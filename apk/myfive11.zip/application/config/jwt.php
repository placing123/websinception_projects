<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['jwt_key'] = 'ingDLMRuGe9UKHRNjs7cYckS2yul4lc3';

$config['jwt_algorithm'] = 'HS256';
