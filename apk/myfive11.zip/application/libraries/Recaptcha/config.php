<?php

return [
	'client-key' => '6Lex4GYUAAAAAE7DEFtKEQALwn0WGQKrXbVgsKnR',
	'secret-key' => '6Lex4GYUAAAAAI3lDlMpU9gVi7GbWC-KNnOeC2m9'
];