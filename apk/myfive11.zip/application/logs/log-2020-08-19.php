<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-19 00:00:02 --> Config Class Initialized
INFO - 2020-08-19 00:00:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:00:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:02 --> URI Class Initialized
INFO - 2020-08-19 00:00:02 --> Config Class Initialized
INFO - 2020-08-19 00:00:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:00:02 --> Router Class Initialized
INFO - 2020-08-19 00:00:02 --> Output Class Initialized
DEBUG - 2020-08-19 00:00:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:02 --> Security Class Initialized
INFO - 2020-08-19 00:00:02 --> URI Class Initialized
DEBUG - 2020-08-19 00:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:02 --> Input Class Initialized
INFO - 2020-08-19 00:00:02 --> Language Class Initialized
INFO - 2020-08-19 00:00:02 --> Router Class Initialized
INFO - 2020-08-19 00:00:02 --> Output Class Initialized
INFO - 2020-08-19 00:00:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:02 --> Input Class Initialized
INFO - 2020-08-19 00:00:02 --> Language Class Initialized
INFO - 2020-08-19 00:00:02 --> Language Class Initialized
INFO - 2020-08-19 00:00:02 --> Config Class Initialized
INFO - 2020-08-19 00:00:02 --> Loader Class Initialized
INFO - 2020-08-19 00:00:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:02 --> Language Class Initialized
INFO - 2020-08-19 00:00:02 --> Config Class Initialized
INFO - 2020-08-19 00:00:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:02 --> Loader Class Initialized
INFO - 2020-08-19 00:00:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:00:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:02 --> Upload Class Initialized
INFO - 2020-08-19 00:00:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:00:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:00:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:03 --> URI Class Initialized
INFO - 2020-08-19 00:00:03 --> Router Class Initialized
INFO - 2020-08-19 00:00:03 --> Output Class Initialized
INFO - 2020-08-19 00:00:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:03 --> Input Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Loader Class Initialized
INFO - 2020-08-19 00:00:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:03 --> Upload Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:00:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:03 --> URI Class Initialized
DEBUG - 2020-08-19 00:00:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:03 --> URI Class Initialized
INFO - 2020-08-19 00:00:03 --> Router Class Initialized
INFO - 2020-08-19 00:00:03 --> Output Class Initialized
INFO - 2020-08-19 00:00:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:03 --> Input Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Router Class Initialized
INFO - 2020-08-19 00:00:03 --> Output Class Initialized
INFO - 2020-08-19 00:00:03 --> Security Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:03 --> Input Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Loader Class Initialized
INFO - 2020-08-19 00:00:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:03 --> Loader Class Initialized
INFO - 2020-08-19 00:00:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:00:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:03 --> Upload Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:00:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:03 --> URI Class Initialized
INFO - 2020-08-19 00:00:03 --> Router Class Initialized
INFO - 2020-08-19 00:00:03 --> Output Class Initialized
INFO - 2020-08-19 00:00:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:03 --> Input Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Upload Class Initialized
INFO - 2020-08-19 00:00:03 --> Loader Class Initialized
INFO - 2020-08-19 00:00:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:00:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:00:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:00:03 --> URI Class Initialized
INFO - 2020-08-19 00:00:03 --> Router Class Initialized
INFO - 2020-08-19 00:00:03 --> Output Class Initialized
INFO - 2020-08-19 00:00:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:00:03 --> Input Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Language Class Initialized
INFO - 2020-08-19 00:00:03 --> Config Class Initialized
INFO - 2020-08-19 00:00:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:03 --> Loader Class Initialized
INFO - 2020-08-19 00:00:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:00:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:00:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:00:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:00:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:04 --> Upload Class Initialized
DEBUG - 2020-08-19 00:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:00:04 --> Upload Class Initialized
INFO - 2020-08-19 00:00:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:00:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:00:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:01:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:01:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:01:02 --> URI Class Initialized
INFO - 2020-08-19 00:01:02 --> Router Class Initialized
INFO - 2020-08-19 00:01:02 --> Output Class Initialized
INFO - 2020-08-19 00:01:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:01:02 --> Input Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Loader Class Initialized
INFO - 2020-08-19 00:01:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:01:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:01:02 --> Upload Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:01:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:01:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:01:02 --> URI Class Initialized
INFO - 2020-08-19 00:01:02 --> Router Class Initialized
INFO - 2020-08-19 00:01:02 --> Output Class Initialized
INFO - 2020-08-19 00:01:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:01:02 --> Input Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Loader Class Initialized
INFO - 2020-08-19 00:01:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:01:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:01:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:01:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:01:02 --> Upload Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:01:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:01:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:01:02 --> URI Class Initialized
INFO - 2020-08-19 00:01:02 --> Router Class Initialized
INFO - 2020-08-19 00:01:02 --> Output Class Initialized
INFO - 2020-08-19 00:01:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:01:02 --> Input Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:01:02 --> Loader Class Initialized
INFO - 2020-08-19 00:01:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:01:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:01:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:01:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:01:02 --> URI Class Initialized
INFO - 2020-08-19 00:01:02 --> Router Class Initialized
INFO - 2020-08-19 00:01:02 --> Output Class Initialized
INFO - 2020-08-19 00:01:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:01:02 --> Input Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:01:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:01:02 --> Loader Class Initialized
INFO - 2020-08-19 00:01:02 --> Helper loaded: url_helper
DEBUG - 2020-08-19 00:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:01:02 --> Upload Class Initialized
INFO - 2020-08-19 00:01:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:01:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
INFO - 2020-08-19 00:01:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:01:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:01:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:01:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:01:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:01:02 --> URI Class Initialized
INFO - 2020-08-19 00:01:02 --> Router Class Initialized
INFO - 2020-08-19 00:01:02 --> Output Class Initialized
INFO - 2020-08-19 00:01:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:01:02 --> Input Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Language Class Initialized
INFO - 2020-08-19 00:01:02 --> Config Class Initialized
DEBUG - 2020-08-19 00:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:01:02 --> Upload Class Initialized
INFO - 2020-08-19 00:01:02 --> Loader Class Initialized
INFO - 2020-08-19 00:01:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:01:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:01:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:01:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:01:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:01:02 --> Upload Class Initialized
INFO - 2020-08-19 00:01:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:01:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:02:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:02:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:02:02 --> URI Class Initialized
INFO - 2020-08-19 00:02:02 --> Router Class Initialized
INFO - 2020-08-19 00:02:02 --> Output Class Initialized
INFO - 2020-08-19 00:02:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:02:02 --> Input Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Loader Class Initialized
INFO - 2020-08-19 00:02:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:02:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:02:02 --> Upload Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:02:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:02:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:02:02 --> URI Class Initialized
INFO - 2020-08-19 00:02:02 --> Router Class Initialized
INFO - 2020-08-19 00:02:02 --> Output Class Initialized
INFO - 2020-08-19 00:02:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:02:02 --> Input Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Loader Class Initialized
INFO - 2020-08-19 00:02:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:02:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:02:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:02:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:02:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:02:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:02:02 --> URI Class Initialized
INFO - 2020-08-19 00:02:02 --> Router Class Initialized
INFO - 2020-08-19 00:02:02 --> Output Class Initialized
INFO - 2020-08-19 00:02:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:02:02 --> Input Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Loader Class Initialized
INFO - 2020-08-19 00:02:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:02:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:02:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:02:02 --> Upload Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:02:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:02:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:02:02 --> URI Class Initialized
INFO - 2020-08-19 00:02:02 --> Router Class Initialized
INFO - 2020-08-19 00:02:02 --> Output Class Initialized
INFO - 2020-08-19 00:02:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:02:02 --> Input Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:02:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:02:02 --> Loader Class Initialized
INFO - 2020-08-19 00:02:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:02:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:02:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:02:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:02:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:02:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:02:02 --> URI Class Initialized
INFO - 2020-08-19 00:02:02 --> Router Class Initialized
INFO - 2020-08-19 00:02:02 --> Output Class Initialized
INFO - 2020-08-19 00:02:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:02:02 --> Input Class Initialized
INFO - 2020-08-19 00:02:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Language Class Initialized
INFO - 2020-08-19 00:02:02 --> Config Class Initialized
INFO - 2020-08-19 00:02:02 --> Loader Class Initialized
INFO - 2020-08-19 00:02:02 --> Helper loaded: url_helper
DEBUG - 2020-08-19 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:02:02 --> Upload Class Initialized
INFO - 2020-08-19 00:02:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:02:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:02:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:02:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:02:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:02:02 --> Upload Class Initialized
INFO - 2020-08-19 00:02:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:02:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:03:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:03:02 --> URI Class Initialized
INFO - 2020-08-19 00:03:02 --> Router Class Initialized
INFO - 2020-08-19 00:03:02 --> Output Class Initialized
INFO - 2020-08-19 00:03:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:03:02 --> Input Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Loader Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:03:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:03:02 --> URI Class Initialized
INFO - 2020-08-19 00:03:02 --> Router Class Initialized
INFO - 2020-08-19 00:03:02 --> Output Class Initialized
INFO - 2020-08-19 00:03:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:03:02 --> Input Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:03:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:03:02 --> Upload Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:03:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:03:02 --> URI Class Initialized
INFO - 2020-08-19 00:03:02 --> Router Class Initialized
INFO - 2020-08-19 00:03:02 --> Loader Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:03:02 --> Output Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:03:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:03:02 --> Input Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:03:02 --> Loader Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: url_helper
DEBUG - 2020-08-19 00:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:03:02 --> Upload Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:03:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:03:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:03:02 --> URI Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:03:02 --> Router Class Initialized
DEBUG - 2020-08-19 00:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:03:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:03:02 --> Output Class Initialized
INFO - 2020-08-19 00:03:02 --> URI Class Initialized
INFO - 2020-08-19 00:03:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:03:02 --> Input Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Router Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Output Class Initialized
INFO - 2020-08-19 00:03:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:03:02 --> Input Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:03:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:03:02 --> Upload Class Initialized
INFO - 2020-08-19 00:03:02 --> Language Class Initialized
INFO - 2020-08-19 00:03:02 --> Config Class Initialized
INFO - 2020-08-19 00:03:02 --> Loader Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:03:02 --> Loader Class Initialized
INFO - 2020-08-19 00:03:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:03:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:03:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:03:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:03:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:03:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:03:02 --> Upload Class Initialized
INFO - 2020-08-19 00:03:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:03:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:03:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:03:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:03:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:03:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:04:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:04:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:04:02 --> URI Class Initialized
INFO - 2020-08-19 00:04:02 --> Router Class Initialized
INFO - 2020-08-19 00:04:02 --> Output Class Initialized
INFO - 2020-08-19 00:04:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:04:02 --> Input Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Loader Class Initialized
INFO - 2020-08-19 00:04:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:04:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:04:02 --> Upload Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:04:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:04:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:04:02 --> URI Class Initialized
INFO - 2020-08-19 00:04:02 --> Router Class Initialized
INFO - 2020-08-19 00:04:02 --> Output Class Initialized
INFO - 2020-08-19 00:04:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:04:02 --> Input Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Loader Class Initialized
INFO - 2020-08-19 00:04:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:04:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:04:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:04:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:04:02 --> Upload Class Initialized
INFO - 2020-08-19 00:04:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:04:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:04:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:04:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:04:02 --> URI Class Initialized
INFO - 2020-08-19 00:04:02 --> Router Class Initialized
INFO - 2020-08-19 00:04:02 --> Output Class Initialized
INFO - 2020-08-19 00:04:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:04:02 --> Input Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Loader Class Initialized
INFO - 2020-08-19 00:04:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:04:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-19 00:04:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:04:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:04:02 --> URI Class Initialized
INFO - 2020-08-19 00:04:02 --> Upload Class Initialized
INFO - 2020-08-19 00:04:02 --> Router Class Initialized
INFO - 2020-08-19 00:04:02 --> Output Class Initialized
INFO - 2020-08-19 00:04:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:04:02 --> Input Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Loader Class Initialized
INFO - 2020-08-19 00:04:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:04:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:04:02 --> Upload Class Initialized
INFO - 2020-08-19 00:04:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:04:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:04:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:04:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:04:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:04:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:04:02 --> URI Class Initialized
INFO - 2020-08-19 00:04:02 --> Router Class Initialized
INFO - 2020-08-19 00:04:02 --> Output Class Initialized
INFO - 2020-08-19 00:04:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:04:02 --> Input Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Language Class Initialized
INFO - 2020-08-19 00:04:02 --> Config Class Initialized
INFO - 2020-08-19 00:04:02 --> Loader Class Initialized
INFO - 2020-08-19 00:04:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:04:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:04:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:04:02 --> Upload Class Initialized
INFO - 2020-08-19 00:04:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:04:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:05:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:05:03 --> URI Class Initialized
INFO - 2020-08-19 00:05:03 --> Router Class Initialized
INFO - 2020-08-19 00:05:03 --> Output Class Initialized
INFO - 2020-08-19 00:05:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:05:03 --> Input Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Loader Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:05:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:05:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:05:03 --> Upload Class Initialized
INFO - 2020-08-19 00:05:03 --> URI Class Initialized
INFO - 2020-08-19 00:05:03 --> Router Class Initialized
INFO - 2020-08-19 00:05:03 --> Output Class Initialized
INFO - 2020-08-19 00:05:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:05:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:05:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:05:03 --> Input Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Loader Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:05:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:05:03 --> URI Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:05:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:05:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:05:03 --> Router Class Initialized
INFO - 2020-08-19 00:05:03 --> URI Class Initialized
INFO - 2020-08-19 00:05:03 --> Output Class Initialized
INFO - 2020-08-19 00:05:03 --> Router Class Initialized
INFO - 2020-08-19 00:05:03 --> Security Class Initialized
INFO - 2020-08-19 00:05:03 --> Output Class Initialized
DEBUG - 2020-08-19 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:05:03 --> Input Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Security Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
DEBUG - 2020-08-19 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:05:03 --> Input Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
DEBUG - 2020-08-19 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:05:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:05:03 --> URI Class Initialized
INFO - 2020-08-19 00:05:03 --> Loader Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:05:03 --> Router Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:05:03 --> Output Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:05:03 --> Security Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:05:03 --> Input Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Loader Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:05:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:05:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:05:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:05:03 --> Upload Class Initialized
INFO - 2020-08-19 00:05:03 --> Language Class Initialized
INFO - 2020-08-19 00:05:03 --> Config Class Initialized
INFO - 2020-08-19 00:05:03 --> Loader Class Initialized
INFO - 2020-08-19 00:05:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:05:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:05:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:05:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:05:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:05:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:05:03 --> Upload Class Initialized
INFO - 2020-08-19 00:05:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:05:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:05:03 --> Upload Class Initialized
INFO - 2020-08-19 00:05:03 --> Controller Class Initialized
INFO - 2020-08-19 00:05:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:05:03 --> 404 Page Not Found: /index
ERROR - 2020-08-19 00:05:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:06:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:06:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:06:02 --> URI Class Initialized
INFO - 2020-08-19 00:06:02 --> Router Class Initialized
INFO - 2020-08-19 00:06:02 --> Output Class Initialized
INFO - 2020-08-19 00:06:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:06:02 --> Input Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Loader Class Initialized
INFO - 2020-08-19 00:06:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:06:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:06:02 --> Upload Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:06:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:06:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:06:02 --> URI Class Initialized
INFO - 2020-08-19 00:06:02 --> Router Class Initialized
INFO - 2020-08-19 00:06:02 --> Output Class Initialized
INFO - 2020-08-19 00:06:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:06:02 --> Input Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Loader Class Initialized
INFO - 2020-08-19 00:06:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:06:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:06:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:06:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:06:02 --> Upload Class Initialized
INFO - 2020-08-19 00:06:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:06:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:06:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:06:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:06:02 --> URI Class Initialized
INFO - 2020-08-19 00:06:02 --> Router Class Initialized
INFO - 2020-08-19 00:06:02 --> Output Class Initialized
INFO - 2020-08-19 00:06:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:06:02 --> Input Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
DEBUG - 2020-08-19 00:06:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:06:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:06:02 --> Loader Class Initialized
INFO - 2020-08-19 00:06:02 --> URI Class Initialized
INFO - 2020-08-19 00:06:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:06:02 --> Router Class Initialized
INFO - 2020-08-19 00:06:02 --> Output Class Initialized
INFO - 2020-08-19 00:06:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:06:02 --> Input Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:06:02 --> Loader Class Initialized
INFO - 2020-08-19 00:06:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:06:02 --> Upload Class Initialized
INFO - 2020-08-19 00:06:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:06:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:06:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:06:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:06:02 --> Upload Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:06:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:06:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:06:02 --> URI Class Initialized
INFO - 2020-08-19 00:06:02 --> Router Class Initialized
INFO - 2020-08-19 00:06:02 --> Output Class Initialized
INFO - 2020-08-19 00:06:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:06:02 --> Input Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Language Class Initialized
INFO - 2020-08-19 00:06:02 --> Config Class Initialized
INFO - 2020-08-19 00:06:02 --> Loader Class Initialized
INFO - 2020-08-19 00:06:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:06:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:06:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:06:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:06:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:06:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:06:02 --> Upload Class Initialized
INFO - 2020-08-19 00:06:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:06:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:07:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:07:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:07:02 --> URI Class Initialized
INFO - 2020-08-19 00:07:02 --> Router Class Initialized
INFO - 2020-08-19 00:07:02 --> Output Class Initialized
INFO - 2020-08-19 00:07:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:07:02 --> Input Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Loader Class Initialized
INFO - 2020-08-19 00:07:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:07:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:07:02 --> Upload Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:07:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:07:02 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:07:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:07:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:07:02 --> URI Class Initialized
INFO - 2020-08-19 00:07:02 --> URI Class Initialized
INFO - 2020-08-19 00:07:02 --> Router Class Initialized
INFO - 2020-08-19 00:07:02 --> Router Class Initialized
INFO - 2020-08-19 00:07:02 --> Output Class Initialized
INFO - 2020-08-19 00:07:02 --> Security Class Initialized
INFO - 2020-08-19 00:07:02 --> Output Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:07:02 --> Input Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Security Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:07:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:07:02 --> Loader Class Initialized
INFO - 2020-08-19 00:07:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:07:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:07:02 --> Input Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Loader Class Initialized
INFO - 2020-08-19 00:07:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:07:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:07:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:07:02 --> Upload Class Initialized
INFO - 2020-08-19 00:07:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:07:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:07:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:07:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:07:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:07:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:07:02 --> URI Class Initialized
INFO - 2020-08-19 00:07:02 --> Router Class Initialized
INFO - 2020-08-19 00:07:02 --> Output Class Initialized
INFO - 2020-08-19 00:07:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:07:02 --> Input Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Loader Class Initialized
INFO - 2020-08-19 00:07:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:07:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:07:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:07:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:07:02 --> URI Class Initialized
INFO - 2020-08-19 00:07:02 --> Router Class Initialized
INFO - 2020-08-19 00:07:02 --> Output Class Initialized
INFO - 2020-08-19 00:07:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:07:02 --> Input Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Language Class Initialized
INFO - 2020-08-19 00:07:02 --> Config Class Initialized
INFO - 2020-08-19 00:07:02 --> Loader Class Initialized
INFO - 2020-08-19 00:07:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:07:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:07:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:07:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:07:02 --> Upload Class Initialized
INFO - 2020-08-19 00:07:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:07:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:07:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:07:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:08:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:08:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:08:02 --> URI Class Initialized
INFO - 2020-08-19 00:08:02 --> Router Class Initialized
INFO - 2020-08-19 00:08:02 --> Output Class Initialized
INFO - 2020-08-19 00:08:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:08:02 --> Input Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Loader Class Initialized
INFO - 2020-08-19 00:08:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:08:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:08:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:08:02 --> URI Class Initialized
INFO - 2020-08-19 00:08:02 --> Router Class Initialized
INFO - 2020-08-19 00:08:02 --> Output Class Initialized
INFO - 2020-08-19 00:08:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:08:02 --> Input Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Loader Class Initialized
INFO - 2020-08-19 00:08:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:08:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:08:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:08:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:08:02 --> Upload Class Initialized
INFO - 2020-08-19 00:08:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:08:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:08:02 --> Upload Class Initialized
INFO - 2020-08-19 00:08:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:08:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:08:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:08:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:08:02 --> URI Class Initialized
INFO - 2020-08-19 00:08:02 --> Router Class Initialized
INFO - 2020-08-19 00:08:02 --> Output Class Initialized
INFO - 2020-08-19 00:08:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:08:02 --> Input Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Loader Class Initialized
INFO - 2020-08-19 00:08:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:08:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:08:02 --> Upload Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:08:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:08:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:08:02 --> URI Class Initialized
INFO - 2020-08-19 00:08:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:08:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:08:02 --> Router Class Initialized
INFO - 2020-08-19 00:08:02 --> Output Class Initialized
INFO - 2020-08-19 00:08:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:08:02 --> Input Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:08:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:08:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:08:02 --> URI Class Initialized
INFO - 2020-08-19 00:08:02 --> Router Class Initialized
INFO - 2020-08-19 00:08:02 --> Loader Class Initialized
INFO - 2020-08-19 00:08:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:08:02 --> Output Class Initialized
INFO - 2020-08-19 00:08:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:08:02 --> Input Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Language Class Initialized
INFO - 2020-08-19 00:08:02 --> Config Class Initialized
INFO - 2020-08-19 00:08:02 --> Loader Class Initialized
INFO - 2020-08-19 00:08:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:08:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:08:02 --> Upload Class Initialized
INFO - 2020-08-19 00:08:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:08:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:08:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:08:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:08:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:08:02 --> Upload Class Initialized
INFO - 2020-08-19 00:08:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:08:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:09:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:09:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:09:02 --> URI Class Initialized
INFO - 2020-08-19 00:09:02 --> Router Class Initialized
INFO - 2020-08-19 00:09:02 --> Output Class Initialized
INFO - 2020-08-19 00:09:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:09:02 --> Input Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Loader Class Initialized
INFO - 2020-08-19 00:09:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:09:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:09:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:09:02 --> URI Class Initialized
INFO - 2020-08-19 00:09:02 --> Router Class Initialized
INFO - 2020-08-19 00:09:02 --> Output Class Initialized
INFO - 2020-08-19 00:09:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:09:02 --> Input Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:09:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:09:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:09:02 --> URI Class Initialized
INFO - 2020-08-19 00:09:02 --> Router Class Initialized
INFO - 2020-08-19 00:09:02 --> Output Class Initialized
INFO - 2020-08-19 00:09:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:09:02 --> Input Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Loader Class Initialized
INFO - 2020-08-19 00:09:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:09:02 --> Loader Class Initialized
INFO - 2020-08-19 00:09:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:09:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:09:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:09:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:09:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:09:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:09:02 --> URI Class Initialized
INFO - 2020-08-19 00:09:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:09:02 --> Router Class Initialized
INFO - 2020-08-19 00:09:02 --> Output Class Initialized
INFO - 2020-08-19 00:09:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:09:02 --> Input Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Loader Class Initialized
INFO - 2020-08-19 00:09:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:09:02 --> Upload Class Initialized
INFO - 2020-08-19 00:09:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:09:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:09:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:09:02 --> Upload Class Initialized
INFO - 2020-08-19 00:09:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:09:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:09:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:09:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:09:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:09:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:09:02 --> URI Class Initialized
INFO - 2020-08-19 00:09:02 --> Router Class Initialized
INFO - 2020-08-19 00:09:02 --> Output Class Initialized
INFO - 2020-08-19 00:09:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:09:02 --> Input Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Language Class Initialized
INFO - 2020-08-19 00:09:02 --> Config Class Initialized
INFO - 2020-08-19 00:09:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:09:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:09:02 --> Loader Class Initialized
INFO - 2020-08-19 00:09:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:09:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:09:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:09:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:09:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:09:02 --> Upload Class Initialized
INFO - 2020-08-19 00:09:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:09:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:10:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:10:03 --> URI Class Initialized
INFO - 2020-08-19 00:10:03 --> Router Class Initialized
INFO - 2020-08-19 00:10:03 --> Output Class Initialized
INFO - 2020-08-19 00:10:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:10:03 --> Input Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Loader Class Initialized
INFO - 2020-08-19 00:10:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:10:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:10:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:10:03 --> URI Class Initialized
INFO - 2020-08-19 00:10:03 --> Router Class Initialized
INFO - 2020-08-19 00:10:03 --> Output Class Initialized
INFO - 2020-08-19 00:10:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:10:03 --> Input Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Loader Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:10:03 --> Upload Class Initialized
INFO - 2020-08-19 00:10:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:10:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:10:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:10:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:10:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:10:03 --> URI Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:10:03 --> Upload Class Initialized
INFO - 2020-08-19 00:10:03 --> Router Class Initialized
INFO - 2020-08-19 00:10:03 --> Output Class Initialized
INFO - 2020-08-19 00:10:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:10:03 --> Input Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Loader Class Initialized
INFO - 2020-08-19 00:10:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:10:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:10:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:10:03 --> URI Class Initialized
INFO - 2020-08-19 00:10:03 --> Router Class Initialized
INFO - 2020-08-19 00:10:03 --> Output Class Initialized
INFO - 2020-08-19 00:10:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:10:03 --> Input Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:10:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:10:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:10:03 --> Upload Class Initialized
INFO - 2020-08-19 00:10:03 --> Loader Class Initialized
INFO - 2020-08-19 00:10:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:10:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:10:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:10:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:10:03 --> Upload Class Initialized
INFO - 2020-08-19 00:10:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:10:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:10:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:10:03 --> URI Class Initialized
INFO - 2020-08-19 00:10:03 --> Router Class Initialized
INFO - 2020-08-19 00:10:03 --> Output Class Initialized
INFO - 2020-08-19 00:10:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:10:03 --> Input Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Language Class Initialized
INFO - 2020-08-19 00:10:03 --> Config Class Initialized
INFO - 2020-08-19 00:10:03 --> Loader Class Initialized
INFO - 2020-08-19 00:10:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:10:04 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:10:04 --> Upload Class Initialized
INFO - 2020-08-19 00:10:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:10:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:11:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:11:02 --> URI Class Initialized
INFO - 2020-08-19 00:11:02 --> Router Class Initialized
INFO - 2020-08-19 00:11:02 --> Output Class Initialized
INFO - 2020-08-19 00:11:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:11:02 --> Input Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Loader Class Initialized
INFO - 2020-08-19 00:11:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:11:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:11:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:11:02 --> URI Class Initialized
INFO - 2020-08-19 00:11:02 --> Router Class Initialized
INFO - 2020-08-19 00:11:02 --> Output Class Initialized
INFO - 2020-08-19 00:11:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:11:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:11:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:11:02 --> Input Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Loader Class Initialized
INFO - 2020-08-19 00:11:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:11:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:11:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:11:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:11:02 --> Upload Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:11:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:11:02 --> URI Class Initialized
INFO - 2020-08-19 00:11:02 --> Router Class Initialized
INFO - 2020-08-19 00:11:02 --> Output Class Initialized
INFO - 2020-08-19 00:11:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:11:02 --> Input Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Loader Class Initialized
INFO - 2020-08-19 00:11:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:11:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:11:02 --> URI Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:11:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:11:02 --> URI Class Initialized
INFO - 2020-08-19 00:11:02 --> Router Class Initialized
INFO - 2020-08-19 00:11:02 --> Output Class Initialized
INFO - 2020-08-19 00:11:02 --> Security Class Initialized
INFO - 2020-08-19 00:11:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:11:02 --> Router Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:11:02 --> Input Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Output Class Initialized
INFO - 2020-08-19 00:11:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:11:02 --> Input Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Loader Class Initialized
INFO - 2020-08-19 00:11:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:11:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:11:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:11:02 --> Language Class Initialized
INFO - 2020-08-19 00:11:02 --> Config Class Initialized
INFO - 2020-08-19 00:11:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:11:02 --> Loader Class Initialized
INFO - 2020-08-19 00:11:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:11:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:11:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:11:02 --> Upload Class Initialized
INFO - 2020-08-19 00:11:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:11:02 --> Upload Class Initialized
INFO - 2020-08-19 00:11:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:11:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:11:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:11:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:11:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:11:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:12:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:12:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:12:02 --> URI Class Initialized
INFO - 2020-08-19 00:12:02 --> Router Class Initialized
INFO - 2020-08-19 00:12:02 --> Output Class Initialized
INFO - 2020-08-19 00:12:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:12:02 --> Input Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Loader Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:12:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:12:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:12:02 --> URI Class Initialized
INFO - 2020-08-19 00:12:02 --> Router Class Initialized
INFO - 2020-08-19 00:12:02 --> Output Class Initialized
INFO - 2020-08-19 00:12:02 --> Security Class Initialized
INFO - 2020-08-19 00:12:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:12:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:12:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:12:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:12:02 --> URI Class Initialized
INFO - 2020-08-19 00:12:02 --> Router Class Initialized
INFO - 2020-08-19 00:12:02 --> Output Class Initialized
INFO - 2020-08-19 00:12:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:12:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-19 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:12:02 --> Input Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Upload Class Initialized
INFO - 2020-08-19 00:12:02 --> Loader Class Initialized
INFO - 2020-08-19 00:12:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:12:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:12:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:12:02 --> URI Class Initialized
INFO - 2020-08-19 00:12:02 --> Router Class Initialized
INFO - 2020-08-19 00:12:02 --> Output Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:12:02 --> Input Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Security Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:12:02 --> Input Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Loader Class Initialized
INFO - 2020-08-19 00:12:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:12:02 --> Loader Class Initialized
INFO - 2020-08-19 00:12:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:12:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:12:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:12:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:12:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:12:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:12:02 --> Upload Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
INFO - 2020-08-19 00:12:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:12:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:12:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:12:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:12:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:12:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:12:02 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:12:02 --> URI Class Initialized
INFO - 2020-08-19 00:12:02 --> Router Class Initialized
INFO - 2020-08-19 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:12:02 --> Upload Class Initialized
INFO - 2020-08-19 00:12:02 --> Output Class Initialized
INFO - 2020-08-19 00:12:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:12:02 --> Input Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Controller Class Initialized
INFO - 2020-08-19 00:12:02 --> Language Class Initialized
INFO - 2020-08-19 00:12:02 --> Config Class Initialized
ERROR - 2020-08-19 00:12:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:12:02 --> Loader Class Initialized
INFO - 2020-08-19 00:12:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:12:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:12:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:12:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:12:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:12:02 --> Upload Class Initialized
INFO - 2020-08-19 00:12:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:12:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:13:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:13:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:13:02 --> URI Class Initialized
INFO - 2020-08-19 00:13:02 --> Router Class Initialized
INFO - 2020-08-19 00:13:02 --> Output Class Initialized
INFO - 2020-08-19 00:13:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:13:02 --> Input Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Loader Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:13:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:13:02 --> Upload Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:13:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:13:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:13:02 --> URI Class Initialized
INFO - 2020-08-19 00:13:02 --> Router Class Initialized
INFO - 2020-08-19 00:13:02 --> Output Class Initialized
INFO - 2020-08-19 00:13:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:13:02 --> Input Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Loader Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:13:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:13:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:13:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:13:02 --> Upload Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:13:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:13:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:13:02 --> URI Class Initialized
INFO - 2020-08-19 00:13:02 --> Router Class Initialized
INFO - 2020-08-19 00:13:02 --> Output Class Initialized
INFO - 2020-08-19 00:13:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:13:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:13:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:13:02 --> URI Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:13:02 --> Input Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
DEBUG - 2020-08-19 00:13:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> URI Class Initialized
INFO - 2020-08-19 00:13:02 --> Loader Class Initialized
INFO - 2020-08-19 00:13:02 --> Router Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:13:02 --> Output Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:13:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:13:02 --> Input Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Loader Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:13:02 --> Controller Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: myhelper_helper
ERROR - 2020-08-19 00:13:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:13:02 --> Router Class Initialized
INFO - 2020-08-19 00:13:02 --> Output Class Initialized
INFO - 2020-08-19 00:13:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:13:02 --> Input Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Language Class Initialized
INFO - 2020-08-19 00:13:02 --> Config Class Initialized
INFO - 2020-08-19 00:13:02 --> Loader Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:13:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:13:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:13:02 --> Upload Class Initialized
INFO - 2020-08-19 00:13:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:13:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:13:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:13:02 --> Upload Class Initialized
INFO - 2020-08-19 00:13:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:13:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:13:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:13:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:13:02 --> Upload Class Initialized
INFO - 2020-08-19 00:13:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:13:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:14:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:14:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:14:02 --> URI Class Initialized
INFO - 2020-08-19 00:14:02 --> Router Class Initialized
INFO - 2020-08-19 00:14:02 --> Output Class Initialized
INFO - 2020-08-19 00:14:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:14:02 --> Input Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Loader Class Initialized
INFO - 2020-08-19 00:14:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:14:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:14:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:14:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:14:02 --> URI Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:14:02 --> Upload Class Initialized
INFO - 2020-08-19 00:14:02 --> Router Class Initialized
INFO - 2020-08-19 00:14:02 --> Output Class Initialized
INFO - 2020-08-19 00:14:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:14:02 --> Input Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Loader Class Initialized
INFO - 2020-08-19 00:14:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:14:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:14:02 --> Upload Class Initialized
INFO - 2020-08-19 00:14:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:14:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:14:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:14:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:14:02 --> URI Class Initialized
INFO - 2020-08-19 00:14:02 --> Router Class Initialized
INFO - 2020-08-19 00:14:02 --> Output Class Initialized
INFO - 2020-08-19 00:14:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:14:02 --> Input Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Loader Class Initialized
INFO - 2020-08-19 00:14:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:14:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:14:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:14:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:14:02 --> Upload Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:14:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:14:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:14:02 --> URI Class Initialized
INFO - 2020-08-19 00:14:02 --> Router Class Initialized
INFO - 2020-08-19 00:14:02 --> Output Class Initialized
INFO - 2020-08-19 00:14:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:14:02 --> Input Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:14:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
INFO - 2020-08-19 00:14:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:14:02 --> Loader Class Initialized
INFO - 2020-08-19 00:14:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:14:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:14:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:14:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:14:02 --> URI Class Initialized
INFO - 2020-08-19 00:14:02 --> Router Class Initialized
INFO - 2020-08-19 00:14:02 --> Output Class Initialized
INFO - 2020-08-19 00:14:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:14:02 --> Input Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Language Class Initialized
INFO - 2020-08-19 00:14:02 --> Config Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:14:02 --> Upload Class Initialized
INFO - 2020-08-19 00:14:02 --> Loader Class Initialized
INFO - 2020-08-19 00:14:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:14:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:14:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:14:02 --> Upload Class Initialized
INFO - 2020-08-19 00:14:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:14:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:14:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:14:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:15:01 --> Config Class Initialized
INFO - 2020-08-19 00:15:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:15:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:15:01 --> Utf8 Class Initialized
INFO - 2020-08-19 00:15:01 --> URI Class Initialized
INFO - 2020-08-19 00:15:01 --> Router Class Initialized
INFO - 2020-08-19 00:15:02 --> Output Class Initialized
INFO - 2020-08-19 00:15:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:15:02 --> Input Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Loader Class Initialized
INFO - 2020-08-19 00:15:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:15:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:15:02 --> Upload Class Initialized
INFO - 2020-08-19 00:15:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:15:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:15:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:15:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:15:02 --> URI Class Initialized
INFO - 2020-08-19 00:15:02 --> Router Class Initialized
INFO - 2020-08-19 00:15:02 --> Output Class Initialized
INFO - 2020-08-19 00:15:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:15:02 --> Input Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Loader Class Initialized
INFO - 2020-08-19 00:15:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:15:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:15:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:15:02 --> URI Class Initialized
INFO - 2020-08-19 00:15:02 --> Router Class Initialized
INFO - 2020-08-19 00:15:02 --> Output Class Initialized
INFO - 2020-08-19 00:15:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:15:02 --> Input Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:15:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:15:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:15:02 --> URI Class Initialized
INFO - 2020-08-19 00:15:02 --> Router Class Initialized
INFO - 2020-08-19 00:15:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:15:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:15:02 --> Output Class Initialized
INFO - 2020-08-19 00:15:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:15:02 --> Input Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Language Class Initialized
INFO - 2020-08-19 00:15:02 --> Config Class Initialized
INFO - 2020-08-19 00:15:02 --> Loader Class Initialized
INFO - 2020-08-19 00:15:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:15:02 --> Loader Class Initialized
INFO - 2020-08-19 00:15:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:15:02 --> Upload Class Initialized
INFO - 2020-08-19 00:15:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:15:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:15:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:15:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:15:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:15:03 --> Upload Class Initialized
INFO - 2020-08-19 00:15:03 --> Config Class Initialized
INFO - 2020-08-19 00:15:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:15:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:15:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:15:03 --> URI Class Initialized
INFO - 2020-08-19 00:15:03 --> Router Class Initialized
INFO - 2020-08-19 00:15:03 --> Output Class Initialized
INFO - 2020-08-19 00:15:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:15:03 --> Input Class Initialized
INFO - 2020-08-19 00:15:03 --> Language Class Initialized
INFO - 2020-08-19 00:15:03 --> Language Class Initialized
INFO - 2020-08-19 00:15:03 --> Config Class Initialized
INFO - 2020-08-19 00:15:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:15:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:15:03 --> Controller Class Initialized
INFO - 2020-08-19 00:15:03 --> Loader Class Initialized
INFO - 2020-08-19 00:15:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:15:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:15:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:15:03 --> Helper loaded: myhelper_helper
ERROR - 2020-08-19 00:15:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:15:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:15:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:15:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:15:03 --> Config Class Initialized
INFO - 2020-08-19 00:15:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:15:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:15:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:15:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:15:03 --> URI Class Initialized
INFO - 2020-08-19 00:15:03 --> Router Class Initialized
INFO - 2020-08-19 00:15:03 --> Output Class Initialized
INFO - 2020-08-19 00:15:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:15:03 --> Input Class Initialized
INFO - 2020-08-19 00:15:03 --> Language Class Initialized
INFO - 2020-08-19 00:15:03 --> Language Class Initialized
INFO - 2020-08-19 00:15:03 --> Config Class Initialized
INFO - 2020-08-19 00:15:03 --> Loader Class Initialized
INFO - 2020-08-19 00:15:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:15:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:15:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:15:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:15:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:15:03 --> Upload Class Initialized
INFO - 2020-08-19 00:15:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:15:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:15:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:15:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:16:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:16:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:16:02 --> URI Class Initialized
INFO - 2020-08-19 00:16:02 --> Router Class Initialized
INFO - 2020-08-19 00:16:02 --> Output Class Initialized
INFO - 2020-08-19 00:16:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:16:02 --> Input Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Loader Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:16:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:16:02 --> Upload Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:16:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:16:02 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:16:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:16:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:16:02 --> URI Class Initialized
INFO - 2020-08-19 00:16:02 --> Router Class Initialized
INFO - 2020-08-19 00:16:02 --> Output Class Initialized
INFO - 2020-08-19 00:16:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:16:02 --> Input Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Loader Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:16:02 --> URI Class Initialized
INFO - 2020-08-19 00:16:02 --> Router Class Initialized
INFO - 2020-08-19 00:16:02 --> Output Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:16:02 --> Security Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:16:02 --> Input Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Loader Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: url_helper
DEBUG - 2020-08-19 00:16:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:16:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:16:02 --> URI Class Initialized
INFO - 2020-08-19 00:16:02 --> Router Class Initialized
INFO - 2020-08-19 00:16:02 --> Output Class Initialized
INFO - 2020-08-19 00:16:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:16:02 --> Input Class Initialized
INFO - 2020-08-19 00:16:02 --> Controller Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
ERROR - 2020-08-19 00:16:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:16:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Loader Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:16:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:16:02 --> Upload Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:16:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:16:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:16:02 --> URI Class Initialized
INFO - 2020-08-19 00:16:02 --> Router Class Initialized
INFO - 2020-08-19 00:16:02 --> Output Class Initialized
INFO - 2020-08-19 00:16:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:16:02 --> Input Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Language Class Initialized
INFO - 2020-08-19 00:16:02 --> Config Class Initialized
INFO - 2020-08-19 00:16:02 --> Loader Class Initialized
INFO - 2020-08-19 00:16:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:16:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:16:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:16:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:16:02 --> Upload Class Initialized
INFO - 2020-08-19 00:16:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:16:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:16:02 --> Upload Class Initialized
INFO - 2020-08-19 00:16:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:16:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:16:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:16:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:16:02 --> Upload Class Initialized
INFO - 2020-08-19 00:16:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:16:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:17:02 --> Config Class Initialized
INFO - 2020-08-19 00:17:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:17:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:17:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:17:02 --> URI Class Initialized
INFO - 2020-08-19 00:17:02 --> Router Class Initialized
INFO - 2020-08-19 00:17:02 --> Output Class Initialized
INFO - 2020-08-19 00:17:02 --> Config Class Initialized
INFO - 2020-08-19 00:17:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:17:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:17:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:17:02 --> URI Class Initialized
INFO - 2020-08-19 00:17:02 --> Router Class Initialized
INFO - 2020-08-19 00:17:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:17:02 --> Input Class Initialized
INFO - 2020-08-19 00:17:02 --> Language Class Initialized
INFO - 2020-08-19 00:17:02 --> Language Class Initialized
INFO - 2020-08-19 00:17:02 --> Config Class Initialized
INFO - 2020-08-19 00:17:02 --> Loader Class Initialized
INFO - 2020-08-19 00:17:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:17:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:17:03 --> Output Class Initialized
INFO - 2020-08-19 00:17:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:17:03 --> Input Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Loader Class Initialized
INFO - 2020-08-19 00:17:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:17:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:17:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:17:03 --> Upload Class Initialized
INFO - 2020-08-19 00:17:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:17:03 --> Upload Class Initialized
INFO - 2020-08-19 00:17:03 --> Controller Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Hooks Class Initialized
ERROR - 2020-08-19 00:17:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:17:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:17:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:17:03 --> URI Class Initialized
INFO - 2020-08-19 00:17:03 --> Router Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:17:03 --> Output Class Initialized
INFO - 2020-08-19 00:17:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:17:03 --> Input Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Loader Class Initialized
INFO - 2020-08-19 00:17:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:17:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:17:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:17:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:17:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:17:03 --> URI Class Initialized
INFO - 2020-08-19 00:17:03 --> Router Class Initialized
INFO - 2020-08-19 00:17:03 --> Output Class Initialized
INFO - 2020-08-19 00:17:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:17:03 --> Input Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Loader Class Initialized
INFO - 2020-08-19 00:17:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:17:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:17:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:17:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:17:03 --> Upload Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:17:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:17:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:17:03 --> URI Class Initialized
INFO - 2020-08-19 00:17:03 --> Router Class Initialized
INFO - 2020-08-19 00:17:03 --> Output Class Initialized
INFO - 2020-08-19 00:17:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:17:03 --> Input Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Language Class Initialized
INFO - 2020-08-19 00:17:03 --> Config Class Initialized
INFO - 2020-08-19 00:17:03 --> Loader Class Initialized
INFO - 2020-08-19 00:17:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:17:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:17:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:17:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:17:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:17:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:17:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:17:03 --> Upload Class Initialized
INFO - 2020-08-19 00:17:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:17:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:18:01 --> Config Class Initialized
INFO - 2020-08-19 00:18:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:18:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:18:01 --> Utf8 Class Initialized
INFO - 2020-08-19 00:18:01 --> URI Class Initialized
INFO - 2020-08-19 00:18:01 --> Router Class Initialized
INFO - 2020-08-19 00:18:01 --> Output Class Initialized
INFO - 2020-08-19 00:18:01 --> Security Class Initialized
DEBUG - 2020-08-19 00:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:18:01 --> Input Class Initialized
INFO - 2020-08-19 00:18:01 --> Language Class Initialized
INFO - 2020-08-19 00:18:01 --> Language Class Initialized
INFO - 2020-08-19 00:18:01 --> Config Class Initialized
INFO - 2020-08-19 00:18:01 --> Loader Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:18:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:18:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:18:02 --> URI Class Initialized
INFO - 2020-08-19 00:18:02 --> Router Class Initialized
INFO - 2020-08-19 00:18:02 --> Output Class Initialized
INFO - 2020-08-19 00:18:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:18:02 --> Input Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Loader Class Initialized
INFO - 2020-08-19 00:18:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:18:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:18:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:18:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:18:02 --> Upload Class Initialized
INFO - 2020-08-19 00:18:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:18:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:18:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:18:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:18:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:18:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:18:02 --> URI Class Initialized
INFO - 2020-08-19 00:18:02 --> Router Class Initialized
INFO - 2020-08-19 00:18:02 --> Output Class Initialized
INFO - 2020-08-19 00:18:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:18:02 --> Input Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Loader Class Initialized
INFO - 2020-08-19 00:18:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:18:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:18:02 --> Upload Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:18:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:18:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:18:02 --> URI Class Initialized
INFO - 2020-08-19 00:18:02 --> Router Class Initialized
INFO - 2020-08-19 00:18:02 --> Output Class Initialized
INFO - 2020-08-19 00:18:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:18:02 --> Input Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Loader Class Initialized
INFO - 2020-08-19 00:18:02 --> Controller Class Initialized
INFO - 2020-08-19 00:18:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: myhelper_helper
ERROR - 2020-08-19 00:18:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:18:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:18:02 --> Upload Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:18:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:18:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:18:02 --> URI Class Initialized
INFO - 2020-08-19 00:18:02 --> Router Class Initialized
INFO - 2020-08-19 00:18:02 --> Output Class Initialized
INFO - 2020-08-19 00:18:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:18:02 --> Input Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Language Class Initialized
INFO - 2020-08-19 00:18:02 --> Config Class Initialized
INFO - 2020-08-19 00:18:02 --> Loader Class Initialized
INFO - 2020-08-19 00:18:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:18:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:18:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:18:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:18:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:18:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:18:02 --> Upload Class Initialized
INFO - 2020-08-19 00:18:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:18:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:19:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:19:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:19:02 --> URI Class Initialized
INFO - 2020-08-19 00:19:02 --> Router Class Initialized
INFO - 2020-08-19 00:19:02 --> Output Class Initialized
INFO - 2020-08-19 00:19:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:19:02 --> Input Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Loader Class Initialized
INFO - 2020-08-19 00:19:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:19:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:19:02 --> Upload Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:19:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:19:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:19:02 --> URI Class Initialized
INFO - 2020-08-19 00:19:02 --> Router Class Initialized
INFO - 2020-08-19 00:19:02 --> Output Class Initialized
INFO - 2020-08-19 00:19:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:19:02 --> Input Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:19:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:19:02 --> Loader Class Initialized
INFO - 2020-08-19 00:19:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:19:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:19:02 --> Upload Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:19:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:19:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:19:02 --> URI Class Initialized
INFO - 2020-08-19 00:19:02 --> Router Class Initialized
INFO - 2020-08-19 00:19:02 --> Output Class Initialized
INFO - 2020-08-19 00:19:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:19:02 --> Input Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Loader Class Initialized
INFO - 2020-08-19 00:19:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:19:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:19:02 --> Upload Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:19:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:19:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:19:02 --> URI Class Initialized
INFO - 2020-08-19 00:19:02 --> Router Class Initialized
INFO - 2020-08-19 00:19:02 --> Output Class Initialized
INFO - 2020-08-19 00:19:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:19:02 --> Input Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:19:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:19:02 --> Loader Class Initialized
INFO - 2020-08-19 00:19:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:19:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:19:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:19:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:19:02 --> Upload Class Initialized
INFO - 2020-08-19 00:19:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:19:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:19:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:19:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:19:02 --> URI Class Initialized
INFO - 2020-08-19 00:19:02 --> Router Class Initialized
INFO - 2020-08-19 00:19:02 --> Output Class Initialized
INFO - 2020-08-19 00:19:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:19:02 --> Input Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Language Class Initialized
INFO - 2020-08-19 00:19:02 --> Config Class Initialized
INFO - 2020-08-19 00:19:02 --> Loader Class Initialized
INFO - 2020-08-19 00:19:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:19:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:19:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:19:02 --> Upload Class Initialized
INFO - 2020-08-19 00:19:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:19:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:20:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:20:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:20:03 --> URI Class Initialized
INFO - 2020-08-19 00:20:03 --> Router Class Initialized
INFO - 2020-08-19 00:20:03 --> Output Class Initialized
INFO - 2020-08-19 00:20:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:20:03 --> Input Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:20:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:20:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:20:03 --> URI Class Initialized
INFO - 2020-08-19 00:20:03 --> Router Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Loader Class Initialized
INFO - 2020-08-19 00:20:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:20:03 --> Output Class Initialized
INFO - 2020-08-19 00:20:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:20:03 --> Input Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Loader Class Initialized
INFO - 2020-08-19 00:20:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:20:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:20:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:20:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:20:03 --> Upload Class Initialized
INFO - 2020-08-19 00:20:03 --> URI Class Initialized
INFO - 2020-08-19 00:20:03 --> Router Class Initialized
INFO - 2020-08-19 00:20:03 --> Output Class Initialized
INFO - 2020-08-19 00:20:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:20:03 --> Upload Class Initialized
INFO - 2020-08-19 00:20:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:20:03 --> Input Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Loader Class Initialized
INFO - 2020-08-19 00:20:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:20:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:20:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:20:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:20:03 --> URI Class Initialized
INFO - 2020-08-19 00:20:03 --> Router Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:20:03 --> Upload Class Initialized
INFO - 2020-08-19 00:20:03 --> Output Class Initialized
INFO - 2020-08-19 00:20:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:20:03 --> Input Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Loader Class Initialized
INFO - 2020-08-19 00:20:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:20:03 --> Controller Class Initialized
INFO - 2020-08-19 00:20:03 --> Helper loaded: file_helper
ERROR - 2020-08-19 00:20:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:20:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:20:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:20:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:20:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:20:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:20:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:20:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:20:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:20:03 --> URI Class Initialized
INFO - 2020-08-19 00:20:03 --> Router Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:20:03 --> Output Class Initialized
INFO - 2020-08-19 00:20:03 --> Upload Class Initialized
INFO - 2020-08-19 00:20:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:20:03 --> Input Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Language Class Initialized
INFO - 2020-08-19 00:20:03 --> Config Class Initialized
INFO - 2020-08-19 00:20:03 --> Loader Class Initialized
INFO - 2020-08-19 00:20:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:20:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:20:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:20:03 --> Upload Class Initialized
INFO - 2020-08-19 00:20:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:20:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:20:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:20:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:21:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:21:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:21:02 --> URI Class Initialized
INFO - 2020-08-19 00:21:02 --> Router Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:21:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:21:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:21:02 --> URI Class Initialized
INFO - 2020-08-19 00:21:02 --> Output Class Initialized
INFO - 2020-08-19 00:21:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:21:02 --> Input Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Loader Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:21:02 --> Router Class Initialized
INFO - 2020-08-19 00:21:02 --> Output Class Initialized
INFO - 2020-08-19 00:21:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:21:02 --> Input Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:21:02 --> Loader Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:21:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:21:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:21:02 --> URI Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:21:02 --> Router Class Initialized
INFO - 2020-08-19 00:21:02 --> Output Class Initialized
INFO - 2020-08-19 00:21:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:21:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:21:02 --> Upload Class Initialized
INFO - 2020-08-19 00:21:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:21:02 --> Input Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Loader Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: form_helper
DEBUG - 2020-08-19 00:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:21:02 --> Upload Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:21:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:21:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:21:02 --> URI Class Initialized
INFO - 2020-08-19 00:21:02 --> Router Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:21:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:21:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:21:02 --> URI Class Initialized
INFO - 2020-08-19 00:21:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:21:02 --> Router Class Initialized
INFO - 2020-08-19 00:21:02 --> Output Class Initialized
INFO - 2020-08-19 00:21:02 --> Output Class Initialized
INFO - 2020-08-19 00:21:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:21:02 --> Input Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Loader Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:21:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:21:02 --> Input Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Language Class Initialized
INFO - 2020-08-19 00:21:02 --> Config Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:21:02 --> Loader Class Initialized
INFO - 2020-08-19 00:21:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:21:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:21:02 --> Upload Class Initialized
INFO - 2020-08-19 00:21:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:21:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:21:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:21:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:21:02 --> Upload Class Initialized
INFO - 2020-08-19 00:21:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:21:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:21:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:21:02 --> Upload Class Initialized
INFO - 2020-08-19 00:21:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:21:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:21:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:21:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:21:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:21:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:22:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:22:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:22:02 --> URI Class Initialized
INFO - 2020-08-19 00:22:02 --> Router Class Initialized
INFO - 2020-08-19 00:22:02 --> Output Class Initialized
INFO - 2020-08-19 00:22:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:22:02 --> Input Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Loader Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:22:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:22:02 --> Upload Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:22:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:22:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:22:02 --> URI Class Initialized
INFO - 2020-08-19 00:22:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:22:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:22:02 --> Router Class Initialized
INFO - 2020-08-19 00:22:02 --> Output Class Initialized
INFO - 2020-08-19 00:22:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:22:02 --> Input Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Loader Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:22:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:22:02 --> Upload Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:22:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:22:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:22:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:22:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:22:02 --> URI Class Initialized
INFO - 2020-08-19 00:22:02 --> Router Class Initialized
INFO - 2020-08-19 00:22:02 --> Output Class Initialized
INFO - 2020-08-19 00:22:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:22:02 --> Input Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Loader Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:22:02 --> URI Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:22:02 --> Router Class Initialized
INFO - 2020-08-19 00:22:02 --> Output Class Initialized
INFO - 2020-08-19 00:22:02 --> Controller Class Initialized
INFO - 2020-08-19 00:22:02 --> Security Class Initialized
ERROR - 2020-08-19 00:22:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:22:02 --> Input Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Loader Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:22:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:22:02 --> Upload Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:22:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:22:02 --> Upload Class Initialized
INFO - 2020-08-19 00:22:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:22:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:22:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:22:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:22:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:22:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:22:02 --> URI Class Initialized
INFO - 2020-08-19 00:22:02 --> Router Class Initialized
INFO - 2020-08-19 00:22:02 --> Output Class Initialized
INFO - 2020-08-19 00:22:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:22:02 --> Input Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Language Class Initialized
INFO - 2020-08-19 00:22:02 --> Config Class Initialized
INFO - 2020-08-19 00:22:02 --> Loader Class Initialized
INFO - 2020-08-19 00:22:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:22:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:22:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:22:02 --> Upload Class Initialized
INFO - 2020-08-19 00:22:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:22:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:23:01 --> Config Class Initialized
INFO - 2020-08-19 00:23:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:23:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:23:01 --> Utf8 Class Initialized
INFO - 2020-08-19 00:23:01 --> URI Class Initialized
INFO - 2020-08-19 00:23:01 --> Router Class Initialized
INFO - 2020-08-19 00:23:01 --> Output Class Initialized
INFO - 2020-08-19 00:23:01 --> Security Class Initialized
DEBUG - 2020-08-19 00:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:23:01 --> Input Class Initialized
INFO - 2020-08-19 00:23:01 --> Language Class Initialized
INFO - 2020-08-19 00:23:01 --> Language Class Initialized
INFO - 2020-08-19 00:23:01 --> Config Class Initialized
INFO - 2020-08-19 00:23:01 --> Loader Class Initialized
INFO - 2020-08-19 00:23:01 --> Helper loaded: url_helper
INFO - 2020-08-19 00:23:01 --> Helper loaded: form_helper
INFO - 2020-08-19 00:23:01 --> Helper loaded: file_helper
INFO - 2020-08-19 00:23:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:23:01 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:23:01 --> Upload Class Initialized
INFO - 2020-08-19 00:23:01 --> Config Class Initialized
INFO - 2020-08-19 00:23:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:23:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:23:01 --> Utf8 Class Initialized
INFO - 2020-08-19 00:23:01 --> URI Class Initialized
INFO - 2020-08-19 00:23:01 --> Router Class Initialized
INFO - 2020-08-19 00:23:01 --> Output Class Initialized
INFO - 2020-08-19 00:23:01 --> Security Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:23:02 --> Input Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Loader Class Initialized
INFO - 2020-08-19 00:23:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:23:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:23:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:23:02 --> URI Class Initialized
INFO - 2020-08-19 00:23:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:23:02 --> Router Class Initialized
INFO - 2020-08-19 00:23:02 --> Output Class Initialized
INFO - 2020-08-19 00:23:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:23:02 --> Input Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:23:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:23:02 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:23:02 --> Upload Class Initialized
INFO - 2020-08-19 00:23:02 --> Loader Class Initialized
INFO - 2020-08-19 00:23:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:23:02 --> URI Class Initialized
INFO - 2020-08-19 00:23:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:23:02 --> Router Class Initialized
INFO - 2020-08-19 00:23:02 --> Output Class Initialized
INFO - 2020-08-19 00:23:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:23:02 --> Input Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:23:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:23:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:23:02 --> URI Class Initialized
INFO - 2020-08-19 00:23:02 --> Router Class Initialized
INFO - 2020-08-19 00:23:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:23:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:23:02 --> Output Class Initialized
INFO - 2020-08-19 00:23:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:23:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:23:02 --> Input Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Language Class Initialized
INFO - 2020-08-19 00:23:02 --> Config Class Initialized
INFO - 2020-08-19 00:23:02 --> Loader Class Initialized
INFO - 2020-08-19 00:23:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:23:02 --> Loader Class Initialized
INFO - 2020-08-19 00:23:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:23:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:23:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:23:02 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:23:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:23:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:23:02 --> Upload Class Initialized
INFO - 2020-08-19 00:23:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:23:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:23:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:23:02 --> Upload Class Initialized
INFO - 2020-08-19 00:23:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:23:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:23:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:23:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:23:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:23:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:24:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:24:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:24:02 --> URI Class Initialized
INFO - 2020-08-19 00:24:02 --> Router Class Initialized
INFO - 2020-08-19 00:24:02 --> Output Class Initialized
INFO - 2020-08-19 00:24:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:24:02 --> Input Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Loader Class Initialized
INFO - 2020-08-19 00:24:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:24:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:24:02 --> Upload Class Initialized
INFO - 2020-08-19 00:24:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:24:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:24:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:24:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:24:02 --> URI Class Initialized
INFO - 2020-08-19 00:24:02 --> Router Class Initialized
INFO - 2020-08-19 00:24:02 --> Output Class Initialized
INFO - 2020-08-19 00:24:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:24:02 --> Input Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Loader Class Initialized
INFO - 2020-08-19 00:24:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:24:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:24:02 --> Upload Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:24:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:24:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:24:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:24:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:24:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:24:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:24:02 --> URI Class Initialized
INFO - 2020-08-19 00:24:02 --> Router Class Initialized
INFO - 2020-08-19 00:24:02 --> Output Class Initialized
INFO - 2020-08-19 00:24:02 --> Security Class Initialized
INFO - 2020-08-19 00:24:02 --> URI Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:24:02 --> Input Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Router Class Initialized
INFO - 2020-08-19 00:24:02 --> Output Class Initialized
INFO - 2020-08-19 00:24:02 --> Loader Class Initialized
INFO - 2020-08-19 00:24:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:24:02 --> Input Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:24:02 --> Loader Class Initialized
INFO - 2020-08-19 00:24:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:24:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:24:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:24:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:24:02 --> Upload Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:24:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:24:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:24:02 --> URI Class Initialized
INFO - 2020-08-19 00:24:02 --> Router Class Initialized
INFO - 2020-08-19 00:24:02 --> Output Class Initialized
INFO - 2020-08-19 00:24:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:24:02 --> Input Class Initialized
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:24:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:24:02 --> Language Class Initialized
INFO - 2020-08-19 00:24:02 --> Config Class Initialized
INFO - 2020-08-19 00:24:02 --> Loader Class Initialized
INFO - 2020-08-19 00:24:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:24:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:24:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:24:02 --> Controller Class Initialized
INFO - 2020-08-19 00:24:02 --> Upload Class Initialized
ERROR - 2020-08-19 00:24:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:24:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:24:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:25:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:25:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:25:03 --> URI Class Initialized
INFO - 2020-08-19 00:25:03 --> Router Class Initialized
INFO - 2020-08-19 00:25:03 --> Output Class Initialized
INFO - 2020-08-19 00:25:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:25:03 --> Input Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Loader Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:25:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:25:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:25:03 --> URI Class Initialized
INFO - 2020-08-19 00:25:03 --> Router Class Initialized
INFO - 2020-08-19 00:25:03 --> Output Class Initialized
INFO - 2020-08-19 00:25:03 --> Security Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:25:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:25:03 --> Input Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Loader Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:25:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:25:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:25:03 --> Upload Class Initialized
INFO - 2020-08-19 00:25:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:25:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:25:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:25:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:25:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:25:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:25:03 --> URI Class Initialized
INFO - 2020-08-19 00:25:03 --> Router Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:25:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:25:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:25:03 --> URI Class Initialized
INFO - 2020-08-19 00:25:03 --> Router Class Initialized
INFO - 2020-08-19 00:25:03 --> Output Class Initialized
INFO - 2020-08-19 00:25:03 --> Security Class Initialized
INFO - 2020-08-19 00:25:03 --> Output Class Initialized
INFO - 2020-08-19 00:25:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:25:03 --> Input Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Loader Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: form_helper
DEBUG - 2020-08-19 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:25:03 --> Input Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:25:03 --> Loader Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:25:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:25:03 --> Upload Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:25:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:25:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:25:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:25:03 --> URI Class Initialized
INFO - 2020-08-19 00:25:03 --> Router Class Initialized
INFO - 2020-08-19 00:25:03 --> Output Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:25:03 --> Upload Class Initialized
INFO - 2020-08-19 00:25:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:25:03 --> Input Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Language Class Initialized
INFO - 2020-08-19 00:25:03 --> Config Class Initialized
INFO - 2020-08-19 00:25:03 --> Loader Class Initialized
INFO - 2020-08-19 00:25:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:25:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:25:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:25:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:25:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:25:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:25:03 --> Upload Class Initialized
INFO - 2020-08-19 00:25:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:25:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:25:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:25:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:26:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:26:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:26:02 --> URI Class Initialized
INFO - 2020-08-19 00:26:02 --> Router Class Initialized
INFO - 2020-08-19 00:26:02 --> Output Class Initialized
INFO - 2020-08-19 00:26:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:26:02 --> Input Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
DEBUG - 2020-08-19 00:26:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:26:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:26:02 --> URI Class Initialized
INFO - 2020-08-19 00:26:02 --> Router Class Initialized
INFO - 2020-08-19 00:26:02 --> Output Class Initialized
INFO - 2020-08-19 00:26:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:26:02 --> Input Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Loader Class Initialized
INFO - 2020-08-19 00:26:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:26:02 --> Loader Class Initialized
INFO - 2020-08-19 00:26:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:26:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:26:02 --> Upload Class Initialized
INFO - 2020-08-19 00:26:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:26:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:26:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:26:02 --> Upload Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:26:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:26:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:26:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:26:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:26:02 --> URI Class Initialized
INFO - 2020-08-19 00:26:02 --> Router Class Initialized
INFO - 2020-08-19 00:26:02 --> Output Class Initialized
INFO - 2020-08-19 00:26:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:26:02 --> Input Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Loader Class Initialized
INFO - 2020-08-19 00:26:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:26:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:26:02 --> Upload Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:26:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:26:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:26:02 --> URI Class Initialized
INFO - 2020-08-19 00:26:02 --> Router Class Initialized
INFO - 2020-08-19 00:26:02 --> Output Class Initialized
INFO - 2020-08-19 00:26:02 --> Security Class Initialized
INFO - 2020-08-19 00:26:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:26:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:26:02 --> Input Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Loader Class Initialized
INFO - 2020-08-19 00:26:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:26:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:26:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:26:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:26:02 --> URI Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:26:02 --> Router Class Initialized
INFO - 2020-08-19 00:26:02 --> Upload Class Initialized
INFO - 2020-08-19 00:26:02 --> Output Class Initialized
INFO - 2020-08-19 00:26:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:26:02 --> Input Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Language Class Initialized
INFO - 2020-08-19 00:26:02 --> Config Class Initialized
INFO - 2020-08-19 00:26:02 --> Loader Class Initialized
INFO - 2020-08-19 00:26:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:26:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:26:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:26:02 --> Upload Class Initialized
INFO - 2020-08-19 00:26:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:26:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:26:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:26:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:27:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:27:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:27:02 --> URI Class Initialized
INFO - 2020-08-19 00:27:02 --> Router Class Initialized
INFO - 2020-08-19 00:27:02 --> Output Class Initialized
INFO - 2020-08-19 00:27:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:27:02 --> Input Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Loader Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:27:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:27:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:27:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:27:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:27:02 --> URI Class Initialized
INFO - 2020-08-19 00:27:02 --> Router Class Initialized
INFO - 2020-08-19 00:27:02 --> Output Class Initialized
INFO - 2020-08-19 00:27:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:27:02 --> Input Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Loader Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:27:02 --> Upload Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:27:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:27:02 --> Upload Class Initialized
INFO - 2020-08-19 00:27:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:27:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:27:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:27:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:27:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:27:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:27:02 --> URI Class Initialized
INFO - 2020-08-19 00:27:02 --> Router Class Initialized
INFO - 2020-08-19 00:27:02 --> Output Class Initialized
INFO - 2020-08-19 00:27:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:27:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:27:02 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:27:02 --> Input Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> URI Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Router Class Initialized
INFO - 2020-08-19 00:27:02 --> Output Class Initialized
INFO - 2020-08-19 00:27:02 --> Loader Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:27:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:27:02 --> Input Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:27:02 --> Loader Class Initialized
INFO - 2020-08-19 00:27:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:27:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:27:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:27:02 --> Upload Class Initialized
INFO - 2020-08-19 00:27:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:27:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:27:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:27:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:27:02 --> URI Class Initialized
INFO - 2020-08-19 00:27:02 --> Router Class Initialized
INFO - 2020-08-19 00:27:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:27:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:27:02 --> Output Class Initialized
INFO - 2020-08-19 00:27:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:27:02 --> Input Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Language Class Initialized
INFO - 2020-08-19 00:27:02 --> Config Class Initialized
INFO - 2020-08-19 00:27:02 --> Loader Class Initialized
INFO - 2020-08-19 00:27:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:27:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:27:02 --> Upload Class Initialized
INFO - 2020-08-19 00:27:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:27:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:28:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:28:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:28:02 --> URI Class Initialized
INFO - 2020-08-19 00:28:02 --> Router Class Initialized
INFO - 2020-08-19 00:28:02 --> Output Class Initialized
INFO - 2020-08-19 00:28:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:28:02 --> Input Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Loader Class Initialized
INFO - 2020-08-19 00:28:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:28:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:28:02 --> Upload Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:28:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:28:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:28:02 --> URI Class Initialized
INFO - 2020-08-19 00:28:02 --> Router Class Initialized
INFO - 2020-08-19 00:28:02 --> Output Class Initialized
INFO - 2020-08-19 00:28:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:28:02 --> Input Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Loader Class Initialized
INFO - 2020-08-19 00:28:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:28:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:28:02 --> Upload Class Initialized
INFO - 2020-08-19 00:28:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:28:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:28:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:28:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:28:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:28:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:28:02 --> URI Class Initialized
INFO - 2020-08-19 00:28:02 --> Router Class Initialized
INFO - 2020-08-19 00:28:02 --> Output Class Initialized
INFO - 2020-08-19 00:28:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:28:02 --> Input Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Loader Class Initialized
INFO - 2020-08-19 00:28:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:28:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:28:02 --> Upload Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:28:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:28:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:28:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:28:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:28:02 --> URI Class Initialized
INFO - 2020-08-19 00:28:02 --> Router Class Initialized
INFO - 2020-08-19 00:28:02 --> Output Class Initialized
INFO - 2020-08-19 00:28:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:28:02 --> Input Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Loader Class Initialized
INFO - 2020-08-19 00:28:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:28:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:28:02 --> Upload Class Initialized
INFO - 2020-08-19 00:28:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:28:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:28:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:28:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:28:02 --> URI Class Initialized
INFO - 2020-08-19 00:28:02 --> Router Class Initialized
INFO - 2020-08-19 00:28:02 --> Output Class Initialized
INFO - 2020-08-19 00:28:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:28:02 --> Input Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Language Class Initialized
INFO - 2020-08-19 00:28:02 --> Config Class Initialized
INFO - 2020-08-19 00:28:02 --> Loader Class Initialized
INFO - 2020-08-19 00:28:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:28:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:28:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:28:02 --> Upload Class Initialized
INFO - 2020-08-19 00:28:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:28:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:29:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:29:02 --> URI Class Initialized
INFO - 2020-08-19 00:29:02 --> Router Class Initialized
INFO - 2020-08-19 00:29:02 --> Output Class Initialized
INFO - 2020-08-19 00:29:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:29:02 --> Input Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Loader Class Initialized
INFO - 2020-08-19 00:29:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:29:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:29:02 --> URI Class Initialized
INFO - 2020-08-19 00:29:02 --> Router Class Initialized
INFO - 2020-08-19 00:29:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:29:02 --> Upload Class Initialized
INFO - 2020-08-19 00:29:02 --> Output Class Initialized
INFO - 2020-08-19 00:29:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:29:02 --> Input Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Loader Class Initialized
INFO - 2020-08-19 00:29:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:29:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:29:02 --> Upload Class Initialized
INFO - 2020-08-19 00:29:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:29:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:29:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:29:02 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:29:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:29:02 --> URI Class Initialized
INFO - 2020-08-19 00:29:02 --> Router Class Initialized
INFO - 2020-08-19 00:29:02 --> Output Class Initialized
INFO - 2020-08-19 00:29:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:29:02 --> Input Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Loader Class Initialized
INFO - 2020-08-19 00:29:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:29:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:29:02 --> Upload Class Initialized
INFO - 2020-08-19 00:29:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:29:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:29:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:29:02 --> URI Class Initialized
INFO - 2020-08-19 00:29:02 --> Router Class Initialized
INFO - 2020-08-19 00:29:02 --> Output Class Initialized
INFO - 2020-08-19 00:29:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:29:02 --> Input Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Loader Class Initialized
INFO - 2020-08-19 00:29:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:29:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:29:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:29:02 --> URI Class Initialized
INFO - 2020-08-19 00:29:02 --> Router Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:29:02 --> Output Class Initialized
INFO - 2020-08-19 00:29:02 --> Upload Class Initialized
INFO - 2020-08-19 00:29:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:29:02 --> Input Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Language Class Initialized
INFO - 2020-08-19 00:29:02 --> Config Class Initialized
INFO - 2020-08-19 00:29:02 --> Loader Class Initialized
INFO - 2020-08-19 00:29:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:29:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:29:02 --> Upload Class Initialized
INFO - 2020-08-19 00:29:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:29:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:29:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:29:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:02 --> Config Class Initialized
INFO - 2020-08-19 00:30:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:30:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:30:02 --> URI Class Initialized
INFO - 2020-08-19 00:30:02 --> Router Class Initialized
INFO - 2020-08-19 00:30:02 --> Output Class Initialized
INFO - 2020-08-19 00:30:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:02 --> Input Class Initialized
INFO - 2020-08-19 00:30:02 --> Language Class Initialized
INFO - 2020-08-19 00:30:02 --> Language Class Initialized
INFO - 2020-08-19 00:30:02 --> Config Class Initialized
INFO - 2020-08-19 00:30:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:30:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:30:02 --> URI Class Initialized
INFO - 2020-08-19 00:30:02 --> Config Class Initialized
INFO - 2020-08-19 00:30:02 --> Loader Class Initialized
INFO - 2020-08-19 00:30:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:02 --> Router Class Initialized
INFO - 2020-08-19 00:30:02 --> Output Class Initialized
INFO - 2020-08-19 00:30:02 --> Security Class Initialized
INFO - 2020-08-19 00:30:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:02 --> Input Class Initialized
INFO - 2020-08-19 00:30:02 --> Language Class Initialized
INFO - 2020-08-19 00:30:02 --> Language Class Initialized
INFO - 2020-08-19 00:30:02 --> Config Class Initialized
INFO - 2020-08-19 00:30:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:02 --> Loader Class Initialized
INFO - 2020-08-19 00:30:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:30:02 --> Upload Class Initialized
INFO - 2020-08-19 00:30:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:03 --> Upload Class Initialized
INFO - 2020-08-19 00:30:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:30:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:30:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:30:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:30:03 --> URI Class Initialized
INFO - 2020-08-19 00:30:03 --> Router Class Initialized
INFO - 2020-08-19 00:30:03 --> Output Class Initialized
INFO - 2020-08-19 00:30:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:03 --> Input Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Loader Class Initialized
INFO - 2020-08-19 00:30:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:30:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:30:03 --> URI Class Initialized
INFO - 2020-08-19 00:30:03 --> Router Class Initialized
INFO - 2020-08-19 00:30:03 --> Output Class Initialized
INFO - 2020-08-19 00:30:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:30:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:30:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:03 --> Input Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Loader Class Initialized
INFO - 2020-08-19 00:30:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:30:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:30:03 --> URI Class Initialized
INFO - 2020-08-19 00:30:03 --> Router Class Initialized
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:30:03 --> Output Class Initialized
INFO - 2020-08-19 00:30:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:30:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:03 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:03 --> Input Class Initialized
INFO - 2020-08-19 00:30:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
INFO - 2020-08-19 00:30:03 --> Loader Class Initialized
INFO - 2020-08-19 00:30:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:30:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:03 --> Upload Class Initialized
INFO - 2020-08-19 00:30:03 --> URI Class Initialized
INFO - 2020-08-19 00:30:03 --> Router Class Initialized
INFO - 2020-08-19 00:30:03 --> Output Class Initialized
INFO - 2020-08-19 00:30:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:03 --> Input Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Language Class Initialized
INFO - 2020-08-19 00:30:03 --> Config Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:03 --> Upload Class Initialized
INFO - 2020-08-19 00:30:03 --> Loader Class Initialized
INFO - 2020-08-19 00:30:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:30:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:30:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:30:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:04 --> Database Driver Class Initialized
INFO - 2020-08-19 00:30:04 --> Config Class Initialized
INFO - 2020-08-19 00:30:04 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:30:04 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:30:04 --> Utf8 Class Initialized
INFO - 2020-08-19 00:30:04 --> URI Class Initialized
DEBUG - 2020-08-19 00:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:04 --> Upload Class Initialized
INFO - 2020-08-19 00:30:04 --> Router Class Initialized
INFO - 2020-08-19 00:30:04 --> Output Class Initialized
INFO - 2020-08-19 00:30:04 --> Security Class Initialized
INFO - 2020-08-19 00:30:04 --> Controller Class Initialized
DEBUG - 2020-08-19 00:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:30:04 --> Input Class Initialized
ERROR - 2020-08-19 00:30:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:04 --> Language Class Initialized
INFO - 2020-08-19 00:30:04 --> Language Class Initialized
INFO - 2020-08-19 00:30:04 --> Config Class Initialized
INFO - 2020-08-19 00:30:04 --> Loader Class Initialized
INFO - 2020-08-19 00:30:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:30:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:30:04 --> Helper loaded: url_helper
INFO - 2020-08-19 00:30:04 --> Helper loaded: form_helper
INFO - 2020-08-19 00:30:04 --> Helper loaded: file_helper
INFO - 2020-08-19 00:30:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:30:04 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:30:04 --> Upload Class Initialized
INFO - 2020-08-19 00:30:04 --> Controller Class Initialized
ERROR - 2020-08-19 00:30:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:31:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:31:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:31:02 --> URI Class Initialized
INFO - 2020-08-19 00:31:02 --> Router Class Initialized
INFO - 2020-08-19 00:31:02 --> Output Class Initialized
INFO - 2020-08-19 00:31:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:31:02 --> Input Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Loader Class Initialized
INFO - 2020-08-19 00:31:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:31:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:31:02 --> Upload Class Initialized
INFO - 2020-08-19 00:31:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:31:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:31:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:31:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:31:02 --> URI Class Initialized
INFO - 2020-08-19 00:31:02 --> Router Class Initialized
INFO - 2020-08-19 00:31:02 --> Output Class Initialized
INFO - 2020-08-19 00:31:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:31:02 --> Input Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Loader Class Initialized
INFO - 2020-08-19 00:31:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:31:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:31:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:31:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:31:02 --> URI Class Initialized
INFO - 2020-08-19 00:31:02 --> Router Class Initialized
INFO - 2020-08-19 00:31:02 --> Output Class Initialized
INFO - 2020-08-19 00:31:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:31:02 --> Input Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Loader Class Initialized
INFO - 2020-08-19 00:31:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:31:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:31:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:31:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:31:02 --> URI Class Initialized
INFO - 2020-08-19 00:31:02 --> Router Class Initialized
INFO - 2020-08-19 00:31:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:31:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:31:02 --> Utf8 Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:31:02 --> URI Class Initialized
INFO - 2020-08-19 00:31:02 --> Upload Class Initialized
INFO - 2020-08-19 00:31:02 --> Router Class Initialized
INFO - 2020-08-19 00:31:02 --> Output Class Initialized
INFO - 2020-08-19 00:31:02 --> Output Class Initialized
INFO - 2020-08-19 00:31:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:31:02 --> Input Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Loader Class Initialized
INFO - 2020-08-19 00:31:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:31:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:31:02 --> Input Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Language Class Initialized
INFO - 2020-08-19 00:31:02 --> Config Class Initialized
INFO - 2020-08-19 00:31:02 --> Loader Class Initialized
INFO - 2020-08-19 00:31:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: file_helper
DEBUG - 2020-08-19 00:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:31:02 --> Upload Class Initialized
INFO - 2020-08-19 00:31:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:31:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:31:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:31:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:31:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:31:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:31:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-19 00:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:31:03 --> Upload Class Initialized
INFO - 2020-08-19 00:31:03 --> Upload Class Initialized
INFO - 2020-08-19 00:31:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:31:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:31:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:31:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:31:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:31:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:32:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:32:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:32:02 --> URI Class Initialized
INFO - 2020-08-19 00:32:02 --> Router Class Initialized
INFO - 2020-08-19 00:32:02 --> Output Class Initialized
INFO - 2020-08-19 00:32:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:32:02 --> Input Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Loader Class Initialized
INFO - 2020-08-19 00:32:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:32:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:32:02 --> Upload Class Initialized
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:32:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:32:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:32:02 --> URI Class Initialized
INFO - 2020-08-19 00:32:02 --> Router Class Initialized
INFO - 2020-08-19 00:32:02 --> Output Class Initialized
INFO - 2020-08-19 00:32:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:32:02 --> Input Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Loader Class Initialized
INFO - 2020-08-19 00:32:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:32:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:32:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:32:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:32:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:32:02 --> Upload Class Initialized
INFO - 2020-08-19 00:32:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:32:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:32:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:32:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:32:02 --> URI Class Initialized
INFO - 2020-08-19 00:32:02 --> Router Class Initialized
INFO - 2020-08-19 00:32:02 --> Output Class Initialized
INFO - 2020-08-19 00:32:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:32:02 --> Input Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Loader Class Initialized
INFO - 2020-08-19 00:32:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:32:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Hooks Class Initialized
INFO - 2020-08-19 00:32:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:32:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:32:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:32:02 --> URI Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:32:02 --> Upload Class Initialized
INFO - 2020-08-19 00:32:02 --> Router Class Initialized
INFO - 2020-08-19 00:32:02 --> Output Class Initialized
INFO - 2020-08-19 00:32:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:32:02 --> Input Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Language Class Initialized
INFO - 2020-08-19 00:32:02 --> Config Class Initialized
INFO - 2020-08-19 00:32:02 --> Loader Class Initialized
INFO - 2020-08-19 00:32:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:32:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:32:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:32:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:32:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:32:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:32:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:32:03 --> Upload Class Initialized
INFO - 2020-08-19 00:32:03 --> Config Class Initialized
INFO - 2020-08-19 00:32:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:32:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:32:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:32:03 --> URI Class Initialized
INFO - 2020-08-19 00:32:03 --> Router Class Initialized
INFO - 2020-08-19 00:32:03 --> Output Class Initialized
INFO - 2020-08-19 00:32:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:32:03 --> Input Class Initialized
INFO - 2020-08-19 00:32:03 --> Language Class Initialized
INFO - 2020-08-19 00:32:03 --> Language Class Initialized
INFO - 2020-08-19 00:32:03 --> Config Class Initialized
INFO - 2020-08-19 00:32:03 --> Loader Class Initialized
INFO - 2020-08-19 00:32:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:32:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:32:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:32:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:32:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:32:03 --> Upload Class Initialized
INFO - 2020-08-19 00:32:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:32:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:32:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:32:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:33:02 --> Config Class Initialized
INFO - 2020-08-19 00:33:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:33:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:33:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:33:02 --> URI Class Initialized
INFO - 2020-08-19 00:33:02 --> Router Class Initialized
INFO - 2020-08-19 00:33:02 --> Output Class Initialized
INFO - 2020-08-19 00:33:02 --> Security Class Initialized
DEBUG - 2020-08-19 00:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:33:02 --> Input Class Initialized
INFO - 2020-08-19 00:33:02 --> Language Class Initialized
INFO - 2020-08-19 00:33:02 --> Config Class Initialized
INFO - 2020-08-19 00:33:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:33:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:33:02 --> Utf8 Class Initialized
INFO - 2020-08-19 00:33:02 --> URI Class Initialized
INFO - 2020-08-19 00:33:02 --> Router Class Initialized
INFO - 2020-08-19 00:33:02 --> Output Class Initialized
INFO - 2020-08-19 00:33:02 --> Security Class Initialized
INFO - 2020-08-19 00:33:02 --> Language Class Initialized
INFO - 2020-08-19 00:33:02 --> Config Class Initialized
INFO - 2020-08-19 00:33:02 --> Loader Class Initialized
INFO - 2020-08-19 00:33:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:33:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:33:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:33:02 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-19 00:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:33:02 --> Input Class Initialized
INFO - 2020-08-19 00:33:02 --> Language Class Initialized
INFO - 2020-08-19 00:33:02 --> Language Class Initialized
INFO - 2020-08-19 00:33:02 --> Config Class Initialized
INFO - 2020-08-19 00:33:02 --> Loader Class Initialized
INFO - 2020-08-19 00:33:02 --> Helper loaded: url_helper
INFO - 2020-08-19 00:33:02 --> Helper loaded: form_helper
INFO - 2020-08-19 00:33:02 --> Helper loaded: file_helper
INFO - 2020-08-19 00:33:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:33:02 --> Database Driver Class Initialized
INFO - 2020-08-19 00:33:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:33:02 --> Upload Class Initialized
DEBUG - 2020-08-19 00:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:33:02 --> Upload Class Initialized
INFO - 2020-08-19 00:33:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:33:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:33:02 --> Controller Class Initialized
ERROR - 2020-08-19 00:33:02 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:33:03 --> Config Class Initialized
INFO - 2020-08-19 00:33:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:33:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:33:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:33:03 --> URI Class Initialized
INFO - 2020-08-19 00:33:03 --> Config Class Initialized
INFO - 2020-08-19 00:33:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:33:03 --> Router Class Initialized
INFO - 2020-08-19 00:33:03 --> Output Class Initialized
INFO - 2020-08-19 00:33:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:33:03 --> Input Class Initialized
INFO - 2020-08-19 00:33:03 --> Language Class Initialized
INFO - 2020-08-19 00:33:03 --> Language Class Initialized
INFO - 2020-08-19 00:33:03 --> Config Class Initialized
INFO - 2020-08-19 00:33:03 --> Loader Class Initialized
INFO - 2020-08-19 00:33:03 --> Helper loaded: url_helper
DEBUG - 2020-08-19 00:33:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:33:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:33:03 --> URI Class Initialized
INFO - 2020-08-19 00:33:03 --> Router Class Initialized
INFO - 2020-08-19 00:33:03 --> Output Class Initialized
INFO - 2020-08-19 00:33:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:33:03 --> Input Class Initialized
INFO - 2020-08-19 00:33:03 --> Language Class Initialized
INFO - 2020-08-19 00:33:03 --> Language Class Initialized
INFO - 2020-08-19 00:33:03 --> Config Class Initialized
INFO - 2020-08-19 00:33:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:33:03 --> Database Driver Class Initialized
INFO - 2020-08-19 00:33:03 --> Loader Class Initialized
INFO - 2020-08-19 00:33:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:33:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:33:03 --> Upload Class Initialized
DEBUG - 2020-08-19 00:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:33:03 --> Upload Class Initialized
INFO - 2020-08-19 00:33:03 --> Config Class Initialized
INFO - 2020-08-19 00:33:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:33:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:33:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:33:03 --> URI Class Initialized
INFO - 2020-08-19 00:33:03 --> Router Class Initialized
INFO - 2020-08-19 00:33:03 --> Output Class Initialized
INFO - 2020-08-19 00:33:03 --> Security Class Initialized
INFO - 2020-08-19 00:33:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:33:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:33:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:33:03 --> 404 Page Not Found: /index
DEBUG - 2020-08-19 00:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:33:03 --> Input Class Initialized
INFO - 2020-08-19 00:33:03 --> Language Class Initialized
INFO - 2020-08-19 00:33:03 --> Language Class Initialized
INFO - 2020-08-19 00:33:03 --> Config Class Initialized
INFO - 2020-08-19 00:33:03 --> Loader Class Initialized
INFO - 2020-08-19 00:33:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:33:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:33:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:33:03 --> Upload Class Initialized
INFO - 2020-08-19 00:33:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:33:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:34:03 --> Config Class Initialized
INFO - 2020-08-19 00:34:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:34:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:34:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:34:03 --> URI Class Initialized
INFO - 2020-08-19 00:34:03 --> Router Class Initialized
INFO - 2020-08-19 00:34:03 --> Output Class Initialized
INFO - 2020-08-19 00:34:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:34:03 --> Input Class Initialized
INFO - 2020-08-19 00:34:03 --> Language Class Initialized
INFO - 2020-08-19 00:34:03 --> Language Class Initialized
INFO - 2020-08-19 00:34:03 --> Config Class Initialized
INFO - 2020-08-19 00:34:03 --> Loader Class Initialized
INFO - 2020-08-19 00:34:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:34:03 --> Config Class Initialized
INFO - 2020-08-19 00:34:03 --> Hooks Class Initialized
INFO - 2020-08-19 00:34:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:34:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:34:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:34:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:34:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:34:03 --> Utf8 Class Initialized
INFO - 2020-08-19 00:34:03 --> URI Class Initialized
INFO - 2020-08-19 00:34:03 --> Router Class Initialized
INFO - 2020-08-19 00:34:03 --> Output Class Initialized
INFO - 2020-08-19 00:34:03 --> Security Class Initialized
DEBUG - 2020-08-19 00:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:34:03 --> Input Class Initialized
INFO - 2020-08-19 00:34:03 --> Language Class Initialized
INFO - 2020-08-19 00:34:03 --> Language Class Initialized
INFO - 2020-08-19 00:34:03 --> Config Class Initialized
DEBUG - 2020-08-19 00:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:34:03 --> Loader Class Initialized
INFO - 2020-08-19 00:34:03 --> Upload Class Initialized
INFO - 2020-08-19 00:34:03 --> Helper loaded: url_helper
INFO - 2020-08-19 00:34:03 --> Helper loaded: form_helper
INFO - 2020-08-19 00:34:03 --> Helper loaded: file_helper
INFO - 2020-08-19 00:34:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:34:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:34:03 --> Upload Class Initialized
INFO - 2020-08-19 00:34:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:34:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:34:03 --> Controller Class Initialized
ERROR - 2020-08-19 00:34:03 --> 404 Page Not Found: /index
INFO - 2020-08-19 00:59:16 --> Config Class Initialized
INFO - 2020-08-19 00:59:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 00:59:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 00:59:16 --> Utf8 Class Initialized
INFO - 2020-08-19 00:59:16 --> URI Class Initialized
DEBUG - 2020-08-19 00:59:16 --> No URI present. Default controller set.
INFO - 2020-08-19 00:59:16 --> Router Class Initialized
INFO - 2020-08-19 00:59:16 --> Output Class Initialized
INFO - 2020-08-19 00:59:16 --> Security Class Initialized
DEBUG - 2020-08-19 00:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 00:59:16 --> Input Class Initialized
INFO - 2020-08-19 00:59:16 --> Language Class Initialized
INFO - 2020-08-19 00:59:16 --> Language Class Initialized
INFO - 2020-08-19 00:59:16 --> Config Class Initialized
INFO - 2020-08-19 00:59:16 --> Loader Class Initialized
INFO - 2020-08-19 00:59:16 --> Helper loaded: url_helper
INFO - 2020-08-19 00:59:16 --> Helper loaded: form_helper
INFO - 2020-08-19 00:59:16 --> Helper loaded: file_helper
INFO - 2020-08-19 00:59:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 00:59:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 00:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 00:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 00:59:16 --> Upload Class Initialized
INFO - 2020-08-19 00:59:16 --> Controller Class Initialized
DEBUG - 2020-08-19 00:59:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 00:59:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 00:59:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 00:59:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 00:59:16 --> Final output sent to browser
DEBUG - 2020-08-19 00:59:16 --> Total execution time: 0.0520
INFO - 2020-08-19 01:09:09 --> Config Class Initialized
INFO - 2020-08-19 01:09:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 01:09:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 01:09:09 --> Utf8 Class Initialized
INFO - 2020-08-19 01:09:09 --> URI Class Initialized
DEBUG - 2020-08-19 01:09:09 --> No URI present. Default controller set.
INFO - 2020-08-19 01:09:09 --> Router Class Initialized
INFO - 2020-08-19 01:09:09 --> Output Class Initialized
INFO - 2020-08-19 01:09:09 --> Security Class Initialized
DEBUG - 2020-08-19 01:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 01:09:09 --> Input Class Initialized
INFO - 2020-08-19 01:09:09 --> Language Class Initialized
INFO - 2020-08-19 01:09:09 --> Language Class Initialized
INFO - 2020-08-19 01:09:09 --> Config Class Initialized
INFO - 2020-08-19 01:09:09 --> Loader Class Initialized
INFO - 2020-08-19 01:09:09 --> Helper loaded: url_helper
INFO - 2020-08-19 01:09:09 --> Helper loaded: form_helper
INFO - 2020-08-19 01:09:09 --> Helper loaded: file_helper
INFO - 2020-08-19 01:09:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 01:09:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 01:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 01:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 01:09:09 --> Upload Class Initialized
INFO - 2020-08-19 01:09:09 --> Controller Class Initialized
DEBUG - 2020-08-19 01:09:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 01:09:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 01:09:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 01:09:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 01:09:09 --> Final output sent to browser
DEBUG - 2020-08-19 01:09:09 --> Total execution time: 0.0535
INFO - 2020-08-19 01:52:58 --> Config Class Initialized
INFO - 2020-08-19 01:52:58 --> Hooks Class Initialized
DEBUG - 2020-08-19 01:52:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 01:52:58 --> Utf8 Class Initialized
INFO - 2020-08-19 01:52:58 --> URI Class Initialized
INFO - 2020-08-19 01:52:58 --> Router Class Initialized
INFO - 2020-08-19 01:52:58 --> Output Class Initialized
INFO - 2020-08-19 01:52:58 --> Security Class Initialized
DEBUG - 2020-08-19 01:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 01:52:58 --> Input Class Initialized
INFO - 2020-08-19 01:52:58 --> Language Class Initialized
INFO - 2020-08-19 01:52:58 --> Language Class Initialized
INFO - 2020-08-19 01:52:58 --> Config Class Initialized
INFO - 2020-08-19 01:52:58 --> Loader Class Initialized
INFO - 2020-08-19 01:52:58 --> Helper loaded: url_helper
INFO - 2020-08-19 01:52:58 --> Helper loaded: form_helper
INFO - 2020-08-19 01:52:58 --> Helper loaded: file_helper
INFO - 2020-08-19 01:52:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 01:52:58 --> Database Driver Class Initialized
DEBUG - 2020-08-19 01:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 01:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 01:52:58 --> Upload Class Initialized
INFO - 2020-08-19 01:52:58 --> Controller Class Initialized
ERROR - 2020-08-19 01:52:58 --> 404 Page Not Found: /index
INFO - 2020-08-19 01:53:01 --> Config Class Initialized
INFO - 2020-08-19 01:53:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 01:53:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 01:53:01 --> Utf8 Class Initialized
INFO - 2020-08-19 01:53:01 --> URI Class Initialized
INFO - 2020-08-19 01:53:02 --> Router Class Initialized
INFO - 2020-08-19 01:53:02 --> Output Class Initialized
INFO - 2020-08-19 01:53:02 --> Security Class Initialized
DEBUG - 2020-08-19 01:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 01:53:02 --> Input Class Initialized
INFO - 2020-08-19 01:53:02 --> Language Class Initialized
INFO - 2020-08-19 01:53:02 --> Language Class Initialized
INFO - 2020-08-19 01:53:02 --> Config Class Initialized
INFO - 2020-08-19 01:53:02 --> Loader Class Initialized
INFO - 2020-08-19 01:53:02 --> Helper loaded: url_helper
INFO - 2020-08-19 01:53:02 --> Helper loaded: form_helper
INFO - 2020-08-19 01:53:02 --> Helper loaded: file_helper
INFO - 2020-08-19 01:53:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 01:53:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 01:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 01:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 01:53:02 --> Upload Class Initialized
INFO - 2020-08-19 01:53:02 --> Controller Class Initialized
DEBUG - 2020-08-19 01:53:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 01:53:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-19 01:53:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 01:53:02 --> Final output sent to browser
DEBUG - 2020-08-19 01:53:02 --> Total execution time: 0.2362
INFO - 2020-08-19 07:23:39 --> Config Class Initialized
INFO - 2020-08-19 07:23:39 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:23:39 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:23:39 --> Utf8 Class Initialized
INFO - 2020-08-19 07:23:39 --> URI Class Initialized
DEBUG - 2020-08-19 07:23:39 --> No URI present. Default controller set.
INFO - 2020-08-19 07:23:39 --> Router Class Initialized
INFO - 2020-08-19 07:23:39 --> Output Class Initialized
INFO - 2020-08-19 07:23:39 --> Security Class Initialized
DEBUG - 2020-08-19 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:23:39 --> Input Class Initialized
INFO - 2020-08-19 07:23:39 --> Language Class Initialized
INFO - 2020-08-19 07:23:39 --> Language Class Initialized
INFO - 2020-08-19 07:23:39 --> Config Class Initialized
INFO - 2020-08-19 07:23:39 --> Loader Class Initialized
INFO - 2020-08-19 07:23:39 --> Helper loaded: url_helper
INFO - 2020-08-19 07:23:39 --> Helper loaded: form_helper
INFO - 2020-08-19 07:23:39 --> Helper loaded: file_helper
INFO - 2020-08-19 07:23:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 07:23:39 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:23:39 --> Upload Class Initialized
INFO - 2020-08-19 07:23:39 --> Controller Class Initialized
DEBUG - 2020-08-19 07:23:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 07:23:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 07:23:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 07:23:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 07:23:39 --> Final output sent to browser
DEBUG - 2020-08-19 07:23:39 --> Total execution time: 0.0618
INFO - 2020-08-19 07:58:13 --> Config Class Initialized
INFO - 2020-08-19 07:58:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:58:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:58:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:58:13 --> URI Class Initialized
INFO - 2020-08-19 07:58:13 --> Router Class Initialized
INFO - 2020-08-19 07:58:13 --> Output Class Initialized
INFO - 2020-08-19 07:58:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:58:13 --> Input Class Initialized
INFO - 2020-08-19 07:58:13 --> Language Class Initialized
INFO - 2020-08-19 07:58:13 --> Language Class Initialized
INFO - 2020-08-19 07:58:13 --> Config Class Initialized
INFO - 2020-08-19 07:58:13 --> Loader Class Initialized
INFO - 2020-08-19 07:58:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:58:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:58:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:58:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 07:58:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:58:13 --> Upload Class Initialized
INFO - 2020-08-19 07:58:13 --> Controller Class Initialized
ERROR - 2020-08-19 07:58:13 --> 404 Page Not Found: /index
INFO - 2020-08-19 07:58:17 --> Config Class Initialized
INFO - 2020-08-19 07:58:17 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:58:17 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:58:17 --> Utf8 Class Initialized
INFO - 2020-08-19 07:58:17 --> URI Class Initialized
INFO - 2020-08-19 07:58:17 --> Router Class Initialized
INFO - 2020-08-19 07:58:17 --> Output Class Initialized
INFO - 2020-08-19 07:58:17 --> Security Class Initialized
DEBUG - 2020-08-19 07:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:58:17 --> Input Class Initialized
INFO - 2020-08-19 07:58:17 --> Language Class Initialized
INFO - 2020-08-19 07:58:17 --> Language Class Initialized
INFO - 2020-08-19 07:58:17 --> Config Class Initialized
INFO - 2020-08-19 07:58:17 --> Loader Class Initialized
INFO - 2020-08-19 07:58:17 --> Helper loaded: url_helper
INFO - 2020-08-19 07:58:17 --> Helper loaded: form_helper
INFO - 2020-08-19 07:58:17 --> Helper loaded: file_helper
INFO - 2020-08-19 07:58:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 07:58:17 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:58:17 --> Upload Class Initialized
INFO - 2020-08-19 07:58:17 --> Controller Class Initialized
DEBUG - 2020-08-19 07:58:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 07:58:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-19 07:58:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 07:58:17 --> Final output sent to browser
DEBUG - 2020-08-19 07:58:17 --> Total execution time: 0.0637
INFO - 2020-08-19 08:18:45 --> Config Class Initialized
INFO - 2020-08-19 08:18:45 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:18:45 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:18:45 --> Utf8 Class Initialized
INFO - 2020-08-19 08:18:45 --> URI Class Initialized
DEBUG - 2020-08-19 08:18:45 --> No URI present. Default controller set.
INFO - 2020-08-19 08:18:45 --> Router Class Initialized
INFO - 2020-08-19 08:18:45 --> Output Class Initialized
INFO - 2020-08-19 08:18:45 --> Security Class Initialized
DEBUG - 2020-08-19 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:18:45 --> Input Class Initialized
INFO - 2020-08-19 08:18:45 --> Language Class Initialized
INFO - 2020-08-19 08:18:45 --> Language Class Initialized
INFO - 2020-08-19 08:18:45 --> Config Class Initialized
INFO - 2020-08-19 08:18:45 --> Loader Class Initialized
INFO - 2020-08-19 08:18:45 --> Helper loaded: url_helper
INFO - 2020-08-19 08:18:45 --> Helper loaded: form_helper
INFO - 2020-08-19 08:18:45 --> Helper loaded: file_helper
INFO - 2020-08-19 08:18:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 08:18:45 --> Database Driver Class Initialized
DEBUG - 2020-08-19 08:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:18:45 --> Upload Class Initialized
INFO - 2020-08-19 08:18:45 --> Controller Class Initialized
DEBUG - 2020-08-19 08:18:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 08:18:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 08:18:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 08:18:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 08:18:45 --> Final output sent to browser
DEBUG - 2020-08-19 08:18:45 --> Total execution time: 0.0500
INFO - 2020-08-19 08:18:46 --> Config Class Initialized
INFO - 2020-08-19 08:18:46 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:18:46 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:18:46 --> Utf8 Class Initialized
INFO - 2020-08-19 08:18:46 --> URI Class Initialized
INFO - 2020-08-19 08:18:46 --> Router Class Initialized
INFO - 2020-08-19 08:18:46 --> Output Class Initialized
INFO - 2020-08-19 08:18:46 --> Security Class Initialized
DEBUG - 2020-08-19 08:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:18:46 --> Input Class Initialized
INFO - 2020-08-19 08:18:46 --> Language Class Initialized
INFO - 2020-08-19 08:18:46 --> Language Class Initialized
INFO - 2020-08-19 08:18:46 --> Config Class Initialized
INFO - 2020-08-19 08:18:46 --> Loader Class Initialized
INFO - 2020-08-19 08:18:46 --> Helper loaded: url_helper
INFO - 2020-08-19 08:18:46 --> Helper loaded: form_helper
INFO - 2020-08-19 08:18:46 --> Helper loaded: file_helper
INFO - 2020-08-19 08:18:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 08:18:46 --> Database Driver Class Initialized
DEBUG - 2020-08-19 08:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 08:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:18:46 --> Upload Class Initialized
INFO - 2020-08-19 08:18:46 --> Controller Class Initialized
ERROR - 2020-08-19 08:18:46 --> 404 Page Not Found: /index
INFO - 2020-08-19 08:24:50 --> Config Class Initialized
INFO - 2020-08-19 08:24:50 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:24:50 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:24:50 --> Utf8 Class Initialized
INFO - 2020-08-19 08:24:50 --> URI Class Initialized
DEBUG - 2020-08-19 08:24:50 --> No URI present. Default controller set.
INFO - 2020-08-19 08:24:50 --> Router Class Initialized
INFO - 2020-08-19 08:24:50 --> Output Class Initialized
INFO - 2020-08-19 08:24:50 --> Security Class Initialized
DEBUG - 2020-08-19 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:24:50 --> Input Class Initialized
INFO - 2020-08-19 08:24:50 --> Language Class Initialized
INFO - 2020-08-19 08:24:50 --> Language Class Initialized
INFO - 2020-08-19 08:24:50 --> Config Class Initialized
INFO - 2020-08-19 08:24:50 --> Loader Class Initialized
INFO - 2020-08-19 08:24:50 --> Helper loaded: url_helper
INFO - 2020-08-19 08:24:50 --> Helper loaded: form_helper
INFO - 2020-08-19 08:24:50 --> Helper loaded: file_helper
INFO - 2020-08-19 08:24:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 08:24:50 --> Database Driver Class Initialized
DEBUG - 2020-08-19 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:24:50 --> Upload Class Initialized
INFO - 2020-08-19 08:24:50 --> Controller Class Initialized
DEBUG - 2020-08-19 08:24:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 08:24:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 08:24:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 08:24:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 08:24:50 --> Final output sent to browser
DEBUG - 2020-08-19 08:24:50 --> Total execution time: 0.0523
INFO - 2020-08-19 08:41:57 --> Config Class Initialized
INFO - 2020-08-19 08:41:57 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:41:57 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:41:57 --> Utf8 Class Initialized
INFO - 2020-08-19 08:41:57 --> URI Class Initialized
INFO - 2020-08-19 08:41:57 --> Router Class Initialized
INFO - 2020-08-19 08:41:57 --> Output Class Initialized
INFO - 2020-08-19 08:41:57 --> Security Class Initialized
DEBUG - 2020-08-19 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:41:57 --> Input Class Initialized
INFO - 2020-08-19 08:41:57 --> Language Class Initialized
INFO - 2020-08-19 08:41:57 --> Language Class Initialized
INFO - 2020-08-19 08:41:57 --> Config Class Initialized
INFO - 2020-08-19 08:41:57 --> Loader Class Initialized
INFO - 2020-08-19 08:41:57 --> Helper loaded: url_helper
INFO - 2020-08-19 08:41:57 --> Helper loaded: form_helper
INFO - 2020-08-19 08:41:57 --> Helper loaded: file_helper
INFO - 2020-08-19 08:41:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 08:41:57 --> Database Driver Class Initialized
DEBUG - 2020-08-19 08:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 08:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:41:57 --> Upload Class Initialized
INFO - 2020-08-19 08:41:57 --> Controller Class Initialized
ERROR - 2020-08-19 08:41:57 --> 404 Page Not Found: /index
INFO - 2020-08-19 09:11:42 --> Config Class Initialized
INFO - 2020-08-19 09:11:42 --> Hooks Class Initialized
DEBUG - 2020-08-19 09:11:42 --> UTF-8 Support Enabled
INFO - 2020-08-19 09:11:42 --> Utf8 Class Initialized
INFO - 2020-08-19 09:11:42 --> URI Class Initialized
DEBUG - 2020-08-19 09:11:42 --> No URI present. Default controller set.
INFO - 2020-08-19 09:11:42 --> Router Class Initialized
INFO - 2020-08-19 09:11:42 --> Output Class Initialized
INFO - 2020-08-19 09:11:42 --> Security Class Initialized
DEBUG - 2020-08-19 09:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 09:11:42 --> Input Class Initialized
INFO - 2020-08-19 09:11:42 --> Language Class Initialized
INFO - 2020-08-19 09:11:42 --> Language Class Initialized
INFO - 2020-08-19 09:11:42 --> Config Class Initialized
INFO - 2020-08-19 09:11:42 --> Loader Class Initialized
INFO - 2020-08-19 09:11:42 --> Helper loaded: url_helper
INFO - 2020-08-19 09:11:42 --> Helper loaded: form_helper
INFO - 2020-08-19 09:11:42 --> Helper loaded: file_helper
INFO - 2020-08-19 09:11:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 09:11:42 --> Database Driver Class Initialized
DEBUG - 2020-08-19 09:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 09:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 09:11:42 --> Upload Class Initialized
INFO - 2020-08-19 09:11:42 --> Controller Class Initialized
DEBUG - 2020-08-19 09:11:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 09:11:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 09:11:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 09:11:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 09:11:42 --> Final output sent to browser
DEBUG - 2020-08-19 09:11:42 --> Total execution time: 0.0631
INFO - 2020-08-19 10:17:31 --> Config Class Initialized
INFO - 2020-08-19 10:17:31 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:17:31 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:17:31 --> Utf8 Class Initialized
INFO - 2020-08-19 10:17:31 --> URI Class Initialized
DEBUG - 2020-08-19 10:17:31 --> No URI present. Default controller set.
INFO - 2020-08-19 10:17:31 --> Router Class Initialized
INFO - 2020-08-19 10:17:31 --> Output Class Initialized
INFO - 2020-08-19 10:17:31 --> Security Class Initialized
DEBUG - 2020-08-19 10:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:17:31 --> Input Class Initialized
INFO - 2020-08-19 10:17:31 --> Language Class Initialized
INFO - 2020-08-19 10:17:31 --> Language Class Initialized
INFO - 2020-08-19 10:17:31 --> Config Class Initialized
INFO - 2020-08-19 10:17:31 --> Loader Class Initialized
INFO - 2020-08-19 10:17:31 --> Helper loaded: url_helper
INFO - 2020-08-19 10:17:31 --> Helper loaded: form_helper
INFO - 2020-08-19 10:17:31 --> Helper loaded: file_helper
INFO - 2020-08-19 10:17:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:17:31 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:17:31 --> Upload Class Initialized
INFO - 2020-08-19 10:17:31 --> Controller Class Initialized
DEBUG - 2020-08-19 10:17:31 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:17:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:17:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:17:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:17:31 --> Final output sent to browser
DEBUG - 2020-08-19 10:17:31 --> Total execution time: 0.0611
INFO - 2020-08-19 10:17:40 --> Config Class Initialized
INFO - 2020-08-19 10:17:40 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:17:40 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:17:40 --> Utf8 Class Initialized
INFO - 2020-08-19 10:17:40 --> URI Class Initialized
INFO - 2020-08-19 10:17:40 --> Router Class Initialized
INFO - 2020-08-19 10:17:40 --> Output Class Initialized
INFO - 2020-08-19 10:17:40 --> Security Class Initialized
DEBUG - 2020-08-19 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:17:40 --> Input Class Initialized
INFO - 2020-08-19 10:17:40 --> Language Class Initialized
INFO - 2020-08-19 10:17:40 --> Language Class Initialized
INFO - 2020-08-19 10:17:40 --> Config Class Initialized
INFO - 2020-08-19 10:17:40 --> Loader Class Initialized
INFO - 2020-08-19 10:17:40 --> Helper loaded: url_helper
INFO - 2020-08-19 10:17:40 --> Helper loaded: form_helper
INFO - 2020-08-19 10:17:40 --> Helper loaded: file_helper
INFO - 2020-08-19 10:17:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:17:40 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:17:40 --> Upload Class Initialized
INFO - 2020-08-19 10:17:40 --> Controller Class Initialized
ERROR - 2020-08-19 10:17:40 --> 404 Page Not Found: /index
INFO - 2020-08-19 10:17:57 --> Config Class Initialized
INFO - 2020-08-19 10:17:57 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:17:57 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:17:57 --> Utf8 Class Initialized
INFO - 2020-08-19 10:17:57 --> URI Class Initialized
DEBUG - 2020-08-19 10:17:57 --> No URI present. Default controller set.
INFO - 2020-08-19 10:17:57 --> Router Class Initialized
INFO - 2020-08-19 10:17:57 --> Output Class Initialized
INFO - 2020-08-19 10:17:57 --> Security Class Initialized
DEBUG - 2020-08-19 10:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:17:57 --> Input Class Initialized
INFO - 2020-08-19 10:17:57 --> Language Class Initialized
INFO - 2020-08-19 10:17:57 --> Language Class Initialized
INFO - 2020-08-19 10:17:57 --> Config Class Initialized
INFO - 2020-08-19 10:17:57 --> Loader Class Initialized
INFO - 2020-08-19 10:17:57 --> Helper loaded: url_helper
INFO - 2020-08-19 10:17:57 --> Helper loaded: form_helper
INFO - 2020-08-19 10:17:57 --> Helper loaded: file_helper
INFO - 2020-08-19 10:17:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:17:57 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:17:57 --> Upload Class Initialized
INFO - 2020-08-19 10:17:57 --> Controller Class Initialized
DEBUG - 2020-08-19 10:17:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:17:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:17:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:17:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:17:57 --> Final output sent to browser
DEBUG - 2020-08-19 10:17:57 --> Total execution time: 0.0504
INFO - 2020-08-19 10:18:13 --> Config Class Initialized
INFO - 2020-08-19 10:18:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:18:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:18:13 --> Utf8 Class Initialized
INFO - 2020-08-19 10:18:13 --> URI Class Initialized
DEBUG - 2020-08-19 10:18:13 --> No URI present. Default controller set.
INFO - 2020-08-19 10:18:13 --> Router Class Initialized
INFO - 2020-08-19 10:18:13 --> Output Class Initialized
INFO - 2020-08-19 10:18:13 --> Security Class Initialized
DEBUG - 2020-08-19 10:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:18:13 --> Input Class Initialized
INFO - 2020-08-19 10:18:13 --> Language Class Initialized
INFO - 2020-08-19 10:18:13 --> Language Class Initialized
INFO - 2020-08-19 10:18:13 --> Config Class Initialized
INFO - 2020-08-19 10:18:13 --> Loader Class Initialized
INFO - 2020-08-19 10:18:13 --> Helper loaded: url_helper
INFO - 2020-08-19 10:18:13 --> Helper loaded: form_helper
INFO - 2020-08-19 10:18:13 --> Helper loaded: file_helper
INFO - 2020-08-19 10:18:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:18:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:18:13 --> Upload Class Initialized
INFO - 2020-08-19 10:18:13 --> Controller Class Initialized
DEBUG - 2020-08-19 10:18:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:18:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:18:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:18:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:18:13 --> Final output sent to browser
DEBUG - 2020-08-19 10:18:13 --> Total execution time: 0.0517
INFO - 2020-08-19 10:18:14 --> Config Class Initialized
INFO - 2020-08-19 10:18:14 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:18:14 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:18:14 --> Utf8 Class Initialized
INFO - 2020-08-19 10:18:14 --> URI Class Initialized
INFO - 2020-08-19 10:18:14 --> Router Class Initialized
INFO - 2020-08-19 10:18:14 --> Output Class Initialized
INFO - 2020-08-19 10:18:14 --> Security Class Initialized
DEBUG - 2020-08-19 10:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:18:14 --> Input Class Initialized
INFO - 2020-08-19 10:18:14 --> Language Class Initialized
INFO - 2020-08-19 10:18:14 --> Language Class Initialized
INFO - 2020-08-19 10:18:14 --> Config Class Initialized
INFO - 2020-08-19 10:18:14 --> Loader Class Initialized
INFO - 2020-08-19 10:18:14 --> Helper loaded: url_helper
INFO - 2020-08-19 10:18:14 --> Helper loaded: form_helper
INFO - 2020-08-19 10:18:14 --> Helper loaded: file_helper
INFO - 2020-08-19 10:18:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:18:14 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:18:14 --> Upload Class Initialized
INFO - 2020-08-19 10:18:14 --> Controller Class Initialized
ERROR - 2020-08-19 10:18:14 --> 404 Page Not Found: /index
INFO - 2020-08-19 10:18:16 --> Config Class Initialized
INFO - 2020-08-19 10:18:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:18:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:18:16 --> Utf8 Class Initialized
INFO - 2020-08-19 10:18:16 --> URI Class Initialized
DEBUG - 2020-08-19 10:18:16 --> No URI present. Default controller set.
INFO - 2020-08-19 10:18:16 --> Router Class Initialized
INFO - 2020-08-19 10:18:16 --> Output Class Initialized
INFO - 2020-08-19 10:18:16 --> Security Class Initialized
DEBUG - 2020-08-19 10:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:18:16 --> Input Class Initialized
INFO - 2020-08-19 10:18:16 --> Language Class Initialized
INFO - 2020-08-19 10:18:16 --> Language Class Initialized
INFO - 2020-08-19 10:18:16 --> Config Class Initialized
INFO - 2020-08-19 10:18:16 --> Loader Class Initialized
INFO - 2020-08-19 10:18:16 --> Helper loaded: url_helper
INFO - 2020-08-19 10:18:16 --> Helper loaded: form_helper
INFO - 2020-08-19 10:18:16 --> Helper loaded: file_helper
INFO - 2020-08-19 10:18:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:18:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:18:16 --> Upload Class Initialized
INFO - 2020-08-19 10:18:16 --> Controller Class Initialized
DEBUG - 2020-08-19 10:18:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:18:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:18:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:18:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:18:16 --> Final output sent to browser
DEBUG - 2020-08-19 10:18:16 --> Total execution time: 0.0516
INFO - 2020-08-19 10:18:20 --> Config Class Initialized
INFO - 2020-08-19 10:18:20 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:18:20 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:18:20 --> Utf8 Class Initialized
INFO - 2020-08-19 10:18:20 --> URI Class Initialized
DEBUG - 2020-08-19 10:18:20 --> No URI present. Default controller set.
INFO - 2020-08-19 10:18:20 --> Router Class Initialized
INFO - 2020-08-19 10:18:20 --> Output Class Initialized
INFO - 2020-08-19 10:18:20 --> Security Class Initialized
DEBUG - 2020-08-19 10:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:18:20 --> Input Class Initialized
INFO - 2020-08-19 10:18:20 --> Language Class Initialized
INFO - 2020-08-19 10:18:20 --> Language Class Initialized
INFO - 2020-08-19 10:18:20 --> Config Class Initialized
INFO - 2020-08-19 10:18:20 --> Loader Class Initialized
INFO - 2020-08-19 10:18:20 --> Helper loaded: url_helper
INFO - 2020-08-19 10:18:20 --> Helper loaded: form_helper
INFO - 2020-08-19 10:18:20 --> Helper loaded: file_helper
INFO - 2020-08-19 10:18:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:18:20 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:18:20 --> Upload Class Initialized
INFO - 2020-08-19 10:18:21 --> Controller Class Initialized
DEBUG - 2020-08-19 10:18:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:18:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:18:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:18:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:18:21 --> Final output sent to browser
DEBUG - 2020-08-19 10:18:21 --> Total execution time: 0.0496
INFO - 2020-08-19 10:18:53 --> Config Class Initialized
INFO - 2020-08-19 10:18:53 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:18:53 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:18:53 --> Utf8 Class Initialized
INFO - 2020-08-19 10:18:53 --> URI Class Initialized
DEBUG - 2020-08-19 10:18:53 --> No URI present. Default controller set.
INFO - 2020-08-19 10:18:53 --> Router Class Initialized
INFO - 2020-08-19 10:18:53 --> Output Class Initialized
INFO - 2020-08-19 10:18:53 --> Security Class Initialized
DEBUG - 2020-08-19 10:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:18:53 --> Input Class Initialized
INFO - 2020-08-19 10:18:53 --> Language Class Initialized
INFO - 2020-08-19 10:18:53 --> Language Class Initialized
INFO - 2020-08-19 10:18:53 --> Config Class Initialized
INFO - 2020-08-19 10:18:53 --> Loader Class Initialized
INFO - 2020-08-19 10:18:53 --> Helper loaded: url_helper
INFO - 2020-08-19 10:18:53 --> Helper loaded: form_helper
INFO - 2020-08-19 10:18:53 --> Helper loaded: file_helper
INFO - 2020-08-19 10:18:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:18:53 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:18:53 --> Upload Class Initialized
INFO - 2020-08-19 10:18:53 --> Controller Class Initialized
DEBUG - 2020-08-19 10:18:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:18:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:18:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:18:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:18:53 --> Final output sent to browser
DEBUG - 2020-08-19 10:18:53 --> Total execution time: 0.0510
INFO - 2020-08-19 10:18:59 --> Config Class Initialized
INFO - 2020-08-19 10:18:59 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:18:59 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:18:59 --> Utf8 Class Initialized
INFO - 2020-08-19 10:18:59 --> URI Class Initialized
DEBUG - 2020-08-19 10:18:59 --> No URI present. Default controller set.
INFO - 2020-08-19 10:18:59 --> Router Class Initialized
INFO - 2020-08-19 10:18:59 --> Output Class Initialized
INFO - 2020-08-19 10:18:59 --> Security Class Initialized
DEBUG - 2020-08-19 10:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:18:59 --> Input Class Initialized
INFO - 2020-08-19 10:18:59 --> Language Class Initialized
INFO - 2020-08-19 10:18:59 --> Language Class Initialized
INFO - 2020-08-19 10:18:59 --> Config Class Initialized
INFO - 2020-08-19 10:18:59 --> Loader Class Initialized
INFO - 2020-08-19 10:18:59 --> Helper loaded: url_helper
INFO - 2020-08-19 10:18:59 --> Helper loaded: form_helper
INFO - 2020-08-19 10:18:59 --> Helper loaded: file_helper
INFO - 2020-08-19 10:18:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:18:59 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:18:59 --> Upload Class Initialized
INFO - 2020-08-19 10:18:59 --> Controller Class Initialized
DEBUG - 2020-08-19 10:18:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:18:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:18:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:18:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:18:59 --> Final output sent to browser
DEBUG - 2020-08-19 10:18:59 --> Total execution time: 0.0513
INFO - 2020-08-19 10:19:03 --> Config Class Initialized
INFO - 2020-08-19 10:19:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:19:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:19:03 --> Utf8 Class Initialized
INFO - 2020-08-19 10:19:03 --> URI Class Initialized
DEBUG - 2020-08-19 10:19:03 --> No URI present. Default controller set.
INFO - 2020-08-19 10:19:03 --> Router Class Initialized
INFO - 2020-08-19 10:19:03 --> Output Class Initialized
INFO - 2020-08-19 10:19:03 --> Security Class Initialized
DEBUG - 2020-08-19 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:19:03 --> Input Class Initialized
INFO - 2020-08-19 10:19:03 --> Language Class Initialized
INFO - 2020-08-19 10:19:03 --> Language Class Initialized
INFO - 2020-08-19 10:19:03 --> Config Class Initialized
INFO - 2020-08-19 10:19:03 --> Loader Class Initialized
INFO - 2020-08-19 10:19:03 --> Helper loaded: url_helper
INFO - 2020-08-19 10:19:03 --> Helper loaded: form_helper
INFO - 2020-08-19 10:19:03 --> Helper loaded: file_helper
INFO - 2020-08-19 10:19:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:19:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:19:03 --> Upload Class Initialized
INFO - 2020-08-19 10:19:03 --> Controller Class Initialized
DEBUG - 2020-08-19 10:19:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:19:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:19:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:19:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:19:03 --> Final output sent to browser
DEBUG - 2020-08-19 10:19:03 --> Total execution time: 0.1183
INFO - 2020-08-19 10:19:08 --> Config Class Initialized
INFO - 2020-08-19 10:19:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:19:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:19:08 --> Utf8 Class Initialized
INFO - 2020-08-19 10:19:08 --> URI Class Initialized
INFO - 2020-08-19 10:19:08 --> Router Class Initialized
INFO - 2020-08-19 10:19:08 --> Output Class Initialized
INFO - 2020-08-19 10:19:08 --> Security Class Initialized
DEBUG - 2020-08-19 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:19:08 --> Input Class Initialized
INFO - 2020-08-19 10:19:08 --> Language Class Initialized
INFO - 2020-08-19 10:19:08 --> Language Class Initialized
INFO - 2020-08-19 10:19:08 --> Config Class Initialized
INFO - 2020-08-19 10:19:08 --> Loader Class Initialized
INFO - 2020-08-19 10:19:08 --> Helper loaded: url_helper
INFO - 2020-08-19 10:19:08 --> Helper loaded: form_helper
INFO - 2020-08-19 10:19:08 --> Helper loaded: file_helper
INFO - 2020-08-19 10:19:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:19:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:19:08 --> Upload Class Initialized
INFO - 2020-08-19 10:19:08 --> Controller Class Initialized
DEBUG - 2020-08-19 10:19:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:19:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-19 10:19:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:19:09 --> Final output sent to browser
DEBUG - 2020-08-19 10:19:09 --> Total execution time: 0.0584
INFO - 2020-08-19 10:20:36 --> Config Class Initialized
INFO - 2020-08-19 10:20:36 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:20:36 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:20:36 --> Utf8 Class Initialized
INFO - 2020-08-19 10:20:36 --> URI Class Initialized
DEBUG - 2020-08-19 10:20:36 --> No URI present. Default controller set.
INFO - 2020-08-19 10:20:36 --> Router Class Initialized
INFO - 2020-08-19 10:20:36 --> Output Class Initialized
INFO - 2020-08-19 10:20:36 --> Security Class Initialized
DEBUG - 2020-08-19 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:20:36 --> Input Class Initialized
INFO - 2020-08-19 10:20:36 --> Language Class Initialized
INFO - 2020-08-19 10:20:36 --> Language Class Initialized
INFO - 2020-08-19 10:20:36 --> Config Class Initialized
INFO - 2020-08-19 10:20:36 --> Loader Class Initialized
INFO - 2020-08-19 10:20:36 --> Helper loaded: url_helper
INFO - 2020-08-19 10:20:36 --> Helper loaded: form_helper
INFO - 2020-08-19 10:20:36 --> Helper loaded: file_helper
INFO - 2020-08-19 10:20:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:20:36 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:20:36 --> Upload Class Initialized
INFO - 2020-08-19 10:20:36 --> Controller Class Initialized
DEBUG - 2020-08-19 10:20:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:20:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:20:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:20:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:20:36 --> Final output sent to browser
DEBUG - 2020-08-19 10:20:36 --> Total execution time: 0.0510
INFO - 2020-08-19 10:20:48 --> Config Class Initialized
INFO - 2020-08-19 10:20:48 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:20:48 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:20:48 --> Utf8 Class Initialized
INFO - 2020-08-19 10:20:48 --> URI Class Initialized
DEBUG - 2020-08-19 10:20:48 --> No URI present. Default controller set.
INFO - 2020-08-19 10:20:48 --> Router Class Initialized
INFO - 2020-08-19 10:20:48 --> Output Class Initialized
INFO - 2020-08-19 10:20:48 --> Security Class Initialized
DEBUG - 2020-08-19 10:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:20:48 --> Input Class Initialized
INFO - 2020-08-19 10:20:48 --> Language Class Initialized
INFO - 2020-08-19 10:20:48 --> Language Class Initialized
INFO - 2020-08-19 10:20:48 --> Config Class Initialized
INFO - 2020-08-19 10:20:48 --> Loader Class Initialized
INFO - 2020-08-19 10:20:48 --> Helper loaded: url_helper
INFO - 2020-08-19 10:20:48 --> Helper loaded: form_helper
INFO - 2020-08-19 10:20:48 --> Helper loaded: file_helper
INFO - 2020-08-19 10:20:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:20:48 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:20:48 --> Upload Class Initialized
INFO - 2020-08-19 10:20:48 --> Controller Class Initialized
DEBUG - 2020-08-19 10:20:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:20:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:20:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:20:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:20:48 --> Final output sent to browser
DEBUG - 2020-08-19 10:20:48 --> Total execution time: 0.0484
INFO - 2020-08-19 10:22:07 --> Config Class Initialized
INFO - 2020-08-19 10:22:07 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:22:07 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:22:07 --> Utf8 Class Initialized
INFO - 2020-08-19 10:22:07 --> URI Class Initialized
DEBUG - 2020-08-19 10:22:07 --> No URI present. Default controller set.
INFO - 2020-08-19 10:22:07 --> Router Class Initialized
INFO - 2020-08-19 10:22:07 --> Output Class Initialized
INFO - 2020-08-19 10:22:07 --> Security Class Initialized
DEBUG - 2020-08-19 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:22:07 --> Input Class Initialized
INFO - 2020-08-19 10:22:07 --> Language Class Initialized
INFO - 2020-08-19 10:22:07 --> Language Class Initialized
INFO - 2020-08-19 10:22:07 --> Config Class Initialized
INFO - 2020-08-19 10:22:07 --> Loader Class Initialized
INFO - 2020-08-19 10:22:07 --> Helper loaded: url_helper
INFO - 2020-08-19 10:22:07 --> Helper loaded: form_helper
INFO - 2020-08-19 10:22:07 --> Helper loaded: file_helper
INFO - 2020-08-19 10:22:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:22:07 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:22:07 --> Upload Class Initialized
INFO - 2020-08-19 10:22:07 --> Controller Class Initialized
DEBUG - 2020-08-19 10:22:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:22:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:22:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:22:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:22:07 --> Final output sent to browser
DEBUG - 2020-08-19 10:22:07 --> Total execution time: 0.0561
INFO - 2020-08-19 10:22:08 --> Config Class Initialized
INFO - 2020-08-19 10:22:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:22:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:22:08 --> Utf8 Class Initialized
INFO - 2020-08-19 10:22:08 --> URI Class Initialized
INFO - 2020-08-19 10:22:08 --> Router Class Initialized
INFO - 2020-08-19 10:22:08 --> Output Class Initialized
INFO - 2020-08-19 10:22:08 --> Security Class Initialized
DEBUG - 2020-08-19 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:22:08 --> Input Class Initialized
INFO - 2020-08-19 10:22:08 --> Language Class Initialized
INFO - 2020-08-19 10:22:08 --> Language Class Initialized
INFO - 2020-08-19 10:22:08 --> Config Class Initialized
INFO - 2020-08-19 10:22:08 --> Loader Class Initialized
INFO - 2020-08-19 10:22:08 --> Helper loaded: url_helper
INFO - 2020-08-19 10:22:08 --> Helper loaded: form_helper
INFO - 2020-08-19 10:22:08 --> Helper loaded: file_helper
INFO - 2020-08-19 10:22:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:22:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:22:08 --> Upload Class Initialized
INFO - 2020-08-19 10:22:08 --> Controller Class Initialized
ERROR - 2020-08-19 10:22:08 --> 404 Page Not Found: /index
INFO - 2020-08-19 10:46:05 --> Config Class Initialized
INFO - 2020-08-19 10:46:05 --> Hooks Class Initialized
DEBUG - 2020-08-19 10:46:05 --> UTF-8 Support Enabled
INFO - 2020-08-19 10:46:05 --> Utf8 Class Initialized
INFO - 2020-08-19 10:46:05 --> URI Class Initialized
DEBUG - 2020-08-19 10:46:05 --> No URI present. Default controller set.
INFO - 2020-08-19 10:46:05 --> Router Class Initialized
INFO - 2020-08-19 10:46:05 --> Output Class Initialized
INFO - 2020-08-19 10:46:05 --> Security Class Initialized
DEBUG - 2020-08-19 10:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 10:46:05 --> Input Class Initialized
INFO - 2020-08-19 10:46:05 --> Language Class Initialized
INFO - 2020-08-19 10:46:05 --> Language Class Initialized
INFO - 2020-08-19 10:46:05 --> Config Class Initialized
INFO - 2020-08-19 10:46:06 --> Loader Class Initialized
INFO - 2020-08-19 10:46:06 --> Helper loaded: url_helper
INFO - 2020-08-19 10:46:06 --> Helper loaded: form_helper
INFO - 2020-08-19 10:46:06 --> Helper loaded: file_helper
INFO - 2020-08-19 10:46:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 10:46:06 --> Database Driver Class Initialized
DEBUG - 2020-08-19 10:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 10:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 10:46:06 --> Upload Class Initialized
INFO - 2020-08-19 10:46:06 --> Controller Class Initialized
DEBUG - 2020-08-19 10:46:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 10:46:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 10:46:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 10:46:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 10:46:06 --> Final output sent to browser
DEBUG - 2020-08-19 10:46:06 --> Total execution time: 0.0566
INFO - 2020-08-19 11:13:05 --> Config Class Initialized
INFO - 2020-08-19 11:13:05 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:13:05 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:13:05 --> Utf8 Class Initialized
INFO - 2020-08-19 11:13:05 --> URI Class Initialized
DEBUG - 2020-08-19 11:13:05 --> No URI present. Default controller set.
INFO - 2020-08-19 11:13:05 --> Router Class Initialized
INFO - 2020-08-19 11:13:05 --> Output Class Initialized
INFO - 2020-08-19 11:13:05 --> Security Class Initialized
DEBUG - 2020-08-19 11:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:13:05 --> Input Class Initialized
INFO - 2020-08-19 11:13:05 --> Language Class Initialized
INFO - 2020-08-19 11:13:05 --> Language Class Initialized
INFO - 2020-08-19 11:13:05 --> Config Class Initialized
INFO - 2020-08-19 11:13:05 --> Loader Class Initialized
INFO - 2020-08-19 11:13:05 --> Helper loaded: url_helper
INFO - 2020-08-19 11:13:05 --> Helper loaded: form_helper
INFO - 2020-08-19 11:13:05 --> Helper loaded: file_helper
INFO - 2020-08-19 11:13:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:13:05 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:13:05 --> Upload Class Initialized
INFO - 2020-08-19 11:13:05 --> Controller Class Initialized
DEBUG - 2020-08-19 11:13:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:13:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:13:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:13:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:13:05 --> Final output sent to browser
DEBUG - 2020-08-19 11:13:05 --> Total execution time: 0.0540
INFO - 2020-08-19 11:13:06 --> Config Class Initialized
INFO - 2020-08-19 11:13:06 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:13:06 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:13:06 --> Utf8 Class Initialized
INFO - 2020-08-19 11:13:06 --> URI Class Initialized
DEBUG - 2020-08-19 11:13:06 --> No URI present. Default controller set.
INFO - 2020-08-19 11:13:06 --> Router Class Initialized
INFO - 2020-08-19 11:13:06 --> Output Class Initialized
INFO - 2020-08-19 11:13:06 --> Security Class Initialized
DEBUG - 2020-08-19 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:13:06 --> Input Class Initialized
INFO - 2020-08-19 11:13:06 --> Language Class Initialized
INFO - 2020-08-19 11:13:06 --> Language Class Initialized
INFO - 2020-08-19 11:13:06 --> Config Class Initialized
INFO - 2020-08-19 11:13:06 --> Loader Class Initialized
INFO - 2020-08-19 11:13:06 --> Helper loaded: url_helper
INFO - 2020-08-19 11:13:06 --> Helper loaded: form_helper
INFO - 2020-08-19 11:13:06 --> Helper loaded: file_helper
INFO - 2020-08-19 11:13:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:13:06 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:13:06 --> Upload Class Initialized
INFO - 2020-08-19 11:13:06 --> Controller Class Initialized
DEBUG - 2020-08-19 11:13:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:13:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:13:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:13:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:13:06 --> Final output sent to browser
DEBUG - 2020-08-19 11:13:06 --> Total execution time: 0.0514
INFO - 2020-08-19 11:13:19 --> Config Class Initialized
INFO - 2020-08-19 11:13:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:13:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:13:19 --> Utf8 Class Initialized
INFO - 2020-08-19 11:13:19 --> URI Class Initialized
DEBUG - 2020-08-19 11:13:19 --> No URI present. Default controller set.
INFO - 2020-08-19 11:13:19 --> Router Class Initialized
INFO - 2020-08-19 11:13:19 --> Output Class Initialized
INFO - 2020-08-19 11:13:19 --> Security Class Initialized
DEBUG - 2020-08-19 11:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:13:19 --> Input Class Initialized
INFO - 2020-08-19 11:13:19 --> Language Class Initialized
INFO - 2020-08-19 11:13:19 --> Language Class Initialized
INFO - 2020-08-19 11:13:19 --> Config Class Initialized
INFO - 2020-08-19 11:13:19 --> Loader Class Initialized
INFO - 2020-08-19 11:13:19 --> Helper loaded: url_helper
INFO - 2020-08-19 11:13:19 --> Helper loaded: form_helper
INFO - 2020-08-19 11:13:19 --> Helper loaded: file_helper
INFO - 2020-08-19 11:13:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:13:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:13:19 --> Upload Class Initialized
INFO - 2020-08-19 11:13:19 --> Controller Class Initialized
DEBUG - 2020-08-19 11:13:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:13:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:13:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:13:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:13:19 --> Final output sent to browser
DEBUG - 2020-08-19 11:13:19 --> Total execution time: 0.0514
INFO - 2020-08-19 11:13:26 --> Config Class Initialized
INFO - 2020-08-19 11:13:26 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:13:26 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:13:26 --> Utf8 Class Initialized
INFO - 2020-08-19 11:13:26 --> URI Class Initialized
DEBUG - 2020-08-19 11:13:26 --> No URI present. Default controller set.
INFO - 2020-08-19 11:13:26 --> Router Class Initialized
INFO - 2020-08-19 11:13:26 --> Output Class Initialized
INFO - 2020-08-19 11:13:26 --> Security Class Initialized
DEBUG - 2020-08-19 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:13:26 --> Input Class Initialized
INFO - 2020-08-19 11:13:26 --> Language Class Initialized
INFO - 2020-08-19 11:13:26 --> Language Class Initialized
INFO - 2020-08-19 11:13:26 --> Config Class Initialized
INFO - 2020-08-19 11:13:26 --> Loader Class Initialized
INFO - 2020-08-19 11:13:26 --> Helper loaded: url_helper
INFO - 2020-08-19 11:13:26 --> Helper loaded: form_helper
INFO - 2020-08-19 11:13:26 --> Helper loaded: file_helper
INFO - 2020-08-19 11:13:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:13:26 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:13:26 --> Upload Class Initialized
INFO - 2020-08-19 11:13:26 --> Controller Class Initialized
DEBUG - 2020-08-19 11:13:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:13:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:13:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:13:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:13:26 --> Final output sent to browser
DEBUG - 2020-08-19 11:13:26 --> Total execution time: 0.0507
INFO - 2020-08-19 11:13:43 --> Config Class Initialized
INFO - 2020-08-19 11:13:43 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:13:43 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:13:43 --> Utf8 Class Initialized
INFO - 2020-08-19 11:13:43 --> URI Class Initialized
DEBUG - 2020-08-19 11:13:43 --> No URI present. Default controller set.
INFO - 2020-08-19 11:13:43 --> Router Class Initialized
INFO - 2020-08-19 11:13:43 --> Output Class Initialized
INFO - 2020-08-19 11:13:43 --> Security Class Initialized
DEBUG - 2020-08-19 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:13:43 --> Input Class Initialized
INFO - 2020-08-19 11:13:43 --> Language Class Initialized
INFO - 2020-08-19 11:13:43 --> Language Class Initialized
INFO - 2020-08-19 11:13:43 --> Config Class Initialized
INFO - 2020-08-19 11:13:43 --> Loader Class Initialized
INFO - 2020-08-19 11:13:43 --> Helper loaded: url_helper
INFO - 2020-08-19 11:13:43 --> Helper loaded: form_helper
INFO - 2020-08-19 11:13:43 --> Helper loaded: file_helper
INFO - 2020-08-19 11:13:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:13:43 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:13:43 --> Upload Class Initialized
INFO - 2020-08-19 11:13:43 --> Controller Class Initialized
DEBUG - 2020-08-19 11:13:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:13:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:13:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:13:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:13:43 --> Final output sent to browser
DEBUG - 2020-08-19 11:13:43 --> Total execution time: 0.0502
INFO - 2020-08-19 11:13:49 --> Config Class Initialized
INFO - 2020-08-19 11:13:49 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:13:49 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:13:49 --> Utf8 Class Initialized
INFO - 2020-08-19 11:13:49 --> URI Class Initialized
INFO - 2020-08-19 11:13:49 --> Router Class Initialized
INFO - 2020-08-19 11:13:49 --> Output Class Initialized
INFO - 2020-08-19 11:13:49 --> Security Class Initialized
DEBUG - 2020-08-19 11:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:13:49 --> Input Class Initialized
INFO - 2020-08-19 11:13:49 --> Language Class Initialized
INFO - 2020-08-19 11:13:49 --> Language Class Initialized
INFO - 2020-08-19 11:13:49 --> Config Class Initialized
INFO - 2020-08-19 11:13:49 --> Loader Class Initialized
INFO - 2020-08-19 11:13:49 --> Helper loaded: url_helper
INFO - 2020-08-19 11:13:49 --> Helper loaded: form_helper
INFO - 2020-08-19 11:13:49 --> Helper loaded: file_helper
INFO - 2020-08-19 11:13:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:13:49 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:13:49 --> Upload Class Initialized
INFO - 2020-08-19 11:13:49 --> Controller Class Initialized
ERROR - 2020-08-19 11:13:49 --> 404 Page Not Found: /index
INFO - 2020-08-19 11:14:07 --> Config Class Initialized
INFO - 2020-08-19 11:14:07 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:14:07 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:14:07 --> Utf8 Class Initialized
INFO - 2020-08-19 11:14:07 --> URI Class Initialized
DEBUG - 2020-08-19 11:14:07 --> No URI present. Default controller set.
INFO - 2020-08-19 11:14:07 --> Router Class Initialized
INFO - 2020-08-19 11:14:07 --> Output Class Initialized
INFO - 2020-08-19 11:14:07 --> Security Class Initialized
DEBUG - 2020-08-19 11:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:14:07 --> Input Class Initialized
INFO - 2020-08-19 11:14:07 --> Language Class Initialized
INFO - 2020-08-19 11:14:07 --> Language Class Initialized
INFO - 2020-08-19 11:14:07 --> Config Class Initialized
INFO - 2020-08-19 11:14:07 --> Loader Class Initialized
INFO - 2020-08-19 11:14:07 --> Helper loaded: url_helper
INFO - 2020-08-19 11:14:07 --> Helper loaded: form_helper
INFO - 2020-08-19 11:14:07 --> Helper loaded: file_helper
INFO - 2020-08-19 11:14:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:14:07 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:14:07 --> Upload Class Initialized
INFO - 2020-08-19 11:14:07 --> Controller Class Initialized
DEBUG - 2020-08-19 11:14:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:14:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:14:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:14:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:14:07 --> Final output sent to browser
DEBUG - 2020-08-19 11:14:07 --> Total execution time: 0.0495
INFO - 2020-08-19 11:14:08 --> Config Class Initialized
INFO - 2020-08-19 11:14:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:14:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:14:08 --> Utf8 Class Initialized
INFO - 2020-08-19 11:14:08 --> URI Class Initialized
DEBUG - 2020-08-19 11:14:08 --> No URI present. Default controller set.
INFO - 2020-08-19 11:14:08 --> Router Class Initialized
INFO - 2020-08-19 11:14:08 --> Output Class Initialized
INFO - 2020-08-19 11:14:08 --> Security Class Initialized
DEBUG - 2020-08-19 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:14:08 --> Input Class Initialized
INFO - 2020-08-19 11:14:08 --> Language Class Initialized
INFO - 2020-08-19 11:14:08 --> Language Class Initialized
INFO - 2020-08-19 11:14:08 --> Config Class Initialized
INFO - 2020-08-19 11:14:08 --> Loader Class Initialized
INFO - 2020-08-19 11:14:08 --> Helper loaded: url_helper
INFO - 2020-08-19 11:14:08 --> Helper loaded: form_helper
INFO - 2020-08-19 11:14:08 --> Helper loaded: file_helper
INFO - 2020-08-19 11:14:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:14:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:14:08 --> Upload Class Initialized
INFO - 2020-08-19 11:14:08 --> Controller Class Initialized
DEBUG - 2020-08-19 11:14:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:14:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:14:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:14:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:14:08 --> Final output sent to browser
DEBUG - 2020-08-19 11:14:08 --> Total execution time: 0.0486
INFO - 2020-08-19 11:14:09 --> Config Class Initialized
INFO - 2020-08-19 11:14:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:14:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:14:09 --> Utf8 Class Initialized
INFO - 2020-08-19 11:14:09 --> URI Class Initialized
INFO - 2020-08-19 11:14:09 --> Router Class Initialized
INFO - 2020-08-19 11:14:09 --> Output Class Initialized
INFO - 2020-08-19 11:14:09 --> Security Class Initialized
DEBUG - 2020-08-19 11:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:14:09 --> Input Class Initialized
INFO - 2020-08-19 11:14:09 --> Language Class Initialized
INFO - 2020-08-19 11:14:09 --> Language Class Initialized
INFO - 2020-08-19 11:14:09 --> Config Class Initialized
INFO - 2020-08-19 11:14:09 --> Loader Class Initialized
INFO - 2020-08-19 11:14:09 --> Helper loaded: url_helper
INFO - 2020-08-19 11:14:09 --> Helper loaded: form_helper
INFO - 2020-08-19 11:14:09 --> Helper loaded: file_helper
INFO - 2020-08-19 11:14:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:14:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:14:09 --> Upload Class Initialized
INFO - 2020-08-19 11:14:09 --> Controller Class Initialized
ERROR - 2020-08-19 11:14:09 --> 404 Page Not Found: /index
INFO - 2020-08-19 11:17:44 --> Config Class Initialized
INFO - 2020-08-19 11:17:44 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:17:44 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:17:44 --> Utf8 Class Initialized
INFO - 2020-08-19 11:17:44 --> URI Class Initialized
DEBUG - 2020-08-19 11:17:44 --> No URI present. Default controller set.
INFO - 2020-08-19 11:17:44 --> Router Class Initialized
INFO - 2020-08-19 11:17:44 --> Output Class Initialized
INFO - 2020-08-19 11:17:44 --> Security Class Initialized
DEBUG - 2020-08-19 11:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:17:44 --> Input Class Initialized
INFO - 2020-08-19 11:17:44 --> Language Class Initialized
INFO - 2020-08-19 11:17:44 --> Language Class Initialized
INFO - 2020-08-19 11:17:44 --> Config Class Initialized
INFO - 2020-08-19 11:17:44 --> Loader Class Initialized
INFO - 2020-08-19 11:17:44 --> Helper loaded: url_helper
INFO - 2020-08-19 11:17:44 --> Helper loaded: form_helper
INFO - 2020-08-19 11:17:44 --> Helper loaded: file_helper
INFO - 2020-08-19 11:17:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:17:44 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:17:44 --> Upload Class Initialized
INFO - 2020-08-19 11:17:44 --> Controller Class Initialized
DEBUG - 2020-08-19 11:17:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:17:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:17:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:17:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:17:44 --> Final output sent to browser
DEBUG - 2020-08-19 11:17:44 --> Total execution time: 0.0485
INFO - 2020-08-19 11:18:17 --> Config Class Initialized
INFO - 2020-08-19 11:18:17 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:18:17 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:18:17 --> Utf8 Class Initialized
INFO - 2020-08-19 11:18:17 --> URI Class Initialized
DEBUG - 2020-08-19 11:18:17 --> No URI present. Default controller set.
INFO - 2020-08-19 11:18:17 --> Router Class Initialized
INFO - 2020-08-19 11:18:17 --> Output Class Initialized
INFO - 2020-08-19 11:18:17 --> Security Class Initialized
DEBUG - 2020-08-19 11:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:18:17 --> Input Class Initialized
INFO - 2020-08-19 11:18:17 --> Language Class Initialized
INFO - 2020-08-19 11:18:17 --> Language Class Initialized
INFO - 2020-08-19 11:18:17 --> Config Class Initialized
INFO - 2020-08-19 11:18:17 --> Loader Class Initialized
INFO - 2020-08-19 11:18:17 --> Helper loaded: url_helper
INFO - 2020-08-19 11:18:17 --> Helper loaded: form_helper
INFO - 2020-08-19 11:18:17 --> Helper loaded: file_helper
INFO - 2020-08-19 11:18:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:18:17 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:18:17 --> Upload Class Initialized
INFO - 2020-08-19 11:18:17 --> Controller Class Initialized
DEBUG - 2020-08-19 11:18:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:18:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:18:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:18:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:18:17 --> Final output sent to browser
DEBUG - 2020-08-19 11:18:17 --> Total execution time: 0.0496
INFO - 2020-08-19 11:28:23 --> Config Class Initialized
INFO - 2020-08-19 11:28:23 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:28:23 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:28:23 --> Utf8 Class Initialized
INFO - 2020-08-19 11:28:23 --> URI Class Initialized
INFO - 2020-08-19 11:28:23 --> Router Class Initialized
INFO - 2020-08-19 11:28:23 --> Output Class Initialized
INFO - 2020-08-19 11:28:23 --> Security Class Initialized
DEBUG - 2020-08-19 11:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:28:23 --> Input Class Initialized
INFO - 2020-08-19 11:28:23 --> Language Class Initialized
INFO - 2020-08-19 11:28:23 --> Language Class Initialized
INFO - 2020-08-19 11:28:23 --> Config Class Initialized
INFO - 2020-08-19 11:28:23 --> Loader Class Initialized
INFO - 2020-08-19 11:28:23 --> Helper loaded: url_helper
INFO - 2020-08-19 11:28:23 --> Helper loaded: form_helper
INFO - 2020-08-19 11:28:23 --> Helper loaded: file_helper
INFO - 2020-08-19 11:28:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:28:23 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:28:23 --> Upload Class Initialized
INFO - 2020-08-19 11:28:23 --> Controller Class Initialized
ERROR - 2020-08-19 11:28:23 --> 404 Page Not Found: /index
INFO - 2020-08-19 11:28:26 --> Config Class Initialized
INFO - 2020-08-19 11:28:26 --> Hooks Class Initialized
DEBUG - 2020-08-19 11:28:26 --> UTF-8 Support Enabled
INFO - 2020-08-19 11:28:26 --> Utf8 Class Initialized
INFO - 2020-08-19 11:28:26 --> URI Class Initialized
DEBUG - 2020-08-19 11:28:26 --> No URI present. Default controller set.
INFO - 2020-08-19 11:28:26 --> Router Class Initialized
INFO - 2020-08-19 11:28:26 --> Output Class Initialized
INFO - 2020-08-19 11:28:26 --> Security Class Initialized
DEBUG - 2020-08-19 11:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 11:28:26 --> Input Class Initialized
INFO - 2020-08-19 11:28:26 --> Language Class Initialized
INFO - 2020-08-19 11:28:26 --> Language Class Initialized
INFO - 2020-08-19 11:28:26 --> Config Class Initialized
INFO - 2020-08-19 11:28:26 --> Loader Class Initialized
INFO - 2020-08-19 11:28:26 --> Helper loaded: url_helper
INFO - 2020-08-19 11:28:26 --> Helper loaded: form_helper
INFO - 2020-08-19 11:28:26 --> Helper loaded: file_helper
INFO - 2020-08-19 11:28:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 11:28:26 --> Database Driver Class Initialized
DEBUG - 2020-08-19 11:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 11:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 11:28:26 --> Upload Class Initialized
INFO - 2020-08-19 11:28:26 --> Controller Class Initialized
DEBUG - 2020-08-19 11:28:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 11:28:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 11:28:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 11:28:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 11:28:26 --> Final output sent to browser
DEBUG - 2020-08-19 11:28:26 --> Total execution time: 0.0495
INFO - 2020-08-19 12:40:50 --> Config Class Initialized
INFO - 2020-08-19 12:40:50 --> Hooks Class Initialized
DEBUG - 2020-08-19 12:40:50 --> UTF-8 Support Enabled
INFO - 2020-08-19 12:40:50 --> Utf8 Class Initialized
INFO - 2020-08-19 12:40:50 --> URI Class Initialized
DEBUG - 2020-08-19 12:40:50 --> No URI present. Default controller set.
INFO - 2020-08-19 12:40:50 --> Router Class Initialized
INFO - 2020-08-19 12:40:50 --> Output Class Initialized
INFO - 2020-08-19 12:40:50 --> Security Class Initialized
DEBUG - 2020-08-19 12:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 12:40:50 --> Input Class Initialized
INFO - 2020-08-19 12:40:50 --> Language Class Initialized
INFO - 2020-08-19 12:40:50 --> Language Class Initialized
INFO - 2020-08-19 12:40:50 --> Config Class Initialized
INFO - 2020-08-19 12:40:50 --> Loader Class Initialized
INFO - 2020-08-19 12:40:50 --> Helper loaded: url_helper
INFO - 2020-08-19 12:40:50 --> Helper loaded: form_helper
INFO - 2020-08-19 12:40:50 --> Helper loaded: file_helper
INFO - 2020-08-19 12:40:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 12:40:50 --> Database Driver Class Initialized
DEBUG - 2020-08-19 12:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 12:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 12:40:50 --> Upload Class Initialized
INFO - 2020-08-19 12:40:50 --> Controller Class Initialized
DEBUG - 2020-08-19 12:40:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 12:40:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 12:40:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 12:40:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 12:40:50 --> Final output sent to browser
DEBUG - 2020-08-19 12:40:50 --> Total execution time: 0.0513
INFO - 2020-08-19 12:41:15 --> Config Class Initialized
INFO - 2020-08-19 12:41:15 --> Hooks Class Initialized
DEBUG - 2020-08-19 12:41:15 --> UTF-8 Support Enabled
INFO - 2020-08-19 12:41:15 --> Utf8 Class Initialized
INFO - 2020-08-19 12:41:15 --> URI Class Initialized
INFO - 2020-08-19 12:41:15 --> Router Class Initialized
INFO - 2020-08-19 12:41:15 --> Output Class Initialized
INFO - 2020-08-19 12:41:15 --> Security Class Initialized
DEBUG - 2020-08-19 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 12:41:15 --> Input Class Initialized
INFO - 2020-08-19 12:41:15 --> Language Class Initialized
INFO - 2020-08-19 12:41:15 --> Language Class Initialized
INFO - 2020-08-19 12:41:15 --> Config Class Initialized
INFO - 2020-08-19 12:41:15 --> Loader Class Initialized
INFO - 2020-08-19 12:41:15 --> Helper loaded: url_helper
INFO - 2020-08-19 12:41:15 --> Helper loaded: form_helper
INFO - 2020-08-19 12:41:15 --> Helper loaded: file_helper
INFO - 2020-08-19 12:41:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 12:41:15 --> Database Driver Class Initialized
DEBUG - 2020-08-19 12:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 12:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 12:41:15 --> Upload Class Initialized
INFO - 2020-08-19 12:41:15 --> Controller Class Initialized
ERROR - 2020-08-19 12:41:15 --> 404 Page Not Found: /index
INFO - 2020-08-19 12:41:15 --> Config Class Initialized
INFO - 2020-08-19 12:41:15 --> Hooks Class Initialized
DEBUG - 2020-08-19 12:41:15 --> UTF-8 Support Enabled
INFO - 2020-08-19 12:41:15 --> Utf8 Class Initialized
INFO - 2020-08-19 12:41:15 --> URI Class Initialized
DEBUG - 2020-08-19 12:41:15 --> No URI present. Default controller set.
INFO - 2020-08-19 12:41:15 --> Router Class Initialized
INFO - 2020-08-19 12:41:15 --> Output Class Initialized
INFO - 2020-08-19 12:41:15 --> Security Class Initialized
DEBUG - 2020-08-19 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 12:41:15 --> Input Class Initialized
INFO - 2020-08-19 12:41:15 --> Language Class Initialized
INFO - 2020-08-19 12:41:15 --> Language Class Initialized
INFO - 2020-08-19 12:41:15 --> Config Class Initialized
INFO - 2020-08-19 12:41:15 --> Loader Class Initialized
INFO - 2020-08-19 12:41:15 --> Helper loaded: url_helper
INFO - 2020-08-19 12:41:15 --> Helper loaded: form_helper
INFO - 2020-08-19 12:41:15 --> Helper loaded: file_helper
INFO - 2020-08-19 12:41:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 12:41:15 --> Database Driver Class Initialized
DEBUG - 2020-08-19 12:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 12:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 12:41:15 --> Upload Class Initialized
INFO - 2020-08-19 12:41:15 --> Controller Class Initialized
DEBUG - 2020-08-19 12:41:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 12:41:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 12:41:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 12:41:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 12:41:15 --> Final output sent to browser
DEBUG - 2020-08-19 12:41:15 --> Total execution time: 0.0531
INFO - 2020-08-19 14:53:29 --> Config Class Initialized
INFO - 2020-08-19 14:53:29 --> Hooks Class Initialized
DEBUG - 2020-08-19 14:53:29 --> UTF-8 Support Enabled
INFO - 2020-08-19 14:53:29 --> Utf8 Class Initialized
INFO - 2020-08-19 14:53:29 --> URI Class Initialized
DEBUG - 2020-08-19 14:53:29 --> No URI present. Default controller set.
INFO - 2020-08-19 14:53:29 --> Router Class Initialized
INFO - 2020-08-19 14:53:29 --> Output Class Initialized
INFO - 2020-08-19 14:53:29 --> Security Class Initialized
DEBUG - 2020-08-19 14:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 14:53:29 --> Input Class Initialized
INFO - 2020-08-19 14:53:29 --> Language Class Initialized
INFO - 2020-08-19 14:53:29 --> Language Class Initialized
INFO - 2020-08-19 14:53:29 --> Config Class Initialized
INFO - 2020-08-19 14:53:29 --> Loader Class Initialized
INFO - 2020-08-19 14:53:29 --> Helper loaded: url_helper
INFO - 2020-08-19 14:53:29 --> Helper loaded: form_helper
INFO - 2020-08-19 14:53:29 --> Helper loaded: file_helper
INFO - 2020-08-19 14:53:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 14:53:29 --> Database Driver Class Initialized
DEBUG - 2020-08-19 14:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 14:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 14:53:29 --> Upload Class Initialized
INFO - 2020-08-19 14:53:29 --> Controller Class Initialized
DEBUG - 2020-08-19 14:53:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 14:53:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 14:53:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 14:53:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 14:53:29 --> Final output sent to browser
DEBUG - 2020-08-19 14:53:29 --> Total execution time: 0.0805
INFO - 2020-08-19 14:53:35 --> Config Class Initialized
INFO - 2020-08-19 14:53:35 --> Hooks Class Initialized
DEBUG - 2020-08-19 14:53:35 --> UTF-8 Support Enabled
INFO - 2020-08-19 14:53:35 --> Utf8 Class Initialized
INFO - 2020-08-19 14:53:35 --> URI Class Initialized
INFO - 2020-08-19 14:53:35 --> Router Class Initialized
INFO - 2020-08-19 14:53:35 --> Output Class Initialized
INFO - 2020-08-19 14:53:35 --> Security Class Initialized
DEBUG - 2020-08-19 14:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 14:53:35 --> Input Class Initialized
INFO - 2020-08-19 14:53:35 --> Language Class Initialized
INFO - 2020-08-19 14:53:35 --> Language Class Initialized
INFO - 2020-08-19 14:53:35 --> Config Class Initialized
INFO - 2020-08-19 14:53:35 --> Loader Class Initialized
INFO - 2020-08-19 14:53:35 --> Helper loaded: url_helper
INFO - 2020-08-19 14:53:35 --> Helper loaded: form_helper
INFO - 2020-08-19 14:53:35 --> Helper loaded: file_helper
INFO - 2020-08-19 14:53:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 14:53:35 --> Database Driver Class Initialized
DEBUG - 2020-08-19 14:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 14:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 14:53:35 --> Upload Class Initialized
INFO - 2020-08-19 14:53:36 --> Controller Class Initialized
ERROR - 2020-08-19 14:53:36 --> 404 Page Not Found: /index
INFO - 2020-08-19 16:33:50 --> Config Class Initialized
INFO - 2020-08-19 16:33:50 --> Hooks Class Initialized
DEBUG - 2020-08-19 16:33:50 --> UTF-8 Support Enabled
INFO - 2020-08-19 16:33:50 --> Utf8 Class Initialized
INFO - 2020-08-19 16:33:50 --> URI Class Initialized
INFO - 2020-08-19 16:33:50 --> Router Class Initialized
INFO - 2020-08-19 16:33:50 --> Output Class Initialized
INFO - 2020-08-19 16:33:50 --> Security Class Initialized
DEBUG - 2020-08-19 16:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 16:33:50 --> Input Class Initialized
INFO - 2020-08-19 16:33:50 --> Language Class Initialized
INFO - 2020-08-19 16:33:50 --> Language Class Initialized
INFO - 2020-08-19 16:33:50 --> Config Class Initialized
INFO - 2020-08-19 16:33:50 --> Loader Class Initialized
INFO - 2020-08-19 16:33:50 --> Helper loaded: url_helper
INFO - 2020-08-19 16:33:50 --> Helper loaded: form_helper
INFO - 2020-08-19 16:33:50 --> Helper loaded: file_helper
INFO - 2020-08-19 16:33:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 16:33:50 --> Database Driver Class Initialized
DEBUG - 2020-08-19 16:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 16:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 16:33:50 --> Upload Class Initialized
INFO - 2020-08-19 16:33:50 --> Controller Class Initialized
ERROR - 2020-08-19 16:33:50 --> 404 Page Not Found: /index
INFO - 2020-08-19 16:33:54 --> Config Class Initialized
INFO - 2020-08-19 16:33:54 --> Hooks Class Initialized
DEBUG - 2020-08-19 16:33:54 --> UTF-8 Support Enabled
INFO - 2020-08-19 16:33:54 --> Utf8 Class Initialized
INFO - 2020-08-19 16:33:54 --> URI Class Initialized
INFO - 2020-08-19 16:33:54 --> Router Class Initialized
INFO - 2020-08-19 16:33:54 --> Output Class Initialized
INFO - 2020-08-19 16:33:54 --> Security Class Initialized
DEBUG - 2020-08-19 16:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 16:33:54 --> Input Class Initialized
INFO - 2020-08-19 16:33:54 --> Language Class Initialized
INFO - 2020-08-19 16:33:54 --> Language Class Initialized
INFO - 2020-08-19 16:33:54 --> Config Class Initialized
INFO - 2020-08-19 16:33:54 --> Loader Class Initialized
INFO - 2020-08-19 16:33:54 --> Helper loaded: url_helper
INFO - 2020-08-19 16:33:54 --> Helper loaded: form_helper
INFO - 2020-08-19 16:33:54 --> Helper loaded: file_helper
INFO - 2020-08-19 16:33:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 16:33:54 --> Database Driver Class Initialized
DEBUG - 2020-08-19 16:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 16:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 16:33:54 --> Upload Class Initialized
INFO - 2020-08-19 16:33:54 --> Controller Class Initialized
DEBUG - 2020-08-19 16:33:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 16:33:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-19 16:33:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 16:33:54 --> Final output sent to browser
DEBUG - 2020-08-19 16:33:54 --> Total execution time: 0.0757
INFO - 2020-08-19 16:57:48 --> Config Class Initialized
INFO - 2020-08-19 16:57:48 --> Hooks Class Initialized
DEBUG - 2020-08-19 16:57:48 --> UTF-8 Support Enabled
INFO - 2020-08-19 16:57:48 --> Utf8 Class Initialized
INFO - 2020-08-19 16:57:48 --> URI Class Initialized
DEBUG - 2020-08-19 16:57:48 --> No URI present. Default controller set.
INFO - 2020-08-19 16:57:48 --> Router Class Initialized
INFO - 2020-08-19 16:57:48 --> Output Class Initialized
INFO - 2020-08-19 16:57:48 --> Security Class Initialized
DEBUG - 2020-08-19 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 16:57:48 --> Input Class Initialized
INFO - 2020-08-19 16:57:48 --> Language Class Initialized
INFO - 2020-08-19 16:57:48 --> Language Class Initialized
INFO - 2020-08-19 16:57:48 --> Config Class Initialized
INFO - 2020-08-19 16:57:48 --> Loader Class Initialized
INFO - 2020-08-19 16:57:48 --> Helper loaded: url_helper
INFO - 2020-08-19 16:57:48 --> Helper loaded: form_helper
INFO - 2020-08-19 16:57:48 --> Helper loaded: file_helper
INFO - 2020-08-19 16:57:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 16:57:48 --> Database Driver Class Initialized
DEBUG - 2020-08-19 16:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 16:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 16:57:48 --> Upload Class Initialized
INFO - 2020-08-19 16:57:48 --> Controller Class Initialized
DEBUG - 2020-08-19 16:57:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 16:57:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 16:57:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 16:57:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 16:57:48 --> Final output sent to browser
DEBUG - 2020-08-19 16:57:48 --> Total execution time: 0.0522
INFO - 2020-08-19 17:07:08 --> Config Class Initialized
INFO - 2020-08-19 17:07:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 17:07:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 17:07:08 --> Utf8 Class Initialized
INFO - 2020-08-19 17:07:08 --> URI Class Initialized
DEBUG - 2020-08-19 17:07:08 --> No URI present. Default controller set.
INFO - 2020-08-19 17:07:08 --> Router Class Initialized
INFO - 2020-08-19 17:07:08 --> Output Class Initialized
INFO - 2020-08-19 17:07:08 --> Security Class Initialized
DEBUG - 2020-08-19 17:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 17:07:08 --> Input Class Initialized
INFO - 2020-08-19 17:07:08 --> Language Class Initialized
INFO - 2020-08-19 17:07:08 --> Language Class Initialized
INFO - 2020-08-19 17:07:08 --> Config Class Initialized
INFO - 2020-08-19 17:07:08 --> Loader Class Initialized
INFO - 2020-08-19 17:07:08 --> Helper loaded: url_helper
INFO - 2020-08-19 17:07:08 --> Helper loaded: form_helper
INFO - 2020-08-19 17:07:08 --> Helper loaded: file_helper
INFO - 2020-08-19 17:07:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 17:07:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 17:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 17:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 17:07:08 --> Upload Class Initialized
INFO - 2020-08-19 17:07:08 --> Controller Class Initialized
DEBUG - 2020-08-19 17:07:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 17:07:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 17:07:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 17:07:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 17:07:08 --> Final output sent to browser
DEBUG - 2020-08-19 17:07:08 --> Total execution time: 0.0499
INFO - 2020-08-19 17:35:22 --> Config Class Initialized
INFO - 2020-08-19 17:35:22 --> Hooks Class Initialized
DEBUG - 2020-08-19 17:35:22 --> UTF-8 Support Enabled
INFO - 2020-08-19 17:35:22 --> Utf8 Class Initialized
INFO - 2020-08-19 17:35:22 --> URI Class Initialized
DEBUG - 2020-08-19 17:35:22 --> No URI present. Default controller set.
INFO - 2020-08-19 17:35:22 --> Router Class Initialized
INFO - 2020-08-19 17:35:22 --> Output Class Initialized
INFO - 2020-08-19 17:35:22 --> Security Class Initialized
DEBUG - 2020-08-19 17:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 17:35:22 --> Input Class Initialized
INFO - 2020-08-19 17:35:22 --> Language Class Initialized
INFO - 2020-08-19 17:35:22 --> Language Class Initialized
INFO - 2020-08-19 17:35:22 --> Config Class Initialized
INFO - 2020-08-19 17:35:22 --> Loader Class Initialized
INFO - 2020-08-19 17:35:22 --> Helper loaded: url_helper
INFO - 2020-08-19 17:35:22 --> Helper loaded: form_helper
INFO - 2020-08-19 17:35:22 --> Helper loaded: file_helper
INFO - 2020-08-19 17:35:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 17:35:22 --> Database Driver Class Initialized
DEBUG - 2020-08-19 17:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 17:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 17:35:22 --> Upload Class Initialized
INFO - 2020-08-19 17:35:22 --> Controller Class Initialized
DEBUG - 2020-08-19 17:35:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 17:35:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 17:35:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 17:35:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 17:35:22 --> Final output sent to browser
DEBUG - 2020-08-19 17:35:22 --> Total execution time: 0.0498
INFO - 2020-08-19 17:37:13 --> Config Class Initialized
INFO - 2020-08-19 17:37:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 17:37:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 17:37:13 --> Utf8 Class Initialized
INFO - 2020-08-19 17:37:13 --> URI Class Initialized
DEBUG - 2020-08-19 17:37:13 --> No URI present. Default controller set.
INFO - 2020-08-19 17:37:13 --> Router Class Initialized
INFO - 2020-08-19 17:37:13 --> Output Class Initialized
INFO - 2020-08-19 17:37:13 --> Security Class Initialized
DEBUG - 2020-08-19 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 17:37:13 --> Input Class Initialized
INFO - 2020-08-19 17:37:13 --> Language Class Initialized
INFO - 2020-08-19 17:37:13 --> Language Class Initialized
INFO - 2020-08-19 17:37:13 --> Config Class Initialized
INFO - 2020-08-19 17:37:13 --> Loader Class Initialized
INFO - 2020-08-19 17:37:13 --> Helper loaded: url_helper
INFO - 2020-08-19 17:37:13 --> Helper loaded: form_helper
INFO - 2020-08-19 17:37:13 --> Helper loaded: file_helper
INFO - 2020-08-19 17:37:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 17:37:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 17:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 17:37:13 --> Upload Class Initialized
INFO - 2020-08-19 17:37:13 --> Controller Class Initialized
DEBUG - 2020-08-19 17:37:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 17:37:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 17:37:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 17:37:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 17:37:13 --> Final output sent to browser
DEBUG - 2020-08-19 17:37:13 --> Total execution time: 0.0536
INFO - 2020-08-19 17:54:23 --> Config Class Initialized
INFO - 2020-08-19 17:54:23 --> Hooks Class Initialized
DEBUG - 2020-08-19 17:54:23 --> UTF-8 Support Enabled
INFO - 2020-08-19 17:54:23 --> Utf8 Class Initialized
INFO - 2020-08-19 17:54:23 --> URI Class Initialized
INFO - 2020-08-19 17:54:23 --> Router Class Initialized
INFO - 2020-08-19 17:54:23 --> Output Class Initialized
INFO - 2020-08-19 17:54:23 --> Security Class Initialized
DEBUG - 2020-08-19 17:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 17:54:23 --> Input Class Initialized
INFO - 2020-08-19 17:54:23 --> Language Class Initialized
INFO - 2020-08-19 17:54:23 --> Language Class Initialized
INFO - 2020-08-19 17:54:23 --> Config Class Initialized
INFO - 2020-08-19 17:54:23 --> Loader Class Initialized
INFO - 2020-08-19 17:54:23 --> Helper loaded: url_helper
INFO - 2020-08-19 17:54:23 --> Helper loaded: form_helper
INFO - 2020-08-19 17:54:23 --> Helper loaded: file_helper
INFO - 2020-08-19 17:54:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 17:54:23 --> Database Driver Class Initialized
DEBUG - 2020-08-19 17:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 17:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 17:54:23 --> Upload Class Initialized
INFO - 2020-08-19 17:54:23 --> Controller Class Initialized
ERROR - 2020-08-19 17:54:23 --> 404 Page Not Found: /index
INFO - 2020-08-19 18:18:56 --> Config Class Initialized
INFO - 2020-08-19 18:18:56 --> Hooks Class Initialized
DEBUG - 2020-08-19 18:18:56 --> UTF-8 Support Enabled
INFO - 2020-08-19 18:18:56 --> Utf8 Class Initialized
INFO - 2020-08-19 18:18:56 --> URI Class Initialized
DEBUG - 2020-08-19 18:18:56 --> No URI present. Default controller set.
INFO - 2020-08-19 18:18:56 --> Router Class Initialized
INFO - 2020-08-19 18:18:56 --> Output Class Initialized
INFO - 2020-08-19 18:18:56 --> Security Class Initialized
DEBUG - 2020-08-19 18:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 18:18:56 --> Input Class Initialized
INFO - 2020-08-19 18:18:56 --> Language Class Initialized
INFO - 2020-08-19 18:18:56 --> Language Class Initialized
INFO - 2020-08-19 18:18:56 --> Config Class Initialized
INFO - 2020-08-19 18:18:56 --> Loader Class Initialized
INFO - 2020-08-19 18:18:56 --> Helper loaded: url_helper
INFO - 2020-08-19 18:18:56 --> Helper loaded: form_helper
INFO - 2020-08-19 18:18:56 --> Helper loaded: file_helper
INFO - 2020-08-19 18:18:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 18:18:56 --> Database Driver Class Initialized
DEBUG - 2020-08-19 18:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 18:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 18:18:56 --> Upload Class Initialized
INFO - 2020-08-19 18:18:56 --> Controller Class Initialized
DEBUG - 2020-08-19 18:18:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 18:18:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 18:18:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 18:18:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 18:18:56 --> Final output sent to browser
DEBUG - 2020-08-19 18:18:56 --> Total execution time: 0.0513
INFO - 2020-08-19 18:25:06 --> Config Class Initialized
INFO - 2020-08-19 18:25:06 --> Hooks Class Initialized
DEBUG - 2020-08-19 18:25:06 --> UTF-8 Support Enabled
INFO - 2020-08-19 18:25:06 --> Utf8 Class Initialized
INFO - 2020-08-19 18:25:06 --> URI Class Initialized
INFO - 2020-08-19 18:25:06 --> Router Class Initialized
INFO - 2020-08-19 18:25:06 --> Output Class Initialized
INFO - 2020-08-19 18:25:06 --> Security Class Initialized
DEBUG - 2020-08-19 18:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 18:25:06 --> Input Class Initialized
INFO - 2020-08-19 18:25:06 --> Language Class Initialized
INFO - 2020-08-19 18:25:06 --> Language Class Initialized
INFO - 2020-08-19 18:25:06 --> Config Class Initialized
INFO - 2020-08-19 18:25:06 --> Loader Class Initialized
INFO - 2020-08-19 18:25:06 --> Helper loaded: url_helper
INFO - 2020-08-19 18:25:06 --> Helper loaded: form_helper
INFO - 2020-08-19 18:25:06 --> Helper loaded: file_helper
INFO - 2020-08-19 18:25:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 18:25:06 --> Database Driver Class Initialized
DEBUG - 2020-08-19 18:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 18:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 18:25:06 --> Upload Class Initialized
INFO - 2020-08-19 18:25:06 --> Controller Class Initialized
ERROR - 2020-08-19 18:25:06 --> 404 Page Not Found: /index
INFO - 2020-08-19 18:25:07 --> Config Class Initialized
INFO - 2020-08-19 18:25:07 --> Hooks Class Initialized
DEBUG - 2020-08-19 18:25:07 --> UTF-8 Support Enabled
INFO - 2020-08-19 18:25:07 --> Utf8 Class Initialized
INFO - 2020-08-19 18:25:07 --> URI Class Initialized
DEBUG - 2020-08-19 18:25:07 --> No URI present. Default controller set.
INFO - 2020-08-19 18:25:07 --> Router Class Initialized
INFO - 2020-08-19 18:25:07 --> Output Class Initialized
INFO - 2020-08-19 18:25:07 --> Security Class Initialized
DEBUG - 2020-08-19 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 18:25:07 --> Input Class Initialized
INFO - 2020-08-19 18:25:07 --> Language Class Initialized
INFO - 2020-08-19 18:25:07 --> Language Class Initialized
INFO - 2020-08-19 18:25:07 --> Config Class Initialized
INFO - 2020-08-19 18:25:07 --> Loader Class Initialized
INFO - 2020-08-19 18:25:07 --> Helper loaded: url_helper
INFO - 2020-08-19 18:25:07 --> Helper loaded: form_helper
INFO - 2020-08-19 18:25:07 --> Helper loaded: file_helper
INFO - 2020-08-19 18:25:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 18:25:07 --> Database Driver Class Initialized
DEBUG - 2020-08-19 18:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 18:25:07 --> Upload Class Initialized
INFO - 2020-08-19 18:25:07 --> Controller Class Initialized
DEBUG - 2020-08-19 18:25:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 18:25:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 18:25:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 18:25:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 18:25:07 --> Final output sent to browser
DEBUG - 2020-08-19 18:25:07 --> Total execution time: 0.0514
INFO - 2020-08-19 18:25:08 --> Config Class Initialized
INFO - 2020-08-19 18:25:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 18:25:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 18:25:08 --> Utf8 Class Initialized
INFO - 2020-08-19 18:25:08 --> URI Class Initialized
DEBUG - 2020-08-19 18:25:08 --> No URI present. Default controller set.
INFO - 2020-08-19 18:25:08 --> Router Class Initialized
INFO - 2020-08-19 18:25:08 --> Output Class Initialized
INFO - 2020-08-19 18:25:08 --> Security Class Initialized
DEBUG - 2020-08-19 18:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 18:25:08 --> Input Class Initialized
INFO - 2020-08-19 18:25:08 --> Language Class Initialized
INFO - 2020-08-19 18:25:08 --> Language Class Initialized
INFO - 2020-08-19 18:25:08 --> Config Class Initialized
INFO - 2020-08-19 18:25:08 --> Loader Class Initialized
INFO - 2020-08-19 18:25:08 --> Helper loaded: url_helper
INFO - 2020-08-19 18:25:08 --> Helper loaded: form_helper
INFO - 2020-08-19 18:25:08 --> Helper loaded: file_helper
INFO - 2020-08-19 18:25:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 18:25:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 18:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 18:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 18:25:08 --> Upload Class Initialized
INFO - 2020-08-19 18:25:08 --> Controller Class Initialized
DEBUG - 2020-08-19 18:25:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 18:25:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 18:25:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 18:25:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 18:25:08 --> Final output sent to browser
DEBUG - 2020-08-19 18:25:08 --> Total execution time: 0.0495
INFO - 2020-08-19 18:27:41 --> Config Class Initialized
INFO - 2020-08-19 18:27:41 --> Hooks Class Initialized
DEBUG - 2020-08-19 18:27:41 --> UTF-8 Support Enabled
INFO - 2020-08-19 18:27:41 --> Utf8 Class Initialized
INFO - 2020-08-19 18:27:41 --> URI Class Initialized
DEBUG - 2020-08-19 18:27:41 --> No URI present. Default controller set.
INFO - 2020-08-19 18:27:41 --> Router Class Initialized
INFO - 2020-08-19 18:27:41 --> Output Class Initialized
INFO - 2020-08-19 18:27:41 --> Security Class Initialized
DEBUG - 2020-08-19 18:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 18:27:41 --> Input Class Initialized
INFO - 2020-08-19 18:27:41 --> Language Class Initialized
INFO - 2020-08-19 18:27:41 --> Language Class Initialized
INFO - 2020-08-19 18:27:41 --> Config Class Initialized
INFO - 2020-08-19 18:27:41 --> Loader Class Initialized
INFO - 2020-08-19 18:27:41 --> Helper loaded: url_helper
INFO - 2020-08-19 18:27:41 --> Helper loaded: form_helper
INFO - 2020-08-19 18:27:41 --> Helper loaded: file_helper
INFO - 2020-08-19 18:27:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 18:27:41 --> Database Driver Class Initialized
DEBUG - 2020-08-19 18:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 18:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 18:27:41 --> Upload Class Initialized
INFO - 2020-08-19 18:27:41 --> Controller Class Initialized
DEBUG - 2020-08-19 18:27:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 18:27:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 18:27:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 18:27:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 18:27:41 --> Final output sent to browser
DEBUG - 2020-08-19 18:27:41 --> Total execution time: 0.0506
INFO - 2020-08-19 18:47:10 --> Config Class Initialized
INFO - 2020-08-19 18:47:10 --> Hooks Class Initialized
DEBUG - 2020-08-19 18:47:10 --> UTF-8 Support Enabled
INFO - 2020-08-19 18:47:10 --> Utf8 Class Initialized
INFO - 2020-08-19 18:47:10 --> URI Class Initialized
DEBUG - 2020-08-19 18:47:10 --> No URI present. Default controller set.
INFO - 2020-08-19 18:47:10 --> Router Class Initialized
INFO - 2020-08-19 18:47:10 --> Output Class Initialized
INFO - 2020-08-19 18:47:10 --> Security Class Initialized
DEBUG - 2020-08-19 18:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 18:47:10 --> Input Class Initialized
INFO - 2020-08-19 18:47:10 --> Language Class Initialized
INFO - 2020-08-19 18:47:10 --> Language Class Initialized
INFO - 2020-08-19 18:47:10 --> Config Class Initialized
INFO - 2020-08-19 18:47:10 --> Loader Class Initialized
INFO - 2020-08-19 18:47:10 --> Helper loaded: url_helper
INFO - 2020-08-19 18:47:10 --> Helper loaded: form_helper
INFO - 2020-08-19 18:47:10 --> Helper loaded: file_helper
INFO - 2020-08-19 18:47:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 18:47:10 --> Database Driver Class Initialized
DEBUG - 2020-08-19 18:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 18:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 18:47:10 --> Upload Class Initialized
INFO - 2020-08-19 18:47:10 --> Controller Class Initialized
DEBUG - 2020-08-19 18:47:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 18:47:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 18:47:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 18:47:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 18:47:10 --> Final output sent to browser
DEBUG - 2020-08-19 18:47:10 --> Total execution time: 0.0619
INFO - 2020-08-19 19:21:36 --> Config Class Initialized
INFO - 2020-08-19 19:21:36 --> Hooks Class Initialized
DEBUG - 2020-08-19 19:21:36 --> UTF-8 Support Enabled
INFO - 2020-08-19 19:21:36 --> Utf8 Class Initialized
INFO - 2020-08-19 19:21:36 --> URI Class Initialized
INFO - 2020-08-19 19:21:36 --> Router Class Initialized
INFO - 2020-08-19 19:21:36 --> Output Class Initialized
INFO - 2020-08-19 19:21:36 --> Security Class Initialized
DEBUG - 2020-08-19 19:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 19:21:36 --> Input Class Initialized
INFO - 2020-08-19 19:21:36 --> Language Class Initialized
INFO - 2020-08-19 19:21:36 --> Language Class Initialized
INFO - 2020-08-19 19:21:36 --> Config Class Initialized
INFO - 2020-08-19 19:21:36 --> Loader Class Initialized
INFO - 2020-08-19 19:21:36 --> Helper loaded: url_helper
INFO - 2020-08-19 19:21:36 --> Helper loaded: form_helper
INFO - 2020-08-19 19:21:36 --> Helper loaded: file_helper
INFO - 2020-08-19 19:21:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 19:21:36 --> Database Driver Class Initialized
DEBUG - 2020-08-19 19:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 19:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 19:21:36 --> Upload Class Initialized
INFO - 2020-08-19 19:21:36 --> Controller Class Initialized
ERROR - 2020-08-19 19:21:36 --> 404 Page Not Found: /index
INFO - 2020-08-19 19:21:37 --> Config Class Initialized
INFO - 2020-08-19 19:21:37 --> Hooks Class Initialized
DEBUG - 2020-08-19 19:21:37 --> UTF-8 Support Enabled
INFO - 2020-08-19 19:21:37 --> Utf8 Class Initialized
INFO - 2020-08-19 19:21:37 --> URI Class Initialized
INFO - 2020-08-19 19:21:37 --> Router Class Initialized
INFO - 2020-08-19 19:21:37 --> Output Class Initialized
INFO - 2020-08-19 19:21:37 --> Security Class Initialized
DEBUG - 2020-08-19 19:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 19:21:37 --> Input Class Initialized
INFO - 2020-08-19 19:21:37 --> Language Class Initialized
INFO - 2020-08-19 19:21:37 --> Language Class Initialized
INFO - 2020-08-19 19:21:37 --> Config Class Initialized
INFO - 2020-08-19 19:21:37 --> Loader Class Initialized
INFO - 2020-08-19 19:21:37 --> Helper loaded: url_helper
INFO - 2020-08-19 19:21:37 --> Helper loaded: form_helper
INFO - 2020-08-19 19:21:37 --> Helper loaded: file_helper
INFO - 2020-08-19 19:21:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 19:21:37 --> Database Driver Class Initialized
DEBUG - 2020-08-19 19:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 19:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 19:21:37 --> Upload Class Initialized
INFO - 2020-08-19 19:21:37 --> Controller Class Initialized
ERROR - 2020-08-19 19:21:37 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:28:24 --> Config Class Initialized
INFO - 2020-08-19 21:28:24 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:28:24 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:28:24 --> Utf8 Class Initialized
INFO - 2020-08-19 21:28:24 --> URI Class Initialized
INFO - 2020-08-19 21:28:24 --> Router Class Initialized
INFO - 2020-08-19 21:28:24 --> Output Class Initialized
INFO - 2020-08-19 21:28:24 --> Security Class Initialized
DEBUG - 2020-08-19 21:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:28:24 --> Input Class Initialized
INFO - 2020-08-19 21:28:24 --> Language Class Initialized
INFO - 2020-08-19 21:28:24 --> Language Class Initialized
INFO - 2020-08-19 21:28:24 --> Config Class Initialized
INFO - 2020-08-19 21:28:24 --> Loader Class Initialized
INFO - 2020-08-19 21:28:24 --> Helper loaded: url_helper
INFO - 2020-08-19 21:28:24 --> Helper loaded: form_helper
INFO - 2020-08-19 21:28:24 --> Helper loaded: file_helper
INFO - 2020-08-19 21:28:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:28:24 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:28:24 --> Upload Class Initialized
INFO - 2020-08-19 21:28:24 --> Controller Class Initialized
ERROR - 2020-08-19 21:28:24 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:28:28 --> Config Class Initialized
INFO - 2020-08-19 21:28:28 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:28:28 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:28:28 --> Utf8 Class Initialized
INFO - 2020-08-19 21:28:28 --> URI Class Initialized
INFO - 2020-08-19 21:28:28 --> Router Class Initialized
INFO - 2020-08-19 21:28:28 --> Output Class Initialized
INFO - 2020-08-19 21:28:28 --> Security Class Initialized
DEBUG - 2020-08-19 21:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:28:28 --> Input Class Initialized
INFO - 2020-08-19 21:28:28 --> Language Class Initialized
INFO - 2020-08-19 21:28:28 --> Language Class Initialized
INFO - 2020-08-19 21:28:28 --> Config Class Initialized
INFO - 2020-08-19 21:28:28 --> Loader Class Initialized
INFO - 2020-08-19 21:28:28 --> Helper loaded: url_helper
INFO - 2020-08-19 21:28:28 --> Helper loaded: form_helper
INFO - 2020-08-19 21:28:28 --> Helper loaded: file_helper
INFO - 2020-08-19 21:28:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:28:28 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:28:28 --> Upload Class Initialized
INFO - 2020-08-19 21:28:28 --> Controller Class Initialized
ERROR - 2020-08-19 21:28:28 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:28:30 --> Config Class Initialized
INFO - 2020-08-19 21:28:30 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:28:30 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:28:30 --> Utf8 Class Initialized
INFO - 2020-08-19 21:28:30 --> URI Class Initialized
INFO - 2020-08-19 21:28:30 --> Router Class Initialized
INFO - 2020-08-19 21:28:30 --> Output Class Initialized
INFO - 2020-08-19 21:28:30 --> Security Class Initialized
DEBUG - 2020-08-19 21:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:28:30 --> Input Class Initialized
INFO - 2020-08-19 21:28:30 --> Language Class Initialized
INFO - 2020-08-19 21:28:30 --> Language Class Initialized
INFO - 2020-08-19 21:28:30 --> Config Class Initialized
INFO - 2020-08-19 21:28:30 --> Loader Class Initialized
INFO - 2020-08-19 21:28:30 --> Helper loaded: url_helper
INFO - 2020-08-19 21:28:30 --> Helper loaded: form_helper
INFO - 2020-08-19 21:28:30 --> Helper loaded: file_helper
INFO - 2020-08-19 21:28:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:28:30 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:28:30 --> Upload Class Initialized
INFO - 2020-08-19 21:28:30 --> Controller Class Initialized
ERROR - 2020-08-19 21:28:30 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:28:36 --> Config Class Initialized
INFO - 2020-08-19 21:28:36 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:28:36 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:28:36 --> Utf8 Class Initialized
INFO - 2020-08-19 21:28:36 --> URI Class Initialized
INFO - 2020-08-19 21:28:36 --> Router Class Initialized
INFO - 2020-08-19 21:28:36 --> Output Class Initialized
INFO - 2020-08-19 21:28:36 --> Security Class Initialized
DEBUG - 2020-08-19 21:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:28:36 --> Input Class Initialized
INFO - 2020-08-19 21:28:36 --> Language Class Initialized
INFO - 2020-08-19 21:28:36 --> Language Class Initialized
INFO - 2020-08-19 21:28:36 --> Config Class Initialized
INFO - 2020-08-19 21:28:36 --> Loader Class Initialized
INFO - 2020-08-19 21:28:36 --> Helper loaded: url_helper
INFO - 2020-08-19 21:28:36 --> Helper loaded: form_helper
INFO - 2020-08-19 21:28:36 --> Helper loaded: file_helper
INFO - 2020-08-19 21:28:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:28:36 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:28:36 --> Upload Class Initialized
INFO - 2020-08-19 21:28:36 --> Controller Class Initialized
ERROR - 2020-08-19 21:28:36 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:28:51 --> Config Class Initialized
INFO - 2020-08-19 21:28:51 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:28:51 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:28:51 --> Utf8 Class Initialized
INFO - 2020-08-19 21:28:51 --> URI Class Initialized
INFO - 2020-08-19 21:28:51 --> Router Class Initialized
INFO - 2020-08-19 21:28:51 --> Output Class Initialized
INFO - 2020-08-19 21:28:51 --> Security Class Initialized
DEBUG - 2020-08-19 21:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:28:51 --> Input Class Initialized
INFO - 2020-08-19 21:28:51 --> Language Class Initialized
INFO - 2020-08-19 21:28:51 --> Language Class Initialized
INFO - 2020-08-19 21:28:51 --> Config Class Initialized
INFO - 2020-08-19 21:28:51 --> Loader Class Initialized
INFO - 2020-08-19 21:28:51 --> Helper loaded: url_helper
INFO - 2020-08-19 21:28:51 --> Helper loaded: form_helper
INFO - 2020-08-19 21:28:51 --> Helper loaded: file_helper
INFO - 2020-08-19 21:28:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:28:51 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:28:51 --> Upload Class Initialized
INFO - 2020-08-19 21:28:51 --> Controller Class Initialized
ERROR - 2020-08-19 21:28:51 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:29:00 --> Config Class Initialized
INFO - 2020-08-19 21:29:00 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:29:00 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:29:00 --> Utf8 Class Initialized
INFO - 2020-08-19 21:29:00 --> URI Class Initialized
INFO - 2020-08-19 21:29:00 --> Router Class Initialized
INFO - 2020-08-19 21:29:00 --> Output Class Initialized
INFO - 2020-08-19 21:29:00 --> Security Class Initialized
DEBUG - 2020-08-19 21:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:29:00 --> Input Class Initialized
INFO - 2020-08-19 21:29:00 --> Language Class Initialized
INFO - 2020-08-19 21:29:00 --> Language Class Initialized
INFO - 2020-08-19 21:29:00 --> Config Class Initialized
INFO - 2020-08-19 21:29:00 --> Loader Class Initialized
INFO - 2020-08-19 21:29:00 --> Helper loaded: url_helper
INFO - 2020-08-19 21:29:00 --> Helper loaded: form_helper
INFO - 2020-08-19 21:29:00 --> Helper loaded: file_helper
INFO - 2020-08-19 21:29:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:29:00 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:29:00 --> Upload Class Initialized
INFO - 2020-08-19 21:29:00 --> Controller Class Initialized
ERROR - 2020-08-19 21:29:00 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:29:16 --> Config Class Initialized
INFO - 2020-08-19 21:29:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:29:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:29:16 --> Utf8 Class Initialized
INFO - 2020-08-19 21:29:16 --> URI Class Initialized
INFO - 2020-08-19 21:29:16 --> Router Class Initialized
INFO - 2020-08-19 21:29:16 --> Output Class Initialized
INFO - 2020-08-19 21:29:16 --> Security Class Initialized
DEBUG - 2020-08-19 21:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:29:16 --> Input Class Initialized
INFO - 2020-08-19 21:29:16 --> Language Class Initialized
INFO - 2020-08-19 21:29:16 --> Language Class Initialized
INFO - 2020-08-19 21:29:16 --> Config Class Initialized
INFO - 2020-08-19 21:29:16 --> Loader Class Initialized
INFO - 2020-08-19 21:29:16 --> Helper loaded: url_helper
INFO - 2020-08-19 21:29:16 --> Helper loaded: form_helper
INFO - 2020-08-19 21:29:16 --> Helper loaded: file_helper
INFO - 2020-08-19 21:29:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:29:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:29:16 --> Upload Class Initialized
INFO - 2020-08-19 21:29:16 --> Controller Class Initialized
ERROR - 2020-08-19 21:29:16 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:29:22 --> Config Class Initialized
INFO - 2020-08-19 21:29:22 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:29:22 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:29:22 --> Utf8 Class Initialized
INFO - 2020-08-19 21:29:22 --> URI Class Initialized
INFO - 2020-08-19 21:29:22 --> Router Class Initialized
INFO - 2020-08-19 21:29:22 --> Output Class Initialized
INFO - 2020-08-19 21:29:22 --> Security Class Initialized
DEBUG - 2020-08-19 21:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:29:22 --> Input Class Initialized
INFO - 2020-08-19 21:29:22 --> Language Class Initialized
INFO - 2020-08-19 21:29:22 --> Language Class Initialized
INFO - 2020-08-19 21:29:22 --> Config Class Initialized
INFO - 2020-08-19 21:29:22 --> Loader Class Initialized
INFO - 2020-08-19 21:29:22 --> Helper loaded: url_helper
INFO - 2020-08-19 21:29:22 --> Helper loaded: form_helper
INFO - 2020-08-19 21:29:22 --> Helper loaded: file_helper
INFO - 2020-08-19 21:29:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:29:22 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:29:22 --> Upload Class Initialized
INFO - 2020-08-19 21:29:22 --> Controller Class Initialized
ERROR - 2020-08-19 21:29:22 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:29:40 --> Config Class Initialized
INFO - 2020-08-19 21:29:40 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:29:40 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:29:40 --> Utf8 Class Initialized
INFO - 2020-08-19 21:29:40 --> URI Class Initialized
INFO - 2020-08-19 21:29:40 --> Router Class Initialized
INFO - 2020-08-19 21:29:40 --> Output Class Initialized
INFO - 2020-08-19 21:29:40 --> Security Class Initialized
DEBUG - 2020-08-19 21:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:29:40 --> Input Class Initialized
INFO - 2020-08-19 21:29:40 --> Language Class Initialized
INFO - 2020-08-19 21:29:40 --> Language Class Initialized
INFO - 2020-08-19 21:29:40 --> Config Class Initialized
INFO - 2020-08-19 21:29:40 --> Loader Class Initialized
INFO - 2020-08-19 21:29:40 --> Helper loaded: url_helper
INFO - 2020-08-19 21:29:40 --> Helper loaded: form_helper
INFO - 2020-08-19 21:29:40 --> Helper loaded: file_helper
INFO - 2020-08-19 21:29:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:29:40 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:29:40 --> Upload Class Initialized
INFO - 2020-08-19 21:29:41 --> Controller Class Initialized
ERROR - 2020-08-19 21:29:41 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:29:48 --> Config Class Initialized
INFO - 2020-08-19 21:29:48 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:29:48 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:29:48 --> Utf8 Class Initialized
INFO - 2020-08-19 21:29:48 --> URI Class Initialized
INFO - 2020-08-19 21:29:48 --> Router Class Initialized
INFO - 2020-08-19 21:29:48 --> Output Class Initialized
INFO - 2020-08-19 21:29:48 --> Security Class Initialized
DEBUG - 2020-08-19 21:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:29:48 --> Input Class Initialized
INFO - 2020-08-19 21:29:48 --> Language Class Initialized
INFO - 2020-08-19 21:29:48 --> Language Class Initialized
INFO - 2020-08-19 21:29:48 --> Config Class Initialized
INFO - 2020-08-19 21:29:48 --> Loader Class Initialized
INFO - 2020-08-19 21:29:48 --> Helper loaded: url_helper
INFO - 2020-08-19 21:29:48 --> Helper loaded: form_helper
INFO - 2020-08-19 21:29:48 --> Helper loaded: file_helper
INFO - 2020-08-19 21:29:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:29:48 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:29:48 --> Upload Class Initialized
INFO - 2020-08-19 21:29:48 --> Controller Class Initialized
ERROR - 2020-08-19 21:29:48 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:30:04 --> Config Class Initialized
INFO - 2020-08-19 21:30:04 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:30:04 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:30:04 --> Utf8 Class Initialized
INFO - 2020-08-19 21:30:04 --> URI Class Initialized
INFO - 2020-08-19 21:30:04 --> Router Class Initialized
INFO - 2020-08-19 21:30:04 --> Output Class Initialized
INFO - 2020-08-19 21:30:04 --> Security Class Initialized
DEBUG - 2020-08-19 21:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:30:04 --> Input Class Initialized
INFO - 2020-08-19 21:30:04 --> Language Class Initialized
INFO - 2020-08-19 21:30:04 --> Language Class Initialized
INFO - 2020-08-19 21:30:04 --> Config Class Initialized
INFO - 2020-08-19 21:30:04 --> Loader Class Initialized
INFO - 2020-08-19 21:30:04 --> Helper loaded: url_helper
INFO - 2020-08-19 21:30:04 --> Helper loaded: form_helper
INFO - 2020-08-19 21:30:04 --> Helper loaded: file_helper
INFO - 2020-08-19 21:30:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:30:04 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:30:04 --> Upload Class Initialized
INFO - 2020-08-19 21:30:04 --> Controller Class Initialized
ERROR - 2020-08-19 21:30:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:30:23 --> Config Class Initialized
INFO - 2020-08-19 21:30:23 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:30:23 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:30:23 --> Utf8 Class Initialized
INFO - 2020-08-19 21:30:23 --> URI Class Initialized
INFO - 2020-08-19 21:30:23 --> Router Class Initialized
INFO - 2020-08-19 21:30:23 --> Output Class Initialized
INFO - 2020-08-19 21:30:23 --> Security Class Initialized
DEBUG - 2020-08-19 21:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:30:23 --> Input Class Initialized
INFO - 2020-08-19 21:30:23 --> Language Class Initialized
INFO - 2020-08-19 21:30:23 --> Language Class Initialized
INFO - 2020-08-19 21:30:23 --> Config Class Initialized
INFO - 2020-08-19 21:30:23 --> Loader Class Initialized
INFO - 2020-08-19 21:30:23 --> Helper loaded: url_helper
INFO - 2020-08-19 21:30:23 --> Helper loaded: form_helper
INFO - 2020-08-19 21:30:23 --> Helper loaded: file_helper
INFO - 2020-08-19 21:30:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:30:23 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:30:23 --> Upload Class Initialized
INFO - 2020-08-19 21:30:23 --> Controller Class Initialized
ERROR - 2020-08-19 21:30:23 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:30:26 --> Config Class Initialized
INFO - 2020-08-19 21:30:26 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:30:26 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:30:26 --> Utf8 Class Initialized
INFO - 2020-08-19 21:30:26 --> URI Class Initialized
INFO - 2020-08-19 21:30:26 --> Router Class Initialized
INFO - 2020-08-19 21:30:26 --> Output Class Initialized
INFO - 2020-08-19 21:30:26 --> Security Class Initialized
DEBUG - 2020-08-19 21:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:30:26 --> Input Class Initialized
INFO - 2020-08-19 21:30:26 --> Language Class Initialized
INFO - 2020-08-19 21:30:26 --> Language Class Initialized
INFO - 2020-08-19 21:30:26 --> Config Class Initialized
INFO - 2020-08-19 21:30:26 --> Loader Class Initialized
INFO - 2020-08-19 21:30:26 --> Helper loaded: url_helper
INFO - 2020-08-19 21:30:26 --> Helper loaded: form_helper
INFO - 2020-08-19 21:30:26 --> Helper loaded: file_helper
INFO - 2020-08-19 21:30:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:30:26 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:30:26 --> Upload Class Initialized
INFO - 2020-08-19 21:30:26 --> Controller Class Initialized
ERROR - 2020-08-19 21:30:26 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:30:31 --> Config Class Initialized
INFO - 2020-08-19 21:30:31 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:30:31 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:30:31 --> Utf8 Class Initialized
INFO - 2020-08-19 21:30:31 --> URI Class Initialized
INFO - 2020-08-19 21:30:31 --> Router Class Initialized
INFO - 2020-08-19 21:30:31 --> Output Class Initialized
INFO - 2020-08-19 21:30:31 --> Security Class Initialized
DEBUG - 2020-08-19 21:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:30:31 --> Input Class Initialized
INFO - 2020-08-19 21:30:31 --> Language Class Initialized
INFO - 2020-08-19 21:30:31 --> Language Class Initialized
INFO - 2020-08-19 21:30:31 --> Config Class Initialized
INFO - 2020-08-19 21:30:31 --> Loader Class Initialized
INFO - 2020-08-19 21:30:31 --> Helper loaded: url_helper
INFO - 2020-08-19 21:30:31 --> Helper loaded: form_helper
INFO - 2020-08-19 21:30:31 --> Helper loaded: file_helper
INFO - 2020-08-19 21:30:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:30:31 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:30:31 --> Upload Class Initialized
INFO - 2020-08-19 21:30:31 --> Controller Class Initialized
ERROR - 2020-08-19 21:30:31 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:30:54 --> Config Class Initialized
INFO - 2020-08-19 21:30:54 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:30:54 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:30:54 --> Utf8 Class Initialized
INFO - 2020-08-19 21:30:54 --> URI Class Initialized
INFO - 2020-08-19 21:30:54 --> Router Class Initialized
INFO - 2020-08-19 21:30:54 --> Output Class Initialized
INFO - 2020-08-19 21:30:54 --> Security Class Initialized
DEBUG - 2020-08-19 21:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:30:54 --> Input Class Initialized
INFO - 2020-08-19 21:30:54 --> Language Class Initialized
INFO - 2020-08-19 21:30:54 --> Language Class Initialized
INFO - 2020-08-19 21:30:54 --> Config Class Initialized
INFO - 2020-08-19 21:30:54 --> Loader Class Initialized
INFO - 2020-08-19 21:30:54 --> Helper loaded: url_helper
INFO - 2020-08-19 21:30:54 --> Helper loaded: form_helper
INFO - 2020-08-19 21:30:54 --> Helper loaded: file_helper
INFO - 2020-08-19 21:30:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:30:54 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:30:54 --> Upload Class Initialized
INFO - 2020-08-19 21:30:54 --> Controller Class Initialized
ERROR - 2020-08-19 21:30:54 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:31:09 --> Config Class Initialized
INFO - 2020-08-19 21:31:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:31:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:31:09 --> Utf8 Class Initialized
INFO - 2020-08-19 21:31:09 --> URI Class Initialized
INFO - 2020-08-19 21:31:09 --> Router Class Initialized
INFO - 2020-08-19 21:31:09 --> Output Class Initialized
INFO - 2020-08-19 21:31:09 --> Security Class Initialized
DEBUG - 2020-08-19 21:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:31:09 --> Input Class Initialized
INFO - 2020-08-19 21:31:09 --> Language Class Initialized
INFO - 2020-08-19 21:31:09 --> Language Class Initialized
INFO - 2020-08-19 21:31:09 --> Config Class Initialized
INFO - 2020-08-19 21:31:09 --> Loader Class Initialized
INFO - 2020-08-19 21:31:09 --> Helper loaded: url_helper
INFO - 2020-08-19 21:31:09 --> Helper loaded: form_helper
INFO - 2020-08-19 21:31:09 --> Helper loaded: file_helper
INFO - 2020-08-19 21:31:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:31:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:31:09 --> Upload Class Initialized
INFO - 2020-08-19 21:31:09 --> Controller Class Initialized
ERROR - 2020-08-19 21:31:09 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:31:19 --> Config Class Initialized
INFO - 2020-08-19 21:31:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:31:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:31:19 --> Utf8 Class Initialized
INFO - 2020-08-19 21:31:19 --> URI Class Initialized
INFO - 2020-08-19 21:31:19 --> Router Class Initialized
INFO - 2020-08-19 21:31:19 --> Output Class Initialized
INFO - 2020-08-19 21:31:19 --> Security Class Initialized
DEBUG - 2020-08-19 21:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:31:19 --> Input Class Initialized
INFO - 2020-08-19 21:31:19 --> Language Class Initialized
INFO - 2020-08-19 21:31:19 --> Language Class Initialized
INFO - 2020-08-19 21:31:19 --> Config Class Initialized
INFO - 2020-08-19 21:31:19 --> Loader Class Initialized
INFO - 2020-08-19 21:31:19 --> Helper loaded: url_helper
INFO - 2020-08-19 21:31:19 --> Helper loaded: form_helper
INFO - 2020-08-19 21:31:19 --> Helper loaded: file_helper
INFO - 2020-08-19 21:31:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:31:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:31:19 --> Upload Class Initialized
INFO - 2020-08-19 21:31:19 --> Controller Class Initialized
ERROR - 2020-08-19 21:31:19 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:31:27 --> Config Class Initialized
INFO - 2020-08-19 21:31:27 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:31:27 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:31:27 --> Utf8 Class Initialized
INFO - 2020-08-19 21:31:27 --> URI Class Initialized
INFO - 2020-08-19 21:31:27 --> Router Class Initialized
INFO - 2020-08-19 21:31:27 --> Output Class Initialized
INFO - 2020-08-19 21:31:27 --> Security Class Initialized
DEBUG - 2020-08-19 21:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:31:27 --> Input Class Initialized
INFO - 2020-08-19 21:31:27 --> Language Class Initialized
INFO - 2020-08-19 21:31:27 --> Language Class Initialized
INFO - 2020-08-19 21:31:27 --> Config Class Initialized
INFO - 2020-08-19 21:31:27 --> Loader Class Initialized
INFO - 2020-08-19 21:31:27 --> Helper loaded: url_helper
INFO - 2020-08-19 21:31:27 --> Helper loaded: form_helper
INFO - 2020-08-19 21:31:27 --> Helper loaded: file_helper
INFO - 2020-08-19 21:31:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:31:27 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:31:27 --> Upload Class Initialized
INFO - 2020-08-19 21:31:27 --> Controller Class Initialized
ERROR - 2020-08-19 21:31:27 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:42:44 --> Config Class Initialized
INFO - 2020-08-19 21:42:44 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:42:44 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:42:44 --> Utf8 Class Initialized
INFO - 2020-08-19 21:42:44 --> URI Class Initialized
INFO - 2020-08-19 21:42:44 --> Router Class Initialized
INFO - 2020-08-19 21:42:44 --> Output Class Initialized
INFO - 2020-08-19 21:42:44 --> Security Class Initialized
DEBUG - 2020-08-19 21:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:42:44 --> Input Class Initialized
INFO - 2020-08-19 21:42:44 --> Language Class Initialized
INFO - 2020-08-19 21:42:44 --> Language Class Initialized
INFO - 2020-08-19 21:42:44 --> Config Class Initialized
INFO - 2020-08-19 21:42:44 --> Loader Class Initialized
INFO - 2020-08-19 21:42:44 --> Helper loaded: url_helper
INFO - 2020-08-19 21:42:44 --> Helper loaded: form_helper
INFO - 2020-08-19 21:42:44 --> Helper loaded: file_helper
INFO - 2020-08-19 21:42:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:42:44 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:42:44 --> Upload Class Initialized
INFO - 2020-08-19 21:42:44 --> Controller Class Initialized
ERROR - 2020-08-19 21:42:44 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:49:46 --> Config Class Initialized
INFO - 2020-08-19 21:49:46 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:49:46 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:49:46 --> Utf8 Class Initialized
INFO - 2020-08-19 21:49:46 --> URI Class Initialized
INFO - 2020-08-19 21:49:46 --> Router Class Initialized
INFO - 2020-08-19 21:49:46 --> Output Class Initialized
INFO - 2020-08-19 21:49:46 --> Security Class Initialized
DEBUG - 2020-08-19 21:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:49:46 --> Input Class Initialized
INFO - 2020-08-19 21:49:46 --> Language Class Initialized
INFO - 2020-08-19 21:49:46 --> Language Class Initialized
INFO - 2020-08-19 21:49:46 --> Config Class Initialized
INFO - 2020-08-19 21:49:46 --> Loader Class Initialized
INFO - 2020-08-19 21:49:46 --> Helper loaded: url_helper
INFO - 2020-08-19 21:49:46 --> Helper loaded: form_helper
INFO - 2020-08-19 21:49:46 --> Helper loaded: file_helper
INFO - 2020-08-19 21:49:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:49:46 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:49:46 --> Upload Class Initialized
INFO - 2020-08-19 21:49:46 --> Controller Class Initialized
DEBUG - 2020-08-19 21:49:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 21:49:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-19 21:49:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 21:49:46 --> Final output sent to browser
DEBUG - 2020-08-19 21:49:46 --> Total execution time: 0.0522
INFO - 2020-08-19 21:49:48 --> Config Class Initialized
INFO - 2020-08-19 21:49:48 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:49:48 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:49:48 --> Utf8 Class Initialized
INFO - 2020-08-19 21:49:48 --> URI Class Initialized
INFO - 2020-08-19 21:49:48 --> Router Class Initialized
INFO - 2020-08-19 21:49:48 --> Output Class Initialized
INFO - 2020-08-19 21:49:48 --> Security Class Initialized
DEBUG - 2020-08-19 21:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:49:48 --> Input Class Initialized
INFO - 2020-08-19 21:49:48 --> Language Class Initialized
INFO - 2020-08-19 21:49:48 --> Language Class Initialized
INFO - 2020-08-19 21:49:48 --> Config Class Initialized
INFO - 2020-08-19 21:49:48 --> Loader Class Initialized
INFO - 2020-08-19 21:49:48 --> Helper loaded: url_helper
INFO - 2020-08-19 21:49:48 --> Helper loaded: form_helper
INFO - 2020-08-19 21:49:48 --> Helper loaded: file_helper
INFO - 2020-08-19 21:49:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:49:48 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:49:48 --> Upload Class Initialized
INFO - 2020-08-19 21:49:48 --> Controller Class Initialized
DEBUG - 2020-08-19 21:49:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 21:49:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-19 21:49:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 21:49:48 --> Final output sent to browser
DEBUG - 2020-08-19 21:49:48 --> Total execution time: 0.0570
INFO - 2020-08-19 21:49:51 --> Config Class Initialized
INFO - 2020-08-19 21:49:51 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:49:51 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:49:51 --> Utf8 Class Initialized
INFO - 2020-08-19 21:49:51 --> URI Class Initialized
INFO - 2020-08-19 21:49:51 --> Router Class Initialized
INFO - 2020-08-19 21:49:51 --> Output Class Initialized
INFO - 2020-08-19 21:49:51 --> Security Class Initialized
DEBUG - 2020-08-19 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:49:51 --> Input Class Initialized
INFO - 2020-08-19 21:49:51 --> Language Class Initialized
INFO - 2020-08-19 21:49:51 --> Language Class Initialized
INFO - 2020-08-19 21:49:51 --> Config Class Initialized
INFO - 2020-08-19 21:49:51 --> Loader Class Initialized
INFO - 2020-08-19 21:49:51 --> Helper loaded: url_helper
INFO - 2020-08-19 21:49:51 --> Helper loaded: form_helper
INFO - 2020-08-19 21:49:51 --> Helper loaded: file_helper
INFO - 2020-08-19 21:49:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:49:51 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:49:51 --> Upload Class Initialized
INFO - 2020-08-19 21:49:51 --> Controller Class Initialized
ERROR - 2020-08-19 21:49:51 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:49:51 --> Config Class Initialized
INFO - 2020-08-19 21:49:51 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:49:51 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:49:51 --> Utf8 Class Initialized
INFO - 2020-08-19 21:49:51 --> URI Class Initialized
INFO - 2020-08-19 21:49:51 --> Router Class Initialized
INFO - 2020-08-19 21:49:51 --> Output Class Initialized
INFO - 2020-08-19 21:49:51 --> Security Class Initialized
DEBUG - 2020-08-19 21:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:49:51 --> Input Class Initialized
INFO - 2020-08-19 21:49:51 --> Language Class Initialized
INFO - 2020-08-19 21:49:51 --> Language Class Initialized
INFO - 2020-08-19 21:49:51 --> Config Class Initialized
INFO - 2020-08-19 21:49:51 --> Loader Class Initialized
INFO - 2020-08-19 21:49:51 --> Helper loaded: url_helper
INFO - 2020-08-19 21:49:51 --> Helper loaded: form_helper
INFO - 2020-08-19 21:49:51 --> Helper loaded: file_helper
INFO - 2020-08-19 21:49:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:49:51 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:49:51 --> Upload Class Initialized
INFO - 2020-08-19 21:49:51 --> Controller Class Initialized
ERROR - 2020-08-19 21:49:51 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:49:52 --> Config Class Initialized
INFO - 2020-08-19 21:49:52 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:49:52 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:49:52 --> Utf8 Class Initialized
INFO - 2020-08-19 21:49:52 --> URI Class Initialized
DEBUG - 2020-08-19 21:49:52 --> No URI present. Default controller set.
INFO - 2020-08-19 21:49:52 --> Router Class Initialized
INFO - 2020-08-19 21:49:52 --> Output Class Initialized
INFO - 2020-08-19 21:49:52 --> Security Class Initialized
DEBUG - 2020-08-19 21:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:49:52 --> Input Class Initialized
INFO - 2020-08-19 21:49:52 --> Language Class Initialized
INFO - 2020-08-19 21:49:52 --> Language Class Initialized
INFO - 2020-08-19 21:49:52 --> Config Class Initialized
INFO - 2020-08-19 21:49:52 --> Loader Class Initialized
INFO - 2020-08-19 21:49:52 --> Helper loaded: url_helper
INFO - 2020-08-19 21:49:52 --> Helper loaded: form_helper
INFO - 2020-08-19 21:49:52 --> Helper loaded: file_helper
INFO - 2020-08-19 21:49:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:49:52 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:49:52 --> Upload Class Initialized
INFO - 2020-08-19 21:49:52 --> Controller Class Initialized
DEBUG - 2020-08-19 21:49:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 21:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 21:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 21:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 21:49:52 --> Final output sent to browser
DEBUG - 2020-08-19 21:49:52 --> Total execution time: 0.0594
INFO - 2020-08-19 21:50:00 --> Config Class Initialized
INFO - 2020-08-19 21:50:00 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:50:00 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:50:00 --> Utf8 Class Initialized
INFO - 2020-08-19 21:50:00 --> URI Class Initialized
INFO - 2020-08-19 21:50:00 --> Router Class Initialized
INFO - 2020-08-19 21:50:00 --> Output Class Initialized
INFO - 2020-08-19 21:50:00 --> Security Class Initialized
DEBUG - 2020-08-19 21:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:50:00 --> Input Class Initialized
INFO - 2020-08-19 21:50:00 --> Language Class Initialized
INFO - 2020-08-19 21:50:00 --> Language Class Initialized
INFO - 2020-08-19 21:50:00 --> Config Class Initialized
INFO - 2020-08-19 21:50:00 --> Loader Class Initialized
INFO - 2020-08-19 21:50:00 --> Helper loaded: url_helper
INFO - 2020-08-19 21:50:00 --> Helper loaded: form_helper
INFO - 2020-08-19 21:50:00 --> Helper loaded: file_helper
INFO - 2020-08-19 21:50:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:50:00 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:50:00 --> Upload Class Initialized
INFO - 2020-08-19 21:50:00 --> Controller Class Initialized
ERROR - 2020-08-19 21:50:00 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:50:07 --> Config Class Initialized
INFO - 2020-08-19 21:50:07 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:50:07 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:50:07 --> Utf8 Class Initialized
INFO - 2020-08-19 21:50:07 --> URI Class Initialized
INFO - 2020-08-19 21:50:07 --> Router Class Initialized
INFO - 2020-08-19 21:50:07 --> Output Class Initialized
INFO - 2020-08-19 21:50:07 --> Security Class Initialized
DEBUG - 2020-08-19 21:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:50:07 --> Input Class Initialized
INFO - 2020-08-19 21:50:07 --> Language Class Initialized
INFO - 2020-08-19 21:50:07 --> Language Class Initialized
INFO - 2020-08-19 21:50:07 --> Config Class Initialized
INFO - 2020-08-19 21:50:07 --> Loader Class Initialized
INFO - 2020-08-19 21:50:07 --> Helper loaded: url_helper
INFO - 2020-08-19 21:50:07 --> Helper loaded: form_helper
INFO - 2020-08-19 21:50:07 --> Helper loaded: file_helper
INFO - 2020-08-19 21:50:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:50:07 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:50:07 --> Upload Class Initialized
INFO - 2020-08-19 21:50:07 --> Controller Class Initialized
DEBUG - 2020-08-19 21:50:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 21:50:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-19 21:50:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 21:50:07 --> Final output sent to browser
DEBUG - 2020-08-19 21:50:07 --> Total execution time: 0.0504
INFO - 2020-08-19 21:50:08 --> Config Class Initialized
INFO - 2020-08-19 21:50:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:50:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:50:08 --> Utf8 Class Initialized
INFO - 2020-08-19 21:50:08 --> URI Class Initialized
INFO - 2020-08-19 21:50:08 --> Router Class Initialized
INFO - 2020-08-19 21:50:08 --> Output Class Initialized
INFO - 2020-08-19 21:50:08 --> Security Class Initialized
DEBUG - 2020-08-19 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:50:08 --> Input Class Initialized
INFO - 2020-08-19 21:50:08 --> Language Class Initialized
INFO - 2020-08-19 21:50:08 --> Language Class Initialized
INFO - 2020-08-19 21:50:08 --> Config Class Initialized
INFO - 2020-08-19 21:50:08 --> Loader Class Initialized
INFO - 2020-08-19 21:50:08 --> Helper loaded: url_helper
INFO - 2020-08-19 21:50:08 --> Helper loaded: form_helper
INFO - 2020-08-19 21:50:08 --> Helper loaded: file_helper
INFO - 2020-08-19 21:50:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:50:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:50:08 --> Upload Class Initialized
INFO - 2020-08-19 21:50:08 --> Controller Class Initialized
ERROR - 2020-08-19 21:50:08 --> 404 Page Not Found: /index
INFO - 2020-08-19 21:55:04 --> Config Class Initialized
INFO - 2020-08-19 21:55:04 --> Hooks Class Initialized
DEBUG - 2020-08-19 21:55:04 --> UTF-8 Support Enabled
INFO - 2020-08-19 21:55:04 --> Utf8 Class Initialized
INFO - 2020-08-19 21:55:04 --> URI Class Initialized
DEBUG - 2020-08-19 21:55:04 --> No URI present. Default controller set.
INFO - 2020-08-19 21:55:04 --> Router Class Initialized
INFO - 2020-08-19 21:55:04 --> Output Class Initialized
INFO - 2020-08-19 21:55:04 --> Security Class Initialized
DEBUG - 2020-08-19 21:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 21:55:04 --> Input Class Initialized
INFO - 2020-08-19 21:55:04 --> Language Class Initialized
INFO - 2020-08-19 21:55:04 --> Language Class Initialized
INFO - 2020-08-19 21:55:04 --> Config Class Initialized
INFO - 2020-08-19 21:55:04 --> Loader Class Initialized
INFO - 2020-08-19 21:55:04 --> Helper loaded: url_helper
INFO - 2020-08-19 21:55:04 --> Helper loaded: form_helper
INFO - 2020-08-19 21:55:04 --> Helper loaded: file_helper
INFO - 2020-08-19 21:55:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 21:55:04 --> Database Driver Class Initialized
DEBUG - 2020-08-19 21:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 21:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 21:55:04 --> Upload Class Initialized
INFO - 2020-08-19 21:55:04 --> Controller Class Initialized
DEBUG - 2020-08-19 21:55:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 21:55:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 21:55:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 21:55:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 21:55:04 --> Final output sent to browser
DEBUG - 2020-08-19 21:55:04 --> Total execution time: 0.0925
INFO - 2020-08-19 22:20:04 --> Config Class Initialized
INFO - 2020-08-19 22:20:04 --> Hooks Class Initialized
DEBUG - 2020-08-19 22:20:04 --> UTF-8 Support Enabled
INFO - 2020-08-19 22:20:04 --> Utf8 Class Initialized
INFO - 2020-08-19 22:20:04 --> URI Class Initialized
INFO - 2020-08-19 22:20:04 --> Router Class Initialized
INFO - 2020-08-19 22:20:04 --> Output Class Initialized
INFO - 2020-08-19 22:20:04 --> Security Class Initialized
DEBUG - 2020-08-19 22:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 22:20:04 --> Input Class Initialized
INFO - 2020-08-19 22:20:04 --> Language Class Initialized
INFO - 2020-08-19 22:20:04 --> Language Class Initialized
INFO - 2020-08-19 22:20:04 --> Config Class Initialized
INFO - 2020-08-19 22:20:04 --> Loader Class Initialized
INFO - 2020-08-19 22:20:04 --> Helper loaded: url_helper
INFO - 2020-08-19 22:20:04 --> Helper loaded: form_helper
INFO - 2020-08-19 22:20:04 --> Helper loaded: file_helper
INFO - 2020-08-19 22:20:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 22:20:04 --> Database Driver Class Initialized
DEBUG - 2020-08-19 22:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 22:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 22:20:04 --> Upload Class Initialized
INFO - 2020-08-19 22:20:04 --> Controller Class Initialized
ERROR - 2020-08-19 22:20:04 --> 404 Page Not Found: /index
INFO - 2020-08-19 23:24:58 --> Config Class Initialized
INFO - 2020-08-19 23:24:58 --> Config Class Initialized
INFO - 2020-08-19 23:24:58 --> Hooks Class Initialized
INFO - 2020-08-19 23:24:58 --> Hooks Class Initialized
DEBUG - 2020-08-19 23:24:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 23:24:58 --> Utf8 Class Initialized
DEBUG - 2020-08-19 23:24:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 23:24:58 --> Utf8 Class Initialized
INFO - 2020-08-19 23:24:58 --> URI Class Initialized
INFO - 2020-08-19 23:24:58 --> URI Class Initialized
DEBUG - 2020-08-19 23:24:58 --> No URI present. Default controller set.
INFO - 2020-08-19 23:24:58 --> Router Class Initialized
DEBUG - 2020-08-19 23:24:58 --> No URI present. Default controller set.
INFO - 2020-08-19 23:24:58 --> Router Class Initialized
INFO - 2020-08-19 23:24:58 --> Output Class Initialized
INFO - 2020-08-19 23:24:58 --> Output Class Initialized
INFO - 2020-08-19 23:24:58 --> Security Class Initialized
INFO - 2020-08-19 23:24:58 --> Security Class Initialized
DEBUG - 2020-08-19 23:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 23:24:58 --> Input Class Initialized
DEBUG - 2020-08-19 23:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 23:24:58 --> Input Class Initialized
INFO - 2020-08-19 23:24:58 --> Language Class Initialized
INFO - 2020-08-19 23:24:58 --> Language Class Initialized
INFO - 2020-08-19 23:24:58 --> Language Class Initialized
INFO - 2020-08-19 23:24:58 --> Config Class Initialized
INFO - 2020-08-19 23:24:58 --> Language Class Initialized
INFO - 2020-08-19 23:24:58 --> Config Class Initialized
INFO - 2020-08-19 23:24:58 --> Loader Class Initialized
INFO - 2020-08-19 23:24:58 --> Loader Class Initialized
INFO - 2020-08-19 23:24:58 --> Helper loaded: url_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: url_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: form_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: form_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: file_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: file_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 23:24:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 23:24:58 --> Database Driver Class Initialized
INFO - 2020-08-19 23:24:58 --> Database Driver Class Initialized
DEBUG - 2020-08-19 23:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-08-19 23:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 23:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 23:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 23:24:58 --> Upload Class Initialized
INFO - 2020-08-19 23:24:58 --> Upload Class Initialized
INFO - 2020-08-19 23:24:58 --> Controller Class Initialized
DEBUG - 2020-08-19 23:24:58 --> Home MX_Controller Initialized
INFO - 2020-08-19 23:24:58 --> Controller Class Initialized
DEBUG - 2020-08-19 23:24:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 23:24:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 23:24:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 23:24:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 23:24:58 --> Final output sent to browser
DEBUG - 2020-08-19 23:24:58 --> Total execution time: 0.0510
DEBUG - 2020-08-19 23:24:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 23:24:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 23:24:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 23:24:58 --> Final output sent to browser
DEBUG - 2020-08-19 23:24:58 --> Total execution time: 0.0532
INFO - 2020-08-19 23:28:29 --> Config Class Initialized
INFO - 2020-08-19 23:28:29 --> Hooks Class Initialized
DEBUG - 2020-08-19 23:28:29 --> UTF-8 Support Enabled
INFO - 2020-08-19 23:28:29 --> Utf8 Class Initialized
INFO - 2020-08-19 23:28:29 --> URI Class Initialized
INFO - 2020-08-19 23:28:29 --> Router Class Initialized
INFO - 2020-08-19 23:28:29 --> Output Class Initialized
INFO - 2020-08-19 23:28:29 --> Security Class Initialized
DEBUG - 2020-08-19 23:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 23:28:29 --> Input Class Initialized
INFO - 2020-08-19 23:28:29 --> Language Class Initialized
INFO - 2020-08-19 23:28:29 --> Language Class Initialized
INFO - 2020-08-19 23:28:29 --> Config Class Initialized
INFO - 2020-08-19 23:28:29 --> Loader Class Initialized
INFO - 2020-08-19 23:28:29 --> Helper loaded: url_helper
INFO - 2020-08-19 23:28:29 --> Helper loaded: form_helper
INFO - 2020-08-19 23:28:29 --> Helper loaded: file_helper
INFO - 2020-08-19 23:28:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 23:28:29 --> Database Driver Class Initialized
DEBUG - 2020-08-19 23:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 23:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 23:28:29 --> Upload Class Initialized
INFO - 2020-08-19 23:28:29 --> Controller Class Initialized
ERROR - 2020-08-19 23:28:29 --> 404 Page Not Found: /index
INFO - 2020-08-19 23:28:30 --> Config Class Initialized
INFO - 2020-08-19 23:28:30 --> Hooks Class Initialized
DEBUG - 2020-08-19 23:28:30 --> UTF-8 Support Enabled
INFO - 2020-08-19 23:28:30 --> Utf8 Class Initialized
INFO - 2020-08-19 23:28:30 --> URI Class Initialized
DEBUG - 2020-08-19 23:28:30 --> No URI present. Default controller set.
INFO - 2020-08-19 23:28:30 --> Router Class Initialized
INFO - 2020-08-19 23:28:30 --> Output Class Initialized
INFO - 2020-08-19 23:28:30 --> Security Class Initialized
DEBUG - 2020-08-19 23:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 23:28:30 --> Input Class Initialized
INFO - 2020-08-19 23:28:30 --> Language Class Initialized
INFO - 2020-08-19 23:28:30 --> Language Class Initialized
INFO - 2020-08-19 23:28:30 --> Config Class Initialized
INFO - 2020-08-19 23:28:30 --> Loader Class Initialized
INFO - 2020-08-19 23:28:30 --> Helper loaded: url_helper
INFO - 2020-08-19 23:28:30 --> Helper loaded: form_helper
INFO - 2020-08-19 23:28:30 --> Helper loaded: file_helper
INFO - 2020-08-19 23:28:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-19 23:28:30 --> Database Driver Class Initialized
DEBUG - 2020-08-19 23:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 23:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 23:28:30 --> Upload Class Initialized
INFO - 2020-08-19 23:28:30 --> Controller Class Initialized
DEBUG - 2020-08-19 23:28:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-19 23:28:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-19 23:28:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-19 23:28:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-19 23:28:30 --> Final output sent to browser
DEBUG - 2020-08-19 23:28:30 --> Total execution time: 0.0517
