<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-20 00:02:11 --> Config Class Initialized
INFO - 2020-08-20 00:02:11 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:02:11 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:02:11 --> Utf8 Class Initialized
INFO - 2020-08-20 00:02:11 --> URI Class Initialized
DEBUG - 2020-08-20 00:02:11 --> No URI present. Default controller set.
INFO - 2020-08-20 00:02:11 --> Router Class Initialized
INFO - 2020-08-20 00:02:11 --> Output Class Initialized
INFO - 2020-08-20 00:02:11 --> Security Class Initialized
DEBUG - 2020-08-20 00:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:02:11 --> Input Class Initialized
INFO - 2020-08-20 00:02:11 --> Language Class Initialized
INFO - 2020-08-20 00:02:11 --> Language Class Initialized
INFO - 2020-08-20 00:02:11 --> Config Class Initialized
INFO - 2020-08-20 00:02:11 --> Loader Class Initialized
INFO - 2020-08-20 00:02:11 --> Helper loaded: url_helper
INFO - 2020-08-20 00:02:11 --> Helper loaded: form_helper
INFO - 2020-08-20 00:02:11 --> Helper loaded: file_helper
INFO - 2020-08-20 00:02:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:02:11 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:02:11 --> Upload Class Initialized
INFO - 2020-08-20 00:02:11 --> Controller Class Initialized
DEBUG - 2020-08-20 00:02:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 00:02:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 00:02:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 00:02:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 00:02:11 --> Final output sent to browser
DEBUG - 2020-08-20 00:02:11 --> Total execution time: 0.0543
INFO - 2020-08-20 00:37:05 --> Config Class Initialized
INFO - 2020-08-20 00:37:05 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:37:05 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:37:05 --> Utf8 Class Initialized
INFO - 2020-08-20 00:37:05 --> URI Class Initialized
DEBUG - 2020-08-20 00:37:05 --> No URI present. Default controller set.
INFO - 2020-08-20 00:37:05 --> Router Class Initialized
INFO - 2020-08-20 00:37:05 --> Output Class Initialized
INFO - 2020-08-20 00:37:05 --> Security Class Initialized
DEBUG - 2020-08-20 00:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:37:05 --> Input Class Initialized
INFO - 2020-08-20 00:37:05 --> Language Class Initialized
INFO - 2020-08-20 00:37:05 --> Language Class Initialized
INFO - 2020-08-20 00:37:05 --> Config Class Initialized
INFO - 2020-08-20 00:37:05 --> Loader Class Initialized
INFO - 2020-08-20 00:37:05 --> Helper loaded: url_helper
INFO - 2020-08-20 00:37:05 --> Helper loaded: form_helper
INFO - 2020-08-20 00:37:05 --> Helper loaded: file_helper
INFO - 2020-08-20 00:37:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:37:05 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:37:05 --> Upload Class Initialized
INFO - 2020-08-20 00:37:05 --> Controller Class Initialized
DEBUG - 2020-08-20 00:37:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 00:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 00:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 00:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 00:37:05 --> Final output sent to browser
DEBUG - 2020-08-20 00:37:05 --> Total execution time: 0.0503
INFO - 2020-08-20 00:42:22 --> Config Class Initialized
INFO - 2020-08-20 00:42:22 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:42:22 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:42:22 --> Utf8 Class Initialized
INFO - 2020-08-20 00:42:22 --> URI Class Initialized
INFO - 2020-08-20 00:42:22 --> Router Class Initialized
INFO - 2020-08-20 00:42:22 --> Output Class Initialized
INFO - 2020-08-20 00:42:22 --> Security Class Initialized
DEBUG - 2020-08-20 00:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:42:22 --> Input Class Initialized
INFO - 2020-08-20 00:42:22 --> Language Class Initialized
INFO - 2020-08-20 00:42:22 --> Language Class Initialized
INFO - 2020-08-20 00:42:22 --> Config Class Initialized
INFO - 2020-08-20 00:42:22 --> Loader Class Initialized
INFO - 2020-08-20 00:42:22 --> Helper loaded: url_helper
INFO - 2020-08-20 00:42:22 --> Helper loaded: form_helper
INFO - 2020-08-20 00:42:22 --> Helper loaded: file_helper
INFO - 2020-08-20 00:42:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:42:22 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:42:22 --> Upload Class Initialized
INFO - 2020-08-20 00:42:22 --> Controller Class Initialized
ERROR - 2020-08-20 00:42:22 --> 404 Page Not Found: /index
INFO - 2020-08-20 00:42:22 --> Config Class Initialized
INFO - 2020-08-20 00:42:22 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:42:22 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:42:22 --> Utf8 Class Initialized
INFO - 2020-08-20 00:42:22 --> URI Class Initialized
INFO - 2020-08-20 00:42:22 --> Router Class Initialized
INFO - 2020-08-20 00:42:22 --> Output Class Initialized
INFO - 2020-08-20 00:42:22 --> Security Class Initialized
DEBUG - 2020-08-20 00:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:42:22 --> Input Class Initialized
INFO - 2020-08-20 00:42:22 --> Language Class Initialized
INFO - 2020-08-20 00:42:22 --> Language Class Initialized
INFO - 2020-08-20 00:42:22 --> Config Class Initialized
INFO - 2020-08-20 00:42:22 --> Loader Class Initialized
INFO - 2020-08-20 00:42:22 --> Helper loaded: url_helper
INFO - 2020-08-20 00:42:22 --> Helper loaded: form_helper
INFO - 2020-08-20 00:42:22 --> Helper loaded: file_helper
INFO - 2020-08-20 00:42:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:42:22 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:42:22 --> Upload Class Initialized
INFO - 2020-08-20 00:42:22 --> Controller Class Initialized
ERROR - 2020-08-20 00:42:22 --> 404 Page Not Found: /index
INFO - 2020-08-20 00:42:25 --> Config Class Initialized
INFO - 2020-08-20 00:42:25 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:42:25 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:42:25 --> Utf8 Class Initialized
INFO - 2020-08-20 00:42:25 --> URI Class Initialized
DEBUG - 2020-08-20 00:42:25 --> No URI present. Default controller set.
INFO - 2020-08-20 00:42:25 --> Router Class Initialized
INFO - 2020-08-20 00:42:25 --> Output Class Initialized
INFO - 2020-08-20 00:42:25 --> Security Class Initialized
DEBUG - 2020-08-20 00:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:42:25 --> Input Class Initialized
INFO - 2020-08-20 00:42:25 --> Language Class Initialized
INFO - 2020-08-20 00:42:25 --> Language Class Initialized
INFO - 2020-08-20 00:42:25 --> Config Class Initialized
INFO - 2020-08-20 00:42:25 --> Loader Class Initialized
INFO - 2020-08-20 00:42:25 --> Helper loaded: url_helper
INFO - 2020-08-20 00:42:25 --> Helper loaded: form_helper
INFO - 2020-08-20 00:42:25 --> Helper loaded: file_helper
INFO - 2020-08-20 00:42:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:42:25 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:42:25 --> Upload Class Initialized
INFO - 2020-08-20 00:42:25 --> Controller Class Initialized
DEBUG - 2020-08-20 00:42:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 00:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 00:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 00:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 00:42:25 --> Final output sent to browser
DEBUG - 2020-08-20 00:42:25 --> Total execution time: 0.0593
INFO - 2020-08-20 00:42:26 --> Config Class Initialized
INFO - 2020-08-20 00:42:26 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:42:26 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:42:26 --> Utf8 Class Initialized
INFO - 2020-08-20 00:42:26 --> URI Class Initialized
DEBUG - 2020-08-20 00:42:26 --> No URI present. Default controller set.
INFO - 2020-08-20 00:42:26 --> Router Class Initialized
INFO - 2020-08-20 00:42:26 --> Output Class Initialized
INFO - 2020-08-20 00:42:26 --> Security Class Initialized
DEBUG - 2020-08-20 00:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:42:26 --> Input Class Initialized
INFO - 2020-08-20 00:42:26 --> Language Class Initialized
INFO - 2020-08-20 00:42:26 --> Language Class Initialized
INFO - 2020-08-20 00:42:26 --> Config Class Initialized
INFO - 2020-08-20 00:42:26 --> Loader Class Initialized
INFO - 2020-08-20 00:42:26 --> Helper loaded: url_helper
INFO - 2020-08-20 00:42:26 --> Helper loaded: form_helper
INFO - 2020-08-20 00:42:26 --> Helper loaded: file_helper
INFO - 2020-08-20 00:42:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:42:26 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:42:26 --> Upload Class Initialized
INFO - 2020-08-20 00:42:26 --> Controller Class Initialized
DEBUG - 2020-08-20 00:42:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 00:42:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 00:42:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 00:42:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 00:42:26 --> Final output sent to browser
DEBUG - 2020-08-20 00:42:26 --> Total execution time: 0.0522
INFO - 2020-08-20 00:42:30 --> Config Class Initialized
INFO - 2020-08-20 00:42:30 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:42:30 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:42:30 --> Utf8 Class Initialized
INFO - 2020-08-20 00:42:30 --> URI Class Initialized
DEBUG - 2020-08-20 00:42:30 --> No URI present. Default controller set.
INFO - 2020-08-20 00:42:30 --> Router Class Initialized
INFO - 2020-08-20 00:42:30 --> Output Class Initialized
INFO - 2020-08-20 00:42:30 --> Security Class Initialized
DEBUG - 2020-08-20 00:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:42:30 --> Input Class Initialized
INFO - 2020-08-20 00:42:30 --> Language Class Initialized
INFO - 2020-08-20 00:42:30 --> Language Class Initialized
INFO - 2020-08-20 00:42:30 --> Config Class Initialized
INFO - 2020-08-20 00:42:30 --> Loader Class Initialized
INFO - 2020-08-20 00:42:30 --> Helper loaded: url_helper
INFO - 2020-08-20 00:42:30 --> Helper loaded: form_helper
INFO - 2020-08-20 00:42:30 --> Helper loaded: file_helper
INFO - 2020-08-20 00:42:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:42:30 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:42:30 --> Upload Class Initialized
INFO - 2020-08-20 00:42:30 --> Controller Class Initialized
DEBUG - 2020-08-20 00:42:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 00:42:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 00:42:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 00:42:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 00:42:30 --> Final output sent to browser
DEBUG - 2020-08-20 00:42:30 --> Total execution time: 0.0503
INFO - 2020-08-20 00:42:30 --> Config Class Initialized
INFO - 2020-08-20 00:42:30 --> Hooks Class Initialized
DEBUG - 2020-08-20 00:42:30 --> UTF-8 Support Enabled
INFO - 2020-08-20 00:42:30 --> Utf8 Class Initialized
INFO - 2020-08-20 00:42:30 --> URI Class Initialized
DEBUG - 2020-08-20 00:42:30 --> No URI present. Default controller set.
INFO - 2020-08-20 00:42:30 --> Router Class Initialized
INFO - 2020-08-20 00:42:30 --> Output Class Initialized
INFO - 2020-08-20 00:42:30 --> Security Class Initialized
DEBUG - 2020-08-20 00:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 00:42:30 --> Input Class Initialized
INFO - 2020-08-20 00:42:30 --> Language Class Initialized
INFO - 2020-08-20 00:42:30 --> Language Class Initialized
INFO - 2020-08-20 00:42:30 --> Config Class Initialized
INFO - 2020-08-20 00:42:30 --> Loader Class Initialized
INFO - 2020-08-20 00:42:30 --> Helper loaded: url_helper
INFO - 2020-08-20 00:42:30 --> Helper loaded: form_helper
INFO - 2020-08-20 00:42:30 --> Helper loaded: file_helper
INFO - 2020-08-20 00:42:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 00:42:30 --> Database Driver Class Initialized
DEBUG - 2020-08-20 00:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 00:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 00:42:30 --> Upload Class Initialized
INFO - 2020-08-20 00:42:30 --> Controller Class Initialized
DEBUG - 2020-08-20 00:42:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 00:42:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 00:42:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 00:42:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 00:42:30 --> Final output sent to browser
DEBUG - 2020-08-20 00:42:30 --> Total execution time: 0.0510
INFO - 2020-08-20 02:18:11 --> Config Class Initialized
INFO - 2020-08-20 02:18:11 --> Hooks Class Initialized
DEBUG - 2020-08-20 02:18:11 --> UTF-8 Support Enabled
INFO - 2020-08-20 02:18:11 --> Utf8 Class Initialized
INFO - 2020-08-20 02:18:11 --> URI Class Initialized
DEBUG - 2020-08-20 02:18:11 --> No URI present. Default controller set.
INFO - 2020-08-20 02:18:11 --> Router Class Initialized
INFO - 2020-08-20 02:18:11 --> Output Class Initialized
INFO - 2020-08-20 02:18:11 --> Security Class Initialized
DEBUG - 2020-08-20 02:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 02:18:11 --> Input Class Initialized
INFO - 2020-08-20 02:18:11 --> Language Class Initialized
INFO - 2020-08-20 02:18:11 --> Language Class Initialized
INFO - 2020-08-20 02:18:11 --> Config Class Initialized
INFO - 2020-08-20 02:18:11 --> Loader Class Initialized
INFO - 2020-08-20 02:18:11 --> Helper loaded: url_helper
INFO - 2020-08-20 02:18:11 --> Helper loaded: form_helper
INFO - 2020-08-20 02:18:11 --> Helper loaded: file_helper
INFO - 2020-08-20 02:18:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 02:18:11 --> Database Driver Class Initialized
DEBUG - 2020-08-20 02:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 02:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 02:18:11 --> Upload Class Initialized
INFO - 2020-08-20 02:18:11 --> Controller Class Initialized
DEBUG - 2020-08-20 02:18:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 02:18:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 02:18:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 02:18:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 02:18:11 --> Final output sent to browser
DEBUG - 2020-08-20 02:18:11 --> Total execution time: 0.0522
INFO - 2020-08-20 05:53:44 --> Config Class Initialized
INFO - 2020-08-20 05:53:44 --> Hooks Class Initialized
DEBUG - 2020-08-20 05:53:44 --> UTF-8 Support Enabled
INFO - 2020-08-20 05:53:44 --> Utf8 Class Initialized
INFO - 2020-08-20 05:53:44 --> URI Class Initialized
DEBUG - 2020-08-20 05:53:44 --> No URI present. Default controller set.
INFO - 2020-08-20 05:53:44 --> Router Class Initialized
INFO - 2020-08-20 05:53:44 --> Output Class Initialized
INFO - 2020-08-20 05:53:44 --> Security Class Initialized
DEBUG - 2020-08-20 05:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 05:53:44 --> Input Class Initialized
INFO - 2020-08-20 05:53:44 --> Language Class Initialized
INFO - 2020-08-20 05:53:44 --> Language Class Initialized
INFO - 2020-08-20 05:53:44 --> Config Class Initialized
INFO - 2020-08-20 05:53:44 --> Loader Class Initialized
INFO - 2020-08-20 05:53:44 --> Helper loaded: url_helper
INFO - 2020-08-20 05:53:44 --> Helper loaded: form_helper
INFO - 2020-08-20 05:53:44 --> Helper loaded: file_helper
INFO - 2020-08-20 05:53:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 05:53:44 --> Database Driver Class Initialized
DEBUG - 2020-08-20 05:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 05:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 05:53:44 --> Upload Class Initialized
INFO - 2020-08-20 05:53:44 --> Controller Class Initialized
DEBUG - 2020-08-20 05:53:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 05:53:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 05:53:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 05:53:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 05:53:44 --> Final output sent to browser
DEBUG - 2020-08-20 05:53:44 --> Total execution time: 0.0502
INFO - 2020-08-20 07:12:55 --> Config Class Initialized
INFO - 2020-08-20 07:12:55 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:12:55 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:12:55 --> Utf8 Class Initialized
INFO - 2020-08-20 07:12:55 --> URI Class Initialized
DEBUG - 2020-08-20 07:12:55 --> No URI present. Default controller set.
INFO - 2020-08-20 07:12:55 --> Router Class Initialized
INFO - 2020-08-20 07:12:55 --> Output Class Initialized
INFO - 2020-08-20 07:12:55 --> Security Class Initialized
DEBUG - 2020-08-20 07:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:12:55 --> Input Class Initialized
INFO - 2020-08-20 07:12:55 --> Language Class Initialized
INFO - 2020-08-20 07:12:55 --> Language Class Initialized
INFO - 2020-08-20 07:12:55 --> Config Class Initialized
INFO - 2020-08-20 07:12:55 --> Loader Class Initialized
INFO - 2020-08-20 07:12:55 --> Helper loaded: url_helper
INFO - 2020-08-20 07:12:55 --> Helper loaded: form_helper
INFO - 2020-08-20 07:12:55 --> Helper loaded: file_helper
INFO - 2020-08-20 07:12:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:12:55 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:12:55 --> Upload Class Initialized
INFO - 2020-08-20 07:12:55 --> Controller Class Initialized
DEBUG - 2020-08-20 07:12:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:12:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:12:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:12:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:12:55 --> Final output sent to browser
DEBUG - 2020-08-20 07:12:55 --> Total execution time: 0.0497
INFO - 2020-08-20 07:18:36 --> Config Class Initialized
INFO - 2020-08-20 07:18:36 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:18:36 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:18:36 --> Utf8 Class Initialized
INFO - 2020-08-20 07:18:36 --> URI Class Initialized
DEBUG - 2020-08-20 07:18:36 --> No URI present. Default controller set.
INFO - 2020-08-20 07:18:36 --> Router Class Initialized
INFO - 2020-08-20 07:18:36 --> Output Class Initialized
INFO - 2020-08-20 07:18:36 --> Security Class Initialized
DEBUG - 2020-08-20 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:18:36 --> Input Class Initialized
INFO - 2020-08-20 07:18:36 --> Language Class Initialized
INFO - 2020-08-20 07:18:36 --> Language Class Initialized
INFO - 2020-08-20 07:18:36 --> Config Class Initialized
INFO - 2020-08-20 07:18:36 --> Loader Class Initialized
INFO - 2020-08-20 07:18:36 --> Helper loaded: url_helper
INFO - 2020-08-20 07:18:36 --> Helper loaded: form_helper
INFO - 2020-08-20 07:18:36 --> Helper loaded: file_helper
INFO - 2020-08-20 07:18:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:18:36 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:18:36 --> Upload Class Initialized
INFO - 2020-08-20 07:18:36 --> Controller Class Initialized
DEBUG - 2020-08-20 07:18:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:18:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:18:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:18:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:18:36 --> Final output sent to browser
DEBUG - 2020-08-20 07:18:36 --> Total execution time: 0.0508
INFO - 2020-08-20 07:18:36 --> Config Class Initialized
INFO - 2020-08-20 07:18:36 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:18:36 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:18:36 --> Utf8 Class Initialized
INFO - 2020-08-20 07:18:36 --> URI Class Initialized
DEBUG - 2020-08-20 07:18:36 --> No URI present. Default controller set.
INFO - 2020-08-20 07:18:36 --> Router Class Initialized
INFO - 2020-08-20 07:18:36 --> Output Class Initialized
INFO - 2020-08-20 07:18:36 --> Security Class Initialized
DEBUG - 2020-08-20 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:18:36 --> Input Class Initialized
INFO - 2020-08-20 07:18:36 --> Language Class Initialized
INFO - 2020-08-20 07:18:36 --> Language Class Initialized
INFO - 2020-08-20 07:18:36 --> Config Class Initialized
INFO - 2020-08-20 07:18:36 --> Loader Class Initialized
INFO - 2020-08-20 07:18:36 --> Helper loaded: url_helper
INFO - 2020-08-20 07:18:36 --> Helper loaded: form_helper
INFO - 2020-08-20 07:18:36 --> Helper loaded: file_helper
INFO - 2020-08-20 07:18:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:18:36 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:18:36 --> Upload Class Initialized
INFO - 2020-08-20 07:18:36 --> Controller Class Initialized
DEBUG - 2020-08-20 07:18:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:18:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:18:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:18:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:18:36 --> Final output sent to browser
DEBUG - 2020-08-20 07:18:36 --> Total execution time: 0.0502
INFO - 2020-08-20 07:50:36 --> Config Class Initialized
INFO - 2020-08-20 07:50:36 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:50:36 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:50:36 --> Utf8 Class Initialized
INFO - 2020-08-20 07:50:36 --> URI Class Initialized
DEBUG - 2020-08-20 07:50:36 --> No URI present. Default controller set.
INFO - 2020-08-20 07:50:36 --> Router Class Initialized
INFO - 2020-08-20 07:50:36 --> Output Class Initialized
INFO - 2020-08-20 07:50:36 --> Security Class Initialized
DEBUG - 2020-08-20 07:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:50:36 --> Input Class Initialized
INFO - 2020-08-20 07:50:36 --> Language Class Initialized
INFO - 2020-08-20 07:50:36 --> Language Class Initialized
INFO - 2020-08-20 07:50:36 --> Config Class Initialized
INFO - 2020-08-20 07:50:36 --> Loader Class Initialized
INFO - 2020-08-20 07:50:36 --> Helper loaded: url_helper
INFO - 2020-08-20 07:50:36 --> Helper loaded: form_helper
INFO - 2020-08-20 07:50:36 --> Helper loaded: file_helper
INFO - 2020-08-20 07:50:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:50:36 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:50:36 --> Upload Class Initialized
INFO - 2020-08-20 07:50:36 --> Controller Class Initialized
DEBUG - 2020-08-20 07:50:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:50:36 --> Final output sent to browser
DEBUG - 2020-08-20 07:50:36 --> Total execution time: 0.0506
INFO - 2020-08-20 07:50:43 --> Config Class Initialized
INFO - 2020-08-20 07:50:43 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:50:43 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:50:43 --> Utf8 Class Initialized
INFO - 2020-08-20 07:50:43 --> URI Class Initialized
INFO - 2020-08-20 07:50:43 --> Router Class Initialized
INFO - 2020-08-20 07:50:43 --> Output Class Initialized
INFO - 2020-08-20 07:50:43 --> Security Class Initialized
DEBUG - 2020-08-20 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:50:43 --> Input Class Initialized
INFO - 2020-08-20 07:50:43 --> Language Class Initialized
INFO - 2020-08-20 07:50:43 --> Language Class Initialized
INFO - 2020-08-20 07:50:43 --> Config Class Initialized
INFO - 2020-08-20 07:50:43 --> Loader Class Initialized
INFO - 2020-08-20 07:50:43 --> Helper loaded: url_helper
INFO - 2020-08-20 07:50:43 --> Helper loaded: form_helper
INFO - 2020-08-20 07:50:43 --> Helper loaded: file_helper
INFO - 2020-08-20 07:50:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:50:43 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:50:43 --> Upload Class Initialized
INFO - 2020-08-20 07:50:43 --> Controller Class Initialized
ERROR - 2020-08-20 07:50:43 --> 404 Page Not Found: /index
INFO - 2020-08-20 07:50:51 --> Config Class Initialized
INFO - 2020-08-20 07:50:51 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:50:51 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:50:51 --> Utf8 Class Initialized
INFO - 2020-08-20 07:50:51 --> URI Class Initialized
DEBUG - 2020-08-20 07:50:51 --> No URI present. Default controller set.
INFO - 2020-08-20 07:50:51 --> Router Class Initialized
INFO - 2020-08-20 07:50:51 --> Output Class Initialized
INFO - 2020-08-20 07:50:51 --> Security Class Initialized
DEBUG - 2020-08-20 07:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:50:51 --> Input Class Initialized
INFO - 2020-08-20 07:50:51 --> Language Class Initialized
INFO - 2020-08-20 07:50:51 --> Language Class Initialized
INFO - 2020-08-20 07:50:51 --> Config Class Initialized
INFO - 2020-08-20 07:50:51 --> Loader Class Initialized
INFO - 2020-08-20 07:50:51 --> Helper loaded: url_helper
INFO - 2020-08-20 07:50:51 --> Helper loaded: form_helper
INFO - 2020-08-20 07:50:51 --> Helper loaded: file_helper
INFO - 2020-08-20 07:50:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:50:51 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:50:51 --> Upload Class Initialized
INFO - 2020-08-20 07:50:51 --> Controller Class Initialized
DEBUG - 2020-08-20 07:50:51 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:50:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:50:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:50:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:50:51 --> Final output sent to browser
DEBUG - 2020-08-20 07:50:51 --> Total execution time: 0.0499
INFO - 2020-08-20 07:51:22 --> Config Class Initialized
INFO - 2020-08-20 07:51:22 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:51:22 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:51:22 --> Utf8 Class Initialized
INFO - 2020-08-20 07:51:22 --> URI Class Initialized
DEBUG - 2020-08-20 07:51:22 --> No URI present. Default controller set.
INFO - 2020-08-20 07:51:22 --> Router Class Initialized
INFO - 2020-08-20 07:51:22 --> Output Class Initialized
INFO - 2020-08-20 07:51:22 --> Security Class Initialized
DEBUG - 2020-08-20 07:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:51:22 --> Input Class Initialized
INFO - 2020-08-20 07:51:22 --> Language Class Initialized
INFO - 2020-08-20 07:51:22 --> Language Class Initialized
INFO - 2020-08-20 07:51:22 --> Config Class Initialized
INFO - 2020-08-20 07:51:22 --> Loader Class Initialized
INFO - 2020-08-20 07:51:22 --> Helper loaded: url_helper
INFO - 2020-08-20 07:51:22 --> Helper loaded: form_helper
INFO - 2020-08-20 07:51:22 --> Helper loaded: file_helper
INFO - 2020-08-20 07:51:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:51:22 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:51:22 --> Upload Class Initialized
INFO - 2020-08-20 07:51:22 --> Controller Class Initialized
DEBUG - 2020-08-20 07:51:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:51:22 --> Final output sent to browser
DEBUG - 2020-08-20 07:51:22 --> Total execution time: 0.0490
INFO - 2020-08-20 07:51:54 --> Config Class Initialized
INFO - 2020-08-20 07:51:54 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:51:54 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:51:54 --> Utf8 Class Initialized
INFO - 2020-08-20 07:51:54 --> URI Class Initialized
INFO - 2020-08-20 07:51:54 --> Router Class Initialized
INFO - 2020-08-20 07:51:54 --> Output Class Initialized
INFO - 2020-08-20 07:51:54 --> Security Class Initialized
DEBUG - 2020-08-20 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:51:54 --> Input Class Initialized
INFO - 2020-08-20 07:51:54 --> Language Class Initialized
INFO - 2020-08-20 07:51:54 --> Language Class Initialized
INFO - 2020-08-20 07:51:54 --> Config Class Initialized
INFO - 2020-08-20 07:51:54 --> Loader Class Initialized
INFO - 2020-08-20 07:51:54 --> Helper loaded: url_helper
INFO - 2020-08-20 07:51:54 --> Helper loaded: form_helper
INFO - 2020-08-20 07:51:54 --> Helper loaded: file_helper
INFO - 2020-08-20 07:51:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:51:54 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:51:54 --> Upload Class Initialized
INFO - 2020-08-20 07:51:54 --> Controller Class Initialized
ERROR - 2020-08-20 07:51:54 --> 404 Page Not Found: /index
INFO - 2020-08-20 07:51:55 --> Config Class Initialized
INFO - 2020-08-20 07:51:55 --> Hooks Class Initialized
DEBUG - 2020-08-20 07:51:55 --> UTF-8 Support Enabled
INFO - 2020-08-20 07:51:55 --> Utf8 Class Initialized
INFO - 2020-08-20 07:51:55 --> URI Class Initialized
DEBUG - 2020-08-20 07:51:55 --> No URI present. Default controller set.
INFO - 2020-08-20 07:51:55 --> Router Class Initialized
INFO - 2020-08-20 07:51:55 --> Output Class Initialized
INFO - 2020-08-20 07:51:55 --> Security Class Initialized
DEBUG - 2020-08-20 07:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 07:51:55 --> Input Class Initialized
INFO - 2020-08-20 07:51:55 --> Language Class Initialized
INFO - 2020-08-20 07:51:55 --> Language Class Initialized
INFO - 2020-08-20 07:51:55 --> Config Class Initialized
INFO - 2020-08-20 07:51:55 --> Loader Class Initialized
INFO - 2020-08-20 07:51:55 --> Helper loaded: url_helper
INFO - 2020-08-20 07:51:55 --> Helper loaded: form_helper
INFO - 2020-08-20 07:51:55 --> Helper loaded: file_helper
INFO - 2020-08-20 07:51:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 07:51:55 --> Database Driver Class Initialized
DEBUG - 2020-08-20 07:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 07:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 07:51:55 --> Upload Class Initialized
INFO - 2020-08-20 07:51:55 --> Controller Class Initialized
DEBUG - 2020-08-20 07:51:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 07:51:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 07:51:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 07:51:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 07:51:55 --> Final output sent to browser
DEBUG - 2020-08-20 07:51:55 --> Total execution time: 0.0495
INFO - 2020-08-20 08:34:36 --> Config Class Initialized
INFO - 2020-08-20 08:34:36 --> Hooks Class Initialized
DEBUG - 2020-08-20 08:34:36 --> UTF-8 Support Enabled
INFO - 2020-08-20 08:34:36 --> Utf8 Class Initialized
INFO - 2020-08-20 08:34:36 --> URI Class Initialized
INFO - 2020-08-20 08:34:36 --> Router Class Initialized
INFO - 2020-08-20 08:34:36 --> Output Class Initialized
INFO - 2020-08-20 08:34:36 --> Security Class Initialized
DEBUG - 2020-08-20 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 08:34:36 --> Input Class Initialized
INFO - 2020-08-20 08:34:36 --> Language Class Initialized
INFO - 2020-08-20 08:34:36 --> Language Class Initialized
INFO - 2020-08-20 08:34:36 --> Config Class Initialized
INFO - 2020-08-20 08:34:36 --> Loader Class Initialized
INFO - 2020-08-20 08:34:36 --> Helper loaded: url_helper
INFO - 2020-08-20 08:34:36 --> Helper loaded: form_helper
INFO - 2020-08-20 08:34:36 --> Helper loaded: file_helper
INFO - 2020-08-20 08:34:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 08:34:36 --> Database Driver Class Initialized
DEBUG - 2020-08-20 08:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 08:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 08:34:36 --> Upload Class Initialized
INFO - 2020-08-20 08:34:36 --> Controller Class Initialized
ERROR - 2020-08-20 08:34:36 --> 404 Page Not Found: /index
INFO - 2020-08-20 08:34:36 --> Config Class Initialized
INFO - 2020-08-20 08:34:36 --> Hooks Class Initialized
DEBUG - 2020-08-20 08:34:36 --> UTF-8 Support Enabled
INFO - 2020-08-20 08:34:36 --> Utf8 Class Initialized
INFO - 2020-08-20 08:34:36 --> URI Class Initialized
DEBUG - 2020-08-20 08:34:36 --> No URI present. Default controller set.
INFO - 2020-08-20 08:34:36 --> Router Class Initialized
INFO - 2020-08-20 08:34:36 --> Output Class Initialized
INFO - 2020-08-20 08:34:36 --> Security Class Initialized
DEBUG - 2020-08-20 08:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 08:34:36 --> Input Class Initialized
INFO - 2020-08-20 08:34:36 --> Language Class Initialized
INFO - 2020-08-20 08:34:36 --> Language Class Initialized
INFO - 2020-08-20 08:34:36 --> Config Class Initialized
INFO - 2020-08-20 08:34:36 --> Loader Class Initialized
INFO - 2020-08-20 08:34:36 --> Helper loaded: url_helper
INFO - 2020-08-20 08:34:36 --> Helper loaded: form_helper
INFO - 2020-08-20 08:34:36 --> Helper loaded: file_helper
INFO - 2020-08-20 08:34:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 08:34:36 --> Database Driver Class Initialized
DEBUG - 2020-08-20 08:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 08:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 08:34:36 --> Upload Class Initialized
INFO - 2020-08-20 08:34:36 --> Controller Class Initialized
DEBUG - 2020-08-20 08:34:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 08:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 08:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 08:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 08:34:36 --> Final output sent to browser
DEBUG - 2020-08-20 08:34:36 --> Total execution time: 0.0522
INFO - 2020-08-20 09:42:55 --> Config Class Initialized
INFO - 2020-08-20 09:42:55 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:42:55 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:42:55 --> Utf8 Class Initialized
INFO - 2020-08-20 09:42:55 --> URI Class Initialized
DEBUG - 2020-08-20 09:42:55 --> No URI present. Default controller set.
INFO - 2020-08-20 09:42:55 --> Router Class Initialized
INFO - 2020-08-20 09:42:55 --> Output Class Initialized
INFO - 2020-08-20 09:42:55 --> Security Class Initialized
DEBUG - 2020-08-20 09:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:42:55 --> Input Class Initialized
INFO - 2020-08-20 09:42:55 --> Language Class Initialized
INFO - 2020-08-20 09:42:55 --> Language Class Initialized
INFO - 2020-08-20 09:42:55 --> Config Class Initialized
INFO - 2020-08-20 09:42:55 --> Loader Class Initialized
INFO - 2020-08-20 09:42:55 --> Helper loaded: url_helper
INFO - 2020-08-20 09:42:55 --> Helper loaded: form_helper
INFO - 2020-08-20 09:42:55 --> Helper loaded: file_helper
INFO - 2020-08-20 09:42:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:42:55 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:42:55 --> Upload Class Initialized
INFO - 2020-08-20 09:42:55 --> Controller Class Initialized
DEBUG - 2020-08-20 09:42:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 09:42:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 09:42:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 09:42:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 09:42:55 --> Final output sent to browser
DEBUG - 2020-08-20 09:42:55 --> Total execution time: 0.1954
INFO - 2020-08-20 09:43:03 --> Config Class Initialized
INFO - 2020-08-20 09:43:03 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:43:03 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:43:03 --> Utf8 Class Initialized
INFO - 2020-08-20 09:43:03 --> URI Class Initialized
INFO - 2020-08-20 09:43:03 --> Router Class Initialized
INFO - 2020-08-20 09:43:03 --> Output Class Initialized
INFO - 2020-08-20 09:43:03 --> Security Class Initialized
DEBUG - 2020-08-20 09:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:43:03 --> Input Class Initialized
INFO - 2020-08-20 09:43:03 --> Language Class Initialized
INFO - 2020-08-20 09:43:03 --> Language Class Initialized
INFO - 2020-08-20 09:43:03 --> Config Class Initialized
INFO - 2020-08-20 09:43:03 --> Loader Class Initialized
INFO - 2020-08-20 09:43:03 --> Helper loaded: url_helper
INFO - 2020-08-20 09:43:03 --> Helper loaded: form_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: file_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:43:04 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:43:04 --> Upload Class Initialized
INFO - 2020-08-20 09:43:04 --> Controller Class Initialized
ERROR - 2020-08-20 09:43:04 --> 404 Page Not Found: /index
INFO - 2020-08-20 09:43:04 --> Config Class Initialized
INFO - 2020-08-20 09:43:04 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:43:04 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:43:04 --> Utf8 Class Initialized
INFO - 2020-08-20 09:43:04 --> URI Class Initialized
INFO - 2020-08-20 09:43:04 --> Router Class Initialized
INFO - 2020-08-20 09:43:04 --> Output Class Initialized
INFO - 2020-08-20 09:43:04 --> Security Class Initialized
DEBUG - 2020-08-20 09:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:43:04 --> Input Class Initialized
INFO - 2020-08-20 09:43:04 --> Language Class Initialized
INFO - 2020-08-20 09:43:04 --> Language Class Initialized
INFO - 2020-08-20 09:43:04 --> Config Class Initialized
INFO - 2020-08-20 09:43:04 --> Loader Class Initialized
INFO - 2020-08-20 09:43:04 --> Helper loaded: url_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: form_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: file_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:43:04 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:43:04 --> Upload Class Initialized
INFO - 2020-08-20 09:43:04 --> Controller Class Initialized
ERROR - 2020-08-20 09:43:04 --> 404 Page Not Found: /index
INFO - 2020-08-20 09:43:04 --> Config Class Initialized
INFO - 2020-08-20 09:43:04 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:43:04 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:43:04 --> Utf8 Class Initialized
INFO - 2020-08-20 09:43:04 --> URI Class Initialized
INFO - 2020-08-20 09:43:04 --> Router Class Initialized
INFO - 2020-08-20 09:43:04 --> Output Class Initialized
INFO - 2020-08-20 09:43:04 --> Security Class Initialized
DEBUG - 2020-08-20 09:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:43:04 --> Input Class Initialized
INFO - 2020-08-20 09:43:04 --> Language Class Initialized
INFO - 2020-08-20 09:43:04 --> Language Class Initialized
INFO - 2020-08-20 09:43:04 --> Config Class Initialized
INFO - 2020-08-20 09:43:04 --> Loader Class Initialized
INFO - 2020-08-20 09:43:04 --> Helper loaded: url_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: form_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: file_helper
INFO - 2020-08-20 09:43:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:43:04 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:43:04 --> Upload Class Initialized
INFO - 2020-08-20 09:43:04 --> Controller Class Initialized
ERROR - 2020-08-20 09:43:04 --> 404 Page Not Found: /index
INFO - 2020-08-20 09:43:06 --> Config Class Initialized
INFO - 2020-08-20 09:43:06 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:43:06 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:43:06 --> Utf8 Class Initialized
INFO - 2020-08-20 09:43:06 --> URI Class Initialized
INFO - 2020-08-20 09:43:06 --> Router Class Initialized
INFO - 2020-08-20 09:43:06 --> Output Class Initialized
INFO - 2020-08-20 09:43:06 --> Security Class Initialized
DEBUG - 2020-08-20 09:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:43:06 --> Input Class Initialized
INFO - 2020-08-20 09:43:06 --> Language Class Initialized
INFO - 2020-08-20 09:43:06 --> Language Class Initialized
INFO - 2020-08-20 09:43:06 --> Config Class Initialized
INFO - 2020-08-20 09:43:06 --> Loader Class Initialized
INFO - 2020-08-20 09:43:06 --> Helper loaded: url_helper
INFO - 2020-08-20 09:43:06 --> Helper loaded: form_helper
INFO - 2020-08-20 09:43:06 --> Helper loaded: file_helper
INFO - 2020-08-20 09:43:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:43:06 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:43:06 --> Upload Class Initialized
INFO - 2020-08-20 09:43:06 --> Controller Class Initialized
ERROR - 2020-08-20 09:43:06 --> 404 Page Not Found: /index
INFO - 2020-08-20 09:56:27 --> Config Class Initialized
INFO - 2020-08-20 09:56:27 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:56:27 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:56:27 --> Utf8 Class Initialized
INFO - 2020-08-20 09:56:27 --> URI Class Initialized
DEBUG - 2020-08-20 09:56:27 --> No URI present. Default controller set.
INFO - 2020-08-20 09:56:27 --> Router Class Initialized
INFO - 2020-08-20 09:56:27 --> Output Class Initialized
INFO - 2020-08-20 09:56:27 --> Security Class Initialized
DEBUG - 2020-08-20 09:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:56:27 --> Input Class Initialized
INFO - 2020-08-20 09:56:27 --> Language Class Initialized
INFO - 2020-08-20 09:56:27 --> Language Class Initialized
INFO - 2020-08-20 09:56:27 --> Config Class Initialized
INFO - 2020-08-20 09:56:27 --> Loader Class Initialized
INFO - 2020-08-20 09:56:27 --> Helper loaded: url_helper
INFO - 2020-08-20 09:56:27 --> Helper loaded: form_helper
INFO - 2020-08-20 09:56:27 --> Helper loaded: file_helper
INFO - 2020-08-20 09:56:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:56:27 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:56:27 --> Upload Class Initialized
INFO - 2020-08-20 09:56:27 --> Controller Class Initialized
DEBUG - 2020-08-20 09:56:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 09:56:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 09:56:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 09:56:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 09:56:27 --> Final output sent to browser
DEBUG - 2020-08-20 09:56:27 --> Total execution time: 0.0506
INFO - 2020-08-20 09:56:52 --> Config Class Initialized
INFO - 2020-08-20 09:56:52 --> Hooks Class Initialized
DEBUG - 2020-08-20 09:56:52 --> UTF-8 Support Enabled
INFO - 2020-08-20 09:56:52 --> Utf8 Class Initialized
INFO - 2020-08-20 09:56:52 --> URI Class Initialized
INFO - 2020-08-20 09:56:52 --> Router Class Initialized
INFO - 2020-08-20 09:56:52 --> Output Class Initialized
INFO - 2020-08-20 09:56:52 --> Security Class Initialized
DEBUG - 2020-08-20 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 09:56:52 --> Input Class Initialized
INFO - 2020-08-20 09:56:52 --> Language Class Initialized
INFO - 2020-08-20 09:56:52 --> Language Class Initialized
INFO - 2020-08-20 09:56:52 --> Config Class Initialized
INFO - 2020-08-20 09:56:52 --> Loader Class Initialized
INFO - 2020-08-20 09:56:52 --> Helper loaded: url_helper
INFO - 2020-08-20 09:56:52 --> Helper loaded: form_helper
INFO - 2020-08-20 09:56:52 --> Helper loaded: file_helper
INFO - 2020-08-20 09:56:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 09:56:52 --> Database Driver Class Initialized
DEBUG - 2020-08-20 09:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 09:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 09:56:52 --> Upload Class Initialized
INFO - 2020-08-20 09:56:52 --> Controller Class Initialized
ERROR - 2020-08-20 09:56:52 --> 404 Page Not Found: /index
INFO - 2020-08-20 10:32:25 --> Config Class Initialized
INFO - 2020-08-20 10:32:25 --> Hooks Class Initialized
DEBUG - 2020-08-20 10:32:25 --> UTF-8 Support Enabled
INFO - 2020-08-20 10:32:25 --> Utf8 Class Initialized
INFO - 2020-08-20 10:32:25 --> URI Class Initialized
DEBUG - 2020-08-20 10:32:25 --> No URI present. Default controller set.
INFO - 2020-08-20 10:32:25 --> Router Class Initialized
INFO - 2020-08-20 10:32:25 --> Output Class Initialized
INFO - 2020-08-20 10:32:25 --> Security Class Initialized
DEBUG - 2020-08-20 10:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 10:32:25 --> Input Class Initialized
INFO - 2020-08-20 10:32:25 --> Language Class Initialized
INFO - 2020-08-20 10:32:25 --> Language Class Initialized
INFO - 2020-08-20 10:32:25 --> Config Class Initialized
INFO - 2020-08-20 10:32:25 --> Loader Class Initialized
INFO - 2020-08-20 10:32:25 --> Helper loaded: url_helper
INFO - 2020-08-20 10:32:25 --> Helper loaded: form_helper
INFO - 2020-08-20 10:32:25 --> Helper loaded: file_helper
INFO - 2020-08-20 10:32:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 10:32:25 --> Database Driver Class Initialized
DEBUG - 2020-08-20 10:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 10:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 10:32:25 --> Upload Class Initialized
INFO - 2020-08-20 10:32:25 --> Controller Class Initialized
DEBUG - 2020-08-20 10:32:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 10:32:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 10:32:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 10:32:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 10:32:25 --> Final output sent to browser
DEBUG - 2020-08-20 10:32:25 --> Total execution time: 0.0728
INFO - 2020-08-20 10:32:32 --> Config Class Initialized
INFO - 2020-08-20 10:32:32 --> Hooks Class Initialized
DEBUG - 2020-08-20 10:32:32 --> UTF-8 Support Enabled
INFO - 2020-08-20 10:32:32 --> Utf8 Class Initialized
INFO - 2020-08-20 10:32:32 --> URI Class Initialized
INFO - 2020-08-20 10:32:32 --> Router Class Initialized
INFO - 2020-08-20 10:32:32 --> Output Class Initialized
INFO - 2020-08-20 10:32:32 --> Security Class Initialized
DEBUG - 2020-08-20 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 10:32:32 --> Input Class Initialized
INFO - 2020-08-20 10:32:32 --> Language Class Initialized
INFO - 2020-08-20 10:32:32 --> Language Class Initialized
INFO - 2020-08-20 10:32:32 --> Config Class Initialized
INFO - 2020-08-20 10:32:32 --> Loader Class Initialized
INFO - 2020-08-20 10:32:32 --> Helper loaded: url_helper
INFO - 2020-08-20 10:32:32 --> Helper loaded: form_helper
INFO - 2020-08-20 10:32:32 --> Helper loaded: file_helper
INFO - 2020-08-20 10:32:32 --> Config Class Initialized
INFO - 2020-08-20 10:32:32 --> Hooks Class Initialized
INFO - 2020-08-20 10:32:32 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-20 10:32:32 --> UTF-8 Support Enabled
INFO - 2020-08-20 10:32:32 --> Utf8 Class Initialized
INFO - 2020-08-20 10:32:32 --> URI Class Initialized
DEBUG - 2020-08-20 10:32:32 --> No URI present. Default controller set.
INFO - 2020-08-20 10:32:32 --> Router Class Initialized
INFO - 2020-08-20 10:32:32 --> Output Class Initialized
INFO - 2020-08-20 10:32:32 --> Security Class Initialized
INFO - 2020-08-20 10:32:32 --> Database Driver Class Initialized
DEBUG - 2020-08-20 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 10:32:32 --> Input Class Initialized
INFO - 2020-08-20 10:32:32 --> Language Class Initialized
INFO - 2020-08-20 10:32:32 --> Language Class Initialized
INFO - 2020-08-20 10:32:32 --> Config Class Initialized
DEBUG - 2020-08-20 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 10:32:32 --> Loader Class Initialized
INFO - 2020-08-20 10:32:32 --> Upload Class Initialized
INFO - 2020-08-20 10:32:32 --> Helper loaded: url_helper
INFO - 2020-08-20 10:32:32 --> Helper loaded: form_helper
INFO - 2020-08-20 10:32:32 --> Helper loaded: file_helper
INFO - 2020-08-20 10:32:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 10:32:32 --> Database Driver Class Initialized
DEBUG - 2020-08-20 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 10:32:32 --> Controller Class Initialized
ERROR - 2020-08-20 10:32:32 --> 404 Page Not Found: /index
INFO - 2020-08-20 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 10:32:32 --> Upload Class Initialized
INFO - 2020-08-20 10:32:32 --> Controller Class Initialized
DEBUG - 2020-08-20 10:32:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 10:32:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 10:32:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 10:32:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 10:32:32 --> Final output sent to browser
DEBUG - 2020-08-20 10:32:32 --> Total execution time: 0.0880
INFO - 2020-08-20 12:04:17 --> Config Class Initialized
INFO - 2020-08-20 12:04:17 --> Hooks Class Initialized
DEBUG - 2020-08-20 12:04:17 --> UTF-8 Support Enabled
INFO - 2020-08-20 12:04:17 --> Utf8 Class Initialized
INFO - 2020-08-20 12:04:17 --> URI Class Initialized
DEBUG - 2020-08-20 12:04:17 --> No URI present. Default controller set.
INFO - 2020-08-20 12:04:17 --> Router Class Initialized
INFO - 2020-08-20 12:04:17 --> Output Class Initialized
INFO - 2020-08-20 12:04:17 --> Security Class Initialized
DEBUG - 2020-08-20 12:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 12:04:17 --> Input Class Initialized
INFO - 2020-08-20 12:04:17 --> Language Class Initialized
INFO - 2020-08-20 12:04:17 --> Language Class Initialized
INFO - 2020-08-20 12:04:17 --> Config Class Initialized
INFO - 2020-08-20 12:04:17 --> Loader Class Initialized
INFO - 2020-08-20 12:04:17 --> Helper loaded: url_helper
INFO - 2020-08-20 12:04:17 --> Helper loaded: form_helper
INFO - 2020-08-20 12:04:17 --> Helper loaded: file_helper
INFO - 2020-08-20 12:04:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 12:04:17 --> Database Driver Class Initialized
DEBUG - 2020-08-20 12:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 12:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 12:04:17 --> Upload Class Initialized
INFO - 2020-08-20 12:04:17 --> Controller Class Initialized
DEBUG - 2020-08-20 12:04:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 12:04:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 12:04:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 12:04:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 12:04:17 --> Final output sent to browser
DEBUG - 2020-08-20 12:04:17 --> Total execution time: 0.0508
INFO - 2020-08-20 12:08:08 --> Config Class Initialized
INFO - 2020-08-20 12:08:08 --> Hooks Class Initialized
DEBUG - 2020-08-20 12:08:08 --> UTF-8 Support Enabled
INFO - 2020-08-20 12:08:08 --> Utf8 Class Initialized
INFO - 2020-08-20 12:08:08 --> URI Class Initialized
DEBUG - 2020-08-20 12:08:08 --> No URI present. Default controller set.
INFO - 2020-08-20 12:08:08 --> Router Class Initialized
INFO - 2020-08-20 12:08:08 --> Output Class Initialized
INFO - 2020-08-20 12:08:08 --> Security Class Initialized
DEBUG - 2020-08-20 12:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 12:08:08 --> Input Class Initialized
INFO - 2020-08-20 12:08:08 --> Language Class Initialized
INFO - 2020-08-20 12:08:08 --> Language Class Initialized
INFO - 2020-08-20 12:08:08 --> Config Class Initialized
INFO - 2020-08-20 12:08:08 --> Loader Class Initialized
INFO - 2020-08-20 12:08:08 --> Helper loaded: url_helper
INFO - 2020-08-20 12:08:08 --> Helper loaded: form_helper
INFO - 2020-08-20 12:08:08 --> Helper loaded: file_helper
INFO - 2020-08-20 12:08:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 12:08:08 --> Database Driver Class Initialized
DEBUG - 2020-08-20 12:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 12:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 12:08:08 --> Upload Class Initialized
INFO - 2020-08-20 12:08:08 --> Controller Class Initialized
DEBUG - 2020-08-20 12:08:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 12:08:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 12:08:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 12:08:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 12:08:08 --> Final output sent to browser
DEBUG - 2020-08-20 12:08:08 --> Total execution time: 0.0621
INFO - 2020-08-20 12:47:50 --> Config Class Initialized
INFO - 2020-08-20 12:47:50 --> Hooks Class Initialized
DEBUG - 2020-08-20 12:47:50 --> UTF-8 Support Enabled
INFO - 2020-08-20 12:47:50 --> Utf8 Class Initialized
INFO - 2020-08-20 12:47:50 --> URI Class Initialized
INFO - 2020-08-20 12:47:50 --> Router Class Initialized
INFO - 2020-08-20 12:47:50 --> Output Class Initialized
INFO - 2020-08-20 12:47:50 --> Security Class Initialized
DEBUG - 2020-08-20 12:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 12:47:50 --> Input Class Initialized
INFO - 2020-08-20 12:47:50 --> Language Class Initialized
INFO - 2020-08-20 12:47:50 --> Language Class Initialized
INFO - 2020-08-20 12:47:50 --> Config Class Initialized
INFO - 2020-08-20 12:47:50 --> Loader Class Initialized
INFO - 2020-08-20 12:47:50 --> Helper loaded: url_helper
INFO - 2020-08-20 12:47:50 --> Helper loaded: form_helper
INFO - 2020-08-20 12:47:50 --> Helper loaded: file_helper
INFO - 2020-08-20 12:47:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 12:47:50 --> Database Driver Class Initialized
DEBUG - 2020-08-20 12:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 12:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 12:47:50 --> Upload Class Initialized
INFO - 2020-08-20 12:47:50 --> Controller Class Initialized
ERROR - 2020-08-20 12:47:50 --> 404 Page Not Found: /index
INFO - 2020-08-20 14:21:11 --> Config Class Initialized
INFO - 2020-08-20 14:21:11 --> Hooks Class Initialized
DEBUG - 2020-08-20 14:21:11 --> UTF-8 Support Enabled
INFO - 2020-08-20 14:21:11 --> Utf8 Class Initialized
INFO - 2020-08-20 14:21:11 --> URI Class Initialized
INFO - 2020-08-20 14:21:11 --> Router Class Initialized
INFO - 2020-08-20 14:21:11 --> Output Class Initialized
INFO - 2020-08-20 14:21:11 --> Security Class Initialized
DEBUG - 2020-08-20 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 14:21:11 --> Input Class Initialized
INFO - 2020-08-20 14:21:11 --> Language Class Initialized
INFO - 2020-08-20 14:21:11 --> Language Class Initialized
INFO - 2020-08-20 14:21:11 --> Config Class Initialized
INFO - 2020-08-20 14:21:11 --> Loader Class Initialized
INFO - 2020-08-20 14:21:11 --> Helper loaded: url_helper
INFO - 2020-08-20 14:21:11 --> Helper loaded: form_helper
INFO - 2020-08-20 14:21:11 --> Helper loaded: file_helper
INFO - 2020-08-20 14:21:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 14:21:11 --> Database Driver Class Initialized
DEBUG - 2020-08-20 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 14:21:11 --> Upload Class Initialized
INFO - 2020-08-20 14:21:11 --> Controller Class Initialized
DEBUG - 2020-08-20 14:21:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 14:21:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-20 14:21:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 14:21:11 --> Final output sent to browser
DEBUG - 2020-08-20 14:21:11 --> Total execution time: 0.0819
INFO - 2020-08-20 14:37:05 --> Config Class Initialized
INFO - 2020-08-20 14:37:05 --> Hooks Class Initialized
DEBUG - 2020-08-20 14:37:05 --> UTF-8 Support Enabled
INFO - 2020-08-20 14:37:05 --> Utf8 Class Initialized
INFO - 2020-08-20 14:37:05 --> URI Class Initialized
INFO - 2020-08-20 14:37:05 --> Router Class Initialized
INFO - 2020-08-20 14:37:05 --> Output Class Initialized
INFO - 2020-08-20 14:37:05 --> Security Class Initialized
DEBUG - 2020-08-20 14:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 14:37:05 --> Input Class Initialized
INFO - 2020-08-20 14:37:05 --> Language Class Initialized
INFO - 2020-08-20 14:37:05 --> Language Class Initialized
INFO - 2020-08-20 14:37:05 --> Config Class Initialized
INFO - 2020-08-20 14:37:05 --> Loader Class Initialized
INFO - 2020-08-20 14:37:05 --> Helper loaded: url_helper
INFO - 2020-08-20 14:37:05 --> Helper loaded: form_helper
INFO - 2020-08-20 14:37:05 --> Helper loaded: file_helper
INFO - 2020-08-20 14:37:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 14:37:05 --> Database Driver Class Initialized
DEBUG - 2020-08-20 14:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 14:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 14:37:05 --> Upload Class Initialized
INFO - 2020-08-20 14:37:05 --> Controller Class Initialized
DEBUG - 2020-08-20 14:37:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 14:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 14:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 14:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 14:37:05 --> Final output sent to browser
DEBUG - 2020-08-20 14:37:05 --> Total execution time: 0.0515
INFO - 2020-08-20 15:05:44 --> Config Class Initialized
INFO - 2020-08-20 15:05:44 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:05:44 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:05:44 --> Utf8 Class Initialized
INFO - 2020-08-20 15:05:44 --> URI Class Initialized
INFO - 2020-08-20 15:05:44 --> Router Class Initialized
INFO - 2020-08-20 15:05:44 --> Output Class Initialized
INFO - 2020-08-20 15:05:44 --> Security Class Initialized
DEBUG - 2020-08-20 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:05:44 --> Input Class Initialized
INFO - 2020-08-20 15:05:44 --> Language Class Initialized
INFO - 2020-08-20 15:05:44 --> Language Class Initialized
INFO - 2020-08-20 15:05:44 --> Config Class Initialized
INFO - 2020-08-20 15:05:44 --> Loader Class Initialized
INFO - 2020-08-20 15:05:44 --> Helper loaded: url_helper
INFO - 2020-08-20 15:05:44 --> Helper loaded: form_helper
INFO - 2020-08-20 15:05:44 --> Helper loaded: file_helper
INFO - 2020-08-20 15:05:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:05:44 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:05:44 --> Upload Class Initialized
INFO - 2020-08-20 15:05:44 --> Controller Class Initialized
DEBUG - 2020-08-20 15:05:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:05:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-20 15:05:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:05:44 --> Final output sent to browser
DEBUG - 2020-08-20 15:05:44 --> Total execution time: 0.0513
INFO - 2020-08-20 15:06:02 --> Config Class Initialized
INFO - 2020-08-20 15:06:02 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:06:02 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:06:02 --> Utf8 Class Initialized
INFO - 2020-08-20 15:06:02 --> URI Class Initialized
INFO - 2020-08-20 15:06:02 --> Router Class Initialized
INFO - 2020-08-20 15:06:02 --> Output Class Initialized
INFO - 2020-08-20 15:06:02 --> Security Class Initialized
DEBUG - 2020-08-20 15:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:06:02 --> Input Class Initialized
INFO - 2020-08-20 15:06:02 --> Language Class Initialized
INFO - 2020-08-20 15:06:02 --> Language Class Initialized
INFO - 2020-08-20 15:06:02 --> Config Class Initialized
INFO - 2020-08-20 15:06:02 --> Loader Class Initialized
INFO - 2020-08-20 15:06:02 --> Helper loaded: url_helper
INFO - 2020-08-20 15:06:02 --> Helper loaded: form_helper
INFO - 2020-08-20 15:06:02 --> Helper loaded: file_helper
INFO - 2020-08-20 15:06:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:06:02 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:06:02 --> Upload Class Initialized
INFO - 2020-08-20 15:06:02 --> Controller Class Initialized
DEBUG - 2020-08-20 15:06:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:06:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-20 15:06:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:06:02 --> Final output sent to browser
DEBUG - 2020-08-20 15:06:02 --> Total execution time: 0.0928
INFO - 2020-08-20 15:06:23 --> Config Class Initialized
INFO - 2020-08-20 15:06:23 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:06:23 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:06:23 --> Utf8 Class Initialized
INFO - 2020-08-20 15:06:23 --> URI Class Initialized
INFO - 2020-08-20 15:06:23 --> Router Class Initialized
INFO - 2020-08-20 15:06:23 --> Output Class Initialized
INFO - 2020-08-20 15:06:23 --> Security Class Initialized
DEBUG - 2020-08-20 15:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:06:23 --> Input Class Initialized
INFO - 2020-08-20 15:06:23 --> Language Class Initialized
INFO - 2020-08-20 15:06:23 --> Language Class Initialized
INFO - 2020-08-20 15:06:23 --> Config Class Initialized
INFO - 2020-08-20 15:06:23 --> Loader Class Initialized
INFO - 2020-08-20 15:06:23 --> Helper loaded: url_helper
INFO - 2020-08-20 15:06:23 --> Helper loaded: form_helper
INFO - 2020-08-20 15:06:23 --> Helper loaded: file_helper
INFO - 2020-08-20 15:06:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:06:23 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:06:23 --> Upload Class Initialized
INFO - 2020-08-20 15:06:23 --> Controller Class Initialized
DEBUG - 2020-08-20 15:06:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:06:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-20 15:06:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:06:23 --> Final output sent to browser
DEBUG - 2020-08-20 15:06:23 --> Total execution time: 0.0577
INFO - 2020-08-20 15:06:47 --> Config Class Initialized
INFO - 2020-08-20 15:06:47 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:06:47 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:06:47 --> Utf8 Class Initialized
INFO - 2020-08-20 15:06:47 --> URI Class Initialized
INFO - 2020-08-20 15:06:47 --> Router Class Initialized
INFO - 2020-08-20 15:06:47 --> Output Class Initialized
INFO - 2020-08-20 15:06:47 --> Security Class Initialized
DEBUG - 2020-08-20 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:06:47 --> Input Class Initialized
INFO - 2020-08-20 15:06:47 --> Language Class Initialized
INFO - 2020-08-20 15:06:47 --> Language Class Initialized
INFO - 2020-08-20 15:06:47 --> Config Class Initialized
INFO - 2020-08-20 15:06:47 --> Loader Class Initialized
INFO - 2020-08-20 15:06:47 --> Helper loaded: url_helper
INFO - 2020-08-20 15:06:47 --> Helper loaded: form_helper
INFO - 2020-08-20 15:06:47 --> Helper loaded: file_helper
INFO - 2020-08-20 15:06:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:06:47 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:06:47 --> Upload Class Initialized
INFO - 2020-08-20 15:06:47 --> Controller Class Initialized
DEBUG - 2020-08-20 15:06:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:06:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-20 15:06:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:06:47 --> Final output sent to browser
DEBUG - 2020-08-20 15:06:47 --> Total execution time: 0.0577
INFO - 2020-08-20 15:07:29 --> Config Class Initialized
INFO - 2020-08-20 15:07:29 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:07:29 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:07:29 --> Utf8 Class Initialized
INFO - 2020-08-20 15:07:29 --> URI Class Initialized
INFO - 2020-08-20 15:07:29 --> Router Class Initialized
INFO - 2020-08-20 15:07:29 --> Output Class Initialized
INFO - 2020-08-20 15:07:29 --> Security Class Initialized
DEBUG - 2020-08-20 15:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:07:29 --> Input Class Initialized
INFO - 2020-08-20 15:07:29 --> Language Class Initialized
INFO - 2020-08-20 15:07:29 --> Language Class Initialized
INFO - 2020-08-20 15:07:29 --> Config Class Initialized
INFO - 2020-08-20 15:07:29 --> Loader Class Initialized
INFO - 2020-08-20 15:07:29 --> Helper loaded: url_helper
INFO - 2020-08-20 15:07:29 --> Helper loaded: form_helper
INFO - 2020-08-20 15:07:29 --> Helper loaded: file_helper
INFO - 2020-08-20 15:07:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:07:29 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:07:29 --> Upload Class Initialized
INFO - 2020-08-20 15:07:29 --> Controller Class Initialized
DEBUG - 2020-08-20 15:07:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:07:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-20 15:07:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:07:29 --> Final output sent to browser
DEBUG - 2020-08-20 15:07:29 --> Total execution time: 0.0512
INFO - 2020-08-20 15:08:26 --> Config Class Initialized
INFO - 2020-08-20 15:08:26 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:08:26 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:08:26 --> Utf8 Class Initialized
INFO - 2020-08-20 15:08:26 --> URI Class Initialized
INFO - 2020-08-20 15:08:26 --> Router Class Initialized
INFO - 2020-08-20 15:08:26 --> Output Class Initialized
INFO - 2020-08-20 15:08:26 --> Security Class Initialized
DEBUG - 2020-08-20 15:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:08:26 --> Input Class Initialized
INFO - 2020-08-20 15:08:26 --> Language Class Initialized
INFO - 2020-08-20 15:08:26 --> Language Class Initialized
INFO - 2020-08-20 15:08:26 --> Config Class Initialized
INFO - 2020-08-20 15:08:26 --> Loader Class Initialized
INFO - 2020-08-20 15:08:26 --> Helper loaded: url_helper
INFO - 2020-08-20 15:08:26 --> Helper loaded: form_helper
INFO - 2020-08-20 15:08:26 --> Helper loaded: file_helper
INFO - 2020-08-20 15:08:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:08:26 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:08:26 --> Upload Class Initialized
INFO - 2020-08-20 15:08:26 --> Controller Class Initialized
DEBUG - 2020-08-20 15:08:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:08:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-20 15:08:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:08:26 --> Final output sent to browser
DEBUG - 2020-08-20 15:08:26 --> Total execution time: 0.0570
INFO - 2020-08-20 15:38:44 --> Config Class Initialized
INFO - 2020-08-20 15:38:44 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:38:44 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:38:44 --> Utf8 Class Initialized
INFO - 2020-08-20 15:38:44 --> URI Class Initialized
INFO - 2020-08-20 15:38:44 --> Router Class Initialized
INFO - 2020-08-20 15:38:44 --> Output Class Initialized
INFO - 2020-08-20 15:38:44 --> Security Class Initialized
DEBUG - 2020-08-20 15:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:38:44 --> Input Class Initialized
INFO - 2020-08-20 15:38:44 --> Language Class Initialized
INFO - 2020-08-20 15:38:44 --> Language Class Initialized
INFO - 2020-08-20 15:38:44 --> Config Class Initialized
INFO - 2020-08-20 15:38:44 --> Loader Class Initialized
INFO - 2020-08-20 15:38:44 --> Helper loaded: url_helper
INFO - 2020-08-20 15:38:44 --> Helper loaded: form_helper
INFO - 2020-08-20 15:38:44 --> Helper loaded: file_helper
INFO - 2020-08-20 15:38:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:38:44 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:38:44 --> Upload Class Initialized
INFO - 2020-08-20 15:38:44 --> Controller Class Initialized
ERROR - 2020-08-20 15:38:44 --> 404 Page Not Found: /index
INFO - 2020-08-20 15:38:45 --> Config Class Initialized
INFO - 2020-08-20 15:38:45 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:38:45 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:38:45 --> Utf8 Class Initialized
INFO - 2020-08-20 15:38:45 --> URI Class Initialized
INFO - 2020-08-20 15:38:45 --> Router Class Initialized
INFO - 2020-08-20 15:38:45 --> Output Class Initialized
INFO - 2020-08-20 15:38:45 --> Security Class Initialized
DEBUG - 2020-08-20 15:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:38:45 --> Input Class Initialized
INFO - 2020-08-20 15:38:45 --> Language Class Initialized
INFO - 2020-08-20 15:38:45 --> Language Class Initialized
INFO - 2020-08-20 15:38:45 --> Config Class Initialized
INFO - 2020-08-20 15:38:45 --> Loader Class Initialized
INFO - 2020-08-20 15:38:45 --> Helper loaded: url_helper
INFO - 2020-08-20 15:38:45 --> Helper loaded: form_helper
INFO - 2020-08-20 15:38:45 --> Helper loaded: file_helper
INFO - 2020-08-20 15:38:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:38:45 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:38:45 --> Upload Class Initialized
INFO - 2020-08-20 15:38:45 --> Controller Class Initialized
DEBUG - 2020-08-20 15:38:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 15:38:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 15:38:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 15:38:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 15:38:45 --> Final output sent to browser
DEBUG - 2020-08-20 15:38:45 --> Total execution time: 0.0547
INFO - 2020-08-20 15:38:47 --> Config Class Initialized
INFO - 2020-08-20 15:38:47 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:38:47 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:38:47 --> Utf8 Class Initialized
INFO - 2020-08-20 15:38:47 --> URI Class Initialized
INFO - 2020-08-20 15:38:47 --> Router Class Initialized
INFO - 2020-08-20 15:38:47 --> Output Class Initialized
INFO - 2020-08-20 15:38:47 --> Security Class Initialized
DEBUG - 2020-08-20 15:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:38:47 --> Input Class Initialized
INFO - 2020-08-20 15:38:47 --> Language Class Initialized
INFO - 2020-08-20 15:38:47 --> Language Class Initialized
INFO - 2020-08-20 15:38:47 --> Config Class Initialized
INFO - 2020-08-20 15:38:47 --> Loader Class Initialized
INFO - 2020-08-20 15:38:47 --> Helper loaded: url_helper
INFO - 2020-08-20 15:38:47 --> Helper loaded: form_helper
INFO - 2020-08-20 15:38:47 --> Helper loaded: file_helper
INFO - 2020-08-20 15:38:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 15:38:47 --> Database Driver Class Initialized
DEBUG - 2020-08-20 15:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 15:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:38:47 --> Upload Class Initialized
INFO - 2020-08-20 15:38:47 --> Controller Class Initialized
ERROR - 2020-08-20 15:38:47 --> 404 Page Not Found: /index
INFO - 2020-08-20 16:05:32 --> Config Class Initialized
INFO - 2020-08-20 16:05:32 --> Hooks Class Initialized
DEBUG - 2020-08-20 16:05:32 --> UTF-8 Support Enabled
INFO - 2020-08-20 16:05:32 --> Utf8 Class Initialized
INFO - 2020-08-20 16:05:32 --> URI Class Initialized
INFO - 2020-08-20 16:05:32 --> Router Class Initialized
INFO - 2020-08-20 16:05:32 --> Output Class Initialized
INFO - 2020-08-20 16:05:32 --> Security Class Initialized
DEBUG - 2020-08-20 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 16:05:32 --> Input Class Initialized
INFO - 2020-08-20 16:05:32 --> Language Class Initialized
INFO - 2020-08-20 16:05:32 --> Language Class Initialized
INFO - 2020-08-20 16:05:32 --> Config Class Initialized
INFO - 2020-08-20 16:05:32 --> Loader Class Initialized
INFO - 2020-08-20 16:05:32 --> Helper loaded: url_helper
INFO - 2020-08-20 16:05:32 --> Helper loaded: form_helper
INFO - 2020-08-20 16:05:32 --> Helper loaded: file_helper
INFO - 2020-08-20 16:05:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 16:05:32 --> Database Driver Class Initialized
DEBUG - 2020-08-20 16:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 16:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 16:05:32 --> Upload Class Initialized
INFO - 2020-08-20 16:05:32 --> Controller Class Initialized
ERROR - 2020-08-20 16:05:32 --> 404 Page Not Found: /index
INFO - 2020-08-20 16:05:32 --> Config Class Initialized
INFO - 2020-08-20 16:05:32 --> Hooks Class Initialized
DEBUG - 2020-08-20 16:05:32 --> UTF-8 Support Enabled
INFO - 2020-08-20 16:05:32 --> Utf8 Class Initialized
INFO - 2020-08-20 16:05:32 --> URI Class Initialized
INFO - 2020-08-20 16:05:32 --> Router Class Initialized
INFO - 2020-08-20 16:05:32 --> Output Class Initialized
INFO - 2020-08-20 16:05:32 --> Security Class Initialized
DEBUG - 2020-08-20 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 16:05:32 --> Input Class Initialized
INFO - 2020-08-20 16:05:32 --> Language Class Initialized
INFO - 2020-08-20 16:05:32 --> Language Class Initialized
INFO - 2020-08-20 16:05:32 --> Config Class Initialized
INFO - 2020-08-20 16:05:33 --> Loader Class Initialized
INFO - 2020-08-20 16:05:33 --> Helper loaded: url_helper
INFO - 2020-08-20 16:05:33 --> Helper loaded: form_helper
INFO - 2020-08-20 16:05:33 --> Helper loaded: file_helper
INFO - 2020-08-20 16:05:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 16:05:33 --> Database Driver Class Initialized
DEBUG - 2020-08-20 16:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 16:05:33 --> Upload Class Initialized
INFO - 2020-08-20 16:05:33 --> Controller Class Initialized
ERROR - 2020-08-20 16:05:33 --> 404 Page Not Found: /index
INFO - 2020-08-20 17:17:09 --> Config Class Initialized
INFO - 2020-08-20 17:17:09 --> Hooks Class Initialized
DEBUG - 2020-08-20 17:17:09 --> UTF-8 Support Enabled
INFO - 2020-08-20 17:17:09 --> Utf8 Class Initialized
INFO - 2020-08-20 17:17:09 --> URI Class Initialized
DEBUG - 2020-08-20 17:17:09 --> No URI present. Default controller set.
INFO - 2020-08-20 17:17:09 --> Router Class Initialized
INFO - 2020-08-20 17:17:09 --> Output Class Initialized
INFO - 2020-08-20 17:17:09 --> Security Class Initialized
DEBUG - 2020-08-20 17:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 17:17:09 --> Input Class Initialized
INFO - 2020-08-20 17:17:09 --> Language Class Initialized
INFO - 2020-08-20 17:17:09 --> Language Class Initialized
INFO - 2020-08-20 17:17:09 --> Config Class Initialized
INFO - 2020-08-20 17:17:09 --> Loader Class Initialized
INFO - 2020-08-20 17:17:09 --> Helper loaded: url_helper
INFO - 2020-08-20 17:17:09 --> Helper loaded: form_helper
INFO - 2020-08-20 17:17:09 --> Helper loaded: file_helper
INFO - 2020-08-20 17:17:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 17:17:09 --> Database Driver Class Initialized
DEBUG - 2020-08-20 17:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 17:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 17:17:09 --> Upload Class Initialized
INFO - 2020-08-20 17:17:10 --> Controller Class Initialized
DEBUG - 2020-08-20 17:17:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 17:17:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 17:17:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 17:17:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 17:17:10 --> Final output sent to browser
DEBUG - 2020-08-20 17:17:10 --> Total execution time: 0.0736
INFO - 2020-08-20 17:17:11 --> Config Class Initialized
INFO - 2020-08-20 17:17:11 --> Hooks Class Initialized
DEBUG - 2020-08-20 17:17:11 --> UTF-8 Support Enabled
INFO - 2020-08-20 17:17:11 --> Utf8 Class Initialized
INFO - 2020-08-20 17:17:11 --> URI Class Initialized
INFO - 2020-08-20 17:17:11 --> Router Class Initialized
INFO - 2020-08-20 17:17:11 --> Output Class Initialized
INFO - 2020-08-20 17:17:11 --> Security Class Initialized
DEBUG - 2020-08-20 17:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 17:17:11 --> Input Class Initialized
INFO - 2020-08-20 17:17:11 --> Language Class Initialized
INFO - 2020-08-20 17:17:11 --> Language Class Initialized
INFO - 2020-08-20 17:17:11 --> Config Class Initialized
INFO - 2020-08-20 17:17:11 --> Loader Class Initialized
INFO - 2020-08-20 17:17:11 --> Helper loaded: url_helper
INFO - 2020-08-20 17:17:11 --> Helper loaded: form_helper
INFO - 2020-08-20 17:17:11 --> Helper loaded: file_helper
INFO - 2020-08-20 17:17:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 17:17:11 --> Database Driver Class Initialized
DEBUG - 2020-08-20 17:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 17:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 17:17:11 --> Upload Class Initialized
INFO - 2020-08-20 17:17:11 --> Controller Class Initialized
ERROR - 2020-08-20 17:17:11 --> 404 Page Not Found: /index
INFO - 2020-08-20 17:30:43 --> Config Class Initialized
INFO - 2020-08-20 17:30:43 --> Hooks Class Initialized
DEBUG - 2020-08-20 17:30:43 --> UTF-8 Support Enabled
INFO - 2020-08-20 17:30:43 --> Utf8 Class Initialized
INFO - 2020-08-20 17:30:43 --> URI Class Initialized
DEBUG - 2020-08-20 17:30:43 --> No URI present. Default controller set.
INFO - 2020-08-20 17:30:43 --> Router Class Initialized
INFO - 2020-08-20 17:30:43 --> Output Class Initialized
INFO - 2020-08-20 17:30:43 --> Security Class Initialized
DEBUG - 2020-08-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 17:30:43 --> Input Class Initialized
INFO - 2020-08-20 17:30:43 --> Language Class Initialized
INFO - 2020-08-20 17:30:43 --> Language Class Initialized
INFO - 2020-08-20 17:30:43 --> Config Class Initialized
INFO - 2020-08-20 17:30:43 --> Loader Class Initialized
INFO - 2020-08-20 17:30:43 --> Helper loaded: url_helper
INFO - 2020-08-20 17:30:43 --> Helper loaded: form_helper
INFO - 2020-08-20 17:30:43 --> Helper loaded: file_helper
INFO - 2020-08-20 17:30:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 17:30:43 --> Database Driver Class Initialized
DEBUG - 2020-08-20 17:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 17:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 17:30:43 --> Upload Class Initialized
INFO - 2020-08-20 17:30:43 --> Controller Class Initialized
DEBUG - 2020-08-20 17:30:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 17:30:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 17:30:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 17:30:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 17:30:43 --> Final output sent to browser
DEBUG - 2020-08-20 17:30:43 --> Total execution time: 0.0525
INFO - 2020-08-20 17:30:45 --> Config Class Initialized
INFO - 2020-08-20 17:30:45 --> Hooks Class Initialized
DEBUG - 2020-08-20 17:30:45 --> UTF-8 Support Enabled
INFO - 2020-08-20 17:30:45 --> Utf8 Class Initialized
INFO - 2020-08-20 17:30:45 --> URI Class Initialized
INFO - 2020-08-20 17:30:45 --> Router Class Initialized
INFO - 2020-08-20 17:30:45 --> Output Class Initialized
INFO - 2020-08-20 17:30:45 --> Security Class Initialized
DEBUG - 2020-08-20 17:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 17:30:45 --> Input Class Initialized
INFO - 2020-08-20 17:30:45 --> Language Class Initialized
INFO - 2020-08-20 17:30:45 --> Language Class Initialized
INFO - 2020-08-20 17:30:45 --> Config Class Initialized
INFO - 2020-08-20 17:30:45 --> Loader Class Initialized
INFO - 2020-08-20 17:30:45 --> Helper loaded: url_helper
INFO - 2020-08-20 17:30:45 --> Helper loaded: form_helper
INFO - 2020-08-20 17:30:45 --> Helper loaded: file_helper
INFO - 2020-08-20 17:30:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 17:30:45 --> Database Driver Class Initialized
DEBUG - 2020-08-20 17:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 17:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 17:30:45 --> Upload Class Initialized
INFO - 2020-08-20 17:30:45 --> Controller Class Initialized
ERROR - 2020-08-20 17:30:45 --> 404 Page Not Found: /index
INFO - 2020-08-20 18:11:26 --> Config Class Initialized
INFO - 2020-08-20 18:11:26 --> Hooks Class Initialized
DEBUG - 2020-08-20 18:11:26 --> UTF-8 Support Enabled
INFO - 2020-08-20 18:11:26 --> Utf8 Class Initialized
INFO - 2020-08-20 18:11:26 --> URI Class Initialized
DEBUG - 2020-08-20 18:11:26 --> No URI present. Default controller set.
INFO - 2020-08-20 18:11:26 --> Router Class Initialized
INFO - 2020-08-20 18:11:26 --> Output Class Initialized
INFO - 2020-08-20 18:11:26 --> Security Class Initialized
DEBUG - 2020-08-20 18:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 18:11:26 --> Input Class Initialized
INFO - 2020-08-20 18:11:26 --> Language Class Initialized
INFO - 2020-08-20 18:11:26 --> Language Class Initialized
INFO - 2020-08-20 18:11:26 --> Config Class Initialized
INFO - 2020-08-20 18:11:26 --> Loader Class Initialized
INFO - 2020-08-20 18:11:26 --> Helper loaded: url_helper
INFO - 2020-08-20 18:11:26 --> Helper loaded: form_helper
INFO - 2020-08-20 18:11:26 --> Helper loaded: file_helper
INFO - 2020-08-20 18:11:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 18:11:26 --> Database Driver Class Initialized
DEBUG - 2020-08-20 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 18:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 18:11:26 --> Upload Class Initialized
INFO - 2020-08-20 18:11:26 --> Controller Class Initialized
DEBUG - 2020-08-20 18:11:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 18:11:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 18:11:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 18:11:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 18:11:26 --> Final output sent to browser
DEBUG - 2020-08-20 18:11:26 --> Total execution time: 0.0530
INFO - 2020-08-20 18:56:58 --> Config Class Initialized
INFO - 2020-08-20 18:56:58 --> Hooks Class Initialized
DEBUG - 2020-08-20 18:56:58 --> UTF-8 Support Enabled
INFO - 2020-08-20 18:56:58 --> Utf8 Class Initialized
INFO - 2020-08-20 18:56:58 --> URI Class Initialized
DEBUG - 2020-08-20 18:56:58 --> No URI present. Default controller set.
INFO - 2020-08-20 18:56:58 --> Router Class Initialized
INFO - 2020-08-20 18:56:58 --> Output Class Initialized
INFO - 2020-08-20 18:56:58 --> Security Class Initialized
DEBUG - 2020-08-20 18:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 18:56:58 --> Input Class Initialized
INFO - 2020-08-20 18:56:58 --> Language Class Initialized
INFO - 2020-08-20 18:56:58 --> Language Class Initialized
INFO - 2020-08-20 18:56:58 --> Config Class Initialized
INFO - 2020-08-20 18:56:58 --> Loader Class Initialized
INFO - 2020-08-20 18:56:58 --> Helper loaded: url_helper
INFO - 2020-08-20 18:56:58 --> Helper loaded: form_helper
INFO - 2020-08-20 18:56:58 --> Helper loaded: file_helper
INFO - 2020-08-20 18:56:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 18:56:58 --> Database Driver Class Initialized
DEBUG - 2020-08-20 18:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 18:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 18:56:58 --> Upload Class Initialized
INFO - 2020-08-20 18:56:58 --> Controller Class Initialized
DEBUG - 2020-08-20 18:56:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 18:56:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 18:56:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 18:56:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 18:56:58 --> Final output sent to browser
DEBUG - 2020-08-20 18:56:58 --> Total execution time: 0.0512
INFO - 2020-08-20 18:57:04 --> Config Class Initialized
INFO - 2020-08-20 18:57:04 --> Hooks Class Initialized
DEBUG - 2020-08-20 18:57:04 --> UTF-8 Support Enabled
INFO - 2020-08-20 18:57:04 --> Utf8 Class Initialized
INFO - 2020-08-20 18:57:04 --> URI Class Initialized
INFO - 2020-08-20 18:57:04 --> Router Class Initialized
INFO - 2020-08-20 18:57:04 --> Output Class Initialized
INFO - 2020-08-20 18:57:04 --> Security Class Initialized
DEBUG - 2020-08-20 18:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 18:57:04 --> Input Class Initialized
INFO - 2020-08-20 18:57:04 --> Language Class Initialized
INFO - 2020-08-20 18:57:04 --> Language Class Initialized
INFO - 2020-08-20 18:57:04 --> Config Class Initialized
INFO - 2020-08-20 18:57:04 --> Loader Class Initialized
INFO - 2020-08-20 18:57:04 --> Helper loaded: url_helper
INFO - 2020-08-20 18:57:04 --> Helper loaded: form_helper
INFO - 2020-08-20 18:57:04 --> Helper loaded: file_helper
INFO - 2020-08-20 18:57:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 18:57:04 --> Database Driver Class Initialized
DEBUG - 2020-08-20 18:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 18:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 18:57:04 --> Upload Class Initialized
INFO - 2020-08-20 18:57:04 --> Controller Class Initialized
ERROR - 2020-08-20 18:57:04 --> 404 Page Not Found: /index
INFO - 2020-08-20 19:20:45 --> Config Class Initialized
INFO - 2020-08-20 19:20:45 --> Hooks Class Initialized
DEBUG - 2020-08-20 19:20:45 --> UTF-8 Support Enabled
INFO - 2020-08-20 19:20:45 --> Utf8 Class Initialized
INFO - 2020-08-20 19:20:45 --> URI Class Initialized
DEBUG - 2020-08-20 19:20:45 --> No URI present. Default controller set.
INFO - 2020-08-20 19:20:45 --> Router Class Initialized
INFO - 2020-08-20 19:20:45 --> Output Class Initialized
INFO - 2020-08-20 19:20:45 --> Security Class Initialized
DEBUG - 2020-08-20 19:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 19:20:45 --> Input Class Initialized
INFO - 2020-08-20 19:20:45 --> Language Class Initialized
INFO - 2020-08-20 19:20:45 --> Language Class Initialized
INFO - 2020-08-20 19:20:45 --> Config Class Initialized
INFO - 2020-08-20 19:20:45 --> Loader Class Initialized
INFO - 2020-08-20 19:20:45 --> Helper loaded: url_helper
INFO - 2020-08-20 19:20:45 --> Helper loaded: form_helper
INFO - 2020-08-20 19:20:45 --> Helper loaded: file_helper
INFO - 2020-08-20 19:20:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 19:20:45 --> Database Driver Class Initialized
DEBUG - 2020-08-20 19:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 19:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 19:20:45 --> Upload Class Initialized
INFO - 2020-08-20 19:20:45 --> Controller Class Initialized
DEBUG - 2020-08-20 19:20:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 19:20:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 19:20:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 19:20:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 19:20:45 --> Final output sent to browser
DEBUG - 2020-08-20 19:20:45 --> Total execution time: 0.0513
INFO - 2020-08-20 19:20:45 --> Config Class Initialized
INFO - 2020-08-20 19:20:45 --> Hooks Class Initialized
DEBUG - 2020-08-20 19:20:45 --> UTF-8 Support Enabled
INFO - 2020-08-20 19:20:45 --> Utf8 Class Initialized
INFO - 2020-08-20 19:20:45 --> URI Class Initialized
DEBUG - 2020-08-20 19:20:45 --> No URI present. Default controller set.
INFO - 2020-08-20 19:20:45 --> Router Class Initialized
INFO - 2020-08-20 19:20:45 --> Output Class Initialized
INFO - 2020-08-20 19:20:45 --> Security Class Initialized
DEBUG - 2020-08-20 19:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 19:20:45 --> Input Class Initialized
INFO - 2020-08-20 19:20:45 --> Language Class Initialized
INFO - 2020-08-20 19:20:45 --> Language Class Initialized
INFO - 2020-08-20 19:20:45 --> Config Class Initialized
INFO - 2020-08-20 19:20:45 --> Loader Class Initialized
INFO - 2020-08-20 19:20:45 --> Helper loaded: url_helper
INFO - 2020-08-20 19:20:45 --> Helper loaded: form_helper
INFO - 2020-08-20 19:20:45 --> Helper loaded: file_helper
INFO - 2020-08-20 19:20:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 19:20:45 --> Database Driver Class Initialized
DEBUG - 2020-08-20 19:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 19:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 19:20:45 --> Upload Class Initialized
INFO - 2020-08-20 19:20:45 --> Controller Class Initialized
DEBUG - 2020-08-20 19:20:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-20 19:20:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-20 19:20:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-20 19:20:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-20 19:20:45 --> Final output sent to browser
DEBUG - 2020-08-20 19:20:45 --> Total execution time: 0.0519
INFO - 2020-08-20 20:13:24 --> Config Class Initialized
INFO - 2020-08-20 20:13:24 --> Hooks Class Initialized
DEBUG - 2020-08-20 20:13:24 --> UTF-8 Support Enabled
INFO - 2020-08-20 20:13:24 --> Utf8 Class Initialized
INFO - 2020-08-20 20:13:24 --> URI Class Initialized
INFO - 2020-08-20 20:13:24 --> Router Class Initialized
INFO - 2020-08-20 20:13:24 --> Output Class Initialized
INFO - 2020-08-20 20:13:24 --> Security Class Initialized
DEBUG - 2020-08-20 20:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 20:13:24 --> Input Class Initialized
INFO - 2020-08-20 20:13:24 --> Language Class Initialized
INFO - 2020-08-20 20:13:24 --> Language Class Initialized
INFO - 2020-08-20 20:13:24 --> Config Class Initialized
INFO - 2020-08-20 20:13:24 --> Loader Class Initialized
INFO - 2020-08-20 20:13:24 --> Helper loaded: url_helper
INFO - 2020-08-20 20:13:24 --> Helper loaded: form_helper
INFO - 2020-08-20 20:13:24 --> Helper loaded: file_helper
INFO - 2020-08-20 20:13:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 20:13:24 --> Database Driver Class Initialized
DEBUG - 2020-08-20 20:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 20:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 20:13:24 --> Upload Class Initialized
INFO - 2020-08-20 20:13:24 --> Controller Class Initialized
ERROR - 2020-08-20 20:13:24 --> 404 Page Not Found: /index
INFO - 2020-08-20 21:03:16 --> Config Class Initialized
INFO - 2020-08-20 21:03:16 --> Hooks Class Initialized
DEBUG - 2020-08-20 21:03:16 --> UTF-8 Support Enabled
INFO - 2020-08-20 21:03:16 --> Utf8 Class Initialized
INFO - 2020-08-20 21:03:16 --> URI Class Initialized
INFO - 2020-08-20 21:03:16 --> Router Class Initialized
INFO - 2020-08-20 21:03:16 --> Output Class Initialized
INFO - 2020-08-20 21:03:16 --> Security Class Initialized
DEBUG - 2020-08-20 21:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 21:03:16 --> Input Class Initialized
INFO - 2020-08-20 21:03:16 --> Language Class Initialized
INFO - 2020-08-20 21:03:16 --> Language Class Initialized
INFO - 2020-08-20 21:03:16 --> Config Class Initialized
INFO - 2020-08-20 21:03:16 --> Loader Class Initialized
INFO - 2020-08-20 21:03:16 --> Helper loaded: url_helper
INFO - 2020-08-20 21:03:16 --> Helper loaded: form_helper
INFO - 2020-08-20 21:03:16 --> Helper loaded: file_helper
INFO - 2020-08-20 21:03:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 21:03:16 --> Database Driver Class Initialized
DEBUG - 2020-08-20 21:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 21:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 21:03:16 --> Upload Class Initialized
INFO - 2020-08-20 21:03:16 --> Controller Class Initialized
ERROR - 2020-08-20 21:03:16 --> 404 Page Not Found: /index
INFO - 2020-08-20 22:41:21 --> Config Class Initialized
INFO - 2020-08-20 22:41:21 --> Hooks Class Initialized
DEBUG - 2020-08-20 22:41:21 --> UTF-8 Support Enabled
INFO - 2020-08-20 22:41:21 --> Utf8 Class Initialized
INFO - 2020-08-20 22:41:21 --> URI Class Initialized
INFO - 2020-08-20 22:41:21 --> Router Class Initialized
INFO - 2020-08-20 22:41:21 --> Output Class Initialized
INFO - 2020-08-20 22:41:21 --> Security Class Initialized
DEBUG - 2020-08-20 22:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 22:41:21 --> Input Class Initialized
INFO - 2020-08-20 22:41:21 --> Language Class Initialized
INFO - 2020-08-20 22:41:21 --> Language Class Initialized
INFO - 2020-08-20 22:41:21 --> Config Class Initialized
INFO - 2020-08-20 22:41:21 --> Loader Class Initialized
INFO - 2020-08-20 22:41:21 --> Helper loaded: url_helper
INFO - 2020-08-20 22:41:21 --> Helper loaded: form_helper
INFO - 2020-08-20 22:41:21 --> Helper loaded: file_helper
INFO - 2020-08-20 22:41:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 22:41:21 --> Database Driver Class Initialized
DEBUG - 2020-08-20 22:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 22:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 22:41:21 --> Upload Class Initialized
INFO - 2020-08-20 22:41:21 --> Controller Class Initialized
ERROR - 2020-08-20 22:41:21 --> 404 Page Not Found: /index
INFO - 2020-08-20 23:13:56 --> Config Class Initialized
INFO - 2020-08-20 23:13:56 --> Hooks Class Initialized
DEBUG - 2020-08-20 23:13:56 --> UTF-8 Support Enabled
INFO - 2020-08-20 23:13:56 --> Utf8 Class Initialized
INFO - 2020-08-20 23:13:56 --> URI Class Initialized
INFO - 2020-08-20 23:13:56 --> Router Class Initialized
INFO - 2020-08-20 23:13:56 --> Output Class Initialized
INFO - 2020-08-20 23:13:56 --> Security Class Initialized
DEBUG - 2020-08-20 23:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 23:13:56 --> Input Class Initialized
INFO - 2020-08-20 23:13:56 --> Language Class Initialized
INFO - 2020-08-20 23:13:56 --> Language Class Initialized
INFO - 2020-08-20 23:13:56 --> Config Class Initialized
INFO - 2020-08-20 23:13:56 --> Loader Class Initialized
INFO - 2020-08-20 23:13:56 --> Helper loaded: url_helper
INFO - 2020-08-20 23:13:56 --> Helper loaded: form_helper
INFO - 2020-08-20 23:13:56 --> Helper loaded: file_helper
INFO - 2020-08-20 23:13:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-20 23:13:56 --> Database Driver Class Initialized
DEBUG - 2020-08-20 23:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-20 23:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 23:13:56 --> Upload Class Initialized
INFO - 2020-08-20 23:13:56 --> Controller Class Initialized
ERROR - 2020-08-20 23:13:56 --> 404 Page Not Found: /index
