<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-21 00:22:12 --> Config Class Initialized
INFO - 2020-08-21 00:22:12 --> Hooks Class Initialized
DEBUG - 2020-08-21 00:22:12 --> UTF-8 Support Enabled
INFO - 2020-08-21 00:22:12 --> Utf8 Class Initialized
INFO - 2020-08-21 00:22:12 --> URI Class Initialized
DEBUG - 2020-08-21 00:22:12 --> No URI present. Default controller set.
INFO - 2020-08-21 00:22:12 --> Router Class Initialized
INFO - 2020-08-21 00:22:12 --> Output Class Initialized
INFO - 2020-08-21 00:22:12 --> Security Class Initialized
DEBUG - 2020-08-21 00:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 00:22:12 --> Input Class Initialized
INFO - 2020-08-21 00:22:12 --> Language Class Initialized
INFO - 2020-08-21 00:22:12 --> Language Class Initialized
INFO - 2020-08-21 00:22:12 --> Config Class Initialized
INFO - 2020-08-21 00:22:12 --> Loader Class Initialized
INFO - 2020-08-21 00:22:12 --> Helper loaded: url_helper
INFO - 2020-08-21 00:22:12 --> Helper loaded: form_helper
INFO - 2020-08-21 00:22:12 --> Helper loaded: file_helper
INFO - 2020-08-21 00:22:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 00:22:12 --> Database Driver Class Initialized
DEBUG - 2020-08-21 00:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 00:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 00:22:12 --> Upload Class Initialized
INFO - 2020-08-21 00:22:12 --> Controller Class Initialized
DEBUG - 2020-08-21 00:22:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 00:22:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 00:22:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 00:22:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 00:22:12 --> Final output sent to browser
DEBUG - 2020-08-21 00:22:12 --> Total execution time: 0.0573
INFO - 2020-08-21 01:21:18 --> Config Class Initialized
INFO - 2020-08-21 01:21:18 --> Hooks Class Initialized
DEBUG - 2020-08-21 01:21:18 --> UTF-8 Support Enabled
INFO - 2020-08-21 01:21:18 --> Utf8 Class Initialized
INFO - 2020-08-21 01:21:18 --> URI Class Initialized
DEBUG - 2020-08-21 01:21:18 --> No URI present. Default controller set.
INFO - 2020-08-21 01:21:18 --> Router Class Initialized
INFO - 2020-08-21 01:21:18 --> Output Class Initialized
INFO - 2020-08-21 01:21:18 --> Security Class Initialized
DEBUG - 2020-08-21 01:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 01:21:18 --> Input Class Initialized
INFO - 2020-08-21 01:21:18 --> Language Class Initialized
INFO - 2020-08-21 01:21:18 --> Language Class Initialized
INFO - 2020-08-21 01:21:18 --> Config Class Initialized
INFO - 2020-08-21 01:21:18 --> Loader Class Initialized
INFO - 2020-08-21 01:21:18 --> Helper loaded: url_helper
INFO - 2020-08-21 01:21:18 --> Helper loaded: form_helper
INFO - 2020-08-21 01:21:18 --> Helper loaded: file_helper
INFO - 2020-08-21 01:21:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 01:21:18 --> Database Driver Class Initialized
DEBUG - 2020-08-21 01:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 01:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 01:21:18 --> Upload Class Initialized
INFO - 2020-08-21 01:21:18 --> Controller Class Initialized
DEBUG - 2020-08-21 01:21:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 01:21:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 01:21:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 01:21:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 01:21:18 --> Final output sent to browser
DEBUG - 2020-08-21 01:21:18 --> Total execution time: 0.0523
INFO - 2020-08-21 01:26:56 --> Config Class Initialized
INFO - 2020-08-21 01:26:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 01:26:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 01:26:56 --> Utf8 Class Initialized
INFO - 2020-08-21 01:26:56 --> URI Class Initialized
DEBUG - 2020-08-21 01:26:56 --> No URI present. Default controller set.
INFO - 2020-08-21 01:26:56 --> Router Class Initialized
INFO - 2020-08-21 01:26:56 --> Output Class Initialized
INFO - 2020-08-21 01:26:56 --> Security Class Initialized
DEBUG - 2020-08-21 01:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 01:26:56 --> Input Class Initialized
INFO - 2020-08-21 01:26:56 --> Language Class Initialized
INFO - 2020-08-21 01:26:56 --> Language Class Initialized
INFO - 2020-08-21 01:26:56 --> Config Class Initialized
INFO - 2020-08-21 01:26:56 --> Loader Class Initialized
INFO - 2020-08-21 01:26:56 --> Helper loaded: url_helper
INFO - 2020-08-21 01:26:56 --> Helper loaded: form_helper
INFO - 2020-08-21 01:26:56 --> Helper loaded: file_helper
INFO - 2020-08-21 01:26:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 01:26:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 01:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 01:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 01:26:56 --> Upload Class Initialized
INFO - 2020-08-21 01:26:56 --> Controller Class Initialized
DEBUG - 2020-08-21 01:26:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 01:26:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 01:26:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 01:26:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 01:26:56 --> Final output sent to browser
DEBUG - 2020-08-21 01:26:56 --> Total execution time: 0.0832
INFO - 2020-08-21 02:48:36 --> Config Class Initialized
INFO - 2020-08-21 02:48:36 --> Hooks Class Initialized
DEBUG - 2020-08-21 02:48:36 --> UTF-8 Support Enabled
INFO - 2020-08-21 02:48:36 --> Utf8 Class Initialized
INFO - 2020-08-21 02:48:36 --> URI Class Initialized
DEBUG - 2020-08-21 02:48:36 --> No URI present. Default controller set.
INFO - 2020-08-21 02:48:36 --> Router Class Initialized
INFO - 2020-08-21 02:48:36 --> Output Class Initialized
INFO - 2020-08-21 02:48:36 --> Security Class Initialized
DEBUG - 2020-08-21 02:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 02:48:36 --> Input Class Initialized
INFO - 2020-08-21 02:48:36 --> Language Class Initialized
INFO - 2020-08-21 02:48:36 --> Language Class Initialized
INFO - 2020-08-21 02:48:36 --> Config Class Initialized
INFO - 2020-08-21 02:48:36 --> Loader Class Initialized
INFO - 2020-08-21 02:48:36 --> Helper loaded: url_helper
INFO - 2020-08-21 02:48:36 --> Helper loaded: form_helper
INFO - 2020-08-21 02:48:36 --> Helper loaded: file_helper
INFO - 2020-08-21 02:48:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 02:48:36 --> Database Driver Class Initialized
DEBUG - 2020-08-21 02:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 02:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 02:48:36 --> Upload Class Initialized
INFO - 2020-08-21 02:48:36 --> Controller Class Initialized
DEBUG - 2020-08-21 02:48:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 02:48:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 02:48:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 02:48:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 02:48:36 --> Final output sent to browser
DEBUG - 2020-08-21 02:48:36 --> Total execution time: 0.0489
INFO - 2020-08-21 02:51:53 --> Config Class Initialized
INFO - 2020-08-21 02:51:53 --> Hooks Class Initialized
DEBUG - 2020-08-21 02:51:53 --> UTF-8 Support Enabled
INFO - 2020-08-21 02:51:53 --> Utf8 Class Initialized
INFO - 2020-08-21 02:51:53 --> URI Class Initialized
DEBUG - 2020-08-21 02:51:53 --> No URI present. Default controller set.
INFO - 2020-08-21 02:51:53 --> Router Class Initialized
INFO - 2020-08-21 02:51:53 --> Output Class Initialized
INFO - 2020-08-21 02:51:53 --> Security Class Initialized
DEBUG - 2020-08-21 02:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 02:51:53 --> Input Class Initialized
INFO - 2020-08-21 02:51:53 --> Language Class Initialized
INFO - 2020-08-21 02:51:53 --> Language Class Initialized
INFO - 2020-08-21 02:51:53 --> Config Class Initialized
INFO - 2020-08-21 02:51:53 --> Loader Class Initialized
INFO - 2020-08-21 02:51:53 --> Helper loaded: url_helper
INFO - 2020-08-21 02:51:53 --> Helper loaded: form_helper
INFO - 2020-08-21 02:51:53 --> Helper loaded: file_helper
INFO - 2020-08-21 02:51:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 02:51:53 --> Database Driver Class Initialized
DEBUG - 2020-08-21 02:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 02:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 02:51:53 --> Upload Class Initialized
INFO - 2020-08-21 02:51:53 --> Controller Class Initialized
DEBUG - 2020-08-21 02:51:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 02:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 02:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 02:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 02:51:53 --> Final output sent to browser
DEBUG - 2020-08-21 02:51:53 --> Total execution time: 0.0525
INFO - 2020-08-21 02:52:00 --> Config Class Initialized
INFO - 2020-08-21 02:52:00 --> Hooks Class Initialized
DEBUG - 2020-08-21 02:52:00 --> UTF-8 Support Enabled
INFO - 2020-08-21 02:52:00 --> Utf8 Class Initialized
INFO - 2020-08-21 02:52:00 --> URI Class Initialized
INFO - 2020-08-21 02:52:00 --> Router Class Initialized
INFO - 2020-08-21 02:52:00 --> Output Class Initialized
INFO - 2020-08-21 02:52:00 --> Security Class Initialized
DEBUG - 2020-08-21 02:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 02:52:00 --> Input Class Initialized
INFO - 2020-08-21 02:52:00 --> Language Class Initialized
INFO - 2020-08-21 02:52:00 --> Language Class Initialized
INFO - 2020-08-21 02:52:00 --> Config Class Initialized
INFO - 2020-08-21 02:52:00 --> Loader Class Initialized
INFO - 2020-08-21 02:52:00 --> Helper loaded: url_helper
INFO - 2020-08-21 02:52:00 --> Helper loaded: form_helper
INFO - 2020-08-21 02:52:00 --> Helper loaded: file_helper
INFO - 2020-08-21 02:52:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 02:52:00 --> Database Driver Class Initialized
DEBUG - 2020-08-21 02:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 02:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 02:52:00 --> Upload Class Initialized
INFO - 2020-08-21 02:52:00 --> Controller Class Initialized
ERROR - 2020-08-21 02:52:00 --> 404 Page Not Found: /index
INFO - 2020-08-21 02:52:09 --> Config Class Initialized
INFO - 2020-08-21 02:52:09 --> Hooks Class Initialized
DEBUG - 2020-08-21 02:52:09 --> UTF-8 Support Enabled
INFO - 2020-08-21 02:52:09 --> Utf8 Class Initialized
INFO - 2020-08-21 02:52:09 --> URI Class Initialized
INFO - 2020-08-21 02:52:09 --> Router Class Initialized
INFO - 2020-08-21 02:52:09 --> Output Class Initialized
INFO - 2020-08-21 02:52:09 --> Security Class Initialized
DEBUG - 2020-08-21 02:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 02:52:09 --> Input Class Initialized
INFO - 2020-08-21 02:52:09 --> Language Class Initialized
INFO - 2020-08-21 02:52:09 --> Language Class Initialized
INFO - 2020-08-21 02:52:09 --> Config Class Initialized
INFO - 2020-08-21 02:52:09 --> Loader Class Initialized
INFO - 2020-08-21 02:52:09 --> Helper loaded: url_helper
INFO - 2020-08-21 02:52:09 --> Helper loaded: form_helper
INFO - 2020-08-21 02:52:09 --> Helper loaded: file_helper
INFO - 2020-08-21 02:52:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 02:52:09 --> Database Driver Class Initialized
DEBUG - 2020-08-21 02:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 02:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 02:52:09 --> Upload Class Initialized
INFO - 2020-08-21 02:52:09 --> Controller Class Initialized
ERROR - 2020-08-21 02:52:09 --> 404 Page Not Found: /index
INFO - 2020-08-21 02:52:11 --> Config Class Initialized
INFO - 2020-08-21 02:52:11 --> Hooks Class Initialized
DEBUG - 2020-08-21 02:52:11 --> UTF-8 Support Enabled
INFO - 2020-08-21 02:52:11 --> Utf8 Class Initialized
INFO - 2020-08-21 02:52:11 --> URI Class Initialized
DEBUG - 2020-08-21 02:52:11 --> No URI present. Default controller set.
INFO - 2020-08-21 02:52:11 --> Router Class Initialized
INFO - 2020-08-21 02:52:11 --> Output Class Initialized
INFO - 2020-08-21 02:52:11 --> Security Class Initialized
DEBUG - 2020-08-21 02:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 02:52:11 --> Input Class Initialized
INFO - 2020-08-21 02:52:11 --> Language Class Initialized
INFO - 2020-08-21 02:52:11 --> Language Class Initialized
INFO - 2020-08-21 02:52:11 --> Config Class Initialized
INFO - 2020-08-21 02:52:11 --> Loader Class Initialized
INFO - 2020-08-21 02:52:11 --> Helper loaded: url_helper
INFO - 2020-08-21 02:52:11 --> Helper loaded: form_helper
INFO - 2020-08-21 02:52:11 --> Helper loaded: file_helper
INFO - 2020-08-21 02:52:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 02:52:11 --> Database Driver Class Initialized
DEBUG - 2020-08-21 02:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 02:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 02:52:11 --> Upload Class Initialized
INFO - 2020-08-21 02:52:11 --> Controller Class Initialized
DEBUG - 2020-08-21 02:52:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 02:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 02:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 02:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 02:52:11 --> Final output sent to browser
DEBUG - 2020-08-21 02:52:11 --> Total execution time: 0.0538
INFO - 2020-08-21 04:53:43 --> Config Class Initialized
INFO - 2020-08-21 04:53:43 --> Hooks Class Initialized
DEBUG - 2020-08-21 04:53:43 --> UTF-8 Support Enabled
INFO - 2020-08-21 04:53:43 --> Utf8 Class Initialized
INFO - 2020-08-21 04:53:43 --> URI Class Initialized
INFO - 2020-08-21 04:53:43 --> Router Class Initialized
INFO - 2020-08-21 04:53:43 --> Output Class Initialized
INFO - 2020-08-21 04:53:43 --> Security Class Initialized
DEBUG - 2020-08-21 04:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 04:53:43 --> Input Class Initialized
INFO - 2020-08-21 04:53:43 --> Language Class Initialized
INFO - 2020-08-21 04:53:43 --> Language Class Initialized
INFO - 2020-08-21 04:53:43 --> Config Class Initialized
INFO - 2020-08-21 04:53:43 --> Loader Class Initialized
INFO - 2020-08-21 04:53:43 --> Helper loaded: url_helper
INFO - 2020-08-21 04:53:43 --> Helper loaded: form_helper
INFO - 2020-08-21 04:53:43 --> Helper loaded: file_helper
INFO - 2020-08-21 04:53:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 04:53:43 --> Database Driver Class Initialized
DEBUG - 2020-08-21 04:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 04:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 04:53:43 --> Upload Class Initialized
INFO - 2020-08-21 04:53:43 --> Controller Class Initialized
ERROR - 2020-08-21 04:53:43 --> 404 Page Not Found: /index
INFO - 2020-08-21 08:02:56 --> Config Class Initialized
INFO - 2020-08-21 08:02:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 08:02:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 08:02:56 --> Utf8 Class Initialized
INFO - 2020-08-21 08:02:56 --> URI Class Initialized
DEBUG - 2020-08-21 08:02:56 --> No URI present. Default controller set.
INFO - 2020-08-21 08:02:56 --> Router Class Initialized
INFO - 2020-08-21 08:02:56 --> Output Class Initialized
INFO - 2020-08-21 08:02:56 --> Security Class Initialized
DEBUG - 2020-08-21 08:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 08:02:56 --> Input Class Initialized
INFO - 2020-08-21 08:02:56 --> Language Class Initialized
INFO - 2020-08-21 08:02:56 --> Language Class Initialized
INFO - 2020-08-21 08:02:56 --> Config Class Initialized
INFO - 2020-08-21 08:02:56 --> Loader Class Initialized
INFO - 2020-08-21 08:02:56 --> Helper loaded: url_helper
INFO - 2020-08-21 08:02:56 --> Helper loaded: form_helper
INFO - 2020-08-21 08:02:56 --> Helper loaded: file_helper
INFO - 2020-08-21 08:02:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 08:02:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 08:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 08:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 08:02:56 --> Upload Class Initialized
INFO - 2020-08-21 08:02:56 --> Controller Class Initialized
DEBUG - 2020-08-21 08:02:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 08:02:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 08:02:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 08:02:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 08:02:56 --> Final output sent to browser
DEBUG - 2020-08-21 08:02:56 --> Total execution time: 0.0488
INFO - 2020-08-21 08:55:00 --> Config Class Initialized
INFO - 2020-08-21 08:55:00 --> Hooks Class Initialized
DEBUG - 2020-08-21 08:55:00 --> UTF-8 Support Enabled
INFO - 2020-08-21 08:55:00 --> Utf8 Class Initialized
INFO - 2020-08-21 08:55:00 --> URI Class Initialized
DEBUG - 2020-08-21 08:55:00 --> No URI present. Default controller set.
INFO - 2020-08-21 08:55:00 --> Router Class Initialized
INFO - 2020-08-21 08:55:00 --> Output Class Initialized
INFO - 2020-08-21 08:55:00 --> Security Class Initialized
DEBUG - 2020-08-21 08:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 08:55:00 --> Input Class Initialized
INFO - 2020-08-21 08:55:00 --> Language Class Initialized
INFO - 2020-08-21 08:55:00 --> Language Class Initialized
INFO - 2020-08-21 08:55:00 --> Config Class Initialized
INFO - 2020-08-21 08:55:00 --> Loader Class Initialized
INFO - 2020-08-21 08:55:00 --> Helper loaded: url_helper
INFO - 2020-08-21 08:55:00 --> Helper loaded: form_helper
INFO - 2020-08-21 08:55:00 --> Helper loaded: file_helper
INFO - 2020-08-21 08:55:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 08:55:00 --> Database Driver Class Initialized
DEBUG - 2020-08-21 08:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 08:55:00 --> Upload Class Initialized
INFO - 2020-08-21 08:55:00 --> Controller Class Initialized
DEBUG - 2020-08-21 08:55:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 08:55:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 08:55:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 08:55:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 08:55:00 --> Final output sent to browser
DEBUG - 2020-08-21 08:55:00 --> Total execution time: 0.1637
INFO - 2020-08-21 08:55:04 --> Config Class Initialized
INFO - 2020-08-21 08:55:04 --> Hooks Class Initialized
DEBUG - 2020-08-21 08:55:04 --> UTF-8 Support Enabled
INFO - 2020-08-21 08:55:04 --> Utf8 Class Initialized
INFO - 2020-08-21 08:55:04 --> URI Class Initialized
DEBUG - 2020-08-21 08:55:04 --> No URI present. Default controller set.
INFO - 2020-08-21 08:55:04 --> Router Class Initialized
INFO - 2020-08-21 08:55:04 --> Output Class Initialized
INFO - 2020-08-21 08:55:04 --> Security Class Initialized
DEBUG - 2020-08-21 08:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 08:55:04 --> Input Class Initialized
INFO - 2020-08-21 08:55:04 --> Language Class Initialized
INFO - 2020-08-21 08:55:04 --> Language Class Initialized
INFO - 2020-08-21 08:55:04 --> Config Class Initialized
INFO - 2020-08-21 08:55:04 --> Loader Class Initialized
INFO - 2020-08-21 08:55:04 --> Helper loaded: url_helper
INFO - 2020-08-21 08:55:04 --> Helper loaded: form_helper
INFO - 2020-08-21 08:55:04 --> Helper loaded: file_helper
INFO - 2020-08-21 08:55:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 08:55:04 --> Database Driver Class Initialized
DEBUG - 2020-08-21 08:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 08:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 08:55:04 --> Upload Class Initialized
INFO - 2020-08-21 08:55:04 --> Controller Class Initialized
DEBUG - 2020-08-21 08:55:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 08:55:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 08:55:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 08:55:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 08:55:04 --> Final output sent to browser
DEBUG - 2020-08-21 08:55:04 --> Total execution time: 0.0984
INFO - 2020-08-21 08:55:14 --> Config Class Initialized
INFO - 2020-08-21 08:55:14 --> Hooks Class Initialized
DEBUG - 2020-08-21 08:55:14 --> UTF-8 Support Enabled
INFO - 2020-08-21 08:55:14 --> Utf8 Class Initialized
INFO - 2020-08-21 08:55:14 --> URI Class Initialized
INFO - 2020-08-21 08:55:14 --> Router Class Initialized
INFO - 2020-08-21 08:55:14 --> Output Class Initialized
INFO - 2020-08-21 08:55:14 --> Security Class Initialized
DEBUG - 2020-08-21 08:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 08:55:14 --> Input Class Initialized
INFO - 2020-08-21 08:55:14 --> Language Class Initialized
INFO - 2020-08-21 08:55:14 --> Language Class Initialized
INFO - 2020-08-21 08:55:14 --> Config Class Initialized
INFO - 2020-08-21 08:55:14 --> Loader Class Initialized
INFO - 2020-08-21 08:55:14 --> Helper loaded: url_helper
INFO - 2020-08-21 08:55:14 --> Helper loaded: form_helper
INFO - 2020-08-21 08:55:14 --> Helper loaded: file_helper
INFO - 2020-08-21 08:55:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 08:55:14 --> Database Driver Class Initialized
DEBUG - 2020-08-21 08:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 08:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 08:55:14 --> Upload Class Initialized
INFO - 2020-08-21 08:55:14 --> Controller Class Initialized
ERROR - 2020-08-21 08:55:14 --> 404 Page Not Found: /index
INFO - 2020-08-21 08:57:31 --> Config Class Initialized
INFO - 2020-08-21 08:57:31 --> Hooks Class Initialized
DEBUG - 2020-08-21 08:57:31 --> UTF-8 Support Enabled
INFO - 2020-08-21 08:57:31 --> Utf8 Class Initialized
INFO - 2020-08-21 08:57:31 --> URI Class Initialized
INFO - 2020-08-21 08:57:31 --> Router Class Initialized
INFO - 2020-08-21 08:57:31 --> Output Class Initialized
INFO - 2020-08-21 08:57:31 --> Security Class Initialized
DEBUG - 2020-08-21 08:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 08:57:31 --> Input Class Initialized
INFO - 2020-08-21 08:57:31 --> Language Class Initialized
INFO - 2020-08-21 08:57:31 --> Language Class Initialized
INFO - 2020-08-21 08:57:31 --> Config Class Initialized
INFO - 2020-08-21 08:57:31 --> Loader Class Initialized
INFO - 2020-08-21 08:57:31 --> Helper loaded: url_helper
INFO - 2020-08-21 08:57:31 --> Helper loaded: form_helper
INFO - 2020-08-21 08:57:31 --> Helper loaded: file_helper
INFO - 2020-08-21 08:57:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 08:57:31 --> Database Driver Class Initialized
DEBUG - 2020-08-21 08:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 08:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 08:57:31 --> Upload Class Initialized
INFO - 2020-08-21 08:57:31 --> Controller Class Initialized
ERROR - 2020-08-21 08:57:31 --> 404 Page Not Found: /index
INFO - 2020-08-21 08:57:32 --> Config Class Initialized
INFO - 2020-08-21 08:57:32 --> Hooks Class Initialized
DEBUG - 2020-08-21 08:57:32 --> UTF-8 Support Enabled
INFO - 2020-08-21 08:57:32 --> Utf8 Class Initialized
INFO - 2020-08-21 08:57:32 --> URI Class Initialized
INFO - 2020-08-21 08:57:32 --> Router Class Initialized
INFO - 2020-08-21 08:57:32 --> Output Class Initialized
INFO - 2020-08-21 08:57:32 --> Security Class Initialized
DEBUG - 2020-08-21 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 08:57:32 --> Input Class Initialized
INFO - 2020-08-21 08:57:32 --> Language Class Initialized
INFO - 2020-08-21 08:57:32 --> Language Class Initialized
INFO - 2020-08-21 08:57:32 --> Config Class Initialized
INFO - 2020-08-21 08:57:32 --> Loader Class Initialized
INFO - 2020-08-21 08:57:32 --> Helper loaded: url_helper
INFO - 2020-08-21 08:57:32 --> Helper loaded: form_helper
INFO - 2020-08-21 08:57:32 --> Helper loaded: file_helper
INFO - 2020-08-21 08:57:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 08:57:32 --> Database Driver Class Initialized
DEBUG - 2020-08-21 08:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 08:57:32 --> Upload Class Initialized
INFO - 2020-08-21 08:57:32 --> Controller Class Initialized
ERROR - 2020-08-21 08:57:32 --> 404 Page Not Found: /index
INFO - 2020-08-21 09:03:15 --> Config Class Initialized
INFO - 2020-08-21 09:03:15 --> Hooks Class Initialized
DEBUG - 2020-08-21 09:03:15 --> UTF-8 Support Enabled
INFO - 2020-08-21 09:03:15 --> Utf8 Class Initialized
INFO - 2020-08-21 09:03:15 --> URI Class Initialized
DEBUG - 2020-08-21 09:03:15 --> No URI present. Default controller set.
INFO - 2020-08-21 09:03:15 --> Router Class Initialized
INFO - 2020-08-21 09:03:15 --> Output Class Initialized
INFO - 2020-08-21 09:03:15 --> Security Class Initialized
DEBUG - 2020-08-21 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 09:03:15 --> Input Class Initialized
INFO - 2020-08-21 09:03:15 --> Language Class Initialized
INFO - 2020-08-21 09:03:15 --> Language Class Initialized
INFO - 2020-08-21 09:03:15 --> Config Class Initialized
INFO - 2020-08-21 09:03:15 --> Loader Class Initialized
INFO - 2020-08-21 09:03:15 --> Helper loaded: url_helper
INFO - 2020-08-21 09:03:15 --> Helper loaded: form_helper
INFO - 2020-08-21 09:03:15 --> Helper loaded: file_helper
INFO - 2020-08-21 09:03:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 09:03:15 --> Database Driver Class Initialized
DEBUG - 2020-08-21 09:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 09:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 09:03:15 --> Upload Class Initialized
INFO - 2020-08-21 09:03:15 --> Controller Class Initialized
DEBUG - 2020-08-21 09:03:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 09:03:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 09:03:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 09:03:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 09:03:15 --> Final output sent to browser
DEBUG - 2020-08-21 09:03:15 --> Total execution time: 0.0533
INFO - 2020-08-21 09:03:17 --> Config Class Initialized
INFO - 2020-08-21 09:03:17 --> Hooks Class Initialized
DEBUG - 2020-08-21 09:03:17 --> UTF-8 Support Enabled
INFO - 2020-08-21 09:03:17 --> Utf8 Class Initialized
INFO - 2020-08-21 09:03:17 --> URI Class Initialized
INFO - 2020-08-21 09:03:17 --> Router Class Initialized
INFO - 2020-08-21 09:03:17 --> Output Class Initialized
INFO - 2020-08-21 09:03:17 --> Security Class Initialized
DEBUG - 2020-08-21 09:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 09:03:17 --> Input Class Initialized
INFO - 2020-08-21 09:03:17 --> Language Class Initialized
INFO - 2020-08-21 09:03:17 --> Language Class Initialized
INFO - 2020-08-21 09:03:17 --> Config Class Initialized
INFO - 2020-08-21 09:03:17 --> Loader Class Initialized
INFO - 2020-08-21 09:03:17 --> Helper loaded: url_helper
INFO - 2020-08-21 09:03:17 --> Helper loaded: form_helper
INFO - 2020-08-21 09:03:17 --> Helper loaded: file_helper
INFO - 2020-08-21 09:03:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 09:03:17 --> Database Driver Class Initialized
DEBUG - 2020-08-21 09:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 09:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 09:03:17 --> Upload Class Initialized
INFO - 2020-08-21 09:03:17 --> Controller Class Initialized
ERROR - 2020-08-21 09:03:17 --> 404 Page Not Found: /index
INFO - 2020-08-21 09:03:18 --> Config Class Initialized
INFO - 2020-08-21 09:03:18 --> Hooks Class Initialized
DEBUG - 2020-08-21 09:03:18 --> UTF-8 Support Enabled
INFO - 2020-08-21 09:03:18 --> Utf8 Class Initialized
INFO - 2020-08-21 09:03:18 --> URI Class Initialized
INFO - 2020-08-21 09:03:18 --> Router Class Initialized
INFO - 2020-08-21 09:03:18 --> Output Class Initialized
INFO - 2020-08-21 09:03:18 --> Security Class Initialized
DEBUG - 2020-08-21 09:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 09:03:18 --> Input Class Initialized
INFO - 2020-08-21 09:03:18 --> Language Class Initialized
INFO - 2020-08-21 09:03:18 --> Language Class Initialized
INFO - 2020-08-21 09:03:18 --> Config Class Initialized
INFO - 2020-08-21 09:03:18 --> Loader Class Initialized
INFO - 2020-08-21 09:03:18 --> Helper loaded: url_helper
INFO - 2020-08-21 09:03:18 --> Helper loaded: form_helper
INFO - 2020-08-21 09:03:18 --> Helper loaded: file_helper
INFO - 2020-08-21 09:03:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 09:03:18 --> Database Driver Class Initialized
DEBUG - 2020-08-21 09:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 09:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 09:03:18 --> Upload Class Initialized
INFO - 2020-08-21 09:03:18 --> Controller Class Initialized
ERROR - 2020-08-21 09:03:18 --> 404 Page Not Found: /index
INFO - 2020-08-21 09:03:20 --> Config Class Initialized
INFO - 2020-08-21 09:03:20 --> Hooks Class Initialized
DEBUG - 2020-08-21 09:03:20 --> UTF-8 Support Enabled
INFO - 2020-08-21 09:03:20 --> Utf8 Class Initialized
INFO - 2020-08-21 09:03:20 --> URI Class Initialized
DEBUG - 2020-08-21 09:03:20 --> No URI present. Default controller set.
INFO - 2020-08-21 09:03:20 --> Router Class Initialized
INFO - 2020-08-21 09:03:20 --> Output Class Initialized
INFO - 2020-08-21 09:03:20 --> Security Class Initialized
DEBUG - 2020-08-21 09:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 09:03:20 --> Input Class Initialized
INFO - 2020-08-21 09:03:20 --> Language Class Initialized
INFO - 2020-08-21 09:03:20 --> Language Class Initialized
INFO - 2020-08-21 09:03:20 --> Config Class Initialized
INFO - 2020-08-21 09:03:20 --> Loader Class Initialized
INFO - 2020-08-21 09:03:20 --> Helper loaded: url_helper
INFO - 2020-08-21 09:03:20 --> Helper loaded: form_helper
INFO - 2020-08-21 09:03:20 --> Helper loaded: file_helper
INFO - 2020-08-21 09:03:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 09:03:20 --> Database Driver Class Initialized
DEBUG - 2020-08-21 09:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 09:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 09:03:20 --> Upload Class Initialized
INFO - 2020-08-21 09:03:20 --> Controller Class Initialized
DEBUG - 2020-08-21 09:03:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 09:03:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 09:03:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 09:03:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 09:03:20 --> Final output sent to browser
DEBUG - 2020-08-21 09:03:20 --> Total execution time: 0.0529
INFO - 2020-08-21 09:26:21 --> Config Class Initialized
INFO - 2020-08-21 09:26:21 --> Hooks Class Initialized
DEBUG - 2020-08-21 09:26:21 --> UTF-8 Support Enabled
INFO - 2020-08-21 09:26:21 --> Utf8 Class Initialized
INFO - 2020-08-21 09:26:21 --> URI Class Initialized
INFO - 2020-08-21 09:26:21 --> Router Class Initialized
INFO - 2020-08-21 09:26:21 --> Output Class Initialized
INFO - 2020-08-21 09:26:21 --> Security Class Initialized
DEBUG - 2020-08-21 09:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 09:26:21 --> Input Class Initialized
INFO - 2020-08-21 09:26:21 --> Language Class Initialized
INFO - 2020-08-21 09:26:21 --> Language Class Initialized
INFO - 2020-08-21 09:26:21 --> Config Class Initialized
INFO - 2020-08-21 09:26:21 --> Loader Class Initialized
INFO - 2020-08-21 09:26:21 --> Helper loaded: url_helper
INFO - 2020-08-21 09:26:21 --> Helper loaded: form_helper
INFO - 2020-08-21 09:26:21 --> Helper loaded: file_helper
INFO - 2020-08-21 09:26:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 09:26:21 --> Database Driver Class Initialized
DEBUG - 2020-08-21 09:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 09:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 09:26:21 --> Upload Class Initialized
INFO - 2020-08-21 09:26:21 --> Controller Class Initialized
ERROR - 2020-08-21 09:26:21 --> 404 Page Not Found: /index
INFO - 2020-08-21 09:58:10 --> Config Class Initialized
INFO - 2020-08-21 09:58:10 --> Hooks Class Initialized
DEBUG - 2020-08-21 09:58:10 --> UTF-8 Support Enabled
INFO - 2020-08-21 09:58:10 --> Utf8 Class Initialized
INFO - 2020-08-21 09:58:10 --> URI Class Initialized
DEBUG - 2020-08-21 09:58:10 --> No URI present. Default controller set.
INFO - 2020-08-21 09:58:10 --> Router Class Initialized
INFO - 2020-08-21 09:58:10 --> Output Class Initialized
INFO - 2020-08-21 09:58:10 --> Security Class Initialized
DEBUG - 2020-08-21 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 09:58:10 --> Input Class Initialized
INFO - 2020-08-21 09:58:10 --> Language Class Initialized
INFO - 2020-08-21 09:58:10 --> Language Class Initialized
INFO - 2020-08-21 09:58:10 --> Config Class Initialized
INFO - 2020-08-21 09:58:10 --> Loader Class Initialized
INFO - 2020-08-21 09:58:10 --> Helper loaded: url_helper
INFO - 2020-08-21 09:58:10 --> Helper loaded: form_helper
INFO - 2020-08-21 09:58:10 --> Helper loaded: file_helper
INFO - 2020-08-21 09:58:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 09:58:10 --> Database Driver Class Initialized
DEBUG - 2020-08-21 09:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 09:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 09:58:10 --> Upload Class Initialized
INFO - 2020-08-21 09:58:10 --> Controller Class Initialized
DEBUG - 2020-08-21 09:58:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 09:58:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 09:58:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 09:58:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 09:58:10 --> Final output sent to browser
DEBUG - 2020-08-21 09:58:10 --> Total execution time: 0.0512
INFO - 2020-08-21 10:57:35 --> Config Class Initialized
INFO - 2020-08-21 10:57:35 --> Hooks Class Initialized
DEBUG - 2020-08-21 10:57:35 --> UTF-8 Support Enabled
INFO - 2020-08-21 10:57:35 --> Utf8 Class Initialized
INFO - 2020-08-21 10:57:35 --> URI Class Initialized
DEBUG - 2020-08-21 10:57:35 --> No URI present. Default controller set.
INFO - 2020-08-21 10:57:35 --> Router Class Initialized
INFO - 2020-08-21 10:57:35 --> Output Class Initialized
INFO - 2020-08-21 10:57:35 --> Security Class Initialized
DEBUG - 2020-08-21 10:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 10:57:35 --> Input Class Initialized
INFO - 2020-08-21 10:57:35 --> Language Class Initialized
INFO - 2020-08-21 10:57:35 --> Language Class Initialized
INFO - 2020-08-21 10:57:35 --> Config Class Initialized
INFO - 2020-08-21 10:57:35 --> Loader Class Initialized
INFO - 2020-08-21 10:57:35 --> Helper loaded: url_helper
INFO - 2020-08-21 10:57:35 --> Helper loaded: form_helper
INFO - 2020-08-21 10:57:35 --> Helper loaded: file_helper
INFO - 2020-08-21 10:57:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 10:57:35 --> Database Driver Class Initialized
DEBUG - 2020-08-21 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 10:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 10:57:35 --> Upload Class Initialized
INFO - 2020-08-21 10:57:35 --> Controller Class Initialized
DEBUG - 2020-08-21 10:57:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 10:57:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 10:57:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 10:57:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 10:57:35 --> Final output sent to browser
DEBUG - 2020-08-21 10:57:35 --> Total execution time: 0.0493
INFO - 2020-08-21 11:04:21 --> Config Class Initialized
INFO - 2020-08-21 11:04:21 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:04:21 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:04:21 --> Utf8 Class Initialized
INFO - 2020-08-21 11:04:21 --> URI Class Initialized
DEBUG - 2020-08-21 11:04:21 --> No URI present. Default controller set.
INFO - 2020-08-21 11:04:21 --> Router Class Initialized
INFO - 2020-08-21 11:04:21 --> Output Class Initialized
INFO - 2020-08-21 11:04:21 --> Security Class Initialized
DEBUG - 2020-08-21 11:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:04:21 --> Input Class Initialized
INFO - 2020-08-21 11:04:21 --> Language Class Initialized
INFO - 2020-08-21 11:04:21 --> Language Class Initialized
INFO - 2020-08-21 11:04:21 --> Config Class Initialized
INFO - 2020-08-21 11:04:21 --> Loader Class Initialized
INFO - 2020-08-21 11:04:21 --> Helper loaded: url_helper
INFO - 2020-08-21 11:04:21 --> Helper loaded: form_helper
INFO - 2020-08-21 11:04:21 --> Helper loaded: file_helper
INFO - 2020-08-21 11:04:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:04:21 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:04:21 --> Upload Class Initialized
INFO - 2020-08-21 11:04:21 --> Controller Class Initialized
DEBUG - 2020-08-21 11:04:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 11:04:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 11:04:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 11:04:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 11:04:21 --> Final output sent to browser
DEBUG - 2020-08-21 11:04:21 --> Total execution time: 0.0509
INFO - 2020-08-21 11:04:28 --> Config Class Initialized
INFO - 2020-08-21 11:04:28 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:04:28 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:04:28 --> Utf8 Class Initialized
INFO - 2020-08-21 11:04:28 --> URI Class Initialized
INFO - 2020-08-21 11:04:28 --> Router Class Initialized
INFO - 2020-08-21 11:04:28 --> Output Class Initialized
INFO - 2020-08-21 11:04:28 --> Security Class Initialized
DEBUG - 2020-08-21 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:04:28 --> Input Class Initialized
INFO - 2020-08-21 11:04:28 --> Language Class Initialized
INFO - 2020-08-21 11:04:28 --> Language Class Initialized
INFO - 2020-08-21 11:04:28 --> Config Class Initialized
INFO - 2020-08-21 11:04:28 --> Loader Class Initialized
INFO - 2020-08-21 11:04:28 --> Helper loaded: url_helper
INFO - 2020-08-21 11:04:28 --> Helper loaded: form_helper
INFO - 2020-08-21 11:04:28 --> Helper loaded: file_helper
INFO - 2020-08-21 11:04:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:04:28 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:04:28 --> Upload Class Initialized
INFO - 2020-08-21 11:04:28 --> Controller Class Initialized
ERROR - 2020-08-21 11:04:28 --> 404 Page Not Found: /index
INFO - 2020-08-21 11:27:44 --> Config Class Initialized
INFO - 2020-08-21 11:27:44 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:27:44 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:27:44 --> Utf8 Class Initialized
INFO - 2020-08-21 11:27:44 --> URI Class Initialized
DEBUG - 2020-08-21 11:27:44 --> No URI present. Default controller set.
INFO - 2020-08-21 11:27:44 --> Router Class Initialized
INFO - 2020-08-21 11:27:44 --> Output Class Initialized
INFO - 2020-08-21 11:27:44 --> Security Class Initialized
DEBUG - 2020-08-21 11:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:27:44 --> Input Class Initialized
INFO - 2020-08-21 11:27:44 --> Language Class Initialized
INFO - 2020-08-21 11:27:44 --> Language Class Initialized
INFO - 2020-08-21 11:27:44 --> Config Class Initialized
INFO - 2020-08-21 11:27:44 --> Loader Class Initialized
INFO - 2020-08-21 11:27:44 --> Helper loaded: url_helper
INFO - 2020-08-21 11:27:44 --> Helper loaded: form_helper
INFO - 2020-08-21 11:27:44 --> Helper loaded: file_helper
INFO - 2020-08-21 11:27:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:27:44 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:27:44 --> Upload Class Initialized
INFO - 2020-08-21 11:27:44 --> Controller Class Initialized
DEBUG - 2020-08-21 11:27:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 11:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 11:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 11:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 11:27:44 --> Final output sent to browser
DEBUG - 2020-08-21 11:27:44 --> Total execution time: 0.0568
INFO - 2020-08-21 11:27:44 --> Config Class Initialized
INFO - 2020-08-21 11:27:44 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:27:44 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:27:44 --> Utf8 Class Initialized
INFO - 2020-08-21 11:27:44 --> URI Class Initialized
DEBUG - 2020-08-21 11:27:44 --> No URI present. Default controller set.
INFO - 2020-08-21 11:27:44 --> Router Class Initialized
INFO - 2020-08-21 11:27:44 --> Output Class Initialized
INFO - 2020-08-21 11:27:44 --> Security Class Initialized
DEBUG - 2020-08-21 11:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:27:44 --> Input Class Initialized
INFO - 2020-08-21 11:27:44 --> Language Class Initialized
INFO - 2020-08-21 11:27:44 --> Language Class Initialized
INFO - 2020-08-21 11:27:44 --> Config Class Initialized
INFO - 2020-08-21 11:27:44 --> Loader Class Initialized
INFO - 2020-08-21 11:27:44 --> Helper loaded: url_helper
INFO - 2020-08-21 11:27:44 --> Helper loaded: form_helper
INFO - 2020-08-21 11:27:44 --> Helper loaded: file_helper
INFO - 2020-08-21 11:27:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:27:44 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:27:44 --> Upload Class Initialized
INFO - 2020-08-21 11:27:44 --> Controller Class Initialized
DEBUG - 2020-08-21 11:27:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 11:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 11:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 11:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 11:27:44 --> Final output sent to browser
DEBUG - 2020-08-21 11:27:44 --> Total execution time: 0.0509
INFO - 2020-08-21 11:27:45 --> Config Class Initialized
INFO - 2020-08-21 11:27:45 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:27:45 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:27:45 --> Utf8 Class Initialized
INFO - 2020-08-21 11:27:45 --> URI Class Initialized
INFO - 2020-08-21 11:27:45 --> Router Class Initialized
INFO - 2020-08-21 11:27:45 --> Output Class Initialized
INFO - 2020-08-21 11:27:45 --> Security Class Initialized
DEBUG - 2020-08-21 11:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:27:45 --> Input Class Initialized
INFO - 2020-08-21 11:27:45 --> Language Class Initialized
INFO - 2020-08-21 11:27:45 --> Language Class Initialized
INFO - 2020-08-21 11:27:45 --> Config Class Initialized
INFO - 2020-08-21 11:27:45 --> Loader Class Initialized
INFO - 2020-08-21 11:27:45 --> Helper loaded: url_helper
INFO - 2020-08-21 11:27:45 --> Helper loaded: form_helper
INFO - 2020-08-21 11:27:45 --> Helper loaded: file_helper
INFO - 2020-08-21 11:27:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:27:45 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:27:45 --> Upload Class Initialized
INFO - 2020-08-21 11:27:45 --> Controller Class Initialized
ERROR - 2020-08-21 11:27:45 --> 404 Page Not Found: /index
INFO - 2020-08-21 11:27:55 --> Config Class Initialized
INFO - 2020-08-21 11:27:55 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:27:55 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:27:55 --> Utf8 Class Initialized
INFO - 2020-08-21 11:27:55 --> URI Class Initialized
DEBUG - 2020-08-21 11:27:55 --> No URI present. Default controller set.
INFO - 2020-08-21 11:27:55 --> Router Class Initialized
INFO - 2020-08-21 11:27:55 --> Output Class Initialized
INFO - 2020-08-21 11:27:55 --> Security Class Initialized
DEBUG - 2020-08-21 11:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:27:55 --> Input Class Initialized
INFO - 2020-08-21 11:27:55 --> Language Class Initialized
INFO - 2020-08-21 11:27:55 --> Language Class Initialized
INFO - 2020-08-21 11:27:55 --> Config Class Initialized
INFO - 2020-08-21 11:27:55 --> Loader Class Initialized
INFO - 2020-08-21 11:27:55 --> Helper loaded: url_helper
INFO - 2020-08-21 11:27:55 --> Helper loaded: form_helper
INFO - 2020-08-21 11:27:55 --> Helper loaded: file_helper
INFO - 2020-08-21 11:27:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:27:55 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:27:55 --> Upload Class Initialized
INFO - 2020-08-21 11:27:55 --> Controller Class Initialized
DEBUG - 2020-08-21 11:27:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 11:27:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 11:27:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 11:27:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 11:27:55 --> Final output sent to browser
DEBUG - 2020-08-21 11:27:55 --> Total execution time: 0.0506
INFO - 2020-08-21 11:27:56 --> Config Class Initialized
INFO - 2020-08-21 11:27:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 11:27:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 11:27:56 --> Utf8 Class Initialized
INFO - 2020-08-21 11:27:56 --> URI Class Initialized
INFO - 2020-08-21 11:27:56 --> Router Class Initialized
INFO - 2020-08-21 11:27:56 --> Output Class Initialized
INFO - 2020-08-21 11:27:56 --> Security Class Initialized
DEBUG - 2020-08-21 11:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 11:27:56 --> Input Class Initialized
INFO - 2020-08-21 11:27:56 --> Language Class Initialized
INFO - 2020-08-21 11:27:56 --> Language Class Initialized
INFO - 2020-08-21 11:27:56 --> Config Class Initialized
INFO - 2020-08-21 11:27:56 --> Loader Class Initialized
INFO - 2020-08-21 11:27:56 --> Helper loaded: url_helper
INFO - 2020-08-21 11:27:56 --> Helper loaded: form_helper
INFO - 2020-08-21 11:27:56 --> Helper loaded: file_helper
INFO - 2020-08-21 11:27:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 11:27:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 11:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 11:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 11:27:56 --> Upload Class Initialized
INFO - 2020-08-21 11:27:56 --> Controller Class Initialized
ERROR - 2020-08-21 11:27:56 --> 404 Page Not Found: /index
INFO - 2020-08-21 12:42:17 --> Config Class Initialized
INFO - 2020-08-21 12:42:17 --> Hooks Class Initialized
DEBUG - 2020-08-21 12:42:17 --> UTF-8 Support Enabled
INFO - 2020-08-21 12:42:17 --> Utf8 Class Initialized
INFO - 2020-08-21 12:42:17 --> URI Class Initialized
DEBUG - 2020-08-21 12:42:17 --> No URI present. Default controller set.
INFO - 2020-08-21 12:42:17 --> Router Class Initialized
INFO - 2020-08-21 12:42:17 --> Output Class Initialized
INFO - 2020-08-21 12:42:17 --> Security Class Initialized
DEBUG - 2020-08-21 12:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 12:42:17 --> Input Class Initialized
INFO - 2020-08-21 12:42:17 --> Language Class Initialized
INFO - 2020-08-21 12:42:17 --> Language Class Initialized
INFO - 2020-08-21 12:42:17 --> Config Class Initialized
INFO - 2020-08-21 12:42:17 --> Loader Class Initialized
INFO - 2020-08-21 12:42:17 --> Helper loaded: url_helper
INFO - 2020-08-21 12:42:17 --> Helper loaded: form_helper
INFO - 2020-08-21 12:42:17 --> Helper loaded: file_helper
INFO - 2020-08-21 12:42:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 12:42:17 --> Database Driver Class Initialized
DEBUG - 2020-08-21 12:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 12:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 12:42:17 --> Upload Class Initialized
INFO - 2020-08-21 12:42:17 --> Controller Class Initialized
DEBUG - 2020-08-21 12:42:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 12:42:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 12:42:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 12:42:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 12:42:17 --> Final output sent to browser
DEBUG - 2020-08-21 12:42:17 --> Total execution time: 0.0513
INFO - 2020-08-21 12:42:32 --> Config Class Initialized
INFO - 2020-08-21 12:42:32 --> Hooks Class Initialized
DEBUG - 2020-08-21 12:42:32 --> UTF-8 Support Enabled
INFO - 2020-08-21 12:42:32 --> Utf8 Class Initialized
INFO - 2020-08-21 12:42:32 --> URI Class Initialized
INFO - 2020-08-21 12:42:32 --> Router Class Initialized
INFO - 2020-08-21 12:42:32 --> Output Class Initialized
INFO - 2020-08-21 12:42:32 --> Security Class Initialized
DEBUG - 2020-08-21 12:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 12:42:32 --> Input Class Initialized
INFO - 2020-08-21 12:42:32 --> Language Class Initialized
INFO - 2020-08-21 12:42:32 --> Language Class Initialized
INFO - 2020-08-21 12:42:32 --> Config Class Initialized
INFO - 2020-08-21 12:42:32 --> Loader Class Initialized
INFO - 2020-08-21 12:42:32 --> Helper loaded: url_helper
INFO - 2020-08-21 12:42:32 --> Helper loaded: form_helper
INFO - 2020-08-21 12:42:32 --> Helper loaded: file_helper
INFO - 2020-08-21 12:42:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 12:42:32 --> Database Driver Class Initialized
DEBUG - 2020-08-21 12:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 12:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 12:42:32 --> Upload Class Initialized
INFO - 2020-08-21 12:42:32 --> Controller Class Initialized
ERROR - 2020-08-21 12:42:32 --> 404 Page Not Found: /index
INFO - 2020-08-21 12:43:12 --> Config Class Initialized
INFO - 2020-08-21 12:43:12 --> Hooks Class Initialized
DEBUG - 2020-08-21 12:43:12 --> UTF-8 Support Enabled
INFO - 2020-08-21 12:43:12 --> Utf8 Class Initialized
INFO - 2020-08-21 12:43:12 --> URI Class Initialized
DEBUG - 2020-08-21 12:43:12 --> No URI present. Default controller set.
INFO - 2020-08-21 12:43:12 --> Router Class Initialized
INFO - 2020-08-21 12:43:12 --> Output Class Initialized
INFO - 2020-08-21 12:43:12 --> Security Class Initialized
DEBUG - 2020-08-21 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 12:43:12 --> Input Class Initialized
INFO - 2020-08-21 12:43:12 --> Language Class Initialized
INFO - 2020-08-21 12:43:12 --> Language Class Initialized
INFO - 2020-08-21 12:43:12 --> Config Class Initialized
INFO - 2020-08-21 12:43:12 --> Loader Class Initialized
INFO - 2020-08-21 12:43:12 --> Helper loaded: url_helper
INFO - 2020-08-21 12:43:12 --> Helper loaded: form_helper
INFO - 2020-08-21 12:43:12 --> Helper loaded: file_helper
INFO - 2020-08-21 12:43:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 12:43:12 --> Database Driver Class Initialized
DEBUG - 2020-08-21 12:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 12:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 12:43:12 --> Upload Class Initialized
INFO - 2020-08-21 12:43:12 --> Controller Class Initialized
DEBUG - 2020-08-21 12:43:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 12:43:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 12:43:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 12:43:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 12:43:12 --> Final output sent to browser
DEBUG - 2020-08-21 12:43:12 --> Total execution time: 0.0762
INFO - 2020-08-21 12:43:13 --> Config Class Initialized
INFO - 2020-08-21 12:43:13 --> Hooks Class Initialized
DEBUG - 2020-08-21 12:43:13 --> UTF-8 Support Enabled
INFO - 2020-08-21 12:43:13 --> Utf8 Class Initialized
INFO - 2020-08-21 12:43:13 --> URI Class Initialized
INFO - 2020-08-21 12:43:13 --> Router Class Initialized
INFO - 2020-08-21 12:43:13 --> Output Class Initialized
INFO - 2020-08-21 12:43:13 --> Security Class Initialized
DEBUG - 2020-08-21 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 12:43:13 --> Input Class Initialized
INFO - 2020-08-21 12:43:13 --> Language Class Initialized
INFO - 2020-08-21 12:43:13 --> Language Class Initialized
INFO - 2020-08-21 12:43:13 --> Config Class Initialized
INFO - 2020-08-21 12:43:13 --> Loader Class Initialized
INFO - 2020-08-21 12:43:13 --> Helper loaded: url_helper
INFO - 2020-08-21 12:43:13 --> Helper loaded: form_helper
INFO - 2020-08-21 12:43:13 --> Helper loaded: file_helper
INFO - 2020-08-21 12:43:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 12:43:13 --> Database Driver Class Initialized
DEBUG - 2020-08-21 12:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 12:43:13 --> Upload Class Initialized
INFO - 2020-08-21 12:43:13 --> Controller Class Initialized
ERROR - 2020-08-21 12:43:13 --> 404 Page Not Found: /index
INFO - 2020-08-21 12:43:17 --> Config Class Initialized
INFO - 2020-08-21 12:43:17 --> Hooks Class Initialized
DEBUG - 2020-08-21 12:43:17 --> UTF-8 Support Enabled
INFO - 2020-08-21 12:43:17 --> Utf8 Class Initialized
INFO - 2020-08-21 12:43:17 --> URI Class Initialized
INFO - 2020-08-21 12:43:17 --> Router Class Initialized
INFO - 2020-08-21 12:43:17 --> Output Class Initialized
INFO - 2020-08-21 12:43:17 --> Security Class Initialized
DEBUG - 2020-08-21 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 12:43:17 --> Input Class Initialized
INFO - 2020-08-21 12:43:17 --> Language Class Initialized
INFO - 2020-08-21 12:43:17 --> Language Class Initialized
INFO - 2020-08-21 12:43:17 --> Config Class Initialized
INFO - 2020-08-21 12:43:17 --> Loader Class Initialized
INFO - 2020-08-21 12:43:17 --> Helper loaded: url_helper
INFO - 2020-08-21 12:43:17 --> Helper loaded: form_helper
INFO - 2020-08-21 12:43:17 --> Helper loaded: file_helper
INFO - 2020-08-21 12:43:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 12:43:17 --> Database Driver Class Initialized
DEBUG - 2020-08-21 12:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 12:43:17 --> Upload Class Initialized
INFO - 2020-08-21 12:43:17 --> Controller Class Initialized
DEBUG - 2020-08-21 12:43:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 12:43:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 12:43:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 12:43:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 12:43:17 --> Final output sent to browser
DEBUG - 2020-08-21 12:43:17 --> Total execution time: 0.0620
INFO - 2020-08-21 12:52:01 --> Config Class Initialized
INFO - 2020-08-21 12:52:01 --> Hooks Class Initialized
DEBUG - 2020-08-21 12:52:01 --> UTF-8 Support Enabled
INFO - 2020-08-21 12:52:01 --> Utf8 Class Initialized
INFO - 2020-08-21 12:52:01 --> URI Class Initialized
DEBUG - 2020-08-21 12:52:01 --> No URI present. Default controller set.
INFO - 2020-08-21 12:52:01 --> Router Class Initialized
INFO - 2020-08-21 12:52:01 --> Output Class Initialized
INFO - 2020-08-21 12:52:01 --> Security Class Initialized
DEBUG - 2020-08-21 12:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 12:52:01 --> Input Class Initialized
INFO - 2020-08-21 12:52:01 --> Language Class Initialized
INFO - 2020-08-21 12:52:01 --> Language Class Initialized
INFO - 2020-08-21 12:52:01 --> Config Class Initialized
INFO - 2020-08-21 12:52:01 --> Loader Class Initialized
INFO - 2020-08-21 12:52:01 --> Helper loaded: url_helper
INFO - 2020-08-21 12:52:01 --> Helper loaded: form_helper
INFO - 2020-08-21 12:52:01 --> Helper loaded: file_helper
INFO - 2020-08-21 12:52:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 12:52:01 --> Database Driver Class Initialized
DEBUG - 2020-08-21 12:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 12:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 12:52:01 --> Upload Class Initialized
INFO - 2020-08-21 12:52:01 --> Controller Class Initialized
DEBUG - 2020-08-21 12:52:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 12:52:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 12:52:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 12:52:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 12:52:01 --> Final output sent to browser
DEBUG - 2020-08-21 12:52:01 --> Total execution time: 0.0522
INFO - 2020-08-21 14:03:11 --> Config Class Initialized
INFO - 2020-08-21 14:03:11 --> Hooks Class Initialized
DEBUG - 2020-08-21 14:03:11 --> UTF-8 Support Enabled
INFO - 2020-08-21 14:03:11 --> Utf8 Class Initialized
INFO - 2020-08-21 14:03:11 --> URI Class Initialized
DEBUG - 2020-08-21 14:03:11 --> No URI present. Default controller set.
INFO - 2020-08-21 14:03:11 --> Router Class Initialized
INFO - 2020-08-21 14:03:11 --> Output Class Initialized
INFO - 2020-08-21 14:03:11 --> Security Class Initialized
DEBUG - 2020-08-21 14:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 14:03:11 --> Input Class Initialized
INFO - 2020-08-21 14:03:11 --> Language Class Initialized
INFO - 2020-08-21 14:03:11 --> Language Class Initialized
INFO - 2020-08-21 14:03:11 --> Config Class Initialized
INFO - 2020-08-21 14:03:11 --> Loader Class Initialized
INFO - 2020-08-21 14:03:11 --> Helper loaded: url_helper
INFO - 2020-08-21 14:03:11 --> Helper loaded: form_helper
INFO - 2020-08-21 14:03:11 --> Helper loaded: file_helper
INFO - 2020-08-21 14:03:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 14:03:11 --> Database Driver Class Initialized
DEBUG - 2020-08-21 14:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 14:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 14:03:11 --> Upload Class Initialized
INFO - 2020-08-21 14:03:11 --> Controller Class Initialized
DEBUG - 2020-08-21 14:03:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 14:03:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 14:03:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 14:03:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 14:03:11 --> Final output sent to browser
DEBUG - 2020-08-21 14:03:11 --> Total execution time: 0.0515
INFO - 2020-08-21 14:03:21 --> Config Class Initialized
INFO - 2020-08-21 14:03:21 --> Hooks Class Initialized
DEBUG - 2020-08-21 14:03:21 --> UTF-8 Support Enabled
INFO - 2020-08-21 14:03:21 --> Utf8 Class Initialized
INFO - 2020-08-21 14:03:21 --> URI Class Initialized
INFO - 2020-08-21 14:03:21 --> Router Class Initialized
INFO - 2020-08-21 14:03:21 --> Output Class Initialized
INFO - 2020-08-21 14:03:21 --> Security Class Initialized
DEBUG - 2020-08-21 14:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 14:03:21 --> Input Class Initialized
INFO - 2020-08-21 14:03:21 --> Language Class Initialized
INFO - 2020-08-21 14:03:21 --> Language Class Initialized
INFO - 2020-08-21 14:03:21 --> Config Class Initialized
INFO - 2020-08-21 14:03:21 --> Loader Class Initialized
INFO - 2020-08-21 14:03:21 --> Helper loaded: url_helper
INFO - 2020-08-21 14:03:21 --> Helper loaded: form_helper
INFO - 2020-08-21 14:03:21 --> Helper loaded: file_helper
INFO - 2020-08-21 14:03:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 14:03:21 --> Database Driver Class Initialized
DEBUG - 2020-08-21 14:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 14:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 14:03:21 --> Upload Class Initialized
INFO - 2020-08-21 14:03:21 --> Controller Class Initialized
ERROR - 2020-08-21 14:03:21 --> 404 Page Not Found: /index
INFO - 2020-08-21 14:37:59 --> Config Class Initialized
INFO - 2020-08-21 14:37:59 --> Hooks Class Initialized
DEBUG - 2020-08-21 14:37:59 --> UTF-8 Support Enabled
INFO - 2020-08-21 14:37:59 --> Utf8 Class Initialized
INFO - 2020-08-21 14:37:59 --> URI Class Initialized
INFO - 2020-08-21 14:37:59 --> Router Class Initialized
INFO - 2020-08-21 14:37:59 --> Output Class Initialized
INFO - 2020-08-21 14:37:59 --> Security Class Initialized
DEBUG - 2020-08-21 14:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 14:37:59 --> Input Class Initialized
INFO - 2020-08-21 14:37:59 --> Language Class Initialized
INFO - 2020-08-21 14:37:59 --> Language Class Initialized
INFO - 2020-08-21 14:37:59 --> Config Class Initialized
INFO - 2020-08-21 14:37:59 --> Loader Class Initialized
INFO - 2020-08-21 14:37:59 --> Helper loaded: url_helper
INFO - 2020-08-21 14:38:00 --> Helper loaded: form_helper
INFO - 2020-08-21 14:38:00 --> Helper loaded: file_helper
INFO - 2020-08-21 14:38:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 14:38:00 --> Database Driver Class Initialized
DEBUG - 2020-08-21 14:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 14:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 14:38:00 --> Upload Class Initialized
INFO - 2020-08-21 14:38:00 --> Controller Class Initialized
ERROR - 2020-08-21 14:38:00 --> 404 Page Not Found: /index
INFO - 2020-08-21 14:38:00 --> Config Class Initialized
INFO - 2020-08-21 14:38:00 --> Hooks Class Initialized
DEBUG - 2020-08-21 14:38:00 --> UTF-8 Support Enabled
INFO - 2020-08-21 14:38:00 --> Utf8 Class Initialized
INFO - 2020-08-21 14:38:00 --> URI Class Initialized
INFO - 2020-08-21 14:38:00 --> Router Class Initialized
INFO - 2020-08-21 14:38:00 --> Output Class Initialized
INFO - 2020-08-21 14:38:00 --> Security Class Initialized
DEBUG - 2020-08-21 14:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 14:38:00 --> Input Class Initialized
INFO - 2020-08-21 14:38:00 --> Language Class Initialized
INFO - 2020-08-21 14:38:00 --> Language Class Initialized
INFO - 2020-08-21 14:38:00 --> Config Class Initialized
INFO - 2020-08-21 14:38:00 --> Loader Class Initialized
INFO - 2020-08-21 14:38:00 --> Helper loaded: url_helper
INFO - 2020-08-21 14:38:00 --> Helper loaded: form_helper
INFO - 2020-08-21 14:38:00 --> Helper loaded: file_helper
INFO - 2020-08-21 14:38:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 14:38:00 --> Database Driver Class Initialized
DEBUG - 2020-08-21 14:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 14:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 14:38:00 --> Upload Class Initialized
INFO - 2020-08-21 14:38:00 --> Controller Class Initialized
ERROR - 2020-08-21 14:38:00 --> 404 Page Not Found: /index
INFO - 2020-08-21 15:31:55 --> Config Class Initialized
INFO - 2020-08-21 15:31:55 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:55 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:55 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:55 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:55 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:55 --> Router Class Initialized
INFO - 2020-08-21 15:31:55 --> Output Class Initialized
INFO - 2020-08-21 15:31:55 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:55 --> Input Class Initialized
INFO - 2020-08-21 15:31:55 --> Language Class Initialized
INFO - 2020-08-21 15:31:55 --> Language Class Initialized
INFO - 2020-08-21 15:31:55 --> Config Class Initialized
INFO - 2020-08-21 15:31:55 --> Loader Class Initialized
INFO - 2020-08-21 15:31:55 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:55 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:55 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:55 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:55 --> Upload Class Initialized
INFO - 2020-08-21 15:31:55 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:55 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:55 --> Total execution time: 0.0521
INFO - 2020-08-21 15:31:56 --> Config Class Initialized
INFO - 2020-08-21 15:31:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:56 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:56 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:56 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:56 --> Router Class Initialized
INFO - 2020-08-21 15:31:56 --> Output Class Initialized
INFO - 2020-08-21 15:31:56 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:56 --> Input Class Initialized
INFO - 2020-08-21 15:31:56 --> Language Class Initialized
INFO - 2020-08-21 15:31:56 --> Language Class Initialized
INFO - 2020-08-21 15:31:56 --> Config Class Initialized
INFO - 2020-08-21 15:31:56 --> Loader Class Initialized
INFO - 2020-08-21 15:31:56 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:56 --> Upload Class Initialized
INFO - 2020-08-21 15:31:56 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:56 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:56 --> Total execution time: 0.0510
INFO - 2020-08-21 15:31:56 --> Config Class Initialized
INFO - 2020-08-21 15:31:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:56 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:56 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:56 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:56 --> Router Class Initialized
INFO - 2020-08-21 15:31:56 --> Output Class Initialized
INFO - 2020-08-21 15:31:56 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:56 --> Input Class Initialized
INFO - 2020-08-21 15:31:56 --> Language Class Initialized
INFO - 2020-08-21 15:31:56 --> Language Class Initialized
INFO - 2020-08-21 15:31:56 --> Config Class Initialized
INFO - 2020-08-21 15:31:56 --> Loader Class Initialized
INFO - 2020-08-21 15:31:56 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:56 --> Upload Class Initialized
INFO - 2020-08-21 15:31:56 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:56 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:56 --> Total execution time: 0.0509
INFO - 2020-08-21 15:31:56 --> Config Class Initialized
INFO - 2020-08-21 15:31:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:56 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:56 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:56 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:56 --> Router Class Initialized
INFO - 2020-08-21 15:31:56 --> Output Class Initialized
INFO - 2020-08-21 15:31:56 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:56 --> Input Class Initialized
INFO - 2020-08-21 15:31:56 --> Language Class Initialized
INFO - 2020-08-21 15:31:56 --> Language Class Initialized
INFO - 2020-08-21 15:31:56 --> Config Class Initialized
INFO - 2020-08-21 15:31:56 --> Loader Class Initialized
INFO - 2020-08-21 15:31:56 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:56 --> Upload Class Initialized
INFO - 2020-08-21 15:31:56 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:56 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:56 --> Total execution time: 0.0513
INFO - 2020-08-21 15:31:57 --> Config Class Initialized
INFO - 2020-08-21 15:31:57 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:57 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:57 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:57 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:57 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:57 --> Router Class Initialized
INFO - 2020-08-21 15:31:57 --> Output Class Initialized
INFO - 2020-08-21 15:31:57 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:57 --> Input Class Initialized
INFO - 2020-08-21 15:31:57 --> Language Class Initialized
INFO - 2020-08-21 15:31:57 --> Language Class Initialized
INFO - 2020-08-21 15:31:57 --> Config Class Initialized
INFO - 2020-08-21 15:31:57 --> Loader Class Initialized
INFO - 2020-08-21 15:31:57 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:57 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:57 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:57 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:57 --> Upload Class Initialized
INFO - 2020-08-21 15:31:57 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:57 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:57 --> Total execution time: 0.0503
INFO - 2020-08-21 15:31:57 --> Config Class Initialized
INFO - 2020-08-21 15:31:57 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:57 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:57 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:57 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:57 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:57 --> Router Class Initialized
INFO - 2020-08-21 15:31:57 --> Output Class Initialized
INFO - 2020-08-21 15:31:57 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:57 --> Input Class Initialized
INFO - 2020-08-21 15:31:57 --> Language Class Initialized
INFO - 2020-08-21 15:31:57 --> Language Class Initialized
INFO - 2020-08-21 15:31:57 --> Config Class Initialized
INFO - 2020-08-21 15:31:57 --> Loader Class Initialized
INFO - 2020-08-21 15:31:57 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:57 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:57 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:57 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:57 --> Upload Class Initialized
INFO - 2020-08-21 15:31:57 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:57 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:57 --> Total execution time: 0.0496
INFO - 2020-08-21 15:31:58 --> Config Class Initialized
INFO - 2020-08-21 15:31:58 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:58 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:58 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:58 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:58 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:58 --> Router Class Initialized
INFO - 2020-08-21 15:31:58 --> Output Class Initialized
INFO - 2020-08-21 15:31:58 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:58 --> Input Class Initialized
INFO - 2020-08-21 15:31:58 --> Language Class Initialized
INFO - 2020-08-21 15:31:58 --> Language Class Initialized
INFO - 2020-08-21 15:31:58 --> Config Class Initialized
INFO - 2020-08-21 15:31:58 --> Loader Class Initialized
INFO - 2020-08-21 15:31:58 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:58 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:58 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:58 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:58 --> Upload Class Initialized
INFO - 2020-08-21 15:31:58 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:58 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:58 --> Total execution time: 0.0494
INFO - 2020-08-21 15:31:58 --> Config Class Initialized
INFO - 2020-08-21 15:31:58 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:31:58 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:31:58 --> Utf8 Class Initialized
INFO - 2020-08-21 15:31:58 --> URI Class Initialized
DEBUG - 2020-08-21 15:31:58 --> No URI present. Default controller set.
INFO - 2020-08-21 15:31:58 --> Router Class Initialized
INFO - 2020-08-21 15:31:58 --> Output Class Initialized
INFO - 2020-08-21 15:31:58 --> Security Class Initialized
DEBUG - 2020-08-21 15:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:31:58 --> Input Class Initialized
INFO - 2020-08-21 15:31:58 --> Language Class Initialized
INFO - 2020-08-21 15:31:58 --> Language Class Initialized
INFO - 2020-08-21 15:31:58 --> Config Class Initialized
INFO - 2020-08-21 15:31:58 --> Loader Class Initialized
INFO - 2020-08-21 15:31:58 --> Helper loaded: url_helper
INFO - 2020-08-21 15:31:58 --> Helper loaded: form_helper
INFO - 2020-08-21 15:31:58 --> Helper loaded: file_helper
INFO - 2020-08-21 15:31:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:31:58 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:31:58 --> Upload Class Initialized
INFO - 2020-08-21 15:31:58 --> Controller Class Initialized
DEBUG - 2020-08-21 15:31:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:31:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:31:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:31:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:31:58 --> Final output sent to browser
DEBUG - 2020-08-21 15:31:58 --> Total execution time: 0.0496
INFO - 2020-08-21 15:39:56 --> Config Class Initialized
INFO - 2020-08-21 15:39:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:39:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:39:56 --> Utf8 Class Initialized
INFO - 2020-08-21 15:39:56 --> URI Class Initialized
DEBUG - 2020-08-21 15:39:56 --> No URI present. Default controller set.
INFO - 2020-08-21 15:39:56 --> Router Class Initialized
INFO - 2020-08-21 15:39:56 --> Output Class Initialized
INFO - 2020-08-21 15:39:56 --> Security Class Initialized
DEBUG - 2020-08-21 15:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:39:56 --> Input Class Initialized
INFO - 2020-08-21 15:39:56 --> Language Class Initialized
INFO - 2020-08-21 15:39:56 --> Language Class Initialized
INFO - 2020-08-21 15:39:56 --> Config Class Initialized
INFO - 2020-08-21 15:39:56 --> Loader Class Initialized
INFO - 2020-08-21 15:39:56 --> Helper loaded: url_helper
INFO - 2020-08-21 15:39:56 --> Helper loaded: form_helper
INFO - 2020-08-21 15:39:56 --> Helper loaded: file_helper
INFO - 2020-08-21 15:39:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:39:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:39:56 --> Upload Class Initialized
INFO - 2020-08-21 15:39:56 --> Controller Class Initialized
DEBUG - 2020-08-21 15:39:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:39:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:39:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:39:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:39:56 --> Final output sent to browser
DEBUG - 2020-08-21 15:39:56 --> Total execution time: 0.0511
INFO - 2020-08-21 15:51:40 --> Config Class Initialized
INFO - 2020-08-21 15:51:40 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:51:40 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:51:40 --> Utf8 Class Initialized
INFO - 2020-08-21 15:51:40 --> URI Class Initialized
INFO - 2020-08-21 15:51:40 --> Router Class Initialized
INFO - 2020-08-21 15:51:40 --> Output Class Initialized
INFO - 2020-08-21 15:51:40 --> Security Class Initialized
DEBUG - 2020-08-21 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:51:40 --> Input Class Initialized
INFO - 2020-08-21 15:51:40 --> Language Class Initialized
INFO - 2020-08-21 15:51:40 --> Language Class Initialized
INFO - 2020-08-21 15:51:40 --> Config Class Initialized
INFO - 2020-08-21 15:51:40 --> Loader Class Initialized
INFO - 2020-08-21 15:51:40 --> Helper loaded: url_helper
INFO - 2020-08-21 15:51:40 --> Helper loaded: form_helper
INFO - 2020-08-21 15:51:40 --> Helper loaded: file_helper
INFO - 2020-08-21 15:51:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:51:40 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:51:40 --> Upload Class Initialized
INFO - 2020-08-21 15:51:40 --> Controller Class Initialized
ERROR - 2020-08-21 15:51:40 --> 404 Page Not Found: /index
INFO - 2020-08-21 15:51:40 --> Config Class Initialized
INFO - 2020-08-21 15:51:40 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:51:40 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:51:40 --> Utf8 Class Initialized
INFO - 2020-08-21 15:51:40 --> URI Class Initialized
INFO - 2020-08-21 15:51:40 --> Router Class Initialized
INFO - 2020-08-21 15:51:40 --> Output Class Initialized
INFO - 2020-08-21 15:51:40 --> Security Class Initialized
DEBUG - 2020-08-21 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:51:40 --> Input Class Initialized
INFO - 2020-08-21 15:51:40 --> Language Class Initialized
INFO - 2020-08-21 15:51:40 --> Language Class Initialized
INFO - 2020-08-21 15:51:40 --> Config Class Initialized
INFO - 2020-08-21 15:51:40 --> Loader Class Initialized
INFO - 2020-08-21 15:51:40 --> Helper loaded: url_helper
INFO - 2020-08-21 15:51:40 --> Helper loaded: form_helper
INFO - 2020-08-21 15:51:40 --> Helper loaded: file_helper
INFO - 2020-08-21 15:51:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:51:40 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:51:40 --> Upload Class Initialized
INFO - 2020-08-21 15:51:41 --> Controller Class Initialized
ERROR - 2020-08-21 15:51:41 --> 404 Page Not Found: /index
INFO - 2020-08-21 15:55:52 --> Config Class Initialized
INFO - 2020-08-21 15:55:52 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:55:52 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:55:52 --> Utf8 Class Initialized
INFO - 2020-08-21 15:55:52 --> URI Class Initialized
INFO - 2020-08-21 15:55:52 --> Router Class Initialized
INFO - 2020-08-21 15:55:52 --> Output Class Initialized
INFO - 2020-08-21 15:55:52 --> Security Class Initialized
DEBUG - 2020-08-21 15:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:55:52 --> Input Class Initialized
INFO - 2020-08-21 15:55:52 --> Language Class Initialized
INFO - 2020-08-21 15:55:52 --> Language Class Initialized
INFO - 2020-08-21 15:55:52 --> Config Class Initialized
INFO - 2020-08-21 15:55:52 --> Loader Class Initialized
INFO - 2020-08-21 15:55:52 --> Helper loaded: url_helper
INFO - 2020-08-21 15:55:52 --> Helper loaded: form_helper
INFO - 2020-08-21 15:55:52 --> Helper loaded: file_helper
INFO - 2020-08-21 15:55:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:55:52 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:55:52 --> Upload Class Initialized
INFO - 2020-08-21 15:55:52 --> Controller Class Initialized
DEBUG - 2020-08-21 15:55:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:55:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-21 15:55:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:55:52 --> Final output sent to browser
DEBUG - 2020-08-21 15:55:52 --> Total execution time: 0.0566
INFO - 2020-08-21 15:55:56 --> Config Class Initialized
INFO - 2020-08-21 15:55:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:55:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:55:56 --> Utf8 Class Initialized
INFO - 2020-08-21 15:55:56 --> URI Class Initialized
INFO - 2020-08-21 15:55:56 --> Router Class Initialized
INFO - 2020-08-21 15:55:56 --> Output Class Initialized
INFO - 2020-08-21 15:55:56 --> Security Class Initialized
DEBUG - 2020-08-21 15:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:55:56 --> Input Class Initialized
INFO - 2020-08-21 15:55:56 --> Language Class Initialized
INFO - 2020-08-21 15:55:56 --> Language Class Initialized
INFO - 2020-08-21 15:55:56 --> Config Class Initialized
INFO - 2020-08-21 15:55:56 --> Loader Class Initialized
INFO - 2020-08-21 15:55:56 --> Helper loaded: url_helper
INFO - 2020-08-21 15:55:56 --> Helper loaded: form_helper
INFO - 2020-08-21 15:55:56 --> Helper loaded: file_helper
INFO - 2020-08-21 15:55:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:55:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:55:56 --> Upload Class Initialized
INFO - 2020-08-21 15:55:56 --> Controller Class Initialized
ERROR - 2020-08-21 15:55:56 --> 404 Page Not Found: /index
INFO - 2020-08-21 15:57:19 --> Config Class Initialized
INFO - 2020-08-21 15:57:19 --> Hooks Class Initialized
DEBUG - 2020-08-21 15:57:19 --> UTF-8 Support Enabled
INFO - 2020-08-21 15:57:19 --> Utf8 Class Initialized
INFO - 2020-08-21 15:57:19 --> URI Class Initialized
DEBUG - 2020-08-21 15:57:19 --> No URI present. Default controller set.
INFO - 2020-08-21 15:57:19 --> Router Class Initialized
INFO - 2020-08-21 15:57:19 --> Output Class Initialized
INFO - 2020-08-21 15:57:19 --> Security Class Initialized
DEBUG - 2020-08-21 15:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 15:57:19 --> Input Class Initialized
INFO - 2020-08-21 15:57:19 --> Language Class Initialized
INFO - 2020-08-21 15:57:19 --> Language Class Initialized
INFO - 2020-08-21 15:57:19 --> Config Class Initialized
INFO - 2020-08-21 15:57:19 --> Loader Class Initialized
INFO - 2020-08-21 15:57:19 --> Helper loaded: url_helper
INFO - 2020-08-21 15:57:19 --> Helper loaded: form_helper
INFO - 2020-08-21 15:57:19 --> Helper loaded: file_helper
INFO - 2020-08-21 15:57:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 15:57:19 --> Database Driver Class Initialized
DEBUG - 2020-08-21 15:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 15:57:19 --> Upload Class Initialized
INFO - 2020-08-21 15:57:19 --> Controller Class Initialized
DEBUG - 2020-08-21 15:57:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 15:57:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 15:57:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 15:57:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 15:57:19 --> Final output sent to browser
DEBUG - 2020-08-21 15:57:19 --> Total execution time: 0.0491
INFO - 2020-08-21 16:31:17 --> Config Class Initialized
INFO - 2020-08-21 16:31:17 --> Hooks Class Initialized
DEBUG - 2020-08-21 16:31:17 --> UTF-8 Support Enabled
INFO - 2020-08-21 16:31:17 --> Utf8 Class Initialized
INFO - 2020-08-21 16:31:17 --> URI Class Initialized
INFO - 2020-08-21 16:31:17 --> Router Class Initialized
INFO - 2020-08-21 16:31:17 --> Output Class Initialized
INFO - 2020-08-21 16:31:17 --> Security Class Initialized
DEBUG - 2020-08-21 16:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 16:31:17 --> Input Class Initialized
INFO - 2020-08-21 16:31:17 --> Language Class Initialized
INFO - 2020-08-21 16:31:17 --> Language Class Initialized
INFO - 2020-08-21 16:31:17 --> Config Class Initialized
INFO - 2020-08-21 16:31:17 --> Loader Class Initialized
INFO - 2020-08-21 16:31:17 --> Helper loaded: url_helper
INFO - 2020-08-21 16:31:17 --> Helper loaded: form_helper
INFO - 2020-08-21 16:31:17 --> Helper loaded: file_helper
INFO - 2020-08-21 16:31:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 16:31:17 --> Database Driver Class Initialized
DEBUG - 2020-08-21 16:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 16:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 16:31:17 --> Upload Class Initialized
INFO - 2020-08-21 16:31:18 --> Controller Class Initialized
ERROR - 2020-08-21 16:31:18 --> 404 Page Not Found: /index
INFO - 2020-08-21 16:46:52 --> Config Class Initialized
INFO - 2020-08-21 16:46:52 --> Hooks Class Initialized
DEBUG - 2020-08-21 16:46:52 --> UTF-8 Support Enabled
INFO - 2020-08-21 16:46:52 --> Utf8 Class Initialized
INFO - 2020-08-21 16:46:52 --> URI Class Initialized
INFO - 2020-08-21 16:46:52 --> Router Class Initialized
INFO - 2020-08-21 16:46:52 --> Output Class Initialized
INFO - 2020-08-21 16:46:52 --> Security Class Initialized
DEBUG - 2020-08-21 16:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 16:46:52 --> Input Class Initialized
INFO - 2020-08-21 16:46:52 --> Language Class Initialized
INFO - 2020-08-21 16:46:52 --> Language Class Initialized
INFO - 2020-08-21 16:46:52 --> Config Class Initialized
INFO - 2020-08-21 16:46:52 --> Loader Class Initialized
INFO - 2020-08-21 16:46:52 --> Helper loaded: url_helper
INFO - 2020-08-21 16:46:52 --> Helper loaded: form_helper
INFO - 2020-08-21 16:46:52 --> Helper loaded: file_helper
INFO - 2020-08-21 16:46:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 16:46:52 --> Database Driver Class Initialized
DEBUG - 2020-08-21 16:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 16:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 16:46:52 --> Upload Class Initialized
INFO - 2020-08-21 16:46:52 --> Controller Class Initialized
DEBUG - 2020-08-21 16:46:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 16:46:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-21 16:46:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 16:46:52 --> Final output sent to browser
DEBUG - 2020-08-21 16:46:52 --> Total execution time: 0.0683
INFO - 2020-08-21 16:46:56 --> Config Class Initialized
INFO - 2020-08-21 16:46:56 --> Hooks Class Initialized
DEBUG - 2020-08-21 16:46:56 --> UTF-8 Support Enabled
INFO - 2020-08-21 16:46:56 --> Utf8 Class Initialized
INFO - 2020-08-21 16:46:56 --> URI Class Initialized
INFO - 2020-08-21 16:46:56 --> Router Class Initialized
INFO - 2020-08-21 16:46:56 --> Output Class Initialized
INFO - 2020-08-21 16:46:56 --> Security Class Initialized
DEBUG - 2020-08-21 16:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 16:46:56 --> Input Class Initialized
INFO - 2020-08-21 16:46:56 --> Language Class Initialized
INFO - 2020-08-21 16:46:56 --> Language Class Initialized
INFO - 2020-08-21 16:46:56 --> Config Class Initialized
INFO - 2020-08-21 16:46:56 --> Loader Class Initialized
INFO - 2020-08-21 16:46:56 --> Helper loaded: url_helper
INFO - 2020-08-21 16:46:56 --> Helper loaded: form_helper
INFO - 2020-08-21 16:46:56 --> Helper loaded: file_helper
INFO - 2020-08-21 16:46:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 16:46:56 --> Database Driver Class Initialized
DEBUG - 2020-08-21 16:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 16:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 16:46:56 --> Upload Class Initialized
INFO - 2020-08-21 16:46:56 --> Controller Class Initialized
ERROR - 2020-08-21 16:46:56 --> 404 Page Not Found: /index
INFO - 2020-08-21 17:16:19 --> Config Class Initialized
INFO - 2020-08-21 17:16:19 --> Hooks Class Initialized
DEBUG - 2020-08-21 17:16:19 --> UTF-8 Support Enabled
INFO - 2020-08-21 17:16:19 --> Utf8 Class Initialized
INFO - 2020-08-21 17:16:19 --> URI Class Initialized
DEBUG - 2020-08-21 17:16:19 --> No URI present. Default controller set.
INFO - 2020-08-21 17:16:19 --> Router Class Initialized
INFO - 2020-08-21 17:16:19 --> Output Class Initialized
INFO - 2020-08-21 17:16:19 --> Security Class Initialized
DEBUG - 2020-08-21 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 17:16:19 --> Input Class Initialized
INFO - 2020-08-21 17:16:19 --> Language Class Initialized
INFO - 2020-08-21 17:16:19 --> Language Class Initialized
INFO - 2020-08-21 17:16:19 --> Config Class Initialized
INFO - 2020-08-21 17:16:19 --> Loader Class Initialized
INFO - 2020-08-21 17:16:19 --> Helper loaded: url_helper
INFO - 2020-08-21 17:16:19 --> Helper loaded: form_helper
INFO - 2020-08-21 17:16:19 --> Helper loaded: file_helper
INFO - 2020-08-21 17:16:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 17:16:19 --> Database Driver Class Initialized
DEBUG - 2020-08-21 17:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 17:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 17:16:19 --> Upload Class Initialized
INFO - 2020-08-21 17:16:19 --> Controller Class Initialized
DEBUG - 2020-08-21 17:16:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 17:16:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 17:16:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 17:16:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 17:16:19 --> Final output sent to browser
DEBUG - 2020-08-21 17:16:19 --> Total execution time: 0.0618
INFO - 2020-08-21 17:28:30 --> Config Class Initialized
INFO - 2020-08-21 17:28:30 --> Hooks Class Initialized
DEBUG - 2020-08-21 17:28:30 --> UTF-8 Support Enabled
INFO - 2020-08-21 17:28:30 --> Utf8 Class Initialized
INFO - 2020-08-21 17:28:30 --> URI Class Initialized
INFO - 2020-08-21 17:28:30 --> Router Class Initialized
INFO - 2020-08-21 17:28:30 --> Output Class Initialized
INFO - 2020-08-21 17:28:30 --> Security Class Initialized
DEBUG - 2020-08-21 17:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 17:28:30 --> Input Class Initialized
INFO - 2020-08-21 17:28:30 --> Language Class Initialized
INFO - 2020-08-21 17:28:30 --> Language Class Initialized
INFO - 2020-08-21 17:28:30 --> Config Class Initialized
INFO - 2020-08-21 17:28:30 --> Loader Class Initialized
INFO - 2020-08-21 17:28:30 --> Helper loaded: url_helper
INFO - 2020-08-21 17:28:30 --> Helper loaded: form_helper
INFO - 2020-08-21 17:28:30 --> Helper loaded: file_helper
INFO - 2020-08-21 17:28:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 17:28:30 --> Database Driver Class Initialized
DEBUG - 2020-08-21 17:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 17:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 17:28:30 --> Upload Class Initialized
INFO - 2020-08-21 17:28:30 --> Controller Class Initialized
ERROR - 2020-08-21 17:28:30 --> 404 Page Not Found: /index
INFO - 2020-08-21 17:36:54 --> Config Class Initialized
INFO - 2020-08-21 17:36:54 --> Hooks Class Initialized
DEBUG - 2020-08-21 17:36:54 --> UTF-8 Support Enabled
INFO - 2020-08-21 17:36:54 --> Utf8 Class Initialized
INFO - 2020-08-21 17:36:54 --> URI Class Initialized
DEBUG - 2020-08-21 17:36:54 --> No URI present. Default controller set.
INFO - 2020-08-21 17:36:54 --> Router Class Initialized
INFO - 2020-08-21 17:36:54 --> Output Class Initialized
INFO - 2020-08-21 17:36:54 --> Security Class Initialized
DEBUG - 2020-08-21 17:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 17:36:54 --> Input Class Initialized
INFO - 2020-08-21 17:36:54 --> Language Class Initialized
INFO - 2020-08-21 17:36:54 --> Language Class Initialized
INFO - 2020-08-21 17:36:54 --> Config Class Initialized
INFO - 2020-08-21 17:36:54 --> Loader Class Initialized
INFO - 2020-08-21 17:36:54 --> Helper loaded: url_helper
INFO - 2020-08-21 17:36:54 --> Helper loaded: form_helper
INFO - 2020-08-21 17:36:54 --> Helper loaded: file_helper
INFO - 2020-08-21 17:36:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 17:36:54 --> Database Driver Class Initialized
DEBUG - 2020-08-21 17:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 17:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 17:36:54 --> Upload Class Initialized
INFO - 2020-08-21 17:36:54 --> Controller Class Initialized
DEBUG - 2020-08-21 17:36:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 17:36:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 17:36:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 17:36:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 17:36:54 --> Final output sent to browser
DEBUG - 2020-08-21 17:36:54 --> Total execution time: 0.0507
INFO - 2020-08-21 17:36:55 --> Config Class Initialized
INFO - 2020-08-21 17:36:55 --> Hooks Class Initialized
DEBUG - 2020-08-21 17:36:55 --> UTF-8 Support Enabled
INFO - 2020-08-21 17:36:55 --> Utf8 Class Initialized
INFO - 2020-08-21 17:36:55 --> URI Class Initialized
DEBUG - 2020-08-21 17:36:55 --> No URI present. Default controller set.
INFO - 2020-08-21 17:36:55 --> Router Class Initialized
INFO - 2020-08-21 17:36:55 --> Output Class Initialized
INFO - 2020-08-21 17:36:55 --> Security Class Initialized
DEBUG - 2020-08-21 17:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 17:36:55 --> Input Class Initialized
INFO - 2020-08-21 17:36:55 --> Language Class Initialized
INFO - 2020-08-21 17:36:55 --> Language Class Initialized
INFO - 2020-08-21 17:36:55 --> Config Class Initialized
INFO - 2020-08-21 17:36:55 --> Loader Class Initialized
INFO - 2020-08-21 17:36:55 --> Helper loaded: url_helper
INFO - 2020-08-21 17:36:55 --> Helper loaded: form_helper
INFO - 2020-08-21 17:36:55 --> Helper loaded: file_helper
INFO - 2020-08-21 17:36:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 17:36:55 --> Database Driver Class Initialized
DEBUG - 2020-08-21 17:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 17:36:55 --> Upload Class Initialized
INFO - 2020-08-21 17:36:55 --> Controller Class Initialized
DEBUG - 2020-08-21 17:36:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 17:36:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 17:36:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 17:36:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 17:36:55 --> Final output sent to browser
DEBUG - 2020-08-21 17:36:55 --> Total execution time: 0.0483
INFO - 2020-08-21 18:51:27 --> Config Class Initialized
INFO - 2020-08-21 18:51:27 --> Hooks Class Initialized
DEBUG - 2020-08-21 18:51:27 --> UTF-8 Support Enabled
INFO - 2020-08-21 18:51:27 --> Utf8 Class Initialized
INFO - 2020-08-21 18:51:27 --> URI Class Initialized
INFO - 2020-08-21 18:51:27 --> Router Class Initialized
INFO - 2020-08-21 18:51:27 --> Output Class Initialized
INFO - 2020-08-21 18:51:27 --> Security Class Initialized
DEBUG - 2020-08-21 18:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 18:51:27 --> Input Class Initialized
INFO - 2020-08-21 18:51:27 --> Language Class Initialized
INFO - 2020-08-21 18:51:27 --> Language Class Initialized
INFO - 2020-08-21 18:51:27 --> Config Class Initialized
INFO - 2020-08-21 18:51:27 --> Loader Class Initialized
INFO - 2020-08-21 18:51:27 --> Helper loaded: url_helper
INFO - 2020-08-21 18:51:27 --> Helper loaded: form_helper
INFO - 2020-08-21 18:51:27 --> Helper loaded: file_helper
INFO - 2020-08-21 18:51:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 18:51:27 --> Database Driver Class Initialized
DEBUG - 2020-08-21 18:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 18:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 18:51:27 --> Upload Class Initialized
INFO - 2020-08-21 18:51:27 --> Controller Class Initialized
ERROR - 2020-08-21 18:51:27 --> 404 Page Not Found: /index
INFO - 2020-08-21 18:51:27 --> Config Class Initialized
INFO - 2020-08-21 18:51:27 --> Hooks Class Initialized
DEBUG - 2020-08-21 18:51:27 --> UTF-8 Support Enabled
INFO - 2020-08-21 18:51:27 --> Utf8 Class Initialized
INFO - 2020-08-21 18:51:27 --> URI Class Initialized
INFO - 2020-08-21 18:51:27 --> Router Class Initialized
INFO - 2020-08-21 18:51:27 --> Output Class Initialized
INFO - 2020-08-21 18:51:27 --> Security Class Initialized
DEBUG - 2020-08-21 18:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 18:51:27 --> Input Class Initialized
INFO - 2020-08-21 18:51:27 --> Language Class Initialized
INFO - 2020-08-21 18:51:27 --> Language Class Initialized
INFO - 2020-08-21 18:51:27 --> Config Class Initialized
INFO - 2020-08-21 18:51:27 --> Loader Class Initialized
INFO - 2020-08-21 18:51:27 --> Helper loaded: url_helper
INFO - 2020-08-21 18:51:27 --> Helper loaded: form_helper
INFO - 2020-08-21 18:51:27 --> Helper loaded: file_helper
INFO - 2020-08-21 18:51:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 18:51:27 --> Database Driver Class Initialized
DEBUG - 2020-08-21 18:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 18:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 18:51:27 --> Upload Class Initialized
INFO - 2020-08-21 18:51:27 --> Controller Class Initialized
ERROR - 2020-08-21 18:51:27 --> 404 Page Not Found: /index
INFO - 2020-08-21 18:54:57 --> Config Class Initialized
INFO - 2020-08-21 18:54:57 --> Hooks Class Initialized
DEBUG - 2020-08-21 18:54:57 --> UTF-8 Support Enabled
INFO - 2020-08-21 18:54:57 --> Utf8 Class Initialized
INFO - 2020-08-21 18:54:57 --> URI Class Initialized
INFO - 2020-08-21 18:54:57 --> Router Class Initialized
INFO - 2020-08-21 18:54:57 --> Output Class Initialized
INFO - 2020-08-21 18:54:57 --> Security Class Initialized
DEBUG - 2020-08-21 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 18:54:57 --> Input Class Initialized
INFO - 2020-08-21 18:54:57 --> Language Class Initialized
INFO - 2020-08-21 18:54:57 --> Language Class Initialized
INFO - 2020-08-21 18:54:57 --> Config Class Initialized
INFO - 2020-08-21 18:54:57 --> Loader Class Initialized
INFO - 2020-08-21 18:54:57 --> Helper loaded: url_helper
INFO - 2020-08-21 18:54:57 --> Helper loaded: form_helper
INFO - 2020-08-21 18:54:57 --> Helper loaded: file_helper
INFO - 2020-08-21 18:54:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 18:54:57 --> Database Driver Class Initialized
DEBUG - 2020-08-21 18:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 18:54:57 --> Upload Class Initialized
INFO - 2020-08-21 18:54:57 --> Controller Class Initialized
DEBUG - 2020-08-21 18:54:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 18:54:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-21 18:54:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 18:54:57 --> Final output sent to browser
DEBUG - 2020-08-21 18:54:57 --> Total execution time: 0.0634
INFO - 2020-08-21 18:55:00 --> Config Class Initialized
INFO - 2020-08-21 18:55:00 --> Hooks Class Initialized
DEBUG - 2020-08-21 18:55:00 --> UTF-8 Support Enabled
INFO - 2020-08-21 18:55:00 --> Utf8 Class Initialized
INFO - 2020-08-21 18:55:00 --> URI Class Initialized
INFO - 2020-08-21 18:55:00 --> Router Class Initialized
INFO - 2020-08-21 18:55:00 --> Output Class Initialized
INFO - 2020-08-21 18:55:00 --> Security Class Initialized
DEBUG - 2020-08-21 18:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 18:55:00 --> Input Class Initialized
INFO - 2020-08-21 18:55:00 --> Language Class Initialized
INFO - 2020-08-21 18:55:00 --> Language Class Initialized
INFO - 2020-08-21 18:55:00 --> Config Class Initialized
INFO - 2020-08-21 18:55:00 --> Loader Class Initialized
INFO - 2020-08-21 18:55:00 --> Helper loaded: url_helper
INFO - 2020-08-21 18:55:00 --> Helper loaded: form_helper
INFO - 2020-08-21 18:55:00 --> Helper loaded: file_helper
INFO - 2020-08-21 18:55:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 18:55:00 --> Database Driver Class Initialized
DEBUG - 2020-08-21 18:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 18:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 18:55:00 --> Upload Class Initialized
INFO - 2020-08-21 18:55:00 --> Controller Class Initialized
ERROR - 2020-08-21 18:55:00 --> 404 Page Not Found: /index
INFO - 2020-08-21 18:56:54 --> Config Class Initialized
INFO - 2020-08-21 18:56:54 --> Hooks Class Initialized
DEBUG - 2020-08-21 18:56:54 --> UTF-8 Support Enabled
INFO - 2020-08-21 18:56:54 --> Utf8 Class Initialized
INFO - 2020-08-21 18:56:54 --> URI Class Initialized
INFO - 2020-08-21 18:56:54 --> Router Class Initialized
INFO - 2020-08-21 18:56:54 --> Output Class Initialized
INFO - 2020-08-21 18:56:54 --> Security Class Initialized
DEBUG - 2020-08-21 18:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 18:56:54 --> Input Class Initialized
INFO - 2020-08-21 18:56:54 --> Language Class Initialized
INFO - 2020-08-21 18:56:54 --> Language Class Initialized
INFO - 2020-08-21 18:56:54 --> Config Class Initialized
INFO - 2020-08-21 18:56:54 --> Loader Class Initialized
INFO - 2020-08-21 18:56:54 --> Helper loaded: url_helper
INFO - 2020-08-21 18:56:54 --> Helper loaded: form_helper
INFO - 2020-08-21 18:56:54 --> Helper loaded: file_helper
INFO - 2020-08-21 18:56:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 18:56:54 --> Database Driver Class Initialized
DEBUG - 2020-08-21 18:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 18:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 18:56:54 --> Upload Class Initialized
INFO - 2020-08-21 18:56:54 --> Controller Class Initialized
DEBUG - 2020-08-21 18:56:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 18:56:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-21 18:56:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 18:56:54 --> Final output sent to browser
DEBUG - 2020-08-21 18:56:54 --> Total execution time: 0.0496
INFO - 2020-08-21 18:56:55 --> Config Class Initialized
INFO - 2020-08-21 18:56:55 --> Hooks Class Initialized
DEBUG - 2020-08-21 18:56:55 --> UTF-8 Support Enabled
INFO - 2020-08-21 18:56:55 --> Utf8 Class Initialized
INFO - 2020-08-21 18:56:55 --> URI Class Initialized
INFO - 2020-08-21 18:56:55 --> Router Class Initialized
INFO - 2020-08-21 18:56:55 --> Output Class Initialized
INFO - 2020-08-21 18:56:55 --> Security Class Initialized
DEBUG - 2020-08-21 18:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 18:56:55 --> Input Class Initialized
INFO - 2020-08-21 18:56:55 --> Language Class Initialized
INFO - 2020-08-21 18:56:55 --> Language Class Initialized
INFO - 2020-08-21 18:56:55 --> Config Class Initialized
INFO - 2020-08-21 18:56:55 --> Loader Class Initialized
INFO - 2020-08-21 18:56:55 --> Helper loaded: url_helper
INFO - 2020-08-21 18:56:55 --> Helper loaded: form_helper
INFO - 2020-08-21 18:56:55 --> Helper loaded: file_helper
INFO - 2020-08-21 18:56:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 18:56:55 --> Database Driver Class Initialized
DEBUG - 2020-08-21 18:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 18:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 18:56:55 --> Upload Class Initialized
INFO - 2020-08-21 18:56:55 --> Controller Class Initialized
ERROR - 2020-08-21 18:56:55 --> 404 Page Not Found: /index
INFO - 2020-08-21 20:35:51 --> Config Class Initialized
INFO - 2020-08-21 20:35:51 --> Hooks Class Initialized
DEBUG - 2020-08-21 20:35:51 --> UTF-8 Support Enabled
INFO - 2020-08-21 20:35:51 --> Utf8 Class Initialized
INFO - 2020-08-21 20:35:51 --> URI Class Initialized
INFO - 2020-08-21 20:35:51 --> Router Class Initialized
INFO - 2020-08-21 20:35:51 --> Output Class Initialized
INFO - 2020-08-21 20:35:51 --> Security Class Initialized
DEBUG - 2020-08-21 20:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 20:35:51 --> Input Class Initialized
INFO - 2020-08-21 20:35:51 --> Language Class Initialized
INFO - 2020-08-21 20:35:51 --> Language Class Initialized
INFO - 2020-08-21 20:35:51 --> Config Class Initialized
INFO - 2020-08-21 20:35:51 --> Loader Class Initialized
INFO - 2020-08-21 20:35:51 --> Helper loaded: url_helper
INFO - 2020-08-21 20:35:51 --> Helper loaded: form_helper
INFO - 2020-08-21 20:35:51 --> Helper loaded: file_helper
INFO - 2020-08-21 20:35:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 20:35:51 --> Database Driver Class Initialized
DEBUG - 2020-08-21 20:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 20:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 20:35:51 --> Upload Class Initialized
INFO - 2020-08-21 20:35:51 --> Controller Class Initialized
ERROR - 2020-08-21 20:35:51 --> 404 Page Not Found: /index
INFO - 2020-08-21 20:35:52 --> Config Class Initialized
INFO - 2020-08-21 20:35:52 --> Hooks Class Initialized
DEBUG - 2020-08-21 20:35:52 --> UTF-8 Support Enabled
INFO - 2020-08-21 20:35:52 --> Utf8 Class Initialized
INFO - 2020-08-21 20:35:52 --> URI Class Initialized
DEBUG - 2020-08-21 20:35:52 --> No URI present. Default controller set.
INFO - 2020-08-21 20:35:52 --> Router Class Initialized
INFO - 2020-08-21 20:35:52 --> Output Class Initialized
INFO - 2020-08-21 20:35:52 --> Security Class Initialized
DEBUG - 2020-08-21 20:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 20:35:52 --> Input Class Initialized
INFO - 2020-08-21 20:35:52 --> Language Class Initialized
INFO - 2020-08-21 20:35:52 --> Language Class Initialized
INFO - 2020-08-21 20:35:52 --> Config Class Initialized
INFO - 2020-08-21 20:35:52 --> Loader Class Initialized
INFO - 2020-08-21 20:35:52 --> Helper loaded: url_helper
INFO - 2020-08-21 20:35:52 --> Helper loaded: form_helper
INFO - 2020-08-21 20:35:52 --> Helper loaded: file_helper
INFO - 2020-08-21 20:35:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 20:35:52 --> Database Driver Class Initialized
DEBUG - 2020-08-21 20:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 20:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 20:35:52 --> Upload Class Initialized
INFO - 2020-08-21 20:35:52 --> Controller Class Initialized
DEBUG - 2020-08-21 20:35:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 20:35:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 20:35:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 20:35:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 20:35:52 --> Final output sent to browser
DEBUG - 2020-08-21 20:35:52 --> Total execution time: 0.0507
INFO - 2020-08-21 21:20:20 --> Config Class Initialized
INFO - 2020-08-21 21:20:20 --> Hooks Class Initialized
DEBUG - 2020-08-21 21:20:20 --> UTF-8 Support Enabled
INFO - 2020-08-21 21:20:20 --> Utf8 Class Initialized
INFO - 2020-08-21 21:20:20 --> URI Class Initialized
DEBUG - 2020-08-21 21:20:20 --> No URI present. Default controller set.
INFO - 2020-08-21 21:20:20 --> Router Class Initialized
INFO - 2020-08-21 21:20:20 --> Output Class Initialized
INFO - 2020-08-21 21:20:20 --> Security Class Initialized
DEBUG - 2020-08-21 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 21:20:20 --> Input Class Initialized
INFO - 2020-08-21 21:20:20 --> Language Class Initialized
INFO - 2020-08-21 21:20:20 --> Language Class Initialized
INFO - 2020-08-21 21:20:20 --> Config Class Initialized
INFO - 2020-08-21 21:20:20 --> Loader Class Initialized
INFO - 2020-08-21 21:20:20 --> Helper loaded: url_helper
INFO - 2020-08-21 21:20:20 --> Helper loaded: form_helper
INFO - 2020-08-21 21:20:20 --> Helper loaded: file_helper
INFO - 2020-08-21 21:20:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 21:20:20 --> Database Driver Class Initialized
DEBUG - 2020-08-21 21:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 21:20:20 --> Upload Class Initialized
INFO - 2020-08-21 21:20:20 --> Controller Class Initialized
DEBUG - 2020-08-21 21:20:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 21:20:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 21:20:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 21:20:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 21:20:20 --> Final output sent to browser
DEBUG - 2020-08-21 21:20:20 --> Total execution time: 0.0511
INFO - 2020-08-21 21:20:32 --> Config Class Initialized
INFO - 2020-08-21 21:20:32 --> Hooks Class Initialized
DEBUG - 2020-08-21 21:20:32 --> UTF-8 Support Enabled
INFO - 2020-08-21 21:20:32 --> Utf8 Class Initialized
INFO - 2020-08-21 21:20:32 --> URI Class Initialized
INFO - 2020-08-21 21:20:32 --> Router Class Initialized
INFO - 2020-08-21 21:20:32 --> Output Class Initialized
INFO - 2020-08-21 21:20:32 --> Security Class Initialized
DEBUG - 2020-08-21 21:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 21:20:32 --> Input Class Initialized
INFO - 2020-08-21 21:20:32 --> Language Class Initialized
INFO - 2020-08-21 21:20:32 --> Language Class Initialized
INFO - 2020-08-21 21:20:32 --> Config Class Initialized
INFO - 2020-08-21 21:20:32 --> Loader Class Initialized
INFO - 2020-08-21 21:20:32 --> Helper loaded: url_helper
INFO - 2020-08-21 21:20:32 --> Helper loaded: form_helper
INFO - 2020-08-21 21:20:32 --> Helper loaded: file_helper
INFO - 2020-08-21 21:20:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 21:20:32 --> Database Driver Class Initialized
DEBUG - 2020-08-21 21:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 21:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 21:20:32 --> Upload Class Initialized
INFO - 2020-08-21 21:20:32 --> Controller Class Initialized
DEBUG - 2020-08-21 21:20:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 21:20:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 21:20:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 21:20:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 21:20:32 --> Final output sent to browser
DEBUG - 2020-08-21 21:20:32 --> Total execution time: 0.0549
INFO - 2020-08-21 21:20:40 --> Config Class Initialized
INFO - 2020-08-21 21:20:40 --> Hooks Class Initialized
DEBUG - 2020-08-21 21:20:40 --> UTF-8 Support Enabled
INFO - 2020-08-21 21:20:40 --> Utf8 Class Initialized
INFO - 2020-08-21 21:20:40 --> URI Class Initialized
INFO - 2020-08-21 21:20:40 --> Router Class Initialized
INFO - 2020-08-21 21:20:40 --> Output Class Initialized
INFO - 2020-08-21 21:20:40 --> Security Class Initialized
DEBUG - 2020-08-21 21:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 21:20:40 --> Input Class Initialized
INFO - 2020-08-21 21:20:40 --> Language Class Initialized
INFO - 2020-08-21 21:20:40 --> Language Class Initialized
INFO - 2020-08-21 21:20:40 --> Config Class Initialized
INFO - 2020-08-21 21:20:40 --> Loader Class Initialized
INFO - 2020-08-21 21:20:40 --> Helper loaded: url_helper
INFO - 2020-08-21 21:20:40 --> Helper loaded: form_helper
INFO - 2020-08-21 21:20:40 --> Helper loaded: file_helper
INFO - 2020-08-21 21:20:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 21:20:40 --> Database Driver Class Initialized
DEBUG - 2020-08-21 21:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 21:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 21:20:40 --> Upload Class Initialized
INFO - 2020-08-21 21:20:40 --> Controller Class Initialized
ERROR - 2020-08-21 21:20:40 --> 404 Page Not Found: /index
INFO - 2020-08-21 22:38:38 --> Config Class Initialized
INFO - 2020-08-21 22:38:38 --> Hooks Class Initialized
DEBUG - 2020-08-21 22:38:38 --> UTF-8 Support Enabled
INFO - 2020-08-21 22:38:38 --> Utf8 Class Initialized
INFO - 2020-08-21 22:38:38 --> URI Class Initialized
DEBUG - 2020-08-21 22:38:38 --> No URI present. Default controller set.
INFO - 2020-08-21 22:38:38 --> Router Class Initialized
INFO - 2020-08-21 22:38:38 --> Output Class Initialized
INFO - 2020-08-21 22:38:38 --> Security Class Initialized
DEBUG - 2020-08-21 22:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 22:38:38 --> Input Class Initialized
INFO - 2020-08-21 22:38:38 --> Language Class Initialized
INFO - 2020-08-21 22:38:38 --> Language Class Initialized
INFO - 2020-08-21 22:38:38 --> Config Class Initialized
INFO - 2020-08-21 22:38:38 --> Loader Class Initialized
INFO - 2020-08-21 22:38:38 --> Helper loaded: url_helper
INFO - 2020-08-21 22:38:38 --> Helper loaded: form_helper
INFO - 2020-08-21 22:38:38 --> Helper loaded: file_helper
INFO - 2020-08-21 22:38:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 22:38:38 --> Database Driver Class Initialized
DEBUG - 2020-08-21 22:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 22:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 22:38:38 --> Upload Class Initialized
INFO - 2020-08-21 22:38:38 --> Controller Class Initialized
DEBUG - 2020-08-21 22:38:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-21 22:38:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-21 22:38:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-21 22:38:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-21 22:38:38 --> Final output sent to browser
DEBUG - 2020-08-21 22:38:38 --> Total execution time: 0.0546
INFO - 2020-08-21 23:55:01 --> Config Class Initialized
INFO - 2020-08-21 23:55:01 --> Hooks Class Initialized
DEBUG - 2020-08-21 23:55:01 --> UTF-8 Support Enabled
INFO - 2020-08-21 23:55:01 --> Utf8 Class Initialized
INFO - 2020-08-21 23:55:01 --> URI Class Initialized
INFO - 2020-08-21 23:55:01 --> Router Class Initialized
INFO - 2020-08-21 23:55:01 --> Output Class Initialized
INFO - 2020-08-21 23:55:01 --> Security Class Initialized
DEBUG - 2020-08-21 23:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 23:55:01 --> Input Class Initialized
INFO - 2020-08-21 23:55:01 --> Language Class Initialized
INFO - 2020-08-21 23:55:01 --> Language Class Initialized
INFO - 2020-08-21 23:55:01 --> Config Class Initialized
INFO - 2020-08-21 23:55:01 --> Loader Class Initialized
INFO - 2020-08-21 23:55:01 --> Helper loaded: url_helper
INFO - 2020-08-21 23:55:01 --> Helper loaded: form_helper
INFO - 2020-08-21 23:55:01 --> Helper loaded: file_helper
INFO - 2020-08-21 23:55:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-21 23:55:01 --> Database Driver Class Initialized
DEBUG - 2020-08-21 23:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-21 23:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 23:55:01 --> Upload Class Initialized
INFO - 2020-08-21 23:55:01 --> Controller Class Initialized
ERROR - 2020-08-21 23:55:01 --> 404 Page Not Found: /index
