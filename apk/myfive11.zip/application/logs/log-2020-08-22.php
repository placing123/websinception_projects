<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-22 00:07:05 --> Config Class Initialized
INFO - 2020-08-22 00:07:05 --> Hooks Class Initialized
DEBUG - 2020-08-22 00:07:05 --> UTF-8 Support Enabled
INFO - 2020-08-22 00:07:05 --> Utf8 Class Initialized
INFO - 2020-08-22 00:07:05 --> URI Class Initialized
INFO - 2020-08-22 00:07:05 --> Router Class Initialized
INFO - 2020-08-22 00:07:05 --> Output Class Initialized
INFO - 2020-08-22 00:07:05 --> Security Class Initialized
DEBUG - 2020-08-22 00:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 00:07:05 --> Input Class Initialized
INFO - 2020-08-22 00:07:05 --> Language Class Initialized
INFO - 2020-08-22 00:07:05 --> Language Class Initialized
INFO - 2020-08-22 00:07:05 --> Config Class Initialized
INFO - 2020-08-22 00:07:05 --> Loader Class Initialized
INFO - 2020-08-22 00:07:05 --> Helper loaded: url_helper
INFO - 2020-08-22 00:07:05 --> Helper loaded: form_helper
INFO - 2020-08-22 00:07:05 --> Helper loaded: file_helper
INFO - 2020-08-22 00:07:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 00:07:05 --> Database Driver Class Initialized
DEBUG - 2020-08-22 00:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 00:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 00:07:05 --> Upload Class Initialized
INFO - 2020-08-22 00:07:05 --> Controller Class Initialized
ERROR - 2020-08-22 00:07:05 --> 404 Page Not Found: /index
INFO - 2020-08-22 03:05:44 --> Config Class Initialized
INFO - 2020-08-22 03:05:44 --> Hooks Class Initialized
DEBUG - 2020-08-22 03:05:44 --> UTF-8 Support Enabled
INFO - 2020-08-22 03:05:44 --> Utf8 Class Initialized
INFO - 2020-08-22 03:05:44 --> URI Class Initialized
INFO - 2020-08-22 03:05:44 --> Router Class Initialized
INFO - 2020-08-22 03:05:44 --> Output Class Initialized
INFO - 2020-08-22 03:05:44 --> Security Class Initialized
DEBUG - 2020-08-22 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 03:05:44 --> Input Class Initialized
INFO - 2020-08-22 03:05:44 --> Language Class Initialized
INFO - 2020-08-22 03:05:44 --> Language Class Initialized
INFO - 2020-08-22 03:05:44 --> Config Class Initialized
INFO - 2020-08-22 03:05:44 --> Loader Class Initialized
INFO - 2020-08-22 03:05:44 --> Helper loaded: url_helper
INFO - 2020-08-22 03:05:44 --> Helper loaded: form_helper
INFO - 2020-08-22 03:05:44 --> Helper loaded: file_helper
INFO - 2020-08-22 03:05:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 03:05:44 --> Database Driver Class Initialized
DEBUG - 2020-08-22 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 03:05:44 --> Upload Class Initialized
INFO - 2020-08-22 03:05:44 --> Controller Class Initialized
ERROR - 2020-08-22 03:05:44 --> 404 Page Not Found: /index
INFO - 2020-08-22 05:47:43 --> Config Class Initialized
INFO - 2020-08-22 05:47:43 --> Hooks Class Initialized
DEBUG - 2020-08-22 05:47:43 --> UTF-8 Support Enabled
INFO - 2020-08-22 05:47:43 --> Utf8 Class Initialized
INFO - 2020-08-22 05:47:43 --> URI Class Initialized
INFO - 2020-08-22 05:47:43 --> Router Class Initialized
INFO - 2020-08-22 05:47:43 --> Output Class Initialized
INFO - 2020-08-22 05:47:43 --> Security Class Initialized
DEBUG - 2020-08-22 05:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 05:47:43 --> Input Class Initialized
INFO - 2020-08-22 05:47:43 --> Language Class Initialized
INFO - 2020-08-22 05:47:43 --> Language Class Initialized
INFO - 2020-08-22 05:47:43 --> Config Class Initialized
INFO - 2020-08-22 05:47:43 --> Loader Class Initialized
INFO - 2020-08-22 05:47:43 --> Helper loaded: url_helper
INFO - 2020-08-22 05:47:43 --> Helper loaded: form_helper
INFO - 2020-08-22 05:47:43 --> Helper loaded: file_helper
INFO - 2020-08-22 05:47:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 05:47:43 --> Database Driver Class Initialized
DEBUG - 2020-08-22 05:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 05:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 05:47:43 --> Upload Class Initialized
INFO - 2020-08-22 05:47:43 --> Controller Class Initialized
ERROR - 2020-08-22 05:47:43 --> 404 Page Not Found: /index
INFO - 2020-08-22 05:47:47 --> Config Class Initialized
INFO - 2020-08-22 05:47:47 --> Hooks Class Initialized
DEBUG - 2020-08-22 05:47:47 --> UTF-8 Support Enabled
INFO - 2020-08-22 05:47:47 --> Utf8 Class Initialized
INFO - 2020-08-22 05:47:47 --> URI Class Initialized
INFO - 2020-08-22 05:47:47 --> Router Class Initialized
INFO - 2020-08-22 05:47:47 --> Output Class Initialized
INFO - 2020-08-22 05:47:47 --> Security Class Initialized
DEBUG - 2020-08-22 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 05:47:47 --> Input Class Initialized
INFO - 2020-08-22 05:47:47 --> Language Class Initialized
INFO - 2020-08-22 05:47:47 --> Language Class Initialized
INFO - 2020-08-22 05:47:47 --> Config Class Initialized
INFO - 2020-08-22 05:47:47 --> Loader Class Initialized
INFO - 2020-08-22 05:47:47 --> Helper loaded: url_helper
INFO - 2020-08-22 05:47:47 --> Helper loaded: form_helper
INFO - 2020-08-22 05:47:47 --> Helper loaded: file_helper
INFO - 2020-08-22 05:47:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 05:47:47 --> Database Driver Class Initialized
DEBUG - 2020-08-22 05:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 05:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 05:47:47 --> Upload Class Initialized
INFO - 2020-08-22 05:47:47 --> Controller Class Initialized
DEBUG - 2020-08-22 05:47:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 05:47:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-22 05:47:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 05:47:47 --> Final output sent to browser
DEBUG - 2020-08-22 05:47:47 --> Total execution time: 0.0595
INFO - 2020-08-22 05:54:43 --> Config Class Initialized
INFO - 2020-08-22 05:54:43 --> Hooks Class Initialized
DEBUG - 2020-08-22 05:54:43 --> UTF-8 Support Enabled
INFO - 2020-08-22 05:54:43 --> Utf8 Class Initialized
INFO - 2020-08-22 05:54:43 --> URI Class Initialized
INFO - 2020-08-22 05:54:43 --> Router Class Initialized
INFO - 2020-08-22 05:54:43 --> Output Class Initialized
INFO - 2020-08-22 05:54:43 --> Security Class Initialized
DEBUG - 2020-08-22 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 05:54:43 --> Input Class Initialized
INFO - 2020-08-22 05:54:43 --> Language Class Initialized
INFO - 2020-08-22 05:54:43 --> Language Class Initialized
INFO - 2020-08-22 05:54:43 --> Config Class Initialized
INFO - 2020-08-22 05:54:43 --> Loader Class Initialized
INFO - 2020-08-22 05:54:43 --> Helper loaded: url_helper
INFO - 2020-08-22 05:54:43 --> Helper loaded: form_helper
INFO - 2020-08-22 05:54:43 --> Helper loaded: file_helper
INFO - 2020-08-22 05:54:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 05:54:43 --> Database Driver Class Initialized
DEBUG - 2020-08-22 05:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 05:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 05:54:43 --> Upload Class Initialized
INFO - 2020-08-22 05:54:43 --> Controller Class Initialized
DEBUG - 2020-08-22 05:54:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 05:54:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-22 05:54:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 05:54:43 --> Final output sent to browser
DEBUG - 2020-08-22 05:54:43 --> Total execution time: 0.0543
INFO - 2020-08-22 05:59:06 --> Config Class Initialized
INFO - 2020-08-22 05:59:06 --> Hooks Class Initialized
DEBUG - 2020-08-22 05:59:06 --> UTF-8 Support Enabled
INFO - 2020-08-22 05:59:06 --> Utf8 Class Initialized
INFO - 2020-08-22 05:59:06 --> URI Class Initialized
DEBUG - 2020-08-22 05:59:06 --> No URI present. Default controller set.
INFO - 2020-08-22 05:59:06 --> Router Class Initialized
INFO - 2020-08-22 05:59:06 --> Output Class Initialized
INFO - 2020-08-22 05:59:06 --> Security Class Initialized
DEBUG - 2020-08-22 05:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 05:59:06 --> Input Class Initialized
INFO - 2020-08-22 05:59:06 --> Language Class Initialized
INFO - 2020-08-22 05:59:06 --> Language Class Initialized
INFO - 2020-08-22 05:59:06 --> Config Class Initialized
INFO - 2020-08-22 05:59:06 --> Loader Class Initialized
INFO - 2020-08-22 05:59:06 --> Helper loaded: url_helper
INFO - 2020-08-22 05:59:06 --> Helper loaded: form_helper
INFO - 2020-08-22 05:59:06 --> Helper loaded: file_helper
INFO - 2020-08-22 05:59:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 05:59:06 --> Database Driver Class Initialized
DEBUG - 2020-08-22 05:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 05:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 05:59:06 --> Upload Class Initialized
INFO - 2020-08-22 05:59:06 --> Controller Class Initialized
DEBUG - 2020-08-22 05:59:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 05:59:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 05:59:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 05:59:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 05:59:06 --> Final output sent to browser
DEBUG - 2020-08-22 05:59:06 --> Total execution time: 0.0523
INFO - 2020-08-22 06:00:02 --> Config Class Initialized
INFO - 2020-08-22 06:00:02 --> Hooks Class Initialized
DEBUG - 2020-08-22 06:00:02 --> UTF-8 Support Enabled
INFO - 2020-08-22 06:00:02 --> Utf8 Class Initialized
INFO - 2020-08-22 06:00:02 --> URI Class Initialized
INFO - 2020-08-22 06:00:02 --> Router Class Initialized
INFO - 2020-08-22 06:00:02 --> Output Class Initialized
INFO - 2020-08-22 06:00:02 --> Security Class Initialized
DEBUG - 2020-08-22 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 06:00:02 --> Input Class Initialized
INFO - 2020-08-22 06:00:02 --> Language Class Initialized
INFO - 2020-08-22 06:00:02 --> Language Class Initialized
INFO - 2020-08-22 06:00:02 --> Config Class Initialized
INFO - 2020-08-22 06:00:02 --> Loader Class Initialized
INFO - 2020-08-22 06:00:02 --> Helper loaded: url_helper
INFO - 2020-08-22 06:00:02 --> Helper loaded: form_helper
INFO - 2020-08-22 06:00:02 --> Helper loaded: file_helper
INFO - 2020-08-22 06:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 06:00:03 --> Database Driver Class Initialized
DEBUG - 2020-08-22 06:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 06:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 06:00:03 --> Upload Class Initialized
INFO - 2020-08-22 06:00:03 --> Controller Class Initialized
DEBUG - 2020-08-22 06:00:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 06:00:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-22 06:00:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 06:00:03 --> Final output sent to browser
DEBUG - 2020-08-22 06:00:03 --> Total execution time: 0.4430
INFO - 2020-08-22 07:08:06 --> Config Class Initialized
INFO - 2020-08-22 07:08:06 --> Hooks Class Initialized
DEBUG - 2020-08-22 07:08:06 --> UTF-8 Support Enabled
INFO - 2020-08-22 07:08:06 --> Utf8 Class Initialized
INFO - 2020-08-22 07:08:06 --> URI Class Initialized
DEBUG - 2020-08-22 07:08:06 --> No URI present. Default controller set.
INFO - 2020-08-22 07:08:06 --> Router Class Initialized
INFO - 2020-08-22 07:08:06 --> Output Class Initialized
INFO - 2020-08-22 07:08:06 --> Security Class Initialized
DEBUG - 2020-08-22 07:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 07:08:06 --> Input Class Initialized
INFO - 2020-08-22 07:08:06 --> Language Class Initialized
INFO - 2020-08-22 07:08:06 --> Language Class Initialized
INFO - 2020-08-22 07:08:06 --> Config Class Initialized
INFO - 2020-08-22 07:08:06 --> Loader Class Initialized
INFO - 2020-08-22 07:08:06 --> Helper loaded: url_helper
INFO - 2020-08-22 07:08:06 --> Helper loaded: form_helper
INFO - 2020-08-22 07:08:06 --> Helper loaded: file_helper
INFO - 2020-08-22 07:08:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 07:08:06 --> Database Driver Class Initialized
DEBUG - 2020-08-22 07:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 07:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 07:08:06 --> Upload Class Initialized
INFO - 2020-08-22 07:08:06 --> Controller Class Initialized
DEBUG - 2020-08-22 07:08:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 07:08:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 07:08:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 07:08:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 07:08:06 --> Final output sent to browser
DEBUG - 2020-08-22 07:08:06 --> Total execution time: 0.0510
INFO - 2020-08-22 08:50:04 --> Config Class Initialized
INFO - 2020-08-22 08:50:04 --> Hooks Class Initialized
DEBUG - 2020-08-22 08:50:04 --> UTF-8 Support Enabled
INFO - 2020-08-22 08:50:04 --> Utf8 Class Initialized
INFO - 2020-08-22 08:50:04 --> URI Class Initialized
INFO - 2020-08-22 08:50:04 --> Router Class Initialized
INFO - 2020-08-22 08:50:04 --> Output Class Initialized
INFO - 2020-08-22 08:50:04 --> Security Class Initialized
DEBUG - 2020-08-22 08:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 08:50:04 --> Input Class Initialized
INFO - 2020-08-22 08:50:04 --> Language Class Initialized
INFO - 2020-08-22 08:50:04 --> Language Class Initialized
INFO - 2020-08-22 08:50:04 --> Config Class Initialized
INFO - 2020-08-22 08:50:04 --> Loader Class Initialized
INFO - 2020-08-22 08:50:04 --> Helper loaded: url_helper
INFO - 2020-08-22 08:50:04 --> Helper loaded: form_helper
INFO - 2020-08-22 08:50:04 --> Helper loaded: file_helper
INFO - 2020-08-22 08:50:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 08:50:04 --> Database Driver Class Initialized
DEBUG - 2020-08-22 08:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 08:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 08:50:04 --> Upload Class Initialized
INFO - 2020-08-22 08:50:04 --> Controller Class Initialized
ERROR - 2020-08-22 08:50:04 --> 404 Page Not Found: /index
INFO - 2020-08-22 08:50:06 --> Config Class Initialized
INFO - 2020-08-22 08:50:06 --> Hooks Class Initialized
DEBUG - 2020-08-22 08:50:06 --> UTF-8 Support Enabled
INFO - 2020-08-22 08:50:06 --> Utf8 Class Initialized
INFO - 2020-08-22 08:50:06 --> URI Class Initialized
INFO - 2020-08-22 08:50:07 --> Router Class Initialized
INFO - 2020-08-22 08:50:07 --> Output Class Initialized
INFO - 2020-08-22 08:50:07 --> Security Class Initialized
DEBUG - 2020-08-22 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 08:50:07 --> Input Class Initialized
INFO - 2020-08-22 08:50:07 --> Language Class Initialized
INFO - 2020-08-22 08:50:07 --> Language Class Initialized
INFO - 2020-08-22 08:50:07 --> Config Class Initialized
INFO - 2020-08-22 08:50:07 --> Loader Class Initialized
INFO - 2020-08-22 08:50:07 --> Helper loaded: url_helper
INFO - 2020-08-22 08:50:07 --> Helper loaded: form_helper
INFO - 2020-08-22 08:50:07 --> Helper loaded: file_helper
INFO - 2020-08-22 08:50:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 08:50:07 --> Database Driver Class Initialized
DEBUG - 2020-08-22 08:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 08:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 08:50:07 --> Upload Class Initialized
INFO - 2020-08-22 08:50:07 --> Controller Class Initialized
DEBUG - 2020-08-22 08:50:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 08:50:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-22 08:50:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 08:50:07 --> Final output sent to browser
DEBUG - 2020-08-22 08:50:07 --> Total execution time: 0.0835
INFO - 2020-08-22 09:34:57 --> Config Class Initialized
INFO - 2020-08-22 09:34:57 --> Hooks Class Initialized
DEBUG - 2020-08-22 09:34:57 --> UTF-8 Support Enabled
INFO - 2020-08-22 09:34:57 --> Utf8 Class Initialized
INFO - 2020-08-22 09:34:57 --> URI Class Initialized
DEBUG - 2020-08-22 09:34:57 --> No URI present. Default controller set.
INFO - 2020-08-22 09:34:57 --> Router Class Initialized
INFO - 2020-08-22 09:34:57 --> Output Class Initialized
INFO - 2020-08-22 09:34:57 --> Security Class Initialized
DEBUG - 2020-08-22 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 09:34:57 --> Input Class Initialized
INFO - 2020-08-22 09:34:57 --> Language Class Initialized
INFO - 2020-08-22 09:34:57 --> Language Class Initialized
INFO - 2020-08-22 09:34:57 --> Config Class Initialized
INFO - 2020-08-22 09:34:57 --> Loader Class Initialized
INFO - 2020-08-22 09:34:57 --> Helper loaded: url_helper
INFO - 2020-08-22 09:34:57 --> Helper loaded: form_helper
INFO - 2020-08-22 09:34:57 --> Helper loaded: file_helper
INFO - 2020-08-22 09:34:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 09:34:57 --> Database Driver Class Initialized
DEBUG - 2020-08-22 09:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 09:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 09:34:57 --> Upload Class Initialized
INFO - 2020-08-22 09:34:57 --> Controller Class Initialized
DEBUG - 2020-08-22 09:34:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 09:34:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 09:34:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 09:34:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 09:34:57 --> Final output sent to browser
DEBUG - 2020-08-22 09:34:57 --> Total execution time: 0.0616
INFO - 2020-08-22 09:35:07 --> Config Class Initialized
INFO - 2020-08-22 09:35:07 --> Hooks Class Initialized
DEBUG - 2020-08-22 09:35:07 --> UTF-8 Support Enabled
INFO - 2020-08-22 09:35:07 --> Utf8 Class Initialized
INFO - 2020-08-22 09:35:07 --> URI Class Initialized
DEBUG - 2020-08-22 09:35:07 --> No URI present. Default controller set.
INFO - 2020-08-22 09:35:07 --> Router Class Initialized
INFO - 2020-08-22 09:35:07 --> Output Class Initialized
INFO - 2020-08-22 09:35:07 --> Security Class Initialized
DEBUG - 2020-08-22 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 09:35:07 --> Input Class Initialized
INFO - 2020-08-22 09:35:07 --> Language Class Initialized
INFO - 2020-08-22 09:35:07 --> Language Class Initialized
INFO - 2020-08-22 09:35:07 --> Config Class Initialized
INFO - 2020-08-22 09:35:07 --> Loader Class Initialized
INFO - 2020-08-22 09:35:07 --> Helper loaded: url_helper
INFO - 2020-08-22 09:35:07 --> Helper loaded: form_helper
INFO - 2020-08-22 09:35:07 --> Helper loaded: file_helper
INFO - 2020-08-22 09:35:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 09:35:07 --> Database Driver Class Initialized
DEBUG - 2020-08-22 09:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 09:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 09:35:07 --> Upload Class Initialized
INFO - 2020-08-22 09:35:07 --> Controller Class Initialized
DEBUG - 2020-08-22 09:35:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 09:35:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 09:35:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 09:35:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 09:35:07 --> Final output sent to browser
DEBUG - 2020-08-22 09:35:07 --> Total execution time: 0.0488
INFO - 2020-08-22 11:20:36 --> Config Class Initialized
INFO - 2020-08-22 11:20:36 --> Hooks Class Initialized
DEBUG - 2020-08-22 11:20:36 --> UTF-8 Support Enabled
INFO - 2020-08-22 11:20:36 --> Utf8 Class Initialized
INFO - 2020-08-22 11:20:36 --> URI Class Initialized
DEBUG - 2020-08-22 11:20:36 --> No URI present. Default controller set.
INFO - 2020-08-22 11:20:36 --> Router Class Initialized
INFO - 2020-08-22 11:20:36 --> Output Class Initialized
INFO - 2020-08-22 11:20:36 --> Security Class Initialized
DEBUG - 2020-08-22 11:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 11:20:36 --> Input Class Initialized
INFO - 2020-08-22 11:20:36 --> Language Class Initialized
INFO - 2020-08-22 11:20:36 --> Language Class Initialized
INFO - 2020-08-22 11:20:36 --> Config Class Initialized
INFO - 2020-08-22 11:20:36 --> Loader Class Initialized
INFO - 2020-08-22 11:20:36 --> Helper loaded: url_helper
INFO - 2020-08-22 11:20:36 --> Helper loaded: form_helper
INFO - 2020-08-22 11:20:36 --> Helper loaded: file_helper
INFO - 2020-08-22 11:20:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 11:20:36 --> Database Driver Class Initialized
DEBUG - 2020-08-22 11:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 11:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 11:20:36 --> Upload Class Initialized
INFO - 2020-08-22 11:20:36 --> Controller Class Initialized
DEBUG - 2020-08-22 11:20:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 11:20:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 11:20:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 11:20:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 11:20:36 --> Final output sent to browser
DEBUG - 2020-08-22 11:20:36 --> Total execution time: 0.0536
INFO - 2020-08-22 11:37:51 --> Config Class Initialized
INFO - 2020-08-22 11:37:51 --> Hooks Class Initialized
DEBUG - 2020-08-22 11:37:51 --> UTF-8 Support Enabled
INFO - 2020-08-22 11:37:51 --> Utf8 Class Initialized
INFO - 2020-08-22 11:37:51 --> URI Class Initialized
INFO - 2020-08-22 11:37:51 --> Router Class Initialized
INFO - 2020-08-22 11:37:51 --> Output Class Initialized
INFO - 2020-08-22 11:37:51 --> Security Class Initialized
DEBUG - 2020-08-22 11:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 11:37:51 --> Input Class Initialized
INFO - 2020-08-22 11:37:51 --> Language Class Initialized
INFO - 2020-08-22 11:37:51 --> Language Class Initialized
INFO - 2020-08-22 11:37:51 --> Config Class Initialized
INFO - 2020-08-22 11:37:51 --> Loader Class Initialized
INFO - 2020-08-22 11:37:51 --> Helper loaded: url_helper
INFO - 2020-08-22 11:37:51 --> Helper loaded: form_helper
INFO - 2020-08-22 11:37:51 --> Helper loaded: file_helper
INFO - 2020-08-22 11:37:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 11:37:51 --> Database Driver Class Initialized
DEBUG - 2020-08-22 11:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 11:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 11:37:51 --> Upload Class Initialized
INFO - 2020-08-22 11:37:51 --> Controller Class Initialized
ERROR - 2020-08-22 11:37:51 --> 404 Page Not Found: /index
INFO - 2020-08-22 12:34:36 --> Config Class Initialized
INFO - 2020-08-22 12:34:36 --> Hooks Class Initialized
DEBUG - 2020-08-22 12:34:36 --> UTF-8 Support Enabled
INFO - 2020-08-22 12:34:36 --> Utf8 Class Initialized
INFO - 2020-08-22 12:34:36 --> URI Class Initialized
DEBUG - 2020-08-22 12:34:36 --> No URI present. Default controller set.
INFO - 2020-08-22 12:34:36 --> Router Class Initialized
INFO - 2020-08-22 12:34:36 --> Output Class Initialized
INFO - 2020-08-22 12:34:36 --> Security Class Initialized
DEBUG - 2020-08-22 12:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 12:34:36 --> Input Class Initialized
INFO - 2020-08-22 12:34:36 --> Language Class Initialized
INFO - 2020-08-22 12:34:36 --> Language Class Initialized
INFO - 2020-08-22 12:34:36 --> Config Class Initialized
INFO - 2020-08-22 12:34:36 --> Loader Class Initialized
INFO - 2020-08-22 12:34:36 --> Helper loaded: url_helper
INFO - 2020-08-22 12:34:36 --> Helper loaded: form_helper
INFO - 2020-08-22 12:34:36 --> Helper loaded: file_helper
INFO - 2020-08-22 12:34:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 12:34:36 --> Database Driver Class Initialized
DEBUG - 2020-08-22 12:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 12:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 12:34:36 --> Upload Class Initialized
INFO - 2020-08-22 12:34:36 --> Controller Class Initialized
DEBUG - 2020-08-22 12:34:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 12:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 12:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 12:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 12:34:36 --> Final output sent to browser
DEBUG - 2020-08-22 12:34:36 --> Total execution time: 0.0503
INFO - 2020-08-22 12:56:03 --> Config Class Initialized
INFO - 2020-08-22 12:56:03 --> Hooks Class Initialized
DEBUG - 2020-08-22 12:56:03 --> UTF-8 Support Enabled
INFO - 2020-08-22 12:56:03 --> Utf8 Class Initialized
INFO - 2020-08-22 12:56:03 --> URI Class Initialized
DEBUG - 2020-08-22 12:56:03 --> No URI present. Default controller set.
INFO - 2020-08-22 12:56:03 --> Router Class Initialized
INFO - 2020-08-22 12:56:03 --> Output Class Initialized
INFO - 2020-08-22 12:56:03 --> Security Class Initialized
DEBUG - 2020-08-22 12:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 12:56:03 --> Input Class Initialized
INFO - 2020-08-22 12:56:03 --> Language Class Initialized
INFO - 2020-08-22 12:56:03 --> Language Class Initialized
INFO - 2020-08-22 12:56:03 --> Config Class Initialized
INFO - 2020-08-22 12:56:03 --> Loader Class Initialized
INFO - 2020-08-22 12:56:03 --> Helper loaded: url_helper
INFO - 2020-08-22 12:56:03 --> Helper loaded: form_helper
INFO - 2020-08-22 12:56:03 --> Helper loaded: file_helper
INFO - 2020-08-22 12:56:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 12:56:03 --> Database Driver Class Initialized
DEBUG - 2020-08-22 12:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 12:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 12:56:03 --> Upload Class Initialized
INFO - 2020-08-22 12:56:03 --> Controller Class Initialized
DEBUG - 2020-08-22 12:56:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 12:56:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 12:56:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 12:56:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 12:56:03 --> Final output sent to browser
DEBUG - 2020-08-22 12:56:03 --> Total execution time: 0.0567
INFO - 2020-08-22 13:04:59 --> Config Class Initialized
INFO - 2020-08-22 13:04:59 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:04:59 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:04:59 --> Utf8 Class Initialized
INFO - 2020-08-22 13:04:59 --> URI Class Initialized
INFO - 2020-08-22 13:04:59 --> Router Class Initialized
INFO - 2020-08-22 13:04:59 --> Output Class Initialized
INFO - 2020-08-22 13:04:59 --> Security Class Initialized
DEBUG - 2020-08-22 13:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:04:59 --> Input Class Initialized
INFO - 2020-08-22 13:04:59 --> Language Class Initialized
INFO - 2020-08-22 13:04:59 --> Language Class Initialized
INFO - 2020-08-22 13:04:59 --> Config Class Initialized
INFO - 2020-08-22 13:04:59 --> Loader Class Initialized
INFO - 2020-08-22 13:04:59 --> Helper loaded: url_helper
INFO - 2020-08-22 13:04:59 --> Helper loaded: form_helper
INFO - 2020-08-22 13:04:59 --> Helper loaded: file_helper
INFO - 2020-08-22 13:04:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:04:59 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:04:59 --> Upload Class Initialized
INFO - 2020-08-22 13:04:59 --> Controller Class Initialized
DEBUG - 2020-08-22 13:04:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 13:04:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 13:04:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 13:04:59 --> Final output sent to browser
DEBUG - 2020-08-22 13:04:59 --> Total execution time: 0.0539
INFO - 2020-08-22 13:05:01 --> Config Class Initialized
INFO - 2020-08-22 13:05:01 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:05:01 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:05:01 --> Utf8 Class Initialized
INFO - 2020-08-22 13:05:01 --> URI Class Initialized
INFO - 2020-08-22 13:05:01 --> Router Class Initialized
INFO - 2020-08-22 13:05:01 --> Output Class Initialized
INFO - 2020-08-22 13:05:01 --> Security Class Initialized
DEBUG - 2020-08-22 13:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:05:01 --> Input Class Initialized
INFO - 2020-08-22 13:05:01 --> Language Class Initialized
INFO - 2020-08-22 13:05:01 --> Language Class Initialized
INFO - 2020-08-22 13:05:01 --> Config Class Initialized
INFO - 2020-08-22 13:05:01 --> Loader Class Initialized
INFO - 2020-08-22 13:05:01 --> Helper loaded: url_helper
INFO - 2020-08-22 13:05:01 --> Helper loaded: form_helper
INFO - 2020-08-22 13:05:01 --> Helper loaded: file_helper
INFO - 2020-08-22 13:05:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:05:01 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:05:01 --> Upload Class Initialized
INFO - 2020-08-22 13:05:01 --> Controller Class Initialized
ERROR - 2020-08-22 13:05:01 --> 404 Page Not Found: /index
INFO - 2020-08-22 13:29:37 --> Config Class Initialized
INFO - 2020-08-22 13:29:37 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:29:37 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:29:37 --> Utf8 Class Initialized
INFO - 2020-08-22 13:29:37 --> URI Class Initialized
DEBUG - 2020-08-22 13:29:37 --> No URI present. Default controller set.
INFO - 2020-08-22 13:29:37 --> Router Class Initialized
INFO - 2020-08-22 13:29:37 --> Output Class Initialized
INFO - 2020-08-22 13:29:37 --> Security Class Initialized
DEBUG - 2020-08-22 13:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:29:37 --> Input Class Initialized
INFO - 2020-08-22 13:29:37 --> Language Class Initialized
INFO - 2020-08-22 13:29:37 --> Language Class Initialized
INFO - 2020-08-22 13:29:37 --> Config Class Initialized
INFO - 2020-08-22 13:29:37 --> Loader Class Initialized
INFO - 2020-08-22 13:29:37 --> Helper loaded: url_helper
INFO - 2020-08-22 13:29:37 --> Helper loaded: form_helper
INFO - 2020-08-22 13:29:37 --> Helper loaded: file_helper
INFO - 2020-08-22 13:29:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:29:37 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:29:37 --> Upload Class Initialized
INFO - 2020-08-22 13:29:37 --> Controller Class Initialized
DEBUG - 2020-08-22 13:29:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 13:29:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 13:29:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 13:29:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 13:29:37 --> Final output sent to browser
DEBUG - 2020-08-22 13:29:37 --> Total execution time: 0.0605
INFO - 2020-08-22 13:50:57 --> Config Class Initialized
INFO - 2020-08-22 13:50:57 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:50:57 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:50:57 --> Utf8 Class Initialized
INFO - 2020-08-22 13:50:57 --> URI Class Initialized
INFO - 2020-08-22 13:50:57 --> Router Class Initialized
INFO - 2020-08-22 13:50:57 --> Output Class Initialized
INFO - 2020-08-22 13:50:57 --> Security Class Initialized
DEBUG - 2020-08-22 13:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:50:57 --> Input Class Initialized
INFO - 2020-08-22 13:50:57 --> Language Class Initialized
INFO - 2020-08-22 13:50:57 --> Language Class Initialized
INFO - 2020-08-22 13:50:57 --> Config Class Initialized
INFO - 2020-08-22 13:50:57 --> Loader Class Initialized
INFO - 2020-08-22 13:50:57 --> Helper loaded: url_helper
INFO - 2020-08-22 13:50:57 --> Helper loaded: form_helper
INFO - 2020-08-22 13:50:57 --> Helper loaded: file_helper
INFO - 2020-08-22 13:50:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:50:57 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:50:57 --> Upload Class Initialized
INFO - 2020-08-22 13:50:57 --> Controller Class Initialized
DEBUG - 2020-08-22 13:50:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 13:50:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 13:50:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 13:50:57 --> Final output sent to browser
DEBUG - 2020-08-22 13:50:57 --> Total execution time: 0.0499
INFO - 2020-08-22 13:50:58 --> Config Class Initialized
INFO - 2020-08-22 13:50:58 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:50:58 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:50:58 --> Utf8 Class Initialized
INFO - 2020-08-22 13:50:58 --> URI Class Initialized
INFO - 2020-08-22 13:50:58 --> Router Class Initialized
INFO - 2020-08-22 13:50:58 --> Output Class Initialized
INFO - 2020-08-22 13:50:58 --> Security Class Initialized
DEBUG - 2020-08-22 13:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:50:58 --> Input Class Initialized
INFO - 2020-08-22 13:50:58 --> Language Class Initialized
INFO - 2020-08-22 13:50:58 --> Language Class Initialized
INFO - 2020-08-22 13:50:58 --> Config Class Initialized
INFO - 2020-08-22 13:50:58 --> Loader Class Initialized
INFO - 2020-08-22 13:50:58 --> Helper loaded: url_helper
INFO - 2020-08-22 13:50:58 --> Helper loaded: form_helper
INFO - 2020-08-22 13:50:58 --> Helper loaded: file_helper
INFO - 2020-08-22 13:50:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:50:58 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:50:58 --> Upload Class Initialized
INFO - 2020-08-22 13:50:58 --> Controller Class Initialized
ERROR - 2020-08-22 13:50:58 --> 404 Page Not Found: /index
INFO - 2020-08-22 13:51:17 --> Config Class Initialized
INFO - 2020-08-22 13:51:17 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:51:17 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:51:17 --> Utf8 Class Initialized
INFO - 2020-08-22 13:51:17 --> URI Class Initialized
INFO - 2020-08-22 13:51:17 --> Router Class Initialized
INFO - 2020-08-22 13:51:17 --> Output Class Initialized
INFO - 2020-08-22 13:51:17 --> Security Class Initialized
DEBUG - 2020-08-22 13:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:51:17 --> Input Class Initialized
INFO - 2020-08-22 13:51:17 --> Language Class Initialized
INFO - 2020-08-22 13:51:17 --> Language Class Initialized
INFO - 2020-08-22 13:51:17 --> Config Class Initialized
INFO - 2020-08-22 13:51:17 --> Loader Class Initialized
INFO - 2020-08-22 13:51:17 --> Helper loaded: url_helper
INFO - 2020-08-22 13:51:17 --> Helper loaded: form_helper
INFO - 2020-08-22 13:51:17 --> Helper loaded: file_helper
INFO - 2020-08-22 13:51:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:51:17 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:51:17 --> Upload Class Initialized
INFO - 2020-08-22 13:51:17 --> Controller Class Initialized
ERROR - 2020-08-22 13:51:17 --> 404 Page Not Found: /index
INFO - 2020-08-22 13:56:37 --> Config Class Initialized
INFO - 2020-08-22 13:56:37 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:56:37 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:56:37 --> Utf8 Class Initialized
INFO - 2020-08-22 13:56:37 --> URI Class Initialized
INFO - 2020-08-22 13:56:37 --> Router Class Initialized
INFO - 2020-08-22 13:56:37 --> Output Class Initialized
INFO - 2020-08-22 13:56:37 --> Security Class Initialized
DEBUG - 2020-08-22 13:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:56:37 --> Input Class Initialized
INFO - 2020-08-22 13:56:37 --> Language Class Initialized
INFO - 2020-08-22 13:56:37 --> Language Class Initialized
INFO - 2020-08-22 13:56:37 --> Config Class Initialized
INFO - 2020-08-22 13:56:37 --> Loader Class Initialized
INFO - 2020-08-22 13:56:37 --> Helper loaded: url_helper
INFO - 2020-08-22 13:56:37 --> Helper loaded: form_helper
INFO - 2020-08-22 13:56:37 --> Helper loaded: file_helper
INFO - 2020-08-22 13:56:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:56:37 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:56:37 --> Upload Class Initialized
INFO - 2020-08-22 13:56:37 --> Controller Class Initialized
DEBUG - 2020-08-22 13:56:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 13:56:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 13:56:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 13:56:37 --> Final output sent to browser
DEBUG - 2020-08-22 13:56:37 --> Total execution time: 0.0566
INFO - 2020-08-22 13:56:38 --> Config Class Initialized
INFO - 2020-08-22 13:56:38 --> Hooks Class Initialized
DEBUG - 2020-08-22 13:56:38 --> UTF-8 Support Enabled
INFO - 2020-08-22 13:56:38 --> Utf8 Class Initialized
INFO - 2020-08-22 13:56:38 --> URI Class Initialized
INFO - 2020-08-22 13:56:38 --> Router Class Initialized
INFO - 2020-08-22 13:56:38 --> Output Class Initialized
INFO - 2020-08-22 13:56:38 --> Security Class Initialized
DEBUG - 2020-08-22 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 13:56:38 --> Input Class Initialized
INFO - 2020-08-22 13:56:38 --> Language Class Initialized
INFO - 2020-08-22 13:56:38 --> Language Class Initialized
INFO - 2020-08-22 13:56:38 --> Config Class Initialized
INFO - 2020-08-22 13:56:38 --> Loader Class Initialized
INFO - 2020-08-22 13:56:38 --> Helper loaded: url_helper
INFO - 2020-08-22 13:56:38 --> Helper loaded: form_helper
INFO - 2020-08-22 13:56:38 --> Helper loaded: file_helper
INFO - 2020-08-22 13:56:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 13:56:38 --> Database Driver Class Initialized
DEBUG - 2020-08-22 13:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 13:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 13:56:38 --> Upload Class Initialized
INFO - 2020-08-22 13:56:38 --> Controller Class Initialized
ERROR - 2020-08-22 13:56:38 --> 404 Page Not Found: /index
INFO - 2020-08-22 15:12:03 --> Config Class Initialized
INFO - 2020-08-22 15:12:03 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:12:03 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:12:03 --> Utf8 Class Initialized
INFO - 2020-08-22 15:12:03 --> URI Class Initialized
INFO - 2020-08-22 15:12:03 --> Router Class Initialized
INFO - 2020-08-22 15:12:03 --> Output Class Initialized
INFO - 2020-08-22 15:12:03 --> Security Class Initialized
DEBUG - 2020-08-22 15:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:12:03 --> Input Class Initialized
INFO - 2020-08-22 15:12:03 --> Language Class Initialized
INFO - 2020-08-22 15:12:03 --> Language Class Initialized
INFO - 2020-08-22 15:12:03 --> Config Class Initialized
INFO - 2020-08-22 15:12:03 --> Loader Class Initialized
INFO - 2020-08-22 15:12:03 --> Helper loaded: url_helper
INFO - 2020-08-22 15:12:03 --> Helper loaded: form_helper
INFO - 2020-08-22 15:12:03 --> Helper loaded: file_helper
INFO - 2020-08-22 15:12:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:12:03 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:12:03 --> Upload Class Initialized
INFO - 2020-08-22 15:12:03 --> Controller Class Initialized
DEBUG - 2020-08-22 15:12:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:12:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 15:12:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:12:03 --> Final output sent to browser
DEBUG - 2020-08-22 15:12:03 --> Total execution time: 0.0581
INFO - 2020-08-22 15:24:06 --> Config Class Initialized
INFO - 2020-08-22 15:24:06 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:24:06 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:24:06 --> Utf8 Class Initialized
INFO - 2020-08-22 15:24:06 --> URI Class Initialized
INFO - 2020-08-22 15:24:07 --> Router Class Initialized
INFO - 2020-08-22 15:24:07 --> Output Class Initialized
INFO - 2020-08-22 15:24:07 --> Security Class Initialized
DEBUG - 2020-08-22 15:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:24:07 --> Input Class Initialized
INFO - 2020-08-22 15:24:07 --> Language Class Initialized
INFO - 2020-08-22 15:24:07 --> Language Class Initialized
INFO - 2020-08-22 15:24:07 --> Config Class Initialized
INFO - 2020-08-22 15:24:07 --> Loader Class Initialized
INFO - 2020-08-22 15:24:07 --> Helper loaded: url_helper
INFO - 2020-08-22 15:24:07 --> Helper loaded: form_helper
INFO - 2020-08-22 15:24:07 --> Helper loaded: file_helper
INFO - 2020-08-22 15:24:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:24:07 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:24:07 --> Upload Class Initialized
INFO - 2020-08-22 15:24:07 --> Controller Class Initialized
DEBUG - 2020-08-22 15:24:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:24:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 15:24:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:24:07 --> Final output sent to browser
DEBUG - 2020-08-22 15:24:07 --> Total execution time: 0.0658
INFO - 2020-08-22 15:24:08 --> Config Class Initialized
INFO - 2020-08-22 15:24:08 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:24:08 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:24:08 --> Utf8 Class Initialized
INFO - 2020-08-22 15:24:08 --> URI Class Initialized
INFO - 2020-08-22 15:24:08 --> Router Class Initialized
INFO - 2020-08-22 15:24:08 --> Output Class Initialized
INFO - 2020-08-22 15:24:08 --> Security Class Initialized
DEBUG - 2020-08-22 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:24:08 --> Input Class Initialized
INFO - 2020-08-22 15:24:08 --> Language Class Initialized
INFO - 2020-08-22 15:24:08 --> Language Class Initialized
INFO - 2020-08-22 15:24:08 --> Config Class Initialized
INFO - 2020-08-22 15:24:08 --> Loader Class Initialized
INFO - 2020-08-22 15:24:08 --> Helper loaded: url_helper
INFO - 2020-08-22 15:24:08 --> Helper loaded: form_helper
INFO - 2020-08-22 15:24:08 --> Helper loaded: file_helper
INFO - 2020-08-22 15:24:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:24:08 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:24:08 --> Upload Class Initialized
INFO - 2020-08-22 15:24:08 --> Controller Class Initialized
ERROR - 2020-08-22 15:24:08 --> 404 Page Not Found: /index
INFO - 2020-08-22 15:32:05 --> Config Class Initialized
INFO - 2020-08-22 15:32:05 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:32:05 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:32:05 --> Utf8 Class Initialized
INFO - 2020-08-22 15:32:05 --> URI Class Initialized
INFO - 2020-08-22 15:32:05 --> Router Class Initialized
INFO - 2020-08-22 15:32:05 --> Output Class Initialized
INFO - 2020-08-22 15:32:05 --> Security Class Initialized
DEBUG - 2020-08-22 15:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:32:05 --> Input Class Initialized
INFO - 2020-08-22 15:32:05 --> Language Class Initialized
INFO - 2020-08-22 15:32:05 --> Language Class Initialized
INFO - 2020-08-22 15:32:05 --> Config Class Initialized
INFO - 2020-08-22 15:32:05 --> Loader Class Initialized
INFO - 2020-08-22 15:32:05 --> Helper loaded: url_helper
INFO - 2020-08-22 15:32:05 --> Helper loaded: form_helper
INFO - 2020-08-22 15:32:05 --> Helper loaded: file_helper
INFO - 2020-08-22 15:32:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:32:05 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:32:05 --> Upload Class Initialized
INFO - 2020-08-22 15:32:05 --> Controller Class Initialized
DEBUG - 2020-08-22 15:32:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:32:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 15:32:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:32:05 --> Final output sent to browser
DEBUG - 2020-08-22 15:32:05 --> Total execution time: 0.0519
INFO - 2020-08-22 15:32:07 --> Config Class Initialized
INFO - 2020-08-22 15:32:07 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:32:07 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:32:07 --> Utf8 Class Initialized
INFO - 2020-08-22 15:32:07 --> URI Class Initialized
INFO - 2020-08-22 15:32:07 --> Router Class Initialized
INFO - 2020-08-22 15:32:07 --> Output Class Initialized
INFO - 2020-08-22 15:32:07 --> Security Class Initialized
DEBUG - 2020-08-22 15:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:32:07 --> Input Class Initialized
INFO - 2020-08-22 15:32:07 --> Language Class Initialized
INFO - 2020-08-22 15:32:07 --> Language Class Initialized
INFO - 2020-08-22 15:32:07 --> Config Class Initialized
INFO - 2020-08-22 15:32:07 --> Loader Class Initialized
INFO - 2020-08-22 15:32:07 --> Helper loaded: url_helper
INFO - 2020-08-22 15:32:07 --> Helper loaded: form_helper
INFO - 2020-08-22 15:32:07 --> Helper loaded: file_helper
INFO - 2020-08-22 15:32:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:32:07 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:32:07 --> Upload Class Initialized
INFO - 2020-08-22 15:32:07 --> Controller Class Initialized
ERROR - 2020-08-22 15:32:07 --> 404 Page Not Found: /index
INFO - 2020-08-22 15:39:19 --> Config Class Initialized
INFO - 2020-08-22 15:39:19 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:39:19 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:39:19 --> Utf8 Class Initialized
INFO - 2020-08-22 15:39:19 --> URI Class Initialized
INFO - 2020-08-22 15:39:19 --> Router Class Initialized
INFO - 2020-08-22 15:39:19 --> Output Class Initialized
INFO - 2020-08-22 15:39:19 --> Security Class Initialized
DEBUG - 2020-08-22 15:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:39:19 --> Input Class Initialized
INFO - 2020-08-22 15:39:19 --> Language Class Initialized
INFO - 2020-08-22 15:39:19 --> Language Class Initialized
INFO - 2020-08-22 15:39:19 --> Config Class Initialized
INFO - 2020-08-22 15:39:19 --> Loader Class Initialized
INFO - 2020-08-22 15:39:19 --> Helper loaded: url_helper
INFO - 2020-08-22 15:39:19 --> Helper loaded: form_helper
INFO - 2020-08-22 15:39:19 --> Helper loaded: file_helper
INFO - 2020-08-22 15:39:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:39:19 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:39:19 --> Upload Class Initialized
INFO - 2020-08-22 15:39:19 --> Controller Class Initialized
DEBUG - 2020-08-22 15:39:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:39:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 15:39:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:39:19 --> Final output sent to browser
DEBUG - 2020-08-22 15:39:19 --> Total execution time: 0.0660
INFO - 2020-08-22 15:39:21 --> Config Class Initialized
INFO - 2020-08-22 15:39:21 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:39:21 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:39:21 --> Utf8 Class Initialized
INFO - 2020-08-22 15:39:21 --> URI Class Initialized
INFO - 2020-08-22 15:39:21 --> Router Class Initialized
INFO - 2020-08-22 15:39:21 --> Output Class Initialized
INFO - 2020-08-22 15:39:21 --> Security Class Initialized
DEBUG - 2020-08-22 15:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:39:21 --> Input Class Initialized
INFO - 2020-08-22 15:39:21 --> Language Class Initialized
INFO - 2020-08-22 15:39:21 --> Language Class Initialized
INFO - 2020-08-22 15:39:21 --> Config Class Initialized
INFO - 2020-08-22 15:39:21 --> Loader Class Initialized
INFO - 2020-08-22 15:39:21 --> Helper loaded: url_helper
INFO - 2020-08-22 15:39:21 --> Helper loaded: form_helper
INFO - 2020-08-22 15:39:21 --> Helper loaded: file_helper
INFO - 2020-08-22 15:39:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:39:21 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:39:21 --> Upload Class Initialized
INFO - 2020-08-22 15:39:21 --> Controller Class Initialized
ERROR - 2020-08-22 15:39:21 --> 404 Page Not Found: /index
INFO - 2020-08-22 15:45:12 --> Config Class Initialized
INFO - 2020-08-22 15:45:12 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:45:12 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:45:12 --> Utf8 Class Initialized
INFO - 2020-08-22 15:45:12 --> URI Class Initialized
INFO - 2020-08-22 15:45:12 --> Router Class Initialized
INFO - 2020-08-22 15:45:12 --> Output Class Initialized
INFO - 2020-08-22 15:45:12 --> Security Class Initialized
DEBUG - 2020-08-22 15:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:45:12 --> Input Class Initialized
INFO - 2020-08-22 15:45:12 --> Language Class Initialized
INFO - 2020-08-22 15:45:12 --> Language Class Initialized
INFO - 2020-08-22 15:45:12 --> Config Class Initialized
INFO - 2020-08-22 15:45:12 --> Loader Class Initialized
INFO - 2020-08-22 15:45:12 --> Helper loaded: url_helper
INFO - 2020-08-22 15:45:12 --> Helper loaded: form_helper
INFO - 2020-08-22 15:45:12 --> Helper loaded: file_helper
INFO - 2020-08-22 15:45:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:45:12 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:45:12 --> Upload Class Initialized
INFO - 2020-08-22 15:45:12 --> Controller Class Initialized
DEBUG - 2020-08-22 15:45:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:45:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 15:45:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:45:12 --> Final output sent to browser
DEBUG - 2020-08-22 15:45:12 --> Total execution time: 0.0490
INFO - 2020-08-22 15:45:13 --> Config Class Initialized
INFO - 2020-08-22 15:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:45:13 --> Utf8 Class Initialized
INFO - 2020-08-22 15:45:13 --> URI Class Initialized
INFO - 2020-08-22 15:45:13 --> Router Class Initialized
INFO - 2020-08-22 15:45:13 --> Output Class Initialized
INFO - 2020-08-22 15:45:13 --> Security Class Initialized
DEBUG - 2020-08-22 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:45:13 --> Input Class Initialized
INFO - 2020-08-22 15:45:13 --> Language Class Initialized
INFO - 2020-08-22 15:45:13 --> Language Class Initialized
INFO - 2020-08-22 15:45:13 --> Config Class Initialized
INFO - 2020-08-22 15:45:13 --> Loader Class Initialized
INFO - 2020-08-22 15:45:13 --> Helper loaded: url_helper
INFO - 2020-08-22 15:45:13 --> Helper loaded: form_helper
INFO - 2020-08-22 15:45:13 --> Helper loaded: file_helper
INFO - 2020-08-22 15:45:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:45:13 --> Upload Class Initialized
INFO - 2020-08-22 15:45:13 --> Controller Class Initialized
ERROR - 2020-08-22 15:45:13 --> 404 Page Not Found: /index
INFO - 2020-08-22 15:51:08 --> Config Class Initialized
INFO - 2020-08-22 15:51:08 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:51:08 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:51:08 --> Utf8 Class Initialized
INFO - 2020-08-22 15:51:08 --> URI Class Initialized
INFO - 2020-08-22 15:51:08 --> Router Class Initialized
INFO - 2020-08-22 15:51:08 --> Output Class Initialized
INFO - 2020-08-22 15:51:08 --> Security Class Initialized
DEBUG - 2020-08-22 15:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:51:08 --> Input Class Initialized
INFO - 2020-08-22 15:51:08 --> Language Class Initialized
INFO - 2020-08-22 15:51:08 --> Language Class Initialized
INFO - 2020-08-22 15:51:08 --> Config Class Initialized
INFO - 2020-08-22 15:51:08 --> Loader Class Initialized
INFO - 2020-08-22 15:51:08 --> Helper loaded: url_helper
INFO - 2020-08-22 15:51:08 --> Helper loaded: form_helper
INFO - 2020-08-22 15:51:08 --> Helper loaded: file_helper
INFO - 2020-08-22 15:51:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:51:08 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:51:08 --> Upload Class Initialized
INFO - 2020-08-22 15:51:08 --> Controller Class Initialized
DEBUG - 2020-08-22 15:51:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:51:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 15:51:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:51:08 --> Final output sent to browser
DEBUG - 2020-08-22 15:51:08 --> Total execution time: 0.0469
INFO - 2020-08-22 15:51:10 --> Config Class Initialized
INFO - 2020-08-22 15:51:10 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:51:10 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:51:10 --> Utf8 Class Initialized
INFO - 2020-08-22 15:51:10 --> URI Class Initialized
INFO - 2020-08-22 15:51:10 --> Router Class Initialized
INFO - 2020-08-22 15:51:10 --> Output Class Initialized
INFO - 2020-08-22 15:51:10 --> Security Class Initialized
DEBUG - 2020-08-22 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:51:10 --> Input Class Initialized
INFO - 2020-08-22 15:51:10 --> Language Class Initialized
INFO - 2020-08-22 15:51:10 --> Language Class Initialized
INFO - 2020-08-22 15:51:10 --> Config Class Initialized
INFO - 2020-08-22 15:51:10 --> Loader Class Initialized
INFO - 2020-08-22 15:51:10 --> Helper loaded: url_helper
INFO - 2020-08-22 15:51:10 --> Helper loaded: form_helper
INFO - 2020-08-22 15:51:10 --> Helper loaded: file_helper
INFO - 2020-08-22 15:51:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:51:10 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:51:10 --> Upload Class Initialized
INFO - 2020-08-22 15:51:10 --> Controller Class Initialized
ERROR - 2020-08-22 15:51:10 --> 404 Page Not Found: /index
INFO - 2020-08-22 15:55:25 --> Config Class Initialized
INFO - 2020-08-22 15:55:25 --> Hooks Class Initialized
DEBUG - 2020-08-22 15:55:25 --> UTF-8 Support Enabled
INFO - 2020-08-22 15:55:25 --> Utf8 Class Initialized
INFO - 2020-08-22 15:55:25 --> URI Class Initialized
DEBUG - 2020-08-22 15:55:25 --> No URI present. Default controller set.
INFO - 2020-08-22 15:55:25 --> Router Class Initialized
INFO - 2020-08-22 15:55:25 --> Output Class Initialized
INFO - 2020-08-22 15:55:25 --> Security Class Initialized
DEBUG - 2020-08-22 15:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 15:55:25 --> Input Class Initialized
INFO - 2020-08-22 15:55:25 --> Language Class Initialized
INFO - 2020-08-22 15:55:25 --> Language Class Initialized
INFO - 2020-08-22 15:55:25 --> Config Class Initialized
INFO - 2020-08-22 15:55:25 --> Loader Class Initialized
INFO - 2020-08-22 15:55:25 --> Helper loaded: url_helper
INFO - 2020-08-22 15:55:25 --> Helper loaded: form_helper
INFO - 2020-08-22 15:55:25 --> Helper loaded: file_helper
INFO - 2020-08-22 15:55:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 15:55:25 --> Database Driver Class Initialized
DEBUG - 2020-08-22 15:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 15:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 15:55:25 --> Upload Class Initialized
INFO - 2020-08-22 15:55:25 --> Controller Class Initialized
DEBUG - 2020-08-22 15:55:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 15:55:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 15:55:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 15:55:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 15:55:25 --> Final output sent to browser
DEBUG - 2020-08-22 15:55:25 --> Total execution time: 0.0528
INFO - 2020-08-22 16:06:07 --> Config Class Initialized
INFO - 2020-08-22 16:06:07 --> Hooks Class Initialized
DEBUG - 2020-08-22 16:06:07 --> UTF-8 Support Enabled
INFO - 2020-08-22 16:06:07 --> Utf8 Class Initialized
INFO - 2020-08-22 16:06:07 --> URI Class Initialized
INFO - 2020-08-22 16:06:07 --> Router Class Initialized
INFO - 2020-08-22 16:06:07 --> Output Class Initialized
INFO - 2020-08-22 16:06:07 --> Security Class Initialized
DEBUG - 2020-08-22 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 16:06:07 --> Input Class Initialized
INFO - 2020-08-22 16:06:07 --> Language Class Initialized
INFO - 2020-08-22 16:06:07 --> Language Class Initialized
INFO - 2020-08-22 16:06:07 --> Config Class Initialized
INFO - 2020-08-22 16:06:07 --> Loader Class Initialized
INFO - 2020-08-22 16:06:07 --> Helper loaded: url_helper
INFO - 2020-08-22 16:06:07 --> Helper loaded: form_helper
INFO - 2020-08-22 16:06:07 --> Helper loaded: file_helper
INFO - 2020-08-22 16:06:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 16:06:07 --> Database Driver Class Initialized
DEBUG - 2020-08-22 16:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 16:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 16:06:07 --> Upload Class Initialized
INFO - 2020-08-22 16:06:07 --> Controller Class Initialized
DEBUG - 2020-08-22 16:06:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 16:06:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 16:06:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 16:06:07 --> Final output sent to browser
DEBUG - 2020-08-22 16:06:07 --> Total execution time: 0.0535
INFO - 2020-08-22 16:06:09 --> Config Class Initialized
INFO - 2020-08-22 16:06:09 --> Hooks Class Initialized
DEBUG - 2020-08-22 16:06:09 --> UTF-8 Support Enabled
INFO - 2020-08-22 16:06:09 --> Utf8 Class Initialized
INFO - 2020-08-22 16:06:09 --> URI Class Initialized
INFO - 2020-08-22 16:06:09 --> Router Class Initialized
INFO - 2020-08-22 16:06:09 --> Output Class Initialized
INFO - 2020-08-22 16:06:09 --> Security Class Initialized
DEBUG - 2020-08-22 16:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 16:06:09 --> Input Class Initialized
INFO - 2020-08-22 16:06:09 --> Language Class Initialized
INFO - 2020-08-22 16:06:09 --> Language Class Initialized
INFO - 2020-08-22 16:06:09 --> Config Class Initialized
INFO - 2020-08-22 16:06:09 --> Loader Class Initialized
INFO - 2020-08-22 16:06:09 --> Helper loaded: url_helper
INFO - 2020-08-22 16:06:09 --> Helper loaded: form_helper
INFO - 2020-08-22 16:06:09 --> Helper loaded: file_helper
INFO - 2020-08-22 16:06:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 16:06:09 --> Database Driver Class Initialized
DEBUG - 2020-08-22 16:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 16:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 16:06:09 --> Upload Class Initialized
INFO - 2020-08-22 16:06:09 --> Controller Class Initialized
ERROR - 2020-08-22 16:06:09 --> 404 Page Not Found: /index
INFO - 2020-08-22 18:22:40 --> Config Class Initialized
INFO - 2020-08-22 18:22:40 --> Hooks Class Initialized
DEBUG - 2020-08-22 18:22:40 --> UTF-8 Support Enabled
INFO - 2020-08-22 18:22:40 --> Utf8 Class Initialized
INFO - 2020-08-22 18:22:40 --> URI Class Initialized
DEBUG - 2020-08-22 18:22:40 --> No URI present. Default controller set.
INFO - 2020-08-22 18:22:40 --> Router Class Initialized
INFO - 2020-08-22 18:22:40 --> Output Class Initialized
INFO - 2020-08-22 18:22:40 --> Security Class Initialized
DEBUG - 2020-08-22 18:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 18:22:40 --> Input Class Initialized
INFO - 2020-08-22 18:22:40 --> Language Class Initialized
INFO - 2020-08-22 18:22:40 --> Language Class Initialized
INFO - 2020-08-22 18:22:40 --> Config Class Initialized
INFO - 2020-08-22 18:22:40 --> Loader Class Initialized
INFO - 2020-08-22 18:22:40 --> Helper loaded: url_helper
INFO - 2020-08-22 18:22:40 --> Helper loaded: form_helper
INFO - 2020-08-22 18:22:40 --> Helper loaded: file_helper
INFO - 2020-08-22 18:22:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 18:22:40 --> Database Driver Class Initialized
DEBUG - 2020-08-22 18:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 18:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 18:22:40 --> Upload Class Initialized
INFO - 2020-08-22 18:22:40 --> Controller Class Initialized
DEBUG - 2020-08-22 18:22:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 18:22:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 18:22:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 18:22:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 18:22:40 --> Final output sent to browser
DEBUG - 2020-08-22 18:22:40 --> Total execution time: 0.0927
INFO - 2020-08-22 18:51:30 --> Config Class Initialized
INFO - 2020-08-22 18:51:30 --> Hooks Class Initialized
DEBUG - 2020-08-22 18:51:30 --> UTF-8 Support Enabled
INFO - 2020-08-22 18:51:30 --> Utf8 Class Initialized
INFO - 2020-08-22 18:51:30 --> URI Class Initialized
DEBUG - 2020-08-22 18:51:30 --> No URI present. Default controller set.
INFO - 2020-08-22 18:51:30 --> Router Class Initialized
INFO - 2020-08-22 18:51:30 --> Output Class Initialized
INFO - 2020-08-22 18:51:30 --> Security Class Initialized
DEBUG - 2020-08-22 18:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 18:51:30 --> Input Class Initialized
INFO - 2020-08-22 18:51:30 --> Language Class Initialized
INFO - 2020-08-22 18:51:30 --> Language Class Initialized
INFO - 2020-08-22 18:51:30 --> Config Class Initialized
INFO - 2020-08-22 18:51:30 --> Loader Class Initialized
INFO - 2020-08-22 18:51:30 --> Helper loaded: url_helper
INFO - 2020-08-22 18:51:30 --> Helper loaded: form_helper
INFO - 2020-08-22 18:51:30 --> Helper loaded: file_helper
INFO - 2020-08-22 18:51:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 18:51:30 --> Database Driver Class Initialized
DEBUG - 2020-08-22 18:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 18:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 18:51:30 --> Upload Class Initialized
INFO - 2020-08-22 18:51:30 --> Controller Class Initialized
DEBUG - 2020-08-22 18:51:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 18:51:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 18:51:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 18:51:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 18:51:30 --> Final output sent to browser
DEBUG - 2020-08-22 18:51:30 --> Total execution time: 0.0494
INFO - 2020-08-22 19:06:03 --> Config Class Initialized
INFO - 2020-08-22 19:06:03 --> Hooks Class Initialized
DEBUG - 2020-08-22 19:06:03 --> UTF-8 Support Enabled
INFO - 2020-08-22 19:06:03 --> Utf8 Class Initialized
INFO - 2020-08-22 19:06:03 --> URI Class Initialized
INFO - 2020-08-22 19:06:03 --> Router Class Initialized
INFO - 2020-08-22 19:06:03 --> Output Class Initialized
INFO - 2020-08-22 19:06:03 --> Security Class Initialized
DEBUG - 2020-08-22 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 19:06:03 --> Input Class Initialized
INFO - 2020-08-22 19:06:03 --> Language Class Initialized
INFO - 2020-08-22 19:06:03 --> Language Class Initialized
INFO - 2020-08-22 19:06:03 --> Config Class Initialized
INFO - 2020-08-22 19:06:03 --> Loader Class Initialized
INFO - 2020-08-22 19:06:03 --> Helper loaded: url_helper
INFO - 2020-08-22 19:06:03 --> Helper loaded: form_helper
INFO - 2020-08-22 19:06:03 --> Helper loaded: file_helper
INFO - 2020-08-22 19:06:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 19:06:03 --> Database Driver Class Initialized
DEBUG - 2020-08-22 19:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 19:06:03 --> Upload Class Initialized
INFO - 2020-08-22 19:06:03 --> Controller Class Initialized
ERROR - 2020-08-22 19:06:03 --> 404 Page Not Found: /index
INFO - 2020-08-22 19:06:03 --> Config Class Initialized
INFO - 2020-08-22 19:06:03 --> Hooks Class Initialized
DEBUG - 2020-08-22 19:06:03 --> UTF-8 Support Enabled
INFO - 2020-08-22 19:06:03 --> Utf8 Class Initialized
INFO - 2020-08-22 19:06:03 --> URI Class Initialized
INFO - 2020-08-22 19:06:03 --> Router Class Initialized
INFO - 2020-08-22 19:06:03 --> Output Class Initialized
INFO - 2020-08-22 19:06:03 --> Security Class Initialized
DEBUG - 2020-08-22 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 19:06:03 --> Input Class Initialized
INFO - 2020-08-22 19:06:03 --> Language Class Initialized
INFO - 2020-08-22 19:06:03 --> Language Class Initialized
INFO - 2020-08-22 19:06:03 --> Config Class Initialized
INFO - 2020-08-22 19:06:03 --> Loader Class Initialized
INFO - 2020-08-22 19:06:03 --> Helper loaded: url_helper
INFO - 2020-08-22 19:06:03 --> Helper loaded: form_helper
INFO - 2020-08-22 19:06:03 --> Helper loaded: file_helper
INFO - 2020-08-22 19:06:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 19:06:03 --> Database Driver Class Initialized
DEBUG - 2020-08-22 19:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 19:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 19:06:03 --> Upload Class Initialized
INFO - 2020-08-22 19:06:03 --> Controller Class Initialized
DEBUG - 2020-08-22 19:06:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 19:06:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-22 19:06:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 19:06:03 --> Final output sent to browser
DEBUG - 2020-08-22 19:06:03 --> Total execution time: 0.0599
INFO - 2020-08-22 19:06:43 --> Config Class Initialized
INFO - 2020-08-22 19:06:43 --> Hooks Class Initialized
DEBUG - 2020-08-22 19:06:43 --> UTF-8 Support Enabled
INFO - 2020-08-22 19:06:43 --> Utf8 Class Initialized
INFO - 2020-08-22 19:06:43 --> URI Class Initialized
INFO - 2020-08-22 19:06:43 --> Router Class Initialized
INFO - 2020-08-22 19:06:43 --> Output Class Initialized
INFO - 2020-08-22 19:06:43 --> Security Class Initialized
DEBUG - 2020-08-22 19:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 19:06:43 --> Input Class Initialized
INFO - 2020-08-22 19:06:43 --> Language Class Initialized
INFO - 2020-08-22 19:06:43 --> Language Class Initialized
INFO - 2020-08-22 19:06:43 --> Config Class Initialized
INFO - 2020-08-22 19:06:43 --> Loader Class Initialized
INFO - 2020-08-22 19:06:43 --> Helper loaded: url_helper
INFO - 2020-08-22 19:06:43 --> Helper loaded: form_helper
INFO - 2020-08-22 19:06:43 --> Helper loaded: file_helper
INFO - 2020-08-22 19:06:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 19:06:43 --> Database Driver Class Initialized
DEBUG - 2020-08-22 19:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 19:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 19:06:43 --> Upload Class Initialized
INFO - 2020-08-22 19:06:43 --> Controller Class Initialized
ERROR - 2020-08-22 19:06:43 --> 404 Page Not Found: /index
INFO - 2020-08-22 19:06:44 --> Config Class Initialized
INFO - 2020-08-22 19:06:44 --> Hooks Class Initialized
DEBUG - 2020-08-22 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-08-22 19:06:44 --> Utf8 Class Initialized
INFO - 2020-08-22 19:06:44 --> URI Class Initialized
INFO - 2020-08-22 19:06:44 --> Router Class Initialized
INFO - 2020-08-22 19:06:44 --> Output Class Initialized
INFO - 2020-08-22 19:06:44 --> Security Class Initialized
DEBUG - 2020-08-22 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 19:06:44 --> Input Class Initialized
INFO - 2020-08-22 19:06:44 --> Language Class Initialized
INFO - 2020-08-22 19:06:44 --> Language Class Initialized
INFO - 2020-08-22 19:06:44 --> Config Class Initialized
INFO - 2020-08-22 19:06:44 --> Loader Class Initialized
INFO - 2020-08-22 19:06:44 --> Helper loaded: url_helper
INFO - 2020-08-22 19:06:44 --> Helper loaded: form_helper
INFO - 2020-08-22 19:06:44 --> Helper loaded: file_helper
INFO - 2020-08-22 19:06:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 19:06:44 --> Database Driver Class Initialized
DEBUG - 2020-08-22 19:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 19:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 19:06:44 --> Upload Class Initialized
INFO - 2020-08-22 19:06:44 --> Controller Class Initialized
ERROR - 2020-08-22 19:06:44 --> 404 Page Not Found: /index
INFO - 2020-08-22 19:06:44 --> Config Class Initialized
INFO - 2020-08-22 19:06:44 --> Hooks Class Initialized
DEBUG - 2020-08-22 19:06:44 --> UTF-8 Support Enabled
INFO - 2020-08-22 19:06:44 --> Utf8 Class Initialized
INFO - 2020-08-22 19:06:44 --> URI Class Initialized
INFO - 2020-08-22 19:06:44 --> Router Class Initialized
INFO - 2020-08-22 19:06:44 --> Output Class Initialized
INFO - 2020-08-22 19:06:44 --> Security Class Initialized
DEBUG - 2020-08-22 19:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 19:06:44 --> Input Class Initialized
INFO - 2020-08-22 19:06:44 --> Language Class Initialized
INFO - 2020-08-22 19:06:44 --> Language Class Initialized
INFO - 2020-08-22 19:06:44 --> Config Class Initialized
INFO - 2020-08-22 19:06:44 --> Loader Class Initialized
INFO - 2020-08-22 19:06:44 --> Helper loaded: url_helper
INFO - 2020-08-22 19:06:44 --> Helper loaded: form_helper
INFO - 2020-08-22 19:06:44 --> Helper loaded: file_helper
INFO - 2020-08-22 19:06:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 19:06:44 --> Database Driver Class Initialized
DEBUG - 2020-08-22 19:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 19:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 19:06:44 --> Upload Class Initialized
INFO - 2020-08-22 19:06:44 --> Controller Class Initialized
ERROR - 2020-08-22 19:06:44 --> 404 Page Not Found: /index
INFO - 2020-08-22 19:06:45 --> Config Class Initialized
INFO - 2020-08-22 19:06:45 --> Hooks Class Initialized
DEBUG - 2020-08-22 19:06:45 --> UTF-8 Support Enabled
INFO - 2020-08-22 19:06:45 --> Utf8 Class Initialized
INFO - 2020-08-22 19:06:45 --> URI Class Initialized
DEBUG - 2020-08-22 19:06:45 --> No URI present. Default controller set.
INFO - 2020-08-22 19:06:45 --> Router Class Initialized
INFO - 2020-08-22 19:06:45 --> Output Class Initialized
INFO - 2020-08-22 19:06:45 --> Security Class Initialized
DEBUG - 2020-08-22 19:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 19:06:45 --> Input Class Initialized
INFO - 2020-08-22 19:06:45 --> Language Class Initialized
INFO - 2020-08-22 19:06:45 --> Language Class Initialized
INFO - 2020-08-22 19:06:45 --> Config Class Initialized
INFO - 2020-08-22 19:06:45 --> Loader Class Initialized
INFO - 2020-08-22 19:06:45 --> Helper loaded: url_helper
INFO - 2020-08-22 19:06:45 --> Helper loaded: form_helper
INFO - 2020-08-22 19:06:45 --> Helper loaded: file_helper
INFO - 2020-08-22 19:06:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 19:06:45 --> Database Driver Class Initialized
DEBUG - 2020-08-22 19:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 19:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 19:06:45 --> Upload Class Initialized
INFO - 2020-08-22 19:06:45 --> Controller Class Initialized
DEBUG - 2020-08-22 19:06:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 19:06:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 19:06:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 19:06:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 19:06:45 --> Final output sent to browser
DEBUG - 2020-08-22 19:06:45 --> Total execution time: 0.0479
INFO - 2020-08-22 20:47:47 --> Config Class Initialized
INFO - 2020-08-22 20:47:47 --> Hooks Class Initialized
DEBUG - 2020-08-22 20:47:47 --> UTF-8 Support Enabled
INFO - 2020-08-22 20:47:47 --> Utf8 Class Initialized
INFO - 2020-08-22 20:47:47 --> URI Class Initialized
DEBUG - 2020-08-22 20:47:47 --> No URI present. Default controller set.
INFO - 2020-08-22 20:47:47 --> Router Class Initialized
INFO - 2020-08-22 20:47:47 --> Output Class Initialized
INFO - 2020-08-22 20:47:47 --> Security Class Initialized
DEBUG - 2020-08-22 20:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 20:47:47 --> Input Class Initialized
INFO - 2020-08-22 20:47:47 --> Language Class Initialized
INFO - 2020-08-22 20:47:47 --> Language Class Initialized
INFO - 2020-08-22 20:47:47 --> Config Class Initialized
INFO - 2020-08-22 20:47:47 --> Loader Class Initialized
INFO - 2020-08-22 20:47:47 --> Helper loaded: url_helper
INFO - 2020-08-22 20:47:47 --> Helper loaded: form_helper
INFO - 2020-08-22 20:47:47 --> Helper loaded: file_helper
INFO - 2020-08-22 20:47:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 20:47:47 --> Database Driver Class Initialized
DEBUG - 2020-08-22 20:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 20:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 20:47:47 --> Upload Class Initialized
INFO - 2020-08-22 20:47:47 --> Controller Class Initialized
DEBUG - 2020-08-22 20:47:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 20:47:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 20:47:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 20:47:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 20:47:47 --> Final output sent to browser
DEBUG - 2020-08-22 20:47:47 --> Total execution time: 0.0518
INFO - 2020-08-22 21:01:04 --> Config Class Initialized
INFO - 2020-08-22 21:01:04 --> Hooks Class Initialized
DEBUG - 2020-08-22 21:01:04 --> UTF-8 Support Enabled
INFO - 2020-08-22 21:01:04 --> Utf8 Class Initialized
INFO - 2020-08-22 21:01:04 --> URI Class Initialized
INFO - 2020-08-22 21:01:04 --> Router Class Initialized
INFO - 2020-08-22 21:01:04 --> Output Class Initialized
INFO - 2020-08-22 21:01:04 --> Security Class Initialized
DEBUG - 2020-08-22 21:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 21:01:04 --> Input Class Initialized
INFO - 2020-08-22 21:01:04 --> Language Class Initialized
INFO - 2020-08-22 21:01:04 --> Language Class Initialized
INFO - 2020-08-22 21:01:04 --> Config Class Initialized
INFO - 2020-08-22 21:01:04 --> Loader Class Initialized
INFO - 2020-08-22 21:01:04 --> Helper loaded: url_helper
INFO - 2020-08-22 21:01:04 --> Helper loaded: form_helper
INFO - 2020-08-22 21:01:04 --> Helper loaded: file_helper
INFO - 2020-08-22 21:01:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 21:01:04 --> Database Driver Class Initialized
DEBUG - 2020-08-22 21:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 21:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 21:01:04 --> Upload Class Initialized
INFO - 2020-08-22 21:01:04 --> Controller Class Initialized
ERROR - 2020-08-22 21:01:04 --> 404 Page Not Found: /index
INFO - 2020-08-22 21:01:08 --> Config Class Initialized
INFO - 2020-08-22 21:01:08 --> Hooks Class Initialized
DEBUG - 2020-08-22 21:01:08 --> UTF-8 Support Enabled
INFO - 2020-08-22 21:01:08 --> Utf8 Class Initialized
INFO - 2020-08-22 21:01:08 --> URI Class Initialized
INFO - 2020-08-22 21:01:08 --> Router Class Initialized
INFO - 2020-08-22 21:01:08 --> Output Class Initialized
INFO - 2020-08-22 21:01:08 --> Security Class Initialized
DEBUG - 2020-08-22 21:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 21:01:08 --> Input Class Initialized
INFO - 2020-08-22 21:01:08 --> Language Class Initialized
INFO - 2020-08-22 21:01:08 --> Language Class Initialized
INFO - 2020-08-22 21:01:08 --> Config Class Initialized
INFO - 2020-08-22 21:01:08 --> Loader Class Initialized
INFO - 2020-08-22 21:01:08 --> Helper loaded: url_helper
INFO - 2020-08-22 21:01:08 --> Helper loaded: form_helper
INFO - 2020-08-22 21:01:08 --> Helper loaded: file_helper
INFO - 2020-08-22 21:01:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 21:01:08 --> Database Driver Class Initialized
DEBUG - 2020-08-22 21:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 21:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 21:01:08 --> Upload Class Initialized
INFO - 2020-08-22 21:01:08 --> Controller Class Initialized
DEBUG - 2020-08-22 21:01:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 21:01:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-22 21:01:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 21:01:08 --> Final output sent to browser
DEBUG - 2020-08-22 21:01:08 --> Total execution time: 0.0548
INFO - 2020-08-22 21:08:17 --> Config Class Initialized
INFO - 2020-08-22 21:08:17 --> Hooks Class Initialized
DEBUG - 2020-08-22 21:08:17 --> UTF-8 Support Enabled
INFO - 2020-08-22 21:08:17 --> Utf8 Class Initialized
INFO - 2020-08-22 21:08:17 --> URI Class Initialized
INFO - 2020-08-22 21:08:17 --> Router Class Initialized
INFO - 2020-08-22 21:08:17 --> Output Class Initialized
INFO - 2020-08-22 21:08:17 --> Security Class Initialized
DEBUG - 2020-08-22 21:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 21:08:17 --> Input Class Initialized
INFO - 2020-08-22 21:08:17 --> Language Class Initialized
INFO - 2020-08-22 21:08:17 --> Language Class Initialized
INFO - 2020-08-22 21:08:17 --> Config Class Initialized
INFO - 2020-08-22 21:08:17 --> Loader Class Initialized
INFO - 2020-08-22 21:08:17 --> Helper loaded: url_helper
INFO - 2020-08-22 21:08:17 --> Helper loaded: form_helper
INFO - 2020-08-22 21:08:17 --> Helper loaded: file_helper
INFO - 2020-08-22 21:08:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 21:08:17 --> Database Driver Class Initialized
DEBUG - 2020-08-22 21:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 21:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 21:08:17 --> Upload Class Initialized
INFO - 2020-08-22 21:08:17 --> Controller Class Initialized
DEBUG - 2020-08-22 21:08:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 21:08:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-22 21:08:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 21:08:17 --> Final output sent to browser
DEBUG - 2020-08-22 21:08:17 --> Total execution time: 0.0539
INFO - 2020-08-22 21:08:19 --> Config Class Initialized
INFO - 2020-08-22 21:08:19 --> Hooks Class Initialized
DEBUG - 2020-08-22 21:08:19 --> UTF-8 Support Enabled
INFO - 2020-08-22 21:08:19 --> Utf8 Class Initialized
INFO - 2020-08-22 21:08:19 --> URI Class Initialized
INFO - 2020-08-22 21:08:19 --> Router Class Initialized
INFO - 2020-08-22 21:08:19 --> Output Class Initialized
INFO - 2020-08-22 21:08:19 --> Security Class Initialized
DEBUG - 2020-08-22 21:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 21:08:19 --> Input Class Initialized
INFO - 2020-08-22 21:08:19 --> Language Class Initialized
INFO - 2020-08-22 21:08:19 --> Language Class Initialized
INFO - 2020-08-22 21:08:19 --> Config Class Initialized
INFO - 2020-08-22 21:08:19 --> Loader Class Initialized
INFO - 2020-08-22 21:08:19 --> Helper loaded: url_helper
INFO - 2020-08-22 21:08:19 --> Helper loaded: form_helper
INFO - 2020-08-22 21:08:19 --> Helper loaded: file_helper
INFO - 2020-08-22 21:08:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 21:08:19 --> Database Driver Class Initialized
DEBUG - 2020-08-22 21:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 21:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 21:08:19 --> Upload Class Initialized
INFO - 2020-08-22 21:08:19 --> Controller Class Initialized
ERROR - 2020-08-22 21:08:19 --> 404 Page Not Found: /index
INFO - 2020-08-22 22:14:17 --> Config Class Initialized
INFO - 2020-08-22 22:14:17 --> Hooks Class Initialized
DEBUG - 2020-08-22 22:14:17 --> UTF-8 Support Enabled
INFO - 2020-08-22 22:14:17 --> Utf8 Class Initialized
INFO - 2020-08-22 22:14:17 --> URI Class Initialized
DEBUG - 2020-08-22 22:14:17 --> No URI present. Default controller set.
INFO - 2020-08-22 22:14:17 --> Router Class Initialized
INFO - 2020-08-22 22:14:17 --> Output Class Initialized
INFO - 2020-08-22 22:14:17 --> Security Class Initialized
DEBUG - 2020-08-22 22:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 22:14:17 --> Input Class Initialized
INFO - 2020-08-22 22:14:17 --> Language Class Initialized
INFO - 2020-08-22 22:14:17 --> Language Class Initialized
INFO - 2020-08-22 22:14:17 --> Config Class Initialized
INFO - 2020-08-22 22:14:17 --> Loader Class Initialized
INFO - 2020-08-22 22:14:17 --> Helper loaded: url_helper
INFO - 2020-08-22 22:14:17 --> Helper loaded: form_helper
INFO - 2020-08-22 22:14:17 --> Helper loaded: file_helper
INFO - 2020-08-22 22:14:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 22:14:17 --> Database Driver Class Initialized
DEBUG - 2020-08-22 22:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 22:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 22:14:17 --> Upload Class Initialized
INFO - 2020-08-22 22:14:17 --> Controller Class Initialized
DEBUG - 2020-08-22 22:14:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 22:14:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 22:14:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 22:14:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 22:14:17 --> Final output sent to browser
DEBUG - 2020-08-22 22:14:17 --> Total execution time: 0.0496
INFO - 2020-08-22 22:21:18 --> Config Class Initialized
INFO - 2020-08-22 22:21:18 --> Hooks Class Initialized
DEBUG - 2020-08-22 22:21:18 --> UTF-8 Support Enabled
INFO - 2020-08-22 22:21:18 --> Utf8 Class Initialized
INFO - 2020-08-22 22:21:18 --> URI Class Initialized
INFO - 2020-08-22 22:21:18 --> Router Class Initialized
INFO - 2020-08-22 22:21:18 --> Output Class Initialized
INFO - 2020-08-22 22:21:18 --> Security Class Initialized
DEBUG - 2020-08-22 22:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 22:21:18 --> Input Class Initialized
INFO - 2020-08-22 22:21:18 --> Language Class Initialized
INFO - 2020-08-22 22:21:18 --> Language Class Initialized
INFO - 2020-08-22 22:21:18 --> Config Class Initialized
INFO - 2020-08-22 22:21:18 --> Loader Class Initialized
INFO - 2020-08-22 22:21:18 --> Helper loaded: url_helper
INFO - 2020-08-22 22:21:18 --> Helper loaded: form_helper
INFO - 2020-08-22 22:21:18 --> Helper loaded: file_helper
INFO - 2020-08-22 22:21:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 22:21:18 --> Database Driver Class Initialized
DEBUG - 2020-08-22 22:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 22:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 22:21:18 --> Upload Class Initialized
INFO - 2020-08-22 22:21:18 --> Controller Class Initialized
ERROR - 2020-08-22 22:21:18 --> 404 Page Not Found: /index
INFO - 2020-08-22 23:10:29 --> Config Class Initialized
INFO - 2020-08-22 23:10:29 --> Hooks Class Initialized
DEBUG - 2020-08-22 23:10:29 --> UTF-8 Support Enabled
INFO - 2020-08-22 23:10:29 --> Utf8 Class Initialized
INFO - 2020-08-22 23:10:29 --> URI Class Initialized
DEBUG - 2020-08-22 23:10:29 --> No URI present. Default controller set.
INFO - 2020-08-22 23:10:29 --> Router Class Initialized
INFO - 2020-08-22 23:10:29 --> Output Class Initialized
INFO - 2020-08-22 23:10:29 --> Security Class Initialized
DEBUG - 2020-08-22 23:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 23:10:29 --> Input Class Initialized
INFO - 2020-08-22 23:10:29 --> Language Class Initialized
INFO - 2020-08-22 23:10:29 --> Language Class Initialized
INFO - 2020-08-22 23:10:29 --> Config Class Initialized
INFO - 2020-08-22 23:10:29 --> Loader Class Initialized
INFO - 2020-08-22 23:10:29 --> Helper loaded: url_helper
INFO - 2020-08-22 23:10:29 --> Helper loaded: form_helper
INFO - 2020-08-22 23:10:29 --> Helper loaded: file_helper
INFO - 2020-08-22 23:10:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 23:10:29 --> Database Driver Class Initialized
DEBUG - 2020-08-22 23:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 23:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 23:10:29 --> Upload Class Initialized
INFO - 2020-08-22 23:10:29 --> Controller Class Initialized
DEBUG - 2020-08-22 23:10:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 23:10:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 23:10:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 23:10:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 23:10:29 --> Final output sent to browser
DEBUG - 2020-08-22 23:10:29 --> Total execution time: 0.0524
INFO - 2020-08-22 23:34:19 --> Config Class Initialized
INFO - 2020-08-22 23:34:19 --> Hooks Class Initialized
DEBUG - 2020-08-22 23:34:19 --> UTF-8 Support Enabled
INFO - 2020-08-22 23:34:19 --> Utf8 Class Initialized
INFO - 2020-08-22 23:34:19 --> URI Class Initialized
DEBUG - 2020-08-22 23:34:19 --> No URI present. Default controller set.
INFO - 2020-08-22 23:34:19 --> Router Class Initialized
INFO - 2020-08-22 23:34:19 --> Output Class Initialized
INFO - 2020-08-22 23:34:19 --> Security Class Initialized
DEBUG - 2020-08-22 23:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-22 23:34:19 --> Input Class Initialized
INFO - 2020-08-22 23:34:19 --> Language Class Initialized
INFO - 2020-08-22 23:34:19 --> Language Class Initialized
INFO - 2020-08-22 23:34:19 --> Config Class Initialized
INFO - 2020-08-22 23:34:19 --> Loader Class Initialized
INFO - 2020-08-22 23:34:19 --> Helper loaded: url_helper
INFO - 2020-08-22 23:34:19 --> Helper loaded: form_helper
INFO - 2020-08-22 23:34:19 --> Helper loaded: file_helper
INFO - 2020-08-22 23:34:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-22 23:34:19 --> Database Driver Class Initialized
DEBUG - 2020-08-22 23:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-22 23:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-22 23:34:19 --> Upload Class Initialized
INFO - 2020-08-22 23:34:19 --> Controller Class Initialized
DEBUG - 2020-08-22 23:34:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-22 23:34:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-22 23:34:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-22 23:34:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-22 23:34:19 --> Final output sent to browser
DEBUG - 2020-08-22 23:34:19 --> Total execution time: 0.0510
