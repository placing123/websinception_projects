<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-23 01:16:53 --> Config Class Initialized
INFO - 2020-08-23 01:16:53 --> Hooks Class Initialized
DEBUG - 2020-08-23 01:16:53 --> UTF-8 Support Enabled
INFO - 2020-08-23 01:16:53 --> Utf8 Class Initialized
INFO - 2020-08-23 01:16:53 --> URI Class Initialized
INFO - 2020-08-23 01:16:53 --> Router Class Initialized
INFO - 2020-08-23 01:16:53 --> Output Class Initialized
INFO - 2020-08-23 01:16:53 --> Security Class Initialized
DEBUG - 2020-08-23 01:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 01:16:53 --> Input Class Initialized
INFO - 2020-08-23 01:16:53 --> Language Class Initialized
INFO - 2020-08-23 01:16:53 --> Language Class Initialized
INFO - 2020-08-23 01:16:53 --> Config Class Initialized
INFO - 2020-08-23 01:16:53 --> Loader Class Initialized
INFO - 2020-08-23 01:16:53 --> Helper loaded: url_helper
INFO - 2020-08-23 01:16:53 --> Helper loaded: form_helper
INFO - 2020-08-23 01:16:53 --> Helper loaded: file_helper
INFO - 2020-08-23 01:16:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 01:16:53 --> Database Driver Class Initialized
DEBUG - 2020-08-23 01:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 01:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 01:16:53 --> Upload Class Initialized
INFO - 2020-08-23 01:16:53 --> Controller Class Initialized
ERROR - 2020-08-23 01:16:53 --> 404 Page Not Found: /index
INFO - 2020-08-23 01:16:56 --> Config Class Initialized
INFO - 2020-08-23 01:16:56 --> Hooks Class Initialized
DEBUG - 2020-08-23 01:16:56 --> UTF-8 Support Enabled
INFO - 2020-08-23 01:16:56 --> Utf8 Class Initialized
INFO - 2020-08-23 01:16:56 --> URI Class Initialized
INFO - 2020-08-23 01:16:56 --> Router Class Initialized
INFO - 2020-08-23 01:16:56 --> Output Class Initialized
INFO - 2020-08-23 01:16:56 --> Security Class Initialized
DEBUG - 2020-08-23 01:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 01:16:56 --> Input Class Initialized
INFO - 2020-08-23 01:16:56 --> Language Class Initialized
INFO - 2020-08-23 01:16:56 --> Language Class Initialized
INFO - 2020-08-23 01:16:56 --> Config Class Initialized
INFO - 2020-08-23 01:16:56 --> Loader Class Initialized
INFO - 2020-08-23 01:16:56 --> Helper loaded: url_helper
INFO - 2020-08-23 01:16:56 --> Helper loaded: form_helper
INFO - 2020-08-23 01:16:56 --> Helper loaded: file_helper
INFO - 2020-08-23 01:16:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 01:16:56 --> Database Driver Class Initialized
DEBUG - 2020-08-23 01:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 01:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 01:16:56 --> Upload Class Initialized
INFO - 2020-08-23 01:16:56 --> Controller Class Initialized
DEBUG - 2020-08-23 01:16:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 01:16:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 01:16:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 01:16:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 01:16:56 --> Final output sent to browser
DEBUG - 2020-08-23 01:16:56 --> Total execution time: 0.0498
INFO - 2020-08-23 02:22:23 --> Config Class Initialized
INFO - 2020-08-23 02:22:23 --> Hooks Class Initialized
DEBUG - 2020-08-23 02:22:23 --> UTF-8 Support Enabled
INFO - 2020-08-23 02:22:23 --> Utf8 Class Initialized
INFO - 2020-08-23 02:22:23 --> URI Class Initialized
DEBUG - 2020-08-23 02:22:23 --> No URI present. Default controller set.
INFO - 2020-08-23 02:22:23 --> Router Class Initialized
INFO - 2020-08-23 02:22:23 --> Output Class Initialized
INFO - 2020-08-23 02:22:23 --> Security Class Initialized
DEBUG - 2020-08-23 02:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 02:22:23 --> Input Class Initialized
INFO - 2020-08-23 02:22:23 --> Language Class Initialized
INFO - 2020-08-23 02:22:23 --> Language Class Initialized
INFO - 2020-08-23 02:22:23 --> Config Class Initialized
INFO - 2020-08-23 02:22:23 --> Loader Class Initialized
INFO - 2020-08-23 02:22:23 --> Helper loaded: url_helper
INFO - 2020-08-23 02:22:23 --> Helper loaded: form_helper
INFO - 2020-08-23 02:22:23 --> Helper loaded: file_helper
INFO - 2020-08-23 02:22:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 02:22:23 --> Database Driver Class Initialized
DEBUG - 2020-08-23 02:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 02:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 02:22:23 --> Upload Class Initialized
INFO - 2020-08-23 02:22:23 --> Controller Class Initialized
DEBUG - 2020-08-23 02:22:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 02:22:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 02:22:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 02:22:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 02:22:23 --> Final output sent to browser
DEBUG - 2020-08-23 02:22:23 --> Total execution time: 0.0628
INFO - 2020-08-23 02:22:30 --> Config Class Initialized
INFO - 2020-08-23 02:22:30 --> Hooks Class Initialized
DEBUG - 2020-08-23 02:22:30 --> UTF-8 Support Enabled
INFO - 2020-08-23 02:22:30 --> Utf8 Class Initialized
INFO - 2020-08-23 02:22:30 --> URI Class Initialized
INFO - 2020-08-23 02:22:30 --> Router Class Initialized
INFO - 2020-08-23 02:22:30 --> Output Class Initialized
INFO - 2020-08-23 02:22:30 --> Security Class Initialized
DEBUG - 2020-08-23 02:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 02:22:30 --> Input Class Initialized
INFO - 2020-08-23 02:22:30 --> Language Class Initialized
INFO - 2020-08-23 02:22:30 --> Language Class Initialized
INFO - 2020-08-23 02:22:30 --> Config Class Initialized
INFO - 2020-08-23 02:22:30 --> Loader Class Initialized
INFO - 2020-08-23 02:22:30 --> Helper loaded: url_helper
INFO - 2020-08-23 02:22:30 --> Helper loaded: form_helper
INFO - 2020-08-23 02:22:30 --> Helper loaded: file_helper
INFO - 2020-08-23 02:22:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 02:22:30 --> Database Driver Class Initialized
DEBUG - 2020-08-23 02:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 02:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 02:22:30 --> Upload Class Initialized
INFO - 2020-08-23 02:22:30 --> Controller Class Initialized
ERROR - 2020-08-23 02:22:30 --> 404 Page Not Found: /index
INFO - 2020-08-23 02:22:31 --> Config Class Initialized
INFO - 2020-08-23 02:22:31 --> Hooks Class Initialized
DEBUG - 2020-08-23 02:22:31 --> UTF-8 Support Enabled
INFO - 2020-08-23 02:22:31 --> Utf8 Class Initialized
INFO - 2020-08-23 02:22:31 --> URI Class Initialized
INFO - 2020-08-23 02:22:31 --> Router Class Initialized
INFO - 2020-08-23 02:22:31 --> Output Class Initialized
INFO - 2020-08-23 02:22:31 --> Security Class Initialized
DEBUG - 2020-08-23 02:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 02:22:31 --> Input Class Initialized
INFO - 2020-08-23 02:22:31 --> Language Class Initialized
INFO - 2020-08-23 02:22:31 --> Language Class Initialized
INFO - 2020-08-23 02:22:31 --> Config Class Initialized
INFO - 2020-08-23 02:22:31 --> Loader Class Initialized
INFO - 2020-08-23 02:22:31 --> Helper loaded: url_helper
INFO - 2020-08-23 02:22:31 --> Helper loaded: form_helper
INFO - 2020-08-23 02:22:31 --> Helper loaded: file_helper
INFO - 2020-08-23 02:22:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 02:22:31 --> Database Driver Class Initialized
DEBUG - 2020-08-23 02:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 02:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 02:22:31 --> Upload Class Initialized
INFO - 2020-08-23 02:22:31 --> Controller Class Initialized
ERROR - 2020-08-23 02:22:31 --> 404 Page Not Found: /index
INFO - 2020-08-23 02:22:31 --> Config Class Initialized
INFO - 2020-08-23 02:22:31 --> Hooks Class Initialized
DEBUG - 2020-08-23 02:22:31 --> UTF-8 Support Enabled
INFO - 2020-08-23 02:22:31 --> Utf8 Class Initialized
INFO - 2020-08-23 02:22:31 --> URI Class Initialized
INFO - 2020-08-23 02:22:31 --> Router Class Initialized
INFO - 2020-08-23 02:22:31 --> Output Class Initialized
INFO - 2020-08-23 02:22:31 --> Security Class Initialized
DEBUG - 2020-08-23 02:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 02:22:31 --> Input Class Initialized
INFO - 2020-08-23 02:22:31 --> Language Class Initialized
INFO - 2020-08-23 02:22:31 --> Language Class Initialized
INFO - 2020-08-23 02:22:31 --> Config Class Initialized
INFO - 2020-08-23 02:22:31 --> Loader Class Initialized
INFO - 2020-08-23 02:22:31 --> Helper loaded: url_helper
INFO - 2020-08-23 02:22:31 --> Helper loaded: form_helper
INFO - 2020-08-23 02:22:31 --> Helper loaded: file_helper
INFO - 2020-08-23 02:22:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 02:22:31 --> Database Driver Class Initialized
DEBUG - 2020-08-23 02:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 02:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 02:22:31 --> Upload Class Initialized
INFO - 2020-08-23 02:22:31 --> Controller Class Initialized
ERROR - 2020-08-23 02:22:31 --> 404 Page Not Found: /index
INFO - 2020-08-23 02:22:32 --> Config Class Initialized
INFO - 2020-08-23 02:22:32 --> Hooks Class Initialized
DEBUG - 2020-08-23 02:22:32 --> UTF-8 Support Enabled
INFO - 2020-08-23 02:22:32 --> Utf8 Class Initialized
INFO - 2020-08-23 02:22:32 --> URI Class Initialized
INFO - 2020-08-23 02:22:32 --> Router Class Initialized
INFO - 2020-08-23 02:22:32 --> Output Class Initialized
INFO - 2020-08-23 02:22:32 --> Security Class Initialized
DEBUG - 2020-08-23 02:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 02:22:32 --> Input Class Initialized
INFO - 2020-08-23 02:22:32 --> Language Class Initialized
INFO - 2020-08-23 02:22:32 --> Language Class Initialized
INFO - 2020-08-23 02:22:32 --> Config Class Initialized
INFO - 2020-08-23 02:22:32 --> Loader Class Initialized
INFO - 2020-08-23 02:22:32 --> Helper loaded: url_helper
INFO - 2020-08-23 02:22:32 --> Helper loaded: form_helper
INFO - 2020-08-23 02:22:32 --> Helper loaded: file_helper
INFO - 2020-08-23 02:22:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 02:22:32 --> Database Driver Class Initialized
DEBUG - 2020-08-23 02:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 02:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 02:22:32 --> Upload Class Initialized
INFO - 2020-08-23 02:22:32 --> Controller Class Initialized
ERROR - 2020-08-23 02:22:32 --> 404 Page Not Found: /index
INFO - 2020-08-23 08:18:29 --> Config Class Initialized
INFO - 2020-08-23 08:18:29 --> Hooks Class Initialized
DEBUG - 2020-08-23 08:18:29 --> UTF-8 Support Enabled
INFO - 2020-08-23 08:18:29 --> Utf8 Class Initialized
INFO - 2020-08-23 08:18:29 --> URI Class Initialized
INFO - 2020-08-23 08:18:29 --> Router Class Initialized
INFO - 2020-08-23 08:18:29 --> Output Class Initialized
INFO - 2020-08-23 08:18:29 --> Security Class Initialized
DEBUG - 2020-08-23 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 08:18:29 --> Input Class Initialized
INFO - 2020-08-23 08:18:29 --> Language Class Initialized
INFO - 2020-08-23 08:18:29 --> Language Class Initialized
INFO - 2020-08-23 08:18:29 --> Config Class Initialized
INFO - 2020-08-23 08:18:29 --> Loader Class Initialized
INFO - 2020-08-23 08:18:29 --> Helper loaded: url_helper
INFO - 2020-08-23 08:18:29 --> Helper loaded: form_helper
INFO - 2020-08-23 08:18:29 --> Helper loaded: file_helper
INFO - 2020-08-23 08:18:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 08:18:29 --> Database Driver Class Initialized
DEBUG - 2020-08-23 08:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 08:18:29 --> Upload Class Initialized
INFO - 2020-08-23 08:18:29 --> Controller Class Initialized
ERROR - 2020-08-23 08:18:29 --> 404 Page Not Found: /index
INFO - 2020-08-23 08:59:45 --> Config Class Initialized
INFO - 2020-08-23 08:59:45 --> Hooks Class Initialized
DEBUG - 2020-08-23 08:59:45 --> UTF-8 Support Enabled
INFO - 2020-08-23 08:59:45 --> Utf8 Class Initialized
INFO - 2020-08-23 08:59:45 --> URI Class Initialized
INFO - 2020-08-23 08:59:45 --> Router Class Initialized
INFO - 2020-08-23 08:59:45 --> Output Class Initialized
INFO - 2020-08-23 08:59:45 --> Security Class Initialized
DEBUG - 2020-08-23 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 08:59:45 --> Input Class Initialized
INFO - 2020-08-23 08:59:45 --> Language Class Initialized
INFO - 2020-08-23 08:59:45 --> Language Class Initialized
INFO - 2020-08-23 08:59:45 --> Config Class Initialized
INFO - 2020-08-23 08:59:45 --> Loader Class Initialized
INFO - 2020-08-23 08:59:45 --> Helper loaded: url_helper
INFO - 2020-08-23 08:59:45 --> Helper loaded: form_helper
INFO - 2020-08-23 08:59:45 --> Helper loaded: file_helper
INFO - 2020-08-23 08:59:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 08:59:45 --> Database Driver Class Initialized
DEBUG - 2020-08-23 08:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 08:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 08:59:45 --> Upload Class Initialized
INFO - 2020-08-23 08:59:45 --> Controller Class Initialized
ERROR - 2020-08-23 08:59:45 --> 404 Page Not Found: /index
INFO - 2020-08-23 08:59:46 --> Config Class Initialized
INFO - 2020-08-23 08:59:46 --> Hooks Class Initialized
DEBUG - 2020-08-23 08:59:46 --> UTF-8 Support Enabled
INFO - 2020-08-23 08:59:46 --> Utf8 Class Initialized
INFO - 2020-08-23 08:59:46 --> URI Class Initialized
INFO - 2020-08-23 08:59:46 --> Router Class Initialized
INFO - 2020-08-23 08:59:46 --> Output Class Initialized
INFO - 2020-08-23 08:59:46 --> Security Class Initialized
DEBUG - 2020-08-23 08:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 08:59:46 --> Input Class Initialized
INFO - 2020-08-23 08:59:46 --> Language Class Initialized
INFO - 2020-08-23 08:59:46 --> Language Class Initialized
INFO - 2020-08-23 08:59:46 --> Config Class Initialized
INFO - 2020-08-23 08:59:46 --> Loader Class Initialized
INFO - 2020-08-23 08:59:46 --> Helper loaded: url_helper
INFO - 2020-08-23 08:59:46 --> Helper loaded: form_helper
INFO - 2020-08-23 08:59:46 --> Helper loaded: file_helper
INFO - 2020-08-23 08:59:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 08:59:46 --> Database Driver Class Initialized
DEBUG - 2020-08-23 08:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 08:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 08:59:46 --> Upload Class Initialized
INFO - 2020-08-23 08:59:46 --> Controller Class Initialized
ERROR - 2020-08-23 08:59:46 --> 404 Page Not Found: /index
INFO - 2020-08-23 11:24:43 --> Config Class Initialized
INFO - 2020-08-23 11:24:43 --> Hooks Class Initialized
DEBUG - 2020-08-23 11:24:43 --> UTF-8 Support Enabled
INFO - 2020-08-23 11:24:43 --> Utf8 Class Initialized
INFO - 2020-08-23 11:24:43 --> URI Class Initialized
INFO - 2020-08-23 11:24:43 --> Router Class Initialized
INFO - 2020-08-23 11:24:43 --> Output Class Initialized
INFO - 2020-08-23 11:24:43 --> Security Class Initialized
DEBUG - 2020-08-23 11:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 11:24:43 --> Input Class Initialized
INFO - 2020-08-23 11:24:43 --> Language Class Initialized
INFO - 2020-08-23 11:24:43 --> Language Class Initialized
INFO - 2020-08-23 11:24:43 --> Config Class Initialized
INFO - 2020-08-23 11:24:43 --> Loader Class Initialized
INFO - 2020-08-23 11:24:43 --> Helper loaded: url_helper
INFO - 2020-08-23 11:24:43 --> Helper loaded: form_helper
INFO - 2020-08-23 11:24:43 --> Helper loaded: file_helper
INFO - 2020-08-23 11:24:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 11:24:43 --> Database Driver Class Initialized
DEBUG - 2020-08-23 11:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 11:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 11:24:43 --> Upload Class Initialized
INFO - 2020-08-23 11:24:43 --> Controller Class Initialized
ERROR - 2020-08-23 11:24:43 --> 404 Page Not Found: /index
INFO - 2020-08-23 11:24:44 --> Config Class Initialized
INFO - 2020-08-23 11:24:44 --> Hooks Class Initialized
DEBUG - 2020-08-23 11:24:44 --> UTF-8 Support Enabled
INFO - 2020-08-23 11:24:44 --> Utf8 Class Initialized
INFO - 2020-08-23 11:24:44 --> URI Class Initialized
INFO - 2020-08-23 11:24:44 --> Router Class Initialized
INFO - 2020-08-23 11:24:44 --> Output Class Initialized
INFO - 2020-08-23 11:24:44 --> Security Class Initialized
DEBUG - 2020-08-23 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 11:24:44 --> Input Class Initialized
INFO - 2020-08-23 11:24:44 --> Language Class Initialized
INFO - 2020-08-23 11:24:44 --> Language Class Initialized
INFO - 2020-08-23 11:24:44 --> Config Class Initialized
INFO - 2020-08-23 11:24:44 --> Loader Class Initialized
INFO - 2020-08-23 11:24:44 --> Helper loaded: url_helper
INFO - 2020-08-23 11:24:44 --> Helper loaded: form_helper
INFO - 2020-08-23 11:24:44 --> Helper loaded: file_helper
INFO - 2020-08-23 11:24:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 11:24:44 --> Database Driver Class Initialized
DEBUG - 2020-08-23 11:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 11:24:44 --> Upload Class Initialized
INFO - 2020-08-23 11:24:44 --> Controller Class Initialized
DEBUG - 2020-08-23 11:24:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 11:24:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-23 11:24:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 11:24:44 --> Final output sent to browser
DEBUG - 2020-08-23 11:24:44 --> Total execution time: 0.0790
INFO - 2020-08-23 11:42:47 --> Config Class Initialized
INFO - 2020-08-23 11:42:47 --> Hooks Class Initialized
DEBUG - 2020-08-23 11:42:47 --> UTF-8 Support Enabled
INFO - 2020-08-23 11:42:47 --> Utf8 Class Initialized
INFO - 2020-08-23 11:42:47 --> URI Class Initialized
INFO - 2020-08-23 11:42:47 --> Router Class Initialized
INFO - 2020-08-23 11:42:47 --> Output Class Initialized
INFO - 2020-08-23 11:42:47 --> Security Class Initialized
DEBUG - 2020-08-23 11:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 11:42:47 --> Input Class Initialized
INFO - 2020-08-23 11:42:47 --> Language Class Initialized
INFO - 2020-08-23 11:42:47 --> Language Class Initialized
INFO - 2020-08-23 11:42:47 --> Config Class Initialized
INFO - 2020-08-23 11:42:47 --> Loader Class Initialized
INFO - 2020-08-23 11:42:47 --> Helper loaded: url_helper
INFO - 2020-08-23 11:42:47 --> Helper loaded: form_helper
INFO - 2020-08-23 11:42:47 --> Helper loaded: file_helper
INFO - 2020-08-23 11:42:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 11:42:47 --> Database Driver Class Initialized
DEBUG - 2020-08-23 11:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 11:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 11:42:47 --> Upload Class Initialized
INFO - 2020-08-23 11:42:47 --> Controller Class Initialized
ERROR - 2020-08-23 11:42:47 --> 404 Page Not Found: /index
INFO - 2020-08-23 13:25:27 --> Config Class Initialized
INFO - 2020-08-23 13:25:27 --> Hooks Class Initialized
DEBUG - 2020-08-23 13:25:27 --> UTF-8 Support Enabled
INFO - 2020-08-23 13:25:27 --> Utf8 Class Initialized
INFO - 2020-08-23 13:25:27 --> URI Class Initialized
INFO - 2020-08-23 13:25:27 --> Router Class Initialized
INFO - 2020-08-23 13:25:27 --> Output Class Initialized
INFO - 2020-08-23 13:25:27 --> Security Class Initialized
DEBUG - 2020-08-23 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 13:25:27 --> Input Class Initialized
INFO - 2020-08-23 13:25:27 --> Language Class Initialized
INFO - 2020-08-23 13:25:27 --> Language Class Initialized
INFO - 2020-08-23 13:25:27 --> Config Class Initialized
INFO - 2020-08-23 13:25:27 --> Loader Class Initialized
INFO - 2020-08-23 13:25:27 --> Helper loaded: url_helper
INFO - 2020-08-23 13:25:27 --> Helper loaded: form_helper
INFO - 2020-08-23 13:25:27 --> Helper loaded: file_helper
INFO - 2020-08-23 13:25:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 13:25:27 --> Database Driver Class Initialized
DEBUG - 2020-08-23 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 13:25:27 --> Upload Class Initialized
INFO - 2020-08-23 13:25:27 --> Controller Class Initialized
ERROR - 2020-08-23 13:25:27 --> 404 Page Not Found: /index
INFO - 2020-08-23 13:25:27 --> Config Class Initialized
INFO - 2020-08-23 13:25:27 --> Hooks Class Initialized
DEBUG - 2020-08-23 13:25:27 --> UTF-8 Support Enabled
INFO - 2020-08-23 13:25:27 --> Utf8 Class Initialized
INFO - 2020-08-23 13:25:27 --> URI Class Initialized
INFO - 2020-08-23 13:25:27 --> Router Class Initialized
INFO - 2020-08-23 13:25:27 --> Output Class Initialized
INFO - 2020-08-23 13:25:27 --> Security Class Initialized
DEBUG - 2020-08-23 13:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 13:25:27 --> Input Class Initialized
INFO - 2020-08-23 13:25:27 --> Language Class Initialized
INFO - 2020-08-23 13:25:27 --> Language Class Initialized
INFO - 2020-08-23 13:25:27 --> Config Class Initialized
INFO - 2020-08-23 13:25:27 --> Loader Class Initialized
INFO - 2020-08-23 13:25:27 --> Helper loaded: url_helper
INFO - 2020-08-23 13:25:27 --> Helper loaded: form_helper
INFO - 2020-08-23 13:25:27 --> Helper loaded: file_helper
INFO - 2020-08-23 13:25:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 13:25:27 --> Database Driver Class Initialized
DEBUG - 2020-08-23 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 13:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 13:25:27 --> Upload Class Initialized
INFO - 2020-08-23 13:25:27 --> Controller Class Initialized
DEBUG - 2020-08-23 13:25:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 13:25:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-23 13:25:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 13:25:27 --> Final output sent to browser
DEBUG - 2020-08-23 13:25:27 --> Total execution time: 0.0550
INFO - 2020-08-23 13:42:57 --> Config Class Initialized
INFO - 2020-08-23 13:42:57 --> Hooks Class Initialized
DEBUG - 2020-08-23 13:42:57 --> UTF-8 Support Enabled
INFO - 2020-08-23 13:42:57 --> Utf8 Class Initialized
INFO - 2020-08-23 13:42:57 --> URI Class Initialized
INFO - 2020-08-23 13:42:57 --> Router Class Initialized
INFO - 2020-08-23 13:42:57 --> Output Class Initialized
INFO - 2020-08-23 13:42:57 --> Security Class Initialized
DEBUG - 2020-08-23 13:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 13:42:57 --> Input Class Initialized
INFO - 2020-08-23 13:42:57 --> Language Class Initialized
INFO - 2020-08-23 13:42:57 --> Language Class Initialized
INFO - 2020-08-23 13:42:57 --> Config Class Initialized
INFO - 2020-08-23 13:42:57 --> Loader Class Initialized
INFO - 2020-08-23 13:42:57 --> Helper loaded: url_helper
INFO - 2020-08-23 13:42:57 --> Helper loaded: form_helper
INFO - 2020-08-23 13:42:57 --> Helper loaded: file_helper
INFO - 2020-08-23 13:42:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 13:42:57 --> Database Driver Class Initialized
DEBUG - 2020-08-23 13:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 13:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 13:42:57 --> Upload Class Initialized
INFO - 2020-08-23 13:42:57 --> Controller Class Initialized
ERROR - 2020-08-23 13:42:57 --> 404 Page Not Found: /index
INFO - 2020-08-23 15:15:08 --> Config Class Initialized
INFO - 2020-08-23 15:15:08 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:15:08 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:15:08 --> Utf8 Class Initialized
INFO - 2020-08-23 15:15:08 --> URI Class Initialized
INFO - 2020-08-23 15:15:08 --> Router Class Initialized
INFO - 2020-08-23 15:15:08 --> Output Class Initialized
INFO - 2020-08-23 15:15:08 --> Security Class Initialized
DEBUG - 2020-08-23 15:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:15:08 --> Input Class Initialized
INFO - 2020-08-23 15:15:08 --> Language Class Initialized
INFO - 2020-08-23 15:15:08 --> Language Class Initialized
INFO - 2020-08-23 15:15:08 --> Config Class Initialized
INFO - 2020-08-23 15:15:08 --> Loader Class Initialized
INFO - 2020-08-23 15:15:08 --> Helper loaded: url_helper
INFO - 2020-08-23 15:15:08 --> Helper loaded: form_helper
INFO - 2020-08-23 15:15:08 --> Helper loaded: file_helper
INFO - 2020-08-23 15:15:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:15:08 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:15:08 --> Upload Class Initialized
INFO - 2020-08-23 15:15:08 --> Controller Class Initialized
ERROR - 2020-08-23 15:15:08 --> 404 Page Not Found: /index
INFO - 2020-08-23 15:15:09 --> Config Class Initialized
INFO - 2020-08-23 15:15:09 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:15:09 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:15:09 --> Utf8 Class Initialized
INFO - 2020-08-23 15:15:09 --> URI Class Initialized
DEBUG - 2020-08-23 15:15:09 --> No URI present. Default controller set.
INFO - 2020-08-23 15:15:09 --> Router Class Initialized
INFO - 2020-08-23 15:15:09 --> Output Class Initialized
INFO - 2020-08-23 15:15:09 --> Security Class Initialized
DEBUG - 2020-08-23 15:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:15:09 --> Input Class Initialized
INFO - 2020-08-23 15:15:09 --> Language Class Initialized
INFO - 2020-08-23 15:15:09 --> Language Class Initialized
INFO - 2020-08-23 15:15:09 --> Config Class Initialized
INFO - 2020-08-23 15:15:09 --> Loader Class Initialized
INFO - 2020-08-23 15:15:09 --> Helper loaded: url_helper
INFO - 2020-08-23 15:15:09 --> Helper loaded: form_helper
INFO - 2020-08-23 15:15:09 --> Helper loaded: file_helper
INFO - 2020-08-23 15:15:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:15:09 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:15:09 --> Upload Class Initialized
INFO - 2020-08-23 15:15:09 --> Controller Class Initialized
DEBUG - 2020-08-23 15:15:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:15:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:15:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:15:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:15:09 --> Final output sent to browser
DEBUG - 2020-08-23 15:15:09 --> Total execution time: 0.0753
INFO - 2020-08-23 15:40:48 --> Config Class Initialized
INFO - 2020-08-23 15:40:48 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:40:48 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:40:48 --> Utf8 Class Initialized
INFO - 2020-08-23 15:40:48 --> URI Class Initialized
DEBUG - 2020-08-23 15:40:48 --> No URI present. Default controller set.
INFO - 2020-08-23 15:40:48 --> Router Class Initialized
INFO - 2020-08-23 15:40:48 --> Output Class Initialized
INFO - 2020-08-23 15:40:48 --> Security Class Initialized
DEBUG - 2020-08-23 15:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:40:48 --> Input Class Initialized
INFO - 2020-08-23 15:40:48 --> Language Class Initialized
INFO - 2020-08-23 15:40:48 --> Language Class Initialized
INFO - 2020-08-23 15:40:48 --> Config Class Initialized
INFO - 2020-08-23 15:40:48 --> Loader Class Initialized
INFO - 2020-08-23 15:40:48 --> Helper loaded: url_helper
INFO - 2020-08-23 15:40:48 --> Helper loaded: form_helper
INFO - 2020-08-23 15:40:48 --> Helper loaded: file_helper
INFO - 2020-08-23 15:40:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:40:48 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:40:48 --> Upload Class Initialized
INFO - 2020-08-23 15:40:48 --> Controller Class Initialized
DEBUG - 2020-08-23 15:40:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:40:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:40:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:40:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:40:48 --> Final output sent to browser
DEBUG - 2020-08-23 15:40:48 --> Total execution time: 0.0523
INFO - 2020-08-23 15:40:54 --> Config Class Initialized
INFO - 2020-08-23 15:40:54 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:40:54 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:40:54 --> Utf8 Class Initialized
INFO - 2020-08-23 15:40:54 --> URI Class Initialized
INFO - 2020-08-23 15:40:54 --> Router Class Initialized
INFO - 2020-08-23 15:40:54 --> Output Class Initialized
INFO - 2020-08-23 15:40:54 --> Security Class Initialized
DEBUG - 2020-08-23 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:40:54 --> Input Class Initialized
INFO - 2020-08-23 15:40:54 --> Language Class Initialized
INFO - 2020-08-23 15:40:54 --> Language Class Initialized
INFO - 2020-08-23 15:40:54 --> Config Class Initialized
INFO - 2020-08-23 15:40:54 --> Loader Class Initialized
INFO - 2020-08-23 15:40:54 --> Helper loaded: url_helper
INFO - 2020-08-23 15:40:54 --> Helper loaded: form_helper
INFO - 2020-08-23 15:40:54 --> Helper loaded: file_helper
INFO - 2020-08-23 15:40:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:40:54 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:40:54 --> Upload Class Initialized
INFO - 2020-08-23 15:40:54 --> Controller Class Initialized
ERROR - 2020-08-23 15:40:54 --> 404 Page Not Found: /index
INFO - 2020-08-23 15:44:41 --> Config Class Initialized
INFO - 2020-08-23 15:44:41 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:44:41 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:44:41 --> Utf8 Class Initialized
INFO - 2020-08-23 15:44:41 --> URI Class Initialized
DEBUG - 2020-08-23 15:44:41 --> No URI present. Default controller set.
INFO - 2020-08-23 15:44:41 --> Router Class Initialized
INFO - 2020-08-23 15:44:41 --> Output Class Initialized
INFO - 2020-08-23 15:44:41 --> Security Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:44:41 --> Input Class Initialized
INFO - 2020-08-23 15:44:41 --> Language Class Initialized
INFO - 2020-08-23 15:44:41 --> Language Class Initialized
INFO - 2020-08-23 15:44:41 --> Config Class Initialized
INFO - 2020-08-23 15:44:41 --> Loader Class Initialized
INFO - 2020-08-23 15:44:41 --> Helper loaded: url_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: form_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: file_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:44:41 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:44:41 --> Upload Class Initialized
INFO - 2020-08-23 15:44:41 --> Controller Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:44:41 --> Final output sent to browser
DEBUG - 2020-08-23 15:44:41 --> Total execution time: 0.0524
INFO - 2020-08-23 15:44:41 --> Config Class Initialized
INFO - 2020-08-23 15:44:41 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:44:41 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:44:41 --> Utf8 Class Initialized
INFO - 2020-08-23 15:44:41 --> URI Class Initialized
DEBUG - 2020-08-23 15:44:41 --> No URI present. Default controller set.
INFO - 2020-08-23 15:44:41 --> Router Class Initialized
INFO - 2020-08-23 15:44:41 --> Output Class Initialized
INFO - 2020-08-23 15:44:41 --> Security Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:44:41 --> Input Class Initialized
INFO - 2020-08-23 15:44:41 --> Language Class Initialized
INFO - 2020-08-23 15:44:41 --> Language Class Initialized
INFO - 2020-08-23 15:44:41 --> Config Class Initialized
INFO - 2020-08-23 15:44:41 --> Loader Class Initialized
INFO - 2020-08-23 15:44:41 --> Helper loaded: url_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: form_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: file_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:44:41 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:44:41 --> Upload Class Initialized
INFO - 2020-08-23 15:44:41 --> Controller Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:44:41 --> Final output sent to browser
DEBUG - 2020-08-23 15:44:41 --> Total execution time: 0.0505
INFO - 2020-08-23 15:44:41 --> Config Class Initialized
INFO - 2020-08-23 15:44:41 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:44:41 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:44:41 --> Utf8 Class Initialized
INFO - 2020-08-23 15:44:41 --> URI Class Initialized
DEBUG - 2020-08-23 15:44:41 --> No URI present. Default controller set.
INFO - 2020-08-23 15:44:41 --> Router Class Initialized
INFO - 2020-08-23 15:44:41 --> Output Class Initialized
INFO - 2020-08-23 15:44:41 --> Security Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:44:41 --> Input Class Initialized
INFO - 2020-08-23 15:44:41 --> Language Class Initialized
INFO - 2020-08-23 15:44:41 --> Language Class Initialized
INFO - 2020-08-23 15:44:41 --> Config Class Initialized
INFO - 2020-08-23 15:44:41 --> Loader Class Initialized
INFO - 2020-08-23 15:44:41 --> Helper loaded: url_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: form_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: file_helper
INFO - 2020-08-23 15:44:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:44:41 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:44:41 --> Upload Class Initialized
INFO - 2020-08-23 15:44:41 --> Controller Class Initialized
DEBUG - 2020-08-23 15:44:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:44:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:44:41 --> Final output sent to browser
DEBUG - 2020-08-23 15:44:41 --> Total execution time: 0.0517
INFO - 2020-08-23 15:44:42 --> Config Class Initialized
INFO - 2020-08-23 15:44:42 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:44:42 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:44:42 --> Utf8 Class Initialized
INFO - 2020-08-23 15:44:42 --> URI Class Initialized
DEBUG - 2020-08-23 15:44:42 --> No URI present. Default controller set.
INFO - 2020-08-23 15:44:42 --> Router Class Initialized
INFO - 2020-08-23 15:44:42 --> Output Class Initialized
INFO - 2020-08-23 15:44:42 --> Security Class Initialized
DEBUG - 2020-08-23 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:44:42 --> Input Class Initialized
INFO - 2020-08-23 15:44:42 --> Language Class Initialized
INFO - 2020-08-23 15:44:42 --> Language Class Initialized
INFO - 2020-08-23 15:44:42 --> Config Class Initialized
INFO - 2020-08-23 15:44:42 --> Loader Class Initialized
INFO - 2020-08-23 15:44:42 --> Helper loaded: url_helper
INFO - 2020-08-23 15:44:42 --> Helper loaded: form_helper
INFO - 2020-08-23 15:44:42 --> Helper loaded: file_helper
INFO - 2020-08-23 15:44:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:44:42 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:44:42 --> Upload Class Initialized
INFO - 2020-08-23 15:44:42 --> Controller Class Initialized
DEBUG - 2020-08-23 15:44:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:44:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:44:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:44:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:44:42 --> Final output sent to browser
DEBUG - 2020-08-23 15:44:42 --> Total execution time: 0.0499
INFO - 2020-08-23 15:52:37 --> Config Class Initialized
INFO - 2020-08-23 15:52:37 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:52:37 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:52:37 --> Utf8 Class Initialized
INFO - 2020-08-23 15:52:37 --> URI Class Initialized
DEBUG - 2020-08-23 15:52:37 --> No URI present. Default controller set.
INFO - 2020-08-23 15:52:37 --> Router Class Initialized
INFO - 2020-08-23 15:52:37 --> Output Class Initialized
INFO - 2020-08-23 15:52:37 --> Security Class Initialized
DEBUG - 2020-08-23 15:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:52:37 --> Input Class Initialized
INFO - 2020-08-23 15:52:37 --> Language Class Initialized
INFO - 2020-08-23 15:52:37 --> Language Class Initialized
INFO - 2020-08-23 15:52:37 --> Config Class Initialized
INFO - 2020-08-23 15:52:37 --> Loader Class Initialized
INFO - 2020-08-23 15:52:37 --> Helper loaded: url_helper
INFO - 2020-08-23 15:52:37 --> Helper loaded: form_helper
INFO - 2020-08-23 15:52:37 --> Helper loaded: file_helper
INFO - 2020-08-23 15:52:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:52:37 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:52:37 --> Upload Class Initialized
INFO - 2020-08-23 15:52:37 --> Controller Class Initialized
DEBUG - 2020-08-23 15:52:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:52:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:52:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:52:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:52:37 --> Final output sent to browser
DEBUG - 2020-08-23 15:52:37 --> Total execution time: 0.0499
INFO - 2020-08-23 15:52:48 --> Config Class Initialized
INFO - 2020-08-23 15:52:48 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:52:48 --> Utf8 Class Initialized
INFO - 2020-08-23 15:52:48 --> URI Class Initialized
INFO - 2020-08-23 15:52:48 --> Router Class Initialized
INFO - 2020-08-23 15:52:48 --> Output Class Initialized
INFO - 2020-08-23 15:52:48 --> Security Class Initialized
DEBUG - 2020-08-23 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:52:48 --> Input Class Initialized
INFO - 2020-08-23 15:52:48 --> Language Class Initialized
INFO - 2020-08-23 15:52:48 --> Language Class Initialized
INFO - 2020-08-23 15:52:48 --> Config Class Initialized
INFO - 2020-08-23 15:52:48 --> Loader Class Initialized
INFO - 2020-08-23 15:52:48 --> Helper loaded: url_helper
INFO - 2020-08-23 15:52:48 --> Helper loaded: form_helper
INFO - 2020-08-23 15:52:48 --> Helper loaded: file_helper
INFO - 2020-08-23 15:52:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:52:48 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:52:48 --> Upload Class Initialized
INFO - 2020-08-23 15:52:48 --> Controller Class Initialized
ERROR - 2020-08-23 15:52:48 --> 404 Page Not Found: /index
INFO - 2020-08-23 15:53:37 --> Config Class Initialized
INFO - 2020-08-23 15:53:37 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:53:37 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:53:37 --> Utf8 Class Initialized
INFO - 2020-08-23 15:53:37 --> URI Class Initialized
INFO - 2020-08-23 15:53:37 --> Router Class Initialized
INFO - 2020-08-23 15:53:37 --> Output Class Initialized
INFO - 2020-08-23 15:53:37 --> Security Class Initialized
DEBUG - 2020-08-23 15:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:53:37 --> Input Class Initialized
INFO - 2020-08-23 15:53:37 --> Language Class Initialized
INFO - 2020-08-23 15:53:37 --> Language Class Initialized
INFO - 2020-08-23 15:53:37 --> Config Class Initialized
INFO - 2020-08-23 15:53:37 --> Loader Class Initialized
INFO - 2020-08-23 15:53:37 --> Helper loaded: url_helper
INFO - 2020-08-23 15:53:37 --> Helper loaded: form_helper
INFO - 2020-08-23 15:53:37 --> Helper loaded: file_helper
INFO - 2020-08-23 15:53:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:53:37 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:53:37 --> Upload Class Initialized
INFO - 2020-08-23 15:53:37 --> Controller Class Initialized
ERROR - 2020-08-23 15:53:37 --> 404 Page Not Found: /index
INFO - 2020-08-23 15:53:38 --> Config Class Initialized
INFO - 2020-08-23 15:53:38 --> Hooks Class Initialized
DEBUG - 2020-08-23 15:53:38 --> UTF-8 Support Enabled
INFO - 2020-08-23 15:53:38 --> Utf8 Class Initialized
INFO - 2020-08-23 15:53:38 --> URI Class Initialized
DEBUG - 2020-08-23 15:53:38 --> No URI present. Default controller set.
INFO - 2020-08-23 15:53:38 --> Router Class Initialized
INFO - 2020-08-23 15:53:38 --> Output Class Initialized
INFO - 2020-08-23 15:53:38 --> Security Class Initialized
DEBUG - 2020-08-23 15:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 15:53:38 --> Input Class Initialized
INFO - 2020-08-23 15:53:38 --> Language Class Initialized
INFO - 2020-08-23 15:53:38 --> Language Class Initialized
INFO - 2020-08-23 15:53:38 --> Config Class Initialized
INFO - 2020-08-23 15:53:38 --> Loader Class Initialized
INFO - 2020-08-23 15:53:38 --> Helper loaded: url_helper
INFO - 2020-08-23 15:53:38 --> Helper loaded: form_helper
INFO - 2020-08-23 15:53:38 --> Helper loaded: file_helper
INFO - 2020-08-23 15:53:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 15:53:38 --> Database Driver Class Initialized
DEBUG - 2020-08-23 15:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 15:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 15:53:38 --> Upload Class Initialized
INFO - 2020-08-23 15:53:38 --> Controller Class Initialized
DEBUG - 2020-08-23 15:53:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 15:53:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 15:53:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 15:53:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 15:53:38 --> Final output sent to browser
DEBUG - 2020-08-23 15:53:38 --> Total execution time: 0.0472
INFO - 2020-08-23 16:00:25 --> Config Class Initialized
INFO - 2020-08-23 16:00:25 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:00:25 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:00:25 --> Utf8 Class Initialized
INFO - 2020-08-23 16:00:25 --> URI Class Initialized
INFO - 2020-08-23 16:00:25 --> Router Class Initialized
INFO - 2020-08-23 16:00:25 --> Output Class Initialized
INFO - 2020-08-23 16:00:25 --> Security Class Initialized
DEBUG - 2020-08-23 16:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:00:25 --> Input Class Initialized
INFO - 2020-08-23 16:00:25 --> Language Class Initialized
INFO - 2020-08-23 16:00:25 --> Language Class Initialized
INFO - 2020-08-23 16:00:25 --> Config Class Initialized
INFO - 2020-08-23 16:00:25 --> Loader Class Initialized
INFO - 2020-08-23 16:00:25 --> Helper loaded: url_helper
INFO - 2020-08-23 16:00:25 --> Helper loaded: form_helper
INFO - 2020-08-23 16:00:25 --> Helper loaded: file_helper
INFO - 2020-08-23 16:00:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:00:25 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:00:25 --> Upload Class Initialized
INFO - 2020-08-23 16:00:25 --> Controller Class Initialized
ERROR - 2020-08-23 16:00:25 --> 404 Page Not Found: /index
INFO - 2020-08-23 16:00:25 --> Config Class Initialized
INFO - 2020-08-23 16:00:25 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:00:25 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:00:25 --> Utf8 Class Initialized
INFO - 2020-08-23 16:00:25 --> URI Class Initialized
INFO - 2020-08-23 16:00:25 --> Router Class Initialized
INFO - 2020-08-23 16:00:25 --> Output Class Initialized
INFO - 2020-08-23 16:00:25 --> Security Class Initialized
DEBUG - 2020-08-23 16:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:00:25 --> Input Class Initialized
INFO - 2020-08-23 16:00:25 --> Language Class Initialized
INFO - 2020-08-23 16:00:25 --> Language Class Initialized
INFO - 2020-08-23 16:00:25 --> Config Class Initialized
INFO - 2020-08-23 16:00:25 --> Loader Class Initialized
INFO - 2020-08-23 16:00:25 --> Helper loaded: url_helper
INFO - 2020-08-23 16:00:25 --> Helper loaded: form_helper
INFO - 2020-08-23 16:00:25 --> Helper loaded: file_helper
INFO - 2020-08-23 16:00:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:00:25 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:00:25 --> Upload Class Initialized
INFO - 2020-08-23 16:00:25 --> Controller Class Initialized
ERROR - 2020-08-23 16:00:25 --> 404 Page Not Found: /index
INFO - 2020-08-23 16:03:22 --> Config Class Initialized
INFO - 2020-08-23 16:03:22 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:03:22 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:03:22 --> Utf8 Class Initialized
INFO - 2020-08-23 16:03:22 --> URI Class Initialized
DEBUG - 2020-08-23 16:03:22 --> No URI present. Default controller set.
INFO - 2020-08-23 16:03:22 --> Router Class Initialized
INFO - 2020-08-23 16:03:22 --> Output Class Initialized
INFO - 2020-08-23 16:03:22 --> Security Class Initialized
DEBUG - 2020-08-23 16:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:03:22 --> Input Class Initialized
INFO - 2020-08-23 16:03:22 --> Language Class Initialized
INFO - 2020-08-23 16:03:22 --> Language Class Initialized
INFO - 2020-08-23 16:03:22 --> Config Class Initialized
INFO - 2020-08-23 16:03:22 --> Loader Class Initialized
INFO - 2020-08-23 16:03:22 --> Helper loaded: url_helper
INFO - 2020-08-23 16:03:22 --> Helper loaded: form_helper
INFO - 2020-08-23 16:03:22 --> Helper loaded: file_helper
INFO - 2020-08-23 16:03:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:03:22 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:03:22 --> Upload Class Initialized
INFO - 2020-08-23 16:03:22 --> Controller Class Initialized
DEBUG - 2020-08-23 16:03:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 16:03:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 16:03:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 16:03:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 16:03:22 --> Final output sent to browser
DEBUG - 2020-08-23 16:03:22 --> Total execution time: 0.0511
INFO - 2020-08-23 16:05:59 --> Config Class Initialized
INFO - 2020-08-23 16:05:59 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:05:59 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:05:59 --> Utf8 Class Initialized
INFO - 2020-08-23 16:05:59 --> URI Class Initialized
INFO - 2020-08-23 16:05:59 --> Router Class Initialized
INFO - 2020-08-23 16:05:59 --> Output Class Initialized
INFO - 2020-08-23 16:05:59 --> Security Class Initialized
DEBUG - 2020-08-23 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:05:59 --> Input Class Initialized
INFO - 2020-08-23 16:05:59 --> Language Class Initialized
INFO - 2020-08-23 16:05:59 --> Language Class Initialized
INFO - 2020-08-23 16:05:59 --> Config Class Initialized
INFO - 2020-08-23 16:05:59 --> Loader Class Initialized
INFO - 2020-08-23 16:05:59 --> Helper loaded: url_helper
INFO - 2020-08-23 16:05:59 --> Helper loaded: form_helper
INFO - 2020-08-23 16:05:59 --> Helper loaded: file_helper
INFO - 2020-08-23 16:05:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:05:59 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:05:59 --> Upload Class Initialized
INFO - 2020-08-23 16:05:59 --> Controller Class Initialized
ERROR - 2020-08-23 16:05:59 --> 404 Page Not Found: /index
INFO - 2020-08-23 16:08:01 --> Config Class Initialized
INFO - 2020-08-23 16:08:01 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:08:01 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:08:01 --> Utf8 Class Initialized
INFO - 2020-08-23 16:08:01 --> URI Class Initialized
INFO - 2020-08-23 16:08:01 --> Router Class Initialized
INFO - 2020-08-23 16:08:01 --> Output Class Initialized
INFO - 2020-08-23 16:08:01 --> Security Class Initialized
DEBUG - 2020-08-23 16:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:08:01 --> Input Class Initialized
INFO - 2020-08-23 16:08:01 --> Language Class Initialized
INFO - 2020-08-23 16:08:01 --> Language Class Initialized
INFO - 2020-08-23 16:08:01 --> Config Class Initialized
INFO - 2020-08-23 16:08:01 --> Loader Class Initialized
INFO - 2020-08-23 16:08:01 --> Helper loaded: url_helper
INFO - 2020-08-23 16:08:01 --> Helper loaded: form_helper
INFO - 2020-08-23 16:08:01 --> Helper loaded: file_helper
INFO - 2020-08-23 16:08:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:08:01 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:08:01 --> Upload Class Initialized
INFO - 2020-08-23 16:08:01 --> Controller Class Initialized
ERROR - 2020-08-23 16:08:01 --> 404 Page Not Found: /index
INFO - 2020-08-23 16:12:00 --> Config Class Initialized
INFO - 2020-08-23 16:12:00 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:12:00 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:12:00 --> Utf8 Class Initialized
INFO - 2020-08-23 16:12:00 --> URI Class Initialized
INFO - 2020-08-23 16:12:00 --> Router Class Initialized
INFO - 2020-08-23 16:12:00 --> Output Class Initialized
INFO - 2020-08-23 16:12:00 --> Security Class Initialized
DEBUG - 2020-08-23 16:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:12:00 --> Input Class Initialized
INFO - 2020-08-23 16:12:00 --> Language Class Initialized
INFO - 2020-08-23 16:12:00 --> Language Class Initialized
INFO - 2020-08-23 16:12:00 --> Config Class Initialized
INFO - 2020-08-23 16:12:00 --> Loader Class Initialized
INFO - 2020-08-23 16:12:00 --> Helper loaded: url_helper
INFO - 2020-08-23 16:12:00 --> Helper loaded: form_helper
INFO - 2020-08-23 16:12:00 --> Helper loaded: file_helper
INFO - 2020-08-23 16:12:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:12:00 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:12:00 --> Upload Class Initialized
INFO - 2020-08-23 16:12:00 --> Controller Class Initialized
DEBUG - 2020-08-23 16:12:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 16:12:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-23 16:12:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 16:12:00 --> Final output sent to browser
DEBUG - 2020-08-23 16:12:00 --> Total execution time: 0.0540
INFO - 2020-08-23 16:12:03 --> Config Class Initialized
INFO - 2020-08-23 16:12:03 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:12:03 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:12:03 --> Utf8 Class Initialized
INFO - 2020-08-23 16:12:03 --> URI Class Initialized
INFO - 2020-08-23 16:12:03 --> Router Class Initialized
INFO - 2020-08-23 16:12:03 --> Output Class Initialized
INFO - 2020-08-23 16:12:03 --> Security Class Initialized
DEBUG - 2020-08-23 16:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:12:03 --> Input Class Initialized
INFO - 2020-08-23 16:12:03 --> Language Class Initialized
INFO - 2020-08-23 16:12:03 --> Language Class Initialized
INFO - 2020-08-23 16:12:03 --> Config Class Initialized
INFO - 2020-08-23 16:12:03 --> Loader Class Initialized
INFO - 2020-08-23 16:12:03 --> Helper loaded: url_helper
INFO - 2020-08-23 16:12:03 --> Helper loaded: form_helper
INFO - 2020-08-23 16:12:03 --> Helper loaded: file_helper
INFO - 2020-08-23 16:12:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:12:03 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:12:03 --> Upload Class Initialized
INFO - 2020-08-23 16:12:03 --> Controller Class Initialized
ERROR - 2020-08-23 16:12:03 --> 404 Page Not Found: /index
INFO - 2020-08-23 16:12:05 --> Config Class Initialized
INFO - 2020-08-23 16:12:05 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:12:05 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:12:05 --> Utf8 Class Initialized
INFO - 2020-08-23 16:12:05 --> URI Class Initialized
INFO - 2020-08-23 16:12:05 --> Router Class Initialized
INFO - 2020-08-23 16:12:05 --> Output Class Initialized
INFO - 2020-08-23 16:12:05 --> Security Class Initialized
DEBUG - 2020-08-23 16:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:12:05 --> Input Class Initialized
INFO - 2020-08-23 16:12:05 --> Language Class Initialized
INFO - 2020-08-23 16:12:05 --> Language Class Initialized
INFO - 2020-08-23 16:12:05 --> Config Class Initialized
INFO - 2020-08-23 16:12:05 --> Loader Class Initialized
INFO - 2020-08-23 16:12:05 --> Helper loaded: url_helper
INFO - 2020-08-23 16:12:05 --> Helper loaded: form_helper
INFO - 2020-08-23 16:12:05 --> Helper loaded: file_helper
INFO - 2020-08-23 16:12:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:12:05 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:12:05 --> Upload Class Initialized
INFO - 2020-08-23 16:12:05 --> Controller Class Initialized
DEBUG - 2020-08-23 16:12:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 16:12:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-23 16:12:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 16:12:05 --> Final output sent to browser
DEBUG - 2020-08-23 16:12:05 --> Total execution time: 0.0521
INFO - 2020-08-23 16:12:08 --> Config Class Initialized
INFO - 2020-08-23 16:12:08 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:12:08 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:12:08 --> Utf8 Class Initialized
INFO - 2020-08-23 16:12:08 --> URI Class Initialized
INFO - 2020-08-23 16:12:08 --> Router Class Initialized
INFO - 2020-08-23 16:12:08 --> Output Class Initialized
INFO - 2020-08-23 16:12:08 --> Security Class Initialized
DEBUG - 2020-08-23 16:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:12:08 --> Input Class Initialized
INFO - 2020-08-23 16:12:08 --> Language Class Initialized
INFO - 2020-08-23 16:12:08 --> Language Class Initialized
INFO - 2020-08-23 16:12:08 --> Config Class Initialized
INFO - 2020-08-23 16:12:08 --> Loader Class Initialized
INFO - 2020-08-23 16:12:08 --> Helper loaded: url_helper
INFO - 2020-08-23 16:12:08 --> Helper loaded: form_helper
INFO - 2020-08-23 16:12:08 --> Helper loaded: file_helper
INFO - 2020-08-23 16:12:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:12:08 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:12:08 --> Upload Class Initialized
INFO - 2020-08-23 16:12:08 --> Controller Class Initialized
DEBUG - 2020-08-23 16:12:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 16:12:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-23 16:12:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 16:12:08 --> Final output sent to browser
DEBUG - 2020-08-23 16:12:08 --> Total execution time: 0.0546
INFO - 2020-08-23 16:12:09 --> Config Class Initialized
INFO - 2020-08-23 16:12:09 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:12:09 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:12:09 --> Utf8 Class Initialized
INFO - 2020-08-23 16:12:09 --> URI Class Initialized
INFO - 2020-08-23 16:12:09 --> Router Class Initialized
INFO - 2020-08-23 16:12:09 --> Output Class Initialized
INFO - 2020-08-23 16:12:09 --> Security Class Initialized
DEBUG - 2020-08-23 16:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:12:09 --> Input Class Initialized
INFO - 2020-08-23 16:12:09 --> Language Class Initialized
INFO - 2020-08-23 16:12:09 --> Language Class Initialized
INFO - 2020-08-23 16:12:09 --> Config Class Initialized
INFO - 2020-08-23 16:12:09 --> Loader Class Initialized
INFO - 2020-08-23 16:12:09 --> Helper loaded: url_helper
INFO - 2020-08-23 16:12:09 --> Helper loaded: form_helper
INFO - 2020-08-23 16:12:09 --> Helper loaded: file_helper
INFO - 2020-08-23 16:12:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:12:09 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:12:09 --> Upload Class Initialized
INFO - 2020-08-23 16:12:09 --> Controller Class Initialized
ERROR - 2020-08-23 16:12:09 --> 404 Page Not Found: /index
INFO - 2020-08-23 16:24:32 --> Config Class Initialized
INFO - 2020-08-23 16:24:32 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:24:32 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:24:32 --> Utf8 Class Initialized
INFO - 2020-08-23 16:24:32 --> URI Class Initialized
DEBUG - 2020-08-23 16:24:32 --> No URI present. Default controller set.
INFO - 2020-08-23 16:24:32 --> Router Class Initialized
INFO - 2020-08-23 16:24:32 --> Output Class Initialized
INFO - 2020-08-23 16:24:32 --> Security Class Initialized
DEBUG - 2020-08-23 16:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:24:32 --> Input Class Initialized
INFO - 2020-08-23 16:24:32 --> Language Class Initialized
INFO - 2020-08-23 16:24:32 --> Language Class Initialized
INFO - 2020-08-23 16:24:32 --> Config Class Initialized
INFO - 2020-08-23 16:24:32 --> Loader Class Initialized
INFO - 2020-08-23 16:24:32 --> Helper loaded: url_helper
INFO - 2020-08-23 16:24:32 --> Helper loaded: form_helper
INFO - 2020-08-23 16:24:32 --> Helper loaded: file_helper
INFO - 2020-08-23 16:24:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:24:32 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:24:32 --> Upload Class Initialized
INFO - 2020-08-23 16:24:32 --> Controller Class Initialized
DEBUG - 2020-08-23 16:24:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 16:24:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 16:24:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 16:24:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 16:24:32 --> Final output sent to browser
DEBUG - 2020-08-23 16:24:32 --> Total execution time: 0.0512
INFO - 2020-08-23 16:41:40 --> Config Class Initialized
INFO - 2020-08-23 16:41:40 --> Hooks Class Initialized
DEBUG - 2020-08-23 16:41:40 --> UTF-8 Support Enabled
INFO - 2020-08-23 16:41:40 --> Utf8 Class Initialized
INFO - 2020-08-23 16:41:40 --> URI Class Initialized
INFO - 2020-08-23 16:41:40 --> Router Class Initialized
INFO - 2020-08-23 16:41:40 --> Output Class Initialized
INFO - 2020-08-23 16:41:40 --> Security Class Initialized
DEBUG - 2020-08-23 16:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 16:41:40 --> Input Class Initialized
INFO - 2020-08-23 16:41:40 --> Language Class Initialized
INFO - 2020-08-23 16:41:40 --> Language Class Initialized
INFO - 2020-08-23 16:41:40 --> Config Class Initialized
INFO - 2020-08-23 16:41:40 --> Loader Class Initialized
INFO - 2020-08-23 16:41:40 --> Helper loaded: url_helper
INFO - 2020-08-23 16:41:40 --> Helper loaded: form_helper
INFO - 2020-08-23 16:41:40 --> Helper loaded: file_helper
INFO - 2020-08-23 16:41:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 16:41:40 --> Database Driver Class Initialized
DEBUG - 2020-08-23 16:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 16:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 16:41:40 --> Upload Class Initialized
INFO - 2020-08-23 16:41:40 --> Controller Class Initialized
ERROR - 2020-08-23 16:41:40 --> 404 Page Not Found: /index
INFO - 2020-08-23 17:10:00 --> Config Class Initialized
INFO - 2020-08-23 17:10:00 --> Hooks Class Initialized
DEBUG - 2020-08-23 17:10:00 --> UTF-8 Support Enabled
INFO - 2020-08-23 17:10:00 --> Utf8 Class Initialized
INFO - 2020-08-23 17:10:00 --> URI Class Initialized
INFO - 2020-08-23 17:10:00 --> Router Class Initialized
INFO - 2020-08-23 17:10:00 --> Output Class Initialized
INFO - 2020-08-23 17:10:00 --> Security Class Initialized
DEBUG - 2020-08-23 17:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 17:10:00 --> Input Class Initialized
INFO - 2020-08-23 17:10:00 --> Language Class Initialized
INFO - 2020-08-23 17:10:00 --> Language Class Initialized
INFO - 2020-08-23 17:10:00 --> Config Class Initialized
INFO - 2020-08-23 17:10:00 --> Loader Class Initialized
INFO - 2020-08-23 17:10:00 --> Helper loaded: url_helper
INFO - 2020-08-23 17:10:00 --> Helper loaded: form_helper
INFO - 2020-08-23 17:10:00 --> Helper loaded: file_helper
INFO - 2020-08-23 17:10:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 17:10:00 --> Database Driver Class Initialized
DEBUG - 2020-08-23 17:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 17:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 17:10:00 --> Upload Class Initialized
INFO - 2020-08-23 17:10:00 --> Controller Class Initialized
ERROR - 2020-08-23 17:10:00 --> 404 Page Not Found: /index
INFO - 2020-08-23 17:10:01 --> Config Class Initialized
INFO - 2020-08-23 17:10:01 --> Hooks Class Initialized
DEBUG - 2020-08-23 17:10:01 --> UTF-8 Support Enabled
INFO - 2020-08-23 17:10:01 --> Utf8 Class Initialized
INFO - 2020-08-23 17:10:01 --> URI Class Initialized
INFO - 2020-08-23 17:10:01 --> Router Class Initialized
INFO - 2020-08-23 17:10:01 --> Output Class Initialized
INFO - 2020-08-23 17:10:01 --> Security Class Initialized
DEBUG - 2020-08-23 17:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 17:10:01 --> Input Class Initialized
INFO - 2020-08-23 17:10:01 --> Language Class Initialized
INFO - 2020-08-23 17:10:01 --> Language Class Initialized
INFO - 2020-08-23 17:10:01 --> Config Class Initialized
INFO - 2020-08-23 17:10:01 --> Loader Class Initialized
INFO - 2020-08-23 17:10:01 --> Helper loaded: url_helper
INFO - 2020-08-23 17:10:01 --> Helper loaded: form_helper
INFO - 2020-08-23 17:10:01 --> Helper loaded: file_helper
INFO - 2020-08-23 17:10:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 17:10:01 --> Database Driver Class Initialized
DEBUG - 2020-08-23 17:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 17:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 17:10:01 --> Upload Class Initialized
INFO - 2020-08-23 17:10:02 --> Controller Class Initialized
DEBUG - 2020-08-23 17:10:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 17:10:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-23 17:10:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 17:10:02 --> Final output sent to browser
DEBUG - 2020-08-23 17:10:02 --> Total execution time: 0.4406
INFO - 2020-08-23 17:53:04 --> Config Class Initialized
INFO - 2020-08-23 17:53:04 --> Hooks Class Initialized
DEBUG - 2020-08-23 17:53:04 --> UTF-8 Support Enabled
INFO - 2020-08-23 17:53:04 --> Utf8 Class Initialized
INFO - 2020-08-23 17:53:04 --> URI Class Initialized
DEBUG - 2020-08-23 17:53:04 --> No URI present. Default controller set.
INFO - 2020-08-23 17:53:04 --> Router Class Initialized
INFO - 2020-08-23 17:53:04 --> Output Class Initialized
INFO - 2020-08-23 17:53:04 --> Security Class Initialized
DEBUG - 2020-08-23 17:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 17:53:04 --> Input Class Initialized
INFO - 2020-08-23 17:53:04 --> Language Class Initialized
INFO - 2020-08-23 17:53:04 --> Language Class Initialized
INFO - 2020-08-23 17:53:04 --> Config Class Initialized
INFO - 2020-08-23 17:53:04 --> Loader Class Initialized
INFO - 2020-08-23 17:53:04 --> Helper loaded: url_helper
INFO - 2020-08-23 17:53:04 --> Helper loaded: form_helper
INFO - 2020-08-23 17:53:04 --> Helper loaded: file_helper
INFO - 2020-08-23 17:53:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 17:53:04 --> Database Driver Class Initialized
DEBUG - 2020-08-23 17:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 17:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 17:53:04 --> Upload Class Initialized
INFO - 2020-08-23 17:53:04 --> Controller Class Initialized
DEBUG - 2020-08-23 17:53:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 17:53:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 17:53:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 17:53:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 17:53:04 --> Final output sent to browser
DEBUG - 2020-08-23 17:53:04 --> Total execution time: 0.0805
INFO - 2020-08-23 17:53:04 --> Config Class Initialized
INFO - 2020-08-23 17:53:04 --> Hooks Class Initialized
DEBUG - 2020-08-23 17:53:04 --> UTF-8 Support Enabled
INFO - 2020-08-23 17:53:04 --> Utf8 Class Initialized
INFO - 2020-08-23 17:53:04 --> URI Class Initialized
DEBUG - 2020-08-23 17:53:04 --> No URI present. Default controller set.
INFO - 2020-08-23 17:53:04 --> Router Class Initialized
INFO - 2020-08-23 17:53:04 --> Output Class Initialized
INFO - 2020-08-23 17:53:04 --> Security Class Initialized
DEBUG - 2020-08-23 17:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 17:53:04 --> Input Class Initialized
INFO - 2020-08-23 17:53:04 --> Language Class Initialized
INFO - 2020-08-23 17:53:04 --> Language Class Initialized
INFO - 2020-08-23 17:53:04 --> Config Class Initialized
INFO - 2020-08-23 17:53:04 --> Loader Class Initialized
INFO - 2020-08-23 17:53:04 --> Helper loaded: url_helper
INFO - 2020-08-23 17:53:04 --> Helper loaded: form_helper
INFO - 2020-08-23 17:53:04 --> Helper loaded: file_helper
INFO - 2020-08-23 17:53:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 17:53:04 --> Database Driver Class Initialized
DEBUG - 2020-08-23 17:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 17:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 17:53:04 --> Upload Class Initialized
INFO - 2020-08-23 17:53:04 --> Controller Class Initialized
DEBUG - 2020-08-23 17:53:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 17:53:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 17:53:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 17:53:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 17:53:04 --> Final output sent to browser
DEBUG - 2020-08-23 17:53:04 --> Total execution time: 0.0519
INFO - 2020-08-23 18:07:58 --> Config Class Initialized
INFO - 2020-08-23 18:07:58 --> Hooks Class Initialized
DEBUG - 2020-08-23 18:07:58 --> UTF-8 Support Enabled
INFO - 2020-08-23 18:07:58 --> Utf8 Class Initialized
INFO - 2020-08-23 18:07:58 --> URI Class Initialized
DEBUG - 2020-08-23 18:07:58 --> No URI present. Default controller set.
INFO - 2020-08-23 18:07:58 --> Router Class Initialized
INFO - 2020-08-23 18:07:58 --> Output Class Initialized
INFO - 2020-08-23 18:07:58 --> Security Class Initialized
DEBUG - 2020-08-23 18:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 18:07:58 --> Input Class Initialized
INFO - 2020-08-23 18:07:58 --> Language Class Initialized
INFO - 2020-08-23 18:07:58 --> Language Class Initialized
INFO - 2020-08-23 18:07:58 --> Config Class Initialized
INFO - 2020-08-23 18:07:58 --> Loader Class Initialized
INFO - 2020-08-23 18:07:58 --> Helper loaded: url_helper
INFO - 2020-08-23 18:07:58 --> Helper loaded: form_helper
INFO - 2020-08-23 18:07:58 --> Helper loaded: file_helper
INFO - 2020-08-23 18:07:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 18:07:58 --> Database Driver Class Initialized
DEBUG - 2020-08-23 18:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 18:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 18:07:58 --> Upload Class Initialized
INFO - 2020-08-23 18:07:58 --> Controller Class Initialized
DEBUG - 2020-08-23 18:07:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 18:07:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 18:07:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 18:07:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 18:07:58 --> Final output sent to browser
DEBUG - 2020-08-23 18:07:58 --> Total execution time: 0.0517
INFO - 2020-08-23 19:06:17 --> Config Class Initialized
INFO - 2020-08-23 19:06:17 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:06:17 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:06:17 --> Utf8 Class Initialized
INFO - 2020-08-23 19:06:17 --> URI Class Initialized
INFO - 2020-08-23 19:06:17 --> Router Class Initialized
INFO - 2020-08-23 19:06:17 --> Output Class Initialized
INFO - 2020-08-23 19:06:17 --> Security Class Initialized
DEBUG - 2020-08-23 19:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:06:17 --> Input Class Initialized
INFO - 2020-08-23 19:06:17 --> Language Class Initialized
INFO - 2020-08-23 19:06:17 --> Language Class Initialized
INFO - 2020-08-23 19:06:17 --> Config Class Initialized
INFO - 2020-08-23 19:06:17 --> Loader Class Initialized
INFO - 2020-08-23 19:06:17 --> Helper loaded: url_helper
INFO - 2020-08-23 19:06:17 --> Helper loaded: form_helper
INFO - 2020-08-23 19:06:17 --> Helper loaded: file_helper
INFO - 2020-08-23 19:06:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:06:17 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:06:17 --> Upload Class Initialized
INFO - 2020-08-23 19:06:17 --> Controller Class Initialized
DEBUG - 2020-08-23 19:06:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:06:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-23 19:06:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:06:17 --> Final output sent to browser
DEBUG - 2020-08-23 19:06:17 --> Total execution time: 0.1728
INFO - 2020-08-23 19:06:19 --> Config Class Initialized
INFO - 2020-08-23 19:06:19 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:06:19 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:06:19 --> Utf8 Class Initialized
INFO - 2020-08-23 19:06:19 --> URI Class Initialized
INFO - 2020-08-23 19:06:19 --> Router Class Initialized
INFO - 2020-08-23 19:06:19 --> Output Class Initialized
INFO - 2020-08-23 19:06:19 --> Security Class Initialized
DEBUG - 2020-08-23 19:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:06:19 --> Input Class Initialized
INFO - 2020-08-23 19:06:19 --> Language Class Initialized
INFO - 2020-08-23 19:06:19 --> Language Class Initialized
INFO - 2020-08-23 19:06:19 --> Config Class Initialized
INFO - 2020-08-23 19:06:19 --> Loader Class Initialized
INFO - 2020-08-23 19:06:19 --> Helper loaded: url_helper
INFO - 2020-08-23 19:06:19 --> Helper loaded: form_helper
INFO - 2020-08-23 19:06:19 --> Helper loaded: file_helper
INFO - 2020-08-23 19:06:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:06:19 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:06:19 --> Upload Class Initialized
INFO - 2020-08-23 19:06:19 --> Controller Class Initialized
ERROR - 2020-08-23 19:06:19 --> 404 Page Not Found: /index
INFO - 2020-08-23 19:06:21 --> Config Class Initialized
INFO - 2020-08-23 19:06:21 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:06:21 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:06:21 --> Utf8 Class Initialized
INFO - 2020-08-23 19:06:21 --> URI Class Initialized
INFO - 2020-08-23 19:06:21 --> Router Class Initialized
INFO - 2020-08-23 19:06:21 --> Output Class Initialized
INFO - 2020-08-23 19:06:21 --> Security Class Initialized
DEBUG - 2020-08-23 19:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:06:21 --> Input Class Initialized
INFO - 2020-08-23 19:06:21 --> Language Class Initialized
INFO - 2020-08-23 19:06:21 --> Language Class Initialized
INFO - 2020-08-23 19:06:21 --> Config Class Initialized
INFO - 2020-08-23 19:06:21 --> Loader Class Initialized
INFO - 2020-08-23 19:06:21 --> Helper loaded: url_helper
INFO - 2020-08-23 19:06:21 --> Helper loaded: form_helper
INFO - 2020-08-23 19:06:21 --> Helper loaded: file_helper
INFO - 2020-08-23 19:06:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:06:21 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:06:21 --> Upload Class Initialized
INFO - 2020-08-23 19:06:21 --> Controller Class Initialized
DEBUG - 2020-08-23 19:06:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:06:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-23 19:06:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:06:21 --> Final output sent to browser
DEBUG - 2020-08-23 19:06:21 --> Total execution time: 0.0494
INFO - 2020-08-23 19:06:24 --> Config Class Initialized
INFO - 2020-08-23 19:06:24 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:06:24 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:06:24 --> Utf8 Class Initialized
INFO - 2020-08-23 19:06:24 --> URI Class Initialized
INFO - 2020-08-23 19:06:24 --> Router Class Initialized
INFO - 2020-08-23 19:06:24 --> Output Class Initialized
INFO - 2020-08-23 19:06:24 --> Security Class Initialized
DEBUG - 2020-08-23 19:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:06:24 --> Input Class Initialized
INFO - 2020-08-23 19:06:24 --> Language Class Initialized
INFO - 2020-08-23 19:06:24 --> Language Class Initialized
INFO - 2020-08-23 19:06:24 --> Config Class Initialized
INFO - 2020-08-23 19:06:24 --> Loader Class Initialized
INFO - 2020-08-23 19:06:24 --> Helper loaded: url_helper
INFO - 2020-08-23 19:06:24 --> Helper loaded: form_helper
INFO - 2020-08-23 19:06:24 --> Helper loaded: file_helper
INFO - 2020-08-23 19:06:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:06:24 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:06:24 --> Upload Class Initialized
INFO - 2020-08-23 19:06:24 --> Controller Class Initialized
DEBUG - 2020-08-23 19:06:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:06:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-23 19:06:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:06:24 --> Final output sent to browser
DEBUG - 2020-08-23 19:06:24 --> Total execution time: 0.0500
INFO - 2020-08-23 19:07:27 --> Config Class Initialized
INFO - 2020-08-23 19:07:27 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:07:27 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:07:27 --> Utf8 Class Initialized
INFO - 2020-08-23 19:07:27 --> URI Class Initialized
INFO - 2020-08-23 19:07:27 --> Router Class Initialized
INFO - 2020-08-23 19:07:27 --> Output Class Initialized
INFO - 2020-08-23 19:07:27 --> Security Class Initialized
DEBUG - 2020-08-23 19:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:07:27 --> Input Class Initialized
INFO - 2020-08-23 19:07:27 --> Language Class Initialized
INFO - 2020-08-23 19:07:27 --> Language Class Initialized
INFO - 2020-08-23 19:07:27 --> Config Class Initialized
INFO - 2020-08-23 19:07:27 --> Loader Class Initialized
INFO - 2020-08-23 19:07:27 --> Helper loaded: url_helper
INFO - 2020-08-23 19:07:27 --> Helper loaded: form_helper
INFO - 2020-08-23 19:07:27 --> Helper loaded: file_helper
INFO - 2020-08-23 19:07:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:07:27 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:07:27 --> Upload Class Initialized
INFO - 2020-08-23 19:07:27 --> Controller Class Initialized
DEBUG - 2020-08-23 19:07:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:07:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-23 19:07:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:07:27 --> Final output sent to browser
DEBUG - 2020-08-23 19:07:27 --> Total execution time: 0.0562
INFO - 2020-08-23 19:07:28 --> Config Class Initialized
INFO - 2020-08-23 19:07:28 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:07:28 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:07:28 --> Utf8 Class Initialized
INFO - 2020-08-23 19:07:28 --> URI Class Initialized
INFO - 2020-08-23 19:07:28 --> Router Class Initialized
INFO - 2020-08-23 19:07:28 --> Output Class Initialized
INFO - 2020-08-23 19:07:28 --> Security Class Initialized
DEBUG - 2020-08-23 19:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:07:28 --> Input Class Initialized
INFO - 2020-08-23 19:07:28 --> Language Class Initialized
INFO - 2020-08-23 19:07:28 --> Language Class Initialized
INFO - 2020-08-23 19:07:28 --> Config Class Initialized
INFO - 2020-08-23 19:07:28 --> Loader Class Initialized
INFO - 2020-08-23 19:07:28 --> Helper loaded: url_helper
INFO - 2020-08-23 19:07:28 --> Helper loaded: form_helper
INFO - 2020-08-23 19:07:28 --> Helper loaded: file_helper
INFO - 2020-08-23 19:07:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:07:28 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:07:28 --> Upload Class Initialized
INFO - 2020-08-23 19:07:28 --> Controller Class Initialized
ERROR - 2020-08-23 19:07:28 --> 404 Page Not Found: /index
INFO - 2020-08-23 19:07:50 --> Config Class Initialized
INFO - 2020-08-23 19:07:50 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:07:50 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:07:50 --> Utf8 Class Initialized
INFO - 2020-08-23 19:07:50 --> URI Class Initialized
DEBUG - 2020-08-23 19:07:50 --> No URI present. Default controller set.
INFO - 2020-08-23 19:07:50 --> Router Class Initialized
INFO - 2020-08-23 19:07:50 --> Output Class Initialized
INFO - 2020-08-23 19:07:50 --> Security Class Initialized
DEBUG - 2020-08-23 19:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:07:50 --> Input Class Initialized
INFO - 2020-08-23 19:07:50 --> Language Class Initialized
INFO - 2020-08-23 19:07:50 --> Language Class Initialized
INFO - 2020-08-23 19:07:50 --> Config Class Initialized
INFO - 2020-08-23 19:07:50 --> Loader Class Initialized
INFO - 2020-08-23 19:07:50 --> Helper loaded: url_helper
INFO - 2020-08-23 19:07:50 --> Helper loaded: form_helper
INFO - 2020-08-23 19:07:50 --> Helper loaded: file_helper
INFO - 2020-08-23 19:07:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:07:50 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:07:50 --> Upload Class Initialized
INFO - 2020-08-23 19:07:50 --> Controller Class Initialized
DEBUG - 2020-08-23 19:07:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:07:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 19:07:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 19:07:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:07:50 --> Final output sent to browser
DEBUG - 2020-08-23 19:07:50 --> Total execution time: 0.0528
INFO - 2020-08-23 19:07:51 --> Config Class Initialized
INFO - 2020-08-23 19:07:51 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:07:51 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:07:51 --> Utf8 Class Initialized
INFO - 2020-08-23 19:07:51 --> URI Class Initialized
INFO - 2020-08-23 19:07:51 --> Router Class Initialized
INFO - 2020-08-23 19:07:51 --> Output Class Initialized
INFO - 2020-08-23 19:07:51 --> Security Class Initialized
DEBUG - 2020-08-23 19:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:07:51 --> Input Class Initialized
INFO - 2020-08-23 19:07:51 --> Language Class Initialized
INFO - 2020-08-23 19:07:51 --> Language Class Initialized
INFO - 2020-08-23 19:07:51 --> Config Class Initialized
INFO - 2020-08-23 19:07:51 --> Loader Class Initialized
INFO - 2020-08-23 19:07:51 --> Helper loaded: url_helper
INFO - 2020-08-23 19:07:51 --> Helper loaded: form_helper
INFO - 2020-08-23 19:07:51 --> Helper loaded: file_helper
INFO - 2020-08-23 19:07:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:07:51 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:07:51 --> Upload Class Initialized
INFO - 2020-08-23 19:07:51 --> Controller Class Initialized
ERROR - 2020-08-23 19:07:51 --> 404 Page Not Found: /index
INFO - 2020-08-23 19:07:54 --> Config Class Initialized
INFO - 2020-08-23 19:07:54 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:07:54 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:07:54 --> Utf8 Class Initialized
INFO - 2020-08-23 19:07:54 --> URI Class Initialized
DEBUG - 2020-08-23 19:07:54 --> No URI present. Default controller set.
INFO - 2020-08-23 19:07:54 --> Router Class Initialized
INFO - 2020-08-23 19:07:54 --> Output Class Initialized
INFO - 2020-08-23 19:07:54 --> Security Class Initialized
DEBUG - 2020-08-23 19:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:07:54 --> Input Class Initialized
INFO - 2020-08-23 19:07:54 --> Language Class Initialized
INFO - 2020-08-23 19:07:54 --> Language Class Initialized
INFO - 2020-08-23 19:07:54 --> Config Class Initialized
INFO - 2020-08-23 19:07:54 --> Loader Class Initialized
INFO - 2020-08-23 19:07:54 --> Helper loaded: url_helper
INFO - 2020-08-23 19:07:54 --> Helper loaded: form_helper
INFO - 2020-08-23 19:07:54 --> Helper loaded: file_helper
INFO - 2020-08-23 19:07:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:07:54 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:07:54 --> Upload Class Initialized
INFO - 2020-08-23 19:07:54 --> Controller Class Initialized
DEBUG - 2020-08-23 19:07:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:07:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 19:07:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 19:07:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:07:54 --> Final output sent to browser
DEBUG - 2020-08-23 19:07:54 --> Total execution time: 0.0520
INFO - 2020-08-23 19:08:06 --> Config Class Initialized
INFO - 2020-08-23 19:08:06 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:08:06 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:08:06 --> Utf8 Class Initialized
INFO - 2020-08-23 19:08:06 --> URI Class Initialized
INFO - 2020-08-23 19:08:06 --> Router Class Initialized
INFO - 2020-08-23 19:08:06 --> Output Class Initialized
INFO - 2020-08-23 19:08:06 --> Security Class Initialized
DEBUG - 2020-08-23 19:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:08:06 --> Input Class Initialized
INFO - 2020-08-23 19:08:06 --> Language Class Initialized
INFO - 2020-08-23 19:08:06 --> Language Class Initialized
INFO - 2020-08-23 19:08:06 --> Config Class Initialized
INFO - 2020-08-23 19:08:06 --> Loader Class Initialized
INFO - 2020-08-23 19:08:06 --> Helper loaded: url_helper
INFO - 2020-08-23 19:08:06 --> Helper loaded: form_helper
INFO - 2020-08-23 19:08:06 --> Helper loaded: file_helper
INFO - 2020-08-23 19:08:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:08:06 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:08:06 --> Upload Class Initialized
INFO - 2020-08-23 19:08:06 --> Controller Class Initialized
DEBUG - 2020-08-23 19:08:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:08:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 19:08:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 19:08:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:08:06 --> Final output sent to browser
DEBUG - 2020-08-23 19:08:06 --> Total execution time: 0.0633
INFO - 2020-08-23 19:08:07 --> Config Class Initialized
INFO - 2020-08-23 19:08:07 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:08:07 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:08:07 --> Utf8 Class Initialized
INFO - 2020-08-23 19:08:07 --> URI Class Initialized
INFO - 2020-08-23 19:08:07 --> Router Class Initialized
INFO - 2020-08-23 19:08:07 --> Output Class Initialized
INFO - 2020-08-23 19:08:07 --> Security Class Initialized
DEBUG - 2020-08-23 19:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:08:07 --> Input Class Initialized
INFO - 2020-08-23 19:08:07 --> Language Class Initialized
INFO - 2020-08-23 19:08:07 --> Language Class Initialized
INFO - 2020-08-23 19:08:07 --> Config Class Initialized
INFO - 2020-08-23 19:08:07 --> Loader Class Initialized
INFO - 2020-08-23 19:08:07 --> Helper loaded: url_helper
INFO - 2020-08-23 19:08:07 --> Helper loaded: form_helper
INFO - 2020-08-23 19:08:07 --> Helper loaded: file_helper
INFO - 2020-08-23 19:08:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:08:07 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:08:07 --> Upload Class Initialized
INFO - 2020-08-23 19:08:07 --> Controller Class Initialized
ERROR - 2020-08-23 19:08:07 --> 404 Page Not Found: /index
INFO - 2020-08-23 19:08:14 --> Config Class Initialized
INFO - 2020-08-23 19:08:14 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:08:14 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:08:14 --> Utf8 Class Initialized
INFO - 2020-08-23 19:08:14 --> URI Class Initialized
INFO - 2020-08-23 19:08:14 --> Router Class Initialized
INFO - 2020-08-23 19:08:14 --> Output Class Initialized
INFO - 2020-08-23 19:08:14 --> Security Class Initialized
DEBUG - 2020-08-23 19:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:08:14 --> Input Class Initialized
INFO - 2020-08-23 19:08:14 --> Language Class Initialized
INFO - 2020-08-23 19:08:14 --> Language Class Initialized
INFO - 2020-08-23 19:08:14 --> Config Class Initialized
INFO - 2020-08-23 19:08:14 --> Loader Class Initialized
INFO - 2020-08-23 19:08:14 --> Helper loaded: url_helper
INFO - 2020-08-23 19:08:14 --> Helper loaded: form_helper
INFO - 2020-08-23 19:08:14 --> Helper loaded: file_helper
INFO - 2020-08-23 19:08:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:08:14 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:08:14 --> Upload Class Initialized
INFO - 2020-08-23 19:08:14 --> Controller Class Initialized
DEBUG - 2020-08-23 19:08:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:08:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 19:08:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 19:08:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:08:14 --> Final output sent to browser
DEBUG - 2020-08-23 19:08:14 --> Total execution time: 0.0539
INFO - 2020-08-23 19:08:23 --> Config Class Initialized
INFO - 2020-08-23 19:08:23 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:08:23 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:08:23 --> Utf8 Class Initialized
INFO - 2020-08-23 19:08:23 --> URI Class Initialized
INFO - 2020-08-23 19:08:23 --> Router Class Initialized
INFO - 2020-08-23 19:08:23 --> Output Class Initialized
INFO - 2020-08-23 19:08:23 --> Security Class Initialized
DEBUG - 2020-08-23 19:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:08:23 --> Input Class Initialized
INFO - 2020-08-23 19:08:23 --> Language Class Initialized
INFO - 2020-08-23 19:08:23 --> Language Class Initialized
INFO - 2020-08-23 19:08:23 --> Config Class Initialized
INFO - 2020-08-23 19:08:23 --> Loader Class Initialized
INFO - 2020-08-23 19:08:23 --> Helper loaded: url_helper
INFO - 2020-08-23 19:08:23 --> Helper loaded: form_helper
INFO - 2020-08-23 19:08:23 --> Helper loaded: file_helper
INFO - 2020-08-23 19:08:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:08:23 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:08:23 --> Upload Class Initialized
INFO - 2020-08-23 19:08:23 --> Controller Class Initialized
DEBUG - 2020-08-23 19:08:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:08:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 19:08:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 19:08:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:08:23 --> Final output sent to browser
DEBUG - 2020-08-23 19:08:23 --> Total execution time: 0.0552
INFO - 2020-08-23 19:08:29 --> Config Class Initialized
INFO - 2020-08-23 19:08:29 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:08:29 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:08:29 --> Utf8 Class Initialized
INFO - 2020-08-23 19:08:29 --> URI Class Initialized
DEBUG - 2020-08-23 19:08:29 --> No URI present. Default controller set.
INFO - 2020-08-23 19:08:29 --> Router Class Initialized
INFO - 2020-08-23 19:08:29 --> Output Class Initialized
INFO - 2020-08-23 19:08:29 --> Security Class Initialized
DEBUG - 2020-08-23 19:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:08:29 --> Input Class Initialized
INFO - 2020-08-23 19:08:29 --> Language Class Initialized
INFO - 2020-08-23 19:08:29 --> Language Class Initialized
INFO - 2020-08-23 19:08:29 --> Config Class Initialized
INFO - 2020-08-23 19:08:29 --> Loader Class Initialized
INFO - 2020-08-23 19:08:29 --> Helper loaded: url_helper
INFO - 2020-08-23 19:08:29 --> Helper loaded: form_helper
INFO - 2020-08-23 19:08:29 --> Helper loaded: file_helper
INFO - 2020-08-23 19:08:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:08:29 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:08:29 --> Upload Class Initialized
INFO - 2020-08-23 19:08:29 --> Controller Class Initialized
DEBUG - 2020-08-23 19:08:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 19:08:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 19:08:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 19:08:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 19:08:29 --> Final output sent to browser
DEBUG - 2020-08-23 19:08:29 --> Total execution time: 0.0489
INFO - 2020-08-23 19:23:59 --> Config Class Initialized
INFO - 2020-08-23 19:23:59 --> Hooks Class Initialized
DEBUG - 2020-08-23 19:23:59 --> UTF-8 Support Enabled
INFO - 2020-08-23 19:23:59 --> Utf8 Class Initialized
INFO - 2020-08-23 19:23:59 --> URI Class Initialized
INFO - 2020-08-23 19:23:59 --> Router Class Initialized
INFO - 2020-08-23 19:23:59 --> Output Class Initialized
INFO - 2020-08-23 19:23:59 --> Security Class Initialized
DEBUG - 2020-08-23 19:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 19:23:59 --> Input Class Initialized
INFO - 2020-08-23 19:23:59 --> Language Class Initialized
INFO - 2020-08-23 19:23:59 --> Language Class Initialized
INFO - 2020-08-23 19:23:59 --> Config Class Initialized
INFO - 2020-08-23 19:23:59 --> Loader Class Initialized
INFO - 2020-08-23 19:23:59 --> Helper loaded: url_helper
INFO - 2020-08-23 19:23:59 --> Helper loaded: form_helper
INFO - 2020-08-23 19:23:59 --> Helper loaded: file_helper
INFO - 2020-08-23 19:23:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 19:23:59 --> Database Driver Class Initialized
DEBUG - 2020-08-23 19:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 19:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 19:23:59 --> Upload Class Initialized
INFO - 2020-08-23 19:23:59 --> Controller Class Initialized
ERROR - 2020-08-23 19:23:59 --> 404 Page Not Found: /index
INFO - 2020-08-23 20:20:46 --> Config Class Initialized
INFO - 2020-08-23 20:20:46 --> Hooks Class Initialized
DEBUG - 2020-08-23 20:20:46 --> UTF-8 Support Enabled
INFO - 2020-08-23 20:20:46 --> Utf8 Class Initialized
INFO - 2020-08-23 20:20:46 --> URI Class Initialized
INFO - 2020-08-23 20:20:46 --> Router Class Initialized
INFO - 2020-08-23 20:20:46 --> Output Class Initialized
INFO - 2020-08-23 20:20:46 --> Security Class Initialized
DEBUG - 2020-08-23 20:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 20:20:46 --> Input Class Initialized
INFO - 2020-08-23 20:20:46 --> Language Class Initialized
INFO - 2020-08-23 20:20:46 --> Language Class Initialized
INFO - 2020-08-23 20:20:46 --> Config Class Initialized
INFO - 2020-08-23 20:20:46 --> Loader Class Initialized
INFO - 2020-08-23 20:20:46 --> Helper loaded: url_helper
INFO - 2020-08-23 20:20:46 --> Helper loaded: form_helper
INFO - 2020-08-23 20:20:46 --> Helper loaded: file_helper
INFO - 2020-08-23 20:20:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 20:20:46 --> Database Driver Class Initialized
DEBUG - 2020-08-23 20:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 20:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 20:20:46 --> Upload Class Initialized
INFO - 2020-08-23 20:20:46 --> Controller Class Initialized
ERROR - 2020-08-23 20:20:46 --> 404 Page Not Found: /index
INFO - 2020-08-23 20:27:43 --> Config Class Initialized
INFO - 2020-08-23 20:27:43 --> Hooks Class Initialized
DEBUG - 2020-08-23 20:27:43 --> UTF-8 Support Enabled
INFO - 2020-08-23 20:27:43 --> Utf8 Class Initialized
INFO - 2020-08-23 20:27:43 --> URI Class Initialized
DEBUG - 2020-08-23 20:27:43 --> No URI present. Default controller set.
INFO - 2020-08-23 20:27:43 --> Router Class Initialized
INFO - 2020-08-23 20:27:43 --> Output Class Initialized
INFO - 2020-08-23 20:27:43 --> Security Class Initialized
DEBUG - 2020-08-23 20:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 20:27:43 --> Input Class Initialized
INFO - 2020-08-23 20:27:43 --> Language Class Initialized
INFO - 2020-08-23 20:27:43 --> Language Class Initialized
INFO - 2020-08-23 20:27:43 --> Config Class Initialized
INFO - 2020-08-23 20:27:43 --> Loader Class Initialized
INFO - 2020-08-23 20:27:43 --> Helper loaded: url_helper
INFO - 2020-08-23 20:27:43 --> Helper loaded: form_helper
INFO - 2020-08-23 20:27:43 --> Helper loaded: file_helper
INFO - 2020-08-23 20:27:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 20:27:43 --> Database Driver Class Initialized
DEBUG - 2020-08-23 20:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 20:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 20:27:43 --> Upload Class Initialized
INFO - 2020-08-23 20:27:43 --> Controller Class Initialized
DEBUG - 2020-08-23 20:27:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 20:27:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 20:27:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 20:27:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 20:27:43 --> Final output sent to browser
DEBUG - 2020-08-23 20:27:43 --> Total execution time: 0.0463
INFO - 2020-08-23 22:11:04 --> Config Class Initialized
INFO - 2020-08-23 22:11:04 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:11:04 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:11:04 --> Utf8 Class Initialized
INFO - 2020-08-23 22:11:04 --> URI Class Initialized
DEBUG - 2020-08-23 22:11:04 --> No URI present. Default controller set.
INFO - 2020-08-23 22:11:04 --> Router Class Initialized
INFO - 2020-08-23 22:11:04 --> Output Class Initialized
INFO - 2020-08-23 22:11:04 --> Security Class Initialized
DEBUG - 2020-08-23 22:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:11:04 --> Input Class Initialized
INFO - 2020-08-23 22:11:04 --> Language Class Initialized
INFO - 2020-08-23 22:11:04 --> Language Class Initialized
INFO - 2020-08-23 22:11:04 --> Config Class Initialized
INFO - 2020-08-23 22:11:04 --> Loader Class Initialized
INFO - 2020-08-23 22:11:04 --> Helper loaded: url_helper
INFO - 2020-08-23 22:11:04 --> Helper loaded: form_helper
INFO - 2020-08-23 22:11:04 --> Helper loaded: file_helper
INFO - 2020-08-23 22:11:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:11:04 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:11:04 --> Upload Class Initialized
INFO - 2020-08-23 22:11:05 --> Controller Class Initialized
DEBUG - 2020-08-23 22:11:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:11:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:11:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:11:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:11:05 --> Final output sent to browser
DEBUG - 2020-08-23 22:11:05 --> Total execution time: 0.0570
INFO - 2020-08-23 22:11:08 --> Config Class Initialized
INFO - 2020-08-23 22:11:08 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:11:08 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:11:08 --> Utf8 Class Initialized
INFO - 2020-08-23 22:11:08 --> URI Class Initialized
DEBUG - 2020-08-23 22:11:08 --> No URI present. Default controller set.
INFO - 2020-08-23 22:11:08 --> Router Class Initialized
INFO - 2020-08-23 22:11:08 --> Output Class Initialized
INFO - 2020-08-23 22:11:08 --> Security Class Initialized
DEBUG - 2020-08-23 22:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:11:08 --> Input Class Initialized
INFO - 2020-08-23 22:11:08 --> Language Class Initialized
INFO - 2020-08-23 22:11:08 --> Language Class Initialized
INFO - 2020-08-23 22:11:08 --> Config Class Initialized
INFO - 2020-08-23 22:11:08 --> Loader Class Initialized
INFO - 2020-08-23 22:11:08 --> Helper loaded: url_helper
INFO - 2020-08-23 22:11:08 --> Helper loaded: form_helper
INFO - 2020-08-23 22:11:08 --> Helper loaded: file_helper
INFO - 2020-08-23 22:11:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:11:08 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:11:08 --> Upload Class Initialized
INFO - 2020-08-23 22:11:09 --> Controller Class Initialized
DEBUG - 2020-08-23 22:11:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:11:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:11:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:11:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:11:09 --> Final output sent to browser
DEBUG - 2020-08-23 22:11:09 --> Total execution time: 0.0706
INFO - 2020-08-23 22:11:09 --> Config Class Initialized
INFO - 2020-08-23 22:11:09 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:11:09 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:11:09 --> Utf8 Class Initialized
INFO - 2020-08-23 22:11:09 --> URI Class Initialized
INFO - 2020-08-23 22:11:09 --> Router Class Initialized
INFO - 2020-08-23 22:11:09 --> Output Class Initialized
INFO - 2020-08-23 22:11:09 --> Security Class Initialized
DEBUG - 2020-08-23 22:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:11:09 --> Input Class Initialized
INFO - 2020-08-23 22:11:09 --> Language Class Initialized
INFO - 2020-08-23 22:11:09 --> Language Class Initialized
INFO - 2020-08-23 22:11:09 --> Config Class Initialized
INFO - 2020-08-23 22:11:09 --> Loader Class Initialized
INFO - 2020-08-23 22:11:09 --> Helper loaded: url_helper
INFO - 2020-08-23 22:11:09 --> Helper loaded: form_helper
INFO - 2020-08-23 22:11:09 --> Helper loaded: file_helper
INFO - 2020-08-23 22:11:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:11:09 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:11:09 --> Upload Class Initialized
INFO - 2020-08-23 22:11:09 --> Controller Class Initialized
ERROR - 2020-08-23 22:11:09 --> 404 Page Not Found: /index
INFO - 2020-08-23 22:11:14 --> Config Class Initialized
INFO - 2020-08-23 22:11:14 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:11:14 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:11:14 --> Utf8 Class Initialized
INFO - 2020-08-23 22:11:14 --> URI Class Initialized
DEBUG - 2020-08-23 22:11:14 --> No URI present. Default controller set.
INFO - 2020-08-23 22:11:14 --> Router Class Initialized
INFO - 2020-08-23 22:11:14 --> Output Class Initialized
INFO - 2020-08-23 22:11:14 --> Security Class Initialized
DEBUG - 2020-08-23 22:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:11:14 --> Input Class Initialized
INFO - 2020-08-23 22:11:14 --> Language Class Initialized
INFO - 2020-08-23 22:11:14 --> Language Class Initialized
INFO - 2020-08-23 22:11:14 --> Config Class Initialized
INFO - 2020-08-23 22:11:14 --> Loader Class Initialized
INFO - 2020-08-23 22:11:14 --> Helper loaded: url_helper
INFO - 2020-08-23 22:11:14 --> Helper loaded: form_helper
INFO - 2020-08-23 22:11:14 --> Helper loaded: file_helper
INFO - 2020-08-23 22:11:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:11:14 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:11:14 --> Upload Class Initialized
INFO - 2020-08-23 22:11:14 --> Controller Class Initialized
DEBUG - 2020-08-23 22:11:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:11:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:11:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:11:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:11:14 --> Final output sent to browser
DEBUG - 2020-08-23 22:11:14 --> Total execution time: 0.0510
INFO - 2020-08-23 22:17:48 --> Config Class Initialized
INFO - 2020-08-23 22:17:48 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:17:48 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:17:48 --> Utf8 Class Initialized
INFO - 2020-08-23 22:17:48 --> URI Class Initialized
DEBUG - 2020-08-23 22:17:48 --> No URI present. Default controller set.
INFO - 2020-08-23 22:17:48 --> Router Class Initialized
INFO - 2020-08-23 22:17:48 --> Output Class Initialized
INFO - 2020-08-23 22:17:48 --> Security Class Initialized
DEBUG - 2020-08-23 22:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:17:48 --> Input Class Initialized
INFO - 2020-08-23 22:17:48 --> Language Class Initialized
INFO - 2020-08-23 22:17:48 --> Language Class Initialized
INFO - 2020-08-23 22:17:48 --> Config Class Initialized
INFO - 2020-08-23 22:17:48 --> Loader Class Initialized
INFO - 2020-08-23 22:17:48 --> Helper loaded: url_helper
INFO - 2020-08-23 22:17:48 --> Helper loaded: form_helper
INFO - 2020-08-23 22:17:48 --> Helper loaded: file_helper
INFO - 2020-08-23 22:17:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:17:48 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:17:48 --> Upload Class Initialized
INFO - 2020-08-23 22:17:48 --> Controller Class Initialized
DEBUG - 2020-08-23 22:17:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:17:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:17:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:17:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:17:48 --> Final output sent to browser
DEBUG - 2020-08-23 22:17:48 --> Total execution time: 0.0504
INFO - 2020-08-23 22:17:48 --> Config Class Initialized
INFO - 2020-08-23 22:17:48 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:17:48 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:17:48 --> Utf8 Class Initialized
INFO - 2020-08-23 22:17:48 --> URI Class Initialized
DEBUG - 2020-08-23 22:17:48 --> No URI present. Default controller set.
INFO - 2020-08-23 22:17:48 --> Router Class Initialized
INFO - 2020-08-23 22:17:48 --> Output Class Initialized
INFO - 2020-08-23 22:17:48 --> Security Class Initialized
DEBUG - 2020-08-23 22:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:17:48 --> Input Class Initialized
INFO - 2020-08-23 22:17:48 --> Language Class Initialized
INFO - 2020-08-23 22:17:48 --> Language Class Initialized
INFO - 2020-08-23 22:17:48 --> Config Class Initialized
INFO - 2020-08-23 22:17:48 --> Loader Class Initialized
INFO - 2020-08-23 22:17:48 --> Helper loaded: url_helper
INFO - 2020-08-23 22:17:48 --> Helper loaded: form_helper
INFO - 2020-08-23 22:17:48 --> Helper loaded: file_helper
INFO - 2020-08-23 22:17:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:17:48 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:17:48 --> Upload Class Initialized
INFO - 2020-08-23 22:17:48 --> Controller Class Initialized
DEBUG - 2020-08-23 22:17:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:17:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:17:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:17:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:17:48 --> Final output sent to browser
DEBUG - 2020-08-23 22:17:48 --> Total execution time: 0.0523
INFO - 2020-08-23 22:17:50 --> Config Class Initialized
INFO - 2020-08-23 22:17:50 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:17:50 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:17:50 --> Utf8 Class Initialized
INFO - 2020-08-23 22:17:50 --> URI Class Initialized
INFO - 2020-08-23 22:17:50 --> Router Class Initialized
INFO - 2020-08-23 22:17:50 --> Output Class Initialized
INFO - 2020-08-23 22:17:50 --> Security Class Initialized
DEBUG - 2020-08-23 22:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:17:50 --> Input Class Initialized
INFO - 2020-08-23 22:17:50 --> Language Class Initialized
INFO - 2020-08-23 22:17:50 --> Language Class Initialized
INFO - 2020-08-23 22:17:50 --> Config Class Initialized
INFO - 2020-08-23 22:17:50 --> Loader Class Initialized
INFO - 2020-08-23 22:17:50 --> Helper loaded: url_helper
INFO - 2020-08-23 22:17:50 --> Helper loaded: form_helper
INFO - 2020-08-23 22:17:50 --> Helper loaded: file_helper
INFO - 2020-08-23 22:17:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:17:50 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:17:50 --> Upload Class Initialized
INFO - 2020-08-23 22:17:50 --> Controller Class Initialized
ERROR - 2020-08-23 22:17:50 --> 404 Page Not Found: /index
INFO - 2020-08-23 22:18:55 --> Config Class Initialized
INFO - 2020-08-23 22:18:55 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:18:55 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:18:55 --> Utf8 Class Initialized
INFO - 2020-08-23 22:18:55 --> URI Class Initialized
DEBUG - 2020-08-23 22:18:55 --> No URI present. Default controller set.
INFO - 2020-08-23 22:18:55 --> Router Class Initialized
INFO - 2020-08-23 22:18:55 --> Output Class Initialized
INFO - 2020-08-23 22:18:55 --> Security Class Initialized
DEBUG - 2020-08-23 22:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:18:55 --> Input Class Initialized
INFO - 2020-08-23 22:18:55 --> Language Class Initialized
INFO - 2020-08-23 22:18:55 --> Language Class Initialized
INFO - 2020-08-23 22:18:55 --> Config Class Initialized
INFO - 2020-08-23 22:18:55 --> Loader Class Initialized
INFO - 2020-08-23 22:18:55 --> Helper loaded: url_helper
INFO - 2020-08-23 22:18:55 --> Helper loaded: form_helper
INFO - 2020-08-23 22:18:55 --> Helper loaded: file_helper
INFO - 2020-08-23 22:18:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:18:55 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:18:55 --> Upload Class Initialized
INFO - 2020-08-23 22:18:55 --> Controller Class Initialized
DEBUG - 2020-08-23 22:18:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:18:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:18:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:18:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:18:55 --> Final output sent to browser
DEBUG - 2020-08-23 22:18:55 --> Total execution time: 0.0492
INFO - 2020-08-23 22:43:55 --> Config Class Initialized
INFO - 2020-08-23 22:43:55 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:43:55 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:43:55 --> Utf8 Class Initialized
INFO - 2020-08-23 22:43:55 --> URI Class Initialized
DEBUG - 2020-08-23 22:43:55 --> No URI present. Default controller set.
INFO - 2020-08-23 22:43:55 --> Router Class Initialized
INFO - 2020-08-23 22:43:55 --> Output Class Initialized
INFO - 2020-08-23 22:43:55 --> Security Class Initialized
DEBUG - 2020-08-23 22:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:43:55 --> Input Class Initialized
INFO - 2020-08-23 22:43:55 --> Language Class Initialized
INFO - 2020-08-23 22:43:55 --> Language Class Initialized
INFO - 2020-08-23 22:43:55 --> Config Class Initialized
INFO - 2020-08-23 22:43:55 --> Loader Class Initialized
INFO - 2020-08-23 22:43:55 --> Helper loaded: url_helper
INFO - 2020-08-23 22:43:55 --> Helper loaded: form_helper
INFO - 2020-08-23 22:43:55 --> Helper loaded: file_helper
INFO - 2020-08-23 22:43:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:43:55 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:43:55 --> Upload Class Initialized
INFO - 2020-08-23 22:43:55 --> Controller Class Initialized
DEBUG - 2020-08-23 22:43:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:43:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:43:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:43:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:43:55 --> Final output sent to browser
DEBUG - 2020-08-23 22:43:55 --> Total execution time: 0.0517
INFO - 2020-08-23 22:44:56 --> Config Class Initialized
INFO - 2020-08-23 22:44:56 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:44:56 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:44:56 --> Utf8 Class Initialized
INFO - 2020-08-23 22:44:56 --> URI Class Initialized
DEBUG - 2020-08-23 22:44:56 --> No URI present. Default controller set.
INFO - 2020-08-23 22:44:56 --> Router Class Initialized
INFO - 2020-08-23 22:44:56 --> Output Class Initialized
INFO - 2020-08-23 22:44:56 --> Security Class Initialized
DEBUG - 2020-08-23 22:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:44:56 --> Input Class Initialized
INFO - 2020-08-23 22:44:56 --> Language Class Initialized
INFO - 2020-08-23 22:44:56 --> Language Class Initialized
INFO - 2020-08-23 22:44:56 --> Config Class Initialized
INFO - 2020-08-23 22:44:56 --> Loader Class Initialized
INFO - 2020-08-23 22:44:56 --> Helper loaded: url_helper
INFO - 2020-08-23 22:44:56 --> Helper loaded: form_helper
INFO - 2020-08-23 22:44:56 --> Helper loaded: file_helper
INFO - 2020-08-23 22:44:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:44:56 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:44:56 --> Upload Class Initialized
INFO - 2020-08-23 22:44:56 --> Controller Class Initialized
DEBUG - 2020-08-23 22:44:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:44:56 --> Final output sent to browser
DEBUG - 2020-08-23 22:44:56 --> Total execution time: 0.0516
INFO - 2020-08-23 22:48:10 --> Config Class Initialized
INFO - 2020-08-23 22:48:10 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:48:10 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:48:10 --> Utf8 Class Initialized
INFO - 2020-08-23 22:48:10 --> URI Class Initialized
INFO - 2020-08-23 22:48:10 --> Router Class Initialized
INFO - 2020-08-23 22:48:10 --> Output Class Initialized
INFO - 2020-08-23 22:48:10 --> Security Class Initialized
DEBUG - 2020-08-23 22:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:48:10 --> Input Class Initialized
INFO - 2020-08-23 22:48:10 --> Language Class Initialized
INFO - 2020-08-23 22:48:10 --> Language Class Initialized
INFO - 2020-08-23 22:48:10 --> Config Class Initialized
INFO - 2020-08-23 22:48:10 --> Loader Class Initialized
INFO - 2020-08-23 22:48:10 --> Helper loaded: url_helper
INFO - 2020-08-23 22:48:10 --> Helper loaded: form_helper
INFO - 2020-08-23 22:48:10 --> Helper loaded: file_helper
INFO - 2020-08-23 22:48:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:48:11 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:48:11 --> Upload Class Initialized
INFO - 2020-08-23 22:48:11 --> Controller Class Initialized
ERROR - 2020-08-23 22:48:11 --> 404 Page Not Found: /index
INFO - 2020-08-23 22:48:11 --> Config Class Initialized
INFO - 2020-08-23 22:48:11 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:48:11 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:48:11 --> Utf8 Class Initialized
INFO - 2020-08-23 22:48:11 --> URI Class Initialized
INFO - 2020-08-23 22:48:11 --> Router Class Initialized
INFO - 2020-08-23 22:48:11 --> Output Class Initialized
INFO - 2020-08-23 22:48:11 --> Security Class Initialized
DEBUG - 2020-08-23 22:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:48:11 --> Input Class Initialized
INFO - 2020-08-23 22:48:11 --> Language Class Initialized
INFO - 2020-08-23 22:48:11 --> Language Class Initialized
INFO - 2020-08-23 22:48:11 --> Config Class Initialized
INFO - 2020-08-23 22:48:11 --> Loader Class Initialized
INFO - 2020-08-23 22:48:11 --> Helper loaded: url_helper
INFO - 2020-08-23 22:48:11 --> Helper loaded: form_helper
INFO - 2020-08-23 22:48:11 --> Helper loaded: file_helper
INFO - 2020-08-23 22:48:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:48:11 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:48:11 --> Upload Class Initialized
INFO - 2020-08-23 22:48:11 --> Controller Class Initialized
ERROR - 2020-08-23 22:48:11 --> 404 Page Not Found: /index
INFO - 2020-08-23 22:59:49 --> Config Class Initialized
INFO - 2020-08-23 22:59:49 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:59:49 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:59:49 --> Utf8 Class Initialized
INFO - 2020-08-23 22:59:49 --> URI Class Initialized
DEBUG - 2020-08-23 22:59:49 --> No URI present. Default controller set.
INFO - 2020-08-23 22:59:49 --> Router Class Initialized
INFO - 2020-08-23 22:59:49 --> Output Class Initialized
INFO - 2020-08-23 22:59:49 --> Security Class Initialized
DEBUG - 2020-08-23 22:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:59:49 --> Input Class Initialized
INFO - 2020-08-23 22:59:49 --> Language Class Initialized
INFO - 2020-08-23 22:59:49 --> Language Class Initialized
INFO - 2020-08-23 22:59:49 --> Config Class Initialized
INFO - 2020-08-23 22:59:49 --> Loader Class Initialized
INFO - 2020-08-23 22:59:49 --> Helper loaded: url_helper
INFO - 2020-08-23 22:59:49 --> Helper loaded: form_helper
INFO - 2020-08-23 22:59:49 --> Helper loaded: file_helper
INFO - 2020-08-23 22:59:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:59:49 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:59:49 --> Upload Class Initialized
INFO - 2020-08-23 22:59:49 --> Controller Class Initialized
DEBUG - 2020-08-23 22:59:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 22:59:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 22:59:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 22:59:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 22:59:49 --> Final output sent to browser
DEBUG - 2020-08-23 22:59:49 --> Total execution time: 0.0522
INFO - 2020-08-23 22:59:50 --> Config Class Initialized
INFO - 2020-08-23 22:59:50 --> Hooks Class Initialized
DEBUG - 2020-08-23 22:59:50 --> UTF-8 Support Enabled
INFO - 2020-08-23 22:59:50 --> Utf8 Class Initialized
INFO - 2020-08-23 22:59:50 --> URI Class Initialized
INFO - 2020-08-23 22:59:50 --> Router Class Initialized
INFO - 2020-08-23 22:59:50 --> Output Class Initialized
INFO - 2020-08-23 22:59:50 --> Security Class Initialized
DEBUG - 2020-08-23 22:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 22:59:50 --> Input Class Initialized
INFO - 2020-08-23 22:59:50 --> Language Class Initialized
INFO - 2020-08-23 22:59:50 --> Language Class Initialized
INFO - 2020-08-23 22:59:50 --> Config Class Initialized
INFO - 2020-08-23 22:59:50 --> Loader Class Initialized
INFO - 2020-08-23 22:59:50 --> Helper loaded: url_helper
INFO - 2020-08-23 22:59:50 --> Helper loaded: form_helper
INFO - 2020-08-23 22:59:50 --> Helper loaded: file_helper
INFO - 2020-08-23 22:59:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 22:59:50 --> Database Driver Class Initialized
DEBUG - 2020-08-23 22:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 22:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 22:59:50 --> Upload Class Initialized
INFO - 2020-08-23 22:59:50 --> Controller Class Initialized
ERROR - 2020-08-23 22:59:50 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:17:24 --> Config Class Initialized
INFO - 2020-08-23 23:17:24 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:17:24 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:17:24 --> Utf8 Class Initialized
INFO - 2020-08-23 23:17:24 --> URI Class Initialized
DEBUG - 2020-08-23 23:17:24 --> No URI present. Default controller set.
INFO - 2020-08-23 23:17:24 --> Router Class Initialized
INFO - 2020-08-23 23:17:24 --> Output Class Initialized
INFO - 2020-08-23 23:17:24 --> Security Class Initialized
DEBUG - 2020-08-23 23:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:17:24 --> Input Class Initialized
INFO - 2020-08-23 23:17:24 --> Language Class Initialized
INFO - 2020-08-23 23:17:24 --> Language Class Initialized
INFO - 2020-08-23 23:17:24 --> Config Class Initialized
INFO - 2020-08-23 23:17:24 --> Loader Class Initialized
INFO - 2020-08-23 23:17:24 --> Helper loaded: url_helper
INFO - 2020-08-23 23:17:24 --> Helper loaded: form_helper
INFO - 2020-08-23 23:17:24 --> Helper loaded: file_helper
INFO - 2020-08-23 23:17:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:17:24 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:17:24 --> Upload Class Initialized
INFO - 2020-08-23 23:17:24 --> Controller Class Initialized
DEBUG - 2020-08-23 23:17:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 23:17:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 23:17:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 23:17:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 23:17:24 --> Final output sent to browser
DEBUG - 2020-08-23 23:17:24 --> Total execution time: 0.0542
INFO - 2020-08-23 23:20:15 --> Config Class Initialized
INFO - 2020-08-23 23:20:15 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:20:15 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:20:15 --> Utf8 Class Initialized
INFO - 2020-08-23 23:20:15 --> URI Class Initialized
DEBUG - 2020-08-23 23:20:15 --> No URI present. Default controller set.
INFO - 2020-08-23 23:20:15 --> Router Class Initialized
INFO - 2020-08-23 23:20:15 --> Output Class Initialized
INFO - 2020-08-23 23:20:15 --> Security Class Initialized
DEBUG - 2020-08-23 23:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:20:15 --> Input Class Initialized
INFO - 2020-08-23 23:20:15 --> Language Class Initialized
INFO - 2020-08-23 23:20:15 --> Language Class Initialized
INFO - 2020-08-23 23:20:15 --> Config Class Initialized
INFO - 2020-08-23 23:20:15 --> Loader Class Initialized
INFO - 2020-08-23 23:20:15 --> Helper loaded: url_helper
INFO - 2020-08-23 23:20:15 --> Helper loaded: form_helper
INFO - 2020-08-23 23:20:15 --> Helper loaded: file_helper
INFO - 2020-08-23 23:20:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:20:15 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:20:15 --> Upload Class Initialized
INFO - 2020-08-23 23:20:15 --> Controller Class Initialized
DEBUG - 2020-08-23 23:20:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 23:20:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-23 23:20:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-23 23:20:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 23:20:15 --> Final output sent to browser
DEBUG - 2020-08-23 23:20:15 --> Total execution time: 0.0497
INFO - 2020-08-23 23:20:16 --> Config Class Initialized
INFO - 2020-08-23 23:20:16 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:20:16 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:20:16 --> Utf8 Class Initialized
INFO - 2020-08-23 23:20:16 --> URI Class Initialized
INFO - 2020-08-23 23:20:16 --> Router Class Initialized
INFO - 2020-08-23 23:20:16 --> Output Class Initialized
INFO - 2020-08-23 23:20:16 --> Security Class Initialized
DEBUG - 2020-08-23 23:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:20:16 --> Input Class Initialized
INFO - 2020-08-23 23:20:16 --> Language Class Initialized
INFO - 2020-08-23 23:20:16 --> Language Class Initialized
INFO - 2020-08-23 23:20:16 --> Config Class Initialized
INFO - 2020-08-23 23:20:16 --> Loader Class Initialized
INFO - 2020-08-23 23:20:16 --> Helper loaded: url_helper
INFO - 2020-08-23 23:20:16 --> Helper loaded: form_helper
INFO - 2020-08-23 23:20:16 --> Helper loaded: file_helper
INFO - 2020-08-23 23:20:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:20:16 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:20:16 --> Upload Class Initialized
INFO - 2020-08-23 23:20:16 --> Controller Class Initialized
ERROR - 2020-08-23 23:20:16 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:24:00 --> Config Class Initialized
INFO - 2020-08-23 23:24:00 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:24:00 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:24:00 --> Utf8 Class Initialized
INFO - 2020-08-23 23:24:00 --> URI Class Initialized
INFO - 2020-08-23 23:24:00 --> Router Class Initialized
INFO - 2020-08-23 23:24:00 --> Output Class Initialized
INFO - 2020-08-23 23:24:00 --> Security Class Initialized
DEBUG - 2020-08-23 23:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:24:00 --> Input Class Initialized
INFO - 2020-08-23 23:24:00 --> Language Class Initialized
INFO - 2020-08-23 23:24:00 --> Language Class Initialized
INFO - 2020-08-23 23:24:00 --> Config Class Initialized
INFO - 2020-08-23 23:24:00 --> Loader Class Initialized
INFO - 2020-08-23 23:24:00 --> Helper loaded: url_helper
INFO - 2020-08-23 23:24:00 --> Helper loaded: form_helper
INFO - 2020-08-23 23:24:00 --> Helper loaded: file_helper
INFO - 2020-08-23 23:24:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:24:00 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:24:00 --> Upload Class Initialized
INFO - 2020-08-23 23:24:00 --> Controller Class Initialized
ERROR - 2020-08-23 23:24:00 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:24:00 --> Config Class Initialized
INFO - 2020-08-23 23:24:00 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:24:00 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:24:00 --> Utf8 Class Initialized
INFO - 2020-08-23 23:24:00 --> URI Class Initialized
INFO - 2020-08-23 23:24:00 --> Router Class Initialized
INFO - 2020-08-23 23:24:00 --> Output Class Initialized
INFO - 2020-08-23 23:24:00 --> Security Class Initialized
DEBUG - 2020-08-23 23:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:24:00 --> Input Class Initialized
INFO - 2020-08-23 23:24:00 --> Language Class Initialized
INFO - 2020-08-23 23:24:00 --> Language Class Initialized
INFO - 2020-08-23 23:24:00 --> Config Class Initialized
INFO - 2020-08-23 23:24:00 --> Loader Class Initialized
INFO - 2020-08-23 23:24:00 --> Helper loaded: url_helper
INFO - 2020-08-23 23:24:00 --> Helper loaded: form_helper
INFO - 2020-08-23 23:24:00 --> Helper loaded: file_helper
INFO - 2020-08-23 23:24:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:24:00 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:24:00 --> Upload Class Initialized
INFO - 2020-08-23 23:24:00 --> Controller Class Initialized
DEBUG - 2020-08-23 23:24:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-23 23:24:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-23 23:24:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-23 23:24:00 --> Final output sent to browser
DEBUG - 2020-08-23 23:24:00 --> Total execution time: 0.0492
INFO - 2020-08-23 23:55:45 --> Config Class Initialized
INFO - 2020-08-23 23:55:45 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:55:45 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:55:45 --> Utf8 Class Initialized
INFO - 2020-08-23 23:55:45 --> URI Class Initialized
INFO - 2020-08-23 23:55:45 --> Router Class Initialized
INFO - 2020-08-23 23:55:45 --> Output Class Initialized
INFO - 2020-08-23 23:55:45 --> Security Class Initialized
DEBUG - 2020-08-23 23:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:55:45 --> Input Class Initialized
INFO - 2020-08-23 23:55:45 --> Language Class Initialized
INFO - 2020-08-23 23:55:45 --> Language Class Initialized
INFO - 2020-08-23 23:55:45 --> Config Class Initialized
INFO - 2020-08-23 23:55:45 --> Loader Class Initialized
INFO - 2020-08-23 23:55:45 --> Helper loaded: url_helper
INFO - 2020-08-23 23:55:45 --> Helper loaded: form_helper
INFO - 2020-08-23 23:55:45 --> Helper loaded: file_helper
INFO - 2020-08-23 23:55:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:55:45 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:55:45 --> Upload Class Initialized
INFO - 2020-08-23 23:55:45 --> Controller Class Initialized
ERROR - 2020-08-23 23:55:45 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:55:45 --> Config Class Initialized
INFO - 2020-08-23 23:55:45 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:55:45 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:55:45 --> Utf8 Class Initialized
INFO - 2020-08-23 23:55:45 --> URI Class Initialized
INFO - 2020-08-23 23:55:45 --> Router Class Initialized
INFO - 2020-08-23 23:55:45 --> Output Class Initialized
INFO - 2020-08-23 23:55:45 --> Security Class Initialized
DEBUG - 2020-08-23 23:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:55:45 --> Input Class Initialized
INFO - 2020-08-23 23:55:45 --> Language Class Initialized
INFO - 2020-08-23 23:55:45 --> Language Class Initialized
INFO - 2020-08-23 23:55:45 --> Config Class Initialized
INFO - 2020-08-23 23:55:45 --> Loader Class Initialized
INFO - 2020-08-23 23:55:45 --> Helper loaded: url_helper
INFO - 2020-08-23 23:55:45 --> Helper loaded: form_helper
INFO - 2020-08-23 23:55:45 --> Helper loaded: file_helper
INFO - 2020-08-23 23:55:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:55:45 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:55:45 --> Upload Class Initialized
INFO - 2020-08-23 23:55:45 --> Controller Class Initialized
ERROR - 2020-08-23 23:55:45 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:55:46 --> Config Class Initialized
INFO - 2020-08-23 23:55:46 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:55:46 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:55:46 --> Utf8 Class Initialized
INFO - 2020-08-23 23:55:46 --> URI Class Initialized
INFO - 2020-08-23 23:55:46 --> Router Class Initialized
INFO - 2020-08-23 23:55:46 --> Output Class Initialized
INFO - 2020-08-23 23:55:46 --> Security Class Initialized
DEBUG - 2020-08-23 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:55:46 --> Input Class Initialized
INFO - 2020-08-23 23:55:46 --> Language Class Initialized
INFO - 2020-08-23 23:55:46 --> Language Class Initialized
INFO - 2020-08-23 23:55:46 --> Config Class Initialized
INFO - 2020-08-23 23:55:46 --> Loader Class Initialized
INFO - 2020-08-23 23:55:46 --> Helper loaded: url_helper
INFO - 2020-08-23 23:55:46 --> Helper loaded: form_helper
INFO - 2020-08-23 23:55:46 --> Helper loaded: file_helper
INFO - 2020-08-23 23:55:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:55:46 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:55:46 --> Upload Class Initialized
INFO - 2020-08-23 23:55:46 --> Controller Class Initialized
ERROR - 2020-08-23 23:55:46 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:55:46 --> Config Class Initialized
INFO - 2020-08-23 23:55:46 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:55:46 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:55:46 --> Utf8 Class Initialized
INFO - 2020-08-23 23:55:46 --> URI Class Initialized
INFO - 2020-08-23 23:55:46 --> Router Class Initialized
INFO - 2020-08-23 23:55:46 --> Output Class Initialized
INFO - 2020-08-23 23:55:46 --> Security Class Initialized
DEBUG - 2020-08-23 23:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:55:46 --> Input Class Initialized
INFO - 2020-08-23 23:55:46 --> Language Class Initialized
INFO - 2020-08-23 23:55:46 --> Language Class Initialized
INFO - 2020-08-23 23:55:46 --> Config Class Initialized
INFO - 2020-08-23 23:55:46 --> Loader Class Initialized
INFO - 2020-08-23 23:55:46 --> Helper loaded: url_helper
INFO - 2020-08-23 23:55:46 --> Helper loaded: form_helper
INFO - 2020-08-23 23:55:46 --> Helper loaded: file_helper
INFO - 2020-08-23 23:55:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:55:46 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:55:46 --> Upload Class Initialized
INFO - 2020-08-23 23:55:46 --> Controller Class Initialized
ERROR - 2020-08-23 23:55:46 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:55:47 --> Config Class Initialized
INFO - 2020-08-23 23:55:47 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:55:47 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:55:47 --> Utf8 Class Initialized
INFO - 2020-08-23 23:55:47 --> URI Class Initialized
INFO - 2020-08-23 23:55:47 --> Router Class Initialized
INFO - 2020-08-23 23:55:47 --> Output Class Initialized
INFO - 2020-08-23 23:55:47 --> Security Class Initialized
DEBUG - 2020-08-23 23:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:55:47 --> Input Class Initialized
INFO - 2020-08-23 23:55:47 --> Language Class Initialized
INFO - 2020-08-23 23:55:47 --> Language Class Initialized
INFO - 2020-08-23 23:55:47 --> Config Class Initialized
INFO - 2020-08-23 23:55:47 --> Loader Class Initialized
INFO - 2020-08-23 23:55:47 --> Helper loaded: url_helper
INFO - 2020-08-23 23:55:47 --> Helper loaded: form_helper
INFO - 2020-08-23 23:55:47 --> Helper loaded: file_helper
INFO - 2020-08-23 23:55:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:55:47 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:55:47 --> Upload Class Initialized
INFO - 2020-08-23 23:55:47 --> Controller Class Initialized
ERROR - 2020-08-23 23:55:47 --> 404 Page Not Found: /index
INFO - 2020-08-23 23:55:47 --> Config Class Initialized
INFO - 2020-08-23 23:55:47 --> Hooks Class Initialized
DEBUG - 2020-08-23 23:55:47 --> UTF-8 Support Enabled
INFO - 2020-08-23 23:55:47 --> Utf8 Class Initialized
INFO - 2020-08-23 23:55:47 --> URI Class Initialized
INFO - 2020-08-23 23:55:47 --> Router Class Initialized
INFO - 2020-08-23 23:55:47 --> Output Class Initialized
INFO - 2020-08-23 23:55:47 --> Security Class Initialized
DEBUG - 2020-08-23 23:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-23 23:55:47 --> Input Class Initialized
INFO - 2020-08-23 23:55:47 --> Language Class Initialized
INFO - 2020-08-23 23:55:47 --> Language Class Initialized
INFO - 2020-08-23 23:55:47 --> Config Class Initialized
INFO - 2020-08-23 23:55:47 --> Loader Class Initialized
INFO - 2020-08-23 23:55:47 --> Helper loaded: url_helper
INFO - 2020-08-23 23:55:47 --> Helper loaded: form_helper
INFO - 2020-08-23 23:55:47 --> Helper loaded: file_helper
INFO - 2020-08-23 23:55:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-23 23:55:47 --> Database Driver Class Initialized
DEBUG - 2020-08-23 23:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-23 23:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-23 23:55:47 --> Upload Class Initialized
INFO - 2020-08-23 23:55:47 --> Controller Class Initialized
ERROR - 2020-08-23 23:55:47 --> 404 Page Not Found: /index
