<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-24 00:29:35 --> Config Class Initialized
INFO - 2020-08-24 00:29:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 00:29:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 00:29:35 --> Utf8 Class Initialized
INFO - 2020-08-24 00:29:35 --> URI Class Initialized
DEBUG - 2020-08-24 00:29:35 --> No URI present. Default controller set.
INFO - 2020-08-24 00:29:35 --> Router Class Initialized
INFO - 2020-08-24 00:29:35 --> Output Class Initialized
INFO - 2020-08-24 00:29:35 --> Security Class Initialized
DEBUG - 2020-08-24 00:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 00:29:35 --> Input Class Initialized
INFO - 2020-08-24 00:29:35 --> Language Class Initialized
INFO - 2020-08-24 00:29:35 --> Language Class Initialized
INFO - 2020-08-24 00:29:35 --> Config Class Initialized
INFO - 2020-08-24 00:29:35 --> Loader Class Initialized
INFO - 2020-08-24 00:29:35 --> Helper loaded: url_helper
INFO - 2020-08-24 00:29:35 --> Helper loaded: form_helper
INFO - 2020-08-24 00:29:35 --> Helper loaded: file_helper
INFO - 2020-08-24 00:29:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 00:29:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 00:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 00:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 00:29:35 --> Upload Class Initialized
INFO - 2020-08-24 00:29:35 --> Controller Class Initialized
DEBUG - 2020-08-24 00:29:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 00:29:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 00:29:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 00:29:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 00:29:35 --> Final output sent to browser
DEBUG - 2020-08-24 00:29:35 --> Total execution time: 0.0518
INFO - 2020-08-24 00:29:38 --> Config Class Initialized
INFO - 2020-08-24 00:29:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 00:29:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 00:29:38 --> Utf8 Class Initialized
INFO - 2020-08-24 00:29:38 --> URI Class Initialized
DEBUG - 2020-08-24 00:29:38 --> No URI present. Default controller set.
INFO - 2020-08-24 00:29:38 --> Router Class Initialized
INFO - 2020-08-24 00:29:38 --> Output Class Initialized
INFO - 2020-08-24 00:29:38 --> Security Class Initialized
DEBUG - 2020-08-24 00:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 00:29:38 --> Input Class Initialized
INFO - 2020-08-24 00:29:38 --> Language Class Initialized
INFO - 2020-08-24 00:29:38 --> Language Class Initialized
INFO - 2020-08-24 00:29:38 --> Config Class Initialized
INFO - 2020-08-24 00:29:38 --> Loader Class Initialized
INFO - 2020-08-24 00:29:38 --> Helper loaded: url_helper
INFO - 2020-08-24 00:29:38 --> Helper loaded: form_helper
INFO - 2020-08-24 00:29:38 --> Helper loaded: file_helper
INFO - 2020-08-24 00:29:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 00:29:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 00:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 00:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 00:29:38 --> Upload Class Initialized
INFO - 2020-08-24 00:29:38 --> Controller Class Initialized
DEBUG - 2020-08-24 00:29:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 00:29:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 00:29:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 00:29:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 00:29:38 --> Final output sent to browser
DEBUG - 2020-08-24 00:29:38 --> Total execution time: 0.0498
INFO - 2020-08-24 00:35:30 --> Config Class Initialized
INFO - 2020-08-24 00:35:30 --> Hooks Class Initialized
DEBUG - 2020-08-24 00:35:30 --> UTF-8 Support Enabled
INFO - 2020-08-24 00:35:30 --> Utf8 Class Initialized
INFO - 2020-08-24 00:35:30 --> URI Class Initialized
DEBUG - 2020-08-24 00:35:30 --> No URI present. Default controller set.
INFO - 2020-08-24 00:35:30 --> Router Class Initialized
INFO - 2020-08-24 00:35:30 --> Output Class Initialized
INFO - 2020-08-24 00:35:30 --> Security Class Initialized
DEBUG - 2020-08-24 00:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 00:35:30 --> Input Class Initialized
INFO - 2020-08-24 00:35:30 --> Language Class Initialized
INFO - 2020-08-24 00:35:30 --> Language Class Initialized
INFO - 2020-08-24 00:35:30 --> Config Class Initialized
INFO - 2020-08-24 00:35:30 --> Loader Class Initialized
INFO - 2020-08-24 00:35:30 --> Helper loaded: url_helper
INFO - 2020-08-24 00:35:30 --> Helper loaded: form_helper
INFO - 2020-08-24 00:35:30 --> Helper loaded: file_helper
INFO - 2020-08-24 00:35:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 00:35:30 --> Database Driver Class Initialized
DEBUG - 2020-08-24 00:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 00:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 00:35:30 --> Upload Class Initialized
INFO - 2020-08-24 00:35:30 --> Controller Class Initialized
DEBUG - 2020-08-24 00:35:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 00:35:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 00:35:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 00:35:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 00:35:30 --> Final output sent to browser
DEBUG - 2020-08-24 00:35:30 --> Total execution time: 0.0554
INFO - 2020-08-24 00:35:40 --> Config Class Initialized
INFO - 2020-08-24 00:35:40 --> Hooks Class Initialized
DEBUG - 2020-08-24 00:35:40 --> UTF-8 Support Enabled
INFO - 2020-08-24 00:35:40 --> Utf8 Class Initialized
INFO - 2020-08-24 00:35:40 --> URI Class Initialized
INFO - 2020-08-24 00:35:40 --> Router Class Initialized
INFO - 2020-08-24 00:35:40 --> Output Class Initialized
INFO - 2020-08-24 00:35:40 --> Security Class Initialized
DEBUG - 2020-08-24 00:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 00:35:40 --> Input Class Initialized
INFO - 2020-08-24 00:35:40 --> Language Class Initialized
INFO - 2020-08-24 00:35:40 --> Language Class Initialized
INFO - 2020-08-24 00:35:40 --> Config Class Initialized
INFO - 2020-08-24 00:35:40 --> Loader Class Initialized
INFO - 2020-08-24 00:35:40 --> Helper loaded: url_helper
INFO - 2020-08-24 00:35:40 --> Helper loaded: form_helper
INFO - 2020-08-24 00:35:40 --> Helper loaded: file_helper
INFO - 2020-08-24 00:35:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 00:35:40 --> Database Driver Class Initialized
DEBUG - 2020-08-24 00:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 00:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 00:35:40 --> Upload Class Initialized
INFO - 2020-08-24 00:35:41 --> Controller Class Initialized
ERROR - 2020-08-24 00:35:41 --> 404 Page Not Found: /index
INFO - 2020-08-24 02:33:36 --> Config Class Initialized
INFO - 2020-08-24 02:33:36 --> Hooks Class Initialized
DEBUG - 2020-08-24 02:33:36 --> UTF-8 Support Enabled
INFO - 2020-08-24 02:33:36 --> Utf8 Class Initialized
INFO - 2020-08-24 02:33:36 --> URI Class Initialized
DEBUG - 2020-08-24 02:33:36 --> No URI present. Default controller set.
INFO - 2020-08-24 02:33:36 --> Router Class Initialized
INFO - 2020-08-24 02:33:36 --> Output Class Initialized
INFO - 2020-08-24 02:33:36 --> Security Class Initialized
DEBUG - 2020-08-24 02:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 02:33:36 --> Input Class Initialized
INFO - 2020-08-24 02:33:36 --> Language Class Initialized
INFO - 2020-08-24 02:33:36 --> Language Class Initialized
INFO - 2020-08-24 02:33:36 --> Config Class Initialized
INFO - 2020-08-24 02:33:36 --> Loader Class Initialized
INFO - 2020-08-24 02:33:36 --> Helper loaded: url_helper
INFO - 2020-08-24 02:33:36 --> Helper loaded: form_helper
INFO - 2020-08-24 02:33:36 --> Helper loaded: file_helper
INFO - 2020-08-24 02:33:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 02:33:36 --> Database Driver Class Initialized
DEBUG - 2020-08-24 02:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 02:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 02:33:36 --> Upload Class Initialized
INFO - 2020-08-24 02:33:36 --> Controller Class Initialized
DEBUG - 2020-08-24 02:33:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 02:33:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 02:33:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 02:33:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 02:33:36 --> Final output sent to browser
DEBUG - 2020-08-24 02:33:36 --> Total execution time: 0.0558
INFO - 2020-08-24 04:07:47 --> Config Class Initialized
INFO - 2020-08-24 04:07:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 04:07:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 04:07:47 --> Utf8 Class Initialized
INFO - 2020-08-24 04:07:47 --> URI Class Initialized
INFO - 2020-08-24 04:07:47 --> Router Class Initialized
INFO - 2020-08-24 04:07:47 --> Output Class Initialized
INFO - 2020-08-24 04:07:47 --> Security Class Initialized
DEBUG - 2020-08-24 04:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 04:07:47 --> Input Class Initialized
INFO - 2020-08-24 04:07:47 --> Language Class Initialized
INFO - 2020-08-24 04:07:47 --> Language Class Initialized
INFO - 2020-08-24 04:07:47 --> Config Class Initialized
INFO - 2020-08-24 04:07:47 --> Loader Class Initialized
INFO - 2020-08-24 04:07:47 --> Helper loaded: url_helper
INFO - 2020-08-24 04:07:47 --> Helper loaded: form_helper
INFO - 2020-08-24 04:07:47 --> Helper loaded: file_helper
INFO - 2020-08-24 04:07:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 04:07:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 04:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 04:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 04:07:47 --> Upload Class Initialized
INFO - 2020-08-24 04:07:47 --> Controller Class Initialized
ERROR - 2020-08-24 04:07:47 --> 404 Page Not Found: /index
INFO - 2020-08-24 04:07:48 --> Config Class Initialized
INFO - 2020-08-24 04:07:48 --> Hooks Class Initialized
DEBUG - 2020-08-24 04:07:48 --> UTF-8 Support Enabled
INFO - 2020-08-24 04:07:48 --> Utf8 Class Initialized
INFO - 2020-08-24 04:07:48 --> URI Class Initialized
INFO - 2020-08-24 04:07:48 --> Router Class Initialized
INFO - 2020-08-24 04:07:48 --> Output Class Initialized
INFO - 2020-08-24 04:07:48 --> Security Class Initialized
DEBUG - 2020-08-24 04:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 04:07:48 --> Input Class Initialized
INFO - 2020-08-24 04:07:48 --> Language Class Initialized
INFO - 2020-08-24 04:07:48 --> Language Class Initialized
INFO - 2020-08-24 04:07:48 --> Config Class Initialized
INFO - 2020-08-24 04:07:48 --> Loader Class Initialized
INFO - 2020-08-24 04:07:48 --> Helper loaded: url_helper
INFO - 2020-08-24 04:07:48 --> Helper loaded: form_helper
INFO - 2020-08-24 04:07:48 --> Helper loaded: file_helper
INFO - 2020-08-24 04:07:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 04:07:48 --> Database Driver Class Initialized
DEBUG - 2020-08-24 04:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 04:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 04:07:48 --> Upload Class Initialized
INFO - 2020-08-24 04:07:48 --> Controller Class Initialized
DEBUG - 2020-08-24 04:07:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 04:07:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 04:07:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 04:07:48 --> Final output sent to browser
DEBUG - 2020-08-24 04:07:48 --> Total execution time: 0.0545
INFO - 2020-08-24 07:11:59 --> Config Class Initialized
INFO - 2020-08-24 07:11:59 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:11:59 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:11:59 --> Utf8 Class Initialized
INFO - 2020-08-24 07:11:59 --> URI Class Initialized
DEBUG - 2020-08-24 07:11:59 --> No URI present. Default controller set.
INFO - 2020-08-24 07:11:59 --> Router Class Initialized
INFO - 2020-08-24 07:11:59 --> Output Class Initialized
INFO - 2020-08-24 07:11:59 --> Security Class Initialized
DEBUG - 2020-08-24 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:11:59 --> Input Class Initialized
INFO - 2020-08-24 07:11:59 --> Language Class Initialized
INFO - 2020-08-24 07:11:59 --> Language Class Initialized
INFO - 2020-08-24 07:11:59 --> Config Class Initialized
INFO - 2020-08-24 07:11:59 --> Loader Class Initialized
INFO - 2020-08-24 07:11:59 --> Helper loaded: url_helper
INFO - 2020-08-24 07:11:59 --> Helper loaded: form_helper
INFO - 2020-08-24 07:11:59 --> Helper loaded: file_helper
INFO - 2020-08-24 07:11:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:11:59 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:11:59 --> Upload Class Initialized
INFO - 2020-08-24 07:11:59 --> Controller Class Initialized
DEBUG - 2020-08-24 07:11:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 07:11:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 07:11:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 07:11:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 07:11:59 --> Final output sent to browser
DEBUG - 2020-08-24 07:11:59 --> Total execution time: 0.0516
INFO - 2020-08-24 07:12:00 --> Config Class Initialized
INFO - 2020-08-24 07:12:00 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:12:00 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:12:00 --> Utf8 Class Initialized
INFO - 2020-08-24 07:12:00 --> URI Class Initialized
INFO - 2020-08-24 07:12:00 --> Router Class Initialized
INFO - 2020-08-24 07:12:00 --> Output Class Initialized
INFO - 2020-08-24 07:12:00 --> Security Class Initialized
DEBUG - 2020-08-24 07:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:12:00 --> Input Class Initialized
INFO - 2020-08-24 07:12:00 --> Language Class Initialized
INFO - 2020-08-24 07:12:00 --> Language Class Initialized
INFO - 2020-08-24 07:12:00 --> Config Class Initialized
INFO - 2020-08-24 07:12:00 --> Loader Class Initialized
INFO - 2020-08-24 07:12:00 --> Helper loaded: url_helper
INFO - 2020-08-24 07:12:00 --> Helper loaded: form_helper
INFO - 2020-08-24 07:12:00 --> Helper loaded: file_helper
INFO - 2020-08-24 07:12:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:12:00 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:12:00 --> Upload Class Initialized
INFO - 2020-08-24 07:12:00 --> Controller Class Initialized
ERROR - 2020-08-24 07:12:00 --> 404 Page Not Found: /index
INFO - 2020-08-24 07:56:25 --> Config Class Initialized
INFO - 2020-08-24 07:56:25 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:56:25 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:56:25 --> Utf8 Class Initialized
INFO - 2020-08-24 07:56:25 --> URI Class Initialized
DEBUG - 2020-08-24 07:56:25 --> No URI present. Default controller set.
INFO - 2020-08-24 07:56:25 --> Router Class Initialized
INFO - 2020-08-24 07:56:25 --> Output Class Initialized
INFO - 2020-08-24 07:56:25 --> Security Class Initialized
DEBUG - 2020-08-24 07:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:56:25 --> Input Class Initialized
INFO - 2020-08-24 07:56:25 --> Language Class Initialized
INFO - 2020-08-24 07:56:25 --> Language Class Initialized
INFO - 2020-08-24 07:56:25 --> Config Class Initialized
INFO - 2020-08-24 07:56:25 --> Loader Class Initialized
INFO - 2020-08-24 07:56:25 --> Helper loaded: url_helper
INFO - 2020-08-24 07:56:25 --> Helper loaded: form_helper
INFO - 2020-08-24 07:56:25 --> Helper loaded: file_helper
INFO - 2020-08-24 07:56:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:56:25 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:56:25 --> Upload Class Initialized
INFO - 2020-08-24 07:56:25 --> Controller Class Initialized
DEBUG - 2020-08-24 07:56:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 07:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 07:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 07:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 07:56:25 --> Final output sent to browser
DEBUG - 2020-08-24 07:56:25 --> Total execution time: 0.0607
INFO - 2020-08-24 07:56:26 --> Config Class Initialized
INFO - 2020-08-24 07:56:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:56:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:56:26 --> Utf8 Class Initialized
INFO - 2020-08-24 07:56:26 --> URI Class Initialized
INFO - 2020-08-24 07:56:26 --> Router Class Initialized
INFO - 2020-08-24 07:56:26 --> Output Class Initialized
INFO - 2020-08-24 07:56:26 --> Security Class Initialized
DEBUG - 2020-08-24 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:56:26 --> Input Class Initialized
INFO - 2020-08-24 07:56:26 --> Language Class Initialized
INFO - 2020-08-24 07:56:26 --> Language Class Initialized
INFO - 2020-08-24 07:56:26 --> Config Class Initialized
INFO - 2020-08-24 07:56:26 --> Loader Class Initialized
INFO - 2020-08-24 07:56:26 --> Helper loaded: url_helper
INFO - 2020-08-24 07:56:26 --> Helper loaded: form_helper
INFO - 2020-08-24 07:56:26 --> Helper loaded: file_helper
INFO - 2020-08-24 07:56:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:56:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:56:26 --> Upload Class Initialized
INFO - 2020-08-24 07:56:26 --> Controller Class Initialized
ERROR - 2020-08-24 07:56:26 --> 404 Page Not Found: /index
INFO - 2020-08-24 07:57:14 --> Config Class Initialized
INFO - 2020-08-24 07:57:14 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:57:14 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:57:14 --> Utf8 Class Initialized
INFO - 2020-08-24 07:57:14 --> URI Class Initialized
INFO - 2020-08-24 07:57:14 --> Router Class Initialized
INFO - 2020-08-24 07:57:14 --> Output Class Initialized
INFO - 2020-08-24 07:57:14 --> Security Class Initialized
DEBUG - 2020-08-24 07:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:57:14 --> Input Class Initialized
INFO - 2020-08-24 07:57:14 --> Language Class Initialized
INFO - 2020-08-24 07:57:14 --> Language Class Initialized
INFO - 2020-08-24 07:57:14 --> Config Class Initialized
INFO - 2020-08-24 07:57:14 --> Loader Class Initialized
INFO - 2020-08-24 07:57:14 --> Helper loaded: url_helper
INFO - 2020-08-24 07:57:14 --> Helper loaded: form_helper
INFO - 2020-08-24 07:57:14 --> Helper loaded: file_helper
INFO - 2020-08-24 07:57:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:57:14 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:57:14 --> Upload Class Initialized
INFO - 2020-08-24 07:57:14 --> Controller Class Initialized
DEBUG - 2020-08-24 07:57:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 07:57:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 07:57:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 07:57:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 07:57:14 --> Final output sent to browser
DEBUG - 2020-08-24 07:57:14 --> Total execution time: 0.0520
INFO - 2020-08-24 07:57:22 --> Config Class Initialized
INFO - 2020-08-24 07:57:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:57:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:57:22 --> Utf8 Class Initialized
INFO - 2020-08-24 07:57:22 --> URI Class Initialized
INFO - 2020-08-24 07:57:22 --> Router Class Initialized
INFO - 2020-08-24 07:57:22 --> Output Class Initialized
INFO - 2020-08-24 07:57:22 --> Security Class Initialized
DEBUG - 2020-08-24 07:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:57:22 --> Input Class Initialized
INFO - 2020-08-24 07:57:22 --> Language Class Initialized
INFO - 2020-08-24 07:57:22 --> Language Class Initialized
INFO - 2020-08-24 07:57:22 --> Config Class Initialized
INFO - 2020-08-24 07:57:22 --> Loader Class Initialized
INFO - 2020-08-24 07:57:22 --> Helper loaded: url_helper
INFO - 2020-08-24 07:57:22 --> Helper loaded: form_helper
INFO - 2020-08-24 07:57:22 --> Helper loaded: file_helper
INFO - 2020-08-24 07:57:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:57:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:57:22 --> Upload Class Initialized
INFO - 2020-08-24 07:57:22 --> Controller Class Initialized
ERROR - 2020-08-24 07:57:22 --> 404 Page Not Found: /index
INFO - 2020-08-24 07:58:10 --> Config Class Initialized
INFO - 2020-08-24 07:58:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:58:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:58:10 --> Utf8 Class Initialized
INFO - 2020-08-24 07:58:10 --> URI Class Initialized
DEBUG - 2020-08-24 07:58:10 --> No URI present. Default controller set.
INFO - 2020-08-24 07:58:10 --> Router Class Initialized
INFO - 2020-08-24 07:58:10 --> Output Class Initialized
INFO - 2020-08-24 07:58:10 --> Security Class Initialized
DEBUG - 2020-08-24 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:58:10 --> Input Class Initialized
INFO - 2020-08-24 07:58:10 --> Language Class Initialized
INFO - 2020-08-24 07:58:10 --> Language Class Initialized
INFO - 2020-08-24 07:58:10 --> Config Class Initialized
INFO - 2020-08-24 07:58:10 --> Loader Class Initialized
INFO - 2020-08-24 07:58:10 --> Helper loaded: url_helper
INFO - 2020-08-24 07:58:10 --> Helper loaded: form_helper
INFO - 2020-08-24 07:58:10 --> Helper loaded: file_helper
INFO - 2020-08-24 07:58:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:58:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:58:10 --> Upload Class Initialized
INFO - 2020-08-24 07:58:11 --> Controller Class Initialized
DEBUG - 2020-08-24 07:58:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 07:58:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 07:58:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 07:58:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 07:58:11 --> Final output sent to browser
DEBUG - 2020-08-24 07:58:11 --> Total execution time: 0.0504
INFO - 2020-08-24 07:58:15 --> Config Class Initialized
INFO - 2020-08-24 07:58:15 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:58:15 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:58:15 --> Utf8 Class Initialized
INFO - 2020-08-24 07:58:15 --> URI Class Initialized
INFO - 2020-08-24 07:58:15 --> Router Class Initialized
INFO - 2020-08-24 07:58:15 --> Output Class Initialized
INFO - 2020-08-24 07:58:15 --> Security Class Initialized
DEBUG - 2020-08-24 07:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:58:15 --> Input Class Initialized
INFO - 2020-08-24 07:58:15 --> Language Class Initialized
INFO - 2020-08-24 07:58:15 --> Language Class Initialized
INFO - 2020-08-24 07:58:15 --> Config Class Initialized
INFO - 2020-08-24 07:58:15 --> Loader Class Initialized
INFO - 2020-08-24 07:58:15 --> Helper loaded: url_helper
INFO - 2020-08-24 07:58:15 --> Helper loaded: form_helper
INFO - 2020-08-24 07:58:15 --> Helper loaded: file_helper
INFO - 2020-08-24 07:58:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 07:58:15 --> Database Driver Class Initialized
DEBUG - 2020-08-24 07:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 07:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:58:15 --> Upload Class Initialized
INFO - 2020-08-24 07:58:15 --> Controller Class Initialized
DEBUG - 2020-08-24 07:58:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 07:58:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 07:58:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 07:58:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 07:58:15 --> Final output sent to browser
DEBUG - 2020-08-24 07:58:15 --> Total execution time: 0.0495
INFO - 2020-08-24 08:14:40 --> Config Class Initialized
INFO - 2020-08-24 08:14:40 --> Hooks Class Initialized
DEBUG - 2020-08-24 08:14:40 --> UTF-8 Support Enabled
INFO - 2020-08-24 08:14:40 --> Utf8 Class Initialized
INFO - 2020-08-24 08:14:40 --> URI Class Initialized
DEBUG - 2020-08-24 08:14:40 --> No URI present. Default controller set.
INFO - 2020-08-24 08:14:40 --> Router Class Initialized
INFO - 2020-08-24 08:14:40 --> Output Class Initialized
INFO - 2020-08-24 08:14:40 --> Security Class Initialized
DEBUG - 2020-08-24 08:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 08:14:40 --> Input Class Initialized
INFO - 2020-08-24 08:14:40 --> Language Class Initialized
INFO - 2020-08-24 08:14:40 --> Language Class Initialized
INFO - 2020-08-24 08:14:40 --> Config Class Initialized
INFO - 2020-08-24 08:14:40 --> Loader Class Initialized
INFO - 2020-08-24 08:14:40 --> Helper loaded: url_helper
INFO - 2020-08-24 08:14:40 --> Helper loaded: form_helper
INFO - 2020-08-24 08:14:40 --> Helper loaded: file_helper
INFO - 2020-08-24 08:14:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 08:14:40 --> Database Driver Class Initialized
DEBUG - 2020-08-24 08:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 08:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 08:14:40 --> Upload Class Initialized
INFO - 2020-08-24 08:14:40 --> Controller Class Initialized
DEBUG - 2020-08-24 08:14:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 08:14:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 08:14:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 08:14:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 08:14:40 --> Final output sent to browser
DEBUG - 2020-08-24 08:14:40 --> Total execution time: 0.0503
INFO - 2020-08-24 09:45:42 --> Config Class Initialized
INFO - 2020-08-24 09:45:42 --> Hooks Class Initialized
DEBUG - 2020-08-24 09:45:42 --> UTF-8 Support Enabled
INFO - 2020-08-24 09:45:42 --> Utf8 Class Initialized
INFO - 2020-08-24 09:45:42 --> URI Class Initialized
DEBUG - 2020-08-24 09:45:42 --> No URI present. Default controller set.
INFO - 2020-08-24 09:45:42 --> Router Class Initialized
INFO - 2020-08-24 09:45:42 --> Output Class Initialized
INFO - 2020-08-24 09:45:42 --> Security Class Initialized
DEBUG - 2020-08-24 09:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 09:45:42 --> Input Class Initialized
INFO - 2020-08-24 09:45:42 --> Language Class Initialized
INFO - 2020-08-24 09:45:42 --> Language Class Initialized
INFO - 2020-08-24 09:45:42 --> Config Class Initialized
INFO - 2020-08-24 09:45:42 --> Loader Class Initialized
INFO - 2020-08-24 09:45:42 --> Helper loaded: url_helper
INFO - 2020-08-24 09:45:42 --> Helper loaded: form_helper
INFO - 2020-08-24 09:45:42 --> Helper loaded: file_helper
INFO - 2020-08-24 09:45:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 09:45:42 --> Database Driver Class Initialized
DEBUG - 2020-08-24 09:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 09:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 09:45:42 --> Upload Class Initialized
INFO - 2020-08-24 09:45:42 --> Controller Class Initialized
DEBUG - 2020-08-24 09:45:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 09:45:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 09:45:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 09:45:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 09:45:42 --> Final output sent to browser
DEBUG - 2020-08-24 09:45:42 --> Total execution time: 0.1497
INFO - 2020-08-24 10:37:26 --> Config Class Initialized
INFO - 2020-08-24 10:37:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 10:37:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 10:37:26 --> Utf8 Class Initialized
INFO - 2020-08-24 10:37:26 --> URI Class Initialized
DEBUG - 2020-08-24 10:37:26 --> No URI present. Default controller set.
INFO - 2020-08-24 10:37:26 --> Router Class Initialized
INFO - 2020-08-24 10:37:26 --> Output Class Initialized
INFO - 2020-08-24 10:37:26 --> Security Class Initialized
DEBUG - 2020-08-24 10:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 10:37:26 --> Input Class Initialized
INFO - 2020-08-24 10:37:26 --> Language Class Initialized
INFO - 2020-08-24 10:37:26 --> Language Class Initialized
INFO - 2020-08-24 10:37:26 --> Config Class Initialized
INFO - 2020-08-24 10:37:26 --> Loader Class Initialized
INFO - 2020-08-24 10:37:26 --> Helper loaded: url_helper
INFO - 2020-08-24 10:37:26 --> Helper loaded: form_helper
INFO - 2020-08-24 10:37:26 --> Helper loaded: file_helper
INFO - 2020-08-24 10:37:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 10:37:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 10:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 10:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 10:37:26 --> Upload Class Initialized
INFO - 2020-08-24 10:37:26 --> Controller Class Initialized
DEBUG - 2020-08-24 10:37:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 10:37:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 10:37:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 10:37:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 10:37:26 --> Final output sent to browser
DEBUG - 2020-08-24 10:37:26 --> Total execution time: 0.0564
INFO - 2020-08-24 10:37:26 --> Config Class Initialized
INFO - 2020-08-24 10:37:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 10:37:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 10:37:26 --> Utf8 Class Initialized
INFO - 2020-08-24 10:37:26 --> URI Class Initialized
DEBUG - 2020-08-24 10:37:26 --> No URI present. Default controller set.
INFO - 2020-08-24 10:37:26 --> Router Class Initialized
INFO - 2020-08-24 10:37:26 --> Output Class Initialized
INFO - 2020-08-24 10:37:26 --> Security Class Initialized
DEBUG - 2020-08-24 10:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 10:37:26 --> Input Class Initialized
INFO - 2020-08-24 10:37:26 --> Language Class Initialized
INFO - 2020-08-24 10:37:26 --> Language Class Initialized
INFO - 2020-08-24 10:37:26 --> Config Class Initialized
INFO - 2020-08-24 10:37:26 --> Loader Class Initialized
INFO - 2020-08-24 10:37:26 --> Helper loaded: url_helper
INFO - 2020-08-24 10:37:26 --> Helper loaded: form_helper
INFO - 2020-08-24 10:37:26 --> Helper loaded: file_helper
INFO - 2020-08-24 10:37:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 10:37:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 10:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 10:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 10:37:26 --> Upload Class Initialized
INFO - 2020-08-24 10:37:26 --> Controller Class Initialized
DEBUG - 2020-08-24 10:37:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 10:37:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 10:37:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 10:37:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 10:37:26 --> Final output sent to browser
DEBUG - 2020-08-24 10:37:26 --> Total execution time: 0.0531
INFO - 2020-08-24 11:23:56 --> Config Class Initialized
INFO - 2020-08-24 11:23:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 11:23:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 11:23:56 --> Utf8 Class Initialized
INFO - 2020-08-24 11:23:56 --> URI Class Initialized
DEBUG - 2020-08-24 11:23:56 --> No URI present. Default controller set.
INFO - 2020-08-24 11:23:56 --> Router Class Initialized
INFO - 2020-08-24 11:23:56 --> Output Class Initialized
INFO - 2020-08-24 11:23:56 --> Security Class Initialized
DEBUG - 2020-08-24 11:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 11:23:56 --> Input Class Initialized
INFO - 2020-08-24 11:23:56 --> Language Class Initialized
INFO - 2020-08-24 11:23:56 --> Language Class Initialized
INFO - 2020-08-24 11:23:56 --> Config Class Initialized
INFO - 2020-08-24 11:23:56 --> Loader Class Initialized
INFO - 2020-08-24 11:23:56 --> Helper loaded: url_helper
INFO - 2020-08-24 11:23:56 --> Helper loaded: form_helper
INFO - 2020-08-24 11:23:56 --> Helper loaded: file_helper
INFO - 2020-08-24 11:23:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 11:23:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 11:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 11:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 11:23:56 --> Upload Class Initialized
INFO - 2020-08-24 11:23:56 --> Controller Class Initialized
DEBUG - 2020-08-24 11:23:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 11:23:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 11:23:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 11:23:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 11:23:56 --> Final output sent to browser
DEBUG - 2020-08-24 11:23:56 --> Total execution time: 0.0519
INFO - 2020-08-24 11:24:25 --> Config Class Initialized
INFO - 2020-08-24 11:24:25 --> Hooks Class Initialized
DEBUG - 2020-08-24 11:24:25 --> UTF-8 Support Enabled
INFO - 2020-08-24 11:24:25 --> Utf8 Class Initialized
INFO - 2020-08-24 11:24:25 --> URI Class Initialized
DEBUG - 2020-08-24 11:24:25 --> No URI present. Default controller set.
INFO - 2020-08-24 11:24:25 --> Router Class Initialized
INFO - 2020-08-24 11:24:25 --> Output Class Initialized
INFO - 2020-08-24 11:24:25 --> Security Class Initialized
DEBUG - 2020-08-24 11:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 11:24:25 --> Input Class Initialized
INFO - 2020-08-24 11:24:25 --> Language Class Initialized
INFO - 2020-08-24 11:24:25 --> Language Class Initialized
INFO - 2020-08-24 11:24:25 --> Config Class Initialized
INFO - 2020-08-24 11:24:25 --> Loader Class Initialized
INFO - 2020-08-24 11:24:25 --> Helper loaded: url_helper
INFO - 2020-08-24 11:24:25 --> Helper loaded: form_helper
INFO - 2020-08-24 11:24:25 --> Helper loaded: file_helper
INFO - 2020-08-24 11:24:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 11:24:25 --> Database Driver Class Initialized
DEBUG - 2020-08-24 11:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 11:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 11:24:25 --> Upload Class Initialized
INFO - 2020-08-24 11:24:25 --> Controller Class Initialized
DEBUG - 2020-08-24 11:24:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 11:24:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 11:24:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 11:24:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 11:24:25 --> Final output sent to browser
DEBUG - 2020-08-24 11:24:25 --> Total execution time: 0.0513
INFO - 2020-08-24 12:04:18 --> Config Class Initialized
INFO - 2020-08-24 12:04:18 --> Hooks Class Initialized
DEBUG - 2020-08-24 12:04:18 --> UTF-8 Support Enabled
INFO - 2020-08-24 12:04:18 --> Utf8 Class Initialized
INFO - 2020-08-24 12:04:18 --> URI Class Initialized
DEBUG - 2020-08-24 12:04:18 --> No URI present. Default controller set.
INFO - 2020-08-24 12:04:18 --> Router Class Initialized
INFO - 2020-08-24 12:04:18 --> Output Class Initialized
INFO - 2020-08-24 12:04:18 --> Security Class Initialized
DEBUG - 2020-08-24 12:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 12:04:18 --> Input Class Initialized
INFO - 2020-08-24 12:04:18 --> Language Class Initialized
INFO - 2020-08-24 12:04:18 --> Language Class Initialized
INFO - 2020-08-24 12:04:18 --> Config Class Initialized
INFO - 2020-08-24 12:04:18 --> Loader Class Initialized
INFO - 2020-08-24 12:04:18 --> Helper loaded: url_helper
INFO - 2020-08-24 12:04:18 --> Helper loaded: form_helper
INFO - 2020-08-24 12:04:18 --> Helper loaded: file_helper
INFO - 2020-08-24 12:04:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 12:04:18 --> Database Driver Class Initialized
DEBUG - 2020-08-24 12:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 12:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 12:04:18 --> Upload Class Initialized
INFO - 2020-08-24 12:04:18 --> Controller Class Initialized
DEBUG - 2020-08-24 12:04:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 12:04:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 12:04:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 12:04:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 12:04:18 --> Final output sent to browser
DEBUG - 2020-08-24 12:04:18 --> Total execution time: 0.0730
INFO - 2020-08-24 13:48:00 --> Config Class Initialized
INFO - 2020-08-24 13:48:00 --> Hooks Class Initialized
DEBUG - 2020-08-24 13:48:00 --> UTF-8 Support Enabled
INFO - 2020-08-24 13:48:00 --> Utf8 Class Initialized
INFO - 2020-08-24 13:48:00 --> URI Class Initialized
INFO - 2020-08-24 13:48:00 --> Router Class Initialized
INFO - 2020-08-24 13:48:00 --> Output Class Initialized
INFO - 2020-08-24 13:48:00 --> Security Class Initialized
DEBUG - 2020-08-24 13:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 13:48:00 --> Input Class Initialized
INFO - 2020-08-24 13:48:00 --> Language Class Initialized
INFO - 2020-08-24 13:48:00 --> Language Class Initialized
INFO - 2020-08-24 13:48:00 --> Config Class Initialized
INFO - 2020-08-24 13:48:00 --> Loader Class Initialized
INFO - 2020-08-24 13:48:00 --> Helper loaded: url_helper
INFO - 2020-08-24 13:48:00 --> Helper loaded: form_helper
INFO - 2020-08-24 13:48:00 --> Helper loaded: file_helper
INFO - 2020-08-24 13:48:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 13:48:00 --> Database Driver Class Initialized
DEBUG - 2020-08-24 13:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 13:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 13:48:00 --> Upload Class Initialized
INFO - 2020-08-24 13:48:00 --> Controller Class Initialized
ERROR - 2020-08-24 13:48:00 --> 404 Page Not Found: /index
INFO - 2020-08-24 14:38:52 --> Config Class Initialized
INFO - 2020-08-24 14:38:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 14:38:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 14:38:52 --> Utf8 Class Initialized
INFO - 2020-08-24 14:38:52 --> URI Class Initialized
DEBUG - 2020-08-24 14:38:52 --> No URI present. Default controller set.
INFO - 2020-08-24 14:38:52 --> Router Class Initialized
INFO - 2020-08-24 14:38:52 --> Output Class Initialized
INFO - 2020-08-24 14:38:52 --> Security Class Initialized
DEBUG - 2020-08-24 14:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 14:38:52 --> Input Class Initialized
INFO - 2020-08-24 14:38:52 --> Language Class Initialized
INFO - 2020-08-24 14:38:52 --> Language Class Initialized
INFO - 2020-08-24 14:38:52 --> Config Class Initialized
INFO - 2020-08-24 14:38:52 --> Loader Class Initialized
INFO - 2020-08-24 14:38:52 --> Helper loaded: url_helper
INFO - 2020-08-24 14:38:52 --> Helper loaded: form_helper
INFO - 2020-08-24 14:38:52 --> Helper loaded: file_helper
INFO - 2020-08-24 14:38:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 14:38:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 14:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 14:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 14:38:52 --> Upload Class Initialized
INFO - 2020-08-24 14:38:52 --> Controller Class Initialized
DEBUG - 2020-08-24 14:38:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 14:38:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 14:38:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 14:38:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 14:38:52 --> Final output sent to browser
DEBUG - 2020-08-24 14:38:52 --> Total execution time: 0.0501
INFO - 2020-08-24 14:38:54 --> Config Class Initialized
INFO - 2020-08-24 14:38:54 --> Hooks Class Initialized
DEBUG - 2020-08-24 14:38:54 --> UTF-8 Support Enabled
INFO - 2020-08-24 14:38:54 --> Utf8 Class Initialized
INFO - 2020-08-24 14:38:54 --> URI Class Initialized
INFO - 2020-08-24 14:38:54 --> Router Class Initialized
INFO - 2020-08-24 14:38:54 --> Output Class Initialized
INFO - 2020-08-24 14:38:54 --> Security Class Initialized
DEBUG - 2020-08-24 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 14:38:54 --> Input Class Initialized
INFO - 2020-08-24 14:38:54 --> Language Class Initialized
INFO - 2020-08-24 14:38:54 --> Language Class Initialized
INFO - 2020-08-24 14:38:54 --> Config Class Initialized
INFO - 2020-08-24 14:38:54 --> Loader Class Initialized
INFO - 2020-08-24 14:38:54 --> Helper loaded: url_helper
INFO - 2020-08-24 14:38:54 --> Helper loaded: form_helper
INFO - 2020-08-24 14:38:54 --> Helper loaded: file_helper
INFO - 2020-08-24 14:38:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 14:38:54 --> Database Driver Class Initialized
DEBUG - 2020-08-24 14:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 14:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 14:38:54 --> Upload Class Initialized
INFO - 2020-08-24 14:38:54 --> Controller Class Initialized
ERROR - 2020-08-24 14:38:54 --> 404 Page Not Found: /index
INFO - 2020-08-24 14:39:10 --> Config Class Initialized
INFO - 2020-08-24 14:39:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 14:39:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 14:39:10 --> Utf8 Class Initialized
INFO - 2020-08-24 14:39:10 --> URI Class Initialized
DEBUG - 2020-08-24 14:39:10 --> No URI present. Default controller set.
INFO - 2020-08-24 14:39:10 --> Router Class Initialized
INFO - 2020-08-24 14:39:10 --> Output Class Initialized
INFO - 2020-08-24 14:39:10 --> Security Class Initialized
DEBUG - 2020-08-24 14:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 14:39:10 --> Input Class Initialized
INFO - 2020-08-24 14:39:10 --> Language Class Initialized
INFO - 2020-08-24 14:39:10 --> Language Class Initialized
INFO - 2020-08-24 14:39:10 --> Config Class Initialized
INFO - 2020-08-24 14:39:10 --> Loader Class Initialized
INFO - 2020-08-24 14:39:10 --> Helper loaded: url_helper
INFO - 2020-08-24 14:39:10 --> Helper loaded: form_helper
INFO - 2020-08-24 14:39:10 --> Helper loaded: file_helper
INFO - 2020-08-24 14:39:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 14:39:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 14:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 14:39:10 --> Upload Class Initialized
INFO - 2020-08-24 14:39:10 --> Controller Class Initialized
DEBUG - 2020-08-24 14:39:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 14:39:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 14:39:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 14:39:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 14:39:10 --> Final output sent to browser
DEBUG - 2020-08-24 14:39:10 --> Total execution time: 0.0509
INFO - 2020-08-24 14:43:35 --> Config Class Initialized
INFO - 2020-08-24 14:43:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 14:43:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 14:43:35 --> Utf8 Class Initialized
INFO - 2020-08-24 14:43:35 --> URI Class Initialized
INFO - 2020-08-24 14:43:35 --> Router Class Initialized
INFO - 2020-08-24 14:43:35 --> Output Class Initialized
INFO - 2020-08-24 14:43:35 --> Security Class Initialized
DEBUG - 2020-08-24 14:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 14:43:35 --> Input Class Initialized
INFO - 2020-08-24 14:43:35 --> Language Class Initialized
INFO - 2020-08-24 14:43:35 --> Language Class Initialized
INFO - 2020-08-24 14:43:35 --> Config Class Initialized
INFO - 2020-08-24 14:43:35 --> Loader Class Initialized
INFO - 2020-08-24 14:43:35 --> Helper loaded: url_helper
INFO - 2020-08-24 14:43:35 --> Helper loaded: form_helper
INFO - 2020-08-24 14:43:35 --> Helper loaded: file_helper
INFO - 2020-08-24 14:43:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 14:43:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 14:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 14:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 14:43:35 --> Upload Class Initialized
INFO - 2020-08-24 14:43:35 --> Controller Class Initialized
DEBUG - 2020-08-24 14:43:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 14:43:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 14:43:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 14:43:35 --> Final output sent to browser
DEBUG - 2020-08-24 14:43:35 --> Total execution time: 0.0530
INFO - 2020-08-24 15:01:46 --> Config Class Initialized
INFO - 2020-08-24 15:01:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:01:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:01:46 --> Utf8 Class Initialized
INFO - 2020-08-24 15:01:46 --> URI Class Initialized
INFO - 2020-08-24 15:01:46 --> Router Class Initialized
INFO - 2020-08-24 15:01:46 --> Output Class Initialized
INFO - 2020-08-24 15:01:46 --> Security Class Initialized
DEBUG - 2020-08-24 15:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:01:46 --> Input Class Initialized
INFO - 2020-08-24 15:01:46 --> Language Class Initialized
INFO - 2020-08-24 15:01:46 --> Language Class Initialized
INFO - 2020-08-24 15:01:46 --> Config Class Initialized
INFO - 2020-08-24 15:01:46 --> Loader Class Initialized
INFO - 2020-08-24 15:01:46 --> Helper loaded: url_helper
INFO - 2020-08-24 15:01:46 --> Helper loaded: form_helper
INFO - 2020-08-24 15:01:46 --> Helper loaded: file_helper
INFO - 2020-08-24 15:01:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:01:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:01:46 --> Upload Class Initialized
INFO - 2020-08-24 15:01:46 --> Controller Class Initialized
DEBUG - 2020-08-24 15:01:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:01:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:01:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:01:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:01:46 --> Final output sent to browser
DEBUG - 2020-08-24 15:01:46 --> Total execution time: 0.0555
INFO - 2020-08-24 15:04:46 --> Config Class Initialized
INFO - 2020-08-24 15:04:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:04:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:04:46 --> Utf8 Class Initialized
INFO - 2020-08-24 15:04:46 --> URI Class Initialized
INFO - 2020-08-24 15:04:46 --> Router Class Initialized
INFO - 2020-08-24 15:04:46 --> Output Class Initialized
INFO - 2020-08-24 15:04:46 --> Security Class Initialized
DEBUG - 2020-08-24 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:04:46 --> Input Class Initialized
INFO - 2020-08-24 15:04:46 --> Language Class Initialized
INFO - 2020-08-24 15:04:46 --> Language Class Initialized
INFO - 2020-08-24 15:04:46 --> Config Class Initialized
INFO - 2020-08-24 15:04:46 --> Loader Class Initialized
INFO - 2020-08-24 15:04:46 --> Helper loaded: url_helper
INFO - 2020-08-24 15:04:46 --> Helper loaded: form_helper
INFO - 2020-08-24 15:04:46 --> Helper loaded: file_helper
INFO - 2020-08-24 15:04:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:04:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:04:46 --> Upload Class Initialized
INFO - 2020-08-24 15:04:46 --> Controller Class Initialized
DEBUG - 2020-08-24 15:04:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:04:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:04:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:04:46 --> Final output sent to browser
DEBUG - 2020-08-24 15:04:46 --> Total execution time: 0.0503
INFO - 2020-08-24 15:04:47 --> Config Class Initialized
INFO - 2020-08-24 15:04:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:04:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:04:47 --> Utf8 Class Initialized
INFO - 2020-08-24 15:04:47 --> URI Class Initialized
INFO - 2020-08-24 15:04:47 --> Router Class Initialized
INFO - 2020-08-24 15:04:47 --> Output Class Initialized
INFO - 2020-08-24 15:04:47 --> Security Class Initialized
DEBUG - 2020-08-24 15:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:04:47 --> Input Class Initialized
INFO - 2020-08-24 15:04:47 --> Language Class Initialized
INFO - 2020-08-24 15:04:47 --> Language Class Initialized
INFO - 2020-08-24 15:04:47 --> Config Class Initialized
INFO - 2020-08-24 15:04:47 --> Loader Class Initialized
INFO - 2020-08-24 15:04:47 --> Helper loaded: url_helper
INFO - 2020-08-24 15:04:47 --> Helper loaded: form_helper
INFO - 2020-08-24 15:04:47 --> Helper loaded: file_helper
INFO - 2020-08-24 15:04:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:04:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:04:47 --> Upload Class Initialized
INFO - 2020-08-24 15:04:47 --> Controller Class Initialized
ERROR - 2020-08-24 15:04:47 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:05:02 --> Config Class Initialized
INFO - 2020-08-24 15:05:02 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:05:02 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:05:02 --> Utf8 Class Initialized
INFO - 2020-08-24 15:05:02 --> URI Class Initialized
INFO - 2020-08-24 15:05:02 --> Router Class Initialized
INFO - 2020-08-24 15:05:02 --> Output Class Initialized
INFO - 2020-08-24 15:05:02 --> Security Class Initialized
DEBUG - 2020-08-24 15:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:05:02 --> Input Class Initialized
INFO - 2020-08-24 15:05:02 --> Language Class Initialized
INFO - 2020-08-24 15:05:02 --> Language Class Initialized
INFO - 2020-08-24 15:05:02 --> Config Class Initialized
INFO - 2020-08-24 15:05:02 --> Loader Class Initialized
INFO - 2020-08-24 15:05:02 --> Helper loaded: url_helper
INFO - 2020-08-24 15:05:02 --> Helper loaded: form_helper
INFO - 2020-08-24 15:05:02 --> Helper loaded: file_helper
INFO - 2020-08-24 15:05:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:05:02 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:05:02 --> Upload Class Initialized
INFO - 2020-08-24 15:05:02 --> Controller Class Initialized
DEBUG - 2020-08-24 15:05:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:05:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:05:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:05:02 --> Final output sent to browser
DEBUG - 2020-08-24 15:05:02 --> Total execution time: 0.4086
INFO - 2020-08-24 15:05:04 --> Config Class Initialized
INFO - 2020-08-24 15:05:04 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:05:04 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:05:04 --> Utf8 Class Initialized
INFO - 2020-08-24 15:05:04 --> URI Class Initialized
INFO - 2020-08-24 15:05:04 --> Router Class Initialized
INFO - 2020-08-24 15:05:04 --> Output Class Initialized
INFO - 2020-08-24 15:05:04 --> Security Class Initialized
DEBUG - 2020-08-24 15:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:05:04 --> Input Class Initialized
INFO - 2020-08-24 15:05:04 --> Language Class Initialized
INFO - 2020-08-24 15:05:04 --> Language Class Initialized
INFO - 2020-08-24 15:05:04 --> Config Class Initialized
INFO - 2020-08-24 15:05:04 --> Loader Class Initialized
INFO - 2020-08-24 15:05:04 --> Helper loaded: url_helper
INFO - 2020-08-24 15:05:04 --> Helper loaded: form_helper
INFO - 2020-08-24 15:05:04 --> Helper loaded: file_helper
INFO - 2020-08-24 15:05:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:05:04 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:05:04 --> Upload Class Initialized
INFO - 2020-08-24 15:05:04 --> Controller Class Initialized
ERROR - 2020-08-24 15:05:04 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:08:14 --> Config Class Initialized
INFO - 2020-08-24 15:08:14 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:08:14 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:08:14 --> Utf8 Class Initialized
INFO - 2020-08-24 15:08:14 --> URI Class Initialized
INFO - 2020-08-24 15:08:14 --> Router Class Initialized
INFO - 2020-08-24 15:08:14 --> Output Class Initialized
INFO - 2020-08-24 15:08:14 --> Security Class Initialized
DEBUG - 2020-08-24 15:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:08:14 --> Input Class Initialized
INFO - 2020-08-24 15:08:14 --> Language Class Initialized
INFO - 2020-08-24 15:08:14 --> Language Class Initialized
INFO - 2020-08-24 15:08:14 --> Config Class Initialized
INFO - 2020-08-24 15:08:14 --> Loader Class Initialized
INFO - 2020-08-24 15:08:14 --> Helper loaded: url_helper
INFO - 2020-08-24 15:08:14 --> Helper loaded: form_helper
INFO - 2020-08-24 15:08:14 --> Helper loaded: file_helper
INFO - 2020-08-24 15:08:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:08:14 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:08:14 --> Upload Class Initialized
INFO - 2020-08-24 15:08:14 --> Controller Class Initialized
DEBUG - 2020-08-24 15:08:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:08:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:08:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:08:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:08:14 --> Final output sent to browser
DEBUG - 2020-08-24 15:08:14 --> Total execution time: 0.0498
INFO - 2020-08-24 15:09:55 --> Config Class Initialized
INFO - 2020-08-24 15:09:55 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:09:55 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:09:55 --> Utf8 Class Initialized
INFO - 2020-08-24 15:09:55 --> URI Class Initialized
INFO - 2020-08-24 15:09:55 --> Router Class Initialized
INFO - 2020-08-24 15:09:55 --> Output Class Initialized
INFO - 2020-08-24 15:09:56 --> Security Class Initialized
DEBUG - 2020-08-24 15:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:09:56 --> Input Class Initialized
INFO - 2020-08-24 15:09:56 --> Language Class Initialized
INFO - 2020-08-24 15:09:56 --> Language Class Initialized
INFO - 2020-08-24 15:09:56 --> Config Class Initialized
INFO - 2020-08-24 15:09:56 --> Loader Class Initialized
INFO - 2020-08-24 15:09:56 --> Helper loaded: url_helper
INFO - 2020-08-24 15:09:56 --> Helper loaded: form_helper
INFO - 2020-08-24 15:09:56 --> Helper loaded: file_helper
INFO - 2020-08-24 15:09:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:09:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:09:56 --> Upload Class Initialized
INFO - 2020-08-24 15:09:56 --> Controller Class Initialized
DEBUG - 2020-08-24 15:09:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:09:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:09:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:09:56 --> Final output sent to browser
DEBUG - 2020-08-24 15:09:56 --> Total execution time: 0.0577
INFO - 2020-08-24 15:10:03 --> Config Class Initialized
INFO - 2020-08-24 15:10:03 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:10:03 --> Utf8 Class Initialized
INFO - 2020-08-24 15:10:03 --> URI Class Initialized
INFO - 2020-08-24 15:10:03 --> Router Class Initialized
INFO - 2020-08-24 15:10:03 --> Output Class Initialized
INFO - 2020-08-24 15:10:03 --> Security Class Initialized
DEBUG - 2020-08-24 15:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:10:03 --> Input Class Initialized
INFO - 2020-08-24 15:10:03 --> Language Class Initialized
INFO - 2020-08-24 15:10:03 --> Language Class Initialized
INFO - 2020-08-24 15:10:03 --> Config Class Initialized
INFO - 2020-08-24 15:10:03 --> Loader Class Initialized
INFO - 2020-08-24 15:10:03 --> Helper loaded: url_helper
INFO - 2020-08-24 15:10:03 --> Helper loaded: form_helper
INFO - 2020-08-24 15:10:03 --> Helper loaded: file_helper
INFO - 2020-08-24 15:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:10:03 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:10:03 --> Upload Class Initialized
INFO - 2020-08-24 15:10:03 --> Controller Class Initialized
DEBUG - 2020-08-24 15:10:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:10:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:10:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:10:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:10:03 --> Final output sent to browser
DEBUG - 2020-08-24 15:10:03 --> Total execution time: 0.3321
INFO - 2020-08-24 15:10:07 --> Config Class Initialized
INFO - 2020-08-24 15:10:07 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:10:07 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:10:07 --> Utf8 Class Initialized
INFO - 2020-08-24 15:10:07 --> URI Class Initialized
INFO - 2020-08-24 15:10:07 --> Router Class Initialized
INFO - 2020-08-24 15:10:07 --> Output Class Initialized
INFO - 2020-08-24 15:10:07 --> Security Class Initialized
DEBUG - 2020-08-24 15:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:10:07 --> Input Class Initialized
INFO - 2020-08-24 15:10:07 --> Language Class Initialized
INFO - 2020-08-24 15:10:07 --> Language Class Initialized
INFO - 2020-08-24 15:10:07 --> Config Class Initialized
INFO - 2020-08-24 15:10:07 --> Loader Class Initialized
INFO - 2020-08-24 15:10:07 --> Helper loaded: url_helper
INFO - 2020-08-24 15:10:07 --> Helper loaded: form_helper
INFO - 2020-08-24 15:10:07 --> Helper loaded: file_helper
INFO - 2020-08-24 15:10:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:10:07 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:10:07 --> Upload Class Initialized
INFO - 2020-08-24 15:10:07 --> Controller Class Initialized
DEBUG - 2020-08-24 15:10:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:10:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-24 15:10:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:10:07 --> Final output sent to browser
DEBUG - 2020-08-24 15:10:07 --> Total execution time: 0.0519
INFO - 2020-08-24 15:10:14 --> Config Class Initialized
INFO - 2020-08-24 15:10:14 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:10:14 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:10:14 --> Utf8 Class Initialized
INFO - 2020-08-24 15:10:14 --> URI Class Initialized
INFO - 2020-08-24 15:10:14 --> Router Class Initialized
INFO - 2020-08-24 15:10:14 --> Output Class Initialized
INFO - 2020-08-24 15:10:14 --> Security Class Initialized
DEBUG - 2020-08-24 15:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:10:14 --> Input Class Initialized
INFO - 2020-08-24 15:10:14 --> Language Class Initialized
INFO - 2020-08-24 15:10:14 --> Language Class Initialized
INFO - 2020-08-24 15:10:14 --> Config Class Initialized
INFO - 2020-08-24 15:10:14 --> Loader Class Initialized
INFO - 2020-08-24 15:10:14 --> Helper loaded: url_helper
INFO - 2020-08-24 15:10:14 --> Helper loaded: form_helper
INFO - 2020-08-24 15:10:14 --> Helper loaded: file_helper
INFO - 2020-08-24 15:10:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:10:14 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:10:14 --> Upload Class Initialized
INFO - 2020-08-24 15:10:14 --> Controller Class Initialized
DEBUG - 2020-08-24 15:10:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:10:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-24 15:10:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:10:14 --> Final output sent to browser
DEBUG - 2020-08-24 15:10:14 --> Total execution time: 0.0609
INFO - 2020-08-24 15:10:21 --> Config Class Initialized
INFO - 2020-08-24 15:10:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:10:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:10:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:10:21 --> URI Class Initialized
INFO - 2020-08-24 15:10:21 --> Router Class Initialized
INFO - 2020-08-24 15:10:21 --> Output Class Initialized
INFO - 2020-08-24 15:10:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:10:21 --> Input Class Initialized
INFO - 2020-08-24 15:10:21 --> Language Class Initialized
INFO - 2020-08-24 15:10:21 --> Language Class Initialized
INFO - 2020-08-24 15:10:21 --> Config Class Initialized
INFO - 2020-08-24 15:10:21 --> Loader Class Initialized
INFO - 2020-08-24 15:10:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:10:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:10:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:10:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:10:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:10:21 --> Upload Class Initialized
INFO - 2020-08-24 15:10:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:10:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:10:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:10:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:10:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:10:21 --> Total execution time: 0.0505
INFO - 2020-08-24 15:10:47 --> Config Class Initialized
INFO - 2020-08-24 15:10:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:10:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:10:47 --> Utf8 Class Initialized
INFO - 2020-08-24 15:10:47 --> URI Class Initialized
INFO - 2020-08-24 15:10:47 --> Router Class Initialized
INFO - 2020-08-24 15:10:47 --> Output Class Initialized
INFO - 2020-08-24 15:10:47 --> Security Class Initialized
DEBUG - 2020-08-24 15:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:10:47 --> Input Class Initialized
INFO - 2020-08-24 15:10:47 --> Language Class Initialized
INFO - 2020-08-24 15:10:47 --> Language Class Initialized
INFO - 2020-08-24 15:10:47 --> Config Class Initialized
INFO - 2020-08-24 15:10:47 --> Loader Class Initialized
INFO - 2020-08-24 15:10:47 --> Helper loaded: url_helper
INFO - 2020-08-24 15:10:47 --> Helper loaded: form_helper
INFO - 2020-08-24 15:10:47 --> Helper loaded: file_helper
INFO - 2020-08-24 15:10:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:10:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:10:47 --> Upload Class Initialized
INFO - 2020-08-24 15:10:47 --> Controller Class Initialized
DEBUG - 2020-08-24 15:10:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:10:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:10:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:10:47 --> Final output sent to browser
DEBUG - 2020-08-24 15:10:47 --> Total execution time: 0.0532
INFO - 2020-08-24 15:10:48 --> Config Class Initialized
INFO - 2020-08-24 15:10:48 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:10:48 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:10:48 --> Utf8 Class Initialized
INFO - 2020-08-24 15:10:48 --> URI Class Initialized
INFO - 2020-08-24 15:10:48 --> Router Class Initialized
INFO - 2020-08-24 15:10:48 --> Output Class Initialized
INFO - 2020-08-24 15:10:48 --> Security Class Initialized
DEBUG - 2020-08-24 15:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:10:48 --> Input Class Initialized
INFO - 2020-08-24 15:10:48 --> Language Class Initialized
INFO - 2020-08-24 15:10:48 --> Language Class Initialized
INFO - 2020-08-24 15:10:48 --> Config Class Initialized
INFO - 2020-08-24 15:10:48 --> Loader Class Initialized
INFO - 2020-08-24 15:10:48 --> Helper loaded: url_helper
INFO - 2020-08-24 15:10:48 --> Helper loaded: form_helper
INFO - 2020-08-24 15:10:48 --> Helper loaded: file_helper
INFO - 2020-08-24 15:10:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:10:48 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:10:48 --> Upload Class Initialized
INFO - 2020-08-24 15:10:48 --> Controller Class Initialized
ERROR - 2020-08-24 15:10:48 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:11:37 --> Config Class Initialized
INFO - 2020-08-24 15:11:37 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:11:37 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:11:37 --> Utf8 Class Initialized
INFO - 2020-08-24 15:11:37 --> URI Class Initialized
INFO - 2020-08-24 15:11:37 --> Router Class Initialized
INFO - 2020-08-24 15:11:37 --> Output Class Initialized
INFO - 2020-08-24 15:11:37 --> Security Class Initialized
DEBUG - 2020-08-24 15:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:11:37 --> Input Class Initialized
INFO - 2020-08-24 15:11:37 --> Language Class Initialized
INFO - 2020-08-24 15:11:37 --> Language Class Initialized
INFO - 2020-08-24 15:11:37 --> Config Class Initialized
INFO - 2020-08-24 15:11:37 --> Loader Class Initialized
INFO - 2020-08-24 15:11:37 --> Helper loaded: url_helper
INFO - 2020-08-24 15:11:37 --> Helper loaded: form_helper
INFO - 2020-08-24 15:11:37 --> Helper loaded: file_helper
INFO - 2020-08-24 15:11:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:11:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:11:38 --> Upload Class Initialized
INFO - 2020-08-24 15:11:38 --> Controller Class Initialized
DEBUG - 2020-08-24 15:11:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:11:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:11:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:11:38 --> Final output sent to browser
DEBUG - 2020-08-24 15:11:38 --> Total execution time: 0.0483
INFO - 2020-08-24 15:11:38 --> Config Class Initialized
INFO - 2020-08-24 15:11:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:11:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:11:38 --> Utf8 Class Initialized
INFO - 2020-08-24 15:11:38 --> URI Class Initialized
INFO - 2020-08-24 15:11:38 --> Router Class Initialized
INFO - 2020-08-24 15:11:38 --> Output Class Initialized
INFO - 2020-08-24 15:11:38 --> Security Class Initialized
DEBUG - 2020-08-24 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:11:38 --> Input Class Initialized
INFO - 2020-08-24 15:11:38 --> Language Class Initialized
INFO - 2020-08-24 15:11:38 --> Language Class Initialized
INFO - 2020-08-24 15:11:38 --> Config Class Initialized
INFO - 2020-08-24 15:11:38 --> Loader Class Initialized
INFO - 2020-08-24 15:11:38 --> Helper loaded: url_helper
INFO - 2020-08-24 15:11:38 --> Helper loaded: form_helper
INFO - 2020-08-24 15:11:38 --> Helper loaded: file_helper
INFO - 2020-08-24 15:11:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:11:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:11:38 --> Upload Class Initialized
INFO - 2020-08-24 15:11:38 --> Controller Class Initialized
DEBUG - 2020-08-24 15:11:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:11:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:11:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:11:38 --> Final output sent to browser
DEBUG - 2020-08-24 15:11:38 --> Total execution time: 0.0528
INFO - 2020-08-24 15:11:40 --> Config Class Initialized
INFO - 2020-08-24 15:11:40 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:11:40 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:11:40 --> Utf8 Class Initialized
INFO - 2020-08-24 15:11:40 --> URI Class Initialized
INFO - 2020-08-24 15:11:40 --> Router Class Initialized
INFO - 2020-08-24 15:11:40 --> Output Class Initialized
INFO - 2020-08-24 15:11:40 --> Security Class Initialized
DEBUG - 2020-08-24 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:11:40 --> Input Class Initialized
INFO - 2020-08-24 15:11:40 --> Language Class Initialized
INFO - 2020-08-24 15:11:40 --> Language Class Initialized
INFO - 2020-08-24 15:11:40 --> Config Class Initialized
INFO - 2020-08-24 15:11:40 --> Loader Class Initialized
INFO - 2020-08-24 15:11:40 --> Helper loaded: url_helper
INFO - 2020-08-24 15:11:40 --> Helper loaded: form_helper
INFO - 2020-08-24 15:11:40 --> Helper loaded: file_helper
INFO - 2020-08-24 15:11:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:11:40 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:11:40 --> Upload Class Initialized
INFO - 2020-08-24 15:11:40 --> Controller Class Initialized
ERROR - 2020-08-24 15:11:40 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:11:56 --> Config Class Initialized
INFO - 2020-08-24 15:11:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:11:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:11:56 --> Utf8 Class Initialized
INFO - 2020-08-24 15:11:56 --> URI Class Initialized
INFO - 2020-08-24 15:11:56 --> Router Class Initialized
INFO - 2020-08-24 15:11:56 --> Output Class Initialized
INFO - 2020-08-24 15:11:56 --> Security Class Initialized
DEBUG - 2020-08-24 15:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:11:56 --> Input Class Initialized
INFO - 2020-08-24 15:11:56 --> Language Class Initialized
INFO - 2020-08-24 15:11:56 --> Language Class Initialized
INFO - 2020-08-24 15:11:56 --> Config Class Initialized
INFO - 2020-08-24 15:11:56 --> Loader Class Initialized
INFO - 2020-08-24 15:11:56 --> Helper loaded: url_helper
INFO - 2020-08-24 15:11:56 --> Helper loaded: form_helper
INFO - 2020-08-24 15:11:56 --> Helper loaded: file_helper
INFO - 2020-08-24 15:11:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:11:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:11:56 --> Upload Class Initialized
INFO - 2020-08-24 15:11:56 --> Controller Class Initialized
DEBUG - 2020-08-24 15:11:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:11:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:11:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:11:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:11:56 --> Final output sent to browser
DEBUG - 2020-08-24 15:11:56 --> Total execution time: 0.0511
INFO - 2020-08-24 15:11:58 --> Config Class Initialized
INFO - 2020-08-24 15:11:58 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:11:58 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:11:58 --> Utf8 Class Initialized
INFO - 2020-08-24 15:11:58 --> URI Class Initialized
INFO - 2020-08-24 15:11:58 --> Router Class Initialized
INFO - 2020-08-24 15:11:58 --> Output Class Initialized
INFO - 2020-08-24 15:11:58 --> Security Class Initialized
DEBUG - 2020-08-24 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:11:58 --> Input Class Initialized
INFO - 2020-08-24 15:11:58 --> Language Class Initialized
INFO - 2020-08-24 15:11:58 --> Language Class Initialized
INFO - 2020-08-24 15:11:58 --> Config Class Initialized
INFO - 2020-08-24 15:11:58 --> Loader Class Initialized
INFO - 2020-08-24 15:11:58 --> Helper loaded: url_helper
INFO - 2020-08-24 15:11:58 --> Helper loaded: form_helper
INFO - 2020-08-24 15:11:58 --> Helper loaded: file_helper
INFO - 2020-08-24 15:11:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:11:58 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:11:58 --> Upload Class Initialized
INFO - 2020-08-24 15:11:58 --> Controller Class Initialized
ERROR - 2020-08-24 15:11:58 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:12:03 --> Config Class Initialized
INFO - 2020-08-24 15:12:03 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:12:03 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:12:03 --> Utf8 Class Initialized
INFO - 2020-08-24 15:12:03 --> URI Class Initialized
INFO - 2020-08-24 15:12:03 --> Router Class Initialized
INFO - 2020-08-24 15:12:03 --> Output Class Initialized
INFO - 2020-08-24 15:12:03 --> Security Class Initialized
DEBUG - 2020-08-24 15:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:12:03 --> Input Class Initialized
INFO - 2020-08-24 15:12:03 --> Language Class Initialized
INFO - 2020-08-24 15:12:03 --> Language Class Initialized
INFO - 2020-08-24 15:12:03 --> Config Class Initialized
INFO - 2020-08-24 15:12:03 --> Loader Class Initialized
INFO - 2020-08-24 15:12:03 --> Helper loaded: url_helper
INFO - 2020-08-24 15:12:03 --> Helper loaded: form_helper
INFO - 2020-08-24 15:12:03 --> Helper loaded: file_helper
INFO - 2020-08-24 15:12:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:12:03 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:12:03 --> Upload Class Initialized
INFO - 2020-08-24 15:12:03 --> Controller Class Initialized
DEBUG - 2020-08-24 15:12:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:12:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:12:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:12:03 --> Final output sent to browser
DEBUG - 2020-08-24 15:12:03 --> Total execution time: 0.0753
INFO - 2020-08-24 15:12:48 --> Config Class Initialized
INFO - 2020-08-24 15:12:48 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:12:48 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:12:48 --> Utf8 Class Initialized
INFO - 2020-08-24 15:12:48 --> URI Class Initialized
DEBUG - 2020-08-24 15:12:48 --> No URI present. Default controller set.
INFO - 2020-08-24 15:12:48 --> Router Class Initialized
INFO - 2020-08-24 15:12:48 --> Output Class Initialized
INFO - 2020-08-24 15:12:48 --> Security Class Initialized
DEBUG - 2020-08-24 15:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:12:48 --> Input Class Initialized
INFO - 2020-08-24 15:12:48 --> Language Class Initialized
INFO - 2020-08-24 15:12:48 --> Language Class Initialized
INFO - 2020-08-24 15:12:48 --> Config Class Initialized
INFO - 2020-08-24 15:12:48 --> Loader Class Initialized
INFO - 2020-08-24 15:12:48 --> Helper loaded: url_helper
INFO - 2020-08-24 15:12:48 --> Helper loaded: form_helper
INFO - 2020-08-24 15:12:48 --> Helper loaded: file_helper
INFO - 2020-08-24 15:12:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:12:48 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:12:48 --> Upload Class Initialized
INFO - 2020-08-24 15:12:48 --> Controller Class Initialized
DEBUG - 2020-08-24 15:12:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:12:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:12:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:12:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:12:48 --> Final output sent to browser
DEBUG - 2020-08-24 15:12:48 --> Total execution time: 0.0534
INFO - 2020-08-24 15:12:56 --> Config Class Initialized
INFO - 2020-08-24 15:12:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:12:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:12:56 --> Utf8 Class Initialized
INFO - 2020-08-24 15:12:56 --> URI Class Initialized
INFO - 2020-08-24 15:12:56 --> Router Class Initialized
INFO - 2020-08-24 15:12:56 --> Output Class Initialized
INFO - 2020-08-24 15:12:56 --> Security Class Initialized
DEBUG - 2020-08-24 15:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:12:56 --> Input Class Initialized
INFO - 2020-08-24 15:12:56 --> Language Class Initialized
INFO - 2020-08-24 15:12:56 --> Language Class Initialized
INFO - 2020-08-24 15:12:56 --> Config Class Initialized
INFO - 2020-08-24 15:12:56 --> Loader Class Initialized
INFO - 2020-08-24 15:12:56 --> Helper loaded: url_helper
INFO - 2020-08-24 15:12:56 --> Helper loaded: form_helper
INFO - 2020-08-24 15:12:56 --> Helper loaded: file_helper
INFO - 2020-08-24 15:12:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:12:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:12:56 --> Upload Class Initialized
INFO - 2020-08-24 15:12:56 --> Controller Class Initialized
ERROR - 2020-08-24 15:12:56 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:13:00 --> Config Class Initialized
INFO - 2020-08-24 15:13:00 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:00 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:00 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:00 --> URI Class Initialized
INFO - 2020-08-24 15:13:00 --> Router Class Initialized
INFO - 2020-08-24 15:13:00 --> Output Class Initialized
INFO - 2020-08-24 15:13:00 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:00 --> Input Class Initialized
INFO - 2020-08-24 15:13:00 --> Language Class Initialized
INFO - 2020-08-24 15:13:00 --> Language Class Initialized
INFO - 2020-08-24 15:13:00 --> Config Class Initialized
INFO - 2020-08-24 15:13:00 --> Loader Class Initialized
INFO - 2020-08-24 15:13:00 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:00 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:00 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:00 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:00 --> Upload Class Initialized
INFO - 2020-08-24 15:13:00 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:13:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:00 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:00 --> Total execution time: 0.0493
INFO - 2020-08-24 15:13:21 --> Config Class Initialized
INFO - 2020-08-24 15:13:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:21 --> URI Class Initialized
INFO - 2020-08-24 15:13:21 --> Router Class Initialized
INFO - 2020-08-24 15:13:21 --> Output Class Initialized
INFO - 2020-08-24 15:13:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:21 --> Input Class Initialized
INFO - 2020-08-24 15:13:21 --> Language Class Initialized
INFO - 2020-08-24 15:13:21 --> Language Class Initialized
INFO - 2020-08-24 15:13:21 --> Config Class Initialized
INFO - 2020-08-24 15:13:21 --> Loader Class Initialized
INFO - 2020-08-24 15:13:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:21 --> Upload Class Initialized
INFO - 2020-08-24 15:13:22 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:13:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:22 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:22 --> Total execution time: 0.0676
INFO - 2020-08-24 15:13:26 --> Config Class Initialized
INFO - 2020-08-24 15:13:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:26 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:26 --> URI Class Initialized
INFO - 2020-08-24 15:13:26 --> Router Class Initialized
INFO - 2020-08-24 15:13:26 --> Output Class Initialized
INFO - 2020-08-24 15:13:26 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:26 --> Input Class Initialized
INFO - 2020-08-24 15:13:26 --> Language Class Initialized
INFO - 2020-08-24 15:13:26 --> Language Class Initialized
INFO - 2020-08-24 15:13:26 --> Config Class Initialized
INFO - 2020-08-24 15:13:26 --> Loader Class Initialized
INFO - 2020-08-24 15:13:26 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:26 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:26 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:26 --> Upload Class Initialized
INFO - 2020-08-24 15:13:26 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:13:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:13:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:26 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:26 --> Total execution time: 0.0500
INFO - 2020-08-24 15:13:29 --> Config Class Initialized
INFO - 2020-08-24 15:13:29 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:29 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:29 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:29 --> URI Class Initialized
INFO - 2020-08-24 15:13:29 --> Router Class Initialized
INFO - 2020-08-24 15:13:29 --> Output Class Initialized
INFO - 2020-08-24 15:13:29 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:29 --> Input Class Initialized
INFO - 2020-08-24 15:13:29 --> Language Class Initialized
INFO - 2020-08-24 15:13:29 --> Language Class Initialized
INFO - 2020-08-24 15:13:29 --> Config Class Initialized
INFO - 2020-08-24 15:13:29 --> Loader Class Initialized
INFO - 2020-08-24 15:13:29 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:29 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:29 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:29 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:29 --> Upload Class Initialized
INFO - 2020-08-24 15:13:29 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:13:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:13:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:29 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:29 --> Total execution time: 0.0543
INFO - 2020-08-24 15:13:35 --> Config Class Initialized
INFO - 2020-08-24 15:13:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:35 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:35 --> URI Class Initialized
INFO - 2020-08-24 15:13:35 --> Router Class Initialized
INFO - 2020-08-24 15:13:35 --> Output Class Initialized
INFO - 2020-08-24 15:13:35 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:35 --> Input Class Initialized
INFO - 2020-08-24 15:13:35 --> Language Class Initialized
INFO - 2020-08-24 15:13:35 --> Language Class Initialized
INFO - 2020-08-24 15:13:35 --> Config Class Initialized
INFO - 2020-08-24 15:13:35 --> Loader Class Initialized
INFO - 2020-08-24 15:13:35 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:35 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:35 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:35 --> Upload Class Initialized
INFO - 2020-08-24 15:13:35 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:13:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:35 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:35 --> Total execution time: 0.0492
INFO - 2020-08-24 15:13:40 --> Config Class Initialized
INFO - 2020-08-24 15:13:40 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:40 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:40 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:40 --> URI Class Initialized
INFO - 2020-08-24 15:13:40 --> Router Class Initialized
INFO - 2020-08-24 15:13:40 --> Output Class Initialized
INFO - 2020-08-24 15:13:40 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:40 --> Input Class Initialized
INFO - 2020-08-24 15:13:40 --> Language Class Initialized
INFO - 2020-08-24 15:13:40 --> Language Class Initialized
INFO - 2020-08-24 15:13:40 --> Config Class Initialized
INFO - 2020-08-24 15:13:40 --> Loader Class Initialized
INFO - 2020-08-24 15:13:40 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:40 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:40 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:40 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:40 --> Upload Class Initialized
INFO - 2020-08-24 15:13:40 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:13:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:40 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:40 --> Total execution time: 0.0535
INFO - 2020-08-24 15:13:47 --> Config Class Initialized
INFO - 2020-08-24 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:47 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:47 --> URI Class Initialized
INFO - 2020-08-24 15:13:47 --> Router Class Initialized
INFO - 2020-08-24 15:13:47 --> Output Class Initialized
INFO - 2020-08-24 15:13:47 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:47 --> Input Class Initialized
INFO - 2020-08-24 15:13:47 --> Language Class Initialized
INFO - 2020-08-24 15:13:47 --> Language Class Initialized
INFO - 2020-08-24 15:13:47 --> Config Class Initialized
INFO - 2020-08-24 15:13:47 --> Loader Class Initialized
INFO - 2020-08-24 15:13:47 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:47 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:47 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:47 --> Upload Class Initialized
INFO - 2020-08-24 15:13:47 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:13:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:13:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:47 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:47 --> Total execution time: 0.0579
INFO - 2020-08-24 15:13:49 --> Config Class Initialized
INFO - 2020-08-24 15:13:49 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:49 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:49 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:49 --> URI Class Initialized
INFO - 2020-08-24 15:13:49 --> Router Class Initialized
INFO - 2020-08-24 15:13:49 --> Output Class Initialized
INFO - 2020-08-24 15:13:49 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:49 --> Input Class Initialized
INFO - 2020-08-24 15:13:49 --> Language Class Initialized
INFO - 2020-08-24 15:13:49 --> Language Class Initialized
INFO - 2020-08-24 15:13:49 --> Config Class Initialized
INFO - 2020-08-24 15:13:49 --> Loader Class Initialized
INFO - 2020-08-24 15:13:49 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:49 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:49 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:49 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:49 --> Upload Class Initialized
INFO - 2020-08-24 15:13:49 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:13:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:49 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:49 --> Total execution time: 0.0668
INFO - 2020-08-24 15:13:56 --> Config Class Initialized
INFO - 2020-08-24 15:13:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:13:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:13:56 --> Utf8 Class Initialized
INFO - 2020-08-24 15:13:56 --> URI Class Initialized
INFO - 2020-08-24 15:13:56 --> Router Class Initialized
INFO - 2020-08-24 15:13:56 --> Output Class Initialized
INFO - 2020-08-24 15:13:56 --> Security Class Initialized
DEBUG - 2020-08-24 15:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:13:56 --> Input Class Initialized
INFO - 2020-08-24 15:13:56 --> Language Class Initialized
INFO - 2020-08-24 15:13:56 --> Language Class Initialized
INFO - 2020-08-24 15:13:56 --> Config Class Initialized
INFO - 2020-08-24 15:13:56 --> Loader Class Initialized
INFO - 2020-08-24 15:13:56 --> Helper loaded: url_helper
INFO - 2020-08-24 15:13:56 --> Helper loaded: form_helper
INFO - 2020-08-24 15:13:56 --> Helper loaded: file_helper
INFO - 2020-08-24 15:13:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:13:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:13:56 --> Upload Class Initialized
INFO - 2020-08-24 15:13:56 --> Controller Class Initialized
DEBUG - 2020-08-24 15:13:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:13:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-24 15:13:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:13:56 --> Final output sent to browser
DEBUG - 2020-08-24 15:13:56 --> Total execution time: 0.0592
INFO - 2020-08-24 15:14:07 --> Config Class Initialized
INFO - 2020-08-24 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:14:07 --> Utf8 Class Initialized
INFO - 2020-08-24 15:14:07 --> URI Class Initialized
INFO - 2020-08-24 15:14:07 --> Router Class Initialized
INFO - 2020-08-24 15:14:07 --> Output Class Initialized
INFO - 2020-08-24 15:14:07 --> Security Class Initialized
DEBUG - 2020-08-24 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:14:07 --> Input Class Initialized
INFO - 2020-08-24 15:14:07 --> Language Class Initialized
INFO - 2020-08-24 15:14:07 --> Language Class Initialized
INFO - 2020-08-24 15:14:07 --> Config Class Initialized
INFO - 2020-08-24 15:14:07 --> Loader Class Initialized
INFO - 2020-08-24 15:14:07 --> Helper loaded: url_helper
INFO - 2020-08-24 15:14:07 --> Helper loaded: form_helper
INFO - 2020-08-24 15:14:07 --> Helper loaded: file_helper
INFO - 2020-08-24 15:14:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:14:07 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:14:07 --> Upload Class Initialized
INFO - 2020-08-24 15:14:07 --> Controller Class Initialized
DEBUG - 2020-08-24 15:14:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:14:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:14:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:14:07 --> Final output sent to browser
DEBUG - 2020-08-24 15:14:07 --> Total execution time: 0.0617
INFO - 2020-08-24 15:14:22 --> Config Class Initialized
INFO - 2020-08-24 15:14:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:14:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:14:22 --> Utf8 Class Initialized
INFO - 2020-08-24 15:14:22 --> URI Class Initialized
INFO - 2020-08-24 15:14:22 --> Router Class Initialized
INFO - 2020-08-24 15:14:22 --> Output Class Initialized
INFO - 2020-08-24 15:14:22 --> Security Class Initialized
DEBUG - 2020-08-24 15:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:14:22 --> Input Class Initialized
INFO - 2020-08-24 15:14:22 --> Language Class Initialized
INFO - 2020-08-24 15:14:22 --> Language Class Initialized
INFO - 2020-08-24 15:14:22 --> Config Class Initialized
INFO - 2020-08-24 15:14:22 --> Loader Class Initialized
INFO - 2020-08-24 15:14:22 --> Helper loaded: url_helper
INFO - 2020-08-24 15:14:22 --> Helper loaded: form_helper
INFO - 2020-08-24 15:14:22 --> Helper loaded: file_helper
INFO - 2020-08-24 15:14:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:14:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:14:22 --> Upload Class Initialized
INFO - 2020-08-24 15:14:22 --> Controller Class Initialized
DEBUG - 2020-08-24 15:14:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:14:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-24 15:14:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:14:22 --> Final output sent to browser
DEBUG - 2020-08-24 15:14:22 --> Total execution time: 0.0515
INFO - 2020-08-24 15:14:44 --> Config Class Initialized
INFO - 2020-08-24 15:14:44 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:14:44 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:14:44 --> Utf8 Class Initialized
INFO - 2020-08-24 15:14:44 --> URI Class Initialized
INFO - 2020-08-24 15:14:44 --> Router Class Initialized
INFO - 2020-08-24 15:14:44 --> Output Class Initialized
INFO - 2020-08-24 15:14:44 --> Security Class Initialized
DEBUG - 2020-08-24 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:14:44 --> Input Class Initialized
INFO - 2020-08-24 15:14:44 --> Language Class Initialized
INFO - 2020-08-24 15:14:44 --> Language Class Initialized
INFO - 2020-08-24 15:14:44 --> Config Class Initialized
INFO - 2020-08-24 15:14:44 --> Loader Class Initialized
INFO - 2020-08-24 15:14:44 --> Helper loaded: url_helper
INFO - 2020-08-24 15:14:44 --> Helper loaded: form_helper
INFO - 2020-08-24 15:14:44 --> Helper loaded: file_helper
INFO - 2020-08-24 15:14:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:14:44 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:14:44 --> Upload Class Initialized
INFO - 2020-08-24 15:14:44 --> Controller Class Initialized
DEBUG - 2020-08-24 15:14:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:14:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:14:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:14:44 --> Final output sent to browser
DEBUG - 2020-08-24 15:14:44 --> Total execution time: 0.0511
INFO - 2020-08-24 15:14:47 --> Config Class Initialized
INFO - 2020-08-24 15:14:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:14:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:14:47 --> Utf8 Class Initialized
INFO - 2020-08-24 15:14:47 --> URI Class Initialized
INFO - 2020-08-24 15:14:47 --> Router Class Initialized
INFO - 2020-08-24 15:14:47 --> Output Class Initialized
INFO - 2020-08-24 15:14:47 --> Security Class Initialized
DEBUG - 2020-08-24 15:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:14:47 --> Input Class Initialized
INFO - 2020-08-24 15:14:47 --> Language Class Initialized
INFO - 2020-08-24 15:14:47 --> Language Class Initialized
INFO - 2020-08-24 15:14:47 --> Config Class Initialized
INFO - 2020-08-24 15:14:47 --> Loader Class Initialized
INFO - 2020-08-24 15:14:47 --> Helper loaded: url_helper
INFO - 2020-08-24 15:14:47 --> Helper loaded: form_helper
INFO - 2020-08-24 15:14:47 --> Helper loaded: file_helper
INFO - 2020-08-24 15:14:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:14:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:14:47 --> Upload Class Initialized
INFO - 2020-08-24 15:14:47 --> Controller Class Initialized
DEBUG - 2020-08-24 15:14:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:14:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:14:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:14:47 --> Final output sent to browser
DEBUG - 2020-08-24 15:14:47 --> Total execution time: 0.0514
INFO - 2020-08-24 15:14:58 --> Config Class Initialized
INFO - 2020-08-24 15:14:58 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:14:58 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:14:58 --> Utf8 Class Initialized
INFO - 2020-08-24 15:14:58 --> URI Class Initialized
INFO - 2020-08-24 15:14:58 --> Router Class Initialized
INFO - 2020-08-24 15:14:58 --> Output Class Initialized
INFO - 2020-08-24 15:14:58 --> Security Class Initialized
DEBUG - 2020-08-24 15:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:14:58 --> Input Class Initialized
INFO - 2020-08-24 15:14:58 --> Language Class Initialized
INFO - 2020-08-24 15:14:58 --> Language Class Initialized
INFO - 2020-08-24 15:14:58 --> Config Class Initialized
INFO - 2020-08-24 15:14:58 --> Loader Class Initialized
INFO - 2020-08-24 15:14:58 --> Helper loaded: url_helper
INFO - 2020-08-24 15:14:58 --> Helper loaded: form_helper
INFO - 2020-08-24 15:14:58 --> Helper loaded: file_helper
INFO - 2020-08-24 15:14:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:14:58 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:14:58 --> Upload Class Initialized
INFO - 2020-08-24 15:14:58 --> Controller Class Initialized
DEBUG - 2020-08-24 15:14:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:14:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:14:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:14:58 --> Final output sent to browser
DEBUG - 2020-08-24 15:14:58 --> Total execution time: 0.0546
INFO - 2020-08-24 15:15:16 --> Config Class Initialized
INFO - 2020-08-24 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:15:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:15:16 --> URI Class Initialized
INFO - 2020-08-24 15:15:16 --> Router Class Initialized
INFO - 2020-08-24 15:15:16 --> Output Class Initialized
INFO - 2020-08-24 15:15:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:15:16 --> Input Class Initialized
INFO - 2020-08-24 15:15:16 --> Language Class Initialized
INFO - 2020-08-24 15:15:16 --> Language Class Initialized
INFO - 2020-08-24 15:15:16 --> Config Class Initialized
INFO - 2020-08-24 15:15:16 --> Loader Class Initialized
INFO - 2020-08-24 15:15:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:15:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:15:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:15:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:15:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:15:16 --> Upload Class Initialized
INFO - 2020-08-24 15:15:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:15:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:15:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:15:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:15:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:15:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:15:16 --> Total execution time: 0.0538
INFO - 2020-08-24 15:15:21 --> Config Class Initialized
INFO - 2020-08-24 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:15:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:15:21 --> URI Class Initialized
INFO - 2020-08-24 15:15:21 --> Router Class Initialized
INFO - 2020-08-24 15:15:21 --> Output Class Initialized
INFO - 2020-08-24 15:15:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:15:21 --> Input Class Initialized
INFO - 2020-08-24 15:15:21 --> Language Class Initialized
INFO - 2020-08-24 15:15:21 --> Language Class Initialized
INFO - 2020-08-24 15:15:21 --> Config Class Initialized
INFO - 2020-08-24 15:15:21 --> Loader Class Initialized
INFO - 2020-08-24 15:15:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:15:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:15:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:15:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:15:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:15:21 --> Upload Class Initialized
INFO - 2020-08-24 15:15:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:15:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:15:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:15:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:15:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:15:21 --> Total execution time: 0.0505
INFO - 2020-08-24 15:15:35 --> Config Class Initialized
INFO - 2020-08-24 15:15:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:15:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:15:35 --> Utf8 Class Initialized
INFO - 2020-08-24 15:15:35 --> URI Class Initialized
INFO - 2020-08-24 15:15:35 --> Router Class Initialized
INFO - 2020-08-24 15:15:35 --> Output Class Initialized
INFO - 2020-08-24 15:15:35 --> Security Class Initialized
DEBUG - 2020-08-24 15:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:15:35 --> Input Class Initialized
INFO - 2020-08-24 15:15:35 --> Language Class Initialized
INFO - 2020-08-24 15:15:35 --> Language Class Initialized
INFO - 2020-08-24 15:15:35 --> Config Class Initialized
INFO - 2020-08-24 15:15:35 --> Loader Class Initialized
INFO - 2020-08-24 15:15:35 --> Helper loaded: url_helper
INFO - 2020-08-24 15:15:35 --> Helper loaded: form_helper
INFO - 2020-08-24 15:15:35 --> Helper loaded: file_helper
INFO - 2020-08-24 15:15:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:15:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:15:35 --> Upload Class Initialized
INFO - 2020-08-24 15:15:35 --> Controller Class Initialized
DEBUG - 2020-08-24 15:15:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:15:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:15:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:15:35 --> Final output sent to browser
DEBUG - 2020-08-24 15:15:35 --> Total execution time: 0.0750
INFO - 2020-08-24 15:15:42 --> Config Class Initialized
INFO - 2020-08-24 15:15:42 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:15:42 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:15:42 --> Utf8 Class Initialized
INFO - 2020-08-24 15:15:42 --> URI Class Initialized
INFO - 2020-08-24 15:15:42 --> Router Class Initialized
INFO - 2020-08-24 15:15:42 --> Output Class Initialized
INFO - 2020-08-24 15:15:42 --> Security Class Initialized
DEBUG - 2020-08-24 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:15:42 --> Input Class Initialized
INFO - 2020-08-24 15:15:42 --> Language Class Initialized
INFO - 2020-08-24 15:15:42 --> Language Class Initialized
INFO - 2020-08-24 15:15:42 --> Config Class Initialized
INFO - 2020-08-24 15:15:42 --> Loader Class Initialized
INFO - 2020-08-24 15:15:42 --> Helper loaded: url_helper
INFO - 2020-08-24 15:15:42 --> Helper loaded: form_helper
INFO - 2020-08-24 15:15:42 --> Helper loaded: file_helper
INFO - 2020-08-24 15:15:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:15:42 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:15:42 --> Upload Class Initialized
INFO - 2020-08-24 15:15:42 --> Controller Class Initialized
DEBUG - 2020-08-24 15:15:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:15:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:15:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:15:42 --> Final output sent to browser
DEBUG - 2020-08-24 15:15:42 --> Total execution time: 0.0527
INFO - 2020-08-24 15:16:11 --> Config Class Initialized
INFO - 2020-08-24 15:16:11 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:11 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:11 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:11 --> URI Class Initialized
INFO - 2020-08-24 15:16:11 --> Router Class Initialized
INFO - 2020-08-24 15:16:11 --> Output Class Initialized
INFO - 2020-08-24 15:16:11 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:11 --> Input Class Initialized
INFO - 2020-08-24 15:16:11 --> Language Class Initialized
INFO - 2020-08-24 15:16:11 --> Language Class Initialized
INFO - 2020-08-24 15:16:11 --> Config Class Initialized
INFO - 2020-08-24 15:16:11 --> Loader Class Initialized
INFO - 2020-08-24 15:16:11 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:11 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:11 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:11 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:11 --> Upload Class Initialized
INFO - 2020-08-24 15:16:12 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:16:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:12 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:12 --> Total execution time: 0.0560
INFO - 2020-08-24 15:16:13 --> Config Class Initialized
INFO - 2020-08-24 15:16:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:13 --> URI Class Initialized
INFO - 2020-08-24 15:16:13 --> Router Class Initialized
INFO - 2020-08-24 15:16:13 --> Output Class Initialized
INFO - 2020-08-24 15:16:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:13 --> Input Class Initialized
INFO - 2020-08-24 15:16:13 --> Language Class Initialized
INFO - 2020-08-24 15:16:13 --> Language Class Initialized
INFO - 2020-08-24 15:16:13 --> Config Class Initialized
INFO - 2020-08-24 15:16:13 --> Loader Class Initialized
INFO - 2020-08-24 15:16:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:13 --> Upload Class Initialized
INFO - 2020-08-24 15:16:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:13 --> Total execution time: 0.0645
INFO - 2020-08-24 15:16:16 --> Config Class Initialized
INFO - 2020-08-24 15:16:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:16 --> URI Class Initialized
INFO - 2020-08-24 15:16:16 --> Router Class Initialized
INFO - 2020-08-24 15:16:16 --> Output Class Initialized
INFO - 2020-08-24 15:16:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:16 --> Input Class Initialized
INFO - 2020-08-24 15:16:16 --> Language Class Initialized
INFO - 2020-08-24 15:16:16 --> Language Class Initialized
INFO - 2020-08-24 15:16:16 --> Config Class Initialized
INFO - 2020-08-24 15:16:16 --> Loader Class Initialized
INFO - 2020-08-24 15:16:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:16 --> Upload Class Initialized
INFO - 2020-08-24 15:16:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 15:16:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:16 --> Total execution time: 0.0490
INFO - 2020-08-24 15:16:22 --> Config Class Initialized
INFO - 2020-08-24 15:16:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:22 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:22 --> URI Class Initialized
INFO - 2020-08-24 15:16:22 --> Router Class Initialized
INFO - 2020-08-24 15:16:22 --> Output Class Initialized
INFO - 2020-08-24 15:16:22 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:22 --> Input Class Initialized
INFO - 2020-08-24 15:16:22 --> Language Class Initialized
INFO - 2020-08-24 15:16:22 --> Language Class Initialized
INFO - 2020-08-24 15:16:22 --> Config Class Initialized
INFO - 2020-08-24 15:16:22 --> Loader Class Initialized
INFO - 2020-08-24 15:16:22 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:22 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:22 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:22 --> Upload Class Initialized
INFO - 2020-08-24 15:16:22 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:22 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:22 --> Total execution time: 0.0519
INFO - 2020-08-24 15:16:24 --> Config Class Initialized
INFO - 2020-08-24 15:16:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:24 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:24 --> URI Class Initialized
INFO - 2020-08-24 15:16:24 --> Router Class Initialized
INFO - 2020-08-24 15:16:24 --> Output Class Initialized
INFO - 2020-08-24 15:16:24 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:24 --> Input Class Initialized
INFO - 2020-08-24 15:16:24 --> Language Class Initialized
INFO - 2020-08-24 15:16:24 --> Language Class Initialized
INFO - 2020-08-24 15:16:24 --> Config Class Initialized
INFO - 2020-08-24 15:16:24 --> Loader Class Initialized
INFO - 2020-08-24 15:16:24 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:24 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:24 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:24 --> Upload Class Initialized
INFO - 2020-08-24 15:16:24 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:24 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:24 --> Total execution time: 0.0570
INFO - 2020-08-24 15:16:27 --> Config Class Initialized
INFO - 2020-08-24 15:16:27 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:27 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:27 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:27 --> URI Class Initialized
INFO - 2020-08-24 15:16:27 --> Router Class Initialized
INFO - 2020-08-24 15:16:27 --> Output Class Initialized
INFO - 2020-08-24 15:16:27 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:27 --> Input Class Initialized
INFO - 2020-08-24 15:16:27 --> Language Class Initialized
INFO - 2020-08-24 15:16:27 --> Language Class Initialized
INFO - 2020-08-24 15:16:27 --> Config Class Initialized
INFO - 2020-08-24 15:16:27 --> Loader Class Initialized
INFO - 2020-08-24 15:16:27 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:27 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:27 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:27 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:27 --> Upload Class Initialized
INFO - 2020-08-24 15:16:27 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:27 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:27 --> Total execution time: 0.0620
INFO - 2020-08-24 15:16:30 --> Config Class Initialized
INFO - 2020-08-24 15:16:30 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:30 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:30 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:30 --> URI Class Initialized
INFO - 2020-08-24 15:16:30 --> Router Class Initialized
INFO - 2020-08-24 15:16:30 --> Output Class Initialized
INFO - 2020-08-24 15:16:30 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:30 --> Input Class Initialized
INFO - 2020-08-24 15:16:30 --> Language Class Initialized
INFO - 2020-08-24 15:16:30 --> Language Class Initialized
INFO - 2020-08-24 15:16:30 --> Config Class Initialized
INFO - 2020-08-24 15:16:30 --> Loader Class Initialized
INFO - 2020-08-24 15:16:30 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:30 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:30 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:30 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:30 --> Upload Class Initialized
INFO - 2020-08-24 15:16:30 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:30 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:30 --> Total execution time: 0.0520
INFO - 2020-08-24 15:16:49 --> Config Class Initialized
INFO - 2020-08-24 15:16:49 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:49 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:49 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:49 --> URI Class Initialized
INFO - 2020-08-24 15:16:49 --> Router Class Initialized
INFO - 2020-08-24 15:16:49 --> Output Class Initialized
INFO - 2020-08-24 15:16:49 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:49 --> Input Class Initialized
INFO - 2020-08-24 15:16:49 --> Language Class Initialized
INFO - 2020-08-24 15:16:49 --> Language Class Initialized
INFO - 2020-08-24 15:16:49 --> Config Class Initialized
INFO - 2020-08-24 15:16:49 --> Loader Class Initialized
INFO - 2020-08-24 15:16:49 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:49 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:49 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:49 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:49 --> Upload Class Initialized
INFO - 2020-08-24 15:16:49 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:49 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:49 --> Total execution time: 0.0613
INFO - 2020-08-24 15:16:55 --> Config Class Initialized
INFO - 2020-08-24 15:16:55 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:16:55 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:16:55 --> Utf8 Class Initialized
INFO - 2020-08-24 15:16:55 --> URI Class Initialized
INFO - 2020-08-24 15:16:55 --> Router Class Initialized
INFO - 2020-08-24 15:16:55 --> Output Class Initialized
INFO - 2020-08-24 15:16:55 --> Security Class Initialized
DEBUG - 2020-08-24 15:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:16:55 --> Input Class Initialized
INFO - 2020-08-24 15:16:55 --> Language Class Initialized
INFO - 2020-08-24 15:16:55 --> Language Class Initialized
INFO - 2020-08-24 15:16:55 --> Config Class Initialized
INFO - 2020-08-24 15:16:55 --> Loader Class Initialized
INFO - 2020-08-24 15:16:55 --> Helper loaded: url_helper
INFO - 2020-08-24 15:16:55 --> Helper loaded: form_helper
INFO - 2020-08-24 15:16:55 --> Helper loaded: file_helper
INFO - 2020-08-24 15:16:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:16:55 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:16:55 --> Upload Class Initialized
INFO - 2020-08-24 15:16:55 --> Controller Class Initialized
DEBUG - 2020-08-24 15:16:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:16:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:16:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:16:55 --> Final output sent to browser
DEBUG - 2020-08-24 15:16:55 --> Total execution time: 0.0570
INFO - 2020-08-24 15:17:19 --> Config Class Initialized
INFO - 2020-08-24 15:17:19 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:17:19 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:17:19 --> Utf8 Class Initialized
INFO - 2020-08-24 15:17:19 --> URI Class Initialized
INFO - 2020-08-24 15:17:19 --> Router Class Initialized
INFO - 2020-08-24 15:17:19 --> Output Class Initialized
INFO - 2020-08-24 15:17:19 --> Security Class Initialized
DEBUG - 2020-08-24 15:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:17:19 --> Input Class Initialized
INFO - 2020-08-24 15:17:19 --> Language Class Initialized
INFO - 2020-08-24 15:17:19 --> Language Class Initialized
INFO - 2020-08-24 15:17:19 --> Config Class Initialized
INFO - 2020-08-24 15:17:19 --> Loader Class Initialized
INFO - 2020-08-24 15:17:19 --> Helper loaded: url_helper
INFO - 2020-08-24 15:17:19 --> Helper loaded: form_helper
INFO - 2020-08-24 15:17:19 --> Helper loaded: file_helper
INFO - 2020-08-24 15:17:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:17:19 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:17:19 --> Upload Class Initialized
INFO - 2020-08-24 15:17:19 --> Controller Class Initialized
DEBUG - 2020-08-24 15:17:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:17:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:17:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:17:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:17:19 --> Final output sent to browser
DEBUG - 2020-08-24 15:17:19 --> Total execution time: 0.0538
INFO - 2020-08-24 15:17:24 --> Config Class Initialized
INFO - 2020-08-24 15:17:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:17:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:17:24 --> Utf8 Class Initialized
INFO - 2020-08-24 15:17:24 --> URI Class Initialized
INFO - 2020-08-24 15:17:24 --> Router Class Initialized
INFO - 2020-08-24 15:17:24 --> Output Class Initialized
INFO - 2020-08-24 15:17:24 --> Security Class Initialized
DEBUG - 2020-08-24 15:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:17:24 --> Input Class Initialized
INFO - 2020-08-24 15:17:24 --> Language Class Initialized
INFO - 2020-08-24 15:17:24 --> Language Class Initialized
INFO - 2020-08-24 15:17:24 --> Config Class Initialized
INFO - 2020-08-24 15:17:24 --> Loader Class Initialized
INFO - 2020-08-24 15:17:24 --> Helper loaded: url_helper
INFO - 2020-08-24 15:17:24 --> Helper loaded: form_helper
INFO - 2020-08-24 15:17:24 --> Helper loaded: file_helper
INFO - 2020-08-24 15:17:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:17:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:17:24 --> Upload Class Initialized
INFO - 2020-08-24 15:17:24 --> Controller Class Initialized
DEBUG - 2020-08-24 15:17:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:17:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:17:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:17:24 --> Final output sent to browser
DEBUG - 2020-08-24 15:17:24 --> Total execution time: 0.0497
INFO - 2020-08-24 15:17:47 --> Config Class Initialized
INFO - 2020-08-24 15:17:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:17:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:17:47 --> Utf8 Class Initialized
INFO - 2020-08-24 15:17:47 --> URI Class Initialized
INFO - 2020-08-24 15:17:47 --> Router Class Initialized
INFO - 2020-08-24 15:17:47 --> Output Class Initialized
INFO - 2020-08-24 15:17:47 --> Security Class Initialized
DEBUG - 2020-08-24 15:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:17:47 --> Input Class Initialized
INFO - 2020-08-24 15:17:47 --> Language Class Initialized
INFO - 2020-08-24 15:17:47 --> Language Class Initialized
INFO - 2020-08-24 15:17:47 --> Config Class Initialized
INFO - 2020-08-24 15:17:47 --> Loader Class Initialized
INFO - 2020-08-24 15:17:47 --> Helper loaded: url_helper
INFO - 2020-08-24 15:17:47 --> Helper loaded: form_helper
INFO - 2020-08-24 15:17:47 --> Helper loaded: file_helper
INFO - 2020-08-24 15:17:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:17:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:17:47 --> Upload Class Initialized
INFO - 2020-08-24 15:17:47 --> Controller Class Initialized
DEBUG - 2020-08-24 15:17:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:17:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:17:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:17:47 --> Final output sent to browser
DEBUG - 2020-08-24 15:17:47 --> Total execution time: 0.0540
INFO - 2020-08-24 15:17:53 --> Config Class Initialized
INFO - 2020-08-24 15:17:53 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:17:53 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:17:53 --> Utf8 Class Initialized
INFO - 2020-08-24 15:17:53 --> URI Class Initialized
INFO - 2020-08-24 15:17:53 --> Router Class Initialized
INFO - 2020-08-24 15:17:53 --> Output Class Initialized
INFO - 2020-08-24 15:17:53 --> Security Class Initialized
DEBUG - 2020-08-24 15:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:17:53 --> Input Class Initialized
INFO - 2020-08-24 15:17:53 --> Language Class Initialized
INFO - 2020-08-24 15:17:53 --> Language Class Initialized
INFO - 2020-08-24 15:17:53 --> Config Class Initialized
INFO - 2020-08-24 15:17:53 --> Loader Class Initialized
INFO - 2020-08-24 15:17:53 --> Helper loaded: url_helper
INFO - 2020-08-24 15:17:53 --> Helper loaded: form_helper
INFO - 2020-08-24 15:17:53 --> Helper loaded: file_helper
INFO - 2020-08-24 15:17:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:17:53 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:17:53 --> Upload Class Initialized
INFO - 2020-08-24 15:17:53 --> Controller Class Initialized
DEBUG - 2020-08-24 15:17:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:17:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 15:17:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:17:53 --> Final output sent to browser
DEBUG - 2020-08-24 15:17:53 --> Total execution time: 0.0489
INFO - 2020-08-24 15:17:56 --> Config Class Initialized
INFO - 2020-08-24 15:17:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:17:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:17:56 --> Utf8 Class Initialized
INFO - 2020-08-24 15:17:56 --> URI Class Initialized
INFO - 2020-08-24 15:17:56 --> Router Class Initialized
INFO - 2020-08-24 15:17:56 --> Output Class Initialized
INFO - 2020-08-24 15:17:56 --> Security Class Initialized
DEBUG - 2020-08-24 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:17:56 --> Input Class Initialized
INFO - 2020-08-24 15:17:56 --> Language Class Initialized
INFO - 2020-08-24 15:17:56 --> Language Class Initialized
INFO - 2020-08-24 15:17:56 --> Config Class Initialized
INFO - 2020-08-24 15:17:56 --> Loader Class Initialized
INFO - 2020-08-24 15:17:56 --> Helper loaded: url_helper
INFO - 2020-08-24 15:17:56 --> Helper loaded: form_helper
INFO - 2020-08-24 15:17:56 --> Helper loaded: file_helper
INFO - 2020-08-24 15:17:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:17:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:17:56 --> Upload Class Initialized
INFO - 2020-08-24 15:17:56 --> Controller Class Initialized
DEBUG - 2020-08-24 15:17:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:17:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:17:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:17:56 --> Final output sent to browser
DEBUG - 2020-08-24 15:17:56 --> Total execution time: 0.0524
INFO - 2020-08-24 15:18:08 --> Config Class Initialized
INFO - 2020-08-24 15:18:08 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:18:08 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:18:08 --> Utf8 Class Initialized
INFO - 2020-08-24 15:18:08 --> URI Class Initialized
INFO - 2020-08-24 15:18:08 --> Router Class Initialized
INFO - 2020-08-24 15:18:08 --> Output Class Initialized
INFO - 2020-08-24 15:18:08 --> Security Class Initialized
DEBUG - 2020-08-24 15:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:18:08 --> Input Class Initialized
INFO - 2020-08-24 15:18:08 --> Language Class Initialized
INFO - 2020-08-24 15:18:08 --> Language Class Initialized
INFO - 2020-08-24 15:18:08 --> Config Class Initialized
INFO - 2020-08-24 15:18:08 --> Loader Class Initialized
INFO - 2020-08-24 15:18:08 --> Helper loaded: url_helper
INFO - 2020-08-24 15:18:08 --> Helper loaded: form_helper
INFO - 2020-08-24 15:18:08 --> Helper loaded: file_helper
INFO - 2020-08-24 15:18:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:18:08 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:18:08 --> Upload Class Initialized
INFO - 2020-08-24 15:18:08 --> Controller Class Initialized
DEBUG - 2020-08-24 15:18:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:18:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:18:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:18:08 --> Final output sent to browser
DEBUG - 2020-08-24 15:18:08 --> Total execution time: 0.0544
INFO - 2020-08-24 15:21:32 --> Config Class Initialized
INFO - 2020-08-24 15:21:32 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:21:32 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:21:32 --> Utf8 Class Initialized
INFO - 2020-08-24 15:21:32 --> URI Class Initialized
INFO - 2020-08-24 15:21:32 --> Router Class Initialized
INFO - 2020-08-24 15:21:32 --> Output Class Initialized
INFO - 2020-08-24 15:21:32 --> Security Class Initialized
DEBUG - 2020-08-24 15:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:21:32 --> Input Class Initialized
INFO - 2020-08-24 15:21:32 --> Language Class Initialized
INFO - 2020-08-24 15:21:32 --> Language Class Initialized
INFO - 2020-08-24 15:21:32 --> Config Class Initialized
INFO - 2020-08-24 15:21:32 --> Loader Class Initialized
INFO - 2020-08-24 15:21:32 --> Helper loaded: url_helper
INFO - 2020-08-24 15:21:32 --> Helper loaded: form_helper
INFO - 2020-08-24 15:21:32 --> Helper loaded: file_helper
INFO - 2020-08-24 15:21:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:21:32 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:21:32 --> Upload Class Initialized
INFO - 2020-08-24 15:21:32 --> Controller Class Initialized
DEBUG - 2020-08-24 15:21:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:21:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:21:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:21:32 --> Final output sent to browser
DEBUG - 2020-08-24 15:21:32 --> Total execution time: 0.0509
INFO - 2020-08-24 15:21:40 --> Config Class Initialized
INFO - 2020-08-24 15:21:40 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:21:40 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:21:40 --> Utf8 Class Initialized
INFO - 2020-08-24 15:21:40 --> URI Class Initialized
INFO - 2020-08-24 15:21:40 --> Router Class Initialized
INFO - 2020-08-24 15:21:40 --> Output Class Initialized
INFO - 2020-08-24 15:21:40 --> Security Class Initialized
DEBUG - 2020-08-24 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:21:40 --> Input Class Initialized
INFO - 2020-08-24 15:21:40 --> Language Class Initialized
INFO - 2020-08-24 15:21:40 --> Language Class Initialized
INFO - 2020-08-24 15:21:40 --> Config Class Initialized
INFO - 2020-08-24 15:21:40 --> Loader Class Initialized
INFO - 2020-08-24 15:21:40 --> Helper loaded: url_helper
INFO - 2020-08-24 15:21:40 --> Helper loaded: form_helper
INFO - 2020-08-24 15:21:40 --> Helper loaded: file_helper
INFO - 2020-08-24 15:21:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:21:40 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:21:40 --> Upload Class Initialized
INFO - 2020-08-24 15:21:40 --> Controller Class Initialized
DEBUG - 2020-08-24 15:21:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:21:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:21:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:21:40 --> Final output sent to browser
DEBUG - 2020-08-24 15:21:40 --> Total execution time: 0.0628
INFO - 2020-08-24 15:21:41 --> Config Class Initialized
INFO - 2020-08-24 15:21:41 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:21:41 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:21:41 --> Utf8 Class Initialized
INFO - 2020-08-24 15:21:41 --> URI Class Initialized
INFO - 2020-08-24 15:21:41 --> Router Class Initialized
INFO - 2020-08-24 15:21:41 --> Output Class Initialized
INFO - 2020-08-24 15:21:41 --> Security Class Initialized
DEBUG - 2020-08-24 15:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:21:41 --> Input Class Initialized
INFO - 2020-08-24 15:21:41 --> Language Class Initialized
INFO - 2020-08-24 15:21:41 --> Language Class Initialized
INFO - 2020-08-24 15:21:41 --> Config Class Initialized
INFO - 2020-08-24 15:21:41 --> Loader Class Initialized
INFO - 2020-08-24 15:21:41 --> Helper loaded: url_helper
INFO - 2020-08-24 15:21:41 --> Helper loaded: form_helper
INFO - 2020-08-24 15:21:41 --> Helper loaded: file_helper
INFO - 2020-08-24 15:21:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:21:41 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:21:41 --> Upload Class Initialized
INFO - 2020-08-24 15:21:42 --> Controller Class Initialized
DEBUG - 2020-08-24 15:21:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:21:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:21:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:21:42 --> Final output sent to browser
DEBUG - 2020-08-24 15:21:42 --> Total execution time: 0.0848
INFO - 2020-08-24 15:21:46 --> Config Class Initialized
INFO - 2020-08-24 15:21:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:21:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:21:46 --> Utf8 Class Initialized
INFO - 2020-08-24 15:21:46 --> URI Class Initialized
INFO - 2020-08-24 15:21:46 --> Router Class Initialized
INFO - 2020-08-24 15:21:46 --> Output Class Initialized
INFO - 2020-08-24 15:21:46 --> Security Class Initialized
DEBUG - 2020-08-24 15:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:21:46 --> Input Class Initialized
INFO - 2020-08-24 15:21:46 --> Language Class Initialized
INFO - 2020-08-24 15:21:46 --> Language Class Initialized
INFO - 2020-08-24 15:21:46 --> Config Class Initialized
INFO - 2020-08-24 15:21:46 --> Loader Class Initialized
INFO - 2020-08-24 15:21:46 --> Helper loaded: url_helper
INFO - 2020-08-24 15:21:46 --> Helper loaded: form_helper
INFO - 2020-08-24 15:21:46 --> Helper loaded: file_helper
INFO - 2020-08-24 15:21:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:21:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:21:46 --> Upload Class Initialized
INFO - 2020-08-24 15:21:46 --> Controller Class Initialized
DEBUG - 2020-08-24 15:21:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:21:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:21:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:21:46 --> Final output sent to browser
DEBUG - 2020-08-24 15:21:46 --> Total execution time: 0.0619
INFO - 2020-08-24 15:21:52 --> Config Class Initialized
INFO - 2020-08-24 15:21:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:21:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:21:52 --> Utf8 Class Initialized
INFO - 2020-08-24 15:21:52 --> URI Class Initialized
INFO - 2020-08-24 15:21:52 --> Router Class Initialized
INFO - 2020-08-24 15:21:52 --> Output Class Initialized
INFO - 2020-08-24 15:21:52 --> Security Class Initialized
DEBUG - 2020-08-24 15:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:21:52 --> Input Class Initialized
INFO - 2020-08-24 15:21:52 --> Language Class Initialized
INFO - 2020-08-24 15:21:52 --> Language Class Initialized
INFO - 2020-08-24 15:21:52 --> Config Class Initialized
INFO - 2020-08-24 15:21:52 --> Loader Class Initialized
INFO - 2020-08-24 15:21:52 --> Helper loaded: url_helper
INFO - 2020-08-24 15:21:52 --> Helper loaded: form_helper
INFO - 2020-08-24 15:21:52 --> Helper loaded: file_helper
INFO - 2020-08-24 15:21:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:21:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:21:52 --> Upload Class Initialized
INFO - 2020-08-24 15:21:52 --> Controller Class Initialized
DEBUG - 2020-08-24 15:21:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:21:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:21:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:21:52 --> Final output sent to browser
DEBUG - 2020-08-24 15:21:52 --> Total execution time: 0.0507
INFO - 2020-08-24 15:22:06 --> Config Class Initialized
INFO - 2020-08-24 15:22:06 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:22:06 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:22:06 --> Utf8 Class Initialized
INFO - 2020-08-24 15:22:06 --> URI Class Initialized
INFO - 2020-08-24 15:22:06 --> Router Class Initialized
INFO - 2020-08-24 15:22:06 --> Output Class Initialized
INFO - 2020-08-24 15:22:06 --> Security Class Initialized
DEBUG - 2020-08-24 15:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:22:06 --> Input Class Initialized
INFO - 2020-08-24 15:22:06 --> Language Class Initialized
INFO - 2020-08-24 15:22:06 --> Language Class Initialized
INFO - 2020-08-24 15:22:06 --> Config Class Initialized
INFO - 2020-08-24 15:22:06 --> Loader Class Initialized
INFO - 2020-08-24 15:22:06 --> Helper loaded: url_helper
INFO - 2020-08-24 15:22:06 --> Helper loaded: form_helper
INFO - 2020-08-24 15:22:06 --> Helper loaded: file_helper
INFO - 2020-08-24 15:22:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:22:06 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:22:06 --> Upload Class Initialized
INFO - 2020-08-24 15:22:06 --> Controller Class Initialized
DEBUG - 2020-08-24 15:22:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:22:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:22:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:22:06 --> Final output sent to browser
DEBUG - 2020-08-24 15:22:06 --> Total execution time: 0.0573
INFO - 2020-08-24 15:22:59 --> Config Class Initialized
INFO - 2020-08-24 15:22:59 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:22:59 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:22:59 --> Utf8 Class Initialized
INFO - 2020-08-24 15:22:59 --> URI Class Initialized
INFO - 2020-08-24 15:22:59 --> Router Class Initialized
INFO - 2020-08-24 15:22:59 --> Output Class Initialized
INFO - 2020-08-24 15:22:59 --> Security Class Initialized
DEBUG - 2020-08-24 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:22:59 --> Input Class Initialized
INFO - 2020-08-24 15:22:59 --> Language Class Initialized
INFO - 2020-08-24 15:22:59 --> Language Class Initialized
INFO - 2020-08-24 15:22:59 --> Config Class Initialized
INFO - 2020-08-24 15:22:59 --> Loader Class Initialized
INFO - 2020-08-24 15:22:59 --> Helper loaded: url_helper
INFO - 2020-08-24 15:22:59 --> Helper loaded: form_helper
INFO - 2020-08-24 15:22:59 --> Helper loaded: file_helper
INFO - 2020-08-24 15:22:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:22:59 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:22:59 --> Upload Class Initialized
INFO - 2020-08-24 15:22:59 --> Controller Class Initialized
DEBUG - 2020-08-24 15:22:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:22:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:22:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:22:59 --> Final output sent to browser
DEBUG - 2020-08-24 15:22:59 --> Total execution time: 0.0528
INFO - 2020-08-24 15:23:02 --> Config Class Initialized
INFO - 2020-08-24 15:23:02 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:23:02 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:23:02 --> Utf8 Class Initialized
INFO - 2020-08-24 15:23:02 --> URI Class Initialized
INFO - 2020-08-24 15:23:02 --> Router Class Initialized
INFO - 2020-08-24 15:23:02 --> Output Class Initialized
INFO - 2020-08-24 15:23:02 --> Security Class Initialized
DEBUG - 2020-08-24 15:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:23:02 --> Input Class Initialized
INFO - 2020-08-24 15:23:02 --> Language Class Initialized
INFO - 2020-08-24 15:23:02 --> Language Class Initialized
INFO - 2020-08-24 15:23:02 --> Config Class Initialized
INFO - 2020-08-24 15:23:02 --> Loader Class Initialized
INFO - 2020-08-24 15:23:02 --> Helper loaded: url_helper
INFO - 2020-08-24 15:23:02 --> Helper loaded: form_helper
INFO - 2020-08-24 15:23:02 --> Helper loaded: file_helper
INFO - 2020-08-24 15:23:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:23:02 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:23:02 --> Upload Class Initialized
INFO - 2020-08-24 15:23:02 --> Controller Class Initialized
DEBUG - 2020-08-24 15:23:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:23:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:23:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:23:02 --> Final output sent to browser
DEBUG - 2020-08-24 15:23:02 --> Total execution time: 0.1995
INFO - 2020-08-24 15:23:04 --> Config Class Initialized
INFO - 2020-08-24 15:23:04 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:23:04 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:23:04 --> Utf8 Class Initialized
INFO - 2020-08-24 15:23:04 --> URI Class Initialized
INFO - 2020-08-24 15:23:04 --> Router Class Initialized
INFO - 2020-08-24 15:23:04 --> Output Class Initialized
INFO - 2020-08-24 15:23:04 --> Security Class Initialized
DEBUG - 2020-08-24 15:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:23:04 --> Input Class Initialized
INFO - 2020-08-24 15:23:04 --> Language Class Initialized
INFO - 2020-08-24 15:23:04 --> Language Class Initialized
INFO - 2020-08-24 15:23:04 --> Config Class Initialized
INFO - 2020-08-24 15:23:04 --> Loader Class Initialized
INFO - 2020-08-24 15:23:04 --> Helper loaded: url_helper
INFO - 2020-08-24 15:23:04 --> Helper loaded: form_helper
INFO - 2020-08-24 15:23:04 --> Helper loaded: file_helper
INFO - 2020-08-24 15:23:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:23:04 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:23:04 --> Upload Class Initialized
INFO - 2020-08-24 15:23:04 --> Controller Class Initialized
DEBUG - 2020-08-24 15:23:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:23:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:23:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:23:04 --> Final output sent to browser
DEBUG - 2020-08-24 15:23:04 --> Total execution time: 0.0717
INFO - 2020-08-24 15:23:09 --> Config Class Initialized
INFO - 2020-08-24 15:23:09 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:23:09 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:23:09 --> Utf8 Class Initialized
INFO - 2020-08-24 15:23:09 --> URI Class Initialized
INFO - 2020-08-24 15:23:09 --> Router Class Initialized
INFO - 2020-08-24 15:23:09 --> Output Class Initialized
INFO - 2020-08-24 15:23:09 --> Security Class Initialized
DEBUG - 2020-08-24 15:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:23:09 --> Input Class Initialized
INFO - 2020-08-24 15:23:09 --> Language Class Initialized
INFO - 2020-08-24 15:23:09 --> Language Class Initialized
INFO - 2020-08-24 15:23:09 --> Config Class Initialized
INFO - 2020-08-24 15:23:09 --> Loader Class Initialized
INFO - 2020-08-24 15:23:09 --> Helper loaded: url_helper
INFO - 2020-08-24 15:23:09 --> Helper loaded: form_helper
INFO - 2020-08-24 15:23:09 --> Helper loaded: file_helper
INFO - 2020-08-24 15:23:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:23:09 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:23:09 --> Upload Class Initialized
INFO - 2020-08-24 15:23:09 --> Controller Class Initialized
DEBUG - 2020-08-24 15:23:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:23:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:23:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:23:09 --> Final output sent to browser
DEBUG - 2020-08-24 15:23:09 --> Total execution time: 0.0542
INFO - 2020-08-24 15:23:20 --> Config Class Initialized
INFO - 2020-08-24 15:23:20 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:23:20 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:23:20 --> Utf8 Class Initialized
INFO - 2020-08-24 15:23:20 --> URI Class Initialized
INFO - 2020-08-24 15:23:20 --> Router Class Initialized
INFO - 2020-08-24 15:23:20 --> Output Class Initialized
INFO - 2020-08-24 15:23:20 --> Security Class Initialized
DEBUG - 2020-08-24 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:23:20 --> Input Class Initialized
INFO - 2020-08-24 15:23:20 --> Language Class Initialized
INFO - 2020-08-24 15:23:20 --> Language Class Initialized
INFO - 2020-08-24 15:23:20 --> Config Class Initialized
INFO - 2020-08-24 15:23:20 --> Loader Class Initialized
INFO - 2020-08-24 15:23:20 --> Helper loaded: url_helper
INFO - 2020-08-24 15:23:20 --> Helper loaded: form_helper
INFO - 2020-08-24 15:23:20 --> Helper loaded: file_helper
INFO - 2020-08-24 15:23:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:23:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:23:21 --> Upload Class Initialized
INFO - 2020-08-24 15:23:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:23:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:23:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:23:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:23:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:23:21 --> Total execution time: 0.0585
INFO - 2020-08-24 15:23:24 --> Config Class Initialized
INFO - 2020-08-24 15:23:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:23:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:23:24 --> Utf8 Class Initialized
INFO - 2020-08-24 15:23:24 --> URI Class Initialized
INFO - 2020-08-24 15:23:24 --> Router Class Initialized
INFO - 2020-08-24 15:23:24 --> Output Class Initialized
INFO - 2020-08-24 15:23:24 --> Security Class Initialized
DEBUG - 2020-08-24 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:23:24 --> Input Class Initialized
INFO - 2020-08-24 15:23:24 --> Language Class Initialized
INFO - 2020-08-24 15:23:24 --> Language Class Initialized
INFO - 2020-08-24 15:23:24 --> Config Class Initialized
INFO - 2020-08-24 15:23:24 --> Loader Class Initialized
INFO - 2020-08-24 15:23:24 --> Helper loaded: url_helper
INFO - 2020-08-24 15:23:24 --> Helper loaded: form_helper
INFO - 2020-08-24 15:23:24 --> Helper loaded: file_helper
INFO - 2020-08-24 15:23:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:23:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:23:24 --> Upload Class Initialized
INFO - 2020-08-24 15:23:24 --> Controller Class Initialized
DEBUG - 2020-08-24 15:23:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:23:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:23:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:23:24 --> Final output sent to browser
DEBUG - 2020-08-24 15:23:24 --> Total execution time: 0.0494
INFO - 2020-08-24 15:23:37 --> Config Class Initialized
INFO - 2020-08-24 15:23:37 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:23:37 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:23:37 --> Utf8 Class Initialized
INFO - 2020-08-24 15:23:37 --> URI Class Initialized
INFO - 2020-08-24 15:23:37 --> Router Class Initialized
INFO - 2020-08-24 15:23:37 --> Output Class Initialized
INFO - 2020-08-24 15:23:37 --> Security Class Initialized
DEBUG - 2020-08-24 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:23:37 --> Input Class Initialized
INFO - 2020-08-24 15:23:37 --> Language Class Initialized
INFO - 2020-08-24 15:23:37 --> Language Class Initialized
INFO - 2020-08-24 15:23:37 --> Config Class Initialized
INFO - 2020-08-24 15:23:37 --> Loader Class Initialized
INFO - 2020-08-24 15:23:37 --> Helper loaded: url_helper
INFO - 2020-08-24 15:23:37 --> Helper loaded: form_helper
INFO - 2020-08-24 15:23:37 --> Helper loaded: file_helper
INFO - 2020-08-24 15:23:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:23:37 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:23:37 --> Upload Class Initialized
INFO - 2020-08-24 15:23:37 --> Controller Class Initialized
DEBUG - 2020-08-24 15:23:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:23:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:23:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:23:37 --> Final output sent to browser
DEBUG - 2020-08-24 15:23:37 --> Total execution time: 0.0540
INFO - 2020-08-24 15:25:05 --> Config Class Initialized
INFO - 2020-08-24 15:25:05 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:25:05 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:25:05 --> Utf8 Class Initialized
INFO - 2020-08-24 15:25:05 --> URI Class Initialized
INFO - 2020-08-24 15:25:05 --> Router Class Initialized
INFO - 2020-08-24 15:25:05 --> Output Class Initialized
INFO - 2020-08-24 15:25:05 --> Security Class Initialized
DEBUG - 2020-08-24 15:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:25:05 --> Input Class Initialized
INFO - 2020-08-24 15:25:05 --> Language Class Initialized
INFO - 2020-08-24 15:25:05 --> Language Class Initialized
INFO - 2020-08-24 15:25:05 --> Config Class Initialized
INFO - 2020-08-24 15:25:05 --> Loader Class Initialized
INFO - 2020-08-24 15:25:05 --> Helper loaded: url_helper
INFO - 2020-08-24 15:25:05 --> Helper loaded: form_helper
INFO - 2020-08-24 15:25:05 --> Helper loaded: file_helper
INFO - 2020-08-24 15:25:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:25:05 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:25:05 --> Upload Class Initialized
INFO - 2020-08-24 15:25:06 --> Controller Class Initialized
DEBUG - 2020-08-24 15:25:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:25:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:25:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:25:06 --> Final output sent to browser
DEBUG - 2020-08-24 15:25:06 --> Total execution time: 0.1747
INFO - 2020-08-24 15:25:08 --> Config Class Initialized
INFO - 2020-08-24 15:25:08 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:25:08 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:25:08 --> Utf8 Class Initialized
INFO - 2020-08-24 15:25:08 --> URI Class Initialized
INFO - 2020-08-24 15:25:08 --> Router Class Initialized
INFO - 2020-08-24 15:25:08 --> Output Class Initialized
INFO - 2020-08-24 15:25:08 --> Security Class Initialized
DEBUG - 2020-08-24 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:25:08 --> Input Class Initialized
INFO - 2020-08-24 15:25:08 --> Language Class Initialized
INFO - 2020-08-24 15:25:08 --> Language Class Initialized
INFO - 2020-08-24 15:25:08 --> Config Class Initialized
INFO - 2020-08-24 15:25:08 --> Loader Class Initialized
INFO - 2020-08-24 15:25:08 --> Helper loaded: url_helper
INFO - 2020-08-24 15:25:08 --> Helper loaded: form_helper
INFO - 2020-08-24 15:25:08 --> Helper loaded: file_helper
INFO - 2020-08-24 15:25:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:25:08 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:25:08 --> Upload Class Initialized
INFO - 2020-08-24 15:25:08 --> Controller Class Initialized
DEBUG - 2020-08-24 15:25:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:25:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:25:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:25:08 --> Final output sent to browser
DEBUG - 2020-08-24 15:25:08 --> Total execution time: 0.0452
INFO - 2020-08-24 15:25:28 --> Config Class Initialized
INFO - 2020-08-24 15:25:28 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:25:28 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:25:28 --> Utf8 Class Initialized
INFO - 2020-08-24 15:25:28 --> URI Class Initialized
INFO - 2020-08-24 15:25:28 --> Router Class Initialized
INFO - 2020-08-24 15:25:28 --> Output Class Initialized
INFO - 2020-08-24 15:25:28 --> Security Class Initialized
DEBUG - 2020-08-24 15:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:25:28 --> Input Class Initialized
INFO - 2020-08-24 15:25:28 --> Language Class Initialized
INFO - 2020-08-24 15:25:28 --> Language Class Initialized
INFO - 2020-08-24 15:25:28 --> Config Class Initialized
INFO - 2020-08-24 15:25:28 --> Loader Class Initialized
INFO - 2020-08-24 15:25:28 --> Helper loaded: url_helper
INFO - 2020-08-24 15:25:28 --> Helper loaded: form_helper
INFO - 2020-08-24 15:25:28 --> Helper loaded: file_helper
INFO - 2020-08-24 15:25:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:25:28 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:25:28 --> Upload Class Initialized
INFO - 2020-08-24 15:25:28 --> Controller Class Initialized
DEBUG - 2020-08-24 15:25:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:25:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:25:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:25:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:25:28 --> Final output sent to browser
DEBUG - 2020-08-24 15:25:28 --> Total execution time: 0.0507
INFO - 2020-08-24 15:26:51 --> Config Class Initialized
INFO - 2020-08-24 15:26:51 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:26:51 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:26:51 --> Utf8 Class Initialized
INFO - 2020-08-24 15:26:51 --> URI Class Initialized
INFO - 2020-08-24 15:26:51 --> Router Class Initialized
INFO - 2020-08-24 15:26:51 --> Output Class Initialized
INFO - 2020-08-24 15:26:51 --> Security Class Initialized
DEBUG - 2020-08-24 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:26:51 --> Input Class Initialized
INFO - 2020-08-24 15:26:51 --> Language Class Initialized
INFO - 2020-08-24 15:26:51 --> Language Class Initialized
INFO - 2020-08-24 15:26:51 --> Config Class Initialized
INFO - 2020-08-24 15:26:51 --> Loader Class Initialized
INFO - 2020-08-24 15:26:51 --> Helper loaded: url_helper
INFO - 2020-08-24 15:26:51 --> Helper loaded: form_helper
INFO - 2020-08-24 15:26:51 --> Helper loaded: file_helper
INFO - 2020-08-24 15:26:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:26:51 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:26:51 --> Upload Class Initialized
INFO - 2020-08-24 15:26:51 --> Controller Class Initialized
DEBUG - 2020-08-24 15:26:51 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:26:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:26:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:26:51 --> Final output sent to browser
DEBUG - 2020-08-24 15:26:51 --> Total execution time: 0.0512
INFO - 2020-08-24 15:28:28 --> Config Class Initialized
INFO - 2020-08-24 15:28:28 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:28:28 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:28:28 --> Utf8 Class Initialized
INFO - 2020-08-24 15:28:28 --> URI Class Initialized
INFO - 2020-08-24 15:28:28 --> Router Class Initialized
INFO - 2020-08-24 15:28:28 --> Output Class Initialized
INFO - 2020-08-24 15:28:28 --> Security Class Initialized
DEBUG - 2020-08-24 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:28:28 --> Input Class Initialized
INFO - 2020-08-24 15:28:28 --> Language Class Initialized
INFO - 2020-08-24 15:28:28 --> Language Class Initialized
INFO - 2020-08-24 15:28:28 --> Config Class Initialized
INFO - 2020-08-24 15:28:28 --> Loader Class Initialized
INFO - 2020-08-24 15:28:28 --> Helper loaded: url_helper
INFO - 2020-08-24 15:28:28 --> Helper loaded: form_helper
INFO - 2020-08-24 15:28:28 --> Helper loaded: file_helper
INFO - 2020-08-24 15:28:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:28:28 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:28:28 --> Upload Class Initialized
INFO - 2020-08-24 15:28:28 --> Controller Class Initialized
DEBUG - 2020-08-24 15:28:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:28:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:28:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:28:28 --> Final output sent to browser
DEBUG - 2020-08-24 15:28:28 --> Total execution time: 0.0528
INFO - 2020-08-24 15:29:05 --> Config Class Initialized
INFO - 2020-08-24 15:29:05 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:29:05 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:29:05 --> Utf8 Class Initialized
INFO - 2020-08-24 15:29:05 --> URI Class Initialized
INFO - 2020-08-24 15:29:05 --> Router Class Initialized
INFO - 2020-08-24 15:29:05 --> Output Class Initialized
INFO - 2020-08-24 15:29:05 --> Security Class Initialized
DEBUG - 2020-08-24 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:29:05 --> Input Class Initialized
INFO - 2020-08-24 15:29:05 --> Language Class Initialized
INFO - 2020-08-24 15:29:05 --> Language Class Initialized
INFO - 2020-08-24 15:29:05 --> Config Class Initialized
INFO - 2020-08-24 15:29:05 --> Loader Class Initialized
INFO - 2020-08-24 15:29:05 --> Helper loaded: url_helper
INFO - 2020-08-24 15:29:05 --> Helper loaded: form_helper
INFO - 2020-08-24 15:29:05 --> Helper loaded: file_helper
INFO - 2020-08-24 15:29:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:29:05 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:29:05 --> Upload Class Initialized
INFO - 2020-08-24 15:29:05 --> Controller Class Initialized
DEBUG - 2020-08-24 15:29:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:29:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:29:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:29:05 --> Final output sent to browser
DEBUG - 2020-08-24 15:29:05 --> Total execution time: 0.0529
INFO - 2020-08-24 15:30:08 --> Config Class Initialized
INFO - 2020-08-24 15:30:08 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:30:08 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:30:08 --> Utf8 Class Initialized
INFO - 2020-08-24 15:30:08 --> URI Class Initialized
INFO - 2020-08-24 15:30:08 --> Router Class Initialized
INFO - 2020-08-24 15:30:08 --> Output Class Initialized
INFO - 2020-08-24 15:30:08 --> Security Class Initialized
DEBUG - 2020-08-24 15:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:30:08 --> Input Class Initialized
INFO - 2020-08-24 15:30:08 --> Language Class Initialized
INFO - 2020-08-24 15:30:08 --> Language Class Initialized
INFO - 2020-08-24 15:30:08 --> Config Class Initialized
INFO - 2020-08-24 15:30:08 --> Loader Class Initialized
INFO - 2020-08-24 15:30:08 --> Helper loaded: url_helper
INFO - 2020-08-24 15:30:08 --> Helper loaded: form_helper
INFO - 2020-08-24 15:30:08 --> Helper loaded: file_helper
INFO - 2020-08-24 15:30:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:30:08 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:30:08 --> Upload Class Initialized
INFO - 2020-08-24 15:30:08 --> Controller Class Initialized
DEBUG - 2020-08-24 15:30:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:30:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:30:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:30:08 --> Final output sent to browser
DEBUG - 2020-08-24 15:30:08 --> Total execution time: 0.0980
INFO - 2020-08-24 15:32:13 --> Config Class Initialized
INFO - 2020-08-24 15:32:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:32:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:32:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:32:13 --> URI Class Initialized
INFO - 2020-08-24 15:32:13 --> Router Class Initialized
INFO - 2020-08-24 15:32:13 --> Output Class Initialized
INFO - 2020-08-24 15:32:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:32:13 --> Input Class Initialized
INFO - 2020-08-24 15:32:13 --> Language Class Initialized
INFO - 2020-08-24 15:32:13 --> Language Class Initialized
INFO - 2020-08-24 15:32:13 --> Config Class Initialized
INFO - 2020-08-24 15:32:13 --> Loader Class Initialized
INFO - 2020-08-24 15:32:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:32:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:32:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:32:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:32:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:32:13 --> Upload Class Initialized
INFO - 2020-08-24 15:32:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:32:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:32:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:32:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:32:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:32:13 --> Total execution time: 0.0494
INFO - 2020-08-24 15:32:17 --> Config Class Initialized
INFO - 2020-08-24 15:32:17 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:32:17 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:32:17 --> Utf8 Class Initialized
INFO - 2020-08-24 15:32:17 --> URI Class Initialized
INFO - 2020-08-24 15:32:17 --> Router Class Initialized
INFO - 2020-08-24 15:32:17 --> Output Class Initialized
INFO - 2020-08-24 15:32:17 --> Security Class Initialized
DEBUG - 2020-08-24 15:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:32:17 --> Input Class Initialized
INFO - 2020-08-24 15:32:17 --> Language Class Initialized
INFO - 2020-08-24 15:32:17 --> Language Class Initialized
INFO - 2020-08-24 15:32:17 --> Config Class Initialized
INFO - 2020-08-24 15:32:17 --> Loader Class Initialized
INFO - 2020-08-24 15:32:17 --> Helper loaded: url_helper
INFO - 2020-08-24 15:32:17 --> Helper loaded: form_helper
INFO - 2020-08-24 15:32:17 --> Helper loaded: file_helper
INFO - 2020-08-24 15:32:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:32:17 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:32:17 --> Upload Class Initialized
INFO - 2020-08-24 15:32:17 --> Controller Class Initialized
DEBUG - 2020-08-24 15:32:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:32:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:32:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:32:17 --> Final output sent to browser
DEBUG - 2020-08-24 15:32:17 --> Total execution time: 0.0511
INFO - 2020-08-24 15:32:24 --> Config Class Initialized
INFO - 2020-08-24 15:32:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:32:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:32:24 --> Utf8 Class Initialized
INFO - 2020-08-24 15:32:24 --> URI Class Initialized
DEBUG - 2020-08-24 15:32:24 --> No URI present. Default controller set.
INFO - 2020-08-24 15:32:24 --> Router Class Initialized
INFO - 2020-08-24 15:32:24 --> Output Class Initialized
INFO - 2020-08-24 15:32:24 --> Security Class Initialized
DEBUG - 2020-08-24 15:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:32:24 --> Input Class Initialized
INFO - 2020-08-24 15:32:24 --> Language Class Initialized
INFO - 2020-08-24 15:32:24 --> Language Class Initialized
INFO - 2020-08-24 15:32:24 --> Config Class Initialized
INFO - 2020-08-24 15:32:24 --> Loader Class Initialized
INFO - 2020-08-24 15:32:24 --> Helper loaded: url_helper
INFO - 2020-08-24 15:32:24 --> Helper loaded: form_helper
INFO - 2020-08-24 15:32:24 --> Helper loaded: file_helper
INFO - 2020-08-24 15:32:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:32:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:32:24 --> Upload Class Initialized
INFO - 2020-08-24 15:32:24 --> Controller Class Initialized
DEBUG - 2020-08-24 15:32:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:32:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:32:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:32:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:32:24 --> Final output sent to browser
DEBUG - 2020-08-24 15:32:24 --> Total execution time: 0.0520
INFO - 2020-08-24 15:32:43 --> Config Class Initialized
INFO - 2020-08-24 15:32:43 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:32:43 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:32:43 --> Utf8 Class Initialized
INFO - 2020-08-24 15:32:43 --> URI Class Initialized
INFO - 2020-08-24 15:32:43 --> Router Class Initialized
INFO - 2020-08-24 15:32:43 --> Output Class Initialized
INFO - 2020-08-24 15:32:43 --> Security Class Initialized
DEBUG - 2020-08-24 15:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:32:43 --> Input Class Initialized
INFO - 2020-08-24 15:32:43 --> Language Class Initialized
INFO - 2020-08-24 15:32:43 --> Language Class Initialized
INFO - 2020-08-24 15:32:43 --> Config Class Initialized
INFO - 2020-08-24 15:32:43 --> Loader Class Initialized
INFO - 2020-08-24 15:32:43 --> Helper loaded: url_helper
INFO - 2020-08-24 15:32:43 --> Helper loaded: form_helper
INFO - 2020-08-24 15:32:43 --> Helper loaded: file_helper
INFO - 2020-08-24 15:32:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:32:43 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:32:43 --> Upload Class Initialized
INFO - 2020-08-24 15:32:43 --> Controller Class Initialized
ERROR - 2020-08-24 15:32:43 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:33:32 --> Config Class Initialized
INFO - 2020-08-24 15:33:32 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:33:32 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:33:32 --> Utf8 Class Initialized
INFO - 2020-08-24 15:33:32 --> URI Class Initialized
INFO - 2020-08-24 15:33:32 --> Router Class Initialized
INFO - 2020-08-24 15:33:32 --> Output Class Initialized
INFO - 2020-08-24 15:33:32 --> Security Class Initialized
DEBUG - 2020-08-24 15:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:33:32 --> Input Class Initialized
INFO - 2020-08-24 15:33:32 --> Language Class Initialized
INFO - 2020-08-24 15:33:32 --> Language Class Initialized
INFO - 2020-08-24 15:33:32 --> Config Class Initialized
INFO - 2020-08-24 15:33:32 --> Loader Class Initialized
INFO - 2020-08-24 15:33:32 --> Helper loaded: url_helper
INFO - 2020-08-24 15:33:32 --> Helper loaded: form_helper
INFO - 2020-08-24 15:33:32 --> Helper loaded: file_helper
INFO - 2020-08-24 15:33:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:33:32 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:33:32 --> Upload Class Initialized
INFO - 2020-08-24 15:33:32 --> Controller Class Initialized
DEBUG - 2020-08-24 15:33:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:33:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:33:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:33:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:33:32 --> Final output sent to browser
DEBUG - 2020-08-24 15:33:32 --> Total execution time: 0.0515
INFO - 2020-08-24 15:33:35 --> Config Class Initialized
INFO - 2020-08-24 15:33:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:33:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:33:35 --> Utf8 Class Initialized
INFO - 2020-08-24 15:33:35 --> URI Class Initialized
INFO - 2020-08-24 15:33:35 --> Router Class Initialized
INFO - 2020-08-24 15:33:35 --> Output Class Initialized
INFO - 2020-08-24 15:33:35 --> Security Class Initialized
DEBUG - 2020-08-24 15:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:33:35 --> Input Class Initialized
INFO - 2020-08-24 15:33:35 --> Language Class Initialized
INFO - 2020-08-24 15:33:35 --> Language Class Initialized
INFO - 2020-08-24 15:33:35 --> Config Class Initialized
INFO - 2020-08-24 15:33:35 --> Loader Class Initialized
INFO - 2020-08-24 15:33:35 --> Helper loaded: url_helper
INFO - 2020-08-24 15:33:35 --> Helper loaded: form_helper
INFO - 2020-08-24 15:33:35 --> Helper loaded: file_helper
INFO - 2020-08-24 15:33:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:33:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:33:35 --> Upload Class Initialized
INFO - 2020-08-24 15:33:35 --> Controller Class Initialized
DEBUG - 2020-08-24 15:33:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:33:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:33:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:33:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:33:35 --> Final output sent to browser
DEBUG - 2020-08-24 15:33:35 --> Total execution time: 0.0533
INFO - 2020-08-24 15:36:13 --> Config Class Initialized
INFO - 2020-08-24 15:36:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:36:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:36:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:36:13 --> URI Class Initialized
INFO - 2020-08-24 15:36:13 --> Router Class Initialized
INFO - 2020-08-24 15:36:13 --> Output Class Initialized
INFO - 2020-08-24 15:36:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:36:13 --> Input Class Initialized
INFO - 2020-08-24 15:36:13 --> Language Class Initialized
INFO - 2020-08-24 15:36:13 --> Language Class Initialized
INFO - 2020-08-24 15:36:13 --> Config Class Initialized
INFO - 2020-08-24 15:36:13 --> Loader Class Initialized
INFO - 2020-08-24 15:36:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:36:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:36:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:36:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:36:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:36:13 --> Upload Class Initialized
INFO - 2020-08-24 15:36:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:36:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:36:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 15:36:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:36:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:36:13 --> Total execution time: 0.0508
INFO - 2020-08-24 15:37:32 --> Config Class Initialized
INFO - 2020-08-24 15:37:32 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:37:32 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:37:32 --> Utf8 Class Initialized
INFO - 2020-08-24 15:37:32 --> URI Class Initialized
INFO - 2020-08-24 15:37:32 --> Router Class Initialized
INFO - 2020-08-24 15:37:32 --> Output Class Initialized
INFO - 2020-08-24 15:37:32 --> Security Class Initialized
DEBUG - 2020-08-24 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:37:32 --> Input Class Initialized
INFO - 2020-08-24 15:37:32 --> Language Class Initialized
INFO - 2020-08-24 15:37:32 --> Language Class Initialized
INFO - 2020-08-24 15:37:32 --> Config Class Initialized
INFO - 2020-08-24 15:37:32 --> Loader Class Initialized
INFO - 2020-08-24 15:37:32 --> Helper loaded: url_helper
INFO - 2020-08-24 15:37:32 --> Helper loaded: form_helper
INFO - 2020-08-24 15:37:32 --> Helper loaded: file_helper
INFO - 2020-08-24 15:37:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:37:32 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:37:32 --> Upload Class Initialized
INFO - 2020-08-24 15:37:32 --> Controller Class Initialized
ERROR - 2020-08-24 15:37:32 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:37:35 --> Config Class Initialized
INFO - 2020-08-24 15:37:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:37:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:37:35 --> Utf8 Class Initialized
INFO - 2020-08-24 15:37:35 --> URI Class Initialized
INFO - 2020-08-24 15:37:35 --> Router Class Initialized
INFO - 2020-08-24 15:37:35 --> Output Class Initialized
INFO - 2020-08-24 15:37:35 --> Security Class Initialized
DEBUG - 2020-08-24 15:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:37:35 --> Input Class Initialized
INFO - 2020-08-24 15:37:35 --> Language Class Initialized
INFO - 2020-08-24 15:37:35 --> Language Class Initialized
INFO - 2020-08-24 15:37:35 --> Config Class Initialized
INFO - 2020-08-24 15:37:35 --> Loader Class Initialized
INFO - 2020-08-24 15:37:35 --> Helper loaded: url_helper
INFO - 2020-08-24 15:37:35 --> Helper loaded: form_helper
INFO - 2020-08-24 15:37:35 --> Helper loaded: file_helper
INFO - 2020-08-24 15:37:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:37:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:37:35 --> Upload Class Initialized
INFO - 2020-08-24 15:37:35 --> Controller Class Initialized
ERROR - 2020-08-24 15:37:35 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:37:36 --> Config Class Initialized
INFO - 2020-08-24 15:37:36 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:37:36 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:37:36 --> Utf8 Class Initialized
INFO - 2020-08-24 15:37:36 --> URI Class Initialized
INFO - 2020-08-24 15:37:36 --> Router Class Initialized
INFO - 2020-08-24 15:37:36 --> Output Class Initialized
INFO - 2020-08-24 15:37:36 --> Security Class Initialized
DEBUG - 2020-08-24 15:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:37:36 --> Input Class Initialized
INFO - 2020-08-24 15:37:36 --> Language Class Initialized
INFO - 2020-08-24 15:37:36 --> Language Class Initialized
INFO - 2020-08-24 15:37:36 --> Config Class Initialized
INFO - 2020-08-24 15:37:36 --> Loader Class Initialized
INFO - 2020-08-24 15:37:36 --> Helper loaded: url_helper
INFO - 2020-08-24 15:37:36 --> Helper loaded: form_helper
INFO - 2020-08-24 15:37:36 --> Helper loaded: file_helper
INFO - 2020-08-24 15:37:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:37:36 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:37:36 --> Upload Class Initialized
INFO - 2020-08-24 15:37:36 --> Controller Class Initialized
ERROR - 2020-08-24 15:37:36 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:38:29 --> Config Class Initialized
INFO - 2020-08-24 15:38:29 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:38:29 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:38:29 --> Utf8 Class Initialized
INFO - 2020-08-24 15:38:29 --> URI Class Initialized
INFO - 2020-08-24 15:38:29 --> Router Class Initialized
INFO - 2020-08-24 15:38:29 --> Output Class Initialized
INFO - 2020-08-24 15:38:29 --> Security Class Initialized
DEBUG - 2020-08-24 15:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:38:29 --> Input Class Initialized
INFO - 2020-08-24 15:38:29 --> Language Class Initialized
INFO - 2020-08-24 15:38:29 --> Language Class Initialized
INFO - 2020-08-24 15:38:29 --> Config Class Initialized
INFO - 2020-08-24 15:38:29 --> Loader Class Initialized
INFO - 2020-08-24 15:38:29 --> Helper loaded: url_helper
INFO - 2020-08-24 15:38:29 --> Helper loaded: form_helper
INFO - 2020-08-24 15:38:29 --> Helper loaded: file_helper
INFO - 2020-08-24 15:38:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:38:29 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:38:29 --> Upload Class Initialized
INFO - 2020-08-24 15:38:29 --> Controller Class Initialized
DEBUG - 2020-08-24 15:38:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:38:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:38:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:38:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:38:29 --> Final output sent to browser
DEBUG - 2020-08-24 15:38:29 --> Total execution time: 0.0501
INFO - 2020-08-24 15:39:21 --> Config Class Initialized
INFO - 2020-08-24 15:39:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:39:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:39:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:39:21 --> URI Class Initialized
INFO - 2020-08-24 15:39:21 --> Router Class Initialized
INFO - 2020-08-24 15:39:21 --> Output Class Initialized
INFO - 2020-08-24 15:39:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:39:21 --> Input Class Initialized
INFO - 2020-08-24 15:39:21 --> Language Class Initialized
INFO - 2020-08-24 15:39:21 --> Language Class Initialized
INFO - 2020-08-24 15:39:21 --> Config Class Initialized
INFO - 2020-08-24 15:39:21 --> Loader Class Initialized
INFO - 2020-08-24 15:39:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:39:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:39:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:39:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:39:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:39:21 --> Upload Class Initialized
INFO - 2020-08-24 15:39:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:39:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:39:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:39:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:39:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:39:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:39:21 --> Total execution time: 0.0540
INFO - 2020-08-24 15:39:44 --> Config Class Initialized
INFO - 2020-08-24 15:39:44 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:39:44 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:39:44 --> Utf8 Class Initialized
INFO - 2020-08-24 15:39:44 --> URI Class Initialized
INFO - 2020-08-24 15:39:44 --> Router Class Initialized
INFO - 2020-08-24 15:39:44 --> Output Class Initialized
INFO - 2020-08-24 15:39:44 --> Security Class Initialized
DEBUG - 2020-08-24 15:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:39:44 --> Input Class Initialized
INFO - 2020-08-24 15:39:44 --> Language Class Initialized
INFO - 2020-08-24 15:39:44 --> Language Class Initialized
INFO - 2020-08-24 15:39:44 --> Config Class Initialized
INFO - 2020-08-24 15:39:44 --> Loader Class Initialized
INFO - 2020-08-24 15:39:44 --> Helper loaded: url_helper
INFO - 2020-08-24 15:39:44 --> Helper loaded: form_helper
INFO - 2020-08-24 15:39:44 --> Helper loaded: file_helper
INFO - 2020-08-24 15:39:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:39:44 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:39:44 --> Upload Class Initialized
INFO - 2020-08-24 15:39:44 --> Controller Class Initialized
DEBUG - 2020-08-24 15:39:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:39:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:39:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:39:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:39:44 --> Final output sent to browser
DEBUG - 2020-08-24 15:39:44 --> Total execution time: 0.0504
INFO - 2020-08-24 15:40:13 --> Config Class Initialized
INFO - 2020-08-24 15:40:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:40:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:40:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:40:13 --> URI Class Initialized
INFO - 2020-08-24 15:40:13 --> Router Class Initialized
INFO - 2020-08-24 15:40:13 --> Output Class Initialized
INFO - 2020-08-24 15:40:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:40:13 --> Input Class Initialized
INFO - 2020-08-24 15:40:13 --> Language Class Initialized
INFO - 2020-08-24 15:40:13 --> Language Class Initialized
INFO - 2020-08-24 15:40:13 --> Config Class Initialized
INFO - 2020-08-24 15:40:13 --> Loader Class Initialized
INFO - 2020-08-24 15:40:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:40:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:40:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:40:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:40:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:40:13 --> Upload Class Initialized
INFO - 2020-08-24 15:40:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:40:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:40:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:40:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:40:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:40:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:40:13 --> Total execution time: 0.0509
INFO - 2020-08-24 15:40:16 --> Config Class Initialized
INFO - 2020-08-24 15:40:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:40:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:40:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:40:16 --> URI Class Initialized
INFO - 2020-08-24 15:40:16 --> Router Class Initialized
INFO - 2020-08-24 15:40:16 --> Output Class Initialized
INFO - 2020-08-24 15:40:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:40:16 --> Input Class Initialized
INFO - 2020-08-24 15:40:16 --> Language Class Initialized
INFO - 2020-08-24 15:40:16 --> Language Class Initialized
INFO - 2020-08-24 15:40:16 --> Config Class Initialized
INFO - 2020-08-24 15:40:16 --> Loader Class Initialized
INFO - 2020-08-24 15:40:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:40:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:40:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:40:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:40:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:40:16 --> Upload Class Initialized
INFO - 2020-08-24 15:40:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:40:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:40:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:40:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:40:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:40:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:40:16 --> Total execution time: 0.0494
INFO - 2020-08-24 15:40:17 --> Config Class Initialized
INFO - 2020-08-24 15:40:17 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:40:17 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:40:17 --> Utf8 Class Initialized
INFO - 2020-08-24 15:40:17 --> URI Class Initialized
INFO - 2020-08-24 15:40:17 --> Router Class Initialized
INFO - 2020-08-24 15:40:17 --> Output Class Initialized
INFO - 2020-08-24 15:40:17 --> Security Class Initialized
DEBUG - 2020-08-24 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:40:17 --> Input Class Initialized
INFO - 2020-08-24 15:40:17 --> Language Class Initialized
INFO - 2020-08-24 15:40:17 --> Language Class Initialized
INFO - 2020-08-24 15:40:17 --> Config Class Initialized
INFO - 2020-08-24 15:40:17 --> Loader Class Initialized
INFO - 2020-08-24 15:40:17 --> Helper loaded: url_helper
INFO - 2020-08-24 15:40:17 --> Helper loaded: form_helper
INFO - 2020-08-24 15:40:17 --> Helper loaded: file_helper
INFO - 2020-08-24 15:40:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:40:17 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:40:17 --> Upload Class Initialized
INFO - 2020-08-24 15:40:17 --> Controller Class Initialized
DEBUG - 2020-08-24 15:40:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:40:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:40:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:40:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:40:17 --> Final output sent to browser
DEBUG - 2020-08-24 15:40:17 --> Total execution time: 0.0526
INFO - 2020-08-24 15:40:21 --> Config Class Initialized
INFO - 2020-08-24 15:40:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:40:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:40:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:40:21 --> URI Class Initialized
INFO - 2020-08-24 15:40:21 --> Router Class Initialized
INFO - 2020-08-24 15:40:21 --> Output Class Initialized
INFO - 2020-08-24 15:40:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:40:21 --> Input Class Initialized
INFO - 2020-08-24 15:40:21 --> Language Class Initialized
INFO - 2020-08-24 15:40:21 --> Language Class Initialized
INFO - 2020-08-24 15:40:21 --> Config Class Initialized
INFO - 2020-08-24 15:40:21 --> Loader Class Initialized
INFO - 2020-08-24 15:40:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:40:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:40:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:40:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:40:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:40:21 --> Upload Class Initialized
INFO - 2020-08-24 15:40:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:40:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:40:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:40:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:40:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:40:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:40:21 --> Total execution time: 0.0581
INFO - 2020-08-24 15:40:52 --> Config Class Initialized
INFO - 2020-08-24 15:40:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:40:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:40:52 --> Utf8 Class Initialized
INFO - 2020-08-24 15:40:52 --> URI Class Initialized
INFO - 2020-08-24 15:40:52 --> Router Class Initialized
INFO - 2020-08-24 15:40:52 --> Output Class Initialized
INFO - 2020-08-24 15:40:52 --> Security Class Initialized
DEBUG - 2020-08-24 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:40:52 --> Input Class Initialized
INFO - 2020-08-24 15:40:52 --> Language Class Initialized
INFO - 2020-08-24 15:40:52 --> Language Class Initialized
INFO - 2020-08-24 15:40:52 --> Config Class Initialized
INFO - 2020-08-24 15:40:52 --> Loader Class Initialized
INFO - 2020-08-24 15:40:52 --> Helper loaded: url_helper
INFO - 2020-08-24 15:40:52 --> Helper loaded: form_helper
INFO - 2020-08-24 15:40:52 --> Helper loaded: file_helper
INFO - 2020-08-24 15:40:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:40:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:40:52 --> Upload Class Initialized
INFO - 2020-08-24 15:40:52 --> Controller Class Initialized
DEBUG - 2020-08-24 15:40:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:40:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:40:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:40:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:40:52 --> Final output sent to browser
DEBUG - 2020-08-24 15:40:52 --> Total execution time: 0.0545
INFO - 2020-08-24 15:40:57 --> Config Class Initialized
INFO - 2020-08-24 15:40:57 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:40:57 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:40:57 --> Utf8 Class Initialized
INFO - 2020-08-24 15:40:57 --> URI Class Initialized
INFO - 2020-08-24 15:40:57 --> Router Class Initialized
INFO - 2020-08-24 15:40:57 --> Output Class Initialized
INFO - 2020-08-24 15:40:57 --> Security Class Initialized
DEBUG - 2020-08-24 15:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:40:57 --> Input Class Initialized
INFO - 2020-08-24 15:40:57 --> Language Class Initialized
INFO - 2020-08-24 15:40:57 --> Language Class Initialized
INFO - 2020-08-24 15:40:57 --> Config Class Initialized
INFO - 2020-08-24 15:40:57 --> Loader Class Initialized
INFO - 2020-08-24 15:40:57 --> Helper loaded: url_helper
INFO - 2020-08-24 15:40:57 --> Helper loaded: form_helper
INFO - 2020-08-24 15:40:57 --> Helper loaded: file_helper
INFO - 2020-08-24 15:40:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:40:57 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:40:57 --> Upload Class Initialized
INFO - 2020-08-24 15:40:57 --> Controller Class Initialized
DEBUG - 2020-08-24 15:40:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:40:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:40:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:40:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:40:57 --> Final output sent to browser
DEBUG - 2020-08-24 15:40:57 --> Total execution time: 0.0542
INFO - 2020-08-24 15:41:04 --> Config Class Initialized
INFO - 2020-08-24 15:41:04 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:41:04 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:41:04 --> Utf8 Class Initialized
INFO - 2020-08-24 15:41:04 --> URI Class Initialized
INFO - 2020-08-24 15:41:04 --> Router Class Initialized
INFO - 2020-08-24 15:41:04 --> Output Class Initialized
INFO - 2020-08-24 15:41:04 --> Security Class Initialized
DEBUG - 2020-08-24 15:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:41:04 --> Input Class Initialized
INFO - 2020-08-24 15:41:04 --> Language Class Initialized
INFO - 2020-08-24 15:41:04 --> Language Class Initialized
INFO - 2020-08-24 15:41:04 --> Config Class Initialized
INFO - 2020-08-24 15:41:04 --> Loader Class Initialized
INFO - 2020-08-24 15:41:04 --> Helper loaded: url_helper
INFO - 2020-08-24 15:41:04 --> Helper loaded: form_helper
INFO - 2020-08-24 15:41:04 --> Helper loaded: file_helper
INFO - 2020-08-24 15:41:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:41:04 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:41:04 --> Upload Class Initialized
INFO - 2020-08-24 15:41:04 --> Controller Class Initialized
DEBUG - 2020-08-24 15:41:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:41:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:41:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:41:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:41:04 --> Final output sent to browser
DEBUG - 2020-08-24 15:41:04 --> Total execution time: 0.1087
INFO - 2020-08-24 15:41:17 --> Config Class Initialized
INFO - 2020-08-24 15:41:17 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:41:17 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:41:17 --> Utf8 Class Initialized
INFO - 2020-08-24 15:41:17 --> URI Class Initialized
INFO - 2020-08-24 15:41:17 --> Router Class Initialized
INFO - 2020-08-24 15:41:17 --> Output Class Initialized
INFO - 2020-08-24 15:41:17 --> Security Class Initialized
DEBUG - 2020-08-24 15:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:41:17 --> Input Class Initialized
INFO - 2020-08-24 15:41:17 --> Language Class Initialized
INFO - 2020-08-24 15:41:17 --> Language Class Initialized
INFO - 2020-08-24 15:41:17 --> Config Class Initialized
INFO - 2020-08-24 15:41:17 --> Loader Class Initialized
INFO - 2020-08-24 15:41:17 --> Helper loaded: url_helper
INFO - 2020-08-24 15:41:17 --> Helper loaded: form_helper
INFO - 2020-08-24 15:41:17 --> Helper loaded: file_helper
INFO - 2020-08-24 15:41:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:41:17 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:41:17 --> Upload Class Initialized
INFO - 2020-08-24 15:41:17 --> Controller Class Initialized
DEBUG - 2020-08-24 15:41:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:41:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:41:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:41:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:41:17 --> Final output sent to browser
DEBUG - 2020-08-24 15:41:17 --> Total execution time: 0.0498
INFO - 2020-08-24 15:41:25 --> Config Class Initialized
INFO - 2020-08-24 15:41:25 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:41:25 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:41:25 --> Utf8 Class Initialized
INFO - 2020-08-24 15:41:25 --> URI Class Initialized
INFO - 2020-08-24 15:41:25 --> Router Class Initialized
INFO - 2020-08-24 15:41:25 --> Output Class Initialized
INFO - 2020-08-24 15:41:25 --> Security Class Initialized
DEBUG - 2020-08-24 15:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:41:25 --> Input Class Initialized
INFO - 2020-08-24 15:41:25 --> Language Class Initialized
INFO - 2020-08-24 15:41:25 --> Language Class Initialized
INFO - 2020-08-24 15:41:25 --> Config Class Initialized
INFO - 2020-08-24 15:41:25 --> Loader Class Initialized
INFO - 2020-08-24 15:41:25 --> Helper loaded: url_helper
INFO - 2020-08-24 15:41:25 --> Helper loaded: form_helper
INFO - 2020-08-24 15:41:25 --> Helper loaded: file_helper
INFO - 2020-08-24 15:41:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:41:25 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:41:25 --> Upload Class Initialized
INFO - 2020-08-24 15:41:25 --> Controller Class Initialized
DEBUG - 2020-08-24 15:41:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:41:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:41:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:41:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:41:25 --> Final output sent to browser
DEBUG - 2020-08-24 15:41:25 --> Total execution time: 0.0656
INFO - 2020-08-24 15:41:42 --> Config Class Initialized
INFO - 2020-08-24 15:41:42 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:41:42 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:41:42 --> Utf8 Class Initialized
INFO - 2020-08-24 15:41:42 --> URI Class Initialized
INFO - 2020-08-24 15:41:42 --> Router Class Initialized
INFO - 2020-08-24 15:41:42 --> Output Class Initialized
INFO - 2020-08-24 15:41:42 --> Security Class Initialized
DEBUG - 2020-08-24 15:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:41:42 --> Input Class Initialized
INFO - 2020-08-24 15:41:42 --> Language Class Initialized
INFO - 2020-08-24 15:41:42 --> Language Class Initialized
INFO - 2020-08-24 15:41:42 --> Config Class Initialized
INFO - 2020-08-24 15:41:42 --> Loader Class Initialized
INFO - 2020-08-24 15:41:42 --> Helper loaded: url_helper
INFO - 2020-08-24 15:41:42 --> Helper loaded: form_helper
INFO - 2020-08-24 15:41:42 --> Helper loaded: file_helper
INFO - 2020-08-24 15:41:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:41:42 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:41:42 --> Upload Class Initialized
INFO - 2020-08-24 15:41:42 --> Controller Class Initialized
DEBUG - 2020-08-24 15:41:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:41:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:41:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:41:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:41:42 --> Final output sent to browser
DEBUG - 2020-08-24 15:41:42 --> Total execution time: 0.0581
INFO - 2020-08-24 15:41:55 --> Config Class Initialized
INFO - 2020-08-24 15:41:55 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:41:55 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:41:55 --> Utf8 Class Initialized
INFO - 2020-08-24 15:41:55 --> URI Class Initialized
INFO - 2020-08-24 15:41:55 --> Router Class Initialized
INFO - 2020-08-24 15:41:55 --> Output Class Initialized
INFO - 2020-08-24 15:41:55 --> Security Class Initialized
DEBUG - 2020-08-24 15:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:41:55 --> Input Class Initialized
INFO - 2020-08-24 15:41:55 --> Language Class Initialized
INFO - 2020-08-24 15:41:55 --> Language Class Initialized
INFO - 2020-08-24 15:41:55 --> Config Class Initialized
INFO - 2020-08-24 15:41:55 --> Loader Class Initialized
INFO - 2020-08-24 15:41:55 --> Helper loaded: url_helper
INFO - 2020-08-24 15:41:55 --> Helper loaded: form_helper
INFO - 2020-08-24 15:41:55 --> Helper loaded: file_helper
INFO - 2020-08-24 15:41:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:41:55 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:41:55 --> Upload Class Initialized
INFO - 2020-08-24 15:41:55 --> Controller Class Initialized
DEBUG - 2020-08-24 15:41:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:41:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:41:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:41:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:41:55 --> Final output sent to browser
DEBUG - 2020-08-24 15:41:55 --> Total execution time: 0.0524
INFO - 2020-08-24 15:42:02 --> Config Class Initialized
INFO - 2020-08-24 15:42:02 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:42:02 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:42:02 --> Utf8 Class Initialized
INFO - 2020-08-24 15:42:02 --> URI Class Initialized
INFO - 2020-08-24 15:42:02 --> Router Class Initialized
INFO - 2020-08-24 15:42:02 --> Output Class Initialized
INFO - 2020-08-24 15:42:02 --> Security Class Initialized
DEBUG - 2020-08-24 15:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:42:02 --> Input Class Initialized
INFO - 2020-08-24 15:42:02 --> Language Class Initialized
INFO - 2020-08-24 15:42:02 --> Language Class Initialized
INFO - 2020-08-24 15:42:02 --> Config Class Initialized
INFO - 2020-08-24 15:42:02 --> Loader Class Initialized
INFO - 2020-08-24 15:42:02 --> Helper loaded: url_helper
INFO - 2020-08-24 15:42:02 --> Helper loaded: form_helper
INFO - 2020-08-24 15:42:02 --> Helper loaded: file_helper
INFO - 2020-08-24 15:42:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:42:02 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:42:02 --> Upload Class Initialized
INFO - 2020-08-24 15:42:02 --> Controller Class Initialized
DEBUG - 2020-08-24 15:42:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:42:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:42:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:42:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:42:02 --> Final output sent to browser
DEBUG - 2020-08-24 15:42:02 --> Total execution time: 0.1259
INFO - 2020-08-24 15:42:07 --> Config Class Initialized
INFO - 2020-08-24 15:42:07 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:42:07 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:42:07 --> Utf8 Class Initialized
INFO - 2020-08-24 15:42:07 --> URI Class Initialized
INFO - 2020-08-24 15:42:07 --> Router Class Initialized
INFO - 2020-08-24 15:42:07 --> Output Class Initialized
INFO - 2020-08-24 15:42:07 --> Security Class Initialized
DEBUG - 2020-08-24 15:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:42:07 --> Input Class Initialized
INFO - 2020-08-24 15:42:07 --> Language Class Initialized
INFO - 2020-08-24 15:42:07 --> Language Class Initialized
INFO - 2020-08-24 15:42:07 --> Config Class Initialized
INFO - 2020-08-24 15:42:07 --> Loader Class Initialized
INFO - 2020-08-24 15:42:07 --> Helper loaded: url_helper
INFO - 2020-08-24 15:42:07 --> Helper loaded: form_helper
INFO - 2020-08-24 15:42:07 --> Helper loaded: file_helper
INFO - 2020-08-24 15:42:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:42:07 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:42:07 --> Upload Class Initialized
INFO - 2020-08-24 15:42:07 --> Controller Class Initialized
DEBUG - 2020-08-24 15:42:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:42:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:42:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:42:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:42:07 --> Final output sent to browser
DEBUG - 2020-08-24 15:42:07 --> Total execution time: 0.0801
INFO - 2020-08-24 15:42:13 --> Config Class Initialized
INFO - 2020-08-24 15:42:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:42:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:42:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:42:13 --> URI Class Initialized
INFO - 2020-08-24 15:42:13 --> Router Class Initialized
INFO - 2020-08-24 15:42:13 --> Output Class Initialized
INFO - 2020-08-24 15:42:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:42:13 --> Input Class Initialized
INFO - 2020-08-24 15:42:13 --> Language Class Initialized
INFO - 2020-08-24 15:42:13 --> Language Class Initialized
INFO - 2020-08-24 15:42:13 --> Config Class Initialized
INFO - 2020-08-24 15:42:13 --> Loader Class Initialized
INFO - 2020-08-24 15:42:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:42:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:42:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:42:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:42:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:42:13 --> Upload Class Initialized
INFO - 2020-08-24 15:42:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:42:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:42:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:42:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:42:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:42:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:42:13 --> Total execution time: 0.0501
INFO - 2020-08-24 15:42:22 --> Config Class Initialized
INFO - 2020-08-24 15:42:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:42:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:42:22 --> Utf8 Class Initialized
INFO - 2020-08-24 15:42:22 --> URI Class Initialized
INFO - 2020-08-24 15:42:22 --> Router Class Initialized
INFO - 2020-08-24 15:42:22 --> Output Class Initialized
INFO - 2020-08-24 15:42:22 --> Security Class Initialized
DEBUG - 2020-08-24 15:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:42:22 --> Input Class Initialized
INFO - 2020-08-24 15:42:22 --> Language Class Initialized
INFO - 2020-08-24 15:42:22 --> Language Class Initialized
INFO - 2020-08-24 15:42:22 --> Config Class Initialized
INFO - 2020-08-24 15:42:22 --> Loader Class Initialized
INFO - 2020-08-24 15:42:22 --> Helper loaded: url_helper
INFO - 2020-08-24 15:42:22 --> Helper loaded: form_helper
INFO - 2020-08-24 15:42:22 --> Helper loaded: file_helper
INFO - 2020-08-24 15:42:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:42:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:42:22 --> Upload Class Initialized
INFO - 2020-08-24 15:42:22 --> Controller Class Initialized
DEBUG - 2020-08-24 15:42:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:42:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:42:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:42:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:42:22 --> Final output sent to browser
DEBUG - 2020-08-24 15:42:22 --> Total execution time: 0.0496
INFO - 2020-08-24 15:42:55 --> Config Class Initialized
INFO - 2020-08-24 15:42:55 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:42:55 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:42:55 --> Utf8 Class Initialized
INFO - 2020-08-24 15:42:55 --> URI Class Initialized
INFO - 2020-08-24 15:42:55 --> Router Class Initialized
INFO - 2020-08-24 15:42:55 --> Output Class Initialized
INFO - 2020-08-24 15:42:55 --> Security Class Initialized
DEBUG - 2020-08-24 15:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:42:55 --> Input Class Initialized
INFO - 2020-08-24 15:42:55 --> Language Class Initialized
INFO - 2020-08-24 15:42:55 --> Language Class Initialized
INFO - 2020-08-24 15:42:55 --> Config Class Initialized
INFO - 2020-08-24 15:42:55 --> Loader Class Initialized
INFO - 2020-08-24 15:42:55 --> Helper loaded: url_helper
INFO - 2020-08-24 15:42:55 --> Helper loaded: form_helper
INFO - 2020-08-24 15:42:55 --> Helper loaded: file_helper
INFO - 2020-08-24 15:42:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:42:55 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:42:55 --> Upload Class Initialized
INFO - 2020-08-24 15:42:55 --> Controller Class Initialized
DEBUG - 2020-08-24 15:42:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:42:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:42:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:42:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:42:55 --> Final output sent to browser
DEBUG - 2020-08-24 15:42:55 --> Total execution time: 0.0522
INFO - 2020-08-24 15:43:01 --> Config Class Initialized
INFO - 2020-08-24 15:43:01 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:43:01 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:43:01 --> Utf8 Class Initialized
INFO - 2020-08-24 15:43:01 --> URI Class Initialized
INFO - 2020-08-24 15:43:01 --> Router Class Initialized
INFO - 2020-08-24 15:43:01 --> Output Class Initialized
INFO - 2020-08-24 15:43:01 --> Security Class Initialized
DEBUG - 2020-08-24 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:43:01 --> Input Class Initialized
INFO - 2020-08-24 15:43:01 --> Language Class Initialized
INFO - 2020-08-24 15:43:01 --> Language Class Initialized
INFO - 2020-08-24 15:43:01 --> Config Class Initialized
INFO - 2020-08-24 15:43:01 --> Loader Class Initialized
INFO - 2020-08-24 15:43:01 --> Helper loaded: url_helper
INFO - 2020-08-24 15:43:01 --> Helper loaded: form_helper
INFO - 2020-08-24 15:43:01 --> Helper loaded: file_helper
INFO - 2020-08-24 15:43:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:43:01 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:43:01 --> Upload Class Initialized
INFO - 2020-08-24 15:43:01 --> Controller Class Initialized
DEBUG - 2020-08-24 15:43:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:43:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:43:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:43:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:43:01 --> Final output sent to browser
DEBUG - 2020-08-24 15:43:01 --> Total execution time: 0.0874
INFO - 2020-08-24 15:43:10 --> Config Class Initialized
INFO - 2020-08-24 15:43:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:43:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:43:10 --> Utf8 Class Initialized
INFO - 2020-08-24 15:43:10 --> URI Class Initialized
INFO - 2020-08-24 15:43:10 --> Router Class Initialized
INFO - 2020-08-24 15:43:10 --> Output Class Initialized
INFO - 2020-08-24 15:43:10 --> Security Class Initialized
DEBUG - 2020-08-24 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:43:10 --> Input Class Initialized
INFO - 2020-08-24 15:43:10 --> Language Class Initialized
INFO - 2020-08-24 15:43:10 --> Language Class Initialized
INFO - 2020-08-24 15:43:10 --> Config Class Initialized
INFO - 2020-08-24 15:43:10 --> Loader Class Initialized
INFO - 2020-08-24 15:43:10 --> Helper loaded: url_helper
INFO - 2020-08-24 15:43:10 --> Helper loaded: form_helper
INFO - 2020-08-24 15:43:10 --> Helper loaded: file_helper
INFO - 2020-08-24 15:43:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:43:11 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:43:11 --> Upload Class Initialized
INFO - 2020-08-24 15:43:11 --> Controller Class Initialized
DEBUG - 2020-08-24 15:43:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:43:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:43:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:43:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:43:11 --> Final output sent to browser
DEBUG - 2020-08-24 15:43:11 --> Total execution time: 0.0534
INFO - 2020-08-24 15:43:28 --> Config Class Initialized
INFO - 2020-08-24 15:43:28 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:43:28 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:43:28 --> Utf8 Class Initialized
INFO - 2020-08-24 15:43:28 --> URI Class Initialized
INFO - 2020-08-24 15:43:28 --> Router Class Initialized
INFO - 2020-08-24 15:43:28 --> Output Class Initialized
INFO - 2020-08-24 15:43:28 --> Security Class Initialized
DEBUG - 2020-08-24 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:43:28 --> Input Class Initialized
INFO - 2020-08-24 15:43:28 --> Language Class Initialized
INFO - 2020-08-24 15:43:28 --> Language Class Initialized
INFO - 2020-08-24 15:43:28 --> Config Class Initialized
INFO - 2020-08-24 15:43:28 --> Loader Class Initialized
INFO - 2020-08-24 15:43:28 --> Helper loaded: url_helper
INFO - 2020-08-24 15:43:28 --> Helper loaded: form_helper
INFO - 2020-08-24 15:43:28 --> Helper loaded: file_helper
INFO - 2020-08-24 15:43:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:43:28 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:43:28 --> Upload Class Initialized
INFO - 2020-08-24 15:43:28 --> Controller Class Initialized
DEBUG - 2020-08-24 15:43:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:43:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:43:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:43:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:43:28 --> Final output sent to browser
DEBUG - 2020-08-24 15:43:28 --> Total execution time: 0.0520
INFO - 2020-08-24 15:43:30 --> Config Class Initialized
INFO - 2020-08-24 15:43:30 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:43:30 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:43:30 --> Utf8 Class Initialized
INFO - 2020-08-24 15:43:30 --> URI Class Initialized
INFO - 2020-08-24 15:43:30 --> Router Class Initialized
INFO - 2020-08-24 15:43:30 --> Output Class Initialized
INFO - 2020-08-24 15:43:30 --> Security Class Initialized
DEBUG - 2020-08-24 15:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:43:30 --> Input Class Initialized
INFO - 2020-08-24 15:43:30 --> Language Class Initialized
INFO - 2020-08-24 15:43:30 --> Language Class Initialized
INFO - 2020-08-24 15:43:30 --> Config Class Initialized
INFO - 2020-08-24 15:43:30 --> Loader Class Initialized
INFO - 2020-08-24 15:43:30 --> Helper loaded: url_helper
INFO - 2020-08-24 15:43:30 --> Helper loaded: form_helper
INFO - 2020-08-24 15:43:30 --> Helper loaded: file_helper
INFO - 2020-08-24 15:43:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:43:30 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:43:30 --> Upload Class Initialized
INFO - 2020-08-24 15:43:30 --> Controller Class Initialized
DEBUG - 2020-08-24 15:43:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:43:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:43:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:43:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:43:30 --> Final output sent to browser
DEBUG - 2020-08-24 15:43:30 --> Total execution time: 0.0541
INFO - 2020-08-24 15:43:38 --> Config Class Initialized
INFO - 2020-08-24 15:43:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:43:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:43:38 --> Utf8 Class Initialized
INFO - 2020-08-24 15:43:38 --> URI Class Initialized
INFO - 2020-08-24 15:43:38 --> Router Class Initialized
INFO - 2020-08-24 15:43:38 --> Output Class Initialized
INFO - 2020-08-24 15:43:38 --> Security Class Initialized
DEBUG - 2020-08-24 15:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:43:38 --> Input Class Initialized
INFO - 2020-08-24 15:43:38 --> Language Class Initialized
INFO - 2020-08-24 15:43:38 --> Language Class Initialized
INFO - 2020-08-24 15:43:38 --> Config Class Initialized
INFO - 2020-08-24 15:43:38 --> Loader Class Initialized
INFO - 2020-08-24 15:43:38 --> Helper loaded: url_helper
INFO - 2020-08-24 15:43:38 --> Helper loaded: form_helper
INFO - 2020-08-24 15:43:38 --> Helper loaded: file_helper
INFO - 2020-08-24 15:43:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:43:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:43:38 --> Upload Class Initialized
INFO - 2020-08-24 15:43:38 --> Controller Class Initialized
DEBUG - 2020-08-24 15:43:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:43:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:43:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:43:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:43:38 --> Final output sent to browser
DEBUG - 2020-08-24 15:43:38 --> Total execution time: 0.0736
INFO - 2020-08-24 15:44:13 --> Config Class Initialized
INFO - 2020-08-24 15:44:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:13 --> URI Class Initialized
INFO - 2020-08-24 15:44:13 --> Router Class Initialized
INFO - 2020-08-24 15:44:13 --> Output Class Initialized
INFO - 2020-08-24 15:44:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:13 --> Input Class Initialized
INFO - 2020-08-24 15:44:13 --> Language Class Initialized
INFO - 2020-08-24 15:44:13 --> Language Class Initialized
INFO - 2020-08-24 15:44:13 --> Config Class Initialized
INFO - 2020-08-24 15:44:13 --> Loader Class Initialized
INFO - 2020-08-24 15:44:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:13 --> Upload Class Initialized
INFO - 2020-08-24 15:44:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:13 --> Total execution time: 0.0619
INFO - 2020-08-24 15:44:16 --> Config Class Initialized
INFO - 2020-08-24 15:44:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:16 --> URI Class Initialized
INFO - 2020-08-24 15:44:16 --> Router Class Initialized
INFO - 2020-08-24 15:44:16 --> Output Class Initialized
INFO - 2020-08-24 15:44:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:16 --> Input Class Initialized
INFO - 2020-08-24 15:44:16 --> Language Class Initialized
INFO - 2020-08-24 15:44:16 --> Language Class Initialized
INFO - 2020-08-24 15:44:16 --> Config Class Initialized
INFO - 2020-08-24 15:44:16 --> Loader Class Initialized
INFO - 2020-08-24 15:44:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:16 --> Upload Class Initialized
INFO - 2020-08-24 15:44:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:16 --> Total execution time: 0.0508
INFO - 2020-08-24 15:44:24 --> Config Class Initialized
INFO - 2020-08-24 15:44:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:24 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:24 --> URI Class Initialized
INFO - 2020-08-24 15:44:24 --> Router Class Initialized
INFO - 2020-08-24 15:44:24 --> Output Class Initialized
INFO - 2020-08-24 15:44:24 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:24 --> Input Class Initialized
INFO - 2020-08-24 15:44:24 --> Language Class Initialized
INFO - 2020-08-24 15:44:24 --> Language Class Initialized
INFO - 2020-08-24 15:44:24 --> Config Class Initialized
INFO - 2020-08-24 15:44:24 --> Loader Class Initialized
INFO - 2020-08-24 15:44:24 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:24 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:24 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:24 --> Upload Class Initialized
INFO - 2020-08-24 15:44:24 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:24 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:24 --> Total execution time: 0.0523
INFO - 2020-08-24 15:44:46 --> Config Class Initialized
INFO - 2020-08-24 15:44:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:46 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:46 --> URI Class Initialized
INFO - 2020-08-24 15:44:46 --> Router Class Initialized
INFO - 2020-08-24 15:44:46 --> Output Class Initialized
INFO - 2020-08-24 15:44:46 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:46 --> Input Class Initialized
INFO - 2020-08-24 15:44:46 --> Language Class Initialized
INFO - 2020-08-24 15:44:46 --> Language Class Initialized
INFO - 2020-08-24 15:44:46 --> Config Class Initialized
INFO - 2020-08-24 15:44:46 --> Loader Class Initialized
INFO - 2020-08-24 15:44:46 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:46 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:46 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:46 --> Upload Class Initialized
INFO - 2020-08-24 15:44:46 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:46 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:46 --> Total execution time: 0.0514
INFO - 2020-08-24 15:44:50 --> Config Class Initialized
INFO - 2020-08-24 15:44:50 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:50 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:50 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:50 --> URI Class Initialized
INFO - 2020-08-24 15:44:50 --> Router Class Initialized
INFO - 2020-08-24 15:44:50 --> Output Class Initialized
INFO - 2020-08-24 15:44:50 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:50 --> Input Class Initialized
INFO - 2020-08-24 15:44:50 --> Language Class Initialized
INFO - 2020-08-24 15:44:50 --> Language Class Initialized
INFO - 2020-08-24 15:44:50 --> Config Class Initialized
INFO - 2020-08-24 15:44:50 --> Loader Class Initialized
INFO - 2020-08-24 15:44:50 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:50 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:50 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:50 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:50 --> Upload Class Initialized
INFO - 2020-08-24 15:44:50 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:50 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:50 --> Total execution time: 0.0550
INFO - 2020-08-24 15:44:55 --> Config Class Initialized
INFO - 2020-08-24 15:44:55 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:55 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:55 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:55 --> URI Class Initialized
INFO - 2020-08-24 15:44:55 --> Router Class Initialized
INFO - 2020-08-24 15:44:55 --> Output Class Initialized
INFO - 2020-08-24 15:44:55 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:55 --> Input Class Initialized
INFO - 2020-08-24 15:44:55 --> Language Class Initialized
INFO - 2020-08-24 15:44:55 --> Language Class Initialized
INFO - 2020-08-24 15:44:55 --> Config Class Initialized
INFO - 2020-08-24 15:44:55 --> Loader Class Initialized
INFO - 2020-08-24 15:44:55 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:55 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:55 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:55 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:55 --> Upload Class Initialized
INFO - 2020-08-24 15:44:55 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:55 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:55 --> Total execution time: 0.0505
INFO - 2020-08-24 15:44:56 --> Config Class Initialized
INFO - 2020-08-24 15:44:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:44:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:44:56 --> Utf8 Class Initialized
INFO - 2020-08-24 15:44:56 --> URI Class Initialized
INFO - 2020-08-24 15:44:56 --> Router Class Initialized
INFO - 2020-08-24 15:44:56 --> Output Class Initialized
INFO - 2020-08-24 15:44:56 --> Security Class Initialized
DEBUG - 2020-08-24 15:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:44:56 --> Input Class Initialized
INFO - 2020-08-24 15:44:56 --> Language Class Initialized
INFO - 2020-08-24 15:44:56 --> Language Class Initialized
INFO - 2020-08-24 15:44:56 --> Config Class Initialized
INFO - 2020-08-24 15:44:56 --> Loader Class Initialized
INFO - 2020-08-24 15:44:56 --> Helper loaded: url_helper
INFO - 2020-08-24 15:44:56 --> Helper loaded: form_helper
INFO - 2020-08-24 15:44:56 --> Helper loaded: file_helper
INFO - 2020-08-24 15:44:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:44:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:44:56 --> Upload Class Initialized
INFO - 2020-08-24 15:44:56 --> Controller Class Initialized
DEBUG - 2020-08-24 15:44:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:44:56 --> Final output sent to browser
DEBUG - 2020-08-24 15:44:56 --> Total execution time: 0.0620
INFO - 2020-08-24 15:45:13 --> Config Class Initialized
INFO - 2020-08-24 15:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:45:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:45:13 --> URI Class Initialized
INFO - 2020-08-24 15:45:13 --> Router Class Initialized
INFO - 2020-08-24 15:45:13 --> Output Class Initialized
INFO - 2020-08-24 15:45:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:45:13 --> Input Class Initialized
INFO - 2020-08-24 15:45:13 --> Language Class Initialized
INFO - 2020-08-24 15:45:13 --> Language Class Initialized
INFO - 2020-08-24 15:45:13 --> Config Class Initialized
INFO - 2020-08-24 15:45:13 --> Loader Class Initialized
INFO - 2020-08-24 15:45:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:45:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:45:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:45:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:45:13 --> Upload Class Initialized
INFO - 2020-08-24 15:45:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:45:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:45:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:45:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:45:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:45:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:45:13 --> Total execution time: 0.0516
INFO - 2020-08-24 15:45:13 --> Config Class Initialized
INFO - 2020-08-24 15:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:45:13 --> Utf8 Class Initialized
INFO - 2020-08-24 15:45:13 --> URI Class Initialized
INFO - 2020-08-24 15:45:13 --> Router Class Initialized
INFO - 2020-08-24 15:45:13 --> Output Class Initialized
INFO - 2020-08-24 15:45:13 --> Security Class Initialized
DEBUG - 2020-08-24 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:45:13 --> Input Class Initialized
INFO - 2020-08-24 15:45:13 --> Language Class Initialized
INFO - 2020-08-24 15:45:13 --> Language Class Initialized
INFO - 2020-08-24 15:45:13 --> Config Class Initialized
INFO - 2020-08-24 15:45:13 --> Loader Class Initialized
INFO - 2020-08-24 15:45:13 --> Helper loaded: url_helper
INFO - 2020-08-24 15:45:13 --> Helper loaded: form_helper
INFO - 2020-08-24 15:45:13 --> Helper loaded: file_helper
INFO - 2020-08-24 15:45:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:45:13 --> Upload Class Initialized
INFO - 2020-08-24 15:45:13 --> Controller Class Initialized
DEBUG - 2020-08-24 15:45:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:45:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:45:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:45:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:45:13 --> Final output sent to browser
DEBUG - 2020-08-24 15:45:13 --> Total execution time: 0.0515
INFO - 2020-08-24 15:45:50 --> Config Class Initialized
INFO - 2020-08-24 15:45:50 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:45:50 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:45:50 --> Utf8 Class Initialized
INFO - 2020-08-24 15:45:50 --> URI Class Initialized
INFO - 2020-08-24 15:45:50 --> Router Class Initialized
INFO - 2020-08-24 15:45:50 --> Output Class Initialized
INFO - 2020-08-24 15:45:50 --> Security Class Initialized
DEBUG - 2020-08-24 15:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:45:50 --> Input Class Initialized
INFO - 2020-08-24 15:45:50 --> Language Class Initialized
INFO - 2020-08-24 15:45:50 --> Language Class Initialized
INFO - 2020-08-24 15:45:50 --> Config Class Initialized
INFO - 2020-08-24 15:45:50 --> Loader Class Initialized
INFO - 2020-08-24 15:45:50 --> Helper loaded: url_helper
INFO - 2020-08-24 15:45:50 --> Helper loaded: form_helper
INFO - 2020-08-24 15:45:50 --> Helper loaded: file_helper
INFO - 2020-08-24 15:45:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:45:50 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:45:50 --> Upload Class Initialized
INFO - 2020-08-24 15:45:50 --> Controller Class Initialized
DEBUG - 2020-08-24 15:45:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:45:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:45:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:45:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:45:50 --> Final output sent to browser
DEBUG - 2020-08-24 15:45:50 --> Total execution time: 0.0484
INFO - 2020-08-24 15:46:09 --> Config Class Initialized
INFO - 2020-08-24 15:46:09 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:46:09 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:46:09 --> Utf8 Class Initialized
INFO - 2020-08-24 15:46:09 --> URI Class Initialized
INFO - 2020-08-24 15:46:09 --> Router Class Initialized
INFO - 2020-08-24 15:46:09 --> Output Class Initialized
INFO - 2020-08-24 15:46:09 --> Security Class Initialized
DEBUG - 2020-08-24 15:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:46:09 --> Input Class Initialized
INFO - 2020-08-24 15:46:09 --> Language Class Initialized
INFO - 2020-08-24 15:46:09 --> Language Class Initialized
INFO - 2020-08-24 15:46:09 --> Config Class Initialized
INFO - 2020-08-24 15:46:09 --> Loader Class Initialized
INFO - 2020-08-24 15:46:09 --> Helper loaded: url_helper
INFO - 2020-08-24 15:46:09 --> Helper loaded: form_helper
INFO - 2020-08-24 15:46:09 --> Helper loaded: file_helper
INFO - 2020-08-24 15:46:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:46:09 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:46:09 --> Upload Class Initialized
INFO - 2020-08-24 15:46:09 --> Controller Class Initialized
DEBUG - 2020-08-24 15:46:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:46:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:46:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:46:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:46:09 --> Final output sent to browser
DEBUG - 2020-08-24 15:46:09 --> Total execution time: 0.0495
INFO - 2020-08-24 15:46:33 --> Config Class Initialized
INFO - 2020-08-24 15:46:33 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:46:33 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:46:33 --> Utf8 Class Initialized
INFO - 2020-08-24 15:46:33 --> URI Class Initialized
INFO - 2020-08-24 15:46:33 --> Router Class Initialized
INFO - 2020-08-24 15:46:33 --> Output Class Initialized
INFO - 2020-08-24 15:46:33 --> Security Class Initialized
DEBUG - 2020-08-24 15:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:46:33 --> Input Class Initialized
INFO - 2020-08-24 15:46:33 --> Language Class Initialized
INFO - 2020-08-24 15:46:33 --> Language Class Initialized
INFO - 2020-08-24 15:46:33 --> Config Class Initialized
INFO - 2020-08-24 15:46:33 --> Loader Class Initialized
INFO - 2020-08-24 15:46:33 --> Helper loaded: url_helper
INFO - 2020-08-24 15:46:33 --> Helper loaded: form_helper
INFO - 2020-08-24 15:46:33 --> Helper loaded: file_helper
INFO - 2020-08-24 15:46:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:46:33 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:46:33 --> Upload Class Initialized
INFO - 2020-08-24 15:46:33 --> Controller Class Initialized
DEBUG - 2020-08-24 15:46:33 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:46:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:46:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:46:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:46:33 --> Final output sent to browser
DEBUG - 2020-08-24 15:46:33 --> Total execution time: 0.0523
INFO - 2020-08-24 15:46:43 --> Config Class Initialized
INFO - 2020-08-24 15:46:43 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:46:43 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:46:43 --> Utf8 Class Initialized
INFO - 2020-08-24 15:46:43 --> URI Class Initialized
INFO - 2020-08-24 15:46:43 --> Router Class Initialized
INFO - 2020-08-24 15:46:43 --> Output Class Initialized
INFO - 2020-08-24 15:46:43 --> Security Class Initialized
DEBUG - 2020-08-24 15:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:46:43 --> Input Class Initialized
INFO - 2020-08-24 15:46:43 --> Language Class Initialized
INFO - 2020-08-24 15:46:43 --> Language Class Initialized
INFO - 2020-08-24 15:46:43 --> Config Class Initialized
INFO - 2020-08-24 15:46:43 --> Loader Class Initialized
INFO - 2020-08-24 15:46:43 --> Helper loaded: url_helper
INFO - 2020-08-24 15:46:43 --> Helper loaded: form_helper
INFO - 2020-08-24 15:46:43 --> Helper loaded: file_helper
INFO - 2020-08-24 15:46:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:46:43 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:46:43 --> Upload Class Initialized
INFO - 2020-08-24 15:46:43 --> Controller Class Initialized
DEBUG - 2020-08-24 15:46:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:46:43 --> Final output sent to browser
DEBUG - 2020-08-24 15:46:43 --> Total execution time: 0.0634
INFO - 2020-08-24 15:47:08 --> Config Class Initialized
INFO - 2020-08-24 15:47:08 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:47:08 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:47:08 --> Utf8 Class Initialized
INFO - 2020-08-24 15:47:08 --> URI Class Initialized
INFO - 2020-08-24 15:47:08 --> Router Class Initialized
INFO - 2020-08-24 15:47:08 --> Output Class Initialized
INFO - 2020-08-24 15:47:08 --> Security Class Initialized
DEBUG - 2020-08-24 15:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:47:08 --> Input Class Initialized
INFO - 2020-08-24 15:47:08 --> Language Class Initialized
INFO - 2020-08-24 15:47:08 --> Language Class Initialized
INFO - 2020-08-24 15:47:08 --> Config Class Initialized
INFO - 2020-08-24 15:47:08 --> Loader Class Initialized
INFO - 2020-08-24 15:47:08 --> Helper loaded: url_helper
INFO - 2020-08-24 15:47:08 --> Helper loaded: form_helper
INFO - 2020-08-24 15:47:08 --> Helper loaded: file_helper
INFO - 2020-08-24 15:47:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:47:08 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:47:08 --> Upload Class Initialized
INFO - 2020-08-24 15:47:08 --> Controller Class Initialized
DEBUG - 2020-08-24 15:47:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:47:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:47:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:47:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:47:08 --> Final output sent to browser
DEBUG - 2020-08-24 15:47:08 --> Total execution time: 0.0651
INFO - 2020-08-24 15:47:35 --> Config Class Initialized
INFO - 2020-08-24 15:47:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:47:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:47:35 --> Utf8 Class Initialized
INFO - 2020-08-24 15:47:35 --> URI Class Initialized
INFO - 2020-08-24 15:47:35 --> Router Class Initialized
INFO - 2020-08-24 15:47:35 --> Output Class Initialized
INFO - 2020-08-24 15:47:35 --> Security Class Initialized
DEBUG - 2020-08-24 15:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:47:35 --> Input Class Initialized
INFO - 2020-08-24 15:47:35 --> Language Class Initialized
INFO - 2020-08-24 15:47:35 --> Language Class Initialized
INFO - 2020-08-24 15:47:35 --> Config Class Initialized
INFO - 2020-08-24 15:47:35 --> Loader Class Initialized
INFO - 2020-08-24 15:47:35 --> Helper loaded: url_helper
INFO - 2020-08-24 15:47:35 --> Helper loaded: form_helper
INFO - 2020-08-24 15:47:35 --> Helper loaded: file_helper
INFO - 2020-08-24 15:47:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:47:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:47:35 --> Upload Class Initialized
INFO - 2020-08-24 15:47:35 --> Controller Class Initialized
DEBUG - 2020-08-24 15:47:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:47:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:47:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:47:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:47:35 --> Final output sent to browser
DEBUG - 2020-08-24 15:47:35 --> Total execution time: 0.0465
INFO - 2020-08-24 15:47:49 --> Config Class Initialized
INFO - 2020-08-24 15:47:49 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:47:49 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:47:49 --> Utf8 Class Initialized
INFO - 2020-08-24 15:47:49 --> URI Class Initialized
INFO - 2020-08-24 15:47:49 --> Router Class Initialized
INFO - 2020-08-24 15:47:49 --> Output Class Initialized
INFO - 2020-08-24 15:47:49 --> Security Class Initialized
DEBUG - 2020-08-24 15:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:47:49 --> Input Class Initialized
INFO - 2020-08-24 15:47:49 --> Language Class Initialized
INFO - 2020-08-24 15:47:49 --> Language Class Initialized
INFO - 2020-08-24 15:47:49 --> Config Class Initialized
INFO - 2020-08-24 15:47:49 --> Loader Class Initialized
INFO - 2020-08-24 15:47:49 --> Helper loaded: url_helper
INFO - 2020-08-24 15:47:49 --> Helper loaded: form_helper
INFO - 2020-08-24 15:47:49 --> Helper loaded: file_helper
INFO - 2020-08-24 15:47:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:47:49 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:47:49 --> Upload Class Initialized
INFO - 2020-08-24 15:47:49 --> Controller Class Initialized
DEBUG - 2020-08-24 15:47:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:47:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:47:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:47:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:47:49 --> Final output sent to browser
DEBUG - 2020-08-24 15:47:49 --> Total execution time: 0.0454
INFO - 2020-08-24 15:47:57 --> Config Class Initialized
INFO - 2020-08-24 15:47:57 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:47:57 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:47:57 --> Utf8 Class Initialized
INFO - 2020-08-24 15:47:57 --> URI Class Initialized
INFO - 2020-08-24 15:47:57 --> Router Class Initialized
INFO - 2020-08-24 15:47:57 --> Output Class Initialized
INFO - 2020-08-24 15:47:57 --> Security Class Initialized
DEBUG - 2020-08-24 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:47:57 --> Input Class Initialized
INFO - 2020-08-24 15:47:57 --> Language Class Initialized
INFO - 2020-08-24 15:47:57 --> Language Class Initialized
INFO - 2020-08-24 15:47:57 --> Config Class Initialized
INFO - 2020-08-24 15:47:57 --> Loader Class Initialized
INFO - 2020-08-24 15:47:57 --> Helper loaded: url_helper
INFO - 2020-08-24 15:47:57 --> Helper loaded: form_helper
INFO - 2020-08-24 15:47:57 --> Helper loaded: file_helper
INFO - 2020-08-24 15:47:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:47:57 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:47:57 --> Upload Class Initialized
INFO - 2020-08-24 15:47:57 --> Controller Class Initialized
DEBUG - 2020-08-24 15:47:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:47:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:47:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:47:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:47:57 --> Final output sent to browser
DEBUG - 2020-08-24 15:47:57 --> Total execution time: 0.0474
INFO - 2020-08-24 15:48:04 --> Config Class Initialized
INFO - 2020-08-24 15:48:04 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:48:04 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:48:04 --> Utf8 Class Initialized
INFO - 2020-08-24 15:48:04 --> URI Class Initialized
INFO - 2020-08-24 15:48:04 --> Router Class Initialized
INFO - 2020-08-24 15:48:04 --> Output Class Initialized
INFO - 2020-08-24 15:48:04 --> Security Class Initialized
DEBUG - 2020-08-24 15:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:48:04 --> Input Class Initialized
INFO - 2020-08-24 15:48:04 --> Language Class Initialized
INFO - 2020-08-24 15:48:04 --> Language Class Initialized
INFO - 2020-08-24 15:48:04 --> Config Class Initialized
INFO - 2020-08-24 15:48:04 --> Loader Class Initialized
INFO - 2020-08-24 15:48:04 --> Helper loaded: url_helper
INFO - 2020-08-24 15:48:04 --> Helper loaded: form_helper
INFO - 2020-08-24 15:48:04 --> Helper loaded: file_helper
INFO - 2020-08-24 15:48:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:48:04 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:48:04 --> Upload Class Initialized
INFO - 2020-08-24 15:48:04 --> Controller Class Initialized
DEBUG - 2020-08-24 15:48:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:48:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:48:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:48:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:48:04 --> Final output sent to browser
DEBUG - 2020-08-24 15:48:04 --> Total execution time: 0.0690
INFO - 2020-08-24 15:48:11 --> Config Class Initialized
INFO - 2020-08-24 15:48:11 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:48:11 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:48:11 --> Utf8 Class Initialized
INFO - 2020-08-24 15:48:11 --> URI Class Initialized
INFO - 2020-08-24 15:48:11 --> Router Class Initialized
INFO - 2020-08-24 15:48:11 --> Output Class Initialized
INFO - 2020-08-24 15:48:11 --> Security Class Initialized
DEBUG - 2020-08-24 15:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:48:11 --> Input Class Initialized
INFO - 2020-08-24 15:48:11 --> Language Class Initialized
INFO - 2020-08-24 15:48:11 --> Language Class Initialized
INFO - 2020-08-24 15:48:11 --> Config Class Initialized
INFO - 2020-08-24 15:48:11 --> Loader Class Initialized
INFO - 2020-08-24 15:48:11 --> Helper loaded: url_helper
INFO - 2020-08-24 15:48:11 --> Helper loaded: form_helper
INFO - 2020-08-24 15:48:11 --> Helper loaded: file_helper
INFO - 2020-08-24 15:48:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:48:11 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:48:11 --> Upload Class Initialized
INFO - 2020-08-24 15:48:11 --> Controller Class Initialized
DEBUG - 2020-08-24 15:48:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:48:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:48:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:48:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:48:11 --> Final output sent to browser
DEBUG - 2020-08-24 15:48:11 --> Total execution time: 0.0474
INFO - 2020-08-24 15:48:12 --> Config Class Initialized
INFO - 2020-08-24 15:48:12 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:48:12 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:48:12 --> Utf8 Class Initialized
INFO - 2020-08-24 15:48:12 --> URI Class Initialized
INFO - 2020-08-24 15:48:12 --> Router Class Initialized
INFO - 2020-08-24 15:48:12 --> Output Class Initialized
INFO - 2020-08-24 15:48:12 --> Security Class Initialized
DEBUG - 2020-08-24 15:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:48:12 --> Input Class Initialized
INFO - 2020-08-24 15:48:12 --> Language Class Initialized
INFO - 2020-08-24 15:48:12 --> Language Class Initialized
INFO - 2020-08-24 15:48:12 --> Config Class Initialized
INFO - 2020-08-24 15:48:12 --> Loader Class Initialized
INFO - 2020-08-24 15:48:12 --> Helper loaded: url_helper
INFO - 2020-08-24 15:48:12 --> Helper loaded: form_helper
INFO - 2020-08-24 15:48:12 --> Helper loaded: file_helper
INFO - 2020-08-24 15:48:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:48:12 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:48:12 --> Upload Class Initialized
INFO - 2020-08-24 15:48:12 --> Controller Class Initialized
DEBUG - 2020-08-24 15:48:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:48:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:48:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:48:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:48:12 --> Final output sent to browser
DEBUG - 2020-08-24 15:48:12 --> Total execution time: 0.0466
INFO - 2020-08-24 15:48:16 --> Config Class Initialized
INFO - 2020-08-24 15:48:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:48:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:48:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:48:16 --> URI Class Initialized
INFO - 2020-08-24 15:48:16 --> Router Class Initialized
INFO - 2020-08-24 15:48:16 --> Output Class Initialized
INFO - 2020-08-24 15:48:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:48:16 --> Input Class Initialized
INFO - 2020-08-24 15:48:16 --> Language Class Initialized
INFO - 2020-08-24 15:48:16 --> Language Class Initialized
INFO - 2020-08-24 15:48:16 --> Config Class Initialized
INFO - 2020-08-24 15:48:16 --> Loader Class Initialized
INFO - 2020-08-24 15:48:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:48:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:48:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:48:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:48:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:48:16 --> Upload Class Initialized
INFO - 2020-08-24 15:48:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:48:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:48:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:48:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:48:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:48:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:48:16 --> Total execution time: 0.0461
INFO - 2020-08-24 15:49:16 --> Config Class Initialized
INFO - 2020-08-24 15:49:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:49:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:49:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:49:16 --> URI Class Initialized
INFO - 2020-08-24 15:49:16 --> Router Class Initialized
INFO - 2020-08-24 15:49:16 --> Output Class Initialized
INFO - 2020-08-24 15:49:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:49:16 --> Input Class Initialized
INFO - 2020-08-24 15:49:16 --> Language Class Initialized
INFO - 2020-08-24 15:49:16 --> Language Class Initialized
INFO - 2020-08-24 15:49:16 --> Config Class Initialized
INFO - 2020-08-24 15:49:16 --> Loader Class Initialized
INFO - 2020-08-24 15:49:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:49:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:49:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:49:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:49:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:49:16 --> Upload Class Initialized
INFO - 2020-08-24 15:49:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:49:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:49:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:49:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:49:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:49:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:49:16 --> Total execution time: 0.0548
INFO - 2020-08-24 15:49:31 --> Config Class Initialized
INFO - 2020-08-24 15:49:31 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:49:31 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:49:31 --> Utf8 Class Initialized
INFO - 2020-08-24 15:49:31 --> URI Class Initialized
INFO - 2020-08-24 15:49:31 --> Router Class Initialized
INFO - 2020-08-24 15:49:31 --> Output Class Initialized
INFO - 2020-08-24 15:49:31 --> Security Class Initialized
DEBUG - 2020-08-24 15:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:49:31 --> Input Class Initialized
INFO - 2020-08-24 15:49:31 --> Language Class Initialized
INFO - 2020-08-24 15:49:31 --> Language Class Initialized
INFO - 2020-08-24 15:49:31 --> Config Class Initialized
INFO - 2020-08-24 15:49:31 --> Loader Class Initialized
INFO - 2020-08-24 15:49:31 --> Helper loaded: url_helper
INFO - 2020-08-24 15:49:31 --> Helper loaded: form_helper
INFO - 2020-08-24 15:49:31 --> Helper loaded: file_helper
INFO - 2020-08-24 15:49:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:49:31 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:49:31 --> Upload Class Initialized
INFO - 2020-08-24 15:49:31 --> Controller Class Initialized
DEBUG - 2020-08-24 15:49:31 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:49:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:49:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:49:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:49:31 --> Final output sent to browser
DEBUG - 2020-08-24 15:49:31 --> Total execution time: 0.0481
INFO - 2020-08-24 15:49:44 --> Config Class Initialized
INFO - 2020-08-24 15:49:44 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:49:44 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:49:44 --> Utf8 Class Initialized
INFO - 2020-08-24 15:49:44 --> URI Class Initialized
INFO - 2020-08-24 15:49:44 --> Router Class Initialized
INFO - 2020-08-24 15:49:44 --> Output Class Initialized
INFO - 2020-08-24 15:49:44 --> Security Class Initialized
DEBUG - 2020-08-24 15:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:49:44 --> Input Class Initialized
INFO - 2020-08-24 15:49:44 --> Language Class Initialized
INFO - 2020-08-24 15:49:44 --> Language Class Initialized
INFO - 2020-08-24 15:49:44 --> Config Class Initialized
INFO - 2020-08-24 15:49:44 --> Loader Class Initialized
INFO - 2020-08-24 15:49:44 --> Helper loaded: url_helper
INFO - 2020-08-24 15:49:44 --> Helper loaded: form_helper
INFO - 2020-08-24 15:49:44 --> Helper loaded: file_helper
INFO - 2020-08-24 15:49:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:49:44 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:49:44 --> Upload Class Initialized
INFO - 2020-08-24 15:49:44 --> Controller Class Initialized
DEBUG - 2020-08-24 15:49:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:49:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:49:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:49:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:49:44 --> Final output sent to browser
DEBUG - 2020-08-24 15:49:44 --> Total execution time: 0.0520
INFO - 2020-08-24 15:49:46 --> Config Class Initialized
INFO - 2020-08-24 15:49:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:49:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:49:46 --> Utf8 Class Initialized
INFO - 2020-08-24 15:49:46 --> URI Class Initialized
INFO - 2020-08-24 15:49:46 --> Router Class Initialized
INFO - 2020-08-24 15:49:46 --> Output Class Initialized
INFO - 2020-08-24 15:49:46 --> Security Class Initialized
DEBUG - 2020-08-24 15:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:49:46 --> Input Class Initialized
INFO - 2020-08-24 15:49:46 --> Language Class Initialized
INFO - 2020-08-24 15:49:46 --> Language Class Initialized
INFO - 2020-08-24 15:49:46 --> Config Class Initialized
INFO - 2020-08-24 15:49:46 --> Loader Class Initialized
INFO - 2020-08-24 15:49:46 --> Helper loaded: url_helper
INFO - 2020-08-24 15:49:46 --> Helper loaded: form_helper
INFO - 2020-08-24 15:49:46 --> Helper loaded: file_helper
INFO - 2020-08-24 15:49:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:49:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:49:46 --> Upload Class Initialized
INFO - 2020-08-24 15:49:46 --> Controller Class Initialized
DEBUG - 2020-08-24 15:49:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:49:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:49:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:49:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:49:46 --> Final output sent to browser
DEBUG - 2020-08-24 15:49:46 --> Total execution time: 0.0504
INFO - 2020-08-24 15:49:52 --> Config Class Initialized
INFO - 2020-08-24 15:49:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:49:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:49:52 --> Utf8 Class Initialized
INFO - 2020-08-24 15:49:52 --> URI Class Initialized
INFO - 2020-08-24 15:49:52 --> Router Class Initialized
INFO - 2020-08-24 15:49:52 --> Output Class Initialized
INFO - 2020-08-24 15:49:52 --> Security Class Initialized
DEBUG - 2020-08-24 15:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:49:52 --> Input Class Initialized
INFO - 2020-08-24 15:49:52 --> Language Class Initialized
INFO - 2020-08-24 15:49:52 --> Language Class Initialized
INFO - 2020-08-24 15:49:52 --> Config Class Initialized
INFO - 2020-08-24 15:49:52 --> Loader Class Initialized
INFO - 2020-08-24 15:49:52 --> Helper loaded: url_helper
INFO - 2020-08-24 15:49:52 --> Helper loaded: form_helper
INFO - 2020-08-24 15:49:52 --> Helper loaded: file_helper
INFO - 2020-08-24 15:49:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:49:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:49:52 --> Upload Class Initialized
INFO - 2020-08-24 15:49:52 --> Controller Class Initialized
DEBUG - 2020-08-24 15:49:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:49:52 --> Final output sent to browser
DEBUG - 2020-08-24 15:49:52 --> Total execution time: 0.0687
INFO - 2020-08-24 15:49:57 --> Config Class Initialized
INFO - 2020-08-24 15:49:57 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:49:57 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:49:57 --> Utf8 Class Initialized
INFO - 2020-08-24 15:49:57 --> URI Class Initialized
INFO - 2020-08-24 15:49:57 --> Router Class Initialized
INFO - 2020-08-24 15:49:57 --> Output Class Initialized
INFO - 2020-08-24 15:49:57 --> Security Class Initialized
DEBUG - 2020-08-24 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:49:57 --> Input Class Initialized
INFO - 2020-08-24 15:49:57 --> Language Class Initialized
INFO - 2020-08-24 15:49:57 --> Language Class Initialized
INFO - 2020-08-24 15:49:57 --> Config Class Initialized
INFO - 2020-08-24 15:49:57 --> Loader Class Initialized
INFO - 2020-08-24 15:49:57 --> Helper loaded: url_helper
INFO - 2020-08-24 15:49:57 --> Helper loaded: form_helper
INFO - 2020-08-24 15:49:57 --> Helper loaded: file_helper
INFO - 2020-08-24 15:49:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:49:57 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:49:57 --> Upload Class Initialized
INFO - 2020-08-24 15:49:57 --> Controller Class Initialized
DEBUG - 2020-08-24 15:49:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:49:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:49:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:49:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:49:57 --> Final output sent to browser
DEBUG - 2020-08-24 15:49:57 --> Total execution time: 0.0598
INFO - 2020-08-24 15:50:16 --> Config Class Initialized
INFO - 2020-08-24 15:50:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:50:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:50:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:50:16 --> URI Class Initialized
INFO - 2020-08-24 15:50:16 --> Router Class Initialized
INFO - 2020-08-24 15:50:16 --> Output Class Initialized
INFO - 2020-08-24 15:50:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:50:16 --> Input Class Initialized
INFO - 2020-08-24 15:50:16 --> Language Class Initialized
INFO - 2020-08-24 15:50:16 --> Language Class Initialized
INFO - 2020-08-24 15:50:16 --> Config Class Initialized
INFO - 2020-08-24 15:50:16 --> Loader Class Initialized
INFO - 2020-08-24 15:50:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:50:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:50:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:50:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:50:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:50:16 --> Upload Class Initialized
INFO - 2020-08-24 15:50:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:50:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:50:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:50:16 --> Total execution time: 0.0554
INFO - 2020-08-24 15:50:38 --> Config Class Initialized
INFO - 2020-08-24 15:50:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:50:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:50:38 --> Utf8 Class Initialized
INFO - 2020-08-24 15:50:38 --> URI Class Initialized
INFO - 2020-08-24 15:50:38 --> Router Class Initialized
INFO - 2020-08-24 15:50:38 --> Output Class Initialized
INFO - 2020-08-24 15:50:38 --> Security Class Initialized
DEBUG - 2020-08-24 15:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:50:38 --> Input Class Initialized
INFO - 2020-08-24 15:50:38 --> Language Class Initialized
INFO - 2020-08-24 15:50:38 --> Language Class Initialized
INFO - 2020-08-24 15:50:38 --> Config Class Initialized
INFO - 2020-08-24 15:50:38 --> Loader Class Initialized
INFO - 2020-08-24 15:50:38 --> Helper loaded: url_helper
INFO - 2020-08-24 15:50:38 --> Helper loaded: form_helper
INFO - 2020-08-24 15:50:38 --> Helper loaded: file_helper
INFO - 2020-08-24 15:50:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:50:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:50:38 --> Upload Class Initialized
INFO - 2020-08-24 15:50:38 --> Controller Class Initialized
DEBUG - 2020-08-24 15:50:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:50:38 --> Final output sent to browser
DEBUG - 2020-08-24 15:50:38 --> Total execution time: 0.0529
INFO - 2020-08-24 15:50:39 --> Config Class Initialized
INFO - 2020-08-24 15:50:39 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:50:39 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:50:39 --> Utf8 Class Initialized
INFO - 2020-08-24 15:50:39 --> URI Class Initialized
INFO - 2020-08-24 15:50:39 --> Router Class Initialized
INFO - 2020-08-24 15:50:39 --> Output Class Initialized
INFO - 2020-08-24 15:50:39 --> Security Class Initialized
DEBUG - 2020-08-24 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:50:39 --> Input Class Initialized
INFO - 2020-08-24 15:50:39 --> Language Class Initialized
INFO - 2020-08-24 15:50:39 --> Language Class Initialized
INFO - 2020-08-24 15:50:39 --> Config Class Initialized
INFO - 2020-08-24 15:50:39 --> Loader Class Initialized
INFO - 2020-08-24 15:50:39 --> Helper loaded: url_helper
INFO - 2020-08-24 15:50:39 --> Helper loaded: form_helper
INFO - 2020-08-24 15:50:39 --> Helper loaded: file_helper
INFO - 2020-08-24 15:50:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:50:39 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:50:39 --> Upload Class Initialized
INFO - 2020-08-24 15:50:39 --> Controller Class Initialized
DEBUG - 2020-08-24 15:50:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:50:39 --> Final output sent to browser
DEBUG - 2020-08-24 15:50:39 --> Total execution time: 0.0499
INFO - 2020-08-24 15:50:39 --> Config Class Initialized
INFO - 2020-08-24 15:50:39 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:50:39 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:50:39 --> Utf8 Class Initialized
INFO - 2020-08-24 15:50:39 --> URI Class Initialized
INFO - 2020-08-24 15:50:39 --> Router Class Initialized
INFO - 2020-08-24 15:50:39 --> Output Class Initialized
INFO - 2020-08-24 15:50:39 --> Security Class Initialized
DEBUG - 2020-08-24 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:50:39 --> Input Class Initialized
INFO - 2020-08-24 15:50:39 --> Language Class Initialized
INFO - 2020-08-24 15:50:39 --> Language Class Initialized
INFO - 2020-08-24 15:50:39 --> Config Class Initialized
INFO - 2020-08-24 15:50:39 --> Loader Class Initialized
INFO - 2020-08-24 15:50:39 --> Helper loaded: url_helper
INFO - 2020-08-24 15:50:39 --> Helper loaded: form_helper
INFO - 2020-08-24 15:50:39 --> Helper loaded: file_helper
INFO - 2020-08-24 15:50:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:50:39 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:50:39 --> Upload Class Initialized
INFO - 2020-08-24 15:50:39 --> Controller Class Initialized
DEBUG - 2020-08-24 15:50:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:50:39 --> Final output sent to browser
DEBUG - 2020-08-24 15:50:39 --> Total execution time: 0.0501
INFO - 2020-08-24 15:51:47 --> Config Class Initialized
INFO - 2020-08-24 15:51:47 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:51:47 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:51:47 --> Utf8 Class Initialized
INFO - 2020-08-24 15:51:47 --> URI Class Initialized
INFO - 2020-08-24 15:51:47 --> Router Class Initialized
INFO - 2020-08-24 15:51:47 --> Output Class Initialized
INFO - 2020-08-24 15:51:47 --> Security Class Initialized
DEBUG - 2020-08-24 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:51:47 --> Input Class Initialized
INFO - 2020-08-24 15:51:47 --> Language Class Initialized
INFO - 2020-08-24 15:51:47 --> Language Class Initialized
INFO - 2020-08-24 15:51:47 --> Config Class Initialized
INFO - 2020-08-24 15:51:47 --> Loader Class Initialized
INFO - 2020-08-24 15:51:47 --> Helper loaded: url_helper
INFO - 2020-08-24 15:51:47 --> Helper loaded: form_helper
INFO - 2020-08-24 15:51:47 --> Helper loaded: file_helper
INFO - 2020-08-24 15:51:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:51:47 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:51:47 --> Upload Class Initialized
INFO - 2020-08-24 15:51:47 --> Controller Class Initialized
DEBUG - 2020-08-24 15:51:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:51:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:51:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:51:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:51:47 --> Final output sent to browser
DEBUG - 2020-08-24 15:51:47 --> Total execution time: 0.0497
INFO - 2020-08-24 15:51:53 --> Config Class Initialized
INFO - 2020-08-24 15:51:53 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:51:53 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:51:53 --> Utf8 Class Initialized
INFO - 2020-08-24 15:51:53 --> URI Class Initialized
INFO - 2020-08-24 15:51:53 --> Router Class Initialized
INFO - 2020-08-24 15:51:53 --> Output Class Initialized
INFO - 2020-08-24 15:51:53 --> Security Class Initialized
DEBUG - 2020-08-24 15:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:51:53 --> Input Class Initialized
INFO - 2020-08-24 15:51:53 --> Language Class Initialized
INFO - 2020-08-24 15:51:53 --> Language Class Initialized
INFO - 2020-08-24 15:51:53 --> Config Class Initialized
INFO - 2020-08-24 15:51:53 --> Loader Class Initialized
INFO - 2020-08-24 15:51:53 --> Helper loaded: url_helper
INFO - 2020-08-24 15:51:53 --> Helper loaded: form_helper
INFO - 2020-08-24 15:51:53 --> Helper loaded: file_helper
INFO - 2020-08-24 15:51:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:51:53 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:51:53 --> Upload Class Initialized
INFO - 2020-08-24 15:51:53 --> Controller Class Initialized
DEBUG - 2020-08-24 15:51:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:51:53 --> Final output sent to browser
DEBUG - 2020-08-24 15:51:53 --> Total execution time: 0.0568
INFO - 2020-08-24 15:52:21 --> Config Class Initialized
INFO - 2020-08-24 15:52:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:52:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:52:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:52:21 --> URI Class Initialized
INFO - 2020-08-24 15:52:21 --> Router Class Initialized
INFO - 2020-08-24 15:52:21 --> Output Class Initialized
INFO - 2020-08-24 15:52:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:52:21 --> Input Class Initialized
INFO - 2020-08-24 15:52:21 --> Language Class Initialized
INFO - 2020-08-24 15:52:21 --> Language Class Initialized
INFO - 2020-08-24 15:52:21 --> Config Class Initialized
INFO - 2020-08-24 15:52:21 --> Loader Class Initialized
INFO - 2020-08-24 15:52:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:52:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:52:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:52:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:52:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:52:21 --> Upload Class Initialized
INFO - 2020-08-24 15:52:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:52:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:52:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:52:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:52:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:52:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:52:21 --> Total execution time: 0.0766
INFO - 2020-08-24 15:52:39 --> Config Class Initialized
INFO - 2020-08-24 15:52:39 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:52:39 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:52:39 --> Utf8 Class Initialized
INFO - 2020-08-24 15:52:39 --> URI Class Initialized
INFO - 2020-08-24 15:52:39 --> Router Class Initialized
INFO - 2020-08-24 15:52:39 --> Output Class Initialized
INFO - 2020-08-24 15:52:39 --> Security Class Initialized
DEBUG - 2020-08-24 15:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:52:39 --> Input Class Initialized
INFO - 2020-08-24 15:52:39 --> Language Class Initialized
INFO - 2020-08-24 15:52:39 --> Language Class Initialized
INFO - 2020-08-24 15:52:39 --> Config Class Initialized
INFO - 2020-08-24 15:52:39 --> Loader Class Initialized
INFO - 2020-08-24 15:52:39 --> Helper loaded: url_helper
INFO - 2020-08-24 15:52:39 --> Helper loaded: form_helper
INFO - 2020-08-24 15:52:39 --> Helper loaded: file_helper
INFO - 2020-08-24 15:52:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:52:39 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:52:39 --> Upload Class Initialized
INFO - 2020-08-24 15:52:39 --> Controller Class Initialized
DEBUG - 2020-08-24 15:52:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:52:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:52:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:52:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:52:39 --> Final output sent to browser
DEBUG - 2020-08-24 15:52:39 --> Total execution time: 0.0541
INFO - 2020-08-24 15:52:48 --> Config Class Initialized
INFO - 2020-08-24 15:52:48 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:52:48 --> Utf8 Class Initialized
INFO - 2020-08-24 15:52:48 --> URI Class Initialized
INFO - 2020-08-24 15:52:48 --> Router Class Initialized
INFO - 2020-08-24 15:52:48 --> Output Class Initialized
INFO - 2020-08-24 15:52:48 --> Security Class Initialized
DEBUG - 2020-08-24 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:52:48 --> Input Class Initialized
INFO - 2020-08-24 15:52:48 --> Language Class Initialized
INFO - 2020-08-24 15:52:48 --> Language Class Initialized
INFO - 2020-08-24 15:52:48 --> Config Class Initialized
INFO - 2020-08-24 15:52:48 --> Loader Class Initialized
INFO - 2020-08-24 15:52:48 --> Helper loaded: url_helper
INFO - 2020-08-24 15:52:48 --> Helper loaded: form_helper
INFO - 2020-08-24 15:52:48 --> Helper loaded: file_helper
INFO - 2020-08-24 15:52:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:52:48 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:52:48 --> Upload Class Initialized
INFO - 2020-08-24 15:52:48 --> Controller Class Initialized
DEBUG - 2020-08-24 15:52:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:52:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:52:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:52:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:52:48 --> Final output sent to browser
DEBUG - 2020-08-24 15:52:48 --> Total execution time: 0.0766
INFO - 2020-08-24 15:52:50 --> Config Class Initialized
INFO - 2020-08-24 15:52:50 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:52:50 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:52:50 --> Utf8 Class Initialized
INFO - 2020-08-24 15:52:50 --> URI Class Initialized
INFO - 2020-08-24 15:52:50 --> Router Class Initialized
INFO - 2020-08-24 15:52:50 --> Output Class Initialized
INFO - 2020-08-24 15:52:50 --> Security Class Initialized
DEBUG - 2020-08-24 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:52:50 --> Input Class Initialized
INFO - 2020-08-24 15:52:50 --> Language Class Initialized
INFO - 2020-08-24 15:52:50 --> Language Class Initialized
INFO - 2020-08-24 15:52:50 --> Config Class Initialized
INFO - 2020-08-24 15:52:50 --> Loader Class Initialized
INFO - 2020-08-24 15:52:50 --> Helper loaded: url_helper
INFO - 2020-08-24 15:52:50 --> Helper loaded: form_helper
INFO - 2020-08-24 15:52:50 --> Helper loaded: file_helper
INFO - 2020-08-24 15:52:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:52:50 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:52:50 --> Upload Class Initialized
INFO - 2020-08-24 15:52:50 --> Controller Class Initialized
DEBUG - 2020-08-24 15:52:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:52:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:52:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:52:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:52:50 --> Final output sent to browser
DEBUG - 2020-08-24 15:52:50 --> Total execution time: 0.0554
INFO - 2020-08-24 15:52:55 --> Config Class Initialized
INFO - 2020-08-24 15:52:55 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:52:55 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:52:55 --> Utf8 Class Initialized
INFO - 2020-08-24 15:52:55 --> URI Class Initialized
INFO - 2020-08-24 15:52:55 --> Router Class Initialized
INFO - 2020-08-24 15:52:55 --> Output Class Initialized
INFO - 2020-08-24 15:52:55 --> Security Class Initialized
DEBUG - 2020-08-24 15:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:52:55 --> Input Class Initialized
INFO - 2020-08-24 15:52:55 --> Language Class Initialized
INFO - 2020-08-24 15:52:55 --> Language Class Initialized
INFO - 2020-08-24 15:52:55 --> Config Class Initialized
INFO - 2020-08-24 15:52:55 --> Loader Class Initialized
INFO - 2020-08-24 15:52:55 --> Helper loaded: url_helper
INFO - 2020-08-24 15:52:55 --> Helper loaded: form_helper
INFO - 2020-08-24 15:52:55 --> Helper loaded: file_helper
INFO - 2020-08-24 15:52:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:52:55 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:52:55 --> Upload Class Initialized
INFO - 2020-08-24 15:52:55 --> Controller Class Initialized
DEBUG - 2020-08-24 15:52:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:52:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:52:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:52:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:52:55 --> Final output sent to browser
DEBUG - 2020-08-24 15:52:55 --> Total execution time: 0.0597
INFO - 2020-08-24 15:53:28 --> Config Class Initialized
INFO - 2020-08-24 15:53:28 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:53:28 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:53:28 --> Utf8 Class Initialized
INFO - 2020-08-24 15:53:28 --> URI Class Initialized
INFO - 2020-08-24 15:53:28 --> Router Class Initialized
INFO - 2020-08-24 15:53:28 --> Output Class Initialized
INFO - 2020-08-24 15:53:28 --> Security Class Initialized
DEBUG - 2020-08-24 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:53:28 --> Input Class Initialized
INFO - 2020-08-24 15:53:28 --> Language Class Initialized
INFO - 2020-08-24 15:53:28 --> Language Class Initialized
INFO - 2020-08-24 15:53:28 --> Config Class Initialized
INFO - 2020-08-24 15:53:28 --> Loader Class Initialized
INFO - 2020-08-24 15:53:28 --> Helper loaded: url_helper
INFO - 2020-08-24 15:53:28 --> Helper loaded: form_helper
INFO - 2020-08-24 15:53:28 --> Helper loaded: file_helper
INFO - 2020-08-24 15:53:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:53:28 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:53:28 --> Upload Class Initialized
INFO - 2020-08-24 15:53:28 --> Controller Class Initialized
DEBUG - 2020-08-24 15:53:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:53:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:53:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:53:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:53:28 --> Final output sent to browser
DEBUG - 2020-08-24 15:53:28 --> Total execution time: 0.0525
INFO - 2020-08-24 15:54:14 --> Config Class Initialized
INFO - 2020-08-24 15:54:14 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:54:14 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:54:14 --> Utf8 Class Initialized
INFO - 2020-08-24 15:54:14 --> URI Class Initialized
INFO - 2020-08-24 15:54:14 --> Router Class Initialized
INFO - 2020-08-24 15:54:14 --> Output Class Initialized
INFO - 2020-08-24 15:54:14 --> Security Class Initialized
DEBUG - 2020-08-24 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:54:14 --> Input Class Initialized
INFO - 2020-08-24 15:54:14 --> Language Class Initialized
INFO - 2020-08-24 15:54:14 --> Language Class Initialized
INFO - 2020-08-24 15:54:14 --> Config Class Initialized
INFO - 2020-08-24 15:54:14 --> Loader Class Initialized
INFO - 2020-08-24 15:54:14 --> Helper loaded: url_helper
INFO - 2020-08-24 15:54:14 --> Helper loaded: form_helper
INFO - 2020-08-24 15:54:14 --> Helper loaded: file_helper
INFO - 2020-08-24 15:54:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:54:14 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:54:14 --> Upload Class Initialized
INFO - 2020-08-24 15:54:14 --> Controller Class Initialized
DEBUG - 2020-08-24 15:54:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:54:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:54:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:54:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:54:14 --> Final output sent to browser
DEBUG - 2020-08-24 15:54:14 --> Total execution time: 0.0562
INFO - 2020-08-24 15:54:14 --> Config Class Initialized
INFO - 2020-08-24 15:54:14 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:54:14 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:54:14 --> Utf8 Class Initialized
INFO - 2020-08-24 15:54:14 --> URI Class Initialized
INFO - 2020-08-24 15:54:14 --> Router Class Initialized
INFO - 2020-08-24 15:54:14 --> Output Class Initialized
INFO - 2020-08-24 15:54:14 --> Security Class Initialized
DEBUG - 2020-08-24 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:54:14 --> Input Class Initialized
INFO - 2020-08-24 15:54:14 --> Language Class Initialized
INFO - 2020-08-24 15:54:14 --> Language Class Initialized
INFO - 2020-08-24 15:54:14 --> Config Class Initialized
INFO - 2020-08-24 15:54:14 --> Loader Class Initialized
INFO - 2020-08-24 15:54:14 --> Helper loaded: url_helper
INFO - 2020-08-24 15:54:14 --> Helper loaded: form_helper
INFO - 2020-08-24 15:54:14 --> Helper loaded: file_helper
INFO - 2020-08-24 15:54:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:54:14 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:54:14 --> Upload Class Initialized
INFO - 2020-08-24 15:54:14 --> Controller Class Initialized
DEBUG - 2020-08-24 15:54:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:54:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:54:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:54:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:54:14 --> Final output sent to browser
DEBUG - 2020-08-24 15:54:14 --> Total execution time: 0.0506
INFO - 2020-08-24 15:54:16 --> Config Class Initialized
INFO - 2020-08-24 15:54:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:54:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:54:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:54:16 --> URI Class Initialized
INFO - 2020-08-24 15:54:16 --> Router Class Initialized
INFO - 2020-08-24 15:54:16 --> Output Class Initialized
INFO - 2020-08-24 15:54:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:54:16 --> Input Class Initialized
INFO - 2020-08-24 15:54:16 --> Language Class Initialized
INFO - 2020-08-24 15:54:16 --> Language Class Initialized
INFO - 2020-08-24 15:54:16 --> Config Class Initialized
INFO - 2020-08-24 15:54:16 --> Loader Class Initialized
INFO - 2020-08-24 15:54:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:54:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:54:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:54:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:54:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:54:16 --> Upload Class Initialized
INFO - 2020-08-24 15:54:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:54:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:54:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:54:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:54:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:54:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:54:16 --> Total execution time: 0.0526
INFO - 2020-08-24 15:55:20 --> Config Class Initialized
INFO - 2020-08-24 15:55:20 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:55:20 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:55:20 --> Utf8 Class Initialized
INFO - 2020-08-24 15:55:20 --> URI Class Initialized
INFO - 2020-08-24 15:55:20 --> Router Class Initialized
INFO - 2020-08-24 15:55:20 --> Output Class Initialized
INFO - 2020-08-24 15:55:20 --> Security Class Initialized
DEBUG - 2020-08-24 15:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:55:20 --> Input Class Initialized
INFO - 2020-08-24 15:55:20 --> Language Class Initialized
INFO - 2020-08-24 15:55:20 --> Language Class Initialized
INFO - 2020-08-24 15:55:20 --> Config Class Initialized
INFO - 2020-08-24 15:55:20 --> Loader Class Initialized
INFO - 2020-08-24 15:55:20 --> Helper loaded: url_helper
INFO - 2020-08-24 15:55:20 --> Helper loaded: form_helper
INFO - 2020-08-24 15:55:20 --> Helper loaded: file_helper
INFO - 2020-08-24 15:55:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:55:20 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:55:20 --> Upload Class Initialized
INFO - 2020-08-24 15:55:20 --> Controller Class Initialized
ERROR - 2020-08-24 15:55:20 --> 404 Page Not Found: /index
INFO - 2020-08-24 15:55:21 --> Config Class Initialized
INFO - 2020-08-24 15:55:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:55:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:55:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:55:21 --> URI Class Initialized
DEBUG - 2020-08-24 15:55:21 --> No URI present. Default controller set.
INFO - 2020-08-24 15:55:21 --> Router Class Initialized
INFO - 2020-08-24 15:55:21 --> Output Class Initialized
INFO - 2020-08-24 15:55:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:55:21 --> Input Class Initialized
INFO - 2020-08-24 15:55:21 --> Language Class Initialized
INFO - 2020-08-24 15:55:21 --> Language Class Initialized
INFO - 2020-08-24 15:55:21 --> Config Class Initialized
INFO - 2020-08-24 15:55:21 --> Loader Class Initialized
INFO - 2020-08-24 15:55:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:55:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:55:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:55:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:55:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:55:21 --> Upload Class Initialized
INFO - 2020-08-24 15:55:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:55:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:55:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:55:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:55:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:55:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:55:21 --> Total execution time: 0.0520
INFO - 2020-08-24 15:55:24 --> Config Class Initialized
INFO - 2020-08-24 15:55:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:55:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:55:24 --> Utf8 Class Initialized
INFO - 2020-08-24 15:55:24 --> URI Class Initialized
INFO - 2020-08-24 15:55:24 --> Router Class Initialized
INFO - 2020-08-24 15:55:24 --> Output Class Initialized
INFO - 2020-08-24 15:55:24 --> Security Class Initialized
DEBUG - 2020-08-24 15:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:55:24 --> Input Class Initialized
INFO - 2020-08-24 15:55:24 --> Language Class Initialized
INFO - 2020-08-24 15:55:24 --> Language Class Initialized
INFO - 2020-08-24 15:55:24 --> Config Class Initialized
INFO - 2020-08-24 15:55:24 --> Loader Class Initialized
INFO - 2020-08-24 15:55:24 --> Helper loaded: url_helper
INFO - 2020-08-24 15:55:24 --> Helper loaded: form_helper
INFO - 2020-08-24 15:55:24 --> Helper loaded: file_helper
INFO - 2020-08-24 15:55:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:55:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:55:24 --> Upload Class Initialized
INFO - 2020-08-24 15:55:24 --> Controller Class Initialized
DEBUG - 2020-08-24 15:55:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:55:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:55:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:55:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:55:24 --> Final output sent to browser
DEBUG - 2020-08-24 15:55:24 --> Total execution time: 0.0514
INFO - 2020-08-24 15:55:26 --> Config Class Initialized
INFO - 2020-08-24 15:55:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:55:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:55:26 --> Utf8 Class Initialized
INFO - 2020-08-24 15:55:26 --> URI Class Initialized
INFO - 2020-08-24 15:55:26 --> Router Class Initialized
INFO - 2020-08-24 15:55:26 --> Output Class Initialized
INFO - 2020-08-24 15:55:26 --> Security Class Initialized
DEBUG - 2020-08-24 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:55:26 --> Input Class Initialized
INFO - 2020-08-24 15:55:26 --> Language Class Initialized
INFO - 2020-08-24 15:55:26 --> Language Class Initialized
INFO - 2020-08-24 15:55:26 --> Config Class Initialized
INFO - 2020-08-24 15:55:26 --> Loader Class Initialized
INFO - 2020-08-24 15:55:26 --> Helper loaded: url_helper
INFO - 2020-08-24 15:55:26 --> Helper loaded: form_helper
INFO - 2020-08-24 15:55:26 --> Helper loaded: file_helper
INFO - 2020-08-24 15:55:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:55:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:55:26 --> Upload Class Initialized
INFO - 2020-08-24 15:55:26 --> Controller Class Initialized
DEBUG - 2020-08-24 15:55:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:55:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:55:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:55:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:55:26 --> Final output sent to browser
DEBUG - 2020-08-24 15:55:26 --> Total execution time: 0.0542
INFO - 2020-08-24 15:55:34 --> Config Class Initialized
INFO - 2020-08-24 15:55:34 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:55:34 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:55:34 --> Utf8 Class Initialized
INFO - 2020-08-24 15:55:34 --> URI Class Initialized
INFO - 2020-08-24 15:55:34 --> Router Class Initialized
INFO - 2020-08-24 15:55:34 --> Output Class Initialized
INFO - 2020-08-24 15:55:34 --> Security Class Initialized
DEBUG - 2020-08-24 15:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:55:34 --> Input Class Initialized
INFO - 2020-08-24 15:55:34 --> Language Class Initialized
INFO - 2020-08-24 15:55:34 --> Language Class Initialized
INFO - 2020-08-24 15:55:34 --> Config Class Initialized
INFO - 2020-08-24 15:55:34 --> Loader Class Initialized
INFO - 2020-08-24 15:55:34 --> Helper loaded: url_helper
INFO - 2020-08-24 15:55:34 --> Helper loaded: form_helper
INFO - 2020-08-24 15:55:34 --> Helper loaded: file_helper
INFO - 2020-08-24 15:55:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:55:34 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:55:34 --> Upload Class Initialized
INFO - 2020-08-24 15:55:34 --> Controller Class Initialized
DEBUG - 2020-08-24 15:55:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:55:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:55:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:55:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:55:34 --> Final output sent to browser
DEBUG - 2020-08-24 15:55:34 --> Total execution time: 0.0527
INFO - 2020-08-24 15:56:21 --> Config Class Initialized
INFO - 2020-08-24 15:56:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:21 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:21 --> URI Class Initialized
INFO - 2020-08-24 15:56:21 --> Router Class Initialized
INFO - 2020-08-24 15:56:21 --> Output Class Initialized
INFO - 2020-08-24 15:56:21 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:21 --> Input Class Initialized
INFO - 2020-08-24 15:56:21 --> Language Class Initialized
INFO - 2020-08-24 15:56:21 --> Language Class Initialized
INFO - 2020-08-24 15:56:21 --> Config Class Initialized
INFO - 2020-08-24 15:56:21 --> Loader Class Initialized
INFO - 2020-08-24 15:56:21 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:21 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:21 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:21 --> Upload Class Initialized
INFO - 2020-08-24 15:56:21 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-24 15:56:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:21 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:21 --> Total execution time: 0.0511
INFO - 2020-08-24 15:56:25 --> Config Class Initialized
INFO - 2020-08-24 15:56:25 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:25 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:25 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:25 --> URI Class Initialized
INFO - 2020-08-24 15:56:25 --> Router Class Initialized
INFO - 2020-08-24 15:56:25 --> Output Class Initialized
INFO - 2020-08-24 15:56:25 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:25 --> Input Class Initialized
INFO - 2020-08-24 15:56:25 --> Language Class Initialized
INFO - 2020-08-24 15:56:25 --> Language Class Initialized
INFO - 2020-08-24 15:56:25 --> Config Class Initialized
INFO - 2020-08-24 15:56:25 --> Loader Class Initialized
INFO - 2020-08-24 15:56:25 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:25 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:25 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:25 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:25 --> Upload Class Initialized
INFO - 2020-08-24 15:56:25 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:25 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:25 --> Total execution time: 0.0718
INFO - 2020-08-24 15:56:33 --> Config Class Initialized
INFO - 2020-08-24 15:56:33 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:33 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:33 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:33 --> URI Class Initialized
INFO - 2020-08-24 15:56:33 --> Router Class Initialized
INFO - 2020-08-24 15:56:33 --> Output Class Initialized
INFO - 2020-08-24 15:56:33 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:33 --> Input Class Initialized
INFO - 2020-08-24 15:56:33 --> Language Class Initialized
INFO - 2020-08-24 15:56:33 --> Language Class Initialized
INFO - 2020-08-24 15:56:33 --> Config Class Initialized
INFO - 2020-08-24 15:56:33 --> Loader Class Initialized
INFO - 2020-08-24 15:56:33 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:33 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:33 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:33 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:33 --> Upload Class Initialized
INFO - 2020-08-24 15:56:33 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:33 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-24 15:56:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:33 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:33 --> Total execution time: 0.0500
INFO - 2020-08-24 15:56:36 --> Config Class Initialized
INFO - 2020-08-24 15:56:36 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:36 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:36 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:36 --> URI Class Initialized
INFO - 2020-08-24 15:56:36 --> Router Class Initialized
INFO - 2020-08-24 15:56:36 --> Output Class Initialized
INFO - 2020-08-24 15:56:36 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:36 --> Input Class Initialized
INFO - 2020-08-24 15:56:36 --> Language Class Initialized
INFO - 2020-08-24 15:56:36 --> Language Class Initialized
INFO - 2020-08-24 15:56:36 --> Config Class Initialized
INFO - 2020-08-24 15:56:36 --> Loader Class Initialized
INFO - 2020-08-24 15:56:36 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:36 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:36 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:36 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:36 --> Upload Class Initialized
INFO - 2020-08-24 15:56:36 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:56:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:56:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:36 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:36 --> Total execution time: 0.0523
INFO - 2020-08-24 15:56:44 --> Config Class Initialized
INFO - 2020-08-24 15:56:44 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:44 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:44 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:44 --> URI Class Initialized
INFO - 2020-08-24 15:56:44 --> Router Class Initialized
INFO - 2020-08-24 15:56:44 --> Output Class Initialized
INFO - 2020-08-24 15:56:44 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:44 --> Input Class Initialized
INFO - 2020-08-24 15:56:44 --> Language Class Initialized
INFO - 2020-08-24 15:56:44 --> Language Class Initialized
INFO - 2020-08-24 15:56:44 --> Config Class Initialized
INFO - 2020-08-24 15:56:44 --> Loader Class Initialized
INFO - 2020-08-24 15:56:44 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:44 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:44 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:44 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:44 --> Upload Class Initialized
INFO - 2020-08-24 15:56:44 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:56:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:56:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:44 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:44 --> Total execution time: 0.0534
INFO - 2020-08-24 15:56:49 --> Config Class Initialized
INFO - 2020-08-24 15:56:49 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:49 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:49 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:49 --> URI Class Initialized
INFO - 2020-08-24 15:56:49 --> Router Class Initialized
INFO - 2020-08-24 15:56:49 --> Output Class Initialized
INFO - 2020-08-24 15:56:49 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:49 --> Input Class Initialized
INFO - 2020-08-24 15:56:49 --> Language Class Initialized
INFO - 2020-08-24 15:56:49 --> Language Class Initialized
INFO - 2020-08-24 15:56:49 --> Config Class Initialized
INFO - 2020-08-24 15:56:49 --> Loader Class Initialized
INFO - 2020-08-24 15:56:49 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:49 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:49 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:49 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:49 --> Upload Class Initialized
INFO - 2020-08-24 15:56:49 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-24 15:56:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:49 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:49 --> Total execution time: 0.0751
INFO - 2020-08-24 15:56:49 --> Config Class Initialized
INFO - 2020-08-24 15:56:49 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:49 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:49 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:49 --> URI Class Initialized
INFO - 2020-08-24 15:56:49 --> Router Class Initialized
INFO - 2020-08-24 15:56:49 --> Output Class Initialized
INFO - 2020-08-24 15:56:49 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:49 --> Input Class Initialized
INFO - 2020-08-24 15:56:49 --> Language Class Initialized
INFO - 2020-08-24 15:56:49 --> Language Class Initialized
INFO - 2020-08-24 15:56:49 --> Config Class Initialized
INFO - 2020-08-24 15:56:49 --> Loader Class Initialized
INFO - 2020-08-24 15:56:49 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:49 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:49 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:49 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:49 --> Upload Class Initialized
INFO - 2020-08-24 15:56:49 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:56:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:56:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:49 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:49 --> Total execution time: 0.0699
INFO - 2020-08-24 15:56:51 --> Config Class Initialized
INFO - 2020-08-24 15:56:51 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:56:51 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:56:51 --> Utf8 Class Initialized
INFO - 2020-08-24 15:56:51 --> URI Class Initialized
INFO - 2020-08-24 15:56:51 --> Router Class Initialized
INFO - 2020-08-24 15:56:51 --> Output Class Initialized
INFO - 2020-08-24 15:56:51 --> Security Class Initialized
DEBUG - 2020-08-24 15:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:56:51 --> Input Class Initialized
INFO - 2020-08-24 15:56:51 --> Language Class Initialized
INFO - 2020-08-24 15:56:51 --> Language Class Initialized
INFO - 2020-08-24 15:56:51 --> Config Class Initialized
INFO - 2020-08-24 15:56:51 --> Loader Class Initialized
INFO - 2020-08-24 15:56:51 --> Helper loaded: url_helper
INFO - 2020-08-24 15:56:51 --> Helper loaded: form_helper
INFO - 2020-08-24 15:56:51 --> Helper loaded: file_helper
INFO - 2020-08-24 15:56:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:56:51 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:56:51 --> Upload Class Initialized
INFO - 2020-08-24 15:56:51 --> Controller Class Initialized
DEBUG - 2020-08-24 15:56:51 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:56:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:56:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:56:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:56:51 --> Final output sent to browser
DEBUG - 2020-08-24 15:56:51 --> Total execution time: 0.0549
INFO - 2020-08-24 15:57:01 --> Config Class Initialized
INFO - 2020-08-24 15:57:01 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:57:01 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:57:01 --> Utf8 Class Initialized
INFO - 2020-08-24 15:57:01 --> URI Class Initialized
INFO - 2020-08-24 15:57:01 --> Router Class Initialized
INFO - 2020-08-24 15:57:01 --> Output Class Initialized
INFO - 2020-08-24 15:57:01 --> Security Class Initialized
DEBUG - 2020-08-24 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:57:01 --> Input Class Initialized
INFO - 2020-08-24 15:57:01 --> Language Class Initialized
INFO - 2020-08-24 15:57:01 --> Language Class Initialized
INFO - 2020-08-24 15:57:01 --> Config Class Initialized
INFO - 2020-08-24 15:57:01 --> Loader Class Initialized
INFO - 2020-08-24 15:57:01 --> Helper loaded: url_helper
INFO - 2020-08-24 15:57:01 --> Helper loaded: form_helper
INFO - 2020-08-24 15:57:01 --> Helper loaded: file_helper
INFO - 2020-08-24 15:57:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:57:01 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:57:01 --> Upload Class Initialized
INFO - 2020-08-24 15:57:02 --> Controller Class Initialized
DEBUG - 2020-08-24 15:57:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:57:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:57:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:57:02 --> Final output sent to browser
DEBUG - 2020-08-24 15:57:02 --> Total execution time: 0.1630
INFO - 2020-08-24 15:57:06 --> Config Class Initialized
INFO - 2020-08-24 15:57:06 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:57:06 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:57:06 --> Utf8 Class Initialized
INFO - 2020-08-24 15:57:06 --> URI Class Initialized
INFO - 2020-08-24 15:57:06 --> Router Class Initialized
INFO - 2020-08-24 15:57:06 --> Output Class Initialized
INFO - 2020-08-24 15:57:06 --> Security Class Initialized
DEBUG - 2020-08-24 15:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:57:06 --> Input Class Initialized
INFO - 2020-08-24 15:57:06 --> Language Class Initialized
INFO - 2020-08-24 15:57:06 --> Language Class Initialized
INFO - 2020-08-24 15:57:06 --> Config Class Initialized
INFO - 2020-08-24 15:57:06 --> Loader Class Initialized
INFO - 2020-08-24 15:57:06 --> Helper loaded: url_helper
INFO - 2020-08-24 15:57:06 --> Helper loaded: form_helper
INFO - 2020-08-24 15:57:06 --> Helper loaded: file_helper
INFO - 2020-08-24 15:57:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:57:06 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:57:06 --> Upload Class Initialized
INFO - 2020-08-24 15:57:06 --> Controller Class Initialized
DEBUG - 2020-08-24 15:57:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:57:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 15:57:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:57:06 --> Final output sent to browser
DEBUG - 2020-08-24 15:57:06 --> Total execution time: 0.0509
INFO - 2020-08-24 15:57:10 --> Config Class Initialized
INFO - 2020-08-24 15:57:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:57:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:57:10 --> Utf8 Class Initialized
INFO - 2020-08-24 15:57:10 --> URI Class Initialized
INFO - 2020-08-24 15:57:10 --> Router Class Initialized
INFO - 2020-08-24 15:57:10 --> Output Class Initialized
INFO - 2020-08-24 15:57:10 --> Security Class Initialized
DEBUG - 2020-08-24 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:57:10 --> Input Class Initialized
INFO - 2020-08-24 15:57:10 --> Language Class Initialized
INFO - 2020-08-24 15:57:10 --> Language Class Initialized
INFO - 2020-08-24 15:57:10 --> Config Class Initialized
INFO - 2020-08-24 15:57:10 --> Loader Class Initialized
INFO - 2020-08-24 15:57:10 --> Helper loaded: url_helper
INFO - 2020-08-24 15:57:10 --> Helper loaded: form_helper
INFO - 2020-08-24 15:57:10 --> Helper loaded: file_helper
INFO - 2020-08-24 15:57:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:57:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:57:10 --> Upload Class Initialized
INFO - 2020-08-24 15:57:10 --> Controller Class Initialized
DEBUG - 2020-08-24 15:57:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:57:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:57:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:57:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:57:10 --> Final output sent to browser
DEBUG - 2020-08-24 15:57:10 --> Total execution time: 0.0493
INFO - 2020-08-24 15:57:10 --> Config Class Initialized
INFO - 2020-08-24 15:57:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:57:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:57:10 --> Utf8 Class Initialized
INFO - 2020-08-24 15:57:10 --> URI Class Initialized
INFO - 2020-08-24 15:57:10 --> Router Class Initialized
INFO - 2020-08-24 15:57:10 --> Output Class Initialized
INFO - 2020-08-24 15:57:10 --> Security Class Initialized
DEBUG - 2020-08-24 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:57:10 --> Input Class Initialized
INFO - 2020-08-24 15:57:10 --> Language Class Initialized
INFO - 2020-08-24 15:57:10 --> Language Class Initialized
INFO - 2020-08-24 15:57:10 --> Config Class Initialized
INFO - 2020-08-24 15:57:10 --> Loader Class Initialized
INFO - 2020-08-24 15:57:10 --> Helper loaded: url_helper
INFO - 2020-08-24 15:57:10 --> Helper loaded: form_helper
INFO - 2020-08-24 15:57:10 --> Helper loaded: file_helper
INFO - 2020-08-24 15:57:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:57:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:57:10 --> Upload Class Initialized
INFO - 2020-08-24 15:57:10 --> Controller Class Initialized
DEBUG - 2020-08-24 15:57:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:57:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:57:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:57:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:57:10 --> Final output sent to browser
DEBUG - 2020-08-24 15:57:10 --> Total execution time: 0.0493
INFO - 2020-08-24 15:57:16 --> Config Class Initialized
INFO - 2020-08-24 15:57:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:57:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:57:16 --> Utf8 Class Initialized
INFO - 2020-08-24 15:57:16 --> URI Class Initialized
INFO - 2020-08-24 15:57:16 --> Router Class Initialized
INFO - 2020-08-24 15:57:16 --> Output Class Initialized
INFO - 2020-08-24 15:57:16 --> Security Class Initialized
DEBUG - 2020-08-24 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:57:16 --> Input Class Initialized
INFO - 2020-08-24 15:57:16 --> Language Class Initialized
INFO - 2020-08-24 15:57:16 --> Language Class Initialized
INFO - 2020-08-24 15:57:16 --> Config Class Initialized
INFO - 2020-08-24 15:57:16 --> Loader Class Initialized
INFO - 2020-08-24 15:57:16 --> Helper loaded: url_helper
INFO - 2020-08-24 15:57:16 --> Helper loaded: form_helper
INFO - 2020-08-24 15:57:16 --> Helper loaded: file_helper
INFO - 2020-08-24 15:57:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:57:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:57:16 --> Upload Class Initialized
INFO - 2020-08-24 15:57:16 --> Controller Class Initialized
DEBUG - 2020-08-24 15:57:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:57:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-24 15:57:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:57:16 --> Final output sent to browser
DEBUG - 2020-08-24 15:57:16 --> Total execution time: 0.0530
INFO - 2020-08-24 15:57:25 --> Config Class Initialized
INFO - 2020-08-24 15:57:25 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:57:25 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:57:25 --> Utf8 Class Initialized
INFO - 2020-08-24 15:57:25 --> URI Class Initialized
INFO - 2020-08-24 15:57:25 --> Router Class Initialized
INFO - 2020-08-24 15:57:25 --> Output Class Initialized
INFO - 2020-08-24 15:57:25 --> Security Class Initialized
DEBUG - 2020-08-24 15:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:57:25 --> Input Class Initialized
INFO - 2020-08-24 15:57:25 --> Language Class Initialized
INFO - 2020-08-24 15:57:25 --> Language Class Initialized
INFO - 2020-08-24 15:57:25 --> Config Class Initialized
INFO - 2020-08-24 15:57:25 --> Loader Class Initialized
INFO - 2020-08-24 15:57:25 --> Helper loaded: url_helper
INFO - 2020-08-24 15:57:25 --> Helper loaded: form_helper
INFO - 2020-08-24 15:57:25 --> Helper loaded: file_helper
INFO - 2020-08-24 15:57:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:57:25 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:57:25 --> Upload Class Initialized
INFO - 2020-08-24 15:57:25 --> Controller Class Initialized
DEBUG - 2020-08-24 15:57:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:57:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:57:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:57:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:57:25 --> Final output sent to browser
DEBUG - 2020-08-24 15:57:25 --> Total execution time: 0.0520
INFO - 2020-08-24 15:58:39 --> Config Class Initialized
INFO - 2020-08-24 15:58:39 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:58:39 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:58:39 --> Utf8 Class Initialized
INFO - 2020-08-24 15:58:39 --> URI Class Initialized
INFO - 2020-08-24 15:58:39 --> Router Class Initialized
INFO - 2020-08-24 15:58:39 --> Output Class Initialized
INFO - 2020-08-24 15:58:39 --> Security Class Initialized
DEBUG - 2020-08-24 15:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:58:39 --> Input Class Initialized
INFO - 2020-08-24 15:58:39 --> Language Class Initialized
INFO - 2020-08-24 15:58:39 --> Language Class Initialized
INFO - 2020-08-24 15:58:39 --> Config Class Initialized
INFO - 2020-08-24 15:58:39 --> Loader Class Initialized
INFO - 2020-08-24 15:58:39 --> Helper loaded: url_helper
INFO - 2020-08-24 15:58:39 --> Helper loaded: form_helper
INFO - 2020-08-24 15:58:39 --> Helper loaded: file_helper
INFO - 2020-08-24 15:58:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:58:39 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:58:39 --> Upload Class Initialized
INFO - 2020-08-24 15:58:39 --> Controller Class Initialized
DEBUG - 2020-08-24 15:58:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:58:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:58:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:58:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:58:39 --> Final output sent to browser
DEBUG - 2020-08-24 15:58:39 --> Total execution time: 0.0514
INFO - 2020-08-24 15:58:50 --> Config Class Initialized
INFO - 2020-08-24 15:58:50 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:58:50 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:58:50 --> Utf8 Class Initialized
INFO - 2020-08-24 15:58:50 --> URI Class Initialized
INFO - 2020-08-24 15:58:50 --> Router Class Initialized
INFO - 2020-08-24 15:58:50 --> Output Class Initialized
INFO - 2020-08-24 15:58:50 --> Security Class Initialized
DEBUG - 2020-08-24 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:58:50 --> Input Class Initialized
INFO - 2020-08-24 15:58:50 --> Language Class Initialized
INFO - 2020-08-24 15:58:50 --> Language Class Initialized
INFO - 2020-08-24 15:58:50 --> Config Class Initialized
INFO - 2020-08-24 15:58:50 --> Loader Class Initialized
INFO - 2020-08-24 15:58:50 --> Helper loaded: url_helper
INFO - 2020-08-24 15:58:50 --> Helper loaded: form_helper
INFO - 2020-08-24 15:58:50 --> Helper loaded: file_helper
INFO - 2020-08-24 15:58:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:58:50 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:58:50 --> Upload Class Initialized
INFO - 2020-08-24 15:58:50 --> Controller Class Initialized
DEBUG - 2020-08-24 15:58:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:58:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:58:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:58:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:58:50 --> Final output sent to browser
DEBUG - 2020-08-24 15:58:50 --> Total execution time: 0.0497
INFO - 2020-08-24 15:58:52 --> Config Class Initialized
INFO - 2020-08-24 15:58:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:58:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:58:52 --> Utf8 Class Initialized
INFO - 2020-08-24 15:58:52 --> URI Class Initialized
INFO - 2020-08-24 15:58:52 --> Router Class Initialized
INFO - 2020-08-24 15:58:52 --> Output Class Initialized
INFO - 2020-08-24 15:58:52 --> Security Class Initialized
DEBUG - 2020-08-24 15:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:58:52 --> Input Class Initialized
INFO - 2020-08-24 15:58:52 --> Language Class Initialized
INFO - 2020-08-24 15:58:52 --> Language Class Initialized
INFO - 2020-08-24 15:58:52 --> Config Class Initialized
INFO - 2020-08-24 15:58:52 --> Loader Class Initialized
INFO - 2020-08-24 15:58:52 --> Helper loaded: url_helper
INFO - 2020-08-24 15:58:52 --> Helper loaded: form_helper
INFO - 2020-08-24 15:58:52 --> Helper loaded: file_helper
INFO - 2020-08-24 15:58:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:58:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:58:52 --> Upload Class Initialized
INFO - 2020-08-24 15:58:52 --> Controller Class Initialized
DEBUG - 2020-08-24 15:58:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:58:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:58:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:58:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:58:52 --> Final output sent to browser
DEBUG - 2020-08-24 15:58:52 --> Total execution time: 0.0520
INFO - 2020-08-24 15:59:20 --> Config Class Initialized
INFO - 2020-08-24 15:59:20 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:59:20 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:59:20 --> Utf8 Class Initialized
INFO - 2020-08-24 15:59:20 --> URI Class Initialized
INFO - 2020-08-24 15:59:20 --> Router Class Initialized
INFO - 2020-08-24 15:59:20 --> Output Class Initialized
INFO - 2020-08-24 15:59:20 --> Security Class Initialized
DEBUG - 2020-08-24 15:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:59:20 --> Input Class Initialized
INFO - 2020-08-24 15:59:20 --> Language Class Initialized
INFO - 2020-08-24 15:59:20 --> Language Class Initialized
INFO - 2020-08-24 15:59:20 --> Config Class Initialized
INFO - 2020-08-24 15:59:20 --> Loader Class Initialized
INFO - 2020-08-24 15:59:20 --> Helper loaded: url_helper
INFO - 2020-08-24 15:59:20 --> Helper loaded: form_helper
INFO - 2020-08-24 15:59:20 --> Helper loaded: file_helper
INFO - 2020-08-24 15:59:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:59:20 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:59:20 --> Upload Class Initialized
INFO - 2020-08-24 15:59:20 --> Controller Class Initialized
DEBUG - 2020-08-24 15:59:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:59:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:59:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:59:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:59:20 --> Final output sent to browser
DEBUG - 2020-08-24 15:59:20 --> Total execution time: 0.0500
INFO - 2020-08-24 15:59:20 --> Config Class Initialized
INFO - 2020-08-24 15:59:20 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:59:20 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:59:20 --> Utf8 Class Initialized
INFO - 2020-08-24 15:59:20 --> URI Class Initialized
INFO - 2020-08-24 15:59:20 --> Router Class Initialized
INFO - 2020-08-24 15:59:20 --> Output Class Initialized
INFO - 2020-08-24 15:59:20 --> Security Class Initialized
DEBUG - 2020-08-24 15:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:59:20 --> Input Class Initialized
INFO - 2020-08-24 15:59:20 --> Language Class Initialized
INFO - 2020-08-24 15:59:20 --> Language Class Initialized
INFO - 2020-08-24 15:59:20 --> Config Class Initialized
INFO - 2020-08-24 15:59:20 --> Loader Class Initialized
INFO - 2020-08-24 15:59:20 --> Helper loaded: url_helper
INFO - 2020-08-24 15:59:20 --> Helper loaded: form_helper
INFO - 2020-08-24 15:59:20 --> Helper loaded: file_helper
INFO - 2020-08-24 15:59:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 15:59:20 --> Database Driver Class Initialized
DEBUG - 2020-08-24 15:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 15:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:59:20 --> Upload Class Initialized
INFO - 2020-08-24 15:59:20 --> Controller Class Initialized
DEBUG - 2020-08-24 15:59:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 15:59:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 15:59:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 15:59:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 15:59:20 --> Final output sent to browser
DEBUG - 2020-08-24 15:59:20 --> Total execution time: 0.0505
INFO - 2020-08-24 16:00:03 --> Config Class Initialized
INFO - 2020-08-24 16:00:03 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:00:03 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:00:03 --> Utf8 Class Initialized
INFO - 2020-08-24 16:00:03 --> URI Class Initialized
INFO - 2020-08-24 16:00:03 --> Router Class Initialized
INFO - 2020-08-24 16:00:03 --> Output Class Initialized
INFO - 2020-08-24 16:00:03 --> Security Class Initialized
DEBUG - 2020-08-24 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:00:03 --> Input Class Initialized
INFO - 2020-08-24 16:00:03 --> Language Class Initialized
INFO - 2020-08-24 16:00:03 --> Language Class Initialized
INFO - 2020-08-24 16:00:03 --> Config Class Initialized
INFO - 2020-08-24 16:00:03 --> Loader Class Initialized
INFO - 2020-08-24 16:00:03 --> Helper loaded: url_helper
INFO - 2020-08-24 16:00:03 --> Helper loaded: form_helper
INFO - 2020-08-24 16:00:03 --> Helper loaded: file_helper
INFO - 2020-08-24 16:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:00:03 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:00:03 --> Upload Class Initialized
INFO - 2020-08-24 16:00:04 --> Controller Class Initialized
DEBUG - 2020-08-24 16:00:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:00:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 16:00:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 16:00:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:00:04 --> Final output sent to browser
DEBUG - 2020-08-24 16:00:04 --> Total execution time: 0.3828
INFO - 2020-08-24 16:00:10 --> Config Class Initialized
INFO - 2020-08-24 16:00:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:00:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:00:10 --> Utf8 Class Initialized
INFO - 2020-08-24 16:00:10 --> URI Class Initialized
INFO - 2020-08-24 16:00:10 --> Router Class Initialized
INFO - 2020-08-24 16:00:10 --> Output Class Initialized
INFO - 2020-08-24 16:00:10 --> Security Class Initialized
DEBUG - 2020-08-24 16:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:00:10 --> Input Class Initialized
INFO - 2020-08-24 16:00:10 --> Language Class Initialized
INFO - 2020-08-24 16:00:10 --> Language Class Initialized
INFO - 2020-08-24 16:00:10 --> Config Class Initialized
INFO - 2020-08-24 16:00:10 --> Loader Class Initialized
INFO - 2020-08-24 16:00:10 --> Helper loaded: url_helper
INFO - 2020-08-24 16:00:10 --> Helper loaded: form_helper
INFO - 2020-08-24 16:00:10 --> Helper loaded: file_helper
INFO - 2020-08-24 16:00:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:00:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:00:10 --> Upload Class Initialized
INFO - 2020-08-24 16:00:10 --> Controller Class Initialized
DEBUG - 2020-08-24 16:00:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:00:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 16:00:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 16:00:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:00:10 --> Final output sent to browser
DEBUG - 2020-08-24 16:00:10 --> Total execution time: 0.0541
INFO - 2020-08-24 16:00:16 --> Config Class Initialized
INFO - 2020-08-24 16:00:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:00:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:00:16 --> Utf8 Class Initialized
INFO - 2020-08-24 16:00:16 --> URI Class Initialized
INFO - 2020-08-24 16:00:16 --> Router Class Initialized
INFO - 2020-08-24 16:00:16 --> Output Class Initialized
INFO - 2020-08-24 16:00:16 --> Security Class Initialized
DEBUG - 2020-08-24 16:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:00:16 --> Input Class Initialized
INFO - 2020-08-24 16:00:16 --> Language Class Initialized
INFO - 2020-08-24 16:00:16 --> Language Class Initialized
INFO - 2020-08-24 16:00:16 --> Config Class Initialized
INFO - 2020-08-24 16:00:16 --> Loader Class Initialized
INFO - 2020-08-24 16:00:16 --> Helper loaded: url_helper
INFO - 2020-08-24 16:00:16 --> Helper loaded: form_helper
INFO - 2020-08-24 16:00:16 --> Helper loaded: file_helper
INFO - 2020-08-24 16:00:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:00:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:00:16 --> Upload Class Initialized
INFO - 2020-08-24 16:00:16 --> Controller Class Initialized
DEBUG - 2020-08-24 16:00:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:00:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 16:00:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 16:00:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:00:16 --> Final output sent to browser
DEBUG - 2020-08-24 16:00:16 --> Total execution time: 0.0533
INFO - 2020-08-24 16:00:43 --> Config Class Initialized
INFO - 2020-08-24 16:00:43 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:00:43 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:00:43 --> Utf8 Class Initialized
INFO - 2020-08-24 16:00:43 --> URI Class Initialized
INFO - 2020-08-24 16:00:43 --> Router Class Initialized
INFO - 2020-08-24 16:00:43 --> Output Class Initialized
INFO - 2020-08-24 16:00:43 --> Security Class Initialized
DEBUG - 2020-08-24 16:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:00:43 --> Input Class Initialized
INFO - 2020-08-24 16:00:43 --> Language Class Initialized
INFO - 2020-08-24 16:00:43 --> Language Class Initialized
INFO - 2020-08-24 16:00:43 --> Config Class Initialized
INFO - 2020-08-24 16:00:43 --> Loader Class Initialized
INFO - 2020-08-24 16:00:43 --> Helper loaded: url_helper
INFO - 2020-08-24 16:00:43 --> Helper loaded: form_helper
INFO - 2020-08-24 16:00:43 --> Helper loaded: file_helper
INFO - 2020-08-24 16:00:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:00:43 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:00:43 --> Upload Class Initialized
INFO - 2020-08-24 16:00:43 --> Controller Class Initialized
DEBUG - 2020-08-24 16:00:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:00:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-24 16:00:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:00:43 --> Final output sent to browser
DEBUG - 2020-08-24 16:00:43 --> Total execution time: 0.0515
INFO - 2020-08-24 16:00:52 --> Config Class Initialized
INFO - 2020-08-24 16:00:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:00:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:00:52 --> Utf8 Class Initialized
INFO - 2020-08-24 16:00:52 --> URI Class Initialized
INFO - 2020-08-24 16:00:52 --> Router Class Initialized
INFO - 2020-08-24 16:00:52 --> Output Class Initialized
INFO - 2020-08-24 16:00:52 --> Security Class Initialized
DEBUG - 2020-08-24 16:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:00:52 --> Input Class Initialized
INFO - 2020-08-24 16:00:52 --> Language Class Initialized
INFO - 2020-08-24 16:00:52 --> Language Class Initialized
INFO - 2020-08-24 16:00:52 --> Config Class Initialized
INFO - 2020-08-24 16:00:52 --> Loader Class Initialized
INFO - 2020-08-24 16:00:52 --> Helper loaded: url_helper
INFO - 2020-08-24 16:00:52 --> Helper loaded: form_helper
INFO - 2020-08-24 16:00:52 --> Helper loaded: file_helper
INFO - 2020-08-24 16:00:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:00:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:00:52 --> Upload Class Initialized
INFO - 2020-08-24 16:00:52 --> Controller Class Initialized
DEBUG - 2020-08-24 16:00:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:00:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 16:00:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 16:00:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:00:52 --> Final output sent to browser
DEBUG - 2020-08-24 16:00:52 --> Total execution time: 0.0491
INFO - 2020-08-24 16:00:54 --> Config Class Initialized
INFO - 2020-08-24 16:00:54 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:00:54 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:00:54 --> Utf8 Class Initialized
INFO - 2020-08-24 16:00:54 --> URI Class Initialized
INFO - 2020-08-24 16:00:54 --> Router Class Initialized
INFO - 2020-08-24 16:00:54 --> Output Class Initialized
INFO - 2020-08-24 16:00:54 --> Security Class Initialized
DEBUG - 2020-08-24 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:00:54 --> Input Class Initialized
INFO - 2020-08-24 16:00:54 --> Language Class Initialized
INFO - 2020-08-24 16:00:54 --> Language Class Initialized
INFO - 2020-08-24 16:00:54 --> Config Class Initialized
INFO - 2020-08-24 16:00:54 --> Loader Class Initialized
INFO - 2020-08-24 16:00:54 --> Helper loaded: url_helper
INFO - 2020-08-24 16:00:54 --> Helper loaded: form_helper
INFO - 2020-08-24 16:00:54 --> Helper loaded: file_helper
INFO - 2020-08-24 16:00:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:00:54 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:00:54 --> Upload Class Initialized
INFO - 2020-08-24 16:00:54 --> Controller Class Initialized
DEBUG - 2020-08-24 16:00:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:00:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 16:00:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 16:00:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:00:54 --> Final output sent to browser
DEBUG - 2020-08-24 16:00:54 --> Total execution time: 0.0529
INFO - 2020-08-24 16:04:33 --> Config Class Initialized
INFO - 2020-08-24 16:04:33 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:04:33 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:04:33 --> Utf8 Class Initialized
INFO - 2020-08-24 16:04:33 --> URI Class Initialized
INFO - 2020-08-24 16:04:33 --> Router Class Initialized
INFO - 2020-08-24 16:04:33 --> Output Class Initialized
INFO - 2020-08-24 16:04:33 --> Security Class Initialized
DEBUG - 2020-08-24 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:04:33 --> Input Class Initialized
INFO - 2020-08-24 16:04:33 --> Language Class Initialized
INFO - 2020-08-24 16:04:33 --> Language Class Initialized
INFO - 2020-08-24 16:04:33 --> Config Class Initialized
INFO - 2020-08-24 16:04:33 --> Loader Class Initialized
INFO - 2020-08-24 16:04:33 --> Helper loaded: url_helper
INFO - 2020-08-24 16:04:33 --> Helper loaded: form_helper
INFO - 2020-08-24 16:04:33 --> Helper loaded: file_helper
INFO - 2020-08-24 16:04:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:04:33 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:04:33 --> Upload Class Initialized
INFO - 2020-08-24 16:04:33 --> Controller Class Initialized
DEBUG - 2020-08-24 16:04:33 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 16:04:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-24 16:04:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 16:04:33 --> Final output sent to browser
DEBUG - 2020-08-24 16:04:33 --> Total execution time: 0.0535
INFO - 2020-08-24 16:04:35 --> Config Class Initialized
INFO - 2020-08-24 16:04:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:04:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:04:35 --> Utf8 Class Initialized
INFO - 2020-08-24 16:04:35 --> URI Class Initialized
INFO - 2020-08-24 16:04:35 --> Router Class Initialized
INFO - 2020-08-24 16:04:35 --> Output Class Initialized
INFO - 2020-08-24 16:04:35 --> Security Class Initialized
DEBUG - 2020-08-24 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:04:35 --> Input Class Initialized
INFO - 2020-08-24 16:04:35 --> Language Class Initialized
INFO - 2020-08-24 16:04:35 --> Language Class Initialized
INFO - 2020-08-24 16:04:35 --> Config Class Initialized
INFO - 2020-08-24 16:04:35 --> Loader Class Initialized
INFO - 2020-08-24 16:04:35 --> Helper loaded: url_helper
INFO - 2020-08-24 16:04:35 --> Helper loaded: form_helper
INFO - 2020-08-24 16:04:35 --> Helper loaded: file_helper
INFO - 2020-08-24 16:04:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:04:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:04:35 --> Upload Class Initialized
INFO - 2020-08-24 16:04:35 --> Controller Class Initialized
ERROR - 2020-08-24 16:04:35 --> 404 Page Not Found: /index
INFO - 2020-08-24 16:21:26 --> Config Class Initialized
INFO - 2020-08-24 16:21:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:21:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:21:26 --> Utf8 Class Initialized
INFO - 2020-08-24 16:21:26 --> URI Class Initialized
INFO - 2020-08-24 16:21:26 --> Router Class Initialized
INFO - 2020-08-24 16:21:26 --> Output Class Initialized
INFO - 2020-08-24 16:21:26 --> Security Class Initialized
DEBUG - 2020-08-24 16:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:21:26 --> Input Class Initialized
INFO - 2020-08-24 16:21:26 --> Language Class Initialized
INFO - 2020-08-24 16:21:26 --> Language Class Initialized
INFO - 2020-08-24 16:21:26 --> Config Class Initialized
INFO - 2020-08-24 16:21:26 --> Loader Class Initialized
INFO - 2020-08-24 16:21:26 --> Helper loaded: url_helper
INFO - 2020-08-24 16:21:26 --> Helper loaded: form_helper
INFO - 2020-08-24 16:21:26 --> Helper loaded: file_helper
INFO - 2020-08-24 16:21:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:21:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:21:26 --> Upload Class Initialized
INFO - 2020-08-24 16:21:26 --> Controller Class Initialized
ERROR - 2020-08-24 16:21:26 --> 404 Page Not Found: /index
INFO - 2020-08-24 16:22:31 --> Config Class Initialized
INFO - 2020-08-24 16:22:31 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:22:31 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:22:31 --> Utf8 Class Initialized
INFO - 2020-08-24 16:22:31 --> URI Class Initialized
INFO - 2020-08-24 16:22:31 --> Router Class Initialized
INFO - 2020-08-24 16:22:31 --> Output Class Initialized
INFO - 2020-08-24 16:22:31 --> Security Class Initialized
DEBUG - 2020-08-24 16:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:22:31 --> Input Class Initialized
INFO - 2020-08-24 16:22:31 --> Language Class Initialized
INFO - 2020-08-24 16:22:31 --> Language Class Initialized
INFO - 2020-08-24 16:22:31 --> Config Class Initialized
INFO - 2020-08-24 16:22:31 --> Loader Class Initialized
INFO - 2020-08-24 16:22:31 --> Helper loaded: url_helper
INFO - 2020-08-24 16:22:31 --> Helper loaded: form_helper
INFO - 2020-08-24 16:22:31 --> Helper loaded: file_helper
INFO - 2020-08-24 16:22:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:22:31 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:22:31 --> Upload Class Initialized
INFO - 2020-08-24 16:22:31 --> Controller Class Initialized
ERROR - 2020-08-24 16:22:31 --> 404 Page Not Found: /index
INFO - 2020-08-24 16:22:33 --> Config Class Initialized
INFO - 2020-08-24 16:22:33 --> Hooks Class Initialized
DEBUG - 2020-08-24 16:22:33 --> UTF-8 Support Enabled
INFO - 2020-08-24 16:22:33 --> Utf8 Class Initialized
INFO - 2020-08-24 16:22:33 --> URI Class Initialized
INFO - 2020-08-24 16:22:33 --> Router Class Initialized
INFO - 2020-08-24 16:22:33 --> Output Class Initialized
INFO - 2020-08-24 16:22:33 --> Security Class Initialized
DEBUG - 2020-08-24 16:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 16:22:33 --> Input Class Initialized
INFO - 2020-08-24 16:22:33 --> Language Class Initialized
INFO - 2020-08-24 16:22:33 --> Language Class Initialized
INFO - 2020-08-24 16:22:33 --> Config Class Initialized
INFO - 2020-08-24 16:22:33 --> Loader Class Initialized
INFO - 2020-08-24 16:22:33 --> Helper loaded: url_helper
INFO - 2020-08-24 16:22:33 --> Helper loaded: form_helper
INFO - 2020-08-24 16:22:33 --> Helper loaded: file_helper
INFO - 2020-08-24 16:22:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 16:22:33 --> Database Driver Class Initialized
DEBUG - 2020-08-24 16:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 16:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 16:22:33 --> Upload Class Initialized
INFO - 2020-08-24 16:22:33 --> Controller Class Initialized
ERROR - 2020-08-24 16:22:33 --> 404 Page Not Found: /index
INFO - 2020-08-24 17:10:26 --> Config Class Initialized
INFO - 2020-08-24 17:10:26 --> Hooks Class Initialized
DEBUG - 2020-08-24 17:10:26 --> UTF-8 Support Enabled
INFO - 2020-08-24 17:10:26 --> Utf8 Class Initialized
INFO - 2020-08-24 17:10:26 --> URI Class Initialized
INFO - 2020-08-24 17:10:26 --> Router Class Initialized
INFO - 2020-08-24 17:10:26 --> Output Class Initialized
INFO - 2020-08-24 17:10:26 --> Security Class Initialized
DEBUG - 2020-08-24 17:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 17:10:26 --> Input Class Initialized
INFO - 2020-08-24 17:10:26 --> Language Class Initialized
INFO - 2020-08-24 17:10:26 --> Language Class Initialized
INFO - 2020-08-24 17:10:26 --> Config Class Initialized
INFO - 2020-08-24 17:10:26 --> Loader Class Initialized
INFO - 2020-08-24 17:10:26 --> Helper loaded: url_helper
INFO - 2020-08-24 17:10:26 --> Helper loaded: form_helper
INFO - 2020-08-24 17:10:26 --> Helper loaded: file_helper
INFO - 2020-08-24 17:10:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 17:10:26 --> Database Driver Class Initialized
DEBUG - 2020-08-24 17:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 17:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 17:10:26 --> Upload Class Initialized
INFO - 2020-08-24 17:10:26 --> Controller Class Initialized
ERROR - 2020-08-24 17:10:26 --> 404 Page Not Found: /index
INFO - 2020-08-24 17:10:27 --> Config Class Initialized
INFO - 2020-08-24 17:10:27 --> Hooks Class Initialized
DEBUG - 2020-08-24 17:10:27 --> UTF-8 Support Enabled
INFO - 2020-08-24 17:10:27 --> Utf8 Class Initialized
INFO - 2020-08-24 17:10:27 --> URI Class Initialized
INFO - 2020-08-24 17:10:27 --> Router Class Initialized
INFO - 2020-08-24 17:10:27 --> Output Class Initialized
INFO - 2020-08-24 17:10:27 --> Security Class Initialized
DEBUG - 2020-08-24 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 17:10:27 --> Input Class Initialized
INFO - 2020-08-24 17:10:27 --> Language Class Initialized
INFO - 2020-08-24 17:10:27 --> Language Class Initialized
INFO - 2020-08-24 17:10:27 --> Config Class Initialized
INFO - 2020-08-24 17:10:27 --> Loader Class Initialized
INFO - 2020-08-24 17:10:27 --> Helper loaded: url_helper
INFO - 2020-08-24 17:10:27 --> Helper loaded: form_helper
INFO - 2020-08-24 17:10:27 --> Helper loaded: file_helper
INFO - 2020-08-24 17:10:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 17:10:27 --> Database Driver Class Initialized
DEBUG - 2020-08-24 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 17:10:27 --> Upload Class Initialized
INFO - 2020-08-24 17:10:27 --> Controller Class Initialized
DEBUG - 2020-08-24 17:10:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 17:10:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-24 17:10:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 17:10:27 --> Final output sent to browser
DEBUG - 2020-08-24 17:10:27 --> Total execution time: 0.0546
INFO - 2020-08-24 17:34:39 --> Config Class Initialized
INFO - 2020-08-24 17:34:39 --> Hooks Class Initialized
DEBUG - 2020-08-24 17:34:39 --> UTF-8 Support Enabled
INFO - 2020-08-24 17:34:39 --> Utf8 Class Initialized
INFO - 2020-08-24 17:34:39 --> URI Class Initialized
INFO - 2020-08-24 17:34:39 --> Router Class Initialized
INFO - 2020-08-24 17:34:39 --> Output Class Initialized
INFO - 2020-08-24 17:34:39 --> Security Class Initialized
DEBUG - 2020-08-24 17:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 17:34:39 --> Input Class Initialized
INFO - 2020-08-24 17:34:39 --> Language Class Initialized
INFO - 2020-08-24 17:34:39 --> Language Class Initialized
INFO - 2020-08-24 17:34:39 --> Config Class Initialized
INFO - 2020-08-24 17:34:39 --> Loader Class Initialized
INFO - 2020-08-24 17:34:39 --> Helper loaded: url_helper
INFO - 2020-08-24 17:34:39 --> Helper loaded: form_helper
INFO - 2020-08-24 17:34:39 --> Helper loaded: file_helper
INFO - 2020-08-24 17:34:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 17:34:39 --> Database Driver Class Initialized
DEBUG - 2020-08-24 17:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 17:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 17:34:39 --> Upload Class Initialized
INFO - 2020-08-24 17:34:39 --> Controller Class Initialized
ERROR - 2020-08-24 17:34:39 --> 404 Page Not Found: /index
INFO - 2020-08-24 17:42:52 --> Config Class Initialized
INFO - 2020-08-24 17:42:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 17:42:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 17:42:52 --> Utf8 Class Initialized
INFO - 2020-08-24 17:42:52 --> URI Class Initialized
DEBUG - 2020-08-24 17:42:52 --> No URI present. Default controller set.
INFO - 2020-08-24 17:42:52 --> Router Class Initialized
INFO - 2020-08-24 17:42:52 --> Output Class Initialized
INFO - 2020-08-24 17:42:52 --> Security Class Initialized
DEBUG - 2020-08-24 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 17:42:52 --> Input Class Initialized
INFO - 2020-08-24 17:42:52 --> Language Class Initialized
INFO - 2020-08-24 17:42:52 --> Language Class Initialized
INFO - 2020-08-24 17:42:52 --> Config Class Initialized
INFO - 2020-08-24 17:42:52 --> Loader Class Initialized
INFO - 2020-08-24 17:42:52 --> Helper loaded: url_helper
INFO - 2020-08-24 17:42:52 --> Helper loaded: form_helper
INFO - 2020-08-24 17:42:52 --> Helper loaded: file_helper
INFO - 2020-08-24 17:42:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 17:42:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 17:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 17:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 17:42:52 --> Upload Class Initialized
INFO - 2020-08-24 17:42:52 --> Controller Class Initialized
DEBUG - 2020-08-24 17:42:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 17:42:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 17:42:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 17:42:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 17:42:52 --> Final output sent to browser
DEBUG - 2020-08-24 17:42:52 --> Total execution time: 0.0545
INFO - 2020-08-24 17:42:53 --> Config Class Initialized
INFO - 2020-08-24 17:42:53 --> Hooks Class Initialized
DEBUG - 2020-08-24 17:42:53 --> UTF-8 Support Enabled
INFO - 2020-08-24 17:42:53 --> Utf8 Class Initialized
INFO - 2020-08-24 17:42:53 --> URI Class Initialized
INFO - 2020-08-24 17:42:53 --> Router Class Initialized
INFO - 2020-08-24 17:42:53 --> Output Class Initialized
INFO - 2020-08-24 17:42:53 --> Security Class Initialized
DEBUG - 2020-08-24 17:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 17:42:53 --> Input Class Initialized
INFO - 2020-08-24 17:42:53 --> Language Class Initialized
INFO - 2020-08-24 17:42:53 --> Language Class Initialized
INFO - 2020-08-24 17:42:53 --> Config Class Initialized
INFO - 2020-08-24 17:42:53 --> Loader Class Initialized
INFO - 2020-08-24 17:42:53 --> Helper loaded: url_helper
INFO - 2020-08-24 17:42:53 --> Helper loaded: form_helper
INFO - 2020-08-24 17:42:53 --> Helper loaded: file_helper
INFO - 2020-08-24 17:42:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 17:42:53 --> Database Driver Class Initialized
DEBUG - 2020-08-24 17:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 17:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 17:42:53 --> Upload Class Initialized
INFO - 2020-08-24 17:42:53 --> Controller Class Initialized
ERROR - 2020-08-24 17:42:53 --> 404 Page Not Found: /index
INFO - 2020-08-24 17:57:30 --> Config Class Initialized
INFO - 2020-08-24 17:57:30 --> Hooks Class Initialized
DEBUG - 2020-08-24 17:57:30 --> UTF-8 Support Enabled
INFO - 2020-08-24 17:57:30 --> Utf8 Class Initialized
INFO - 2020-08-24 17:57:30 --> URI Class Initialized
INFO - 2020-08-24 17:57:30 --> Router Class Initialized
INFO - 2020-08-24 17:57:30 --> Output Class Initialized
INFO - 2020-08-24 17:57:30 --> Security Class Initialized
DEBUG - 2020-08-24 17:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 17:57:30 --> Input Class Initialized
INFO - 2020-08-24 17:57:30 --> Language Class Initialized
INFO - 2020-08-24 17:57:30 --> Language Class Initialized
INFO - 2020-08-24 17:57:30 --> Config Class Initialized
INFO - 2020-08-24 17:57:30 --> Loader Class Initialized
INFO - 2020-08-24 17:57:30 --> Helper loaded: url_helper
INFO - 2020-08-24 17:57:30 --> Helper loaded: form_helper
INFO - 2020-08-24 17:57:30 --> Helper loaded: file_helper
INFO - 2020-08-24 17:57:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 17:57:30 --> Database Driver Class Initialized
DEBUG - 2020-08-24 17:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 17:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 17:57:30 --> Upload Class Initialized
INFO - 2020-08-24 17:57:30 --> Controller Class Initialized
ERROR - 2020-08-24 17:57:30 --> 404 Page Not Found: /index
INFO - 2020-08-24 18:14:53 --> Config Class Initialized
INFO - 2020-08-24 18:14:53 --> Hooks Class Initialized
DEBUG - 2020-08-24 18:14:53 --> UTF-8 Support Enabled
INFO - 2020-08-24 18:14:53 --> Utf8 Class Initialized
INFO - 2020-08-24 18:14:53 --> URI Class Initialized
DEBUG - 2020-08-24 18:14:53 --> No URI present. Default controller set.
INFO - 2020-08-24 18:14:53 --> Router Class Initialized
INFO - 2020-08-24 18:14:53 --> Output Class Initialized
INFO - 2020-08-24 18:14:53 --> Security Class Initialized
DEBUG - 2020-08-24 18:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 18:14:53 --> Input Class Initialized
INFO - 2020-08-24 18:14:53 --> Language Class Initialized
INFO - 2020-08-24 18:14:53 --> Language Class Initialized
INFO - 2020-08-24 18:14:53 --> Config Class Initialized
INFO - 2020-08-24 18:14:53 --> Loader Class Initialized
INFO - 2020-08-24 18:14:53 --> Helper loaded: url_helper
INFO - 2020-08-24 18:14:53 --> Helper loaded: form_helper
INFO - 2020-08-24 18:14:53 --> Helper loaded: file_helper
INFO - 2020-08-24 18:14:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 18:14:53 --> Database Driver Class Initialized
DEBUG - 2020-08-24 18:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 18:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 18:14:53 --> Upload Class Initialized
INFO - 2020-08-24 18:14:53 --> Controller Class Initialized
DEBUG - 2020-08-24 18:14:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 18:14:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 18:14:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 18:14:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 18:14:53 --> Final output sent to browser
DEBUG - 2020-08-24 18:14:53 --> Total execution time: 0.0495
INFO - 2020-08-24 18:28:16 --> Config Class Initialized
INFO - 2020-08-24 18:28:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 18:28:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 18:28:16 --> Utf8 Class Initialized
INFO - 2020-08-24 18:28:16 --> URI Class Initialized
INFO - 2020-08-24 18:28:16 --> Router Class Initialized
INFO - 2020-08-24 18:28:16 --> Output Class Initialized
INFO - 2020-08-24 18:28:16 --> Security Class Initialized
DEBUG - 2020-08-24 18:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 18:28:16 --> Input Class Initialized
INFO - 2020-08-24 18:28:16 --> Language Class Initialized
INFO - 2020-08-24 18:28:16 --> Language Class Initialized
INFO - 2020-08-24 18:28:16 --> Config Class Initialized
INFO - 2020-08-24 18:28:16 --> Loader Class Initialized
INFO - 2020-08-24 18:28:16 --> Helper loaded: url_helper
INFO - 2020-08-24 18:28:16 --> Helper loaded: form_helper
INFO - 2020-08-24 18:28:16 --> Helper loaded: file_helper
INFO - 2020-08-24 18:28:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 18:28:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 18:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 18:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 18:28:17 --> Upload Class Initialized
INFO - 2020-08-24 18:28:17 --> Controller Class Initialized
ERROR - 2020-08-24 18:28:17 --> 404 Page Not Found: /index
INFO - 2020-08-24 18:28:18 --> Config Class Initialized
INFO - 2020-08-24 18:28:18 --> Hooks Class Initialized
DEBUG - 2020-08-24 18:28:18 --> UTF-8 Support Enabled
INFO - 2020-08-24 18:28:18 --> Utf8 Class Initialized
INFO - 2020-08-24 18:28:18 --> URI Class Initialized
DEBUG - 2020-08-24 18:28:18 --> No URI present. Default controller set.
INFO - 2020-08-24 18:28:18 --> Router Class Initialized
INFO - 2020-08-24 18:28:18 --> Output Class Initialized
INFO - 2020-08-24 18:28:18 --> Security Class Initialized
DEBUG - 2020-08-24 18:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 18:28:18 --> Input Class Initialized
INFO - 2020-08-24 18:28:18 --> Language Class Initialized
INFO - 2020-08-24 18:28:18 --> Language Class Initialized
INFO - 2020-08-24 18:28:18 --> Config Class Initialized
INFO - 2020-08-24 18:28:18 --> Loader Class Initialized
INFO - 2020-08-24 18:28:18 --> Helper loaded: url_helper
INFO - 2020-08-24 18:28:18 --> Helper loaded: form_helper
INFO - 2020-08-24 18:28:18 --> Helper loaded: file_helper
INFO - 2020-08-24 18:28:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 18:28:18 --> Database Driver Class Initialized
DEBUG - 2020-08-24 18:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 18:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 18:28:18 --> Upload Class Initialized
INFO - 2020-08-24 18:28:18 --> Controller Class Initialized
DEBUG - 2020-08-24 18:28:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 18:28:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 18:28:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 18:28:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 18:28:18 --> Final output sent to browser
DEBUG - 2020-08-24 18:28:18 --> Total execution time: 0.0650
INFO - 2020-08-24 18:43:31 --> Config Class Initialized
INFO - 2020-08-24 18:43:31 --> Hooks Class Initialized
DEBUG - 2020-08-24 18:43:31 --> UTF-8 Support Enabled
INFO - 2020-08-24 18:43:31 --> Utf8 Class Initialized
INFO - 2020-08-24 18:43:31 --> URI Class Initialized
DEBUG - 2020-08-24 18:43:31 --> No URI present. Default controller set.
INFO - 2020-08-24 18:43:31 --> Router Class Initialized
INFO - 2020-08-24 18:43:31 --> Output Class Initialized
INFO - 2020-08-24 18:43:31 --> Security Class Initialized
DEBUG - 2020-08-24 18:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 18:43:31 --> Input Class Initialized
INFO - 2020-08-24 18:43:31 --> Language Class Initialized
INFO - 2020-08-24 18:43:31 --> Language Class Initialized
INFO - 2020-08-24 18:43:31 --> Config Class Initialized
INFO - 2020-08-24 18:43:31 --> Loader Class Initialized
INFO - 2020-08-24 18:43:31 --> Helper loaded: url_helper
INFO - 2020-08-24 18:43:31 --> Helper loaded: form_helper
INFO - 2020-08-24 18:43:31 --> Helper loaded: file_helper
INFO - 2020-08-24 18:43:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 18:43:31 --> Database Driver Class Initialized
DEBUG - 2020-08-24 18:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 18:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 18:43:31 --> Upload Class Initialized
INFO - 2020-08-24 18:43:31 --> Controller Class Initialized
DEBUG - 2020-08-24 18:43:31 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 18:43:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 18:43:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 18:43:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 18:43:31 --> Final output sent to browser
DEBUG - 2020-08-24 18:43:31 --> Total execution time: 0.0521
INFO - 2020-08-24 19:15:29 --> Config Class Initialized
INFO - 2020-08-24 19:15:29 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:15:29 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:15:29 --> Utf8 Class Initialized
INFO - 2020-08-24 19:15:29 --> URI Class Initialized
INFO - 2020-08-24 19:15:29 --> Router Class Initialized
INFO - 2020-08-24 19:15:29 --> Output Class Initialized
INFO - 2020-08-24 19:15:29 --> Security Class Initialized
DEBUG - 2020-08-24 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:15:29 --> Input Class Initialized
INFO - 2020-08-24 19:15:29 --> Language Class Initialized
INFO - 2020-08-24 19:15:29 --> Language Class Initialized
INFO - 2020-08-24 19:15:29 --> Config Class Initialized
INFO - 2020-08-24 19:15:29 --> Loader Class Initialized
INFO - 2020-08-24 19:15:29 --> Helper loaded: url_helper
INFO - 2020-08-24 19:15:29 --> Helper loaded: form_helper
INFO - 2020-08-24 19:15:29 --> Helper loaded: file_helper
INFO - 2020-08-24 19:15:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:15:29 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:15:29 --> Upload Class Initialized
INFO - 2020-08-24 19:15:29 --> Controller Class Initialized
ERROR - 2020-08-24 19:15:29 --> 404 Page Not Found: /index
INFO - 2020-08-24 19:19:22 --> Config Class Initialized
INFO - 2020-08-24 19:19:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:19:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:19:22 --> Utf8 Class Initialized
INFO - 2020-08-24 19:19:22 --> URI Class Initialized
DEBUG - 2020-08-24 19:19:22 --> No URI present. Default controller set.
INFO - 2020-08-24 19:19:22 --> Router Class Initialized
INFO - 2020-08-24 19:19:22 --> Output Class Initialized
INFO - 2020-08-24 19:19:22 --> Security Class Initialized
DEBUG - 2020-08-24 19:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:19:22 --> Input Class Initialized
INFO - 2020-08-24 19:19:22 --> Language Class Initialized
INFO - 2020-08-24 19:19:22 --> Language Class Initialized
INFO - 2020-08-24 19:19:22 --> Config Class Initialized
INFO - 2020-08-24 19:19:22 --> Loader Class Initialized
INFO - 2020-08-24 19:19:22 --> Helper loaded: url_helper
INFO - 2020-08-24 19:19:22 --> Helper loaded: form_helper
INFO - 2020-08-24 19:19:22 --> Helper loaded: file_helper
INFO - 2020-08-24 19:19:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:19:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:19:22 --> Upload Class Initialized
INFO - 2020-08-24 19:19:23 --> Controller Class Initialized
DEBUG - 2020-08-24 19:19:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 19:19:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 19:19:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 19:19:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 19:19:23 --> Final output sent to browser
DEBUG - 2020-08-24 19:19:23 --> Total execution time: 0.0520
INFO - 2020-08-24 19:19:35 --> Config Class Initialized
INFO - 2020-08-24 19:19:35 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:19:35 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:19:35 --> Utf8 Class Initialized
INFO - 2020-08-24 19:19:35 --> URI Class Initialized
DEBUG - 2020-08-24 19:19:35 --> No URI present. Default controller set.
INFO - 2020-08-24 19:19:35 --> Router Class Initialized
INFO - 2020-08-24 19:19:35 --> Output Class Initialized
INFO - 2020-08-24 19:19:35 --> Security Class Initialized
DEBUG - 2020-08-24 19:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:19:35 --> Input Class Initialized
INFO - 2020-08-24 19:19:35 --> Language Class Initialized
INFO - 2020-08-24 19:19:35 --> Language Class Initialized
INFO - 2020-08-24 19:19:35 --> Config Class Initialized
INFO - 2020-08-24 19:19:35 --> Loader Class Initialized
INFO - 2020-08-24 19:19:35 --> Helper loaded: url_helper
INFO - 2020-08-24 19:19:35 --> Helper loaded: form_helper
INFO - 2020-08-24 19:19:35 --> Helper loaded: file_helper
INFO - 2020-08-24 19:19:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:19:35 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:19:35 --> Upload Class Initialized
INFO - 2020-08-24 19:19:35 --> Controller Class Initialized
DEBUG - 2020-08-24 19:19:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 19:19:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 19:19:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 19:19:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 19:19:35 --> Final output sent to browser
DEBUG - 2020-08-24 19:19:35 --> Total execution time: 0.0644
INFO - 2020-08-24 19:21:57 --> Config Class Initialized
INFO - 2020-08-24 19:21:57 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:21:57 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:21:57 --> Utf8 Class Initialized
INFO - 2020-08-24 19:21:57 --> URI Class Initialized
DEBUG - 2020-08-24 19:21:57 --> No URI present. Default controller set.
INFO - 2020-08-24 19:21:57 --> Router Class Initialized
INFO - 2020-08-24 19:21:57 --> Output Class Initialized
INFO - 2020-08-24 19:21:57 --> Security Class Initialized
DEBUG - 2020-08-24 19:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:21:57 --> Input Class Initialized
INFO - 2020-08-24 19:21:57 --> Language Class Initialized
INFO - 2020-08-24 19:21:57 --> Language Class Initialized
INFO - 2020-08-24 19:21:57 --> Config Class Initialized
INFO - 2020-08-24 19:21:57 --> Loader Class Initialized
INFO - 2020-08-24 19:21:57 --> Helper loaded: url_helper
INFO - 2020-08-24 19:21:57 --> Helper loaded: form_helper
INFO - 2020-08-24 19:21:57 --> Helper loaded: file_helper
INFO - 2020-08-24 19:21:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:21:57 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:21:57 --> Upload Class Initialized
INFO - 2020-08-24 19:21:57 --> Controller Class Initialized
DEBUG - 2020-08-24 19:21:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 19:21:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 19:21:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 19:21:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 19:21:57 --> Final output sent to browser
DEBUG - 2020-08-24 19:21:57 --> Total execution time: 0.0541
INFO - 2020-08-24 19:22:38 --> Config Class Initialized
INFO - 2020-08-24 19:22:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:22:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:22:38 --> Utf8 Class Initialized
INFO - 2020-08-24 19:22:38 --> URI Class Initialized
INFO - 2020-08-24 19:22:38 --> Router Class Initialized
INFO - 2020-08-24 19:22:38 --> Output Class Initialized
INFO - 2020-08-24 19:22:38 --> Security Class Initialized
DEBUG - 2020-08-24 19:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:22:38 --> Input Class Initialized
INFO - 2020-08-24 19:22:38 --> Language Class Initialized
INFO - 2020-08-24 19:22:38 --> Language Class Initialized
INFO - 2020-08-24 19:22:38 --> Config Class Initialized
INFO - 2020-08-24 19:22:38 --> Loader Class Initialized
INFO - 2020-08-24 19:22:38 --> Helper loaded: url_helper
INFO - 2020-08-24 19:22:38 --> Helper loaded: form_helper
INFO - 2020-08-24 19:22:38 --> Helper loaded: file_helper
INFO - 2020-08-24 19:22:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:22:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:22:38 --> Upload Class Initialized
INFO - 2020-08-24 19:22:38 --> Controller Class Initialized
ERROR - 2020-08-24 19:22:38 --> 404 Page Not Found: /index
INFO - 2020-08-24 19:27:44 --> Config Class Initialized
INFO - 2020-08-24 19:27:44 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:27:44 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:27:44 --> Utf8 Class Initialized
INFO - 2020-08-24 19:27:44 --> URI Class Initialized
DEBUG - 2020-08-24 19:27:44 --> No URI present. Default controller set.
INFO - 2020-08-24 19:27:44 --> Router Class Initialized
INFO - 2020-08-24 19:27:44 --> Output Class Initialized
INFO - 2020-08-24 19:27:44 --> Security Class Initialized
DEBUG - 2020-08-24 19:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:27:44 --> Input Class Initialized
INFO - 2020-08-24 19:27:44 --> Language Class Initialized
INFO - 2020-08-24 19:27:44 --> Language Class Initialized
INFO - 2020-08-24 19:27:44 --> Config Class Initialized
INFO - 2020-08-24 19:27:44 --> Loader Class Initialized
INFO - 2020-08-24 19:27:44 --> Helper loaded: url_helper
INFO - 2020-08-24 19:27:44 --> Helper loaded: form_helper
INFO - 2020-08-24 19:27:44 --> Helper loaded: file_helper
INFO - 2020-08-24 19:27:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:27:44 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:27:44 --> Upload Class Initialized
INFO - 2020-08-24 19:27:44 --> Controller Class Initialized
DEBUG - 2020-08-24 19:27:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 19:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 19:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 19:27:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 19:27:44 --> Final output sent to browser
DEBUG - 2020-08-24 19:27:44 --> Total execution time: 0.0544
INFO - 2020-08-24 19:27:51 --> Config Class Initialized
INFO - 2020-08-24 19:27:51 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:27:51 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:27:51 --> Utf8 Class Initialized
INFO - 2020-08-24 19:27:51 --> URI Class Initialized
INFO - 2020-08-24 19:27:51 --> Router Class Initialized
INFO - 2020-08-24 19:27:51 --> Output Class Initialized
INFO - 2020-08-24 19:27:51 --> Security Class Initialized
DEBUG - 2020-08-24 19:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:27:51 --> Input Class Initialized
INFO - 2020-08-24 19:27:51 --> Language Class Initialized
INFO - 2020-08-24 19:27:51 --> Language Class Initialized
INFO - 2020-08-24 19:27:51 --> Config Class Initialized
INFO - 2020-08-24 19:27:51 --> Loader Class Initialized
INFO - 2020-08-24 19:27:51 --> Helper loaded: url_helper
INFO - 2020-08-24 19:27:51 --> Helper loaded: form_helper
INFO - 2020-08-24 19:27:51 --> Helper loaded: file_helper
INFO - 2020-08-24 19:27:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:27:51 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:27:51 --> Upload Class Initialized
INFO - 2020-08-24 19:27:51 --> Controller Class Initialized
ERROR - 2020-08-24 19:27:51 --> 404 Page Not Found: /index
INFO - 2020-08-24 19:35:45 --> Config Class Initialized
INFO - 2020-08-24 19:35:45 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:35:45 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:35:45 --> Utf8 Class Initialized
INFO - 2020-08-24 19:35:45 --> URI Class Initialized
DEBUG - 2020-08-24 19:35:45 --> No URI present. Default controller set.
INFO - 2020-08-24 19:35:45 --> Router Class Initialized
INFO - 2020-08-24 19:35:45 --> Output Class Initialized
INFO - 2020-08-24 19:35:45 --> Security Class Initialized
DEBUG - 2020-08-24 19:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:35:45 --> Input Class Initialized
INFO - 2020-08-24 19:35:45 --> Language Class Initialized
INFO - 2020-08-24 19:35:45 --> Language Class Initialized
INFO - 2020-08-24 19:35:45 --> Config Class Initialized
INFO - 2020-08-24 19:35:45 --> Loader Class Initialized
INFO - 2020-08-24 19:35:45 --> Helper loaded: url_helper
INFO - 2020-08-24 19:35:45 --> Helper loaded: form_helper
INFO - 2020-08-24 19:35:45 --> Helper loaded: file_helper
INFO - 2020-08-24 19:35:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:35:45 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:35:45 --> Upload Class Initialized
INFO - 2020-08-24 19:35:45 --> Controller Class Initialized
DEBUG - 2020-08-24 19:35:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 19:35:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 19:35:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 19:35:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 19:35:45 --> Final output sent to browser
DEBUG - 2020-08-24 19:35:45 --> Total execution time: 0.0498
INFO - 2020-08-24 19:50:59 --> Config Class Initialized
INFO - 2020-08-24 19:50:59 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:50:59 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:50:59 --> Utf8 Class Initialized
INFO - 2020-08-24 19:50:59 --> URI Class Initialized
DEBUG - 2020-08-24 19:50:59 --> No URI present. Default controller set.
INFO - 2020-08-24 19:50:59 --> Router Class Initialized
INFO - 2020-08-24 19:50:59 --> Output Class Initialized
INFO - 2020-08-24 19:50:59 --> Security Class Initialized
DEBUG - 2020-08-24 19:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:50:59 --> Input Class Initialized
INFO - 2020-08-24 19:50:59 --> Language Class Initialized
INFO - 2020-08-24 19:50:59 --> Language Class Initialized
INFO - 2020-08-24 19:50:59 --> Config Class Initialized
INFO - 2020-08-24 19:50:59 --> Loader Class Initialized
INFO - 2020-08-24 19:50:59 --> Helper loaded: url_helper
INFO - 2020-08-24 19:50:59 --> Helper loaded: form_helper
INFO - 2020-08-24 19:50:59 --> Helper loaded: file_helper
INFO - 2020-08-24 19:50:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:50:59 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:50:59 --> Upload Class Initialized
INFO - 2020-08-24 19:50:59 --> Controller Class Initialized
DEBUG - 2020-08-24 19:50:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 19:50:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 19:50:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 19:50:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 19:50:59 --> Final output sent to browser
DEBUG - 2020-08-24 19:50:59 --> Total execution time: 0.0526
INFO - 2020-08-24 19:52:45 --> Config Class Initialized
INFO - 2020-08-24 19:52:45 --> Hooks Class Initialized
DEBUG - 2020-08-24 19:52:45 --> UTF-8 Support Enabled
INFO - 2020-08-24 19:52:45 --> Utf8 Class Initialized
INFO - 2020-08-24 19:52:45 --> URI Class Initialized
INFO - 2020-08-24 19:52:45 --> Router Class Initialized
INFO - 2020-08-24 19:52:45 --> Output Class Initialized
INFO - 2020-08-24 19:52:45 --> Security Class Initialized
DEBUG - 2020-08-24 19:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 19:52:45 --> Input Class Initialized
INFO - 2020-08-24 19:52:45 --> Language Class Initialized
INFO - 2020-08-24 19:52:45 --> Language Class Initialized
INFO - 2020-08-24 19:52:45 --> Config Class Initialized
INFO - 2020-08-24 19:52:45 --> Loader Class Initialized
INFO - 2020-08-24 19:52:45 --> Helper loaded: url_helper
INFO - 2020-08-24 19:52:45 --> Helper loaded: form_helper
INFO - 2020-08-24 19:52:45 --> Helper loaded: file_helper
INFO - 2020-08-24 19:52:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 19:52:45 --> Database Driver Class Initialized
DEBUG - 2020-08-24 19:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 19:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 19:52:45 --> Upload Class Initialized
INFO - 2020-08-24 19:52:45 --> Controller Class Initialized
ERROR - 2020-08-24 19:52:45 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:02:09 --> Config Class Initialized
INFO - 2020-08-24 20:02:09 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:02:09 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:02:09 --> Utf8 Class Initialized
INFO - 2020-08-24 20:02:09 --> URI Class Initialized
DEBUG - 2020-08-24 20:02:09 --> No URI present. Default controller set.
INFO - 2020-08-24 20:02:09 --> Router Class Initialized
INFO - 2020-08-24 20:02:09 --> Output Class Initialized
INFO - 2020-08-24 20:02:09 --> Security Class Initialized
DEBUG - 2020-08-24 20:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:02:09 --> Input Class Initialized
INFO - 2020-08-24 20:02:09 --> Language Class Initialized
INFO - 2020-08-24 20:02:09 --> Language Class Initialized
INFO - 2020-08-24 20:02:09 --> Config Class Initialized
INFO - 2020-08-24 20:02:09 --> Loader Class Initialized
INFO - 2020-08-24 20:02:09 --> Helper loaded: url_helper
INFO - 2020-08-24 20:02:09 --> Helper loaded: form_helper
INFO - 2020-08-24 20:02:09 --> Helper loaded: file_helper
INFO - 2020-08-24 20:02:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:02:09 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:02:09 --> Upload Class Initialized
INFO - 2020-08-24 20:02:09 --> Controller Class Initialized
DEBUG - 2020-08-24 20:02:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:02:09 --> Final output sent to browser
DEBUG - 2020-08-24 20:02:09 --> Total execution time: 0.0506
INFO - 2020-08-24 20:02:10 --> Config Class Initialized
INFO - 2020-08-24 20:02:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:02:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:02:10 --> Utf8 Class Initialized
INFO - 2020-08-24 20:02:10 --> URI Class Initialized
INFO - 2020-08-24 20:02:10 --> Router Class Initialized
INFO - 2020-08-24 20:02:10 --> Output Class Initialized
INFO - 2020-08-24 20:02:10 --> Security Class Initialized
DEBUG - 2020-08-24 20:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:02:10 --> Input Class Initialized
INFO - 2020-08-24 20:02:10 --> Language Class Initialized
INFO - 2020-08-24 20:02:10 --> Language Class Initialized
INFO - 2020-08-24 20:02:10 --> Config Class Initialized
INFO - 2020-08-24 20:02:10 --> Loader Class Initialized
INFO - 2020-08-24 20:02:10 --> Helper loaded: url_helper
INFO - 2020-08-24 20:02:10 --> Helper loaded: form_helper
INFO - 2020-08-24 20:02:10 --> Helper loaded: file_helper
INFO - 2020-08-24 20:02:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:02:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:02:10 --> Upload Class Initialized
INFO - 2020-08-24 20:02:10 --> Controller Class Initialized
ERROR - 2020-08-24 20:02:10 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:03:27 --> Config Class Initialized
INFO - 2020-08-24 20:03:27 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:03:27 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:03:27 --> Utf8 Class Initialized
INFO - 2020-08-24 20:03:27 --> URI Class Initialized
DEBUG - 2020-08-24 20:03:27 --> No URI present. Default controller set.
INFO - 2020-08-24 20:03:27 --> Router Class Initialized
INFO - 2020-08-24 20:03:27 --> Output Class Initialized
INFO - 2020-08-24 20:03:27 --> Security Class Initialized
DEBUG - 2020-08-24 20:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:03:27 --> Input Class Initialized
INFO - 2020-08-24 20:03:27 --> Language Class Initialized
INFO - 2020-08-24 20:03:27 --> Language Class Initialized
INFO - 2020-08-24 20:03:27 --> Config Class Initialized
INFO - 2020-08-24 20:03:27 --> Loader Class Initialized
INFO - 2020-08-24 20:03:27 --> Helper loaded: url_helper
INFO - 2020-08-24 20:03:27 --> Helper loaded: form_helper
INFO - 2020-08-24 20:03:27 --> Helper loaded: file_helper
INFO - 2020-08-24 20:03:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:03:27 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:03:27 --> Upload Class Initialized
INFO - 2020-08-24 20:03:27 --> Controller Class Initialized
DEBUG - 2020-08-24 20:03:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:03:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:03:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:03:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:03:27 --> Final output sent to browser
DEBUG - 2020-08-24 20:03:27 --> Total execution time: 0.0527
INFO - 2020-08-24 20:03:42 --> Config Class Initialized
INFO - 2020-08-24 20:03:42 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:03:42 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:03:42 --> Utf8 Class Initialized
INFO - 2020-08-24 20:03:42 --> URI Class Initialized
INFO - 2020-08-24 20:03:42 --> Router Class Initialized
INFO - 2020-08-24 20:03:42 --> Output Class Initialized
INFO - 2020-08-24 20:03:42 --> Security Class Initialized
DEBUG - 2020-08-24 20:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:03:42 --> Input Class Initialized
INFO - 2020-08-24 20:03:42 --> Language Class Initialized
INFO - 2020-08-24 20:03:42 --> Language Class Initialized
INFO - 2020-08-24 20:03:42 --> Config Class Initialized
INFO - 2020-08-24 20:03:42 --> Loader Class Initialized
INFO - 2020-08-24 20:03:42 --> Helper loaded: url_helper
INFO - 2020-08-24 20:03:42 --> Helper loaded: form_helper
INFO - 2020-08-24 20:03:42 --> Helper loaded: file_helper
INFO - 2020-08-24 20:03:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:03:42 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:03:42 --> Upload Class Initialized
INFO - 2020-08-24 20:03:42 --> Controller Class Initialized
ERROR - 2020-08-24 20:03:42 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:04:44 --> Config Class Initialized
INFO - 2020-08-24 20:04:44 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:04:44 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:04:44 --> Utf8 Class Initialized
INFO - 2020-08-24 20:04:44 --> URI Class Initialized
DEBUG - 2020-08-24 20:04:44 --> No URI present. Default controller set.
INFO - 2020-08-24 20:04:44 --> Router Class Initialized
INFO - 2020-08-24 20:04:44 --> Output Class Initialized
INFO - 2020-08-24 20:04:44 --> Security Class Initialized
DEBUG - 2020-08-24 20:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:04:44 --> Input Class Initialized
INFO - 2020-08-24 20:04:44 --> Language Class Initialized
INFO - 2020-08-24 20:04:44 --> Language Class Initialized
INFO - 2020-08-24 20:04:44 --> Config Class Initialized
INFO - 2020-08-24 20:04:44 --> Loader Class Initialized
INFO - 2020-08-24 20:04:44 --> Helper loaded: url_helper
INFO - 2020-08-24 20:04:44 --> Helper loaded: form_helper
INFO - 2020-08-24 20:04:44 --> Helper loaded: file_helper
INFO - 2020-08-24 20:04:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:04:44 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:04:44 --> Upload Class Initialized
INFO - 2020-08-24 20:04:44 --> Controller Class Initialized
DEBUG - 2020-08-24 20:04:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:04:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:04:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:04:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:04:44 --> Final output sent to browser
DEBUG - 2020-08-24 20:04:44 --> Total execution time: 0.0511
INFO - 2020-08-24 20:04:52 --> Config Class Initialized
INFO - 2020-08-24 20:04:52 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:04:52 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:04:52 --> Utf8 Class Initialized
INFO - 2020-08-24 20:04:52 --> URI Class Initialized
INFO - 2020-08-24 20:04:52 --> Router Class Initialized
INFO - 2020-08-24 20:04:52 --> Output Class Initialized
INFO - 2020-08-24 20:04:52 --> Security Class Initialized
DEBUG - 2020-08-24 20:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:04:52 --> Input Class Initialized
INFO - 2020-08-24 20:04:52 --> Language Class Initialized
INFO - 2020-08-24 20:04:52 --> Language Class Initialized
INFO - 2020-08-24 20:04:52 --> Config Class Initialized
INFO - 2020-08-24 20:04:52 --> Loader Class Initialized
INFO - 2020-08-24 20:04:52 --> Helper loaded: url_helper
INFO - 2020-08-24 20:04:52 --> Helper loaded: form_helper
INFO - 2020-08-24 20:04:52 --> Helper loaded: file_helper
INFO - 2020-08-24 20:04:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:04:52 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:04:52 --> Upload Class Initialized
INFO - 2020-08-24 20:04:52 --> Controller Class Initialized
ERROR - 2020-08-24 20:04:52 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:06:49 --> Config Class Initialized
INFO - 2020-08-24 20:06:49 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:06:49 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:06:49 --> Utf8 Class Initialized
INFO - 2020-08-24 20:06:49 --> URI Class Initialized
INFO - 2020-08-24 20:06:49 --> Router Class Initialized
INFO - 2020-08-24 20:06:49 --> Output Class Initialized
INFO - 2020-08-24 20:06:49 --> Security Class Initialized
DEBUG - 2020-08-24 20:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:06:49 --> Input Class Initialized
INFO - 2020-08-24 20:06:49 --> Language Class Initialized
INFO - 2020-08-24 20:06:49 --> Language Class Initialized
INFO - 2020-08-24 20:06:49 --> Config Class Initialized
INFO - 2020-08-24 20:06:49 --> Loader Class Initialized
INFO - 2020-08-24 20:06:49 --> Helper loaded: url_helper
INFO - 2020-08-24 20:06:49 --> Helper loaded: form_helper
INFO - 2020-08-24 20:06:49 --> Helper loaded: file_helper
INFO - 2020-08-24 20:06:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:06:49 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:06:49 --> Upload Class Initialized
INFO - 2020-08-24 20:06:49 --> Controller Class Initialized
ERROR - 2020-08-24 20:06:49 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:08:46 --> Config Class Initialized
INFO - 2020-08-24 20:08:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:08:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:08:46 --> Utf8 Class Initialized
INFO - 2020-08-24 20:08:46 --> URI Class Initialized
INFO - 2020-08-24 20:08:46 --> Router Class Initialized
INFO - 2020-08-24 20:08:46 --> Output Class Initialized
INFO - 2020-08-24 20:08:46 --> Security Class Initialized
DEBUG - 2020-08-24 20:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:08:46 --> Input Class Initialized
INFO - 2020-08-24 20:08:46 --> Language Class Initialized
INFO - 2020-08-24 20:08:46 --> Language Class Initialized
INFO - 2020-08-24 20:08:46 --> Config Class Initialized
INFO - 2020-08-24 20:08:46 --> Loader Class Initialized
INFO - 2020-08-24 20:08:46 --> Helper loaded: url_helper
INFO - 2020-08-24 20:08:46 --> Helper loaded: form_helper
INFO - 2020-08-24 20:08:46 --> Helper loaded: file_helper
INFO - 2020-08-24 20:08:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:08:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:08:46 --> Upload Class Initialized
INFO - 2020-08-24 20:08:46 --> Controller Class Initialized
ERROR - 2020-08-24 20:08:46 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:10:43 --> Config Class Initialized
INFO - 2020-08-24 20:10:43 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:10:43 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:10:43 --> Utf8 Class Initialized
INFO - 2020-08-24 20:10:43 --> URI Class Initialized
INFO - 2020-08-24 20:10:43 --> Router Class Initialized
INFO - 2020-08-24 20:10:43 --> Output Class Initialized
INFO - 2020-08-24 20:10:43 --> Security Class Initialized
DEBUG - 2020-08-24 20:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:10:43 --> Input Class Initialized
INFO - 2020-08-24 20:10:43 --> Language Class Initialized
INFO - 2020-08-24 20:10:43 --> Language Class Initialized
INFO - 2020-08-24 20:10:43 --> Config Class Initialized
INFO - 2020-08-24 20:10:43 --> Loader Class Initialized
INFO - 2020-08-24 20:10:43 --> Helper loaded: url_helper
INFO - 2020-08-24 20:10:43 --> Helper loaded: form_helper
INFO - 2020-08-24 20:10:43 --> Helper loaded: file_helper
INFO - 2020-08-24 20:10:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:10:43 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:10:43 --> Upload Class Initialized
INFO - 2020-08-24 20:10:43 --> Controller Class Initialized
ERROR - 2020-08-24 20:10:43 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:11:43 --> Config Class Initialized
INFO - 2020-08-24 20:11:43 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:11:43 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:11:43 --> Utf8 Class Initialized
INFO - 2020-08-24 20:11:43 --> URI Class Initialized
DEBUG - 2020-08-24 20:11:43 --> No URI present. Default controller set.
INFO - 2020-08-24 20:11:43 --> Router Class Initialized
INFO - 2020-08-24 20:11:43 --> Output Class Initialized
INFO - 2020-08-24 20:11:43 --> Security Class Initialized
DEBUG - 2020-08-24 20:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:11:43 --> Input Class Initialized
INFO - 2020-08-24 20:11:43 --> Language Class Initialized
INFO - 2020-08-24 20:11:43 --> Language Class Initialized
INFO - 2020-08-24 20:11:43 --> Config Class Initialized
INFO - 2020-08-24 20:11:43 --> Loader Class Initialized
INFO - 2020-08-24 20:11:43 --> Helper loaded: url_helper
INFO - 2020-08-24 20:11:43 --> Helper loaded: form_helper
INFO - 2020-08-24 20:11:43 --> Helper loaded: file_helper
INFO - 2020-08-24 20:11:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:11:43 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:11:43 --> Upload Class Initialized
INFO - 2020-08-24 20:11:43 --> Controller Class Initialized
DEBUG - 2020-08-24 20:11:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:11:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:11:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:11:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:11:43 --> Final output sent to browser
DEBUG - 2020-08-24 20:11:43 --> Total execution time: 0.0544
INFO - 2020-08-24 20:11:59 --> Config Class Initialized
INFO - 2020-08-24 20:11:59 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:11:59 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:11:59 --> Utf8 Class Initialized
INFO - 2020-08-24 20:11:59 --> URI Class Initialized
INFO - 2020-08-24 20:11:59 --> Router Class Initialized
INFO - 2020-08-24 20:11:59 --> Output Class Initialized
INFO - 2020-08-24 20:11:59 --> Security Class Initialized
DEBUG - 2020-08-24 20:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:11:59 --> Input Class Initialized
INFO - 2020-08-24 20:11:59 --> Language Class Initialized
INFO - 2020-08-24 20:11:59 --> Language Class Initialized
INFO - 2020-08-24 20:11:59 --> Config Class Initialized
INFO - 2020-08-24 20:11:59 --> Loader Class Initialized
INFO - 2020-08-24 20:11:59 --> Helper loaded: url_helper
INFO - 2020-08-24 20:11:59 --> Helper loaded: form_helper
INFO - 2020-08-24 20:11:59 --> Helper loaded: file_helper
INFO - 2020-08-24 20:11:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:11:59 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:11:59 --> Upload Class Initialized
INFO - 2020-08-24 20:11:59 --> Controller Class Initialized
ERROR - 2020-08-24 20:11:59 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:14:20 --> Config Class Initialized
INFO - 2020-08-24 20:14:20 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:14:20 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:14:20 --> Utf8 Class Initialized
INFO - 2020-08-24 20:14:20 --> URI Class Initialized
DEBUG - 2020-08-24 20:14:20 --> No URI present. Default controller set.
INFO - 2020-08-24 20:14:20 --> Router Class Initialized
INFO - 2020-08-24 20:14:20 --> Output Class Initialized
INFO - 2020-08-24 20:14:20 --> Security Class Initialized
DEBUG - 2020-08-24 20:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:14:20 --> Input Class Initialized
INFO - 2020-08-24 20:14:20 --> Language Class Initialized
INFO - 2020-08-24 20:14:20 --> Language Class Initialized
INFO - 2020-08-24 20:14:20 --> Config Class Initialized
INFO - 2020-08-24 20:14:20 --> Loader Class Initialized
INFO - 2020-08-24 20:14:20 --> Helper loaded: url_helper
INFO - 2020-08-24 20:14:20 --> Helper loaded: form_helper
INFO - 2020-08-24 20:14:20 --> Helper loaded: file_helper
INFO - 2020-08-24 20:14:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:14:20 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:14:20 --> Upload Class Initialized
INFO - 2020-08-24 20:14:20 --> Controller Class Initialized
DEBUG - 2020-08-24 20:14:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:14:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:14:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:14:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:14:20 --> Final output sent to browser
DEBUG - 2020-08-24 20:14:20 --> Total execution time: 0.0516
INFO - 2020-08-24 20:16:46 --> Config Class Initialized
INFO - 2020-08-24 20:16:46 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:16:46 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:16:46 --> Utf8 Class Initialized
INFO - 2020-08-24 20:16:46 --> URI Class Initialized
DEBUG - 2020-08-24 20:16:46 --> No URI present. Default controller set.
INFO - 2020-08-24 20:16:46 --> Router Class Initialized
INFO - 2020-08-24 20:16:46 --> Output Class Initialized
INFO - 2020-08-24 20:16:46 --> Security Class Initialized
DEBUG - 2020-08-24 20:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:16:46 --> Input Class Initialized
INFO - 2020-08-24 20:16:46 --> Language Class Initialized
INFO - 2020-08-24 20:16:46 --> Language Class Initialized
INFO - 2020-08-24 20:16:46 --> Config Class Initialized
INFO - 2020-08-24 20:16:46 --> Loader Class Initialized
INFO - 2020-08-24 20:16:46 --> Helper loaded: url_helper
INFO - 2020-08-24 20:16:46 --> Helper loaded: form_helper
INFO - 2020-08-24 20:16:46 --> Helper loaded: file_helper
INFO - 2020-08-24 20:16:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:16:46 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:16:46 --> Upload Class Initialized
INFO - 2020-08-24 20:16:46 --> Controller Class Initialized
DEBUG - 2020-08-24 20:16:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:16:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:16:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:16:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:16:46 --> Final output sent to browser
DEBUG - 2020-08-24 20:16:46 --> Total execution time: 0.0519
INFO - 2020-08-24 20:17:37 --> Config Class Initialized
INFO - 2020-08-24 20:17:37 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:17:37 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:17:37 --> Utf8 Class Initialized
INFO - 2020-08-24 20:17:37 --> URI Class Initialized
DEBUG - 2020-08-24 20:17:37 --> No URI present. Default controller set.
INFO - 2020-08-24 20:17:37 --> Router Class Initialized
INFO - 2020-08-24 20:17:37 --> Output Class Initialized
INFO - 2020-08-24 20:17:37 --> Security Class Initialized
DEBUG - 2020-08-24 20:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:17:37 --> Input Class Initialized
INFO - 2020-08-24 20:17:37 --> Language Class Initialized
INFO - 2020-08-24 20:17:37 --> Language Class Initialized
INFO - 2020-08-24 20:17:37 --> Config Class Initialized
INFO - 2020-08-24 20:17:37 --> Loader Class Initialized
INFO - 2020-08-24 20:17:37 --> Helper loaded: url_helper
INFO - 2020-08-24 20:17:37 --> Helper loaded: form_helper
INFO - 2020-08-24 20:17:37 --> Helper loaded: file_helper
INFO - 2020-08-24 20:17:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:17:37 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:17:37 --> Upload Class Initialized
INFO - 2020-08-24 20:17:37 --> Controller Class Initialized
DEBUG - 2020-08-24 20:17:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:17:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:17:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:17:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:17:37 --> Final output sent to browser
DEBUG - 2020-08-24 20:17:37 --> Total execution time: 0.0505
INFO - 2020-08-24 20:19:10 --> Config Class Initialized
INFO - 2020-08-24 20:19:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:19:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:19:10 --> Utf8 Class Initialized
INFO - 2020-08-24 20:19:10 --> URI Class Initialized
DEBUG - 2020-08-24 20:19:10 --> No URI present. Default controller set.
INFO - 2020-08-24 20:19:10 --> Router Class Initialized
INFO - 2020-08-24 20:19:10 --> Output Class Initialized
INFO - 2020-08-24 20:19:10 --> Security Class Initialized
DEBUG - 2020-08-24 20:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:19:10 --> Input Class Initialized
INFO - 2020-08-24 20:19:10 --> Language Class Initialized
INFO - 2020-08-24 20:19:10 --> Language Class Initialized
INFO - 2020-08-24 20:19:10 --> Config Class Initialized
INFO - 2020-08-24 20:19:10 --> Loader Class Initialized
INFO - 2020-08-24 20:19:10 --> Helper loaded: url_helper
INFO - 2020-08-24 20:19:10 --> Helper loaded: form_helper
INFO - 2020-08-24 20:19:10 --> Helper loaded: file_helper
INFO - 2020-08-24 20:19:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:19:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:19:10 --> Upload Class Initialized
INFO - 2020-08-24 20:19:10 --> Controller Class Initialized
DEBUG - 2020-08-24 20:19:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:19:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:19:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:19:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:19:10 --> Final output sent to browser
DEBUG - 2020-08-24 20:19:10 --> Total execution time: 0.0494
INFO - 2020-08-24 20:20:01 --> Config Class Initialized
INFO - 2020-08-24 20:20:01 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:20:01 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:20:01 --> Utf8 Class Initialized
INFO - 2020-08-24 20:20:01 --> URI Class Initialized
DEBUG - 2020-08-24 20:20:01 --> No URI present. Default controller set.
INFO - 2020-08-24 20:20:01 --> Router Class Initialized
INFO - 2020-08-24 20:20:01 --> Output Class Initialized
INFO - 2020-08-24 20:20:01 --> Security Class Initialized
DEBUG - 2020-08-24 20:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:20:01 --> Input Class Initialized
INFO - 2020-08-24 20:20:01 --> Language Class Initialized
INFO - 2020-08-24 20:20:01 --> Language Class Initialized
INFO - 2020-08-24 20:20:01 --> Config Class Initialized
INFO - 2020-08-24 20:20:01 --> Loader Class Initialized
INFO - 2020-08-24 20:20:01 --> Helper loaded: url_helper
INFO - 2020-08-24 20:20:01 --> Helper loaded: form_helper
INFO - 2020-08-24 20:20:01 --> Helper loaded: file_helper
INFO - 2020-08-24 20:20:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:20:01 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:20:01 --> Upload Class Initialized
INFO - 2020-08-24 20:20:01 --> Controller Class Initialized
DEBUG - 2020-08-24 20:20:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:20:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:20:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:20:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:20:01 --> Final output sent to browser
DEBUG - 2020-08-24 20:20:01 --> Total execution time: 0.2115
INFO - 2020-08-24 20:22:40 --> Config Class Initialized
INFO - 2020-08-24 20:22:40 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:22:40 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:22:40 --> Utf8 Class Initialized
INFO - 2020-08-24 20:22:40 --> URI Class Initialized
DEBUG - 2020-08-24 20:22:40 --> No URI present. Default controller set.
INFO - 2020-08-24 20:22:40 --> Router Class Initialized
INFO - 2020-08-24 20:22:40 --> Output Class Initialized
INFO - 2020-08-24 20:22:40 --> Security Class Initialized
DEBUG - 2020-08-24 20:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:22:40 --> Input Class Initialized
INFO - 2020-08-24 20:22:40 --> Language Class Initialized
INFO - 2020-08-24 20:22:40 --> Language Class Initialized
INFO - 2020-08-24 20:22:40 --> Config Class Initialized
INFO - 2020-08-24 20:22:40 --> Loader Class Initialized
INFO - 2020-08-24 20:22:40 --> Helper loaded: url_helper
INFO - 2020-08-24 20:22:40 --> Helper loaded: form_helper
INFO - 2020-08-24 20:22:40 --> Helper loaded: file_helper
INFO - 2020-08-24 20:22:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:22:40 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:22:40 --> Upload Class Initialized
INFO - 2020-08-24 20:22:40 --> Controller Class Initialized
DEBUG - 2020-08-24 20:22:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:22:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:22:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:22:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:22:40 --> Final output sent to browser
DEBUG - 2020-08-24 20:22:40 --> Total execution time: 0.0503
INFO - 2020-08-24 20:23:10 --> Config Class Initialized
INFO - 2020-08-24 20:23:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:23:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:23:10 --> Utf8 Class Initialized
INFO - 2020-08-24 20:23:10 --> URI Class Initialized
DEBUG - 2020-08-24 20:23:10 --> No URI present. Default controller set.
INFO - 2020-08-24 20:23:10 --> Router Class Initialized
INFO - 2020-08-24 20:23:10 --> Output Class Initialized
INFO - 2020-08-24 20:23:10 --> Security Class Initialized
DEBUG - 2020-08-24 20:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:23:10 --> Input Class Initialized
INFO - 2020-08-24 20:23:10 --> Language Class Initialized
INFO - 2020-08-24 20:23:10 --> Language Class Initialized
INFO - 2020-08-24 20:23:10 --> Config Class Initialized
INFO - 2020-08-24 20:23:10 --> Loader Class Initialized
INFO - 2020-08-24 20:23:10 --> Helper loaded: url_helper
INFO - 2020-08-24 20:23:10 --> Helper loaded: form_helper
INFO - 2020-08-24 20:23:10 --> Helper loaded: file_helper
INFO - 2020-08-24 20:23:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:23:10 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:23:10 --> Upload Class Initialized
INFO - 2020-08-24 20:23:10 --> Controller Class Initialized
DEBUG - 2020-08-24 20:23:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:23:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:23:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:23:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:23:10 --> Final output sent to browser
DEBUG - 2020-08-24 20:23:10 --> Total execution time: 0.0746
INFO - 2020-08-24 20:24:23 --> Config Class Initialized
INFO - 2020-08-24 20:24:23 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:24:23 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:24:23 --> Utf8 Class Initialized
INFO - 2020-08-24 20:24:23 --> URI Class Initialized
DEBUG - 2020-08-24 20:24:23 --> No URI present. Default controller set.
INFO - 2020-08-24 20:24:23 --> Router Class Initialized
INFO - 2020-08-24 20:24:23 --> Output Class Initialized
INFO - 2020-08-24 20:24:23 --> Security Class Initialized
DEBUG - 2020-08-24 20:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:24:23 --> Input Class Initialized
INFO - 2020-08-24 20:24:23 --> Language Class Initialized
INFO - 2020-08-24 20:24:23 --> Language Class Initialized
INFO - 2020-08-24 20:24:23 --> Config Class Initialized
INFO - 2020-08-24 20:24:23 --> Loader Class Initialized
INFO - 2020-08-24 20:24:23 --> Helper loaded: url_helper
INFO - 2020-08-24 20:24:23 --> Helper loaded: form_helper
INFO - 2020-08-24 20:24:23 --> Helper loaded: file_helper
INFO - 2020-08-24 20:24:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:24:23 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:24:23 --> Upload Class Initialized
INFO - 2020-08-24 20:24:23 --> Controller Class Initialized
DEBUG - 2020-08-24 20:24:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:24:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:24:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:24:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:24:23 --> Final output sent to browser
DEBUG - 2020-08-24 20:24:23 --> Total execution time: 0.0521
INFO - 2020-08-24 20:24:24 --> Config Class Initialized
INFO - 2020-08-24 20:24:24 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:24:24 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:24:24 --> Utf8 Class Initialized
INFO - 2020-08-24 20:24:24 --> URI Class Initialized
INFO - 2020-08-24 20:24:24 --> Router Class Initialized
INFO - 2020-08-24 20:24:24 --> Output Class Initialized
INFO - 2020-08-24 20:24:24 --> Security Class Initialized
DEBUG - 2020-08-24 20:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:24:24 --> Input Class Initialized
INFO - 2020-08-24 20:24:24 --> Language Class Initialized
INFO - 2020-08-24 20:24:24 --> Language Class Initialized
INFO - 2020-08-24 20:24:24 --> Config Class Initialized
INFO - 2020-08-24 20:24:24 --> Loader Class Initialized
INFO - 2020-08-24 20:24:24 --> Helper loaded: url_helper
INFO - 2020-08-24 20:24:24 --> Helper loaded: form_helper
INFO - 2020-08-24 20:24:24 --> Helper loaded: file_helper
INFO - 2020-08-24 20:24:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:24:24 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:24:24 --> Upload Class Initialized
INFO - 2020-08-24 20:24:24 --> Controller Class Initialized
ERROR - 2020-08-24 20:24:24 --> 404 Page Not Found: /index
INFO - 2020-08-24 20:26:38 --> Config Class Initialized
INFO - 2020-08-24 20:26:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:26:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:26:38 --> Utf8 Class Initialized
INFO - 2020-08-24 20:26:38 --> URI Class Initialized
DEBUG - 2020-08-24 20:26:38 --> No URI present. Default controller set.
INFO - 2020-08-24 20:26:38 --> Router Class Initialized
INFO - 2020-08-24 20:26:38 --> Output Class Initialized
INFO - 2020-08-24 20:26:38 --> Security Class Initialized
DEBUG - 2020-08-24 20:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:26:38 --> Input Class Initialized
INFO - 2020-08-24 20:26:38 --> Language Class Initialized
INFO - 2020-08-24 20:26:38 --> Language Class Initialized
INFO - 2020-08-24 20:26:38 --> Config Class Initialized
INFO - 2020-08-24 20:26:38 --> Loader Class Initialized
INFO - 2020-08-24 20:26:38 --> Helper loaded: url_helper
INFO - 2020-08-24 20:26:38 --> Helper loaded: form_helper
INFO - 2020-08-24 20:26:38 --> Helper loaded: file_helper
INFO - 2020-08-24 20:26:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:26:38 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:26:38 --> Upload Class Initialized
INFO - 2020-08-24 20:26:38 --> Controller Class Initialized
DEBUG - 2020-08-24 20:26:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:26:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:26:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:26:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:26:38 --> Final output sent to browser
DEBUG - 2020-08-24 20:26:38 --> Total execution time: 0.0497
INFO - 2020-08-24 20:27:23 --> Config Class Initialized
INFO - 2020-08-24 20:27:23 --> Hooks Class Initialized
DEBUG - 2020-08-24 20:27:23 --> UTF-8 Support Enabled
INFO - 2020-08-24 20:27:23 --> Utf8 Class Initialized
INFO - 2020-08-24 20:27:23 --> URI Class Initialized
DEBUG - 2020-08-24 20:27:23 --> No URI present. Default controller set.
INFO - 2020-08-24 20:27:23 --> Router Class Initialized
INFO - 2020-08-24 20:27:23 --> Output Class Initialized
INFO - 2020-08-24 20:27:23 --> Security Class Initialized
DEBUG - 2020-08-24 20:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 20:27:23 --> Input Class Initialized
INFO - 2020-08-24 20:27:23 --> Language Class Initialized
INFO - 2020-08-24 20:27:23 --> Language Class Initialized
INFO - 2020-08-24 20:27:23 --> Config Class Initialized
INFO - 2020-08-24 20:27:23 --> Loader Class Initialized
INFO - 2020-08-24 20:27:23 --> Helper loaded: url_helper
INFO - 2020-08-24 20:27:23 --> Helper loaded: form_helper
INFO - 2020-08-24 20:27:23 --> Helper loaded: file_helper
INFO - 2020-08-24 20:27:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 20:27:23 --> Database Driver Class Initialized
DEBUG - 2020-08-24 20:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 20:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 20:27:23 --> Upload Class Initialized
INFO - 2020-08-24 20:27:23 --> Controller Class Initialized
DEBUG - 2020-08-24 20:27:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 20:27:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 20:27:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 20:27:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 20:27:23 --> Final output sent to browser
DEBUG - 2020-08-24 20:27:23 --> Total execution time: 0.0525
INFO - 2020-08-24 22:02:27 --> Config Class Initialized
INFO - 2020-08-24 22:02:27 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:02:27 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:02:27 --> Utf8 Class Initialized
INFO - 2020-08-24 22:02:27 --> URI Class Initialized
DEBUG - 2020-08-24 22:02:27 --> No URI present. Default controller set.
INFO - 2020-08-24 22:02:27 --> Router Class Initialized
INFO - 2020-08-24 22:02:27 --> Output Class Initialized
INFO - 2020-08-24 22:02:27 --> Security Class Initialized
DEBUG - 2020-08-24 22:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:02:28 --> Input Class Initialized
INFO - 2020-08-24 22:02:28 --> Language Class Initialized
INFO - 2020-08-24 22:02:28 --> Language Class Initialized
INFO - 2020-08-24 22:02:28 --> Config Class Initialized
INFO - 2020-08-24 22:02:28 --> Loader Class Initialized
INFO - 2020-08-24 22:02:28 --> Helper loaded: url_helper
INFO - 2020-08-24 22:02:28 --> Helper loaded: form_helper
INFO - 2020-08-24 22:02:28 --> Helper loaded: file_helper
INFO - 2020-08-24 22:02:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:02:28 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:02:28 --> Upload Class Initialized
INFO - 2020-08-24 22:02:28 --> Controller Class Initialized
DEBUG - 2020-08-24 22:02:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 22:02:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 22:02:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 22:02:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 22:02:28 --> Final output sent to browser
DEBUG - 2020-08-24 22:02:28 --> Total execution time: 0.0704
INFO - 2020-08-24 22:02:36 --> Config Class Initialized
INFO - 2020-08-24 22:02:36 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:02:36 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:02:36 --> Utf8 Class Initialized
INFO - 2020-08-24 22:02:36 --> URI Class Initialized
INFO - 2020-08-24 22:02:36 --> Router Class Initialized
INFO - 2020-08-24 22:02:36 --> Output Class Initialized
INFO - 2020-08-24 22:02:36 --> Security Class Initialized
DEBUG - 2020-08-24 22:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:02:36 --> Input Class Initialized
INFO - 2020-08-24 22:02:36 --> Language Class Initialized
INFO - 2020-08-24 22:02:36 --> Language Class Initialized
INFO - 2020-08-24 22:02:36 --> Config Class Initialized
INFO - 2020-08-24 22:02:36 --> Loader Class Initialized
INFO - 2020-08-24 22:02:36 --> Helper loaded: url_helper
INFO - 2020-08-24 22:02:36 --> Helper loaded: form_helper
INFO - 2020-08-24 22:02:36 --> Helper loaded: file_helper
INFO - 2020-08-24 22:02:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:02:36 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:02:36 --> Upload Class Initialized
INFO - 2020-08-24 22:02:36 --> Controller Class Initialized
ERROR - 2020-08-24 22:02:36 --> 404 Page Not Found: /index
INFO - 2020-08-24 22:07:45 --> Config Class Initialized
INFO - 2020-08-24 22:07:45 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:07:45 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:07:45 --> Utf8 Class Initialized
INFO - 2020-08-24 22:07:45 --> URI Class Initialized
DEBUG - 2020-08-24 22:07:45 --> No URI present. Default controller set.
INFO - 2020-08-24 22:07:45 --> Router Class Initialized
INFO - 2020-08-24 22:07:45 --> Output Class Initialized
INFO - 2020-08-24 22:07:45 --> Security Class Initialized
DEBUG - 2020-08-24 22:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:07:45 --> Input Class Initialized
INFO - 2020-08-24 22:07:45 --> Language Class Initialized
INFO - 2020-08-24 22:07:45 --> Language Class Initialized
INFO - 2020-08-24 22:07:45 --> Config Class Initialized
INFO - 2020-08-24 22:07:45 --> Loader Class Initialized
INFO - 2020-08-24 22:07:45 --> Helper loaded: url_helper
INFO - 2020-08-24 22:07:45 --> Helper loaded: form_helper
INFO - 2020-08-24 22:07:45 --> Helper loaded: file_helper
INFO - 2020-08-24 22:07:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:07:45 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:07:45 --> Upload Class Initialized
INFO - 2020-08-24 22:07:45 --> Controller Class Initialized
DEBUG - 2020-08-24 22:07:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 22:07:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 22:07:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 22:07:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 22:07:45 --> Final output sent to browser
DEBUG - 2020-08-24 22:07:45 --> Total execution time: 0.0807
INFO - 2020-08-24 22:07:50 --> Config Class Initialized
INFO - 2020-08-24 22:07:50 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:07:50 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:07:50 --> Utf8 Class Initialized
INFO - 2020-08-24 22:07:50 --> URI Class Initialized
INFO - 2020-08-24 22:07:50 --> Router Class Initialized
INFO - 2020-08-24 22:07:50 --> Output Class Initialized
INFO - 2020-08-24 22:07:50 --> Security Class Initialized
DEBUG - 2020-08-24 22:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:07:50 --> Input Class Initialized
INFO - 2020-08-24 22:07:50 --> Language Class Initialized
INFO - 2020-08-24 22:07:50 --> Language Class Initialized
INFO - 2020-08-24 22:07:50 --> Config Class Initialized
INFO - 2020-08-24 22:07:50 --> Loader Class Initialized
INFO - 2020-08-24 22:07:50 --> Helper loaded: url_helper
INFO - 2020-08-24 22:07:50 --> Helper loaded: form_helper
INFO - 2020-08-24 22:07:50 --> Helper loaded: file_helper
INFO - 2020-08-24 22:07:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:07:50 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:07:50 --> Upload Class Initialized
INFO - 2020-08-24 22:07:50 --> Controller Class Initialized
ERROR - 2020-08-24 22:07:50 --> 404 Page Not Found: /index
INFO - 2020-08-24 22:10:13 --> Config Class Initialized
INFO - 2020-08-24 22:10:13 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:10:13 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:10:13 --> Utf8 Class Initialized
INFO - 2020-08-24 22:10:13 --> URI Class Initialized
DEBUG - 2020-08-24 22:10:13 --> No URI present. Default controller set.
INFO - 2020-08-24 22:10:13 --> Router Class Initialized
INFO - 2020-08-24 22:10:13 --> Output Class Initialized
INFO - 2020-08-24 22:10:13 --> Security Class Initialized
DEBUG - 2020-08-24 22:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:10:13 --> Input Class Initialized
INFO - 2020-08-24 22:10:13 --> Language Class Initialized
INFO - 2020-08-24 22:10:13 --> Language Class Initialized
INFO - 2020-08-24 22:10:13 --> Config Class Initialized
INFO - 2020-08-24 22:10:13 --> Loader Class Initialized
INFO - 2020-08-24 22:10:13 --> Helper loaded: url_helper
INFO - 2020-08-24 22:10:13 --> Helper loaded: form_helper
INFO - 2020-08-24 22:10:13 --> Helper loaded: file_helper
INFO - 2020-08-24 22:10:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:10:13 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:10:13 --> Upload Class Initialized
INFO - 2020-08-24 22:10:13 --> Controller Class Initialized
DEBUG - 2020-08-24 22:10:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 22:10:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 22:10:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 22:10:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 22:10:13 --> Final output sent to browser
DEBUG - 2020-08-24 22:10:13 --> Total execution time: 0.0504
INFO - 2020-08-24 22:11:21 --> Config Class Initialized
INFO - 2020-08-24 22:11:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:11:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:11:21 --> Utf8 Class Initialized
INFO - 2020-08-24 22:11:21 --> URI Class Initialized
INFO - 2020-08-24 22:11:21 --> Router Class Initialized
INFO - 2020-08-24 22:11:21 --> Output Class Initialized
INFO - 2020-08-24 22:11:21 --> Security Class Initialized
DEBUG - 2020-08-24 22:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:11:21 --> Input Class Initialized
INFO - 2020-08-24 22:11:21 --> Language Class Initialized
INFO - 2020-08-24 22:11:21 --> Language Class Initialized
INFO - 2020-08-24 22:11:21 --> Config Class Initialized
INFO - 2020-08-24 22:11:21 --> Loader Class Initialized
INFO - 2020-08-24 22:11:21 --> Helper loaded: url_helper
INFO - 2020-08-24 22:11:21 --> Helper loaded: form_helper
INFO - 2020-08-24 22:11:21 --> Helper loaded: file_helper
INFO - 2020-08-24 22:11:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:11:21 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:11:21 --> Upload Class Initialized
INFO - 2020-08-24 22:11:21 --> Controller Class Initialized
ERROR - 2020-08-24 22:11:21 --> 404 Page Not Found: /index
INFO - 2020-08-24 22:11:22 --> Config Class Initialized
INFO - 2020-08-24 22:11:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:11:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:11:22 --> Utf8 Class Initialized
INFO - 2020-08-24 22:11:22 --> URI Class Initialized
INFO - 2020-08-24 22:11:22 --> Router Class Initialized
INFO - 2020-08-24 22:11:22 --> Output Class Initialized
INFO - 2020-08-24 22:11:22 --> Security Class Initialized
DEBUG - 2020-08-24 22:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:11:22 --> Input Class Initialized
INFO - 2020-08-24 22:11:22 --> Language Class Initialized
INFO - 2020-08-24 22:11:22 --> Language Class Initialized
INFO - 2020-08-24 22:11:22 --> Config Class Initialized
INFO - 2020-08-24 22:11:22 --> Loader Class Initialized
INFO - 2020-08-24 22:11:22 --> Helper loaded: url_helper
INFO - 2020-08-24 22:11:22 --> Helper loaded: form_helper
INFO - 2020-08-24 22:11:22 --> Helper loaded: file_helper
INFO - 2020-08-24 22:11:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:11:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:11:22 --> Upload Class Initialized
INFO - 2020-08-24 22:11:22 --> Controller Class Initialized
ERROR - 2020-08-24 22:11:22 --> 404 Page Not Found: /index
INFO - 2020-08-24 22:11:22 --> Config Class Initialized
INFO - 2020-08-24 22:11:22 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:11:22 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:11:22 --> Utf8 Class Initialized
INFO - 2020-08-24 22:11:22 --> URI Class Initialized
DEBUG - 2020-08-24 22:11:22 --> No URI present. Default controller set.
INFO - 2020-08-24 22:11:22 --> Router Class Initialized
INFO - 2020-08-24 22:11:22 --> Output Class Initialized
INFO - 2020-08-24 22:11:22 --> Security Class Initialized
DEBUG - 2020-08-24 22:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:11:22 --> Input Class Initialized
INFO - 2020-08-24 22:11:22 --> Language Class Initialized
INFO - 2020-08-24 22:11:22 --> Language Class Initialized
INFO - 2020-08-24 22:11:22 --> Config Class Initialized
INFO - 2020-08-24 22:11:22 --> Loader Class Initialized
INFO - 2020-08-24 22:11:22 --> Helper loaded: url_helper
INFO - 2020-08-24 22:11:22 --> Helper loaded: form_helper
INFO - 2020-08-24 22:11:22 --> Helper loaded: file_helper
INFO - 2020-08-24 22:11:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:11:22 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:11:22 --> Upload Class Initialized
INFO - 2020-08-24 22:11:22 --> Controller Class Initialized
DEBUG - 2020-08-24 22:11:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 22:11:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 22:11:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 22:11:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 22:11:23 --> Final output sent to browser
DEBUG - 2020-08-24 22:11:23 --> Total execution time: 0.0499
INFO - 2020-08-24 22:12:56 --> Config Class Initialized
INFO - 2020-08-24 22:12:56 --> Hooks Class Initialized
DEBUG - 2020-08-24 22:12:56 --> UTF-8 Support Enabled
INFO - 2020-08-24 22:12:56 --> Utf8 Class Initialized
INFO - 2020-08-24 22:12:56 --> URI Class Initialized
INFO - 2020-08-24 22:12:56 --> Router Class Initialized
INFO - 2020-08-24 22:12:56 --> Output Class Initialized
INFO - 2020-08-24 22:12:56 --> Security Class Initialized
DEBUG - 2020-08-24 22:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 22:12:56 --> Input Class Initialized
INFO - 2020-08-24 22:12:56 --> Language Class Initialized
INFO - 2020-08-24 22:12:56 --> Language Class Initialized
INFO - 2020-08-24 22:12:56 --> Config Class Initialized
INFO - 2020-08-24 22:12:56 --> Loader Class Initialized
INFO - 2020-08-24 22:12:56 --> Helper loaded: url_helper
INFO - 2020-08-24 22:12:56 --> Helper loaded: form_helper
INFO - 2020-08-24 22:12:56 --> Helper loaded: file_helper
INFO - 2020-08-24 22:12:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 22:12:56 --> Database Driver Class Initialized
DEBUG - 2020-08-24 22:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 22:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 22:12:56 --> Upload Class Initialized
INFO - 2020-08-24 22:12:56 --> Controller Class Initialized
DEBUG - 2020-08-24 22:12:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 22:12:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-24 22:12:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 22:12:56 --> Final output sent to browser
DEBUG - 2020-08-24 22:12:56 --> Total execution time: 0.0546
INFO - 2020-08-24 23:26:27 --> Config Class Initialized
INFO - 2020-08-24 23:26:27 --> Hooks Class Initialized
DEBUG - 2020-08-24 23:26:27 --> UTF-8 Support Enabled
INFO - 2020-08-24 23:26:27 --> Utf8 Class Initialized
INFO - 2020-08-24 23:26:27 --> URI Class Initialized
INFO - 2020-08-24 23:26:27 --> Router Class Initialized
INFO - 2020-08-24 23:26:27 --> Output Class Initialized
INFO - 2020-08-24 23:26:27 --> Security Class Initialized
DEBUG - 2020-08-24 23:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 23:26:27 --> Input Class Initialized
INFO - 2020-08-24 23:26:27 --> Language Class Initialized
INFO - 2020-08-24 23:26:27 --> Language Class Initialized
INFO - 2020-08-24 23:26:27 --> Config Class Initialized
INFO - 2020-08-24 23:26:27 --> Loader Class Initialized
INFO - 2020-08-24 23:26:27 --> Helper loaded: url_helper
INFO - 2020-08-24 23:26:27 --> Helper loaded: form_helper
INFO - 2020-08-24 23:26:27 --> Helper loaded: file_helper
INFO - 2020-08-24 23:26:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 23:26:27 --> Database Driver Class Initialized
DEBUG - 2020-08-24 23:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 23:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 23:26:27 --> Upload Class Initialized
INFO - 2020-08-24 23:26:27 --> Controller Class Initialized
ERROR - 2020-08-24 23:26:27 --> 404 Page Not Found: /index
INFO - 2020-08-24 23:26:27 --> Config Class Initialized
INFO - 2020-08-24 23:26:27 --> Hooks Class Initialized
DEBUG - 2020-08-24 23:26:27 --> UTF-8 Support Enabled
INFO - 2020-08-24 23:26:27 --> Utf8 Class Initialized
INFO - 2020-08-24 23:26:27 --> URI Class Initialized
INFO - 2020-08-24 23:26:27 --> Router Class Initialized
INFO - 2020-08-24 23:26:27 --> Output Class Initialized
INFO - 2020-08-24 23:26:27 --> Security Class Initialized
DEBUG - 2020-08-24 23:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 23:26:27 --> Input Class Initialized
INFO - 2020-08-24 23:26:27 --> Language Class Initialized
INFO - 2020-08-24 23:26:27 --> Language Class Initialized
INFO - 2020-08-24 23:26:27 --> Config Class Initialized
INFO - 2020-08-24 23:26:27 --> Loader Class Initialized
INFO - 2020-08-24 23:26:27 --> Helper loaded: url_helper
INFO - 2020-08-24 23:26:27 --> Helper loaded: form_helper
INFO - 2020-08-24 23:26:27 --> Helper loaded: file_helper
INFO - 2020-08-24 23:26:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 23:26:27 --> Database Driver Class Initialized
DEBUG - 2020-08-24 23:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 23:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 23:26:27 --> Upload Class Initialized
INFO - 2020-08-24 23:26:27 --> Controller Class Initialized
DEBUG - 2020-08-24 23:26:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 23:26:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-24 23:26:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 23:26:27 --> Final output sent to browser
DEBUG - 2020-08-24 23:26:27 --> Total execution time: 0.0608
INFO - 2020-08-24 23:42:25 --> Config Class Initialized
INFO - 2020-08-24 23:42:25 --> Hooks Class Initialized
DEBUG - 2020-08-24 23:42:25 --> UTF-8 Support Enabled
INFO - 2020-08-24 23:42:25 --> Utf8 Class Initialized
INFO - 2020-08-24 23:42:25 --> URI Class Initialized
DEBUG - 2020-08-24 23:42:25 --> No URI present. Default controller set.
INFO - 2020-08-24 23:42:25 --> Router Class Initialized
INFO - 2020-08-24 23:42:25 --> Output Class Initialized
INFO - 2020-08-24 23:42:25 --> Security Class Initialized
DEBUG - 2020-08-24 23:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 23:42:25 --> Input Class Initialized
INFO - 2020-08-24 23:42:25 --> Language Class Initialized
INFO - 2020-08-24 23:42:25 --> Language Class Initialized
INFO - 2020-08-24 23:42:25 --> Config Class Initialized
INFO - 2020-08-24 23:42:25 --> Loader Class Initialized
INFO - 2020-08-24 23:42:25 --> Helper loaded: url_helper
INFO - 2020-08-24 23:42:25 --> Helper loaded: form_helper
INFO - 2020-08-24 23:42:25 --> Helper loaded: file_helper
INFO - 2020-08-24 23:42:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 23:42:25 --> Database Driver Class Initialized
DEBUG - 2020-08-24 23:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 23:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 23:42:25 --> Upload Class Initialized
INFO - 2020-08-24 23:42:25 --> Controller Class Initialized
DEBUG - 2020-08-24 23:42:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 23:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 23:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 23:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 23:42:25 --> Final output sent to browser
DEBUG - 2020-08-24 23:42:25 --> Total execution time: 0.0492
INFO - 2020-08-24 23:50:16 --> Config Class Initialized
INFO - 2020-08-24 23:50:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 23:50:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 23:50:16 --> Utf8 Class Initialized
INFO - 2020-08-24 23:50:16 --> URI Class Initialized
DEBUG - 2020-08-24 23:50:16 --> No URI present. Default controller set.
INFO - 2020-08-24 23:50:16 --> Router Class Initialized
INFO - 2020-08-24 23:50:16 --> Output Class Initialized
INFO - 2020-08-24 23:50:16 --> Security Class Initialized
DEBUG - 2020-08-24 23:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 23:50:16 --> Input Class Initialized
INFO - 2020-08-24 23:50:16 --> Language Class Initialized
INFO - 2020-08-24 23:50:16 --> Language Class Initialized
INFO - 2020-08-24 23:50:16 --> Config Class Initialized
INFO - 2020-08-24 23:50:16 --> Loader Class Initialized
INFO - 2020-08-24 23:50:16 --> Helper loaded: url_helper
INFO - 2020-08-24 23:50:16 --> Helper loaded: form_helper
INFO - 2020-08-24 23:50:16 --> Helper loaded: file_helper
INFO - 2020-08-24 23:50:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 23:50:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 23:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 23:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 23:50:16 --> Upload Class Initialized
INFO - 2020-08-24 23:50:16 --> Controller Class Initialized
DEBUG - 2020-08-24 23:50:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 23:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 23:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 23:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 23:50:16 --> Final output sent to browser
DEBUG - 2020-08-24 23:50:16 --> Total execution time: 0.0517
INFO - 2020-08-24 23:50:16 --> Config Class Initialized
INFO - 2020-08-24 23:50:16 --> Hooks Class Initialized
DEBUG - 2020-08-24 23:50:16 --> UTF-8 Support Enabled
INFO - 2020-08-24 23:50:16 --> Utf8 Class Initialized
INFO - 2020-08-24 23:50:16 --> URI Class Initialized
DEBUG - 2020-08-24 23:50:16 --> No URI present. Default controller set.
INFO - 2020-08-24 23:50:16 --> Router Class Initialized
INFO - 2020-08-24 23:50:16 --> Output Class Initialized
INFO - 2020-08-24 23:50:16 --> Security Class Initialized
DEBUG - 2020-08-24 23:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 23:50:16 --> Input Class Initialized
INFO - 2020-08-24 23:50:16 --> Language Class Initialized
INFO - 2020-08-24 23:50:16 --> Language Class Initialized
INFO - 2020-08-24 23:50:16 --> Config Class Initialized
INFO - 2020-08-24 23:50:16 --> Loader Class Initialized
INFO - 2020-08-24 23:50:16 --> Helper loaded: url_helper
INFO - 2020-08-24 23:50:16 --> Helper loaded: form_helper
INFO - 2020-08-24 23:50:16 --> Helper loaded: file_helper
INFO - 2020-08-24 23:50:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-24 23:50:16 --> Database Driver Class Initialized
DEBUG - 2020-08-24 23:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-24 23:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 23:50:16 --> Upload Class Initialized
INFO - 2020-08-24 23:50:16 --> Controller Class Initialized
DEBUG - 2020-08-24 23:50:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-24 23:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-24 23:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-24 23:50:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-24 23:50:16 --> Final output sent to browser
DEBUG - 2020-08-24 23:50:16 --> Total execution time: 0.0488
