<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-25 01:41:00 --> Config Class Initialized
INFO - 2020-08-25 01:41:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 01:41:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 01:41:00 --> Utf8 Class Initialized
INFO - 2020-08-25 01:41:00 --> URI Class Initialized
DEBUG - 2020-08-25 01:41:00 --> No URI present. Default controller set.
INFO - 2020-08-25 01:41:00 --> Router Class Initialized
INFO - 2020-08-25 01:41:00 --> Output Class Initialized
INFO - 2020-08-25 01:41:00 --> Security Class Initialized
DEBUG - 2020-08-25 01:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 01:41:00 --> Input Class Initialized
INFO - 2020-08-25 01:41:00 --> Language Class Initialized
INFO - 2020-08-25 01:41:00 --> Language Class Initialized
INFO - 2020-08-25 01:41:00 --> Config Class Initialized
INFO - 2020-08-25 01:41:00 --> Loader Class Initialized
INFO - 2020-08-25 01:41:00 --> Helper loaded: url_helper
INFO - 2020-08-25 01:41:00 --> Helper loaded: form_helper
INFO - 2020-08-25 01:41:00 --> Helper loaded: file_helper
INFO - 2020-08-25 01:41:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 01:41:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 01:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 01:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 01:41:00 --> Upload Class Initialized
INFO - 2020-08-25 01:41:00 --> Controller Class Initialized
DEBUG - 2020-08-25 01:41:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 01:41:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 01:41:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 01:41:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 01:41:00 --> Final output sent to browser
DEBUG - 2020-08-25 01:41:00 --> Total execution time: 0.0539
INFO - 2020-08-25 01:52:21 --> Config Class Initialized
INFO - 2020-08-25 01:52:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 01:52:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 01:52:21 --> Utf8 Class Initialized
INFO - 2020-08-25 01:52:21 --> URI Class Initialized
DEBUG - 2020-08-25 01:52:21 --> No URI present. Default controller set.
INFO - 2020-08-25 01:52:21 --> Router Class Initialized
INFO - 2020-08-25 01:52:21 --> Output Class Initialized
INFO - 2020-08-25 01:52:21 --> Security Class Initialized
DEBUG - 2020-08-25 01:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 01:52:21 --> Input Class Initialized
INFO - 2020-08-25 01:52:21 --> Language Class Initialized
INFO - 2020-08-25 01:52:21 --> Language Class Initialized
INFO - 2020-08-25 01:52:21 --> Config Class Initialized
INFO - 2020-08-25 01:52:21 --> Loader Class Initialized
INFO - 2020-08-25 01:52:21 --> Helper loaded: url_helper
INFO - 2020-08-25 01:52:21 --> Helper loaded: form_helper
INFO - 2020-08-25 01:52:21 --> Helper loaded: file_helper
INFO - 2020-08-25 01:52:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 01:52:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 01:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 01:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 01:52:21 --> Upload Class Initialized
INFO - 2020-08-25 01:52:21 --> Controller Class Initialized
DEBUG - 2020-08-25 01:52:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 01:52:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 01:52:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 01:52:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 01:52:21 --> Final output sent to browser
DEBUG - 2020-08-25 01:52:21 --> Total execution time: 0.0526
INFO - 2020-08-25 02:22:29 --> Config Class Initialized
INFO - 2020-08-25 02:22:29 --> Hooks Class Initialized
DEBUG - 2020-08-25 02:22:29 --> UTF-8 Support Enabled
INFO - 2020-08-25 02:22:29 --> Utf8 Class Initialized
INFO - 2020-08-25 02:22:29 --> URI Class Initialized
INFO - 2020-08-25 02:22:29 --> Router Class Initialized
INFO - 2020-08-25 02:22:29 --> Output Class Initialized
INFO - 2020-08-25 02:22:29 --> Security Class Initialized
DEBUG - 2020-08-25 02:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 02:22:29 --> Input Class Initialized
INFO - 2020-08-25 02:22:29 --> Language Class Initialized
INFO - 2020-08-25 02:22:29 --> Language Class Initialized
INFO - 2020-08-25 02:22:29 --> Config Class Initialized
INFO - 2020-08-25 02:22:29 --> Loader Class Initialized
INFO - 2020-08-25 02:22:29 --> Helper loaded: url_helper
INFO - 2020-08-25 02:22:29 --> Helper loaded: form_helper
INFO - 2020-08-25 02:22:29 --> Helper loaded: file_helper
INFO - 2020-08-25 02:22:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 02:22:29 --> Database Driver Class Initialized
DEBUG - 2020-08-25 02:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 02:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 02:22:29 --> Upload Class Initialized
INFO - 2020-08-25 02:22:29 --> Controller Class Initialized
ERROR - 2020-08-25 02:22:29 --> 404 Page Not Found: /index
INFO - 2020-08-25 03:04:43 --> Config Class Initialized
INFO - 2020-08-25 03:04:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:04:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:04:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:04:43 --> URI Class Initialized
INFO - 2020-08-25 03:04:43 --> Router Class Initialized
INFO - 2020-08-25 03:04:43 --> Output Class Initialized
INFO - 2020-08-25 03:04:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:04:43 --> Input Class Initialized
INFO - 2020-08-25 03:04:43 --> Language Class Initialized
INFO - 2020-08-25 03:04:43 --> Language Class Initialized
INFO - 2020-08-25 03:04:43 --> Config Class Initialized
INFO - 2020-08-25 03:04:43 --> Loader Class Initialized
INFO - 2020-08-25 03:04:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:04:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:04:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:04:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 03:04:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:04:43 --> Upload Class Initialized
INFO - 2020-08-25 03:04:43 --> Controller Class Initialized
ERROR - 2020-08-25 03:04:43 --> 404 Page Not Found: /index
INFO - 2020-08-25 04:57:03 --> Config Class Initialized
INFO - 2020-08-25 04:57:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:57:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:57:03 --> Utf8 Class Initialized
INFO - 2020-08-25 04:57:03 --> URI Class Initialized
INFO - 2020-08-25 04:57:03 --> Router Class Initialized
INFO - 2020-08-25 04:57:03 --> Output Class Initialized
INFO - 2020-08-25 04:57:03 --> Security Class Initialized
DEBUG - 2020-08-25 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:57:03 --> Input Class Initialized
INFO - 2020-08-25 04:57:03 --> Language Class Initialized
INFO - 2020-08-25 04:57:03 --> Language Class Initialized
INFO - 2020-08-25 04:57:03 --> Config Class Initialized
INFO - 2020-08-25 04:57:03 --> Loader Class Initialized
INFO - 2020-08-25 04:57:03 --> Helper loaded: url_helper
INFO - 2020-08-25 04:57:03 --> Helper loaded: form_helper
INFO - 2020-08-25 04:57:03 --> Helper loaded: file_helper
INFO - 2020-08-25 04:57:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 04:57:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:57:03 --> Upload Class Initialized
INFO - 2020-08-25 04:57:03 --> Controller Class Initialized
ERROR - 2020-08-25 04:57:03 --> 404 Page Not Found: /index
INFO - 2020-08-25 04:57:04 --> Config Class Initialized
INFO - 2020-08-25 04:57:04 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:57:04 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:57:04 --> Utf8 Class Initialized
INFO - 2020-08-25 04:57:04 --> URI Class Initialized
DEBUG - 2020-08-25 04:57:04 --> No URI present. Default controller set.
INFO - 2020-08-25 04:57:04 --> Router Class Initialized
INFO - 2020-08-25 04:57:04 --> Output Class Initialized
INFO - 2020-08-25 04:57:04 --> Security Class Initialized
DEBUG - 2020-08-25 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:57:04 --> Input Class Initialized
INFO - 2020-08-25 04:57:04 --> Language Class Initialized
INFO - 2020-08-25 04:57:04 --> Language Class Initialized
INFO - 2020-08-25 04:57:04 --> Config Class Initialized
INFO - 2020-08-25 04:57:04 --> Loader Class Initialized
INFO - 2020-08-25 04:57:04 --> Helper loaded: url_helper
INFO - 2020-08-25 04:57:04 --> Helper loaded: form_helper
INFO - 2020-08-25 04:57:04 --> Helper loaded: file_helper
INFO - 2020-08-25 04:57:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 04:57:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:57:04 --> Upload Class Initialized
INFO - 2020-08-25 04:57:04 --> Controller Class Initialized
DEBUG - 2020-08-25 04:57:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 04:57:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 04:57:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 04:57:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 04:57:04 --> Final output sent to browser
DEBUG - 2020-08-25 04:57:04 --> Total execution time: 0.0772
INFO - 2020-08-25 05:29:29 --> Config Class Initialized
INFO - 2020-08-25 05:29:29 --> Hooks Class Initialized
DEBUG - 2020-08-25 05:29:29 --> UTF-8 Support Enabled
INFO - 2020-08-25 05:29:29 --> Utf8 Class Initialized
INFO - 2020-08-25 05:29:29 --> URI Class Initialized
INFO - 2020-08-25 05:29:29 --> Router Class Initialized
INFO - 2020-08-25 05:29:29 --> Output Class Initialized
INFO - 2020-08-25 05:29:29 --> Security Class Initialized
DEBUG - 2020-08-25 05:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 05:29:29 --> Input Class Initialized
INFO - 2020-08-25 05:29:29 --> Language Class Initialized
INFO - 2020-08-25 05:29:29 --> Language Class Initialized
INFO - 2020-08-25 05:29:29 --> Config Class Initialized
INFO - 2020-08-25 05:29:29 --> Loader Class Initialized
INFO - 2020-08-25 05:29:29 --> Helper loaded: url_helper
INFO - 2020-08-25 05:29:29 --> Helper loaded: form_helper
INFO - 2020-08-25 05:29:29 --> Helper loaded: file_helper
INFO - 2020-08-25 05:29:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 05:29:29 --> Database Driver Class Initialized
DEBUG - 2020-08-25 05:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 05:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 05:29:29 --> Upload Class Initialized
INFO - 2020-08-25 05:29:29 --> Controller Class Initialized
ERROR - 2020-08-25 05:29:29 --> 404 Page Not Found: /index
INFO - 2020-08-25 07:37:13 --> Config Class Initialized
INFO - 2020-08-25 07:37:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 07:37:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 07:37:13 --> Utf8 Class Initialized
INFO - 2020-08-25 07:37:13 --> URI Class Initialized
INFO - 2020-08-25 07:37:13 --> Router Class Initialized
INFO - 2020-08-25 07:37:13 --> Output Class Initialized
INFO - 2020-08-25 07:37:13 --> Security Class Initialized
DEBUG - 2020-08-25 07:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 07:37:13 --> Input Class Initialized
INFO - 2020-08-25 07:37:13 --> Language Class Initialized
INFO - 2020-08-25 07:37:13 --> Language Class Initialized
INFO - 2020-08-25 07:37:13 --> Config Class Initialized
INFO - 2020-08-25 07:37:13 --> Loader Class Initialized
INFO - 2020-08-25 07:37:13 --> Helper loaded: url_helper
INFO - 2020-08-25 07:37:13 --> Helper loaded: form_helper
INFO - 2020-08-25 07:37:13 --> Helper loaded: file_helper
INFO - 2020-08-25 07:37:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 07:37:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 07:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 07:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 07:37:13 --> Upload Class Initialized
INFO - 2020-08-25 07:37:13 --> Controller Class Initialized
ERROR - 2020-08-25 07:37:13 --> 404 Page Not Found: /index
INFO - 2020-08-25 07:37:53 --> Config Class Initialized
INFO - 2020-08-25 07:37:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 07:37:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 07:37:53 --> Utf8 Class Initialized
INFO - 2020-08-25 07:37:53 --> URI Class Initialized
INFO - 2020-08-25 07:37:53 --> Router Class Initialized
INFO - 2020-08-25 07:37:53 --> Output Class Initialized
INFO - 2020-08-25 07:37:53 --> Security Class Initialized
DEBUG - 2020-08-25 07:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 07:37:53 --> Input Class Initialized
INFO - 2020-08-25 07:37:53 --> Language Class Initialized
INFO - 2020-08-25 07:37:53 --> Language Class Initialized
INFO - 2020-08-25 07:37:53 --> Config Class Initialized
INFO - 2020-08-25 07:37:53 --> Loader Class Initialized
INFO - 2020-08-25 07:37:53 --> Helper loaded: url_helper
INFO - 2020-08-25 07:37:53 --> Helper loaded: form_helper
INFO - 2020-08-25 07:37:53 --> Helper loaded: file_helper
INFO - 2020-08-25 07:37:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 07:37:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 07:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 07:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 07:37:53 --> Upload Class Initialized
INFO - 2020-08-25 07:37:53 --> Controller Class Initialized
ERROR - 2020-08-25 07:37:53 --> 404 Page Not Found: /index
INFO - 2020-08-25 09:09:22 --> Config Class Initialized
INFO - 2020-08-25 09:09:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 09:09:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 09:09:22 --> Utf8 Class Initialized
INFO - 2020-08-25 09:09:22 --> URI Class Initialized
INFO - 2020-08-25 09:09:22 --> Router Class Initialized
INFO - 2020-08-25 09:09:22 --> Output Class Initialized
INFO - 2020-08-25 09:09:22 --> Security Class Initialized
DEBUG - 2020-08-25 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 09:09:22 --> Input Class Initialized
INFO - 2020-08-25 09:09:22 --> Language Class Initialized
INFO - 2020-08-25 09:09:22 --> Language Class Initialized
INFO - 2020-08-25 09:09:22 --> Config Class Initialized
INFO - 2020-08-25 09:09:22 --> Loader Class Initialized
INFO - 2020-08-25 09:09:22 --> Helper loaded: url_helper
INFO - 2020-08-25 09:09:22 --> Helper loaded: form_helper
INFO - 2020-08-25 09:09:22 --> Helper loaded: file_helper
INFO - 2020-08-25 09:09:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 09:09:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 09:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 09:09:22 --> Upload Class Initialized
INFO - 2020-08-25 09:09:22 --> Controller Class Initialized
DEBUG - 2020-08-25 09:09:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 09:09:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-25 09:09:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 09:09:22 --> Final output sent to browser
DEBUG - 2020-08-25 09:09:22 --> Total execution time: 0.1722
INFO - 2020-08-25 09:09:23 --> Config Class Initialized
INFO - 2020-08-25 09:09:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 09:09:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 09:09:23 --> Utf8 Class Initialized
INFO - 2020-08-25 09:09:23 --> URI Class Initialized
INFO - 2020-08-25 09:09:23 --> Router Class Initialized
INFO - 2020-08-25 09:09:23 --> Output Class Initialized
INFO - 2020-08-25 09:09:23 --> Security Class Initialized
DEBUG - 2020-08-25 09:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 09:09:23 --> Input Class Initialized
INFO - 2020-08-25 09:09:23 --> Language Class Initialized
INFO - 2020-08-25 09:09:23 --> Language Class Initialized
INFO - 2020-08-25 09:09:23 --> Config Class Initialized
INFO - 2020-08-25 09:09:23 --> Loader Class Initialized
INFO - 2020-08-25 09:09:23 --> Helper loaded: url_helper
INFO - 2020-08-25 09:09:23 --> Helper loaded: form_helper
INFO - 2020-08-25 09:09:23 --> Helper loaded: file_helper
INFO - 2020-08-25 09:09:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 09:09:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 09:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 09:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 09:09:23 --> Upload Class Initialized
INFO - 2020-08-25 09:09:23 --> Controller Class Initialized
ERROR - 2020-08-25 09:09:23 --> 404 Page Not Found: /index
INFO - 2020-08-25 09:35:37 --> Config Class Initialized
INFO - 2020-08-25 09:35:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 09:35:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 09:35:37 --> Utf8 Class Initialized
INFO - 2020-08-25 09:35:37 --> URI Class Initialized
DEBUG - 2020-08-25 09:35:37 --> No URI present. Default controller set.
INFO - 2020-08-25 09:35:37 --> Router Class Initialized
INFO - 2020-08-25 09:35:37 --> Output Class Initialized
INFO - 2020-08-25 09:35:37 --> Security Class Initialized
DEBUG - 2020-08-25 09:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 09:35:37 --> Input Class Initialized
INFO - 2020-08-25 09:35:37 --> Language Class Initialized
INFO - 2020-08-25 09:35:37 --> Language Class Initialized
INFO - 2020-08-25 09:35:37 --> Config Class Initialized
INFO - 2020-08-25 09:35:37 --> Loader Class Initialized
INFO - 2020-08-25 09:35:37 --> Helper loaded: url_helper
INFO - 2020-08-25 09:35:37 --> Helper loaded: form_helper
INFO - 2020-08-25 09:35:37 --> Helper loaded: file_helper
INFO - 2020-08-25 09:35:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 09:35:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 09:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 09:35:37 --> Upload Class Initialized
INFO - 2020-08-25 09:35:37 --> Controller Class Initialized
DEBUG - 2020-08-25 09:35:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 09:35:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 09:35:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 09:35:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 09:35:37 --> Final output sent to browser
DEBUG - 2020-08-25 09:35:37 --> Total execution time: 0.0883
INFO - 2020-08-25 09:52:56 --> Config Class Initialized
INFO - 2020-08-25 09:52:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 09:52:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 09:52:56 --> Utf8 Class Initialized
INFO - 2020-08-25 09:52:56 --> URI Class Initialized
INFO - 2020-08-25 09:52:56 --> Router Class Initialized
INFO - 2020-08-25 09:52:56 --> Output Class Initialized
INFO - 2020-08-25 09:52:56 --> Security Class Initialized
DEBUG - 2020-08-25 09:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 09:52:56 --> Input Class Initialized
INFO - 2020-08-25 09:52:56 --> Language Class Initialized
INFO - 2020-08-25 09:52:56 --> Language Class Initialized
INFO - 2020-08-25 09:52:56 --> Config Class Initialized
INFO - 2020-08-25 09:52:56 --> Loader Class Initialized
INFO - 2020-08-25 09:52:56 --> Helper loaded: url_helper
INFO - 2020-08-25 09:52:56 --> Helper loaded: form_helper
INFO - 2020-08-25 09:52:56 --> Helper loaded: file_helper
INFO - 2020-08-25 09:52:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 09:52:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 09:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 09:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 09:52:56 --> Upload Class Initialized
INFO - 2020-08-25 09:52:56 --> Controller Class Initialized
ERROR - 2020-08-25 09:52:56 --> 404 Page Not Found: /index
INFO - 2020-08-25 09:52:57 --> Config Class Initialized
INFO - 2020-08-25 09:52:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 09:52:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 09:52:57 --> Utf8 Class Initialized
INFO - 2020-08-25 09:52:57 --> URI Class Initialized
INFO - 2020-08-25 09:52:57 --> Router Class Initialized
INFO - 2020-08-25 09:52:57 --> Output Class Initialized
INFO - 2020-08-25 09:52:57 --> Security Class Initialized
DEBUG - 2020-08-25 09:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 09:52:57 --> Input Class Initialized
INFO - 2020-08-25 09:52:57 --> Language Class Initialized
INFO - 2020-08-25 09:52:57 --> Language Class Initialized
INFO - 2020-08-25 09:52:57 --> Config Class Initialized
INFO - 2020-08-25 09:52:57 --> Loader Class Initialized
INFO - 2020-08-25 09:52:57 --> Helper loaded: url_helper
INFO - 2020-08-25 09:52:57 --> Helper loaded: form_helper
INFO - 2020-08-25 09:52:57 --> Helper loaded: file_helper
INFO - 2020-08-25 09:52:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 09:52:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 09:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 09:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 09:52:57 --> Upload Class Initialized
INFO - 2020-08-25 09:52:57 --> Controller Class Initialized
DEBUG - 2020-08-25 09:52:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 09:52:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-25 09:52:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 09:52:57 --> Final output sent to browser
DEBUG - 2020-08-25 09:52:57 --> Total execution time: 0.0510
INFO - 2020-08-25 10:45:09 --> Config Class Initialized
INFO - 2020-08-25 10:45:09 --> Hooks Class Initialized
DEBUG - 2020-08-25 10:45:09 --> UTF-8 Support Enabled
INFO - 2020-08-25 10:45:09 --> Utf8 Class Initialized
INFO - 2020-08-25 10:45:09 --> URI Class Initialized
DEBUG - 2020-08-25 10:45:09 --> No URI present. Default controller set.
INFO - 2020-08-25 10:45:09 --> Router Class Initialized
INFO - 2020-08-25 10:45:09 --> Output Class Initialized
INFO - 2020-08-25 10:45:09 --> Security Class Initialized
DEBUG - 2020-08-25 10:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 10:45:09 --> Input Class Initialized
INFO - 2020-08-25 10:45:09 --> Language Class Initialized
INFO - 2020-08-25 10:45:09 --> Language Class Initialized
INFO - 2020-08-25 10:45:09 --> Config Class Initialized
INFO - 2020-08-25 10:45:09 --> Loader Class Initialized
INFO - 2020-08-25 10:45:09 --> Helper loaded: url_helper
INFO - 2020-08-25 10:45:09 --> Helper loaded: form_helper
INFO - 2020-08-25 10:45:09 --> Helper loaded: file_helper
INFO - 2020-08-25 10:45:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 10:45:09 --> Database Driver Class Initialized
DEBUG - 2020-08-25 10:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 10:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 10:45:09 --> Upload Class Initialized
INFO - 2020-08-25 10:45:09 --> Controller Class Initialized
DEBUG - 2020-08-25 10:45:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 10:45:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 10:45:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 10:45:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 10:45:09 --> Final output sent to browser
DEBUG - 2020-08-25 10:45:09 --> Total execution time: 0.0546
INFO - 2020-08-25 10:54:19 --> Config Class Initialized
INFO - 2020-08-25 10:54:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 10:54:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 10:54:19 --> Utf8 Class Initialized
INFO - 2020-08-25 10:54:19 --> URI Class Initialized
DEBUG - 2020-08-25 10:54:19 --> No URI present. Default controller set.
INFO - 2020-08-25 10:54:19 --> Router Class Initialized
INFO - 2020-08-25 10:54:19 --> Output Class Initialized
INFO - 2020-08-25 10:54:19 --> Security Class Initialized
DEBUG - 2020-08-25 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 10:54:19 --> Input Class Initialized
INFO - 2020-08-25 10:54:19 --> Language Class Initialized
INFO - 2020-08-25 10:54:19 --> Language Class Initialized
INFO - 2020-08-25 10:54:19 --> Config Class Initialized
INFO - 2020-08-25 10:54:19 --> Loader Class Initialized
INFO - 2020-08-25 10:54:19 --> Helper loaded: url_helper
INFO - 2020-08-25 10:54:19 --> Helper loaded: form_helper
INFO - 2020-08-25 10:54:19 --> Helper loaded: file_helper
INFO - 2020-08-25 10:54:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 10:54:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 10:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 10:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 10:54:19 --> Upload Class Initialized
INFO - 2020-08-25 10:54:19 --> Controller Class Initialized
DEBUG - 2020-08-25 10:54:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 10:54:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 10:54:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 10:54:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 10:54:19 --> Final output sent to browser
DEBUG - 2020-08-25 10:54:19 --> Total execution time: 0.0514
INFO - 2020-08-25 11:30:00 --> Config Class Initialized
INFO - 2020-08-25 11:30:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 11:30:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 11:30:00 --> Utf8 Class Initialized
INFO - 2020-08-25 11:30:00 --> URI Class Initialized
DEBUG - 2020-08-25 11:30:00 --> No URI present. Default controller set.
INFO - 2020-08-25 11:30:00 --> Router Class Initialized
INFO - 2020-08-25 11:30:00 --> Output Class Initialized
INFO - 2020-08-25 11:30:00 --> Security Class Initialized
DEBUG - 2020-08-25 11:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 11:30:00 --> Input Class Initialized
INFO - 2020-08-25 11:30:00 --> Language Class Initialized
INFO - 2020-08-25 11:30:00 --> Language Class Initialized
INFO - 2020-08-25 11:30:00 --> Config Class Initialized
INFO - 2020-08-25 11:30:00 --> Loader Class Initialized
INFO - 2020-08-25 11:30:00 --> Helper loaded: url_helper
INFO - 2020-08-25 11:30:00 --> Helper loaded: form_helper
INFO - 2020-08-25 11:30:00 --> Helper loaded: file_helper
INFO - 2020-08-25 11:30:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 11:30:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 11:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 11:30:00 --> Upload Class Initialized
INFO - 2020-08-25 11:30:00 --> Controller Class Initialized
DEBUG - 2020-08-25 11:30:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 11:30:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 11:30:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 11:30:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 11:30:00 --> Final output sent to browser
DEBUG - 2020-08-25 11:30:00 --> Total execution time: 0.0682
INFO - 2020-08-25 11:30:08 --> Config Class Initialized
INFO - 2020-08-25 11:30:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 11:30:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 11:30:08 --> Utf8 Class Initialized
INFO - 2020-08-25 11:30:08 --> URI Class Initialized
DEBUG - 2020-08-25 11:30:08 --> No URI present. Default controller set.
INFO - 2020-08-25 11:30:08 --> Router Class Initialized
INFO - 2020-08-25 11:30:08 --> Output Class Initialized
INFO - 2020-08-25 11:30:08 --> Security Class Initialized
DEBUG - 2020-08-25 11:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 11:30:08 --> Input Class Initialized
INFO - 2020-08-25 11:30:08 --> Language Class Initialized
INFO - 2020-08-25 11:30:08 --> Language Class Initialized
INFO - 2020-08-25 11:30:08 --> Config Class Initialized
INFO - 2020-08-25 11:30:08 --> Loader Class Initialized
INFO - 2020-08-25 11:30:08 --> Helper loaded: url_helper
INFO - 2020-08-25 11:30:08 --> Helper loaded: form_helper
INFO - 2020-08-25 11:30:08 --> Helper loaded: file_helper
INFO - 2020-08-25 11:30:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 11:30:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 11:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 11:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 11:30:08 --> Upload Class Initialized
INFO - 2020-08-25 11:30:08 --> Controller Class Initialized
DEBUG - 2020-08-25 11:30:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 11:30:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 11:30:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 11:30:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 11:30:08 --> Final output sent to browser
DEBUG - 2020-08-25 11:30:08 --> Total execution time: 0.0907
INFO - 2020-08-25 11:30:10 --> Config Class Initialized
INFO - 2020-08-25 11:30:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 11:30:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 11:30:10 --> Utf8 Class Initialized
INFO - 2020-08-25 11:30:10 --> URI Class Initialized
INFO - 2020-08-25 11:30:10 --> Router Class Initialized
INFO - 2020-08-25 11:30:10 --> Output Class Initialized
INFO - 2020-08-25 11:30:10 --> Security Class Initialized
DEBUG - 2020-08-25 11:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 11:30:10 --> Input Class Initialized
INFO - 2020-08-25 11:30:10 --> Language Class Initialized
INFO - 2020-08-25 11:30:10 --> Language Class Initialized
INFO - 2020-08-25 11:30:10 --> Config Class Initialized
INFO - 2020-08-25 11:30:10 --> Loader Class Initialized
INFO - 2020-08-25 11:30:10 --> Helper loaded: url_helper
INFO - 2020-08-25 11:30:10 --> Helper loaded: form_helper
INFO - 2020-08-25 11:30:10 --> Helper loaded: file_helper
INFO - 2020-08-25 11:30:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 11:30:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 11:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 11:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 11:30:10 --> Upload Class Initialized
INFO - 2020-08-25 11:30:10 --> Controller Class Initialized
ERROR - 2020-08-25 11:30:10 --> 404 Page Not Found: /index
INFO - 2020-08-25 12:35:20 --> Config Class Initialized
INFO - 2020-08-25 12:35:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 12:35:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 12:35:20 --> Utf8 Class Initialized
INFO - 2020-08-25 12:35:20 --> URI Class Initialized
DEBUG - 2020-08-25 12:35:20 --> No URI present. Default controller set.
INFO - 2020-08-25 12:35:20 --> Router Class Initialized
INFO - 2020-08-25 12:35:20 --> Output Class Initialized
INFO - 2020-08-25 12:35:20 --> Security Class Initialized
DEBUG - 2020-08-25 12:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 12:35:20 --> Input Class Initialized
INFO - 2020-08-25 12:35:20 --> Language Class Initialized
INFO - 2020-08-25 12:35:20 --> Language Class Initialized
INFO - 2020-08-25 12:35:20 --> Config Class Initialized
INFO - 2020-08-25 12:35:20 --> Loader Class Initialized
INFO - 2020-08-25 12:35:20 --> Helper loaded: url_helper
INFO - 2020-08-25 12:35:20 --> Helper loaded: form_helper
INFO - 2020-08-25 12:35:20 --> Helper loaded: file_helper
INFO - 2020-08-25 12:35:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 12:35:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 12:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 12:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 12:35:20 --> Upload Class Initialized
INFO - 2020-08-25 12:35:20 --> Controller Class Initialized
DEBUG - 2020-08-25 12:35:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 12:35:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 12:35:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 12:35:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 12:35:20 --> Final output sent to browser
DEBUG - 2020-08-25 12:35:20 --> Total execution time: 0.0577
INFO - 2020-08-25 12:35:21 --> Config Class Initialized
INFO - 2020-08-25 12:35:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 12:35:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 12:35:21 --> Utf8 Class Initialized
INFO - 2020-08-25 12:35:21 --> URI Class Initialized
DEBUG - 2020-08-25 12:35:21 --> No URI present. Default controller set.
INFO - 2020-08-25 12:35:21 --> Router Class Initialized
INFO - 2020-08-25 12:35:21 --> Output Class Initialized
INFO - 2020-08-25 12:35:21 --> Security Class Initialized
DEBUG - 2020-08-25 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 12:35:21 --> Input Class Initialized
INFO - 2020-08-25 12:35:21 --> Language Class Initialized
INFO - 2020-08-25 12:35:21 --> Language Class Initialized
INFO - 2020-08-25 12:35:21 --> Config Class Initialized
INFO - 2020-08-25 12:35:21 --> Loader Class Initialized
INFO - 2020-08-25 12:35:21 --> Helper loaded: url_helper
INFO - 2020-08-25 12:35:21 --> Helper loaded: form_helper
INFO - 2020-08-25 12:35:21 --> Helper loaded: file_helper
INFO - 2020-08-25 12:35:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 12:35:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 12:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 12:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 12:35:21 --> Upload Class Initialized
INFO - 2020-08-25 12:35:21 --> Controller Class Initialized
DEBUG - 2020-08-25 12:35:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 12:35:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 12:35:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 12:35:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 12:35:21 --> Final output sent to browser
DEBUG - 2020-08-25 12:35:21 --> Total execution time: 0.0498
INFO - 2020-08-25 12:35:23 --> Config Class Initialized
INFO - 2020-08-25 12:35:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 12:35:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 12:35:23 --> Utf8 Class Initialized
INFO - 2020-08-25 12:35:23 --> URI Class Initialized
INFO - 2020-08-25 12:35:23 --> Router Class Initialized
INFO - 2020-08-25 12:35:23 --> Output Class Initialized
INFO - 2020-08-25 12:35:23 --> Security Class Initialized
DEBUG - 2020-08-25 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 12:35:23 --> Input Class Initialized
INFO - 2020-08-25 12:35:23 --> Language Class Initialized
INFO - 2020-08-25 12:35:23 --> Language Class Initialized
INFO - 2020-08-25 12:35:23 --> Config Class Initialized
INFO - 2020-08-25 12:35:23 --> Loader Class Initialized
INFO - 2020-08-25 12:35:23 --> Helper loaded: url_helper
INFO - 2020-08-25 12:35:23 --> Helper loaded: form_helper
INFO - 2020-08-25 12:35:23 --> Helper loaded: file_helper
INFO - 2020-08-25 12:35:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 12:35:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 12:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 12:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 12:35:23 --> Upload Class Initialized
INFO - 2020-08-25 12:35:23 --> Controller Class Initialized
ERROR - 2020-08-25 12:35:23 --> 404 Page Not Found: /index
INFO - 2020-08-25 12:42:21 --> Config Class Initialized
INFO - 2020-08-25 12:42:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 12:42:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 12:42:21 --> Utf8 Class Initialized
INFO - 2020-08-25 12:42:21 --> URI Class Initialized
INFO - 2020-08-25 12:42:21 --> Router Class Initialized
INFO - 2020-08-25 12:42:21 --> Output Class Initialized
INFO - 2020-08-25 12:42:21 --> Security Class Initialized
DEBUG - 2020-08-25 12:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 12:42:21 --> Input Class Initialized
INFO - 2020-08-25 12:42:21 --> Language Class Initialized
INFO - 2020-08-25 12:42:21 --> Language Class Initialized
INFO - 2020-08-25 12:42:21 --> Config Class Initialized
INFO - 2020-08-25 12:42:21 --> Loader Class Initialized
INFO - 2020-08-25 12:42:21 --> Helper loaded: url_helper
INFO - 2020-08-25 12:42:21 --> Helper loaded: form_helper
INFO - 2020-08-25 12:42:21 --> Helper loaded: file_helper
INFO - 2020-08-25 12:42:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 12:42:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 12:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 12:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 12:42:21 --> Upload Class Initialized
INFO - 2020-08-25 12:42:21 --> Controller Class Initialized
DEBUG - 2020-08-25 12:42:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 12:42:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-25 12:42:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 12:42:21 --> Final output sent to browser
DEBUG - 2020-08-25 12:42:21 --> Total execution time: 0.0498
INFO - 2020-08-25 12:42:25 --> Config Class Initialized
INFO - 2020-08-25 12:42:25 --> Hooks Class Initialized
DEBUG - 2020-08-25 12:42:25 --> UTF-8 Support Enabled
INFO - 2020-08-25 12:42:25 --> Utf8 Class Initialized
INFO - 2020-08-25 12:42:25 --> URI Class Initialized
INFO - 2020-08-25 12:42:25 --> Router Class Initialized
INFO - 2020-08-25 12:42:25 --> Output Class Initialized
INFO - 2020-08-25 12:42:25 --> Security Class Initialized
DEBUG - 2020-08-25 12:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 12:42:25 --> Input Class Initialized
INFO - 2020-08-25 12:42:25 --> Language Class Initialized
INFO - 2020-08-25 12:42:25 --> Language Class Initialized
INFO - 2020-08-25 12:42:25 --> Config Class Initialized
INFO - 2020-08-25 12:42:25 --> Loader Class Initialized
INFO - 2020-08-25 12:42:25 --> Helper loaded: url_helper
INFO - 2020-08-25 12:42:25 --> Helper loaded: form_helper
INFO - 2020-08-25 12:42:25 --> Helper loaded: file_helper
INFO - 2020-08-25 12:42:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 12:42:25 --> Database Driver Class Initialized
DEBUG - 2020-08-25 12:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 12:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 12:42:25 --> Upload Class Initialized
INFO - 2020-08-25 12:42:25 --> Controller Class Initialized
ERROR - 2020-08-25 12:42:25 --> 404 Page Not Found: /index
INFO - 2020-08-25 12:42:25 --> Config Class Initialized
INFO - 2020-08-25 12:42:25 --> Hooks Class Initialized
DEBUG - 2020-08-25 12:42:25 --> UTF-8 Support Enabled
INFO - 2020-08-25 12:42:25 --> Utf8 Class Initialized
INFO - 2020-08-25 12:42:25 --> URI Class Initialized
DEBUG - 2020-08-25 12:42:25 --> No URI present. Default controller set.
INFO - 2020-08-25 12:42:25 --> Router Class Initialized
INFO - 2020-08-25 12:42:25 --> Output Class Initialized
INFO - 2020-08-25 12:42:25 --> Security Class Initialized
DEBUG - 2020-08-25 12:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 12:42:25 --> Input Class Initialized
INFO - 2020-08-25 12:42:25 --> Language Class Initialized
INFO - 2020-08-25 12:42:25 --> Language Class Initialized
INFO - 2020-08-25 12:42:25 --> Config Class Initialized
INFO - 2020-08-25 12:42:25 --> Loader Class Initialized
INFO - 2020-08-25 12:42:25 --> Helper loaded: url_helper
INFO - 2020-08-25 12:42:25 --> Helper loaded: form_helper
INFO - 2020-08-25 12:42:25 --> Helper loaded: file_helper
INFO - 2020-08-25 12:42:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 12:42:25 --> Database Driver Class Initialized
DEBUG - 2020-08-25 12:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 12:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 12:42:25 --> Upload Class Initialized
INFO - 2020-08-25 12:42:25 --> Controller Class Initialized
DEBUG - 2020-08-25 12:42:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 12:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 12:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 12:42:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 12:42:25 --> Final output sent to browser
DEBUG - 2020-08-25 12:42:25 --> Total execution time: 0.0777
INFO - 2020-08-25 13:43:24 --> Config Class Initialized
INFO - 2020-08-25 13:43:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:43:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:43:24 --> Utf8 Class Initialized
INFO - 2020-08-25 13:43:24 --> URI Class Initialized
DEBUG - 2020-08-25 13:43:24 --> No URI present. Default controller set.
INFO - 2020-08-25 13:43:24 --> Router Class Initialized
INFO - 2020-08-25 13:43:24 --> Output Class Initialized
INFO - 2020-08-25 13:43:24 --> Security Class Initialized
DEBUG - 2020-08-25 13:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:43:24 --> Input Class Initialized
INFO - 2020-08-25 13:43:24 --> Language Class Initialized
INFO - 2020-08-25 13:43:24 --> Language Class Initialized
INFO - 2020-08-25 13:43:24 --> Config Class Initialized
INFO - 2020-08-25 13:43:24 --> Loader Class Initialized
INFO - 2020-08-25 13:43:24 --> Helper loaded: url_helper
INFO - 2020-08-25 13:43:24 --> Helper loaded: form_helper
INFO - 2020-08-25 13:43:24 --> Helper loaded: file_helper
INFO - 2020-08-25 13:43:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:43:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:43:24 --> Upload Class Initialized
INFO - 2020-08-25 13:43:24 --> Controller Class Initialized
DEBUG - 2020-08-25 13:43:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:43:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:43:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:43:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:43:24 --> Final output sent to browser
DEBUG - 2020-08-25 13:43:24 --> Total execution time: 0.0565
INFO - 2020-08-25 13:51:47 --> Config Class Initialized
INFO - 2020-08-25 13:51:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:51:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:51:47 --> Utf8 Class Initialized
INFO - 2020-08-25 13:51:47 --> URI Class Initialized
DEBUG - 2020-08-25 13:51:47 --> No URI present. Default controller set.
INFO - 2020-08-25 13:51:47 --> Router Class Initialized
INFO - 2020-08-25 13:51:47 --> Output Class Initialized
INFO - 2020-08-25 13:51:47 --> Security Class Initialized
DEBUG - 2020-08-25 13:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:51:47 --> Input Class Initialized
INFO - 2020-08-25 13:51:47 --> Language Class Initialized
INFO - 2020-08-25 13:51:47 --> Language Class Initialized
INFO - 2020-08-25 13:51:47 --> Config Class Initialized
INFO - 2020-08-25 13:51:47 --> Loader Class Initialized
INFO - 2020-08-25 13:51:47 --> Helper loaded: url_helper
INFO - 2020-08-25 13:51:47 --> Helper loaded: form_helper
INFO - 2020-08-25 13:51:47 --> Helper loaded: file_helper
INFO - 2020-08-25 13:51:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:51:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:51:47 --> Upload Class Initialized
INFO - 2020-08-25 13:51:48 --> Controller Class Initialized
DEBUG - 2020-08-25 13:51:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:51:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:51:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:51:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:51:48 --> Final output sent to browser
DEBUG - 2020-08-25 13:51:48 --> Total execution time: 0.0502
INFO - 2020-08-25 13:51:51 --> Config Class Initialized
INFO - 2020-08-25 13:51:51 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:51:51 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:51:51 --> Utf8 Class Initialized
INFO - 2020-08-25 13:51:51 --> URI Class Initialized
DEBUG - 2020-08-25 13:51:51 --> No URI present. Default controller set.
INFO - 2020-08-25 13:51:51 --> Router Class Initialized
INFO - 2020-08-25 13:51:51 --> Output Class Initialized
INFO - 2020-08-25 13:51:51 --> Security Class Initialized
DEBUG - 2020-08-25 13:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:51:51 --> Input Class Initialized
INFO - 2020-08-25 13:51:51 --> Language Class Initialized
INFO - 2020-08-25 13:51:51 --> Language Class Initialized
INFO - 2020-08-25 13:51:51 --> Config Class Initialized
INFO - 2020-08-25 13:51:51 --> Loader Class Initialized
INFO - 2020-08-25 13:51:51 --> Helper loaded: url_helper
INFO - 2020-08-25 13:51:51 --> Helper loaded: form_helper
INFO - 2020-08-25 13:51:51 --> Helper loaded: file_helper
INFO - 2020-08-25 13:51:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:51:51 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:51:51 --> Upload Class Initialized
INFO - 2020-08-25 13:51:51 --> Controller Class Initialized
DEBUG - 2020-08-25 13:51:51 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:51:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:51:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:51:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:51:51 --> Final output sent to browser
DEBUG - 2020-08-25 13:51:51 --> Total execution time: 0.0473
INFO - 2020-08-25 13:52:03 --> Config Class Initialized
INFO - 2020-08-25 13:52:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:52:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:52:03 --> Utf8 Class Initialized
INFO - 2020-08-25 13:52:03 --> URI Class Initialized
DEBUG - 2020-08-25 13:52:03 --> No URI present. Default controller set.
INFO - 2020-08-25 13:52:03 --> Router Class Initialized
INFO - 2020-08-25 13:52:03 --> Output Class Initialized
INFO - 2020-08-25 13:52:03 --> Security Class Initialized
DEBUG - 2020-08-25 13:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:52:03 --> Input Class Initialized
INFO - 2020-08-25 13:52:03 --> Language Class Initialized
INFO - 2020-08-25 13:52:03 --> Language Class Initialized
INFO - 2020-08-25 13:52:03 --> Config Class Initialized
INFO - 2020-08-25 13:52:03 --> Loader Class Initialized
INFO - 2020-08-25 13:52:03 --> Helper loaded: url_helper
INFO - 2020-08-25 13:52:03 --> Helper loaded: form_helper
INFO - 2020-08-25 13:52:03 --> Helper loaded: file_helper
INFO - 2020-08-25 13:52:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:52:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:52:03 --> Upload Class Initialized
INFO - 2020-08-25 13:52:03 --> Controller Class Initialized
DEBUG - 2020-08-25 13:52:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:52:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:52:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:52:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:52:03 --> Final output sent to browser
DEBUG - 2020-08-25 13:52:03 --> Total execution time: 0.0559
INFO - 2020-08-25 13:52:11 --> Config Class Initialized
INFO - 2020-08-25 13:52:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:52:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:52:11 --> Utf8 Class Initialized
INFO - 2020-08-25 13:52:11 --> URI Class Initialized
DEBUG - 2020-08-25 13:52:11 --> No URI present. Default controller set.
INFO - 2020-08-25 13:52:11 --> Router Class Initialized
INFO - 2020-08-25 13:52:11 --> Output Class Initialized
INFO - 2020-08-25 13:52:11 --> Security Class Initialized
DEBUG - 2020-08-25 13:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:52:11 --> Input Class Initialized
INFO - 2020-08-25 13:52:11 --> Language Class Initialized
INFO - 2020-08-25 13:52:11 --> Language Class Initialized
INFO - 2020-08-25 13:52:11 --> Config Class Initialized
INFO - 2020-08-25 13:52:11 --> Loader Class Initialized
INFO - 2020-08-25 13:52:11 --> Helper loaded: url_helper
INFO - 2020-08-25 13:52:11 --> Helper loaded: form_helper
INFO - 2020-08-25 13:52:11 --> Helper loaded: file_helper
INFO - 2020-08-25 13:52:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:52:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:52:11 --> Upload Class Initialized
INFO - 2020-08-25 13:52:11 --> Controller Class Initialized
DEBUG - 2020-08-25 13:52:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:52:11 --> Final output sent to browser
DEBUG - 2020-08-25 13:52:11 --> Total execution time: 0.0492
INFO - 2020-08-25 13:52:38 --> Config Class Initialized
INFO - 2020-08-25 13:52:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:52:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:52:38 --> Utf8 Class Initialized
INFO - 2020-08-25 13:52:38 --> URI Class Initialized
DEBUG - 2020-08-25 13:52:38 --> No URI present. Default controller set.
INFO - 2020-08-25 13:52:38 --> Router Class Initialized
INFO - 2020-08-25 13:52:38 --> Output Class Initialized
INFO - 2020-08-25 13:52:38 --> Security Class Initialized
DEBUG - 2020-08-25 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:52:38 --> Input Class Initialized
INFO - 2020-08-25 13:52:38 --> Language Class Initialized
INFO - 2020-08-25 13:52:38 --> Language Class Initialized
INFO - 2020-08-25 13:52:38 --> Config Class Initialized
INFO - 2020-08-25 13:52:38 --> Loader Class Initialized
INFO - 2020-08-25 13:52:38 --> Helper loaded: url_helper
INFO - 2020-08-25 13:52:38 --> Helper loaded: form_helper
INFO - 2020-08-25 13:52:38 --> Helper loaded: file_helper
INFO - 2020-08-25 13:52:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:52:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:52:38 --> Upload Class Initialized
INFO - 2020-08-25 13:52:38 --> Controller Class Initialized
DEBUG - 2020-08-25 13:52:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:52:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:52:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:52:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:52:38 --> Final output sent to browser
DEBUG - 2020-08-25 13:52:38 --> Total execution time: 0.0547
INFO - 2020-08-25 13:52:49 --> Config Class Initialized
INFO - 2020-08-25 13:52:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:52:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:52:49 --> Utf8 Class Initialized
INFO - 2020-08-25 13:52:49 --> URI Class Initialized
DEBUG - 2020-08-25 13:52:49 --> No URI present. Default controller set.
INFO - 2020-08-25 13:52:49 --> Router Class Initialized
INFO - 2020-08-25 13:52:49 --> Output Class Initialized
INFO - 2020-08-25 13:52:49 --> Security Class Initialized
DEBUG - 2020-08-25 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:52:49 --> Input Class Initialized
INFO - 2020-08-25 13:52:49 --> Language Class Initialized
INFO - 2020-08-25 13:52:49 --> Language Class Initialized
INFO - 2020-08-25 13:52:49 --> Config Class Initialized
INFO - 2020-08-25 13:52:49 --> Loader Class Initialized
INFO - 2020-08-25 13:52:49 --> Helper loaded: url_helper
INFO - 2020-08-25 13:52:49 --> Helper loaded: form_helper
INFO - 2020-08-25 13:52:49 --> Helper loaded: file_helper
INFO - 2020-08-25 13:52:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:52:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:52:49 --> Upload Class Initialized
INFO - 2020-08-25 13:52:49 --> Controller Class Initialized
DEBUG - 2020-08-25 13:52:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:52:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:52:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:52:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:52:50 --> Final output sent to browser
DEBUG - 2020-08-25 13:52:50 --> Total execution time: 0.0495
INFO - 2020-08-25 13:58:41 --> Config Class Initialized
INFO - 2020-08-25 13:58:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:58:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:58:41 --> Utf8 Class Initialized
INFO - 2020-08-25 13:58:41 --> URI Class Initialized
DEBUG - 2020-08-25 13:58:41 --> No URI present. Default controller set.
INFO - 2020-08-25 13:58:41 --> Router Class Initialized
INFO - 2020-08-25 13:58:41 --> Output Class Initialized
INFO - 2020-08-25 13:58:41 --> Security Class Initialized
DEBUG - 2020-08-25 13:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:58:41 --> Input Class Initialized
INFO - 2020-08-25 13:58:41 --> Language Class Initialized
INFO - 2020-08-25 13:58:41 --> Language Class Initialized
INFO - 2020-08-25 13:58:41 --> Config Class Initialized
INFO - 2020-08-25 13:58:41 --> Loader Class Initialized
INFO - 2020-08-25 13:58:41 --> Helper loaded: url_helper
INFO - 2020-08-25 13:58:41 --> Helper loaded: form_helper
INFO - 2020-08-25 13:58:41 --> Helper loaded: file_helper
INFO - 2020-08-25 13:58:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:58:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:58:41 --> Upload Class Initialized
INFO - 2020-08-25 13:58:41 --> Controller Class Initialized
DEBUG - 2020-08-25 13:58:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:58:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:58:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:58:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:58:41 --> Final output sent to browser
DEBUG - 2020-08-25 13:58:41 --> Total execution time: 0.0504
INFO - 2020-08-25 13:59:10 --> Config Class Initialized
INFO - 2020-08-25 13:59:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 13:59:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 13:59:10 --> Utf8 Class Initialized
INFO - 2020-08-25 13:59:10 --> URI Class Initialized
DEBUG - 2020-08-25 13:59:10 --> No URI present. Default controller set.
INFO - 2020-08-25 13:59:10 --> Router Class Initialized
INFO - 2020-08-25 13:59:10 --> Output Class Initialized
INFO - 2020-08-25 13:59:10 --> Security Class Initialized
DEBUG - 2020-08-25 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 13:59:10 --> Input Class Initialized
INFO - 2020-08-25 13:59:10 --> Language Class Initialized
INFO - 2020-08-25 13:59:10 --> Language Class Initialized
INFO - 2020-08-25 13:59:10 --> Config Class Initialized
INFO - 2020-08-25 13:59:10 --> Loader Class Initialized
INFO - 2020-08-25 13:59:10 --> Helper loaded: url_helper
INFO - 2020-08-25 13:59:10 --> Helper loaded: form_helper
INFO - 2020-08-25 13:59:10 --> Helper loaded: file_helper
INFO - 2020-08-25 13:59:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 13:59:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 13:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 13:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 13:59:10 --> Upload Class Initialized
INFO - 2020-08-25 13:59:10 --> Controller Class Initialized
DEBUG - 2020-08-25 13:59:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 13:59:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 13:59:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 13:59:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 13:59:10 --> Final output sent to browser
DEBUG - 2020-08-25 13:59:10 --> Total execution time: 0.0492
INFO - 2020-08-25 14:00:09 --> Config Class Initialized
INFO - 2020-08-25 14:00:09 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:00:09 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:00:09 --> Utf8 Class Initialized
INFO - 2020-08-25 14:00:09 --> URI Class Initialized
DEBUG - 2020-08-25 14:00:09 --> No URI present. Default controller set.
INFO - 2020-08-25 14:00:09 --> Router Class Initialized
INFO - 2020-08-25 14:00:09 --> Output Class Initialized
INFO - 2020-08-25 14:00:09 --> Security Class Initialized
DEBUG - 2020-08-25 14:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:00:09 --> Input Class Initialized
INFO - 2020-08-25 14:00:09 --> Language Class Initialized
INFO - 2020-08-25 14:00:09 --> Language Class Initialized
INFO - 2020-08-25 14:00:09 --> Config Class Initialized
INFO - 2020-08-25 14:00:09 --> Loader Class Initialized
INFO - 2020-08-25 14:00:09 --> Helper loaded: url_helper
INFO - 2020-08-25 14:00:09 --> Helper loaded: form_helper
INFO - 2020-08-25 14:00:09 --> Helper loaded: file_helper
INFO - 2020-08-25 14:00:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:00:09 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:00:09 --> Upload Class Initialized
INFO - 2020-08-25 14:00:10 --> Controller Class Initialized
DEBUG - 2020-08-25 14:00:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:00:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:00:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:00:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:00:10 --> Final output sent to browser
DEBUG - 2020-08-25 14:00:10 --> Total execution time: 0.0540
INFO - 2020-08-25 14:00:44 --> Config Class Initialized
INFO - 2020-08-25 14:00:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:00:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:00:44 --> Utf8 Class Initialized
INFO - 2020-08-25 14:00:44 --> URI Class Initialized
DEBUG - 2020-08-25 14:00:44 --> No URI present. Default controller set.
INFO - 2020-08-25 14:00:44 --> Router Class Initialized
INFO - 2020-08-25 14:00:44 --> Output Class Initialized
INFO - 2020-08-25 14:00:44 --> Security Class Initialized
DEBUG - 2020-08-25 14:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:00:44 --> Input Class Initialized
INFO - 2020-08-25 14:00:44 --> Language Class Initialized
INFO - 2020-08-25 14:00:44 --> Language Class Initialized
INFO - 2020-08-25 14:00:44 --> Config Class Initialized
INFO - 2020-08-25 14:00:44 --> Loader Class Initialized
INFO - 2020-08-25 14:00:44 --> Helper loaded: url_helper
INFO - 2020-08-25 14:00:44 --> Helper loaded: form_helper
INFO - 2020-08-25 14:00:44 --> Helper loaded: file_helper
INFO - 2020-08-25 14:00:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:00:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:00:44 --> Upload Class Initialized
INFO - 2020-08-25 14:00:44 --> Controller Class Initialized
DEBUG - 2020-08-25 14:00:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:00:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:00:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:00:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:00:44 --> Final output sent to browser
DEBUG - 2020-08-25 14:00:44 --> Total execution time: 0.0507
INFO - 2020-08-25 14:01:01 --> Config Class Initialized
INFO - 2020-08-25 14:01:01 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:01:01 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:01:01 --> Utf8 Class Initialized
INFO - 2020-08-25 14:01:01 --> URI Class Initialized
DEBUG - 2020-08-25 14:01:01 --> No URI present. Default controller set.
INFO - 2020-08-25 14:01:01 --> Router Class Initialized
INFO - 2020-08-25 14:01:01 --> Output Class Initialized
INFO - 2020-08-25 14:01:01 --> Security Class Initialized
DEBUG - 2020-08-25 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:01:01 --> Input Class Initialized
INFO - 2020-08-25 14:01:01 --> Language Class Initialized
INFO - 2020-08-25 14:01:01 --> Language Class Initialized
INFO - 2020-08-25 14:01:01 --> Config Class Initialized
INFO - 2020-08-25 14:01:01 --> Loader Class Initialized
INFO - 2020-08-25 14:01:01 --> Helper loaded: url_helper
INFO - 2020-08-25 14:01:01 --> Helper loaded: form_helper
INFO - 2020-08-25 14:01:01 --> Helper loaded: file_helper
INFO - 2020-08-25 14:01:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:01:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:01:01 --> Upload Class Initialized
INFO - 2020-08-25 14:01:01 --> Controller Class Initialized
DEBUG - 2020-08-25 14:01:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:01:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:01:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:01:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:01:01 --> Final output sent to browser
DEBUG - 2020-08-25 14:01:01 --> Total execution time: 0.2553
INFO - 2020-08-25 14:17:53 --> Config Class Initialized
INFO - 2020-08-25 14:17:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:17:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:17:53 --> Utf8 Class Initialized
INFO - 2020-08-25 14:17:53 --> URI Class Initialized
DEBUG - 2020-08-25 14:17:53 --> No URI present. Default controller set.
INFO - 2020-08-25 14:17:53 --> Router Class Initialized
INFO - 2020-08-25 14:17:53 --> Output Class Initialized
INFO - 2020-08-25 14:17:53 --> Security Class Initialized
DEBUG - 2020-08-25 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:17:53 --> Input Class Initialized
INFO - 2020-08-25 14:17:53 --> Language Class Initialized
INFO - 2020-08-25 14:17:53 --> Language Class Initialized
INFO - 2020-08-25 14:17:53 --> Config Class Initialized
INFO - 2020-08-25 14:17:53 --> Loader Class Initialized
INFO - 2020-08-25 14:17:53 --> Helper loaded: url_helper
INFO - 2020-08-25 14:17:53 --> Helper loaded: form_helper
INFO - 2020-08-25 14:17:53 --> Helper loaded: file_helper
INFO - 2020-08-25 14:17:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:17:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:17:53 --> Upload Class Initialized
INFO - 2020-08-25 14:17:53 --> Controller Class Initialized
DEBUG - 2020-08-25 14:17:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:17:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:17:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:17:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:17:53 --> Final output sent to browser
DEBUG - 2020-08-25 14:17:53 --> Total execution time: 0.0533
INFO - 2020-08-25 14:21:32 --> Config Class Initialized
INFO - 2020-08-25 14:21:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:21:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:21:32 --> Utf8 Class Initialized
INFO - 2020-08-25 14:21:32 --> URI Class Initialized
DEBUG - 2020-08-25 14:21:32 --> No URI present. Default controller set.
INFO - 2020-08-25 14:21:32 --> Router Class Initialized
INFO - 2020-08-25 14:21:32 --> Output Class Initialized
INFO - 2020-08-25 14:21:32 --> Security Class Initialized
DEBUG - 2020-08-25 14:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:21:32 --> Input Class Initialized
INFO - 2020-08-25 14:21:32 --> Language Class Initialized
INFO - 2020-08-25 14:21:32 --> Language Class Initialized
INFO - 2020-08-25 14:21:32 --> Config Class Initialized
INFO - 2020-08-25 14:21:32 --> Loader Class Initialized
INFO - 2020-08-25 14:21:32 --> Helper loaded: url_helper
INFO - 2020-08-25 14:21:32 --> Helper loaded: form_helper
INFO - 2020-08-25 14:21:32 --> Helper loaded: file_helper
INFO - 2020-08-25 14:21:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:21:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:21:32 --> Upload Class Initialized
INFO - 2020-08-25 14:21:32 --> Controller Class Initialized
DEBUG - 2020-08-25 14:21:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:21:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:21:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:21:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:21:32 --> Final output sent to browser
DEBUG - 2020-08-25 14:21:32 --> Total execution time: 0.0531
INFO - 2020-08-25 14:23:52 --> Config Class Initialized
INFO - 2020-08-25 14:23:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:23:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:23:52 --> Utf8 Class Initialized
INFO - 2020-08-25 14:23:52 --> URI Class Initialized
DEBUG - 2020-08-25 14:23:52 --> No URI present. Default controller set.
INFO - 2020-08-25 14:23:52 --> Router Class Initialized
INFO - 2020-08-25 14:23:52 --> Output Class Initialized
INFO - 2020-08-25 14:23:52 --> Security Class Initialized
DEBUG - 2020-08-25 14:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:23:52 --> Input Class Initialized
INFO - 2020-08-25 14:23:52 --> Language Class Initialized
INFO - 2020-08-25 14:23:52 --> Language Class Initialized
INFO - 2020-08-25 14:23:52 --> Config Class Initialized
INFO - 2020-08-25 14:23:52 --> Loader Class Initialized
INFO - 2020-08-25 14:23:52 --> Helper loaded: url_helper
INFO - 2020-08-25 14:23:52 --> Helper loaded: form_helper
INFO - 2020-08-25 14:23:52 --> Helper loaded: file_helper
INFO - 2020-08-25 14:23:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:23:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:23:52 --> Upload Class Initialized
INFO - 2020-08-25 14:23:52 --> Controller Class Initialized
DEBUG - 2020-08-25 14:23:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:23:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:23:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:23:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:23:52 --> Final output sent to browser
DEBUG - 2020-08-25 14:23:52 --> Total execution time: 0.0509
INFO - 2020-08-25 14:23:58 --> Config Class Initialized
INFO - 2020-08-25 14:23:58 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:23:58 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:23:58 --> Utf8 Class Initialized
INFO - 2020-08-25 14:23:58 --> URI Class Initialized
INFO - 2020-08-25 14:23:58 --> Router Class Initialized
INFO - 2020-08-25 14:23:58 --> Output Class Initialized
INFO - 2020-08-25 14:23:58 --> Security Class Initialized
DEBUG - 2020-08-25 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:23:58 --> Input Class Initialized
INFO - 2020-08-25 14:23:58 --> Language Class Initialized
INFO - 2020-08-25 14:23:58 --> Language Class Initialized
INFO - 2020-08-25 14:23:58 --> Config Class Initialized
INFO - 2020-08-25 14:23:58 --> Loader Class Initialized
INFO - 2020-08-25 14:23:58 --> Helper loaded: url_helper
INFO - 2020-08-25 14:23:58 --> Helper loaded: form_helper
INFO - 2020-08-25 14:23:58 --> Helper loaded: file_helper
INFO - 2020-08-25 14:23:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:23:58 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:23:58 --> Upload Class Initialized
INFO - 2020-08-25 14:23:58 --> Controller Class Initialized
ERROR - 2020-08-25 14:23:58 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:24:04 --> Config Class Initialized
INFO - 2020-08-25 14:24:04 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:24:04 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:24:04 --> Utf8 Class Initialized
INFO - 2020-08-25 14:24:04 --> URI Class Initialized
INFO - 2020-08-25 14:24:04 --> Router Class Initialized
INFO - 2020-08-25 14:24:04 --> Output Class Initialized
INFO - 2020-08-25 14:24:04 --> Security Class Initialized
DEBUG - 2020-08-25 14:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:24:04 --> Input Class Initialized
INFO - 2020-08-25 14:24:04 --> Language Class Initialized
INFO - 2020-08-25 14:24:04 --> Language Class Initialized
INFO - 2020-08-25 14:24:04 --> Config Class Initialized
INFO - 2020-08-25 14:24:04 --> Loader Class Initialized
INFO - 2020-08-25 14:24:04 --> Helper loaded: url_helper
INFO - 2020-08-25 14:24:04 --> Helper loaded: form_helper
INFO - 2020-08-25 14:24:04 --> Helper loaded: file_helper
INFO - 2020-08-25 14:24:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:24:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:24:04 --> Upload Class Initialized
INFO - 2020-08-25 14:24:04 --> Controller Class Initialized
DEBUG - 2020-08-25 14:24:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:24:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-25 14:24:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:24:04 --> Final output sent to browser
DEBUG - 2020-08-25 14:24:04 --> Total execution time: 0.0527
INFO - 2020-08-25 14:24:05 --> Config Class Initialized
INFO - 2020-08-25 14:24:05 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:24:05 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:24:05 --> Utf8 Class Initialized
INFO - 2020-08-25 14:24:05 --> URI Class Initialized
INFO - 2020-08-25 14:24:05 --> Router Class Initialized
INFO - 2020-08-25 14:24:05 --> Output Class Initialized
INFO - 2020-08-25 14:24:05 --> Security Class Initialized
DEBUG - 2020-08-25 14:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:24:05 --> Input Class Initialized
INFO - 2020-08-25 14:24:05 --> Language Class Initialized
INFO - 2020-08-25 14:24:05 --> Language Class Initialized
INFO - 2020-08-25 14:24:05 --> Config Class Initialized
INFO - 2020-08-25 14:24:05 --> Loader Class Initialized
INFO - 2020-08-25 14:24:05 --> Helper loaded: url_helper
INFO - 2020-08-25 14:24:05 --> Helper loaded: form_helper
INFO - 2020-08-25 14:24:05 --> Helper loaded: file_helper
INFO - 2020-08-25 14:24:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:24:05 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:24:05 --> Upload Class Initialized
INFO - 2020-08-25 14:24:05 --> Controller Class Initialized
ERROR - 2020-08-25 14:24:05 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:24:13 --> Config Class Initialized
INFO - 2020-08-25 14:24:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:24:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:24:13 --> Utf8 Class Initialized
INFO - 2020-08-25 14:24:13 --> URI Class Initialized
INFO - 2020-08-25 14:24:13 --> Router Class Initialized
INFO - 2020-08-25 14:24:13 --> Output Class Initialized
INFO - 2020-08-25 14:24:13 --> Security Class Initialized
DEBUG - 2020-08-25 14:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:24:13 --> Input Class Initialized
INFO - 2020-08-25 14:24:13 --> Language Class Initialized
INFO - 2020-08-25 14:24:13 --> Language Class Initialized
INFO - 2020-08-25 14:24:13 --> Config Class Initialized
INFO - 2020-08-25 14:24:13 --> Loader Class Initialized
INFO - 2020-08-25 14:24:13 --> Helper loaded: url_helper
INFO - 2020-08-25 14:24:13 --> Helper loaded: form_helper
INFO - 2020-08-25 14:24:13 --> Helper loaded: file_helper
INFO - 2020-08-25 14:24:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:24:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:24:13 --> Upload Class Initialized
INFO - 2020-08-25 14:24:13 --> Controller Class Initialized
DEBUG - 2020-08-25 14:24:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:24:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-25 14:24:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:24:13 --> Final output sent to browser
DEBUG - 2020-08-25 14:24:13 --> Total execution time: 0.0554
INFO - 2020-08-25 14:24:19 --> Config Class Initialized
INFO - 2020-08-25 14:24:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:24:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:24:19 --> Utf8 Class Initialized
INFO - 2020-08-25 14:24:19 --> URI Class Initialized
INFO - 2020-08-25 14:24:19 --> Router Class Initialized
INFO - 2020-08-25 14:24:19 --> Output Class Initialized
INFO - 2020-08-25 14:24:19 --> Security Class Initialized
DEBUG - 2020-08-25 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:24:19 --> Input Class Initialized
INFO - 2020-08-25 14:24:19 --> Language Class Initialized
INFO - 2020-08-25 14:24:19 --> Language Class Initialized
INFO - 2020-08-25 14:24:19 --> Config Class Initialized
INFO - 2020-08-25 14:24:19 --> Loader Class Initialized
INFO - 2020-08-25 14:24:19 --> Helper loaded: url_helper
INFO - 2020-08-25 14:24:19 --> Helper loaded: form_helper
INFO - 2020-08-25 14:24:19 --> Helper loaded: file_helper
INFO - 2020-08-25 14:24:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:24:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:24:19 --> Upload Class Initialized
INFO - 2020-08-25 14:24:19 --> Controller Class Initialized
DEBUG - 2020-08-25 14:24:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:24:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-25 14:24:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:24:19 --> Final output sent to browser
DEBUG - 2020-08-25 14:24:19 --> Total execution time: 0.0504
INFO - 2020-08-25 14:24:47 --> Config Class Initialized
INFO - 2020-08-25 14:24:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:24:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:24:47 --> Utf8 Class Initialized
INFO - 2020-08-25 14:24:47 --> URI Class Initialized
INFO - 2020-08-25 14:24:47 --> Router Class Initialized
INFO - 2020-08-25 14:24:47 --> Output Class Initialized
INFO - 2020-08-25 14:24:47 --> Security Class Initialized
DEBUG - 2020-08-25 14:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:24:47 --> Input Class Initialized
INFO - 2020-08-25 14:24:47 --> Language Class Initialized
INFO - 2020-08-25 14:24:47 --> Language Class Initialized
INFO - 2020-08-25 14:24:47 --> Config Class Initialized
INFO - 2020-08-25 14:24:47 --> Loader Class Initialized
INFO - 2020-08-25 14:24:47 --> Helper loaded: url_helper
INFO - 2020-08-25 14:24:47 --> Helper loaded: form_helper
INFO - 2020-08-25 14:24:47 --> Helper loaded: file_helper
INFO - 2020-08-25 14:24:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:24:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:24:47 --> Upload Class Initialized
INFO - 2020-08-25 14:24:47 --> Controller Class Initialized
DEBUG - 2020-08-25 14:24:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:24:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:24:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:24:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:24:47 --> Final output sent to browser
DEBUG - 2020-08-25 14:24:47 --> Total execution time: 0.0514
INFO - 2020-08-25 14:24:52 --> Config Class Initialized
INFO - 2020-08-25 14:24:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:24:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:24:52 --> Utf8 Class Initialized
INFO - 2020-08-25 14:24:52 --> URI Class Initialized
INFO - 2020-08-25 14:24:52 --> Router Class Initialized
INFO - 2020-08-25 14:24:52 --> Output Class Initialized
INFO - 2020-08-25 14:24:52 --> Security Class Initialized
DEBUG - 2020-08-25 14:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:24:52 --> Input Class Initialized
INFO - 2020-08-25 14:24:52 --> Language Class Initialized
INFO - 2020-08-25 14:24:52 --> Language Class Initialized
INFO - 2020-08-25 14:24:52 --> Config Class Initialized
INFO - 2020-08-25 14:24:52 --> Loader Class Initialized
INFO - 2020-08-25 14:24:52 --> Helper loaded: url_helper
INFO - 2020-08-25 14:24:52 --> Helper loaded: form_helper
INFO - 2020-08-25 14:24:52 --> Helper loaded: file_helper
INFO - 2020-08-25 14:24:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:24:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:24:52 --> Upload Class Initialized
INFO - 2020-08-25 14:24:52 --> Controller Class Initialized
ERROR - 2020-08-25 14:24:52 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:25:03 --> Config Class Initialized
INFO - 2020-08-25 14:25:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:03 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:03 --> URI Class Initialized
INFO - 2020-08-25 14:25:03 --> Router Class Initialized
INFO - 2020-08-25 14:25:03 --> Output Class Initialized
INFO - 2020-08-25 14:25:03 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:03 --> Input Class Initialized
INFO - 2020-08-25 14:25:03 --> Language Class Initialized
INFO - 2020-08-25 14:25:03 --> Language Class Initialized
INFO - 2020-08-25 14:25:03 --> Config Class Initialized
INFO - 2020-08-25 14:25:03 --> Loader Class Initialized
INFO - 2020-08-25 14:25:03 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:03 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:03 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:03 --> Upload Class Initialized
INFO - 2020-08-25 14:25:03 --> Controller Class Initialized
DEBUG - 2020-08-25 14:25:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:25:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:25:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:25:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:25:03 --> Final output sent to browser
DEBUG - 2020-08-25 14:25:03 --> Total execution time: 0.3149
INFO - 2020-08-25 14:25:06 --> Config Class Initialized
INFO - 2020-08-25 14:25:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:06 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:06 --> URI Class Initialized
INFO - 2020-08-25 14:25:06 --> Router Class Initialized
INFO - 2020-08-25 14:25:06 --> Output Class Initialized
INFO - 2020-08-25 14:25:06 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:06 --> Input Class Initialized
INFO - 2020-08-25 14:25:06 --> Language Class Initialized
INFO - 2020-08-25 14:25:06 --> Language Class Initialized
INFO - 2020-08-25 14:25:06 --> Config Class Initialized
INFO - 2020-08-25 14:25:06 --> Loader Class Initialized
INFO - 2020-08-25 14:25:06 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:06 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:06 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:06 --> Upload Class Initialized
INFO - 2020-08-25 14:25:06 --> Controller Class Initialized
ERROR - 2020-08-25 14:25:06 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:25:22 --> Config Class Initialized
INFO - 2020-08-25 14:25:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:22 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:22 --> URI Class Initialized
DEBUG - 2020-08-25 14:25:22 --> No URI present. Default controller set.
INFO - 2020-08-25 14:25:22 --> Router Class Initialized
INFO - 2020-08-25 14:25:22 --> Output Class Initialized
INFO - 2020-08-25 14:25:22 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:22 --> Input Class Initialized
INFO - 2020-08-25 14:25:22 --> Language Class Initialized
INFO - 2020-08-25 14:25:22 --> Language Class Initialized
INFO - 2020-08-25 14:25:22 --> Config Class Initialized
INFO - 2020-08-25 14:25:22 --> Loader Class Initialized
INFO - 2020-08-25 14:25:22 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:22 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:22 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:22 --> Upload Class Initialized
INFO - 2020-08-25 14:25:22 --> Controller Class Initialized
DEBUG - 2020-08-25 14:25:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:25:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:25:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:25:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:25:22 --> Final output sent to browser
DEBUG - 2020-08-25 14:25:22 --> Total execution time: 0.0502
INFO - 2020-08-25 14:25:31 --> Config Class Initialized
INFO - 2020-08-25 14:25:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:31 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:31 --> URI Class Initialized
DEBUG - 2020-08-25 14:25:31 --> No URI present. Default controller set.
INFO - 2020-08-25 14:25:31 --> Router Class Initialized
INFO - 2020-08-25 14:25:31 --> Output Class Initialized
INFO - 2020-08-25 14:25:31 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:31 --> Input Class Initialized
INFO - 2020-08-25 14:25:31 --> Language Class Initialized
INFO - 2020-08-25 14:25:31 --> Language Class Initialized
INFO - 2020-08-25 14:25:31 --> Config Class Initialized
INFO - 2020-08-25 14:25:31 --> Loader Class Initialized
INFO - 2020-08-25 14:25:31 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:31 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:31 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:31 --> Upload Class Initialized
INFO - 2020-08-25 14:25:31 --> Controller Class Initialized
DEBUG - 2020-08-25 14:25:31 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:25:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:25:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:25:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:25:31 --> Final output sent to browser
DEBUG - 2020-08-25 14:25:31 --> Total execution time: 0.0636
INFO - 2020-08-25 14:25:37 --> Config Class Initialized
INFO - 2020-08-25 14:25:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:37 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:37 --> URI Class Initialized
DEBUG - 2020-08-25 14:25:37 --> No URI present. Default controller set.
INFO - 2020-08-25 14:25:37 --> Router Class Initialized
INFO - 2020-08-25 14:25:37 --> Output Class Initialized
INFO - 2020-08-25 14:25:37 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:37 --> Input Class Initialized
INFO - 2020-08-25 14:25:37 --> Language Class Initialized
INFO - 2020-08-25 14:25:37 --> Language Class Initialized
INFO - 2020-08-25 14:25:37 --> Config Class Initialized
INFO - 2020-08-25 14:25:37 --> Loader Class Initialized
INFO - 2020-08-25 14:25:37 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:37 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:37 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:37 --> Upload Class Initialized
INFO - 2020-08-25 14:25:37 --> Controller Class Initialized
DEBUG - 2020-08-25 14:25:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:25:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:25:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:25:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:25:37 --> Final output sent to browser
DEBUG - 2020-08-25 14:25:37 --> Total execution time: 0.0519
INFO - 2020-08-25 14:25:42 --> Config Class Initialized
INFO - 2020-08-25 14:25:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:42 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:42 --> URI Class Initialized
DEBUG - 2020-08-25 14:25:42 --> No URI present. Default controller set.
INFO - 2020-08-25 14:25:42 --> Router Class Initialized
INFO - 2020-08-25 14:25:42 --> Output Class Initialized
INFO - 2020-08-25 14:25:42 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:42 --> Input Class Initialized
INFO - 2020-08-25 14:25:42 --> Language Class Initialized
INFO - 2020-08-25 14:25:42 --> Language Class Initialized
INFO - 2020-08-25 14:25:42 --> Config Class Initialized
INFO - 2020-08-25 14:25:42 --> Loader Class Initialized
INFO - 2020-08-25 14:25:42 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:42 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:42 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:42 --> Upload Class Initialized
INFO - 2020-08-25 14:25:42 --> Controller Class Initialized
DEBUG - 2020-08-25 14:25:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:25:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:25:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:25:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:25:42 --> Final output sent to browser
DEBUG - 2020-08-25 14:25:42 --> Total execution time: 0.0513
INFO - 2020-08-25 14:25:43 --> Config Class Initialized
INFO - 2020-08-25 14:25:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:43 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:43 --> URI Class Initialized
INFO - 2020-08-25 14:25:43 --> Router Class Initialized
INFO - 2020-08-25 14:25:43 --> Output Class Initialized
INFO - 2020-08-25 14:25:43 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:43 --> Input Class Initialized
INFO - 2020-08-25 14:25:43 --> Language Class Initialized
INFO - 2020-08-25 14:25:43 --> Language Class Initialized
INFO - 2020-08-25 14:25:43 --> Config Class Initialized
INFO - 2020-08-25 14:25:43 --> Loader Class Initialized
INFO - 2020-08-25 14:25:43 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:43 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:43 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:43 --> Upload Class Initialized
INFO - 2020-08-25 14:25:43 --> Controller Class Initialized
ERROR - 2020-08-25 14:25:43 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:25:48 --> Config Class Initialized
INFO - 2020-08-25 14:25:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:25:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:25:48 --> Utf8 Class Initialized
INFO - 2020-08-25 14:25:48 --> URI Class Initialized
DEBUG - 2020-08-25 14:25:48 --> No URI present. Default controller set.
INFO - 2020-08-25 14:25:48 --> Router Class Initialized
INFO - 2020-08-25 14:25:48 --> Output Class Initialized
INFO - 2020-08-25 14:25:48 --> Security Class Initialized
DEBUG - 2020-08-25 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:25:48 --> Input Class Initialized
INFO - 2020-08-25 14:25:48 --> Language Class Initialized
INFO - 2020-08-25 14:25:48 --> Language Class Initialized
INFO - 2020-08-25 14:25:48 --> Config Class Initialized
INFO - 2020-08-25 14:25:48 --> Loader Class Initialized
INFO - 2020-08-25 14:25:48 --> Helper loaded: url_helper
INFO - 2020-08-25 14:25:48 --> Helper loaded: form_helper
INFO - 2020-08-25 14:25:48 --> Helper loaded: file_helper
INFO - 2020-08-25 14:25:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:25:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:25:48 --> Upload Class Initialized
INFO - 2020-08-25 14:25:48 --> Controller Class Initialized
DEBUG - 2020-08-25 14:25:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:25:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:25:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:25:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:25:48 --> Final output sent to browser
DEBUG - 2020-08-25 14:25:48 --> Total execution time: 0.0517
INFO - 2020-08-25 14:26:50 --> Config Class Initialized
INFO - 2020-08-25 14:26:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:26:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:26:50 --> Utf8 Class Initialized
INFO - 2020-08-25 14:26:50 --> URI Class Initialized
DEBUG - 2020-08-25 14:26:50 --> No URI present. Default controller set.
INFO - 2020-08-25 14:26:50 --> Router Class Initialized
INFO - 2020-08-25 14:26:50 --> Output Class Initialized
INFO - 2020-08-25 14:26:50 --> Security Class Initialized
DEBUG - 2020-08-25 14:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:26:50 --> Input Class Initialized
INFO - 2020-08-25 14:26:50 --> Language Class Initialized
INFO - 2020-08-25 14:26:50 --> Language Class Initialized
INFO - 2020-08-25 14:26:50 --> Config Class Initialized
INFO - 2020-08-25 14:26:50 --> Loader Class Initialized
INFO - 2020-08-25 14:26:50 --> Helper loaded: url_helper
INFO - 2020-08-25 14:26:50 --> Helper loaded: form_helper
INFO - 2020-08-25 14:26:50 --> Helper loaded: file_helper
INFO - 2020-08-25 14:26:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:26:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:26:50 --> Upload Class Initialized
INFO - 2020-08-25 14:26:50 --> Controller Class Initialized
DEBUG - 2020-08-25 14:26:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:26:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:26:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:26:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:26:50 --> Final output sent to browser
DEBUG - 2020-08-25 14:26:50 --> Total execution time: 0.0513
INFO - 2020-08-25 14:29:12 --> Config Class Initialized
INFO - 2020-08-25 14:29:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:29:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:29:12 --> Utf8 Class Initialized
INFO - 2020-08-25 14:29:12 --> URI Class Initialized
INFO - 2020-08-25 14:29:12 --> Router Class Initialized
INFO - 2020-08-25 14:29:12 --> Output Class Initialized
INFO - 2020-08-25 14:29:12 --> Security Class Initialized
DEBUG - 2020-08-25 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:29:12 --> Input Class Initialized
INFO - 2020-08-25 14:29:12 --> Language Class Initialized
INFO - 2020-08-25 14:29:12 --> Language Class Initialized
INFO - 2020-08-25 14:29:12 --> Config Class Initialized
INFO - 2020-08-25 14:29:12 --> Loader Class Initialized
INFO - 2020-08-25 14:29:12 --> Helper loaded: url_helper
INFO - 2020-08-25 14:29:12 --> Helper loaded: form_helper
INFO - 2020-08-25 14:29:12 --> Helper loaded: file_helper
INFO - 2020-08-25 14:29:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:29:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:29:12 --> Upload Class Initialized
INFO - 2020-08-25 14:29:12 --> Controller Class Initialized
DEBUG - 2020-08-25 14:29:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:29:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-25 14:29:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:29:12 --> Final output sent to browser
DEBUG - 2020-08-25 14:29:12 --> Total execution time: 0.0539
INFO - 2020-08-25 14:29:18 --> Config Class Initialized
INFO - 2020-08-25 14:29:18 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:29:18 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:29:18 --> Utf8 Class Initialized
INFO - 2020-08-25 14:29:18 --> URI Class Initialized
INFO - 2020-08-25 14:29:18 --> Router Class Initialized
INFO - 2020-08-25 14:29:18 --> Output Class Initialized
INFO - 2020-08-25 14:29:18 --> Security Class Initialized
DEBUG - 2020-08-25 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:29:18 --> Input Class Initialized
INFO - 2020-08-25 14:29:18 --> Language Class Initialized
INFO - 2020-08-25 14:29:18 --> Language Class Initialized
INFO - 2020-08-25 14:29:18 --> Config Class Initialized
INFO - 2020-08-25 14:29:18 --> Loader Class Initialized
INFO - 2020-08-25 14:29:18 --> Helper loaded: url_helper
INFO - 2020-08-25 14:29:18 --> Helper loaded: form_helper
INFO - 2020-08-25 14:29:18 --> Helper loaded: file_helper
INFO - 2020-08-25 14:29:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:29:18 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:29:18 --> Upload Class Initialized
INFO - 2020-08-25 14:29:18 --> Controller Class Initialized
DEBUG - 2020-08-25 14:29:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:29:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:29:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:29:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:29:18 --> Final output sent to browser
DEBUG - 2020-08-25 14:29:18 --> Total execution time: 0.0519
INFO - 2020-08-25 14:29:38 --> Config Class Initialized
INFO - 2020-08-25 14:29:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:29:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:29:38 --> Utf8 Class Initialized
INFO - 2020-08-25 14:29:38 --> URI Class Initialized
INFO - 2020-08-25 14:29:38 --> Router Class Initialized
INFO - 2020-08-25 14:29:38 --> Output Class Initialized
INFO - 2020-08-25 14:29:38 --> Security Class Initialized
DEBUG - 2020-08-25 14:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:29:38 --> Input Class Initialized
INFO - 2020-08-25 14:29:38 --> Language Class Initialized
INFO - 2020-08-25 14:29:38 --> Language Class Initialized
INFO - 2020-08-25 14:29:38 --> Config Class Initialized
INFO - 2020-08-25 14:29:38 --> Loader Class Initialized
INFO - 2020-08-25 14:29:38 --> Helper loaded: url_helper
INFO - 2020-08-25 14:29:38 --> Helper loaded: form_helper
INFO - 2020-08-25 14:29:38 --> Helper loaded: file_helper
INFO - 2020-08-25 14:29:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:29:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:29:38 --> Upload Class Initialized
INFO - 2020-08-25 14:29:38 --> Controller Class Initialized
DEBUG - 2020-08-25 14:29:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:29:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-25 14:29:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:29:38 --> Final output sent to browser
DEBUG - 2020-08-25 14:29:38 --> Total execution time: 0.0501
INFO - 2020-08-25 14:31:49 --> Config Class Initialized
INFO - 2020-08-25 14:31:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:31:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:31:49 --> Utf8 Class Initialized
INFO - 2020-08-25 14:31:49 --> URI Class Initialized
INFO - 2020-08-25 14:31:49 --> Router Class Initialized
INFO - 2020-08-25 14:31:49 --> Output Class Initialized
INFO - 2020-08-25 14:31:49 --> Security Class Initialized
DEBUG - 2020-08-25 14:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:31:49 --> Input Class Initialized
INFO - 2020-08-25 14:31:49 --> Language Class Initialized
INFO - 2020-08-25 14:31:49 --> Language Class Initialized
INFO - 2020-08-25 14:31:49 --> Config Class Initialized
INFO - 2020-08-25 14:31:49 --> Loader Class Initialized
INFO - 2020-08-25 14:31:49 --> Helper loaded: url_helper
INFO - 2020-08-25 14:31:49 --> Helper loaded: form_helper
INFO - 2020-08-25 14:31:49 --> Helper loaded: file_helper
INFO - 2020-08-25 14:31:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:31:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:31:49 --> Upload Class Initialized
INFO - 2020-08-25 14:31:49 --> Controller Class Initialized
ERROR - 2020-08-25 14:31:49 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:36:51 --> Config Class Initialized
INFO - 2020-08-25 14:36:51 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:36:51 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:36:51 --> Utf8 Class Initialized
INFO - 2020-08-25 14:36:51 --> URI Class Initialized
DEBUG - 2020-08-25 14:36:51 --> No URI present. Default controller set.
INFO - 2020-08-25 14:36:51 --> Router Class Initialized
INFO - 2020-08-25 14:36:51 --> Output Class Initialized
INFO - 2020-08-25 14:36:51 --> Security Class Initialized
DEBUG - 2020-08-25 14:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:36:51 --> Input Class Initialized
INFO - 2020-08-25 14:36:51 --> Language Class Initialized
INFO - 2020-08-25 14:36:51 --> Language Class Initialized
INFO - 2020-08-25 14:36:51 --> Config Class Initialized
INFO - 2020-08-25 14:36:51 --> Loader Class Initialized
INFO - 2020-08-25 14:36:51 --> Helper loaded: url_helper
INFO - 2020-08-25 14:36:51 --> Helper loaded: form_helper
INFO - 2020-08-25 14:36:51 --> Helper loaded: file_helper
INFO - 2020-08-25 14:36:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:36:51 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:36:51 --> Upload Class Initialized
INFO - 2020-08-25 14:36:51 --> Controller Class Initialized
DEBUG - 2020-08-25 14:36:51 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:36:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:36:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:36:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:36:51 --> Final output sent to browser
DEBUG - 2020-08-25 14:36:51 --> Total execution time: 0.0497
INFO - 2020-08-25 14:36:53 --> Config Class Initialized
INFO - 2020-08-25 14:36:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:36:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:36:53 --> Utf8 Class Initialized
INFO - 2020-08-25 14:36:53 --> URI Class Initialized
DEBUG - 2020-08-25 14:36:53 --> No URI present. Default controller set.
INFO - 2020-08-25 14:36:53 --> Router Class Initialized
INFO - 2020-08-25 14:36:53 --> Output Class Initialized
INFO - 2020-08-25 14:36:53 --> Security Class Initialized
DEBUG - 2020-08-25 14:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:36:53 --> Input Class Initialized
INFO - 2020-08-25 14:36:53 --> Language Class Initialized
INFO - 2020-08-25 14:36:53 --> Language Class Initialized
INFO - 2020-08-25 14:36:53 --> Config Class Initialized
INFO - 2020-08-25 14:36:53 --> Loader Class Initialized
INFO - 2020-08-25 14:36:53 --> Helper loaded: url_helper
INFO - 2020-08-25 14:36:53 --> Helper loaded: form_helper
INFO - 2020-08-25 14:36:53 --> Helper loaded: file_helper
INFO - 2020-08-25 14:36:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:36:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:36:53 --> Upload Class Initialized
INFO - 2020-08-25 14:36:53 --> Controller Class Initialized
DEBUG - 2020-08-25 14:36:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:36:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:36:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:36:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:36:53 --> Final output sent to browser
DEBUG - 2020-08-25 14:36:53 --> Total execution time: 0.0534
INFO - 2020-08-25 14:36:54 --> Config Class Initialized
INFO - 2020-08-25 14:36:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:36:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:36:54 --> Utf8 Class Initialized
INFO - 2020-08-25 14:36:54 --> URI Class Initialized
DEBUG - 2020-08-25 14:36:54 --> No URI present. Default controller set.
INFO - 2020-08-25 14:36:54 --> Router Class Initialized
INFO - 2020-08-25 14:36:54 --> Output Class Initialized
INFO - 2020-08-25 14:36:54 --> Security Class Initialized
DEBUG - 2020-08-25 14:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:36:54 --> Input Class Initialized
INFO - 2020-08-25 14:36:54 --> Language Class Initialized
INFO - 2020-08-25 14:36:54 --> Language Class Initialized
INFO - 2020-08-25 14:36:54 --> Config Class Initialized
INFO - 2020-08-25 14:36:54 --> Loader Class Initialized
INFO - 2020-08-25 14:36:54 --> Helper loaded: url_helper
INFO - 2020-08-25 14:36:54 --> Helper loaded: form_helper
INFO - 2020-08-25 14:36:54 --> Helper loaded: file_helper
INFO - 2020-08-25 14:36:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:36:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:36:54 --> Upload Class Initialized
INFO - 2020-08-25 14:36:54 --> Controller Class Initialized
DEBUG - 2020-08-25 14:36:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:36:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:36:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:36:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:36:54 --> Final output sent to browser
DEBUG - 2020-08-25 14:36:54 --> Total execution time: 0.0497
INFO - 2020-08-25 14:42:38 --> Config Class Initialized
INFO - 2020-08-25 14:42:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:42:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:42:38 --> Utf8 Class Initialized
INFO - 2020-08-25 14:42:38 --> URI Class Initialized
DEBUG - 2020-08-25 14:42:38 --> No URI present. Default controller set.
INFO - 2020-08-25 14:42:38 --> Router Class Initialized
INFO - 2020-08-25 14:42:38 --> Output Class Initialized
INFO - 2020-08-25 14:42:38 --> Security Class Initialized
DEBUG - 2020-08-25 14:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:42:38 --> Input Class Initialized
INFO - 2020-08-25 14:42:38 --> Language Class Initialized
INFO - 2020-08-25 14:42:38 --> Language Class Initialized
INFO - 2020-08-25 14:42:38 --> Config Class Initialized
INFO - 2020-08-25 14:42:38 --> Loader Class Initialized
INFO - 2020-08-25 14:42:38 --> Helper loaded: url_helper
INFO - 2020-08-25 14:42:38 --> Helper loaded: form_helper
INFO - 2020-08-25 14:42:38 --> Helper loaded: file_helper
INFO - 2020-08-25 14:42:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:42:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:42:38 --> Upload Class Initialized
INFO - 2020-08-25 14:42:38 --> Controller Class Initialized
DEBUG - 2020-08-25 14:42:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:42:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:42:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:42:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:42:38 --> Final output sent to browser
DEBUG - 2020-08-25 14:42:38 --> Total execution time: 0.0507
INFO - 2020-08-25 14:42:59 --> Config Class Initialized
INFO - 2020-08-25 14:42:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:42:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:42:59 --> Utf8 Class Initialized
INFO - 2020-08-25 14:42:59 --> URI Class Initialized
INFO - 2020-08-25 14:42:59 --> Router Class Initialized
INFO - 2020-08-25 14:42:59 --> Output Class Initialized
INFO - 2020-08-25 14:42:59 --> Security Class Initialized
DEBUG - 2020-08-25 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:42:59 --> Input Class Initialized
INFO - 2020-08-25 14:42:59 --> Language Class Initialized
INFO - 2020-08-25 14:42:59 --> Language Class Initialized
INFO - 2020-08-25 14:42:59 --> Config Class Initialized
INFO - 2020-08-25 14:42:59 --> Loader Class Initialized
INFO - 2020-08-25 14:42:59 --> Helper loaded: url_helper
INFO - 2020-08-25 14:42:59 --> Helper loaded: form_helper
INFO - 2020-08-25 14:42:59 --> Helper loaded: file_helper
INFO - 2020-08-25 14:42:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:42:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:42:59 --> Upload Class Initialized
INFO - 2020-08-25 14:42:59 --> Controller Class Initialized
ERROR - 2020-08-25 14:42:59 --> 404 Page Not Found: /index
INFO - 2020-08-25 14:45:42 --> Config Class Initialized
INFO - 2020-08-25 14:45:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:45:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:45:42 --> Utf8 Class Initialized
INFO - 2020-08-25 14:45:42 --> URI Class Initialized
DEBUG - 2020-08-25 14:45:42 --> No URI present. Default controller set.
INFO - 2020-08-25 14:45:42 --> Router Class Initialized
INFO - 2020-08-25 14:45:42 --> Output Class Initialized
INFO - 2020-08-25 14:45:42 --> Security Class Initialized
DEBUG - 2020-08-25 14:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:45:42 --> Input Class Initialized
INFO - 2020-08-25 14:45:42 --> Language Class Initialized
INFO - 2020-08-25 14:45:42 --> Language Class Initialized
INFO - 2020-08-25 14:45:42 --> Config Class Initialized
INFO - 2020-08-25 14:45:42 --> Loader Class Initialized
INFO - 2020-08-25 14:45:42 --> Helper loaded: url_helper
INFO - 2020-08-25 14:45:42 --> Helper loaded: form_helper
INFO - 2020-08-25 14:45:42 --> Helper loaded: file_helper
INFO - 2020-08-25 14:45:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:45:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:45:42 --> Upload Class Initialized
INFO - 2020-08-25 14:45:42 --> Controller Class Initialized
DEBUG - 2020-08-25 14:45:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:45:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:45:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:45:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:45:42 --> Final output sent to browser
DEBUG - 2020-08-25 14:45:42 --> Total execution time: 0.0500
INFO - 2020-08-25 14:45:46 --> Config Class Initialized
INFO - 2020-08-25 14:45:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:45:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:45:46 --> Utf8 Class Initialized
INFO - 2020-08-25 14:45:46 --> URI Class Initialized
DEBUG - 2020-08-25 14:45:46 --> No URI present. Default controller set.
INFO - 2020-08-25 14:45:46 --> Router Class Initialized
INFO - 2020-08-25 14:45:46 --> Output Class Initialized
INFO - 2020-08-25 14:45:46 --> Security Class Initialized
DEBUG - 2020-08-25 14:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:45:46 --> Input Class Initialized
INFO - 2020-08-25 14:45:46 --> Language Class Initialized
INFO - 2020-08-25 14:45:46 --> Language Class Initialized
INFO - 2020-08-25 14:45:46 --> Config Class Initialized
INFO - 2020-08-25 14:45:46 --> Loader Class Initialized
INFO - 2020-08-25 14:45:46 --> Helper loaded: url_helper
INFO - 2020-08-25 14:45:46 --> Helper loaded: form_helper
INFO - 2020-08-25 14:45:46 --> Helper loaded: file_helper
INFO - 2020-08-25 14:45:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:45:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:45:46 --> Upload Class Initialized
INFO - 2020-08-25 14:45:46 --> Controller Class Initialized
DEBUG - 2020-08-25 14:45:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:45:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:45:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:45:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:45:46 --> Final output sent to browser
DEBUG - 2020-08-25 14:45:46 --> Total execution time: 0.0579
INFO - 2020-08-25 14:45:49 --> Config Class Initialized
INFO - 2020-08-25 14:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:45:49 --> Utf8 Class Initialized
INFO - 2020-08-25 14:45:49 --> URI Class Initialized
DEBUG - 2020-08-25 14:45:49 --> No URI present. Default controller set.
INFO - 2020-08-25 14:45:49 --> Router Class Initialized
INFO - 2020-08-25 14:45:49 --> Output Class Initialized
INFO - 2020-08-25 14:45:49 --> Security Class Initialized
DEBUG - 2020-08-25 14:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:45:49 --> Input Class Initialized
INFO - 2020-08-25 14:45:49 --> Language Class Initialized
INFO - 2020-08-25 14:45:49 --> Language Class Initialized
INFO - 2020-08-25 14:45:49 --> Config Class Initialized
INFO - 2020-08-25 14:45:49 --> Loader Class Initialized
INFO - 2020-08-25 14:45:49 --> Helper loaded: url_helper
INFO - 2020-08-25 14:45:49 --> Helper loaded: form_helper
INFO - 2020-08-25 14:45:49 --> Helper loaded: file_helper
INFO - 2020-08-25 14:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:45:49 --> Upload Class Initialized
INFO - 2020-08-25 14:45:49 --> Controller Class Initialized
DEBUG - 2020-08-25 14:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 14:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 14:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 14:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 14:45:49 --> Final output sent to browser
DEBUG - 2020-08-25 14:45:49 --> Total execution time: 0.0492
INFO - 2020-08-25 14:49:09 --> Config Class Initialized
INFO - 2020-08-25 14:49:09 --> Hooks Class Initialized
DEBUG - 2020-08-25 14:49:09 --> UTF-8 Support Enabled
INFO - 2020-08-25 14:49:09 --> Utf8 Class Initialized
INFO - 2020-08-25 14:49:09 --> URI Class Initialized
INFO - 2020-08-25 14:49:09 --> Router Class Initialized
INFO - 2020-08-25 14:49:09 --> Output Class Initialized
INFO - 2020-08-25 14:49:09 --> Security Class Initialized
DEBUG - 2020-08-25 14:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 14:49:09 --> Input Class Initialized
INFO - 2020-08-25 14:49:09 --> Language Class Initialized
INFO - 2020-08-25 14:49:09 --> Language Class Initialized
INFO - 2020-08-25 14:49:09 --> Config Class Initialized
INFO - 2020-08-25 14:49:09 --> Loader Class Initialized
INFO - 2020-08-25 14:49:09 --> Helper loaded: url_helper
INFO - 2020-08-25 14:49:09 --> Helper loaded: form_helper
INFO - 2020-08-25 14:49:09 --> Helper loaded: file_helper
INFO - 2020-08-25 14:49:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 14:49:09 --> Database Driver Class Initialized
DEBUG - 2020-08-25 14:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 14:49:09 --> Upload Class Initialized
INFO - 2020-08-25 14:49:09 --> Controller Class Initialized
ERROR - 2020-08-25 14:49:09 --> 404 Page Not Found: /index
INFO - 2020-08-25 15:10:05 --> Config Class Initialized
INFO - 2020-08-25 15:10:05 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:10:05 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:10:05 --> Utf8 Class Initialized
INFO - 2020-08-25 15:10:05 --> URI Class Initialized
DEBUG - 2020-08-25 15:10:05 --> No URI present. Default controller set.
INFO - 2020-08-25 15:10:05 --> Router Class Initialized
INFO - 2020-08-25 15:10:05 --> Output Class Initialized
INFO - 2020-08-25 15:10:05 --> Security Class Initialized
DEBUG - 2020-08-25 15:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:10:05 --> Input Class Initialized
INFO - 2020-08-25 15:10:05 --> Language Class Initialized
INFO - 2020-08-25 15:10:05 --> Language Class Initialized
INFO - 2020-08-25 15:10:05 --> Config Class Initialized
INFO - 2020-08-25 15:10:05 --> Loader Class Initialized
INFO - 2020-08-25 15:10:05 --> Helper loaded: url_helper
INFO - 2020-08-25 15:10:05 --> Helper loaded: form_helper
INFO - 2020-08-25 15:10:05 --> Helper loaded: file_helper
INFO - 2020-08-25 15:10:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:10:05 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:10:05 --> Upload Class Initialized
INFO - 2020-08-25 15:10:05 --> Controller Class Initialized
DEBUG - 2020-08-25 15:10:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:10:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:10:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:10:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:10:05 --> Final output sent to browser
DEBUG - 2020-08-25 15:10:05 --> Total execution time: 0.1372
INFO - 2020-08-25 15:31:42 --> Config Class Initialized
INFO - 2020-08-25 15:31:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:31:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:31:42 --> Utf8 Class Initialized
INFO - 2020-08-25 15:31:42 --> URI Class Initialized
DEBUG - 2020-08-25 15:31:42 --> No URI present. Default controller set.
INFO - 2020-08-25 15:31:42 --> Router Class Initialized
INFO - 2020-08-25 15:31:42 --> Output Class Initialized
INFO - 2020-08-25 15:31:42 --> Security Class Initialized
DEBUG - 2020-08-25 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:31:42 --> Input Class Initialized
INFO - 2020-08-25 15:31:42 --> Language Class Initialized
INFO - 2020-08-25 15:31:42 --> Language Class Initialized
INFO - 2020-08-25 15:31:42 --> Config Class Initialized
INFO - 2020-08-25 15:31:42 --> Loader Class Initialized
INFO - 2020-08-25 15:31:42 --> Helper loaded: url_helper
INFO - 2020-08-25 15:31:42 --> Helper loaded: form_helper
INFO - 2020-08-25 15:31:42 --> Helper loaded: file_helper
INFO - 2020-08-25 15:31:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:31:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:31:42 --> Upload Class Initialized
INFO - 2020-08-25 15:31:42 --> Controller Class Initialized
DEBUG - 2020-08-25 15:31:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:31:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:31:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:31:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:31:42 --> Final output sent to browser
DEBUG - 2020-08-25 15:31:42 --> Total execution time: 0.0583
INFO - 2020-08-25 15:38:21 --> Config Class Initialized
INFO - 2020-08-25 15:38:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:38:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:38:21 --> Utf8 Class Initialized
INFO - 2020-08-25 15:38:21 --> URI Class Initialized
DEBUG - 2020-08-25 15:38:21 --> No URI present. Default controller set.
INFO - 2020-08-25 15:38:21 --> Router Class Initialized
INFO - 2020-08-25 15:38:21 --> Output Class Initialized
INFO - 2020-08-25 15:38:21 --> Security Class Initialized
DEBUG - 2020-08-25 15:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:38:21 --> Input Class Initialized
INFO - 2020-08-25 15:38:21 --> Language Class Initialized
INFO - 2020-08-25 15:38:21 --> Language Class Initialized
INFO - 2020-08-25 15:38:21 --> Config Class Initialized
INFO - 2020-08-25 15:38:21 --> Loader Class Initialized
INFO - 2020-08-25 15:38:21 --> Helper loaded: url_helper
INFO - 2020-08-25 15:38:21 --> Helper loaded: form_helper
INFO - 2020-08-25 15:38:21 --> Helper loaded: file_helper
INFO - 2020-08-25 15:38:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:38:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:38:21 --> Upload Class Initialized
INFO - 2020-08-25 15:38:21 --> Controller Class Initialized
DEBUG - 2020-08-25 15:38:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:38:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:38:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:38:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:38:21 --> Final output sent to browser
DEBUG - 2020-08-25 15:38:21 --> Total execution time: 0.0506
INFO - 2020-08-25 15:38:34 --> Config Class Initialized
INFO - 2020-08-25 15:38:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:38:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:38:34 --> Utf8 Class Initialized
INFO - 2020-08-25 15:38:34 --> URI Class Initialized
INFO - 2020-08-25 15:38:34 --> Router Class Initialized
INFO - 2020-08-25 15:38:34 --> Output Class Initialized
INFO - 2020-08-25 15:38:34 --> Security Class Initialized
DEBUG - 2020-08-25 15:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:38:34 --> Input Class Initialized
INFO - 2020-08-25 15:38:34 --> Language Class Initialized
INFO - 2020-08-25 15:38:34 --> Language Class Initialized
INFO - 2020-08-25 15:38:34 --> Config Class Initialized
INFO - 2020-08-25 15:38:34 --> Loader Class Initialized
INFO - 2020-08-25 15:38:34 --> Helper loaded: url_helper
INFO - 2020-08-25 15:38:34 --> Helper loaded: form_helper
INFO - 2020-08-25 15:38:34 --> Helper loaded: file_helper
INFO - 2020-08-25 15:38:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:38:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:38:34 --> Upload Class Initialized
INFO - 2020-08-25 15:38:34 --> Controller Class Initialized
ERROR - 2020-08-25 15:38:34 --> 404 Page Not Found: /index
INFO - 2020-08-25 15:40:32 --> Config Class Initialized
INFO - 2020-08-25 15:40:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:40:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:40:32 --> Utf8 Class Initialized
INFO - 2020-08-25 15:40:32 --> URI Class Initialized
DEBUG - 2020-08-25 15:40:32 --> No URI present. Default controller set.
INFO - 2020-08-25 15:40:32 --> Router Class Initialized
INFO - 2020-08-25 15:40:32 --> Output Class Initialized
INFO - 2020-08-25 15:40:32 --> Security Class Initialized
DEBUG - 2020-08-25 15:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:40:32 --> Input Class Initialized
INFO - 2020-08-25 15:40:32 --> Language Class Initialized
INFO - 2020-08-25 15:40:32 --> Language Class Initialized
INFO - 2020-08-25 15:40:32 --> Config Class Initialized
INFO - 2020-08-25 15:40:32 --> Loader Class Initialized
INFO - 2020-08-25 15:40:32 --> Helper loaded: url_helper
INFO - 2020-08-25 15:40:32 --> Helper loaded: form_helper
INFO - 2020-08-25 15:40:32 --> Helper loaded: file_helper
INFO - 2020-08-25 15:40:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:40:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:40:32 --> Upload Class Initialized
INFO - 2020-08-25 15:40:32 --> Controller Class Initialized
DEBUG - 2020-08-25 15:40:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:40:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:40:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:40:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:40:32 --> Final output sent to browser
DEBUG - 2020-08-25 15:40:32 --> Total execution time: 0.0520
INFO - 2020-08-25 15:40:34 --> Config Class Initialized
INFO - 2020-08-25 15:40:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:40:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:40:34 --> Utf8 Class Initialized
INFO - 2020-08-25 15:40:34 --> URI Class Initialized
DEBUG - 2020-08-25 15:40:34 --> No URI present. Default controller set.
INFO - 2020-08-25 15:40:34 --> Router Class Initialized
INFO - 2020-08-25 15:40:34 --> Output Class Initialized
INFO - 2020-08-25 15:40:34 --> Security Class Initialized
DEBUG - 2020-08-25 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:40:34 --> Input Class Initialized
INFO - 2020-08-25 15:40:34 --> Language Class Initialized
INFO - 2020-08-25 15:40:34 --> Language Class Initialized
INFO - 2020-08-25 15:40:34 --> Config Class Initialized
INFO - 2020-08-25 15:40:34 --> Loader Class Initialized
INFO - 2020-08-25 15:40:34 --> Helper loaded: url_helper
INFO - 2020-08-25 15:40:34 --> Helper loaded: form_helper
INFO - 2020-08-25 15:40:34 --> Helper loaded: file_helper
INFO - 2020-08-25 15:40:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:40:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:40:34 --> Upload Class Initialized
INFO - 2020-08-25 15:40:34 --> Controller Class Initialized
DEBUG - 2020-08-25 15:40:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:40:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:40:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:40:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:40:34 --> Final output sent to browser
DEBUG - 2020-08-25 15:40:34 --> Total execution time: 0.0508
INFO - 2020-08-25 15:40:35 --> Config Class Initialized
INFO - 2020-08-25 15:40:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:40:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:40:35 --> Utf8 Class Initialized
INFO - 2020-08-25 15:40:35 --> URI Class Initialized
DEBUG - 2020-08-25 15:40:35 --> No URI present. Default controller set.
INFO - 2020-08-25 15:40:35 --> Router Class Initialized
INFO - 2020-08-25 15:40:35 --> Output Class Initialized
INFO - 2020-08-25 15:40:35 --> Security Class Initialized
DEBUG - 2020-08-25 15:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:40:35 --> Input Class Initialized
INFO - 2020-08-25 15:40:35 --> Language Class Initialized
INFO - 2020-08-25 15:40:35 --> Language Class Initialized
INFO - 2020-08-25 15:40:35 --> Config Class Initialized
INFO - 2020-08-25 15:40:35 --> Loader Class Initialized
INFO - 2020-08-25 15:40:35 --> Helper loaded: url_helper
INFO - 2020-08-25 15:40:35 --> Helper loaded: form_helper
INFO - 2020-08-25 15:40:35 --> Helper loaded: file_helper
INFO - 2020-08-25 15:40:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:40:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:40:35 --> Upload Class Initialized
INFO - 2020-08-25 15:40:35 --> Controller Class Initialized
DEBUG - 2020-08-25 15:40:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:40:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:40:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:40:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:40:35 --> Final output sent to browser
DEBUG - 2020-08-25 15:40:35 --> Total execution time: 0.0632
INFO - 2020-08-25 15:40:58 --> Config Class Initialized
INFO - 2020-08-25 15:40:58 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:40:58 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:40:58 --> Utf8 Class Initialized
INFO - 2020-08-25 15:40:58 --> URI Class Initialized
DEBUG - 2020-08-25 15:40:58 --> No URI present. Default controller set.
INFO - 2020-08-25 15:40:58 --> Router Class Initialized
INFO - 2020-08-25 15:40:58 --> Output Class Initialized
INFO - 2020-08-25 15:40:58 --> Security Class Initialized
DEBUG - 2020-08-25 15:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:40:58 --> Input Class Initialized
INFO - 2020-08-25 15:40:58 --> Language Class Initialized
INFO - 2020-08-25 15:40:58 --> Language Class Initialized
INFO - 2020-08-25 15:40:58 --> Config Class Initialized
INFO - 2020-08-25 15:40:58 --> Loader Class Initialized
INFO - 2020-08-25 15:40:58 --> Helper loaded: url_helper
INFO - 2020-08-25 15:40:58 --> Helper loaded: form_helper
INFO - 2020-08-25 15:40:58 --> Helper loaded: file_helper
INFO - 2020-08-25 15:40:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:40:58 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:40:58 --> Upload Class Initialized
INFO - 2020-08-25 15:40:58 --> Controller Class Initialized
DEBUG - 2020-08-25 15:40:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:40:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:40:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:40:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:40:58 --> Final output sent to browser
DEBUG - 2020-08-25 15:40:58 --> Total execution time: 0.0640
INFO - 2020-08-25 15:41:08 --> Config Class Initialized
INFO - 2020-08-25 15:41:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:41:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:41:08 --> Utf8 Class Initialized
INFO - 2020-08-25 15:41:08 --> URI Class Initialized
DEBUG - 2020-08-25 15:41:08 --> No URI present. Default controller set.
INFO - 2020-08-25 15:41:08 --> Router Class Initialized
INFO - 2020-08-25 15:41:08 --> Output Class Initialized
INFO - 2020-08-25 15:41:08 --> Security Class Initialized
DEBUG - 2020-08-25 15:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:41:08 --> Input Class Initialized
INFO - 2020-08-25 15:41:08 --> Language Class Initialized
INFO - 2020-08-25 15:41:08 --> Language Class Initialized
INFO - 2020-08-25 15:41:08 --> Config Class Initialized
INFO - 2020-08-25 15:41:08 --> Loader Class Initialized
INFO - 2020-08-25 15:41:08 --> Helper loaded: url_helper
INFO - 2020-08-25 15:41:08 --> Helper loaded: form_helper
INFO - 2020-08-25 15:41:08 --> Helper loaded: file_helper
INFO - 2020-08-25 15:41:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:41:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:41:08 --> Upload Class Initialized
INFO - 2020-08-25 15:41:08 --> Controller Class Initialized
DEBUG - 2020-08-25 15:41:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:41:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:41:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:41:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:41:08 --> Final output sent to browser
DEBUG - 2020-08-25 15:41:08 --> Total execution time: 0.0600
INFO - 2020-08-25 15:41:11 --> Config Class Initialized
INFO - 2020-08-25 15:41:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:41:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:41:11 --> Utf8 Class Initialized
INFO - 2020-08-25 15:41:11 --> URI Class Initialized
INFO - 2020-08-25 15:41:11 --> Router Class Initialized
INFO - 2020-08-25 15:41:11 --> Output Class Initialized
INFO - 2020-08-25 15:41:11 --> Security Class Initialized
DEBUG - 2020-08-25 15:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:41:11 --> Input Class Initialized
INFO - 2020-08-25 15:41:11 --> Language Class Initialized
INFO - 2020-08-25 15:41:11 --> Language Class Initialized
INFO - 2020-08-25 15:41:11 --> Config Class Initialized
INFO - 2020-08-25 15:41:11 --> Loader Class Initialized
INFO - 2020-08-25 15:41:11 --> Helper loaded: url_helper
INFO - 2020-08-25 15:41:11 --> Helper loaded: form_helper
INFO - 2020-08-25 15:41:11 --> Helper loaded: file_helper
INFO - 2020-08-25 15:41:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:41:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:41:11 --> Upload Class Initialized
INFO - 2020-08-25 15:41:11 --> Controller Class Initialized
ERROR - 2020-08-25 15:41:11 --> 404 Page Not Found: /index
INFO - 2020-08-25 15:49:52 --> Config Class Initialized
INFO - 2020-08-25 15:49:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:49:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:49:52 --> Utf8 Class Initialized
INFO - 2020-08-25 15:49:52 --> URI Class Initialized
DEBUG - 2020-08-25 15:49:52 --> No URI present. Default controller set.
INFO - 2020-08-25 15:49:52 --> Router Class Initialized
INFO - 2020-08-25 15:49:52 --> Output Class Initialized
INFO - 2020-08-25 15:49:52 --> Security Class Initialized
DEBUG - 2020-08-25 15:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:49:52 --> Input Class Initialized
INFO - 2020-08-25 15:49:52 --> Language Class Initialized
INFO - 2020-08-25 15:49:52 --> Language Class Initialized
INFO - 2020-08-25 15:49:52 --> Config Class Initialized
INFO - 2020-08-25 15:49:52 --> Loader Class Initialized
INFO - 2020-08-25 15:49:52 --> Helper loaded: url_helper
INFO - 2020-08-25 15:49:52 --> Helper loaded: form_helper
INFO - 2020-08-25 15:49:52 --> Helper loaded: file_helper
INFO - 2020-08-25 15:49:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:49:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:49:52 --> Upload Class Initialized
INFO - 2020-08-25 15:49:52 --> Controller Class Initialized
DEBUG - 2020-08-25 15:49:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:49:52 --> Final output sent to browser
DEBUG - 2020-08-25 15:49:52 --> Total execution time: 0.0620
INFO - 2020-08-25 15:49:54 --> Config Class Initialized
INFO - 2020-08-25 15:49:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:49:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:49:54 --> Utf8 Class Initialized
INFO - 2020-08-25 15:49:54 --> URI Class Initialized
DEBUG - 2020-08-25 15:49:54 --> No URI present. Default controller set.
INFO - 2020-08-25 15:49:54 --> Router Class Initialized
INFO - 2020-08-25 15:49:54 --> Output Class Initialized
INFO - 2020-08-25 15:49:54 --> Security Class Initialized
DEBUG - 2020-08-25 15:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:49:54 --> Input Class Initialized
INFO - 2020-08-25 15:49:54 --> Language Class Initialized
INFO - 2020-08-25 15:49:54 --> Language Class Initialized
INFO - 2020-08-25 15:49:54 --> Config Class Initialized
INFO - 2020-08-25 15:49:54 --> Loader Class Initialized
INFO - 2020-08-25 15:49:54 --> Helper loaded: url_helper
INFO - 2020-08-25 15:49:54 --> Helper loaded: form_helper
INFO - 2020-08-25 15:49:54 --> Helper loaded: file_helper
INFO - 2020-08-25 15:49:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:49:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:49:54 --> Upload Class Initialized
INFO - 2020-08-25 15:49:54 --> Controller Class Initialized
DEBUG - 2020-08-25 15:49:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:49:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:49:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:49:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:49:54 --> Final output sent to browser
DEBUG - 2020-08-25 15:49:54 --> Total execution time: 0.0605
INFO - 2020-08-25 15:49:55 --> Config Class Initialized
INFO - 2020-08-25 15:49:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:49:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:49:55 --> Utf8 Class Initialized
INFO - 2020-08-25 15:49:55 --> URI Class Initialized
DEBUG - 2020-08-25 15:49:55 --> No URI present. Default controller set.
INFO - 2020-08-25 15:49:55 --> Router Class Initialized
INFO - 2020-08-25 15:49:55 --> Output Class Initialized
INFO - 2020-08-25 15:49:55 --> Security Class Initialized
DEBUG - 2020-08-25 15:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:49:55 --> Input Class Initialized
INFO - 2020-08-25 15:49:55 --> Language Class Initialized
INFO - 2020-08-25 15:49:55 --> Language Class Initialized
INFO - 2020-08-25 15:49:55 --> Config Class Initialized
INFO - 2020-08-25 15:49:55 --> Loader Class Initialized
INFO - 2020-08-25 15:49:55 --> Helper loaded: url_helper
INFO - 2020-08-25 15:49:55 --> Helper loaded: form_helper
INFO - 2020-08-25 15:49:55 --> Helper loaded: file_helper
INFO - 2020-08-25 15:49:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:49:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:49:55 --> Upload Class Initialized
INFO - 2020-08-25 15:49:55 --> Controller Class Initialized
DEBUG - 2020-08-25 15:49:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:49:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:49:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:49:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:49:55 --> Final output sent to browser
DEBUG - 2020-08-25 15:49:55 --> Total execution time: 0.0519
INFO - 2020-08-25 15:50:16 --> Config Class Initialized
INFO - 2020-08-25 15:50:16 --> Hooks Class Initialized
DEBUG - 2020-08-25 15:50:16 --> UTF-8 Support Enabled
INFO - 2020-08-25 15:50:16 --> Utf8 Class Initialized
INFO - 2020-08-25 15:50:16 --> URI Class Initialized
DEBUG - 2020-08-25 15:50:16 --> No URI present. Default controller set.
INFO - 2020-08-25 15:50:16 --> Router Class Initialized
INFO - 2020-08-25 15:50:16 --> Output Class Initialized
INFO - 2020-08-25 15:50:16 --> Security Class Initialized
DEBUG - 2020-08-25 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 15:50:16 --> Input Class Initialized
INFO - 2020-08-25 15:50:16 --> Language Class Initialized
INFO - 2020-08-25 15:50:16 --> Language Class Initialized
INFO - 2020-08-25 15:50:16 --> Config Class Initialized
INFO - 2020-08-25 15:50:16 --> Loader Class Initialized
INFO - 2020-08-25 15:50:16 --> Helper loaded: url_helper
INFO - 2020-08-25 15:50:16 --> Helper loaded: form_helper
INFO - 2020-08-25 15:50:17 --> Helper loaded: file_helper
INFO - 2020-08-25 15:50:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 15:50:17 --> Database Driver Class Initialized
DEBUG - 2020-08-25 15:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 15:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 15:50:17 --> Upload Class Initialized
INFO - 2020-08-25 15:50:17 --> Controller Class Initialized
DEBUG - 2020-08-25 15:50:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 15:50:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 15:50:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 15:50:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 15:50:17 --> Final output sent to browser
DEBUG - 2020-08-25 15:50:17 --> Total execution time: 0.0667
INFO - 2020-08-25 16:05:12 --> Config Class Initialized
INFO - 2020-08-25 16:05:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:05:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:05:12 --> Utf8 Class Initialized
INFO - 2020-08-25 16:05:12 --> URI Class Initialized
INFO - 2020-08-25 16:05:12 --> Router Class Initialized
INFO - 2020-08-25 16:05:12 --> Output Class Initialized
INFO - 2020-08-25 16:05:12 --> Security Class Initialized
DEBUG - 2020-08-25 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:05:12 --> Input Class Initialized
INFO - 2020-08-25 16:05:12 --> Language Class Initialized
INFO - 2020-08-25 16:05:12 --> Language Class Initialized
INFO - 2020-08-25 16:05:12 --> Config Class Initialized
INFO - 2020-08-25 16:05:12 --> Loader Class Initialized
INFO - 2020-08-25 16:05:12 --> Helper loaded: url_helper
INFO - 2020-08-25 16:05:12 --> Helper loaded: form_helper
INFO - 2020-08-25 16:05:12 --> Helper loaded: file_helper
INFO - 2020-08-25 16:05:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:05:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:05:12 --> Upload Class Initialized
INFO - 2020-08-25 16:05:12 --> Controller Class Initialized
ERROR - 2020-08-25 16:05:12 --> 404 Page Not Found: /index
INFO - 2020-08-25 16:05:12 --> Config Class Initialized
INFO - 2020-08-25 16:05:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:05:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:05:12 --> Utf8 Class Initialized
INFO - 2020-08-25 16:05:12 --> URI Class Initialized
INFO - 2020-08-25 16:05:12 --> Router Class Initialized
INFO - 2020-08-25 16:05:12 --> Output Class Initialized
INFO - 2020-08-25 16:05:12 --> Security Class Initialized
DEBUG - 2020-08-25 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:05:12 --> Input Class Initialized
INFO - 2020-08-25 16:05:12 --> Language Class Initialized
INFO - 2020-08-25 16:05:12 --> Language Class Initialized
INFO - 2020-08-25 16:05:12 --> Config Class Initialized
INFO - 2020-08-25 16:05:12 --> Loader Class Initialized
INFO - 2020-08-25 16:05:12 --> Helper loaded: url_helper
INFO - 2020-08-25 16:05:12 --> Helper loaded: form_helper
INFO - 2020-08-25 16:05:12 --> Helper loaded: file_helper
INFO - 2020-08-25 16:05:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:05:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:05:12 --> Upload Class Initialized
INFO - 2020-08-25 16:05:12 --> Controller Class Initialized
DEBUG - 2020-08-25 16:05:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:05:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-25 16:05:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:05:12 --> Final output sent to browser
DEBUG - 2020-08-25 16:05:12 --> Total execution time: 0.0554
INFO - 2020-08-25 16:08:38 --> Config Class Initialized
INFO - 2020-08-25 16:08:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:08:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:08:38 --> Utf8 Class Initialized
INFO - 2020-08-25 16:08:38 --> URI Class Initialized
DEBUG - 2020-08-25 16:08:38 --> No URI present. Default controller set.
INFO - 2020-08-25 16:08:38 --> Router Class Initialized
INFO - 2020-08-25 16:08:38 --> Output Class Initialized
INFO - 2020-08-25 16:08:38 --> Security Class Initialized
DEBUG - 2020-08-25 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:08:38 --> Input Class Initialized
INFO - 2020-08-25 16:08:38 --> Language Class Initialized
INFO - 2020-08-25 16:08:38 --> Language Class Initialized
INFO - 2020-08-25 16:08:38 --> Config Class Initialized
INFO - 2020-08-25 16:08:38 --> Loader Class Initialized
INFO - 2020-08-25 16:08:38 --> Helper loaded: url_helper
INFO - 2020-08-25 16:08:38 --> Helper loaded: form_helper
INFO - 2020-08-25 16:08:38 --> Helper loaded: file_helper
INFO - 2020-08-25 16:08:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:08:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:08:38 --> Upload Class Initialized
INFO - 2020-08-25 16:08:38 --> Controller Class Initialized
DEBUG - 2020-08-25 16:08:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:08:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:08:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:08:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:08:38 --> Final output sent to browser
DEBUG - 2020-08-25 16:08:38 --> Total execution time: 0.0530
INFO - 2020-08-25 16:08:48 --> Config Class Initialized
INFO - 2020-08-25 16:08:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:08:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:08:48 --> Utf8 Class Initialized
INFO - 2020-08-25 16:08:48 --> URI Class Initialized
DEBUG - 2020-08-25 16:08:48 --> No URI present. Default controller set.
INFO - 2020-08-25 16:08:48 --> Router Class Initialized
INFO - 2020-08-25 16:08:48 --> Output Class Initialized
INFO - 2020-08-25 16:08:48 --> Security Class Initialized
DEBUG - 2020-08-25 16:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:08:48 --> Input Class Initialized
INFO - 2020-08-25 16:08:48 --> Language Class Initialized
INFO - 2020-08-25 16:08:48 --> Language Class Initialized
INFO - 2020-08-25 16:08:48 --> Config Class Initialized
INFO - 2020-08-25 16:08:48 --> Loader Class Initialized
INFO - 2020-08-25 16:08:48 --> Helper loaded: url_helper
INFO - 2020-08-25 16:08:48 --> Helper loaded: form_helper
INFO - 2020-08-25 16:08:48 --> Helper loaded: file_helper
INFO - 2020-08-25 16:08:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:08:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:08:48 --> Upload Class Initialized
INFO - 2020-08-25 16:08:48 --> Controller Class Initialized
DEBUG - 2020-08-25 16:08:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:08:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:08:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:08:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:08:48 --> Final output sent to browser
DEBUG - 2020-08-25 16:08:48 --> Total execution time: 0.0518
INFO - 2020-08-25 16:09:06 --> Config Class Initialized
INFO - 2020-08-25 16:09:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:09:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:09:06 --> Utf8 Class Initialized
INFO - 2020-08-25 16:09:06 --> URI Class Initialized
DEBUG - 2020-08-25 16:09:06 --> No URI present. Default controller set.
INFO - 2020-08-25 16:09:06 --> Router Class Initialized
INFO - 2020-08-25 16:09:06 --> Output Class Initialized
INFO - 2020-08-25 16:09:06 --> Security Class Initialized
DEBUG - 2020-08-25 16:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:09:06 --> Input Class Initialized
INFO - 2020-08-25 16:09:06 --> Language Class Initialized
INFO - 2020-08-25 16:09:06 --> Language Class Initialized
INFO - 2020-08-25 16:09:06 --> Config Class Initialized
INFO - 2020-08-25 16:09:06 --> Loader Class Initialized
INFO - 2020-08-25 16:09:06 --> Helper loaded: url_helper
INFO - 2020-08-25 16:09:06 --> Helper loaded: form_helper
INFO - 2020-08-25 16:09:06 --> Helper loaded: file_helper
INFO - 2020-08-25 16:09:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:09:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:09:06 --> Upload Class Initialized
INFO - 2020-08-25 16:09:06 --> Controller Class Initialized
DEBUG - 2020-08-25 16:09:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:09:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:09:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:09:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:09:06 --> Final output sent to browser
DEBUG - 2020-08-25 16:09:06 --> Total execution time: 0.0521
INFO - 2020-08-25 16:09:13 --> Config Class Initialized
INFO - 2020-08-25 16:09:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:09:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:09:13 --> Utf8 Class Initialized
INFO - 2020-08-25 16:09:13 --> URI Class Initialized
DEBUG - 2020-08-25 16:09:13 --> No URI present. Default controller set.
INFO - 2020-08-25 16:09:13 --> Router Class Initialized
INFO - 2020-08-25 16:09:13 --> Output Class Initialized
INFO - 2020-08-25 16:09:13 --> Security Class Initialized
DEBUG - 2020-08-25 16:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:09:13 --> Input Class Initialized
INFO - 2020-08-25 16:09:13 --> Language Class Initialized
INFO - 2020-08-25 16:09:13 --> Language Class Initialized
INFO - 2020-08-25 16:09:13 --> Config Class Initialized
INFO - 2020-08-25 16:09:13 --> Loader Class Initialized
INFO - 2020-08-25 16:09:13 --> Helper loaded: url_helper
INFO - 2020-08-25 16:09:13 --> Helper loaded: form_helper
INFO - 2020-08-25 16:09:13 --> Helper loaded: file_helper
INFO - 2020-08-25 16:09:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:09:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:09:13 --> Upload Class Initialized
INFO - 2020-08-25 16:09:13 --> Controller Class Initialized
DEBUG - 2020-08-25 16:09:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:09:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:09:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:09:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:09:13 --> Final output sent to browser
DEBUG - 2020-08-25 16:09:13 --> Total execution time: 0.0508
INFO - 2020-08-25 16:14:52 --> Config Class Initialized
INFO - 2020-08-25 16:14:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:14:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:14:52 --> Utf8 Class Initialized
INFO - 2020-08-25 16:14:52 --> URI Class Initialized
INFO - 2020-08-25 16:14:52 --> Router Class Initialized
INFO - 2020-08-25 16:14:52 --> Output Class Initialized
INFO - 2020-08-25 16:14:52 --> Security Class Initialized
DEBUG - 2020-08-25 16:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:14:52 --> Input Class Initialized
INFO - 2020-08-25 16:14:52 --> Language Class Initialized
INFO - 2020-08-25 16:14:52 --> Language Class Initialized
INFO - 2020-08-25 16:14:52 --> Config Class Initialized
INFO - 2020-08-25 16:14:52 --> Loader Class Initialized
INFO - 2020-08-25 16:14:52 --> Helper loaded: url_helper
INFO - 2020-08-25 16:14:52 --> Helper loaded: form_helper
INFO - 2020-08-25 16:14:52 --> Helper loaded: file_helper
INFO - 2020-08-25 16:14:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:14:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:14:52 --> Upload Class Initialized
INFO - 2020-08-25 16:14:52 --> Controller Class Initialized
DEBUG - 2020-08-25 16:14:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:14:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:14:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:14:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:14:52 --> Final output sent to browser
DEBUG - 2020-08-25 16:14:52 --> Total execution time: 0.0510
INFO - 2020-08-25 16:19:59 --> Config Class Initialized
INFO - 2020-08-25 16:19:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:19:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:19:59 --> Utf8 Class Initialized
INFO - 2020-08-25 16:19:59 --> URI Class Initialized
INFO - 2020-08-25 16:19:59 --> Router Class Initialized
INFO - 2020-08-25 16:19:59 --> Output Class Initialized
INFO - 2020-08-25 16:19:59 --> Security Class Initialized
DEBUG - 2020-08-25 16:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:19:59 --> Input Class Initialized
INFO - 2020-08-25 16:19:59 --> Language Class Initialized
INFO - 2020-08-25 16:19:59 --> Language Class Initialized
INFO - 2020-08-25 16:19:59 --> Config Class Initialized
INFO - 2020-08-25 16:19:59 --> Loader Class Initialized
INFO - 2020-08-25 16:19:59 --> Helper loaded: url_helper
INFO - 2020-08-25 16:19:59 --> Helper loaded: form_helper
INFO - 2020-08-25 16:19:59 --> Helper loaded: file_helper
INFO - 2020-08-25 16:19:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:19:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:19:59 --> Upload Class Initialized
INFO - 2020-08-25 16:19:59 --> Controller Class Initialized
DEBUG - 2020-08-25 16:19:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:19:59 --> Final output sent to browser
DEBUG - 2020-08-25 16:19:59 --> Total execution time: 0.0653
INFO - 2020-08-25 16:20:21 --> Config Class Initialized
INFO - 2020-08-25 16:20:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:20:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:20:21 --> Utf8 Class Initialized
INFO - 2020-08-25 16:20:21 --> URI Class Initialized
DEBUG - 2020-08-25 16:20:21 --> No URI present. Default controller set.
INFO - 2020-08-25 16:20:21 --> Router Class Initialized
INFO - 2020-08-25 16:20:21 --> Output Class Initialized
INFO - 2020-08-25 16:20:21 --> Security Class Initialized
DEBUG - 2020-08-25 16:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:20:21 --> Input Class Initialized
INFO - 2020-08-25 16:20:21 --> Language Class Initialized
INFO - 2020-08-25 16:20:21 --> Language Class Initialized
INFO - 2020-08-25 16:20:21 --> Config Class Initialized
INFO - 2020-08-25 16:20:21 --> Loader Class Initialized
INFO - 2020-08-25 16:20:21 --> Helper loaded: url_helper
INFO - 2020-08-25 16:20:21 --> Helper loaded: form_helper
INFO - 2020-08-25 16:20:21 --> Helper loaded: file_helper
INFO - 2020-08-25 16:20:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:20:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:20:21 --> Upload Class Initialized
INFO - 2020-08-25 16:20:21 --> Controller Class Initialized
DEBUG - 2020-08-25 16:20:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:20:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:20:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:20:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:20:21 --> Final output sent to browser
DEBUG - 2020-08-25 16:20:21 --> Total execution time: 0.0840
INFO - 2020-08-25 16:35:46 --> Config Class Initialized
INFO - 2020-08-25 16:35:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:35:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:35:46 --> Utf8 Class Initialized
INFO - 2020-08-25 16:35:46 --> URI Class Initialized
DEBUG - 2020-08-25 16:35:46 --> No URI present. Default controller set.
INFO - 2020-08-25 16:35:46 --> Router Class Initialized
INFO - 2020-08-25 16:35:46 --> Output Class Initialized
INFO - 2020-08-25 16:35:46 --> Security Class Initialized
DEBUG - 2020-08-25 16:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:35:46 --> Input Class Initialized
INFO - 2020-08-25 16:35:46 --> Language Class Initialized
INFO - 2020-08-25 16:35:46 --> Language Class Initialized
INFO - 2020-08-25 16:35:46 --> Config Class Initialized
INFO - 2020-08-25 16:35:46 --> Loader Class Initialized
INFO - 2020-08-25 16:35:46 --> Helper loaded: url_helper
INFO - 2020-08-25 16:35:46 --> Helper loaded: form_helper
INFO - 2020-08-25 16:35:46 --> Helper loaded: file_helper
INFO - 2020-08-25 16:35:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:35:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:35:46 --> Upload Class Initialized
INFO - 2020-08-25 16:35:46 --> Controller Class Initialized
DEBUG - 2020-08-25 16:35:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:35:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:35:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:35:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:35:46 --> Final output sent to browser
DEBUG - 2020-08-25 16:35:46 --> Total execution time: 0.0508
INFO - 2020-08-25 16:35:57 --> Config Class Initialized
INFO - 2020-08-25 16:35:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:35:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:35:57 --> Utf8 Class Initialized
INFO - 2020-08-25 16:35:57 --> URI Class Initialized
INFO - 2020-08-25 16:35:57 --> Router Class Initialized
INFO - 2020-08-25 16:35:57 --> Output Class Initialized
INFO - 2020-08-25 16:35:57 --> Security Class Initialized
DEBUG - 2020-08-25 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:35:57 --> Input Class Initialized
INFO - 2020-08-25 16:35:57 --> Language Class Initialized
INFO - 2020-08-25 16:35:57 --> Language Class Initialized
INFO - 2020-08-25 16:35:57 --> Config Class Initialized
INFO - 2020-08-25 16:35:57 --> Loader Class Initialized
INFO - 2020-08-25 16:35:57 --> Helper loaded: url_helper
INFO - 2020-08-25 16:35:57 --> Helper loaded: form_helper
INFO - 2020-08-25 16:35:57 --> Helper loaded: file_helper
INFO - 2020-08-25 16:35:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:35:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:35:57 --> Upload Class Initialized
INFO - 2020-08-25 16:35:57 --> Controller Class Initialized
ERROR - 2020-08-25 16:35:57 --> 404 Page Not Found: /index
INFO - 2020-08-25 16:40:53 --> Config Class Initialized
INFO - 2020-08-25 16:40:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:40:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:40:53 --> Utf8 Class Initialized
INFO - 2020-08-25 16:40:53 --> URI Class Initialized
DEBUG - 2020-08-25 16:40:53 --> No URI present. Default controller set.
INFO - 2020-08-25 16:40:53 --> Router Class Initialized
INFO - 2020-08-25 16:40:53 --> Output Class Initialized
INFO - 2020-08-25 16:40:53 --> Security Class Initialized
DEBUG - 2020-08-25 16:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:40:53 --> Input Class Initialized
INFO - 2020-08-25 16:40:53 --> Language Class Initialized
INFO - 2020-08-25 16:40:53 --> Language Class Initialized
INFO - 2020-08-25 16:40:53 --> Config Class Initialized
INFO - 2020-08-25 16:40:53 --> Loader Class Initialized
INFO - 2020-08-25 16:40:53 --> Helper loaded: url_helper
INFO - 2020-08-25 16:40:53 --> Helper loaded: form_helper
INFO - 2020-08-25 16:40:53 --> Helper loaded: file_helper
INFO - 2020-08-25 16:40:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:40:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:40:53 --> Upload Class Initialized
INFO - 2020-08-25 16:40:53 --> Controller Class Initialized
DEBUG - 2020-08-25 16:40:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:40:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:40:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:40:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:40:53 --> Final output sent to browser
DEBUG - 2020-08-25 16:40:53 --> Total execution time: 0.0527
INFO - 2020-08-25 16:41:01 --> Config Class Initialized
INFO - 2020-08-25 16:41:01 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:41:01 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:41:01 --> Utf8 Class Initialized
INFO - 2020-08-25 16:41:01 --> URI Class Initialized
DEBUG - 2020-08-25 16:41:01 --> No URI present. Default controller set.
INFO - 2020-08-25 16:41:01 --> Router Class Initialized
INFO - 2020-08-25 16:41:01 --> Output Class Initialized
INFO - 2020-08-25 16:41:01 --> Security Class Initialized
DEBUG - 2020-08-25 16:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:41:01 --> Input Class Initialized
INFO - 2020-08-25 16:41:01 --> Language Class Initialized
INFO - 2020-08-25 16:41:01 --> Language Class Initialized
INFO - 2020-08-25 16:41:01 --> Config Class Initialized
INFO - 2020-08-25 16:41:01 --> Loader Class Initialized
INFO - 2020-08-25 16:41:01 --> Helper loaded: url_helper
INFO - 2020-08-25 16:41:01 --> Helper loaded: form_helper
INFO - 2020-08-25 16:41:01 --> Helper loaded: file_helper
INFO - 2020-08-25 16:41:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:41:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:41:01 --> Upload Class Initialized
INFO - 2020-08-25 16:41:01 --> Controller Class Initialized
DEBUG - 2020-08-25 16:41:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:41:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:41:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:41:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:41:01 --> Final output sent to browser
DEBUG - 2020-08-25 16:41:01 --> Total execution time: 0.0506
INFO - 2020-08-25 16:41:06 --> Config Class Initialized
INFO - 2020-08-25 16:41:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:41:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:41:06 --> Utf8 Class Initialized
INFO - 2020-08-25 16:41:06 --> URI Class Initialized
DEBUG - 2020-08-25 16:41:06 --> No URI present. Default controller set.
INFO - 2020-08-25 16:41:06 --> Router Class Initialized
INFO - 2020-08-25 16:41:06 --> Output Class Initialized
INFO - 2020-08-25 16:41:06 --> Security Class Initialized
DEBUG - 2020-08-25 16:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:41:06 --> Input Class Initialized
INFO - 2020-08-25 16:41:06 --> Language Class Initialized
INFO - 2020-08-25 16:41:06 --> Language Class Initialized
INFO - 2020-08-25 16:41:06 --> Config Class Initialized
INFO - 2020-08-25 16:41:06 --> Loader Class Initialized
INFO - 2020-08-25 16:41:06 --> Helper loaded: url_helper
INFO - 2020-08-25 16:41:06 --> Helper loaded: form_helper
INFO - 2020-08-25 16:41:06 --> Helper loaded: file_helper
INFO - 2020-08-25 16:41:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:41:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:41:06 --> Upload Class Initialized
INFO - 2020-08-25 16:41:06 --> Controller Class Initialized
DEBUG - 2020-08-25 16:41:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:41:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:41:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:41:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:41:06 --> Final output sent to browser
DEBUG - 2020-08-25 16:41:06 --> Total execution time: 0.0495
INFO - 2020-08-25 16:42:18 --> Config Class Initialized
INFO - 2020-08-25 16:42:18 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:42:18 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:42:18 --> Utf8 Class Initialized
INFO - 2020-08-25 16:42:18 --> URI Class Initialized
INFO - 2020-08-25 16:42:18 --> Router Class Initialized
INFO - 2020-08-25 16:42:18 --> Output Class Initialized
INFO - 2020-08-25 16:42:18 --> Security Class Initialized
DEBUG - 2020-08-25 16:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:42:18 --> Input Class Initialized
INFO - 2020-08-25 16:42:18 --> Language Class Initialized
INFO - 2020-08-25 16:42:18 --> Language Class Initialized
INFO - 2020-08-25 16:42:18 --> Config Class Initialized
INFO - 2020-08-25 16:42:18 --> Loader Class Initialized
INFO - 2020-08-25 16:42:18 --> Helper loaded: url_helper
INFO - 2020-08-25 16:42:18 --> Helper loaded: form_helper
INFO - 2020-08-25 16:42:18 --> Helper loaded: file_helper
INFO - 2020-08-25 16:42:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:42:18 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:42:18 --> Upload Class Initialized
INFO - 2020-08-25 16:42:18 --> Controller Class Initialized
DEBUG - 2020-08-25 16:42:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:42:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:42:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:42:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:42:18 --> Final output sent to browser
DEBUG - 2020-08-25 16:42:18 --> Total execution time: 0.0505
INFO - 2020-08-25 16:42:24 --> Config Class Initialized
INFO - 2020-08-25 16:42:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:42:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:42:24 --> Utf8 Class Initialized
INFO - 2020-08-25 16:42:24 --> URI Class Initialized
INFO - 2020-08-25 16:42:24 --> Router Class Initialized
INFO - 2020-08-25 16:42:24 --> Output Class Initialized
INFO - 2020-08-25 16:42:24 --> Security Class Initialized
DEBUG - 2020-08-25 16:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:42:24 --> Input Class Initialized
INFO - 2020-08-25 16:42:24 --> Language Class Initialized
INFO - 2020-08-25 16:42:24 --> Language Class Initialized
INFO - 2020-08-25 16:42:24 --> Config Class Initialized
INFO - 2020-08-25 16:42:24 --> Loader Class Initialized
INFO - 2020-08-25 16:42:24 --> Helper loaded: url_helper
INFO - 2020-08-25 16:42:24 --> Helper loaded: form_helper
INFO - 2020-08-25 16:42:24 --> Helper loaded: file_helper
INFO - 2020-08-25 16:42:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:42:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:42:24 --> Upload Class Initialized
INFO - 2020-08-25 16:42:24 --> Controller Class Initialized
ERROR - 2020-08-25 16:42:24 --> 404 Page Not Found: /index
INFO - 2020-08-25 16:45:17 --> Config Class Initialized
INFO - 2020-08-25 16:45:17 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:45:17 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:45:17 --> Utf8 Class Initialized
INFO - 2020-08-25 16:45:17 --> URI Class Initialized
DEBUG - 2020-08-25 16:45:17 --> No URI present. Default controller set.
INFO - 2020-08-25 16:45:17 --> Router Class Initialized
INFO - 2020-08-25 16:45:17 --> Output Class Initialized
INFO - 2020-08-25 16:45:17 --> Security Class Initialized
DEBUG - 2020-08-25 16:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:45:17 --> Input Class Initialized
INFO - 2020-08-25 16:45:17 --> Language Class Initialized
INFO - 2020-08-25 16:45:17 --> Language Class Initialized
INFO - 2020-08-25 16:45:17 --> Config Class Initialized
INFO - 2020-08-25 16:45:17 --> Loader Class Initialized
INFO - 2020-08-25 16:45:17 --> Helper loaded: url_helper
INFO - 2020-08-25 16:45:17 --> Helper loaded: form_helper
INFO - 2020-08-25 16:45:17 --> Helper loaded: file_helper
INFO - 2020-08-25 16:45:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:45:17 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:45:17 --> Upload Class Initialized
INFO - 2020-08-25 16:45:17 --> Controller Class Initialized
DEBUG - 2020-08-25 16:45:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:45:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:45:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:45:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:45:17 --> Final output sent to browser
DEBUG - 2020-08-25 16:45:17 --> Total execution time: 0.0500
INFO - 2020-08-25 16:45:22 --> Config Class Initialized
INFO - 2020-08-25 16:45:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:45:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:45:22 --> Utf8 Class Initialized
INFO - 2020-08-25 16:45:22 --> URI Class Initialized
INFO - 2020-08-25 16:45:22 --> Router Class Initialized
INFO - 2020-08-25 16:45:22 --> Output Class Initialized
INFO - 2020-08-25 16:45:22 --> Security Class Initialized
DEBUG - 2020-08-25 16:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:45:22 --> Input Class Initialized
INFO - 2020-08-25 16:45:22 --> Language Class Initialized
INFO - 2020-08-25 16:45:22 --> Language Class Initialized
INFO - 2020-08-25 16:45:22 --> Config Class Initialized
INFO - 2020-08-25 16:45:22 --> Loader Class Initialized
INFO - 2020-08-25 16:45:22 --> Helper loaded: url_helper
INFO - 2020-08-25 16:45:22 --> Helper loaded: form_helper
INFO - 2020-08-25 16:45:22 --> Helper loaded: file_helper
INFO - 2020-08-25 16:45:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:45:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:45:22 --> Upload Class Initialized
INFO - 2020-08-25 16:45:22 --> Controller Class Initialized
ERROR - 2020-08-25 16:45:22 --> 404 Page Not Found: /index
INFO - 2020-08-25 16:45:22 --> Config Class Initialized
INFO - 2020-08-25 16:45:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:45:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:45:22 --> Utf8 Class Initialized
INFO - 2020-08-25 16:45:22 --> URI Class Initialized
INFO - 2020-08-25 16:45:23 --> Router Class Initialized
INFO - 2020-08-25 16:45:23 --> Output Class Initialized
INFO - 2020-08-25 16:45:23 --> Security Class Initialized
DEBUG - 2020-08-25 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:45:23 --> Input Class Initialized
INFO - 2020-08-25 16:45:23 --> Language Class Initialized
INFO - 2020-08-25 16:45:23 --> Language Class Initialized
INFO - 2020-08-25 16:45:23 --> Config Class Initialized
INFO - 2020-08-25 16:45:23 --> Loader Class Initialized
INFO - 2020-08-25 16:45:23 --> Helper loaded: url_helper
INFO - 2020-08-25 16:45:23 --> Helper loaded: form_helper
INFO - 2020-08-25 16:45:23 --> Helper loaded: file_helper
INFO - 2020-08-25 16:45:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:45:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:45:23 --> Upload Class Initialized
INFO - 2020-08-25 16:45:23 --> Controller Class Initialized
ERROR - 2020-08-25 16:45:23 --> 404 Page Not Found: /index
INFO - 2020-08-25 16:46:20 --> Config Class Initialized
INFO - 2020-08-25 16:46:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:46:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:46:20 --> Utf8 Class Initialized
INFO - 2020-08-25 16:46:20 --> URI Class Initialized
DEBUG - 2020-08-25 16:46:20 --> No URI present. Default controller set.
INFO - 2020-08-25 16:46:20 --> Router Class Initialized
INFO - 2020-08-25 16:46:20 --> Output Class Initialized
INFO - 2020-08-25 16:46:20 --> Security Class Initialized
DEBUG - 2020-08-25 16:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:46:20 --> Input Class Initialized
INFO - 2020-08-25 16:46:20 --> Language Class Initialized
INFO - 2020-08-25 16:46:20 --> Language Class Initialized
INFO - 2020-08-25 16:46:20 --> Config Class Initialized
INFO - 2020-08-25 16:46:20 --> Loader Class Initialized
INFO - 2020-08-25 16:46:20 --> Helper loaded: url_helper
INFO - 2020-08-25 16:46:20 --> Helper loaded: form_helper
INFO - 2020-08-25 16:46:20 --> Helper loaded: file_helper
INFO - 2020-08-25 16:46:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:46:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:46:20 --> Upload Class Initialized
INFO - 2020-08-25 16:46:20 --> Controller Class Initialized
DEBUG - 2020-08-25 16:46:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:46:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:46:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:46:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:46:20 --> Final output sent to browser
DEBUG - 2020-08-25 16:46:20 --> Total execution time: 0.0500
INFO - 2020-08-25 16:46:43 --> Config Class Initialized
INFO - 2020-08-25 16:46:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:46:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:46:43 --> Utf8 Class Initialized
INFO - 2020-08-25 16:46:43 --> URI Class Initialized
DEBUG - 2020-08-25 16:46:43 --> No URI present. Default controller set.
INFO - 2020-08-25 16:46:43 --> Router Class Initialized
INFO - 2020-08-25 16:46:43 --> Output Class Initialized
INFO - 2020-08-25 16:46:43 --> Security Class Initialized
DEBUG - 2020-08-25 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:46:43 --> Input Class Initialized
INFO - 2020-08-25 16:46:43 --> Language Class Initialized
INFO - 2020-08-25 16:46:43 --> Language Class Initialized
INFO - 2020-08-25 16:46:43 --> Config Class Initialized
INFO - 2020-08-25 16:46:43 --> Loader Class Initialized
INFO - 2020-08-25 16:46:43 --> Helper loaded: url_helper
INFO - 2020-08-25 16:46:43 --> Helper loaded: form_helper
INFO - 2020-08-25 16:46:43 --> Helper loaded: file_helper
INFO - 2020-08-25 16:46:43 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:46:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:46:43 --> Upload Class Initialized
INFO - 2020-08-25 16:46:43 --> Controller Class Initialized
DEBUG - 2020-08-25 16:46:43 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:46:43 --> Final output sent to browser
DEBUG - 2020-08-25 16:46:43 --> Total execution time: 0.0498
INFO - 2020-08-25 16:51:10 --> Config Class Initialized
INFO - 2020-08-25 16:51:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:51:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:51:10 --> Utf8 Class Initialized
INFO - 2020-08-25 16:51:10 --> URI Class Initialized
DEBUG - 2020-08-25 16:51:10 --> No URI present. Default controller set.
INFO - 2020-08-25 16:51:10 --> Router Class Initialized
INFO - 2020-08-25 16:51:10 --> Output Class Initialized
INFO - 2020-08-25 16:51:10 --> Security Class Initialized
DEBUG - 2020-08-25 16:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:51:10 --> Input Class Initialized
INFO - 2020-08-25 16:51:10 --> Language Class Initialized
INFO - 2020-08-25 16:51:10 --> Language Class Initialized
INFO - 2020-08-25 16:51:10 --> Config Class Initialized
INFO - 2020-08-25 16:51:10 --> Loader Class Initialized
INFO - 2020-08-25 16:51:10 --> Helper loaded: url_helper
INFO - 2020-08-25 16:51:10 --> Helper loaded: form_helper
INFO - 2020-08-25 16:51:10 --> Helper loaded: file_helper
INFO - 2020-08-25 16:51:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:51:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:51:10 --> Upload Class Initialized
INFO - 2020-08-25 16:51:10 --> Controller Class Initialized
DEBUG - 2020-08-25 16:51:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:51:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:51:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:51:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:51:10 --> Final output sent to browser
DEBUG - 2020-08-25 16:51:10 --> Total execution time: 0.0543
INFO - 2020-08-25 16:52:11 --> Config Class Initialized
INFO - 2020-08-25 16:52:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:52:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:52:11 --> Utf8 Class Initialized
INFO - 2020-08-25 16:52:11 --> URI Class Initialized
INFO - 2020-08-25 16:52:11 --> Router Class Initialized
INFO - 2020-08-25 16:52:11 --> Output Class Initialized
INFO - 2020-08-25 16:52:11 --> Security Class Initialized
DEBUG - 2020-08-25 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:52:11 --> Input Class Initialized
INFO - 2020-08-25 16:52:11 --> Language Class Initialized
INFO - 2020-08-25 16:52:11 --> Language Class Initialized
INFO - 2020-08-25 16:52:11 --> Config Class Initialized
INFO - 2020-08-25 16:52:11 --> Loader Class Initialized
INFO - 2020-08-25 16:52:11 --> Helper loaded: url_helper
INFO - 2020-08-25 16:52:11 --> Helper loaded: form_helper
INFO - 2020-08-25 16:52:11 --> Helper loaded: file_helper
INFO - 2020-08-25 16:52:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:52:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:52:11 --> Upload Class Initialized
INFO - 2020-08-25 16:52:11 --> Controller Class Initialized
ERROR - 2020-08-25 16:52:11 --> 404 Page Not Found: /index
INFO - 2020-08-25 16:54:52 --> Config Class Initialized
INFO - 2020-08-25 16:54:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:54:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:54:52 --> Utf8 Class Initialized
INFO - 2020-08-25 16:54:52 --> URI Class Initialized
DEBUG - 2020-08-25 16:54:52 --> No URI present. Default controller set.
INFO - 2020-08-25 16:54:52 --> Router Class Initialized
INFO - 2020-08-25 16:54:52 --> Output Class Initialized
INFO - 2020-08-25 16:54:52 --> Security Class Initialized
DEBUG - 2020-08-25 16:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:54:52 --> Input Class Initialized
INFO - 2020-08-25 16:54:52 --> Language Class Initialized
INFO - 2020-08-25 16:54:52 --> Language Class Initialized
INFO - 2020-08-25 16:54:52 --> Config Class Initialized
INFO - 2020-08-25 16:54:52 --> Loader Class Initialized
INFO - 2020-08-25 16:54:52 --> Helper loaded: url_helper
INFO - 2020-08-25 16:54:52 --> Helper loaded: form_helper
INFO - 2020-08-25 16:54:52 --> Helper loaded: file_helper
INFO - 2020-08-25 16:54:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:54:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:54:52 --> Upload Class Initialized
INFO - 2020-08-25 16:54:52 --> Controller Class Initialized
DEBUG - 2020-08-25 16:54:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 16:54:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 16:54:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 16:54:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 16:54:52 --> Final output sent to browser
DEBUG - 2020-08-25 16:54:52 --> Total execution time: 0.0567
INFO - 2020-08-25 16:54:54 --> Config Class Initialized
INFO - 2020-08-25 16:54:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 16:54:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 16:54:54 --> Utf8 Class Initialized
INFO - 2020-08-25 16:54:54 --> URI Class Initialized
INFO - 2020-08-25 16:54:54 --> Router Class Initialized
INFO - 2020-08-25 16:54:54 --> Output Class Initialized
INFO - 2020-08-25 16:54:54 --> Security Class Initialized
DEBUG - 2020-08-25 16:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 16:54:54 --> Input Class Initialized
INFO - 2020-08-25 16:54:54 --> Language Class Initialized
INFO - 2020-08-25 16:54:54 --> Language Class Initialized
INFO - 2020-08-25 16:54:54 --> Config Class Initialized
INFO - 2020-08-25 16:54:54 --> Loader Class Initialized
INFO - 2020-08-25 16:54:54 --> Helper loaded: url_helper
INFO - 2020-08-25 16:54:54 --> Helper loaded: form_helper
INFO - 2020-08-25 16:54:54 --> Helper loaded: file_helper
INFO - 2020-08-25 16:54:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 16:54:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 16:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 16:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 16:54:54 --> Upload Class Initialized
INFO - 2020-08-25 16:54:54 --> Controller Class Initialized
ERROR - 2020-08-25 16:54:54 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:03:02 --> Config Class Initialized
INFO - 2020-08-25 17:03:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:03:02 --> Utf8 Class Initialized
INFO - 2020-08-25 17:03:02 --> URI Class Initialized
INFO - 2020-08-25 17:03:02 --> Router Class Initialized
INFO - 2020-08-25 17:03:02 --> Output Class Initialized
INFO - 2020-08-25 17:03:02 --> Security Class Initialized
DEBUG - 2020-08-25 17:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:03:02 --> Input Class Initialized
INFO - 2020-08-25 17:03:02 --> Language Class Initialized
INFO - 2020-08-25 17:03:02 --> Language Class Initialized
INFO - 2020-08-25 17:03:02 --> Config Class Initialized
INFO - 2020-08-25 17:03:02 --> Loader Class Initialized
INFO - 2020-08-25 17:03:02 --> Helper loaded: url_helper
INFO - 2020-08-25 17:03:02 --> Helper loaded: form_helper
INFO - 2020-08-25 17:03:02 --> Helper loaded: file_helper
INFO - 2020-08-25 17:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:03:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:03:02 --> Upload Class Initialized
INFO - 2020-08-25 17:03:02 --> Controller Class Initialized
DEBUG - 2020-08-25 17:03:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:03:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:03:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:03:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:03:02 --> Final output sent to browser
DEBUG - 2020-08-25 17:03:02 --> Total execution time: 0.2327
INFO - 2020-08-25 17:07:26 --> Config Class Initialized
INFO - 2020-08-25 17:07:26 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:07:26 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:07:26 --> Utf8 Class Initialized
INFO - 2020-08-25 17:07:26 --> URI Class Initialized
INFO - 2020-08-25 17:07:26 --> Router Class Initialized
INFO - 2020-08-25 17:07:26 --> Output Class Initialized
INFO - 2020-08-25 17:07:26 --> Security Class Initialized
DEBUG - 2020-08-25 17:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:07:26 --> Input Class Initialized
INFO - 2020-08-25 17:07:26 --> Language Class Initialized
INFO - 2020-08-25 17:07:26 --> Language Class Initialized
INFO - 2020-08-25 17:07:26 --> Config Class Initialized
INFO - 2020-08-25 17:07:26 --> Loader Class Initialized
INFO - 2020-08-25 17:07:26 --> Helper loaded: url_helper
INFO - 2020-08-25 17:07:26 --> Helper loaded: form_helper
INFO - 2020-08-25 17:07:26 --> Helper loaded: file_helper
INFO - 2020-08-25 17:07:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:07:26 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:07:26 --> Upload Class Initialized
INFO - 2020-08-25 17:07:26 --> Controller Class Initialized
DEBUG - 2020-08-25 17:07:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:07:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:07:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:07:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:07:26 --> Final output sent to browser
DEBUG - 2020-08-25 17:07:26 --> Total execution time: 0.0534
INFO - 2020-08-25 17:07:28 --> Config Class Initialized
INFO - 2020-08-25 17:07:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:07:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:07:28 --> Utf8 Class Initialized
INFO - 2020-08-25 17:07:28 --> URI Class Initialized
INFO - 2020-08-25 17:07:28 --> Router Class Initialized
INFO - 2020-08-25 17:07:28 --> Output Class Initialized
INFO - 2020-08-25 17:07:28 --> Security Class Initialized
DEBUG - 2020-08-25 17:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:07:28 --> Input Class Initialized
INFO - 2020-08-25 17:07:28 --> Language Class Initialized
INFO - 2020-08-25 17:07:28 --> Language Class Initialized
INFO - 2020-08-25 17:07:28 --> Config Class Initialized
INFO - 2020-08-25 17:07:28 --> Loader Class Initialized
INFO - 2020-08-25 17:07:28 --> Helper loaded: url_helper
INFO - 2020-08-25 17:07:28 --> Helper loaded: form_helper
INFO - 2020-08-25 17:07:28 --> Helper loaded: file_helper
INFO - 2020-08-25 17:07:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:07:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:07:28 --> Upload Class Initialized
INFO - 2020-08-25 17:07:28 --> Controller Class Initialized
ERROR - 2020-08-25 17:07:28 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:07:35 --> Config Class Initialized
INFO - 2020-08-25 17:07:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:07:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:07:35 --> Utf8 Class Initialized
INFO - 2020-08-25 17:07:35 --> URI Class Initialized
INFO - 2020-08-25 17:07:35 --> Router Class Initialized
INFO - 2020-08-25 17:07:35 --> Output Class Initialized
INFO - 2020-08-25 17:07:35 --> Security Class Initialized
DEBUG - 2020-08-25 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:07:35 --> Input Class Initialized
INFO - 2020-08-25 17:07:35 --> Language Class Initialized
INFO - 2020-08-25 17:07:35 --> Language Class Initialized
INFO - 2020-08-25 17:07:35 --> Config Class Initialized
INFO - 2020-08-25 17:07:35 --> Loader Class Initialized
INFO - 2020-08-25 17:07:35 --> Helper loaded: url_helper
INFO - 2020-08-25 17:07:35 --> Helper loaded: form_helper
INFO - 2020-08-25 17:07:35 --> Helper loaded: file_helper
INFO - 2020-08-25 17:07:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:07:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:07:35 --> Upload Class Initialized
INFO - 2020-08-25 17:07:35 --> Controller Class Initialized
DEBUG - 2020-08-25 17:07:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:07:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:07:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:07:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:07:35 --> Final output sent to browser
DEBUG - 2020-08-25 17:07:35 --> Total execution time: 0.0498
INFO - 2020-08-25 17:07:36 --> Config Class Initialized
INFO - 2020-08-25 17:07:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:07:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:07:36 --> Utf8 Class Initialized
INFO - 2020-08-25 17:07:36 --> URI Class Initialized
INFO - 2020-08-25 17:07:36 --> Router Class Initialized
INFO - 2020-08-25 17:07:36 --> Output Class Initialized
INFO - 2020-08-25 17:07:36 --> Security Class Initialized
DEBUG - 2020-08-25 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:07:36 --> Input Class Initialized
INFO - 2020-08-25 17:07:36 --> Language Class Initialized
INFO - 2020-08-25 17:07:36 --> Language Class Initialized
INFO - 2020-08-25 17:07:36 --> Config Class Initialized
INFO - 2020-08-25 17:07:36 --> Loader Class Initialized
INFO - 2020-08-25 17:07:36 --> Helper loaded: url_helper
INFO - 2020-08-25 17:07:36 --> Helper loaded: form_helper
INFO - 2020-08-25 17:07:36 --> Helper loaded: file_helper
INFO - 2020-08-25 17:07:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:07:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:07:36 --> Upload Class Initialized
INFO - 2020-08-25 17:07:36 --> Controller Class Initialized
ERROR - 2020-08-25 17:07:36 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:17:36 --> Config Class Initialized
INFO - 2020-08-25 17:17:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:17:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:17:36 --> Utf8 Class Initialized
INFO - 2020-08-25 17:17:36 --> URI Class Initialized
INFO - 2020-08-25 17:17:36 --> Router Class Initialized
INFO - 2020-08-25 17:17:36 --> Output Class Initialized
INFO - 2020-08-25 17:17:36 --> Security Class Initialized
DEBUG - 2020-08-25 17:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:17:36 --> Input Class Initialized
INFO - 2020-08-25 17:17:36 --> Language Class Initialized
INFO - 2020-08-25 17:17:36 --> Language Class Initialized
INFO - 2020-08-25 17:17:36 --> Config Class Initialized
INFO - 2020-08-25 17:17:36 --> Loader Class Initialized
INFO - 2020-08-25 17:17:36 --> Helper loaded: url_helper
INFO - 2020-08-25 17:17:36 --> Helper loaded: form_helper
INFO - 2020-08-25 17:17:36 --> Helper loaded: file_helper
INFO - 2020-08-25 17:17:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:17:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:17:36 --> Upload Class Initialized
INFO - 2020-08-25 17:17:36 --> Controller Class Initialized
DEBUG - 2020-08-25 17:17:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:17:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:17:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:17:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:17:36 --> Final output sent to browser
DEBUG - 2020-08-25 17:17:36 --> Total execution time: 0.0530
INFO - 2020-08-25 17:17:41 --> Config Class Initialized
INFO - 2020-08-25 17:17:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:17:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:17:41 --> Utf8 Class Initialized
INFO - 2020-08-25 17:17:41 --> URI Class Initialized
DEBUG - 2020-08-25 17:17:41 --> No URI present. Default controller set.
INFO - 2020-08-25 17:17:41 --> Router Class Initialized
INFO - 2020-08-25 17:17:41 --> Output Class Initialized
INFO - 2020-08-25 17:17:41 --> Security Class Initialized
DEBUG - 2020-08-25 17:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:17:41 --> Input Class Initialized
INFO - 2020-08-25 17:17:41 --> Language Class Initialized
INFO - 2020-08-25 17:17:41 --> Language Class Initialized
INFO - 2020-08-25 17:17:41 --> Config Class Initialized
INFO - 2020-08-25 17:17:41 --> Loader Class Initialized
INFO - 2020-08-25 17:17:41 --> Helper loaded: url_helper
INFO - 2020-08-25 17:17:41 --> Helper loaded: form_helper
INFO - 2020-08-25 17:17:41 --> Helper loaded: file_helper
INFO - 2020-08-25 17:17:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:17:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:17:41 --> Upload Class Initialized
INFO - 2020-08-25 17:17:41 --> Controller Class Initialized
DEBUG - 2020-08-25 17:17:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:17:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:17:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:17:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:17:41 --> Final output sent to browser
DEBUG - 2020-08-25 17:17:41 --> Total execution time: 0.0526
INFO - 2020-08-25 17:21:59 --> Config Class Initialized
INFO - 2020-08-25 17:21:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:21:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:21:59 --> Utf8 Class Initialized
INFO - 2020-08-25 17:21:59 --> URI Class Initialized
DEBUG - 2020-08-25 17:21:59 --> No URI present. Default controller set.
INFO - 2020-08-25 17:21:59 --> Router Class Initialized
INFO - 2020-08-25 17:21:59 --> Output Class Initialized
INFO - 2020-08-25 17:21:59 --> Security Class Initialized
DEBUG - 2020-08-25 17:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:21:59 --> Input Class Initialized
INFO - 2020-08-25 17:21:59 --> Language Class Initialized
INFO - 2020-08-25 17:21:59 --> Language Class Initialized
INFO - 2020-08-25 17:21:59 --> Config Class Initialized
INFO - 2020-08-25 17:21:59 --> Loader Class Initialized
INFO - 2020-08-25 17:21:59 --> Helper loaded: url_helper
INFO - 2020-08-25 17:21:59 --> Helper loaded: form_helper
INFO - 2020-08-25 17:21:59 --> Helper loaded: file_helper
INFO - 2020-08-25 17:21:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:21:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:21:59 --> Upload Class Initialized
INFO - 2020-08-25 17:21:59 --> Controller Class Initialized
DEBUG - 2020-08-25 17:21:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:21:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:21:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:21:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:21:59 --> Final output sent to browser
DEBUG - 2020-08-25 17:21:59 --> Total execution time: 0.0502
INFO - 2020-08-25 17:23:06 --> Config Class Initialized
INFO - 2020-08-25 17:23:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:23:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:23:06 --> Utf8 Class Initialized
INFO - 2020-08-25 17:23:06 --> URI Class Initialized
INFO - 2020-08-25 17:23:06 --> Router Class Initialized
INFO - 2020-08-25 17:23:06 --> Output Class Initialized
INFO - 2020-08-25 17:23:06 --> Security Class Initialized
DEBUG - 2020-08-25 17:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:23:06 --> Input Class Initialized
INFO - 2020-08-25 17:23:06 --> Language Class Initialized
INFO - 2020-08-25 17:23:06 --> Language Class Initialized
INFO - 2020-08-25 17:23:06 --> Config Class Initialized
INFO - 2020-08-25 17:23:06 --> Loader Class Initialized
INFO - 2020-08-25 17:23:06 --> Helper loaded: url_helper
INFO - 2020-08-25 17:23:06 --> Helper loaded: form_helper
INFO - 2020-08-25 17:23:06 --> Helper loaded: file_helper
INFO - 2020-08-25 17:23:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:23:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:23:06 --> Upload Class Initialized
INFO - 2020-08-25 17:23:06 --> Controller Class Initialized
ERROR - 2020-08-25 17:23:06 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:24:28 --> Config Class Initialized
INFO - 2020-08-25 17:24:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:24:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:24:28 --> Utf8 Class Initialized
INFO - 2020-08-25 17:24:28 --> URI Class Initialized
DEBUG - 2020-08-25 17:24:28 --> No URI present. Default controller set.
INFO - 2020-08-25 17:24:28 --> Router Class Initialized
INFO - 2020-08-25 17:24:28 --> Output Class Initialized
INFO - 2020-08-25 17:24:28 --> Security Class Initialized
DEBUG - 2020-08-25 17:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:24:28 --> Input Class Initialized
INFO - 2020-08-25 17:24:28 --> Language Class Initialized
INFO - 2020-08-25 17:24:28 --> Language Class Initialized
INFO - 2020-08-25 17:24:28 --> Config Class Initialized
INFO - 2020-08-25 17:24:28 --> Loader Class Initialized
INFO - 2020-08-25 17:24:28 --> Helper loaded: url_helper
INFO - 2020-08-25 17:24:28 --> Helper loaded: form_helper
INFO - 2020-08-25 17:24:28 --> Helper loaded: file_helper
INFO - 2020-08-25 17:24:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:24:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:24:28 --> Upload Class Initialized
INFO - 2020-08-25 17:24:28 --> Controller Class Initialized
DEBUG - 2020-08-25 17:24:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:24:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:24:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:24:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:24:28 --> Final output sent to browser
DEBUG - 2020-08-25 17:24:28 --> Total execution time: 0.0472
INFO - 2020-08-25 17:38:10 --> Config Class Initialized
INFO - 2020-08-25 17:38:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:38:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:38:10 --> Utf8 Class Initialized
INFO - 2020-08-25 17:38:10 --> URI Class Initialized
DEBUG - 2020-08-25 17:38:10 --> No URI present. Default controller set.
INFO - 2020-08-25 17:38:10 --> Router Class Initialized
INFO - 2020-08-25 17:38:10 --> Output Class Initialized
INFO - 2020-08-25 17:38:10 --> Security Class Initialized
DEBUG - 2020-08-25 17:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:38:10 --> Input Class Initialized
INFO - 2020-08-25 17:38:10 --> Language Class Initialized
INFO - 2020-08-25 17:38:10 --> Language Class Initialized
INFO - 2020-08-25 17:38:10 --> Config Class Initialized
INFO - 2020-08-25 17:38:10 --> Loader Class Initialized
INFO - 2020-08-25 17:38:10 --> Helper loaded: url_helper
INFO - 2020-08-25 17:38:10 --> Helper loaded: form_helper
INFO - 2020-08-25 17:38:10 --> Helper loaded: file_helper
INFO - 2020-08-25 17:38:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:38:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:38:10 --> Upload Class Initialized
INFO - 2020-08-25 17:38:10 --> Controller Class Initialized
DEBUG - 2020-08-25 17:38:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:38:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:38:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:38:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:38:10 --> Final output sent to browser
DEBUG - 2020-08-25 17:38:10 --> Total execution time: 0.0510
INFO - 2020-08-25 17:38:13 --> Config Class Initialized
INFO - 2020-08-25 17:38:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:38:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:38:13 --> Utf8 Class Initialized
INFO - 2020-08-25 17:38:13 --> URI Class Initialized
INFO - 2020-08-25 17:38:13 --> Router Class Initialized
INFO - 2020-08-25 17:38:13 --> Output Class Initialized
INFO - 2020-08-25 17:38:13 --> Security Class Initialized
DEBUG - 2020-08-25 17:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:38:13 --> Input Class Initialized
INFO - 2020-08-25 17:38:13 --> Language Class Initialized
INFO - 2020-08-25 17:38:13 --> Language Class Initialized
INFO - 2020-08-25 17:38:13 --> Config Class Initialized
INFO - 2020-08-25 17:38:13 --> Loader Class Initialized
INFO - 2020-08-25 17:38:13 --> Helper loaded: url_helper
INFO - 2020-08-25 17:38:13 --> Helper loaded: form_helper
INFO - 2020-08-25 17:38:13 --> Helper loaded: file_helper
INFO - 2020-08-25 17:38:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:38:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:38:13 --> Upload Class Initialized
INFO - 2020-08-25 17:38:13 --> Controller Class Initialized
ERROR - 2020-08-25 17:38:13 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:38:24 --> Config Class Initialized
INFO - 2020-08-25 17:38:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:38:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:38:24 --> Utf8 Class Initialized
INFO - 2020-08-25 17:38:24 --> URI Class Initialized
INFO - 2020-08-25 17:38:24 --> Router Class Initialized
INFO - 2020-08-25 17:38:24 --> Output Class Initialized
INFO - 2020-08-25 17:38:24 --> Security Class Initialized
DEBUG - 2020-08-25 17:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:38:24 --> Input Class Initialized
INFO - 2020-08-25 17:38:24 --> Language Class Initialized
INFO - 2020-08-25 17:38:24 --> Language Class Initialized
INFO - 2020-08-25 17:38:24 --> Config Class Initialized
INFO - 2020-08-25 17:38:24 --> Loader Class Initialized
INFO - 2020-08-25 17:38:24 --> Helper loaded: url_helper
INFO - 2020-08-25 17:38:24 --> Helper loaded: form_helper
INFO - 2020-08-25 17:38:24 --> Helper loaded: file_helper
INFO - 2020-08-25 17:38:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:38:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:38:24 --> Upload Class Initialized
INFO - 2020-08-25 17:38:24 --> Controller Class Initialized
DEBUG - 2020-08-25 17:38:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:38:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:38:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:38:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:38:24 --> Final output sent to browser
DEBUG - 2020-08-25 17:38:24 --> Total execution time: 0.0490
INFO - 2020-08-25 17:44:23 --> Config Class Initialized
INFO - 2020-08-25 17:44:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:23 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:23 --> URI Class Initialized
INFO - 2020-08-25 17:44:23 --> Router Class Initialized
INFO - 2020-08-25 17:44:23 --> Output Class Initialized
INFO - 2020-08-25 17:44:23 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:23 --> Input Class Initialized
INFO - 2020-08-25 17:44:23 --> Language Class Initialized
INFO - 2020-08-25 17:44:23 --> Language Class Initialized
INFO - 2020-08-25 17:44:23 --> Config Class Initialized
INFO - 2020-08-25 17:44:23 --> Loader Class Initialized
INFO - 2020-08-25 17:44:23 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:23 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:23 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:23 --> Upload Class Initialized
INFO - 2020-08-25 17:44:23 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-25 17:44:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:23 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:23 --> Total execution time: 0.0516
INFO - 2020-08-25 17:44:27 --> Config Class Initialized
INFO - 2020-08-25 17:44:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:27 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:27 --> URI Class Initialized
INFO - 2020-08-25 17:44:27 --> Router Class Initialized
INFO - 2020-08-25 17:44:27 --> Output Class Initialized
INFO - 2020-08-25 17:44:27 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:27 --> Input Class Initialized
INFO - 2020-08-25 17:44:27 --> Language Class Initialized
INFO - 2020-08-25 17:44:27 --> Language Class Initialized
INFO - 2020-08-25 17:44:27 --> Config Class Initialized
INFO - 2020-08-25 17:44:27 --> Loader Class Initialized
INFO - 2020-08-25 17:44:27 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:27 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:27 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:27 --> Upload Class Initialized
INFO - 2020-08-25 17:44:27 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:27 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:30 --> Config Class Initialized
INFO - 2020-08-25 17:44:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:30 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:30 --> URI Class Initialized
INFO - 2020-08-25 17:44:30 --> Router Class Initialized
INFO - 2020-08-25 17:44:30 --> Output Class Initialized
INFO - 2020-08-25 17:44:30 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:30 --> Input Class Initialized
INFO - 2020-08-25 17:44:30 --> Language Class Initialized
INFO - 2020-08-25 17:44:30 --> Language Class Initialized
INFO - 2020-08-25 17:44:30 --> Config Class Initialized
INFO - 2020-08-25 17:44:30 --> Loader Class Initialized
INFO - 2020-08-25 17:44:30 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:30 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:30 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:30 --> Upload Class Initialized
INFO - 2020-08-25 17:44:30 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-25 17:44:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:30 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:30 --> Total execution time: 0.0538
INFO - 2020-08-25 17:44:30 --> Config Class Initialized
INFO - 2020-08-25 17:44:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:30 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:30 --> URI Class Initialized
INFO - 2020-08-25 17:44:30 --> Router Class Initialized
INFO - 2020-08-25 17:44:30 --> Output Class Initialized
INFO - 2020-08-25 17:44:30 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:30 --> Input Class Initialized
INFO - 2020-08-25 17:44:30 --> Language Class Initialized
INFO - 2020-08-25 17:44:30 --> Language Class Initialized
INFO - 2020-08-25 17:44:30 --> Config Class Initialized
INFO - 2020-08-25 17:44:30 --> Loader Class Initialized
INFO - 2020-08-25 17:44:30 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:30 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:30 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:30 --> Upload Class Initialized
INFO - 2020-08-25 17:44:31 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:31 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:34 --> Config Class Initialized
INFO - 2020-08-25 17:44:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:34 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:34 --> URI Class Initialized
INFO - 2020-08-25 17:44:34 --> Router Class Initialized
INFO - 2020-08-25 17:44:34 --> Output Class Initialized
INFO - 2020-08-25 17:44:34 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:34 --> Input Class Initialized
INFO - 2020-08-25 17:44:34 --> Language Class Initialized
INFO - 2020-08-25 17:44:34 --> Language Class Initialized
INFO - 2020-08-25 17:44:34 --> Config Class Initialized
INFO - 2020-08-25 17:44:34 --> Loader Class Initialized
INFO - 2020-08-25 17:44:34 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:34 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:34 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:34 --> Upload Class Initialized
INFO - 2020-08-25 17:44:34 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-25 17:44:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:34 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:34 --> Total execution time: 0.0540
INFO - 2020-08-25 17:44:34 --> Config Class Initialized
INFO - 2020-08-25 17:44:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:34 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:34 --> URI Class Initialized
INFO - 2020-08-25 17:44:34 --> Router Class Initialized
INFO - 2020-08-25 17:44:34 --> Output Class Initialized
INFO - 2020-08-25 17:44:34 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:34 --> Input Class Initialized
INFO - 2020-08-25 17:44:34 --> Language Class Initialized
INFO - 2020-08-25 17:44:34 --> Language Class Initialized
INFO - 2020-08-25 17:44:34 --> Config Class Initialized
INFO - 2020-08-25 17:44:34 --> Loader Class Initialized
INFO - 2020-08-25 17:44:34 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:34 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:34 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:34 --> Upload Class Initialized
INFO - 2020-08-25 17:44:34 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:34 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:39 --> Config Class Initialized
INFO - 2020-08-25 17:44:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:39 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:39 --> URI Class Initialized
DEBUG - 2020-08-25 17:44:39 --> No URI present. Default controller set.
INFO - 2020-08-25 17:44:39 --> Router Class Initialized
INFO - 2020-08-25 17:44:39 --> Output Class Initialized
INFO - 2020-08-25 17:44:39 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:39 --> Input Class Initialized
INFO - 2020-08-25 17:44:39 --> Language Class Initialized
INFO - 2020-08-25 17:44:39 --> Language Class Initialized
INFO - 2020-08-25 17:44:39 --> Config Class Initialized
INFO - 2020-08-25 17:44:39 --> Loader Class Initialized
INFO - 2020-08-25 17:44:39 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:39 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:39 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:39 --> Upload Class Initialized
INFO - 2020-08-25 17:44:39 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:44:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:44:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:39 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:39 --> Total execution time: 0.0515
INFO - 2020-08-25 17:44:40 --> Config Class Initialized
INFO - 2020-08-25 17:44:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:40 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:40 --> URI Class Initialized
DEBUG - 2020-08-25 17:44:40 --> No URI present. Default controller set.
INFO - 2020-08-25 17:44:40 --> Router Class Initialized
INFO - 2020-08-25 17:44:40 --> Output Class Initialized
INFO - 2020-08-25 17:44:40 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:40 --> Input Class Initialized
INFO - 2020-08-25 17:44:40 --> Language Class Initialized
INFO - 2020-08-25 17:44:40 --> Language Class Initialized
INFO - 2020-08-25 17:44:40 --> Config Class Initialized
INFO - 2020-08-25 17:44:40 --> Loader Class Initialized
INFO - 2020-08-25 17:44:40 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:40 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:40 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:40 --> Upload Class Initialized
INFO - 2020-08-25 17:44:40 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:44:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:44:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:40 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:40 --> Total execution time: 0.0531
INFO - 2020-08-25 17:44:41 --> Config Class Initialized
INFO - 2020-08-25 17:44:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:41 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:41 --> URI Class Initialized
INFO - 2020-08-25 17:44:41 --> Router Class Initialized
INFO - 2020-08-25 17:44:41 --> Output Class Initialized
INFO - 2020-08-25 17:44:41 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:41 --> Input Class Initialized
INFO - 2020-08-25 17:44:41 --> Language Class Initialized
INFO - 2020-08-25 17:44:41 --> Language Class Initialized
INFO - 2020-08-25 17:44:41 --> Config Class Initialized
INFO - 2020-08-25 17:44:41 --> Loader Class Initialized
INFO - 2020-08-25 17:44:41 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:41 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:41 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:41 --> Upload Class Initialized
INFO - 2020-08-25 17:44:41 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:41 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:44 --> Config Class Initialized
INFO - 2020-08-25 17:44:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:44 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:44 --> URI Class Initialized
INFO - 2020-08-25 17:44:44 --> Router Class Initialized
INFO - 2020-08-25 17:44:44 --> Output Class Initialized
INFO - 2020-08-25 17:44:44 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:44 --> Input Class Initialized
INFO - 2020-08-25 17:44:44 --> Language Class Initialized
INFO - 2020-08-25 17:44:44 --> Language Class Initialized
INFO - 2020-08-25 17:44:44 --> Config Class Initialized
INFO - 2020-08-25 17:44:44 --> Loader Class Initialized
INFO - 2020-08-25 17:44:44 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:44 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:44 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:44 --> Upload Class Initialized
INFO - 2020-08-25 17:44:44 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:44 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:44 --> Config Class Initialized
INFO - 2020-08-25 17:44:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:44 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:44 --> URI Class Initialized
INFO - 2020-08-25 17:44:44 --> Router Class Initialized
INFO - 2020-08-25 17:44:44 --> Output Class Initialized
INFO - 2020-08-25 17:44:44 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:44 --> Input Class Initialized
INFO - 2020-08-25 17:44:44 --> Language Class Initialized
INFO - 2020-08-25 17:44:44 --> Language Class Initialized
INFO - 2020-08-25 17:44:44 --> Config Class Initialized
INFO - 2020-08-25 17:44:44 --> Loader Class Initialized
INFO - 2020-08-25 17:44:44 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:44 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:44 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:44 --> Upload Class Initialized
INFO - 2020-08-25 17:44:44 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:44 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:46 --> Config Class Initialized
INFO - 2020-08-25 17:44:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:46 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:46 --> URI Class Initialized
INFO - 2020-08-25 17:44:46 --> Router Class Initialized
INFO - 2020-08-25 17:44:46 --> Output Class Initialized
INFO - 2020-08-25 17:44:46 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:46 --> Input Class Initialized
INFO - 2020-08-25 17:44:46 --> Language Class Initialized
INFO - 2020-08-25 17:44:46 --> Language Class Initialized
INFO - 2020-08-25 17:44:46 --> Config Class Initialized
INFO - 2020-08-25 17:44:46 --> Loader Class Initialized
INFO - 2020-08-25 17:44:46 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:46 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:46 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:46 --> Upload Class Initialized
INFO - 2020-08-25 17:44:46 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-25 17:44:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:46 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:46 --> Total execution time: 0.0512
INFO - 2020-08-25 17:44:47 --> Config Class Initialized
INFO - 2020-08-25 17:44:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:47 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:47 --> URI Class Initialized
INFO - 2020-08-25 17:44:47 --> Router Class Initialized
INFO - 2020-08-25 17:44:47 --> Output Class Initialized
INFO - 2020-08-25 17:44:47 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:47 --> Input Class Initialized
INFO - 2020-08-25 17:44:47 --> Language Class Initialized
INFO - 2020-08-25 17:44:47 --> Language Class Initialized
INFO - 2020-08-25 17:44:47 --> Config Class Initialized
INFO - 2020-08-25 17:44:47 --> Loader Class Initialized
INFO - 2020-08-25 17:44:47 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:47 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:47 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:47 --> Upload Class Initialized
INFO - 2020-08-25 17:44:47 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:47 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:44:52 --> Config Class Initialized
INFO - 2020-08-25 17:44:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:52 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:52 --> URI Class Initialized
INFO - 2020-08-25 17:44:52 --> Router Class Initialized
INFO - 2020-08-25 17:44:52 --> Output Class Initialized
INFO - 2020-08-25 17:44:52 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:52 --> Input Class Initialized
INFO - 2020-08-25 17:44:52 --> Language Class Initialized
INFO - 2020-08-25 17:44:52 --> Language Class Initialized
INFO - 2020-08-25 17:44:52 --> Config Class Initialized
INFO - 2020-08-25 17:44:52 --> Loader Class Initialized
INFO - 2020-08-25 17:44:52 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:52 --> Upload Class Initialized
INFO - 2020-08-25 17:44:52 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-25 17:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:52 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:52 --> Total execution time: 0.0542
INFO - 2020-08-25 17:44:52 --> Config Class Initialized
INFO - 2020-08-25 17:44:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:52 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:52 --> URI Class Initialized
INFO - 2020-08-25 17:44:52 --> Router Class Initialized
INFO - 2020-08-25 17:44:52 --> Output Class Initialized
INFO - 2020-08-25 17:44:52 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:52 --> Input Class Initialized
INFO - 2020-08-25 17:44:52 --> Language Class Initialized
INFO - 2020-08-25 17:44:52 --> Language Class Initialized
INFO - 2020-08-25 17:44:52 --> Config Class Initialized
INFO - 2020-08-25 17:44:52 --> Loader Class Initialized
INFO - 2020-08-25 17:44:52 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:52 --> Upload Class Initialized
INFO - 2020-08-25 17:44:52 --> Controller Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:44:52 --> Final output sent to browser
DEBUG - 2020-08-25 17:44:52 --> Total execution time: 0.0494
INFO - 2020-08-25 17:44:52 --> Config Class Initialized
INFO - 2020-08-25 17:44:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:44:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:44:52 --> Utf8 Class Initialized
INFO - 2020-08-25 17:44:52 --> URI Class Initialized
INFO - 2020-08-25 17:44:52 --> Router Class Initialized
INFO - 2020-08-25 17:44:52 --> Output Class Initialized
INFO - 2020-08-25 17:44:52 --> Security Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:44:52 --> Input Class Initialized
INFO - 2020-08-25 17:44:52 --> Language Class Initialized
INFO - 2020-08-25 17:44:52 --> Language Class Initialized
INFO - 2020-08-25 17:44:52 --> Config Class Initialized
INFO - 2020-08-25 17:44:52 --> Loader Class Initialized
INFO - 2020-08-25 17:44:52 --> Helper loaded: url_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: form_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: file_helper
INFO - 2020-08-25 17:44:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:44:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:44:52 --> Upload Class Initialized
INFO - 2020-08-25 17:44:52 --> Controller Class Initialized
ERROR - 2020-08-25 17:44:52 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:45:25 --> Config Class Initialized
INFO - 2020-08-25 17:45:25 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:45:25 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:45:25 --> Utf8 Class Initialized
INFO - 2020-08-25 17:45:25 --> URI Class Initialized
DEBUG - 2020-08-25 17:45:25 --> No URI present. Default controller set.
INFO - 2020-08-25 17:45:25 --> Router Class Initialized
INFO - 2020-08-25 17:45:25 --> Output Class Initialized
INFO - 2020-08-25 17:45:25 --> Security Class Initialized
DEBUG - 2020-08-25 17:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:45:25 --> Input Class Initialized
INFO - 2020-08-25 17:45:25 --> Language Class Initialized
INFO - 2020-08-25 17:45:25 --> Language Class Initialized
INFO - 2020-08-25 17:45:25 --> Config Class Initialized
INFO - 2020-08-25 17:45:25 --> Loader Class Initialized
INFO - 2020-08-25 17:45:25 --> Helper loaded: url_helper
INFO - 2020-08-25 17:45:25 --> Helper loaded: form_helper
INFO - 2020-08-25 17:45:25 --> Helper loaded: file_helper
INFO - 2020-08-25 17:45:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:45:25 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:45:25 --> Upload Class Initialized
INFO - 2020-08-25 17:45:25 --> Controller Class Initialized
DEBUG - 2020-08-25 17:45:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:45:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:45:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:45:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:45:25 --> Final output sent to browser
DEBUG - 2020-08-25 17:45:25 --> Total execution time: 0.0528
INFO - 2020-08-25 17:45:32 --> Config Class Initialized
INFO - 2020-08-25 17:45:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:45:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:45:32 --> Utf8 Class Initialized
INFO - 2020-08-25 17:45:32 --> URI Class Initialized
DEBUG - 2020-08-25 17:45:32 --> No URI present. Default controller set.
INFO - 2020-08-25 17:45:32 --> Router Class Initialized
INFO - 2020-08-25 17:45:32 --> Output Class Initialized
INFO - 2020-08-25 17:45:32 --> Security Class Initialized
DEBUG - 2020-08-25 17:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:45:32 --> Input Class Initialized
INFO - 2020-08-25 17:45:32 --> Language Class Initialized
INFO - 2020-08-25 17:45:32 --> Language Class Initialized
INFO - 2020-08-25 17:45:32 --> Config Class Initialized
INFO - 2020-08-25 17:45:32 --> Loader Class Initialized
INFO - 2020-08-25 17:45:32 --> Helper loaded: url_helper
INFO - 2020-08-25 17:45:32 --> Helper loaded: form_helper
INFO - 2020-08-25 17:45:32 --> Helper loaded: file_helper
INFO - 2020-08-25 17:45:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:45:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:45:32 --> Upload Class Initialized
INFO - 2020-08-25 17:45:32 --> Controller Class Initialized
DEBUG - 2020-08-25 17:45:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:45:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:45:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:45:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:45:32 --> Final output sent to browser
DEBUG - 2020-08-25 17:45:32 --> Total execution time: 0.0493
INFO - 2020-08-25 17:50:57 --> Config Class Initialized
INFO - 2020-08-25 17:50:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:50:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:50:57 --> Utf8 Class Initialized
INFO - 2020-08-25 17:50:57 --> URI Class Initialized
INFO - 2020-08-25 17:50:57 --> Router Class Initialized
INFO - 2020-08-25 17:50:57 --> Output Class Initialized
INFO - 2020-08-25 17:50:57 --> Security Class Initialized
DEBUG - 2020-08-25 17:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:50:57 --> Input Class Initialized
INFO - 2020-08-25 17:50:57 --> Language Class Initialized
INFO - 2020-08-25 17:50:57 --> Language Class Initialized
INFO - 2020-08-25 17:50:57 --> Config Class Initialized
INFO - 2020-08-25 17:50:57 --> Loader Class Initialized
INFO - 2020-08-25 17:50:57 --> Helper loaded: url_helper
INFO - 2020-08-25 17:50:57 --> Helper loaded: form_helper
INFO - 2020-08-25 17:50:57 --> Helper loaded: file_helper
INFO - 2020-08-25 17:50:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:50:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:50:57 --> Upload Class Initialized
INFO - 2020-08-25 17:50:57 --> Controller Class Initialized
DEBUG - 2020-08-25 17:50:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:50:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:50:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:50:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:50:57 --> Final output sent to browser
DEBUG - 2020-08-25 17:50:57 --> Total execution time: 0.0530
INFO - 2020-08-25 17:51:01 --> Config Class Initialized
INFO - 2020-08-25 17:51:01 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:51:01 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:51:01 --> Utf8 Class Initialized
INFO - 2020-08-25 17:51:01 --> URI Class Initialized
INFO - 2020-08-25 17:51:01 --> Router Class Initialized
INFO - 2020-08-25 17:51:01 --> Output Class Initialized
INFO - 2020-08-25 17:51:01 --> Security Class Initialized
DEBUG - 2020-08-25 17:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:51:01 --> Input Class Initialized
INFO - 2020-08-25 17:51:01 --> Language Class Initialized
INFO - 2020-08-25 17:51:01 --> Language Class Initialized
INFO - 2020-08-25 17:51:01 --> Config Class Initialized
INFO - 2020-08-25 17:51:01 --> Loader Class Initialized
INFO - 2020-08-25 17:51:01 --> Helper loaded: url_helper
INFO - 2020-08-25 17:51:01 --> Helper loaded: form_helper
INFO - 2020-08-25 17:51:01 --> Helper loaded: file_helper
INFO - 2020-08-25 17:51:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:51:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:51:01 --> Upload Class Initialized
INFO - 2020-08-25 17:51:01 --> Controller Class Initialized
ERROR - 2020-08-25 17:51:01 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:51:06 --> Config Class Initialized
INFO - 2020-08-25 17:51:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:51:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:51:06 --> Utf8 Class Initialized
INFO - 2020-08-25 17:51:06 --> URI Class Initialized
INFO - 2020-08-25 17:51:06 --> Router Class Initialized
INFO - 2020-08-25 17:51:06 --> Output Class Initialized
INFO - 2020-08-25 17:51:06 --> Security Class Initialized
DEBUG - 2020-08-25 17:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:51:06 --> Input Class Initialized
INFO - 2020-08-25 17:51:06 --> Language Class Initialized
INFO - 2020-08-25 17:51:06 --> Language Class Initialized
INFO - 2020-08-25 17:51:06 --> Config Class Initialized
INFO - 2020-08-25 17:51:06 --> Loader Class Initialized
INFO - 2020-08-25 17:51:06 --> Helper loaded: url_helper
INFO - 2020-08-25 17:51:06 --> Helper loaded: form_helper
INFO - 2020-08-25 17:51:06 --> Helper loaded: file_helper
INFO - 2020-08-25 17:51:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:51:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:51:06 --> Upload Class Initialized
INFO - 2020-08-25 17:51:07 --> Controller Class Initialized
DEBUG - 2020-08-25 17:51:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:51:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:51:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:51:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:51:07 --> Final output sent to browser
DEBUG - 2020-08-25 17:51:07 --> Total execution time: 0.0534
INFO - 2020-08-25 17:51:08 --> Config Class Initialized
INFO - 2020-08-25 17:51:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:51:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:51:08 --> Utf8 Class Initialized
INFO - 2020-08-25 17:51:08 --> URI Class Initialized
INFO - 2020-08-25 17:51:08 --> Router Class Initialized
INFO - 2020-08-25 17:51:08 --> Output Class Initialized
INFO - 2020-08-25 17:51:08 --> Security Class Initialized
DEBUG - 2020-08-25 17:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:51:08 --> Input Class Initialized
INFO - 2020-08-25 17:51:08 --> Language Class Initialized
INFO - 2020-08-25 17:51:08 --> Language Class Initialized
INFO - 2020-08-25 17:51:08 --> Config Class Initialized
INFO - 2020-08-25 17:51:08 --> Loader Class Initialized
INFO - 2020-08-25 17:51:08 --> Helper loaded: url_helper
INFO - 2020-08-25 17:51:08 --> Helper loaded: form_helper
INFO - 2020-08-25 17:51:08 --> Helper loaded: file_helper
INFO - 2020-08-25 17:51:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:51:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:51:08 --> Upload Class Initialized
INFO - 2020-08-25 17:51:08 --> Controller Class Initialized
ERROR - 2020-08-25 17:51:08 --> 404 Page Not Found: /index
INFO - 2020-08-25 17:52:44 --> Config Class Initialized
INFO - 2020-08-25 17:52:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:52:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:52:44 --> Utf8 Class Initialized
INFO - 2020-08-25 17:52:44 --> URI Class Initialized
DEBUG - 2020-08-25 17:52:44 --> No URI present. Default controller set.
INFO - 2020-08-25 17:52:44 --> Router Class Initialized
INFO - 2020-08-25 17:52:44 --> Output Class Initialized
INFO - 2020-08-25 17:52:44 --> Security Class Initialized
DEBUG - 2020-08-25 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:52:44 --> Input Class Initialized
INFO - 2020-08-25 17:52:44 --> Language Class Initialized
INFO - 2020-08-25 17:52:44 --> Language Class Initialized
INFO - 2020-08-25 17:52:44 --> Config Class Initialized
INFO - 2020-08-25 17:52:44 --> Loader Class Initialized
INFO - 2020-08-25 17:52:44 --> Helper loaded: url_helper
INFO - 2020-08-25 17:52:44 --> Helper loaded: form_helper
INFO - 2020-08-25 17:52:44 --> Helper loaded: file_helper
INFO - 2020-08-25 17:52:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:52:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:52:44 --> Upload Class Initialized
INFO - 2020-08-25 17:52:44 --> Controller Class Initialized
DEBUG - 2020-08-25 17:52:44 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:52:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:52:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:52:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:52:44 --> Final output sent to browser
DEBUG - 2020-08-25 17:52:44 --> Total execution time: 0.0525
INFO - 2020-08-25 17:57:01 --> Config Class Initialized
INFO - 2020-08-25 17:57:01 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:57:01 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:57:01 --> Utf8 Class Initialized
INFO - 2020-08-25 17:57:01 --> URI Class Initialized
DEBUG - 2020-08-25 17:57:01 --> No URI present. Default controller set.
INFO - 2020-08-25 17:57:01 --> Router Class Initialized
INFO - 2020-08-25 17:57:01 --> Output Class Initialized
INFO - 2020-08-25 17:57:01 --> Security Class Initialized
DEBUG - 2020-08-25 17:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:57:01 --> Input Class Initialized
INFO - 2020-08-25 17:57:01 --> Language Class Initialized
INFO - 2020-08-25 17:57:01 --> Language Class Initialized
INFO - 2020-08-25 17:57:01 --> Config Class Initialized
INFO - 2020-08-25 17:57:01 --> Loader Class Initialized
INFO - 2020-08-25 17:57:01 --> Helper loaded: url_helper
INFO - 2020-08-25 17:57:01 --> Helper loaded: form_helper
INFO - 2020-08-25 17:57:01 --> Helper loaded: file_helper
INFO - 2020-08-25 17:57:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:57:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:57:01 --> Upload Class Initialized
INFO - 2020-08-25 17:57:01 --> Controller Class Initialized
DEBUG - 2020-08-25 17:57:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:57:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:57:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:57:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:57:01 --> Final output sent to browser
DEBUG - 2020-08-25 17:57:01 --> Total execution time: 0.1405
INFO - 2020-08-25 17:57:22 --> Config Class Initialized
INFO - 2020-08-25 17:57:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 17:57:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 17:57:22 --> Utf8 Class Initialized
INFO - 2020-08-25 17:57:22 --> URI Class Initialized
INFO - 2020-08-25 17:57:22 --> Router Class Initialized
INFO - 2020-08-25 17:57:22 --> Output Class Initialized
INFO - 2020-08-25 17:57:22 --> Security Class Initialized
DEBUG - 2020-08-25 17:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 17:57:22 --> Input Class Initialized
INFO - 2020-08-25 17:57:22 --> Language Class Initialized
INFO - 2020-08-25 17:57:22 --> Language Class Initialized
INFO - 2020-08-25 17:57:22 --> Config Class Initialized
INFO - 2020-08-25 17:57:22 --> Loader Class Initialized
INFO - 2020-08-25 17:57:22 --> Helper loaded: url_helper
INFO - 2020-08-25 17:57:22 --> Helper loaded: form_helper
INFO - 2020-08-25 17:57:22 --> Helper loaded: file_helper
INFO - 2020-08-25 17:57:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 17:57:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 17:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 17:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 17:57:22 --> Upload Class Initialized
INFO - 2020-08-25 17:57:22 --> Controller Class Initialized
DEBUG - 2020-08-25 17:57:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 17:57:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 17:57:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 17:57:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 17:57:22 --> Final output sent to browser
DEBUG - 2020-08-25 17:57:22 --> Total execution time: 0.0684
INFO - 2020-08-25 18:01:39 --> Config Class Initialized
INFO - 2020-08-25 18:01:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:01:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:01:40 --> Utf8 Class Initialized
INFO - 2020-08-25 18:01:40 --> URI Class Initialized
INFO - 2020-08-25 18:01:40 --> Router Class Initialized
INFO - 2020-08-25 18:01:40 --> Output Class Initialized
INFO - 2020-08-25 18:01:40 --> Security Class Initialized
DEBUG - 2020-08-25 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:01:40 --> Input Class Initialized
INFO - 2020-08-25 18:01:40 --> Language Class Initialized
INFO - 2020-08-25 18:01:40 --> Language Class Initialized
INFO - 2020-08-25 18:01:40 --> Config Class Initialized
INFO - 2020-08-25 18:01:40 --> Loader Class Initialized
INFO - 2020-08-25 18:01:40 --> Helper loaded: url_helper
INFO - 2020-08-25 18:01:40 --> Helper loaded: form_helper
INFO - 2020-08-25 18:01:40 --> Helper loaded: file_helper
INFO - 2020-08-25 18:01:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:01:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:01:40 --> Upload Class Initialized
INFO - 2020-08-25 18:01:40 --> Controller Class Initialized
DEBUG - 2020-08-25 18:01:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:01:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:01:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:01:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:01:40 --> Final output sent to browser
DEBUG - 2020-08-25 18:01:40 --> Total execution time: 0.0684
INFO - 2020-08-25 18:09:35 --> Config Class Initialized
INFO - 2020-08-25 18:09:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:09:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:09:35 --> Utf8 Class Initialized
INFO - 2020-08-25 18:09:35 --> URI Class Initialized
DEBUG - 2020-08-25 18:09:35 --> No URI present. Default controller set.
INFO - 2020-08-25 18:09:35 --> Router Class Initialized
INFO - 2020-08-25 18:09:35 --> Output Class Initialized
INFO - 2020-08-25 18:09:35 --> Security Class Initialized
DEBUG - 2020-08-25 18:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:09:35 --> Input Class Initialized
INFO - 2020-08-25 18:09:35 --> Language Class Initialized
INFO - 2020-08-25 18:09:35 --> Language Class Initialized
INFO - 2020-08-25 18:09:35 --> Config Class Initialized
INFO - 2020-08-25 18:09:35 --> Loader Class Initialized
INFO - 2020-08-25 18:09:35 --> Helper loaded: url_helper
INFO - 2020-08-25 18:09:35 --> Helper loaded: form_helper
INFO - 2020-08-25 18:09:35 --> Helper loaded: file_helper
INFO - 2020-08-25 18:09:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:09:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:09:35 --> Upload Class Initialized
INFO - 2020-08-25 18:09:35 --> Controller Class Initialized
DEBUG - 2020-08-25 18:09:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:09:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:09:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:09:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:09:35 --> Final output sent to browser
DEBUG - 2020-08-25 18:09:35 --> Total execution time: 0.0522
INFO - 2020-08-25 18:14:50 --> Config Class Initialized
INFO - 2020-08-25 18:14:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:14:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:14:50 --> Utf8 Class Initialized
INFO - 2020-08-25 18:14:50 --> URI Class Initialized
INFO - 2020-08-25 18:14:50 --> Router Class Initialized
INFO - 2020-08-25 18:14:50 --> Output Class Initialized
INFO - 2020-08-25 18:14:50 --> Security Class Initialized
DEBUG - 2020-08-25 18:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:14:50 --> Input Class Initialized
INFO - 2020-08-25 18:14:50 --> Language Class Initialized
INFO - 2020-08-25 18:14:50 --> Language Class Initialized
INFO - 2020-08-25 18:14:50 --> Config Class Initialized
INFO - 2020-08-25 18:14:50 --> Loader Class Initialized
INFO - 2020-08-25 18:14:50 --> Helper loaded: url_helper
INFO - 2020-08-25 18:14:50 --> Helper loaded: form_helper
INFO - 2020-08-25 18:14:50 --> Helper loaded: file_helper
INFO - 2020-08-25 18:14:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:14:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:14:50 --> Upload Class Initialized
INFO - 2020-08-25 18:14:50 --> Controller Class Initialized
DEBUG - 2020-08-25 18:14:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:14:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:14:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:14:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:14:50 --> Final output sent to browser
DEBUG - 2020-08-25 18:14:50 --> Total execution time: 0.0515
INFO - 2020-08-25 18:15:00 --> Config Class Initialized
INFO - 2020-08-25 18:15:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:15:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:15:00 --> Utf8 Class Initialized
INFO - 2020-08-25 18:15:00 --> URI Class Initialized
INFO - 2020-08-25 18:15:00 --> Router Class Initialized
INFO - 2020-08-25 18:15:00 --> Output Class Initialized
INFO - 2020-08-25 18:15:00 --> Security Class Initialized
DEBUG - 2020-08-25 18:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:15:00 --> Input Class Initialized
INFO - 2020-08-25 18:15:00 --> Language Class Initialized
INFO - 2020-08-25 18:15:00 --> Language Class Initialized
INFO - 2020-08-25 18:15:00 --> Config Class Initialized
INFO - 2020-08-25 18:15:00 --> Loader Class Initialized
INFO - 2020-08-25 18:15:00 --> Helper loaded: url_helper
INFO - 2020-08-25 18:15:00 --> Helper loaded: form_helper
INFO - 2020-08-25 18:15:00 --> Helper loaded: file_helper
INFO - 2020-08-25 18:15:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:15:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:15:00 --> Upload Class Initialized
INFO - 2020-08-25 18:15:00 --> Controller Class Initialized
DEBUG - 2020-08-25 18:15:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:15:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:15:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:15:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:15:00 --> Final output sent to browser
DEBUG - 2020-08-25 18:15:00 --> Total execution time: 0.0538
INFO - 2020-08-25 18:15:02 --> Config Class Initialized
INFO - 2020-08-25 18:15:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:15:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:15:02 --> Utf8 Class Initialized
INFO - 2020-08-25 18:15:02 --> URI Class Initialized
INFO - 2020-08-25 18:15:02 --> Router Class Initialized
INFO - 2020-08-25 18:15:02 --> Output Class Initialized
INFO - 2020-08-25 18:15:02 --> Security Class Initialized
DEBUG - 2020-08-25 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:15:02 --> Input Class Initialized
INFO - 2020-08-25 18:15:02 --> Language Class Initialized
INFO - 2020-08-25 18:15:02 --> Language Class Initialized
INFO - 2020-08-25 18:15:02 --> Config Class Initialized
INFO - 2020-08-25 18:15:02 --> Loader Class Initialized
INFO - 2020-08-25 18:15:02 --> Helper loaded: url_helper
INFO - 2020-08-25 18:15:02 --> Helper loaded: form_helper
INFO - 2020-08-25 18:15:02 --> Helper loaded: file_helper
INFO - 2020-08-25 18:15:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:15:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:15:02 --> Upload Class Initialized
INFO - 2020-08-25 18:15:02 --> Controller Class Initialized
ERROR - 2020-08-25 18:15:02 --> 404 Page Not Found: /index
INFO - 2020-08-25 18:18:19 --> Config Class Initialized
INFO - 2020-08-25 18:18:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:18:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:18:19 --> Utf8 Class Initialized
INFO - 2020-08-25 18:18:19 --> URI Class Initialized
INFO - 2020-08-25 18:18:19 --> Router Class Initialized
INFO - 2020-08-25 18:18:19 --> Output Class Initialized
INFO - 2020-08-25 18:18:19 --> Security Class Initialized
DEBUG - 2020-08-25 18:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:18:19 --> Input Class Initialized
INFO - 2020-08-25 18:18:19 --> Language Class Initialized
INFO - 2020-08-25 18:18:19 --> Language Class Initialized
INFO - 2020-08-25 18:18:19 --> Config Class Initialized
INFO - 2020-08-25 18:18:19 --> Loader Class Initialized
INFO - 2020-08-25 18:18:19 --> Helper loaded: url_helper
INFO - 2020-08-25 18:18:19 --> Helper loaded: form_helper
INFO - 2020-08-25 18:18:19 --> Helper loaded: file_helper
INFO - 2020-08-25 18:18:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:18:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:18:19 --> Upload Class Initialized
INFO - 2020-08-25 18:18:19 --> Controller Class Initialized
DEBUG - 2020-08-25 18:18:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:18:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:18:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:18:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:18:19 --> Final output sent to browser
DEBUG - 2020-08-25 18:18:19 --> Total execution time: 0.0916
INFO - 2020-08-25 18:23:21 --> Config Class Initialized
INFO - 2020-08-25 18:23:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:23:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:23:21 --> Utf8 Class Initialized
INFO - 2020-08-25 18:23:21 --> URI Class Initialized
INFO - 2020-08-25 18:23:21 --> Router Class Initialized
INFO - 2020-08-25 18:23:21 --> Output Class Initialized
INFO - 2020-08-25 18:23:21 --> Security Class Initialized
DEBUG - 2020-08-25 18:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:23:21 --> Input Class Initialized
INFO - 2020-08-25 18:23:21 --> Language Class Initialized
INFO - 2020-08-25 18:23:21 --> Language Class Initialized
INFO - 2020-08-25 18:23:21 --> Config Class Initialized
INFO - 2020-08-25 18:23:21 --> Loader Class Initialized
INFO - 2020-08-25 18:23:21 --> Helper loaded: url_helper
INFO - 2020-08-25 18:23:21 --> Helper loaded: form_helper
INFO - 2020-08-25 18:23:21 --> Helper loaded: file_helper
INFO - 2020-08-25 18:23:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:23:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:23:21 --> Upload Class Initialized
INFO - 2020-08-25 18:23:21 --> Controller Class Initialized
DEBUG - 2020-08-25 18:23:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:23:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:23:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:23:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:23:21 --> Final output sent to browser
DEBUG - 2020-08-25 18:23:21 --> Total execution time: 0.0519
INFO - 2020-08-25 18:24:10 --> Config Class Initialized
INFO - 2020-08-25 18:24:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:24:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:24:10 --> Utf8 Class Initialized
INFO - 2020-08-25 18:24:10 --> URI Class Initialized
DEBUG - 2020-08-25 18:24:10 --> No URI present. Default controller set.
INFO - 2020-08-25 18:24:10 --> Router Class Initialized
INFO - 2020-08-25 18:24:10 --> Output Class Initialized
INFO - 2020-08-25 18:24:10 --> Security Class Initialized
DEBUG - 2020-08-25 18:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:24:10 --> Input Class Initialized
INFO - 2020-08-25 18:24:10 --> Language Class Initialized
INFO - 2020-08-25 18:24:10 --> Language Class Initialized
INFO - 2020-08-25 18:24:10 --> Config Class Initialized
INFO - 2020-08-25 18:24:10 --> Loader Class Initialized
INFO - 2020-08-25 18:24:10 --> Helper loaded: url_helper
INFO - 2020-08-25 18:24:10 --> Helper loaded: form_helper
INFO - 2020-08-25 18:24:10 --> Helper loaded: file_helper
INFO - 2020-08-25 18:24:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:24:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:24:10 --> Upload Class Initialized
INFO - 2020-08-25 18:24:10 --> Controller Class Initialized
DEBUG - 2020-08-25 18:24:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:24:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:24:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:24:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:24:10 --> Final output sent to browser
DEBUG - 2020-08-25 18:24:10 --> Total execution time: 0.0601
INFO - 2020-08-25 18:24:26 --> Config Class Initialized
INFO - 2020-08-25 18:24:26 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:24:26 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:24:26 --> Utf8 Class Initialized
INFO - 2020-08-25 18:24:26 --> URI Class Initialized
INFO - 2020-08-25 18:24:26 --> Router Class Initialized
INFO - 2020-08-25 18:24:26 --> Output Class Initialized
INFO - 2020-08-25 18:24:26 --> Security Class Initialized
DEBUG - 2020-08-25 18:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:24:26 --> Input Class Initialized
INFO - 2020-08-25 18:24:26 --> Language Class Initialized
INFO - 2020-08-25 18:24:26 --> Language Class Initialized
INFO - 2020-08-25 18:24:26 --> Config Class Initialized
INFO - 2020-08-25 18:24:26 --> Loader Class Initialized
INFO - 2020-08-25 18:24:26 --> Helper loaded: url_helper
INFO - 2020-08-25 18:24:26 --> Helper loaded: form_helper
INFO - 2020-08-25 18:24:26 --> Helper loaded: file_helper
INFO - 2020-08-25 18:24:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:24:26 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:24:26 --> Upload Class Initialized
INFO - 2020-08-25 18:24:27 --> Controller Class Initialized
ERROR - 2020-08-25 18:24:27 --> 404 Page Not Found: /index
INFO - 2020-08-25 18:24:30 --> Config Class Initialized
INFO - 2020-08-25 18:24:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:24:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:24:30 --> Utf8 Class Initialized
INFO - 2020-08-25 18:24:30 --> URI Class Initialized
DEBUG - 2020-08-25 18:24:30 --> No URI present. Default controller set.
INFO - 2020-08-25 18:24:30 --> Router Class Initialized
INFO - 2020-08-25 18:24:30 --> Output Class Initialized
INFO - 2020-08-25 18:24:30 --> Security Class Initialized
DEBUG - 2020-08-25 18:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:24:30 --> Input Class Initialized
INFO - 2020-08-25 18:24:30 --> Language Class Initialized
INFO - 2020-08-25 18:24:30 --> Language Class Initialized
INFO - 2020-08-25 18:24:30 --> Config Class Initialized
INFO - 2020-08-25 18:24:30 --> Loader Class Initialized
INFO - 2020-08-25 18:24:30 --> Helper loaded: url_helper
INFO - 2020-08-25 18:24:30 --> Helper loaded: form_helper
INFO - 2020-08-25 18:24:30 --> Helper loaded: file_helper
INFO - 2020-08-25 18:24:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:24:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:24:30 --> Upload Class Initialized
INFO - 2020-08-25 18:24:30 --> Controller Class Initialized
DEBUG - 2020-08-25 18:24:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 18:24:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 18:24:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 18:24:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 18:24:30 --> Final output sent to browser
DEBUG - 2020-08-25 18:24:30 --> Total execution time: 0.0517
INFO - 2020-08-25 18:24:41 --> Config Class Initialized
INFO - 2020-08-25 18:24:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 18:24:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 18:24:41 --> Utf8 Class Initialized
INFO - 2020-08-25 18:24:41 --> URI Class Initialized
INFO - 2020-08-25 18:24:41 --> Router Class Initialized
INFO - 2020-08-25 18:24:41 --> Output Class Initialized
INFO - 2020-08-25 18:24:41 --> Security Class Initialized
DEBUG - 2020-08-25 18:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 18:24:41 --> Input Class Initialized
INFO - 2020-08-25 18:24:41 --> Language Class Initialized
INFO - 2020-08-25 18:24:41 --> Language Class Initialized
INFO - 2020-08-25 18:24:41 --> Config Class Initialized
INFO - 2020-08-25 18:24:41 --> Loader Class Initialized
INFO - 2020-08-25 18:24:41 --> Helper loaded: url_helper
INFO - 2020-08-25 18:24:41 --> Helper loaded: form_helper
INFO - 2020-08-25 18:24:41 --> Helper loaded: file_helper
INFO - 2020-08-25 18:24:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 18:24:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 18:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 18:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 18:24:41 --> Upload Class Initialized
INFO - 2020-08-25 18:24:41 --> Controller Class Initialized
ERROR - 2020-08-25 18:24:41 --> 404 Page Not Found: /index
INFO - 2020-08-25 19:00:35 --> Config Class Initialized
INFO - 2020-08-25 19:00:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 19:00:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 19:00:35 --> Utf8 Class Initialized
INFO - 2020-08-25 19:00:35 --> URI Class Initialized
DEBUG - 2020-08-25 19:00:35 --> No URI present. Default controller set.
INFO - 2020-08-25 19:00:35 --> Router Class Initialized
INFO - 2020-08-25 19:00:35 --> Output Class Initialized
INFO - 2020-08-25 19:00:35 --> Security Class Initialized
DEBUG - 2020-08-25 19:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 19:00:35 --> Input Class Initialized
INFO - 2020-08-25 19:00:35 --> Language Class Initialized
INFO - 2020-08-25 19:00:35 --> Language Class Initialized
INFO - 2020-08-25 19:00:35 --> Config Class Initialized
INFO - 2020-08-25 19:00:35 --> Loader Class Initialized
INFO - 2020-08-25 19:00:35 --> Helper loaded: url_helper
INFO - 2020-08-25 19:00:35 --> Helper loaded: form_helper
INFO - 2020-08-25 19:00:35 --> Helper loaded: file_helper
INFO - 2020-08-25 19:00:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 19:00:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 19:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 19:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 19:00:35 --> Upload Class Initialized
INFO - 2020-08-25 19:00:35 --> Controller Class Initialized
DEBUG - 2020-08-25 19:00:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 19:00:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 19:00:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 19:00:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 19:00:35 --> Final output sent to browser
DEBUG - 2020-08-25 19:00:35 --> Total execution time: 0.0525
INFO - 2020-08-25 19:00:37 --> Config Class Initialized
INFO - 2020-08-25 19:00:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 19:00:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 19:00:37 --> Utf8 Class Initialized
INFO - 2020-08-25 19:00:37 --> URI Class Initialized
INFO - 2020-08-25 19:00:37 --> Router Class Initialized
INFO - 2020-08-25 19:00:37 --> Output Class Initialized
INFO - 2020-08-25 19:00:37 --> Security Class Initialized
DEBUG - 2020-08-25 19:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 19:00:37 --> Input Class Initialized
INFO - 2020-08-25 19:00:37 --> Language Class Initialized
INFO - 2020-08-25 19:00:37 --> Language Class Initialized
INFO - 2020-08-25 19:00:37 --> Config Class Initialized
INFO - 2020-08-25 19:00:37 --> Loader Class Initialized
INFO - 2020-08-25 19:00:37 --> Helper loaded: url_helper
INFO - 2020-08-25 19:00:37 --> Helper loaded: form_helper
INFO - 2020-08-25 19:00:37 --> Helper loaded: file_helper
INFO - 2020-08-25 19:00:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 19:00:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 19:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 19:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 19:00:37 --> Upload Class Initialized
INFO - 2020-08-25 19:00:37 --> Controller Class Initialized
ERROR - 2020-08-25 19:00:37 --> 404 Page Not Found: /index
INFO - 2020-08-25 19:00:38 --> Config Class Initialized
INFO - 2020-08-25 19:00:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 19:00:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 19:00:38 --> Utf8 Class Initialized
INFO - 2020-08-25 19:00:38 --> URI Class Initialized
INFO - 2020-08-25 19:00:38 --> Router Class Initialized
INFO - 2020-08-25 19:00:38 --> Output Class Initialized
INFO - 2020-08-25 19:00:38 --> Security Class Initialized
DEBUG - 2020-08-25 19:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 19:00:38 --> Input Class Initialized
INFO - 2020-08-25 19:00:38 --> Language Class Initialized
INFO - 2020-08-25 19:00:38 --> Language Class Initialized
INFO - 2020-08-25 19:00:38 --> Config Class Initialized
INFO - 2020-08-25 19:00:38 --> Loader Class Initialized
INFO - 2020-08-25 19:00:38 --> Helper loaded: url_helper
INFO - 2020-08-25 19:00:38 --> Helper loaded: form_helper
INFO - 2020-08-25 19:00:38 --> Helper loaded: file_helper
INFO - 2020-08-25 19:00:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 19:00:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 19:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 19:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 19:00:38 --> Upload Class Initialized
INFO - 2020-08-25 19:00:38 --> Controller Class Initialized
ERROR - 2020-08-25 19:00:38 --> 404 Page Not Found: /index
INFO - 2020-08-25 19:01:11 --> Config Class Initialized
INFO - 2020-08-25 19:01:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 19:01:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 19:01:11 --> Utf8 Class Initialized
INFO - 2020-08-25 19:01:11 --> URI Class Initialized
INFO - 2020-08-25 19:01:11 --> Router Class Initialized
INFO - 2020-08-25 19:01:11 --> Output Class Initialized
INFO - 2020-08-25 19:01:11 --> Security Class Initialized
DEBUG - 2020-08-25 19:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 19:01:11 --> Input Class Initialized
INFO - 2020-08-25 19:01:11 --> Language Class Initialized
INFO - 2020-08-25 19:01:11 --> Language Class Initialized
INFO - 2020-08-25 19:01:11 --> Config Class Initialized
INFO - 2020-08-25 19:01:11 --> Loader Class Initialized
INFO - 2020-08-25 19:01:11 --> Helper loaded: url_helper
INFO - 2020-08-25 19:01:11 --> Helper loaded: form_helper
INFO - 2020-08-25 19:01:11 --> Helper loaded: file_helper
INFO - 2020-08-25 19:01:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 19:01:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 19:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 19:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 19:01:11 --> Upload Class Initialized
INFO - 2020-08-25 19:01:11 --> Controller Class Initialized
DEBUG - 2020-08-25 19:01:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 19:01:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 19:01:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 19:01:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 19:01:11 --> Final output sent to browser
DEBUG - 2020-08-25 19:01:11 --> Total execution time: 0.0540
INFO - 2020-08-25 19:10:57 --> Config Class Initialized
INFO - 2020-08-25 19:10:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 19:10:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 19:10:57 --> Utf8 Class Initialized
INFO - 2020-08-25 19:10:57 --> URI Class Initialized
INFO - 2020-08-25 19:10:57 --> Router Class Initialized
INFO - 2020-08-25 19:10:57 --> Output Class Initialized
INFO - 2020-08-25 19:10:57 --> Security Class Initialized
DEBUG - 2020-08-25 19:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 19:10:57 --> Input Class Initialized
INFO - 2020-08-25 19:10:57 --> Language Class Initialized
INFO - 2020-08-25 19:10:57 --> Language Class Initialized
INFO - 2020-08-25 19:10:57 --> Config Class Initialized
INFO - 2020-08-25 19:10:57 --> Loader Class Initialized
INFO - 2020-08-25 19:10:57 --> Helper loaded: url_helper
INFO - 2020-08-25 19:10:57 --> Helper loaded: form_helper
INFO - 2020-08-25 19:10:57 --> Helper loaded: file_helper
INFO - 2020-08-25 19:10:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 19:10:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 19:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 19:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 19:10:57 --> Upload Class Initialized
INFO - 2020-08-25 19:10:57 --> Controller Class Initialized
DEBUG - 2020-08-25 19:10:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 19:10:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 19:10:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 19:10:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 19:10:57 --> Final output sent to browser
DEBUG - 2020-08-25 19:10:57 --> Total execution time: 0.0522
INFO - 2020-08-25 19:33:26 --> Config Class Initialized
INFO - 2020-08-25 19:33:26 --> Hooks Class Initialized
DEBUG - 2020-08-25 19:33:26 --> UTF-8 Support Enabled
INFO - 2020-08-25 19:33:26 --> Utf8 Class Initialized
INFO - 2020-08-25 19:33:26 --> URI Class Initialized
DEBUG - 2020-08-25 19:33:26 --> No URI present. Default controller set.
INFO - 2020-08-25 19:33:26 --> Router Class Initialized
INFO - 2020-08-25 19:33:26 --> Output Class Initialized
INFO - 2020-08-25 19:33:26 --> Security Class Initialized
DEBUG - 2020-08-25 19:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 19:33:26 --> Input Class Initialized
INFO - 2020-08-25 19:33:26 --> Language Class Initialized
INFO - 2020-08-25 19:33:26 --> Language Class Initialized
INFO - 2020-08-25 19:33:26 --> Config Class Initialized
INFO - 2020-08-25 19:33:26 --> Loader Class Initialized
INFO - 2020-08-25 19:33:26 --> Helper loaded: url_helper
INFO - 2020-08-25 19:33:26 --> Helper loaded: form_helper
INFO - 2020-08-25 19:33:26 --> Helper loaded: file_helper
INFO - 2020-08-25 19:33:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 19:33:26 --> Database Driver Class Initialized
DEBUG - 2020-08-25 19:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 19:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 19:33:26 --> Upload Class Initialized
INFO - 2020-08-25 19:33:26 --> Controller Class Initialized
DEBUG - 2020-08-25 19:33:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 19:33:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 19:33:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 19:33:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 19:33:26 --> Final output sent to browser
DEBUG - 2020-08-25 19:33:26 --> Total execution time: 0.0575
INFO - 2020-08-25 20:06:22 --> Config Class Initialized
INFO - 2020-08-25 20:06:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 20:06:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 20:06:22 --> Utf8 Class Initialized
INFO - 2020-08-25 20:06:22 --> URI Class Initialized
DEBUG - 2020-08-25 20:06:22 --> No URI present. Default controller set.
INFO - 2020-08-25 20:06:22 --> Router Class Initialized
INFO - 2020-08-25 20:06:22 --> Output Class Initialized
INFO - 2020-08-25 20:06:22 --> Security Class Initialized
DEBUG - 2020-08-25 20:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 20:06:22 --> Input Class Initialized
INFO - 2020-08-25 20:06:22 --> Language Class Initialized
INFO - 2020-08-25 20:06:22 --> Language Class Initialized
INFO - 2020-08-25 20:06:22 --> Config Class Initialized
INFO - 2020-08-25 20:06:22 --> Loader Class Initialized
INFO - 2020-08-25 20:06:22 --> Helper loaded: url_helper
INFO - 2020-08-25 20:06:22 --> Helper loaded: form_helper
INFO - 2020-08-25 20:06:22 --> Helper loaded: file_helper
INFO - 2020-08-25 20:06:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 20:06:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 20:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 20:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 20:06:22 --> Upload Class Initialized
INFO - 2020-08-25 20:06:22 --> Controller Class Initialized
DEBUG - 2020-08-25 20:06:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 20:06:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 20:06:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 20:06:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 20:06:22 --> Final output sent to browser
DEBUG - 2020-08-25 20:06:22 --> Total execution time: 0.0555
INFO - 2020-08-25 20:06:27 --> Config Class Initialized
INFO - 2020-08-25 20:06:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 20:06:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 20:06:27 --> Utf8 Class Initialized
INFO - 2020-08-25 20:06:27 --> URI Class Initialized
INFO - 2020-08-25 20:06:27 --> Router Class Initialized
INFO - 2020-08-25 20:06:27 --> Output Class Initialized
INFO - 2020-08-25 20:06:27 --> Security Class Initialized
DEBUG - 2020-08-25 20:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 20:06:27 --> Input Class Initialized
INFO - 2020-08-25 20:06:27 --> Language Class Initialized
INFO - 2020-08-25 20:06:27 --> Language Class Initialized
INFO - 2020-08-25 20:06:27 --> Config Class Initialized
INFO - 2020-08-25 20:06:27 --> Loader Class Initialized
INFO - 2020-08-25 20:06:27 --> Helper loaded: url_helper
INFO - 2020-08-25 20:06:27 --> Helper loaded: form_helper
INFO - 2020-08-25 20:06:27 --> Helper loaded: file_helper
INFO - 2020-08-25 20:06:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 20:06:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 20:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 20:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 20:06:27 --> Upload Class Initialized
INFO - 2020-08-25 20:06:27 --> Controller Class Initialized
ERROR - 2020-08-25 20:06:27 --> 404 Page Not Found: /index
INFO - 2020-08-25 20:52:22 --> Config Class Initialized
INFO - 2020-08-25 20:52:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 20:52:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 20:52:22 --> Utf8 Class Initialized
INFO - 2020-08-25 20:52:22 --> URI Class Initialized
INFO - 2020-08-25 20:52:22 --> Router Class Initialized
INFO - 2020-08-25 20:52:22 --> Output Class Initialized
INFO - 2020-08-25 20:52:22 --> Security Class Initialized
DEBUG - 2020-08-25 20:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 20:52:22 --> Input Class Initialized
INFO - 2020-08-25 20:52:22 --> Language Class Initialized
INFO - 2020-08-25 20:52:22 --> Language Class Initialized
INFO - 2020-08-25 20:52:22 --> Config Class Initialized
INFO - 2020-08-25 20:52:22 --> Loader Class Initialized
INFO - 2020-08-25 20:52:22 --> Helper loaded: url_helper
INFO - 2020-08-25 20:52:22 --> Helper loaded: form_helper
INFO - 2020-08-25 20:52:22 --> Helper loaded: file_helper
INFO - 2020-08-25 20:52:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 20:52:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 20:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 20:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 20:52:22 --> Upload Class Initialized
INFO - 2020-08-25 20:52:22 --> Controller Class Initialized
ERROR - 2020-08-25 20:52:22 --> 404 Page Not Found: /index
INFO - 2020-08-25 20:52:23 --> Config Class Initialized
INFO - 2020-08-25 20:52:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 20:52:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 20:52:23 --> Utf8 Class Initialized
INFO - 2020-08-25 20:52:23 --> URI Class Initialized
DEBUG - 2020-08-25 20:52:23 --> No URI present. Default controller set.
INFO - 2020-08-25 20:52:23 --> Router Class Initialized
INFO - 2020-08-25 20:52:23 --> Output Class Initialized
INFO - 2020-08-25 20:52:23 --> Security Class Initialized
DEBUG - 2020-08-25 20:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 20:52:23 --> Input Class Initialized
INFO - 2020-08-25 20:52:23 --> Language Class Initialized
INFO - 2020-08-25 20:52:23 --> Language Class Initialized
INFO - 2020-08-25 20:52:23 --> Config Class Initialized
INFO - 2020-08-25 20:52:23 --> Loader Class Initialized
INFO - 2020-08-25 20:52:23 --> Helper loaded: url_helper
INFO - 2020-08-25 20:52:23 --> Helper loaded: form_helper
INFO - 2020-08-25 20:52:23 --> Helper loaded: file_helper
INFO - 2020-08-25 20:52:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 20:52:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 20:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 20:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 20:52:23 --> Upload Class Initialized
INFO - 2020-08-25 20:52:23 --> Controller Class Initialized
DEBUG - 2020-08-25 20:52:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 20:52:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 20:52:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 20:52:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 20:52:23 --> Final output sent to browser
DEBUG - 2020-08-25 20:52:23 --> Total execution time: 0.0511
INFO - 2020-08-25 20:52:24 --> Config Class Initialized
INFO - 2020-08-25 20:52:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 20:52:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 20:52:24 --> Utf8 Class Initialized
INFO - 2020-08-25 20:52:24 --> URI Class Initialized
DEBUG - 2020-08-25 20:52:24 --> No URI present. Default controller set.
INFO - 2020-08-25 20:52:24 --> Router Class Initialized
INFO - 2020-08-25 20:52:24 --> Output Class Initialized
INFO - 2020-08-25 20:52:24 --> Security Class Initialized
DEBUG - 2020-08-25 20:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 20:52:24 --> Input Class Initialized
INFO - 2020-08-25 20:52:24 --> Language Class Initialized
INFO - 2020-08-25 20:52:24 --> Language Class Initialized
INFO - 2020-08-25 20:52:24 --> Config Class Initialized
INFO - 2020-08-25 20:52:24 --> Loader Class Initialized
INFO - 2020-08-25 20:52:24 --> Helper loaded: url_helper
INFO - 2020-08-25 20:52:24 --> Helper loaded: form_helper
INFO - 2020-08-25 20:52:24 --> Helper loaded: file_helper
INFO - 2020-08-25 20:52:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 20:52:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 20:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 20:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 20:52:24 --> Upload Class Initialized
INFO - 2020-08-25 20:52:24 --> Controller Class Initialized
DEBUG - 2020-08-25 20:52:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 20:52:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 20:52:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 20:52:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 20:52:24 --> Final output sent to browser
DEBUG - 2020-08-25 20:52:24 --> Total execution time: 0.0517
INFO - 2020-08-25 21:15:06 --> Config Class Initialized
INFO - 2020-08-25 21:15:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 21:15:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 21:15:06 --> Utf8 Class Initialized
INFO - 2020-08-25 21:15:06 --> URI Class Initialized
DEBUG - 2020-08-25 21:15:06 --> No URI present. Default controller set.
INFO - 2020-08-25 21:15:06 --> Router Class Initialized
INFO - 2020-08-25 21:15:06 --> Output Class Initialized
INFO - 2020-08-25 21:15:06 --> Security Class Initialized
DEBUG - 2020-08-25 21:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 21:15:06 --> Input Class Initialized
INFO - 2020-08-25 21:15:06 --> Language Class Initialized
INFO - 2020-08-25 21:15:06 --> Language Class Initialized
INFO - 2020-08-25 21:15:06 --> Config Class Initialized
INFO - 2020-08-25 21:15:06 --> Loader Class Initialized
INFO - 2020-08-25 21:15:06 --> Helper loaded: url_helper
INFO - 2020-08-25 21:15:06 --> Helper loaded: form_helper
INFO - 2020-08-25 21:15:06 --> Helper loaded: file_helper
INFO - 2020-08-25 21:15:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 21:15:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 21:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 21:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 21:15:06 --> Upload Class Initialized
INFO - 2020-08-25 21:15:06 --> Controller Class Initialized
DEBUG - 2020-08-25 21:15:06 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 21:15:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 21:15:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 21:15:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 21:15:06 --> Final output sent to browser
DEBUG - 2020-08-25 21:15:06 --> Total execution time: 0.0595
INFO - 2020-08-25 21:15:09 --> Config Class Initialized
INFO - 2020-08-25 21:15:09 --> Hooks Class Initialized
DEBUG - 2020-08-25 21:15:09 --> UTF-8 Support Enabled
INFO - 2020-08-25 21:15:09 --> Utf8 Class Initialized
INFO - 2020-08-25 21:15:09 --> URI Class Initialized
INFO - 2020-08-25 21:15:09 --> Router Class Initialized
INFO - 2020-08-25 21:15:09 --> Output Class Initialized
INFO - 2020-08-25 21:15:09 --> Security Class Initialized
DEBUG - 2020-08-25 21:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 21:15:09 --> Input Class Initialized
INFO - 2020-08-25 21:15:09 --> Language Class Initialized
INFO - 2020-08-25 21:15:09 --> Language Class Initialized
INFO - 2020-08-25 21:15:09 --> Config Class Initialized
INFO - 2020-08-25 21:15:09 --> Loader Class Initialized
INFO - 2020-08-25 21:15:09 --> Helper loaded: url_helper
INFO - 2020-08-25 21:15:09 --> Helper loaded: form_helper
INFO - 2020-08-25 21:15:09 --> Helper loaded: file_helper
INFO - 2020-08-25 21:15:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 21:15:09 --> Database Driver Class Initialized
DEBUG - 2020-08-25 21:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 21:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 21:15:09 --> Upload Class Initialized
INFO - 2020-08-25 21:15:09 --> Controller Class Initialized
ERROR - 2020-08-25 21:15:09 --> 404 Page Not Found: /index
INFO - 2020-08-25 21:28:12 --> Config Class Initialized
INFO - 2020-08-25 21:28:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 21:28:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 21:28:12 --> Utf8 Class Initialized
INFO - 2020-08-25 21:28:12 --> URI Class Initialized
DEBUG - 2020-08-25 21:28:12 --> No URI present. Default controller set.
INFO - 2020-08-25 21:28:12 --> Router Class Initialized
INFO - 2020-08-25 21:28:12 --> Output Class Initialized
INFO - 2020-08-25 21:28:12 --> Security Class Initialized
DEBUG - 2020-08-25 21:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 21:28:12 --> Input Class Initialized
INFO - 2020-08-25 21:28:12 --> Language Class Initialized
INFO - 2020-08-25 21:28:12 --> Language Class Initialized
INFO - 2020-08-25 21:28:12 --> Config Class Initialized
INFO - 2020-08-25 21:28:12 --> Loader Class Initialized
INFO - 2020-08-25 21:28:12 --> Helper loaded: url_helper
INFO - 2020-08-25 21:28:12 --> Helper loaded: form_helper
INFO - 2020-08-25 21:28:12 --> Helper loaded: file_helper
INFO - 2020-08-25 21:28:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 21:28:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 21:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 21:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 21:28:12 --> Upload Class Initialized
INFO - 2020-08-25 21:28:12 --> Controller Class Initialized
DEBUG - 2020-08-25 21:28:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 21:28:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 21:28:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 21:28:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 21:28:12 --> Final output sent to browser
DEBUG - 2020-08-25 21:28:12 --> Total execution time: 0.0505
INFO - 2020-08-25 21:40:50 --> Config Class Initialized
INFO - 2020-08-25 21:40:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 21:40:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 21:40:50 --> Utf8 Class Initialized
INFO - 2020-08-25 21:40:50 --> URI Class Initialized
INFO - 2020-08-25 21:40:50 --> Router Class Initialized
INFO - 2020-08-25 21:40:50 --> Output Class Initialized
INFO - 2020-08-25 21:40:50 --> Security Class Initialized
DEBUG - 2020-08-25 21:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 21:40:50 --> Input Class Initialized
INFO - 2020-08-25 21:40:50 --> Language Class Initialized
INFO - 2020-08-25 21:40:50 --> Language Class Initialized
INFO - 2020-08-25 21:40:50 --> Config Class Initialized
INFO - 2020-08-25 21:40:50 --> Loader Class Initialized
INFO - 2020-08-25 21:40:50 --> Helper loaded: url_helper
INFO - 2020-08-25 21:40:50 --> Helper loaded: form_helper
INFO - 2020-08-25 21:40:50 --> Helper loaded: file_helper
INFO - 2020-08-25 21:40:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 21:40:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 21:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 21:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 21:40:50 --> Upload Class Initialized
INFO - 2020-08-25 21:40:50 --> Controller Class Initialized
ERROR - 2020-08-25 21:40:50 --> 404 Page Not Found: /index
INFO - 2020-08-25 23:14:12 --> Config Class Initialized
INFO - 2020-08-25 23:14:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 23:14:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 23:14:12 --> Utf8 Class Initialized
INFO - 2020-08-25 23:14:12 --> URI Class Initialized
DEBUG - 2020-08-25 23:14:12 --> No URI present. Default controller set.
INFO - 2020-08-25 23:14:12 --> Router Class Initialized
INFO - 2020-08-25 23:14:12 --> Output Class Initialized
INFO - 2020-08-25 23:14:12 --> Security Class Initialized
DEBUG - 2020-08-25 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 23:14:12 --> Input Class Initialized
INFO - 2020-08-25 23:14:12 --> Language Class Initialized
INFO - 2020-08-25 23:14:12 --> Language Class Initialized
INFO - 2020-08-25 23:14:12 --> Config Class Initialized
INFO - 2020-08-25 23:14:12 --> Loader Class Initialized
INFO - 2020-08-25 23:14:12 --> Helper loaded: url_helper
INFO - 2020-08-25 23:14:12 --> Helper loaded: form_helper
INFO - 2020-08-25 23:14:12 --> Helper loaded: file_helper
INFO - 2020-08-25 23:14:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 23:14:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 23:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 23:14:12 --> Upload Class Initialized
INFO - 2020-08-25 23:14:12 --> Controller Class Initialized
DEBUG - 2020-08-25 23:14:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 23:14:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 23:14:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 23:14:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 23:14:12 --> Final output sent to browser
DEBUG - 2020-08-25 23:14:12 --> Total execution time: 0.0514
INFO - 2020-08-25 23:18:53 --> Config Class Initialized
INFO - 2020-08-25 23:18:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 23:18:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 23:18:53 --> Utf8 Class Initialized
INFO - 2020-08-25 23:18:53 --> URI Class Initialized
INFO - 2020-08-25 23:18:53 --> Router Class Initialized
INFO - 2020-08-25 23:18:53 --> Output Class Initialized
INFO - 2020-08-25 23:18:53 --> Security Class Initialized
DEBUG - 2020-08-25 23:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 23:18:53 --> Input Class Initialized
INFO - 2020-08-25 23:18:53 --> Language Class Initialized
INFO - 2020-08-25 23:18:53 --> Language Class Initialized
INFO - 2020-08-25 23:18:53 --> Config Class Initialized
INFO - 2020-08-25 23:18:53 --> Loader Class Initialized
INFO - 2020-08-25 23:18:53 --> Helper loaded: url_helper
INFO - 2020-08-25 23:18:53 --> Helper loaded: form_helper
INFO - 2020-08-25 23:18:53 --> Helper loaded: file_helper
INFO - 2020-08-25 23:18:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 23:18:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 23:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 23:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 23:18:53 --> Upload Class Initialized
INFO - 2020-08-25 23:18:53 --> Controller Class Initialized
DEBUG - 2020-08-25 23:18:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-25 23:18:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-25 23:18:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-25 23:18:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-25 23:18:53 --> Final output sent to browser
DEBUG - 2020-08-25 23:18:53 --> Total execution time: 0.0517
INFO - 2020-08-25 23:18:57 --> Config Class Initialized
INFO - 2020-08-25 23:18:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 23:18:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 23:18:57 --> Utf8 Class Initialized
INFO - 2020-08-25 23:18:57 --> URI Class Initialized
INFO - 2020-08-25 23:18:57 --> Router Class Initialized
INFO - 2020-08-25 23:18:57 --> Output Class Initialized
INFO - 2020-08-25 23:18:57 --> Security Class Initialized
DEBUG - 2020-08-25 23:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 23:18:57 --> Input Class Initialized
INFO - 2020-08-25 23:18:57 --> Language Class Initialized
INFO - 2020-08-25 23:18:57 --> Language Class Initialized
INFO - 2020-08-25 23:18:57 --> Config Class Initialized
INFO - 2020-08-25 23:18:57 --> Loader Class Initialized
INFO - 2020-08-25 23:18:57 --> Helper loaded: url_helper
INFO - 2020-08-25 23:18:57 --> Helper loaded: form_helper
INFO - 2020-08-25 23:18:57 --> Helper loaded: file_helper
INFO - 2020-08-25 23:18:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-25 23:18:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 23:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 23:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 23:18:57 --> Upload Class Initialized
INFO - 2020-08-25 23:18:57 --> Controller Class Initialized
ERROR - 2020-08-25 23:18:57 --> 404 Page Not Found: /index
