<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-26 00:27:20 --> Config Class Initialized
INFO - 2020-08-26 00:27:20 --> Hooks Class Initialized
DEBUG - 2020-08-26 00:27:20 --> UTF-8 Support Enabled
INFO - 2020-08-26 00:27:20 --> Utf8 Class Initialized
INFO - 2020-08-26 00:27:20 --> URI Class Initialized
DEBUG - 2020-08-26 00:27:20 --> No URI present. Default controller set.
INFO - 2020-08-26 00:27:20 --> Router Class Initialized
INFO - 2020-08-26 00:27:20 --> Output Class Initialized
INFO - 2020-08-26 00:27:20 --> Security Class Initialized
DEBUG - 2020-08-26 00:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 00:27:20 --> Input Class Initialized
INFO - 2020-08-26 00:27:20 --> Language Class Initialized
INFO - 2020-08-26 00:27:20 --> Language Class Initialized
INFO - 2020-08-26 00:27:20 --> Config Class Initialized
INFO - 2020-08-26 00:27:20 --> Loader Class Initialized
INFO - 2020-08-26 00:27:20 --> Helper loaded: url_helper
INFO - 2020-08-26 00:27:20 --> Helper loaded: form_helper
INFO - 2020-08-26 00:27:20 --> Helper loaded: file_helper
INFO - 2020-08-26 00:27:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 00:27:20 --> Database Driver Class Initialized
DEBUG - 2020-08-26 00:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 00:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 00:27:20 --> Upload Class Initialized
INFO - 2020-08-26 00:27:20 --> Controller Class Initialized
DEBUG - 2020-08-26 00:27:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 00:27:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 00:27:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 00:27:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 00:27:20 --> Final output sent to browser
DEBUG - 2020-08-26 00:27:20 --> Total execution time: 0.0543
INFO - 2020-08-26 00:54:53 --> Config Class Initialized
INFO - 2020-08-26 00:54:53 --> Hooks Class Initialized
DEBUG - 2020-08-26 00:54:53 --> UTF-8 Support Enabled
INFO - 2020-08-26 00:54:53 --> Utf8 Class Initialized
INFO - 2020-08-26 00:54:53 --> URI Class Initialized
INFO - 2020-08-26 00:54:53 --> Router Class Initialized
INFO - 2020-08-26 00:54:53 --> Output Class Initialized
INFO - 2020-08-26 00:54:53 --> Security Class Initialized
DEBUG - 2020-08-26 00:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 00:54:53 --> Input Class Initialized
INFO - 2020-08-26 00:54:53 --> Language Class Initialized
INFO - 2020-08-26 00:54:53 --> Language Class Initialized
INFO - 2020-08-26 00:54:53 --> Config Class Initialized
INFO - 2020-08-26 00:54:53 --> Loader Class Initialized
INFO - 2020-08-26 00:54:53 --> Helper loaded: url_helper
INFO - 2020-08-26 00:54:53 --> Helper loaded: form_helper
INFO - 2020-08-26 00:54:53 --> Helper loaded: file_helper
INFO - 2020-08-26 00:54:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 00:54:53 --> Database Driver Class Initialized
DEBUG - 2020-08-26 00:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 00:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 00:54:53 --> Upload Class Initialized
INFO - 2020-08-26 00:54:53 --> Controller Class Initialized
ERROR - 2020-08-26 00:54:53 --> 404 Page Not Found: /index
INFO - 2020-08-26 00:54:57 --> Config Class Initialized
INFO - 2020-08-26 00:54:57 --> Hooks Class Initialized
DEBUG - 2020-08-26 00:54:57 --> UTF-8 Support Enabled
INFO - 2020-08-26 00:54:57 --> Utf8 Class Initialized
INFO - 2020-08-26 00:54:57 --> URI Class Initialized
DEBUG - 2020-08-26 00:54:57 --> No URI present. Default controller set.
INFO - 2020-08-26 00:54:57 --> Router Class Initialized
INFO - 2020-08-26 00:54:57 --> Output Class Initialized
INFO - 2020-08-26 00:54:57 --> Security Class Initialized
DEBUG - 2020-08-26 00:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 00:54:57 --> Input Class Initialized
INFO - 2020-08-26 00:54:57 --> Language Class Initialized
INFO - 2020-08-26 00:54:57 --> Language Class Initialized
INFO - 2020-08-26 00:54:57 --> Config Class Initialized
INFO - 2020-08-26 00:54:57 --> Loader Class Initialized
INFO - 2020-08-26 00:54:57 --> Helper loaded: url_helper
INFO - 2020-08-26 00:54:57 --> Helper loaded: form_helper
INFO - 2020-08-26 00:54:57 --> Helper loaded: file_helper
INFO - 2020-08-26 00:54:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 00:54:57 --> Database Driver Class Initialized
DEBUG - 2020-08-26 00:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 00:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 00:54:57 --> Upload Class Initialized
INFO - 2020-08-26 00:54:57 --> Controller Class Initialized
DEBUG - 2020-08-26 00:54:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 00:54:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 00:54:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 00:54:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 00:54:57 --> Final output sent to browser
DEBUG - 2020-08-26 00:54:57 --> Total execution time: 0.0511
INFO - 2020-08-26 01:27:18 --> Config Class Initialized
INFO - 2020-08-26 01:27:18 --> Hooks Class Initialized
DEBUG - 2020-08-26 01:27:18 --> UTF-8 Support Enabled
INFO - 2020-08-26 01:27:18 --> Utf8 Class Initialized
INFO - 2020-08-26 01:27:18 --> URI Class Initialized
INFO - 2020-08-26 01:27:18 --> Router Class Initialized
INFO - 2020-08-26 01:27:18 --> Output Class Initialized
INFO - 2020-08-26 01:27:18 --> Security Class Initialized
DEBUG - 2020-08-26 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 01:27:18 --> Input Class Initialized
INFO - 2020-08-26 01:27:18 --> Language Class Initialized
INFO - 2020-08-26 01:27:18 --> Language Class Initialized
INFO - 2020-08-26 01:27:18 --> Config Class Initialized
INFO - 2020-08-26 01:27:18 --> Loader Class Initialized
INFO - 2020-08-26 01:27:18 --> Helper loaded: url_helper
INFO - 2020-08-26 01:27:18 --> Helper loaded: form_helper
INFO - 2020-08-26 01:27:18 --> Helper loaded: file_helper
INFO - 2020-08-26 01:27:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 01:27:18 --> Database Driver Class Initialized
DEBUG - 2020-08-26 01:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 01:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 01:27:18 --> Upload Class Initialized
INFO - 2020-08-26 01:27:18 --> Controller Class Initialized
ERROR - 2020-08-26 01:27:18 --> 404 Page Not Found: /index
INFO - 2020-08-26 01:27:18 --> Config Class Initialized
INFO - 2020-08-26 01:27:18 --> Hooks Class Initialized
DEBUG - 2020-08-26 01:27:18 --> UTF-8 Support Enabled
INFO - 2020-08-26 01:27:18 --> Utf8 Class Initialized
INFO - 2020-08-26 01:27:18 --> URI Class Initialized
DEBUG - 2020-08-26 01:27:18 --> No URI present. Default controller set.
INFO - 2020-08-26 01:27:18 --> Router Class Initialized
INFO - 2020-08-26 01:27:18 --> Output Class Initialized
INFO - 2020-08-26 01:27:18 --> Security Class Initialized
DEBUG - 2020-08-26 01:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 01:27:18 --> Input Class Initialized
INFO - 2020-08-26 01:27:18 --> Language Class Initialized
INFO - 2020-08-26 01:27:18 --> Language Class Initialized
INFO - 2020-08-26 01:27:18 --> Config Class Initialized
INFO - 2020-08-26 01:27:18 --> Loader Class Initialized
INFO - 2020-08-26 01:27:18 --> Helper loaded: url_helper
INFO - 2020-08-26 01:27:18 --> Helper loaded: form_helper
INFO - 2020-08-26 01:27:18 --> Helper loaded: file_helper
INFO - 2020-08-26 01:27:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 01:27:18 --> Database Driver Class Initialized
DEBUG - 2020-08-26 01:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 01:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 01:27:18 --> Upload Class Initialized
INFO - 2020-08-26 01:27:18 --> Controller Class Initialized
DEBUG - 2020-08-26 01:27:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 01:27:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 01:27:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 01:27:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 01:27:18 --> Final output sent to browser
DEBUG - 2020-08-26 01:27:18 --> Total execution time: 0.0506
INFO - 2020-08-26 01:28:00 --> Config Class Initialized
INFO - 2020-08-26 01:28:00 --> Hooks Class Initialized
DEBUG - 2020-08-26 01:28:00 --> UTF-8 Support Enabled
INFO - 2020-08-26 01:28:00 --> Utf8 Class Initialized
INFO - 2020-08-26 01:28:00 --> URI Class Initialized
INFO - 2020-08-26 01:28:00 --> Router Class Initialized
INFO - 2020-08-26 01:28:00 --> Output Class Initialized
INFO - 2020-08-26 01:28:00 --> Security Class Initialized
DEBUG - 2020-08-26 01:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 01:28:00 --> Input Class Initialized
INFO - 2020-08-26 01:28:00 --> Language Class Initialized
INFO - 2020-08-26 01:28:00 --> Language Class Initialized
INFO - 2020-08-26 01:28:00 --> Config Class Initialized
INFO - 2020-08-26 01:28:00 --> Loader Class Initialized
INFO - 2020-08-26 01:28:00 --> Helper loaded: url_helper
INFO - 2020-08-26 01:28:00 --> Helper loaded: form_helper
INFO - 2020-08-26 01:28:00 --> Helper loaded: file_helper
INFO - 2020-08-26 01:28:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 01:28:00 --> Database Driver Class Initialized
DEBUG - 2020-08-26 01:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 01:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 01:28:00 --> Upload Class Initialized
INFO - 2020-08-26 01:28:00 --> Controller Class Initialized
ERROR - 2020-08-26 01:28:00 --> 404 Page Not Found: /index
INFO - 2020-08-26 01:38:00 --> Config Class Initialized
INFO - 2020-08-26 01:38:00 --> Hooks Class Initialized
DEBUG - 2020-08-26 01:38:00 --> UTF-8 Support Enabled
INFO - 2020-08-26 01:38:00 --> Utf8 Class Initialized
INFO - 2020-08-26 01:38:00 --> URI Class Initialized
INFO - 2020-08-26 01:38:00 --> Router Class Initialized
INFO - 2020-08-26 01:38:00 --> Output Class Initialized
INFO - 2020-08-26 01:38:00 --> Security Class Initialized
DEBUG - 2020-08-26 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 01:38:00 --> Input Class Initialized
INFO - 2020-08-26 01:38:00 --> Language Class Initialized
INFO - 2020-08-26 01:38:00 --> Language Class Initialized
INFO - 2020-08-26 01:38:00 --> Config Class Initialized
INFO - 2020-08-26 01:38:00 --> Loader Class Initialized
INFO - 2020-08-26 01:38:00 --> Helper loaded: url_helper
INFO - 2020-08-26 01:38:00 --> Helper loaded: form_helper
INFO - 2020-08-26 01:38:00 --> Helper loaded: file_helper
INFO - 2020-08-26 01:38:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 01:38:00 --> Database Driver Class Initialized
DEBUG - 2020-08-26 01:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 01:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 01:38:00 --> Upload Class Initialized
INFO - 2020-08-26 01:38:00 --> Controller Class Initialized
ERROR - 2020-08-26 01:38:00 --> 404 Page Not Found: /index
INFO - 2020-08-26 01:38:00 --> Config Class Initialized
INFO - 2020-08-26 01:38:00 --> Hooks Class Initialized
DEBUG - 2020-08-26 01:38:00 --> UTF-8 Support Enabled
INFO - 2020-08-26 01:38:00 --> Utf8 Class Initialized
INFO - 2020-08-26 01:38:00 --> URI Class Initialized
INFO - 2020-08-26 01:38:00 --> Router Class Initialized
INFO - 2020-08-26 01:38:00 --> Output Class Initialized
INFO - 2020-08-26 01:38:00 --> Security Class Initialized
DEBUG - 2020-08-26 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 01:38:00 --> Input Class Initialized
INFO - 2020-08-26 01:38:00 --> Language Class Initialized
INFO - 2020-08-26 01:38:00 --> Language Class Initialized
INFO - 2020-08-26 01:38:00 --> Config Class Initialized
INFO - 2020-08-26 01:38:00 --> Loader Class Initialized
INFO - 2020-08-26 01:38:00 --> Helper loaded: url_helper
INFO - 2020-08-26 01:38:00 --> Helper loaded: form_helper
INFO - 2020-08-26 01:38:00 --> Helper loaded: file_helper
INFO - 2020-08-26 01:38:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 01:38:00 --> Database Driver Class Initialized
DEBUG - 2020-08-26 01:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 01:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 01:38:00 --> Upload Class Initialized
INFO - 2020-08-26 01:38:00 --> Controller Class Initialized
DEBUG - 2020-08-26 01:38:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 01:38:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-26 01:38:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 01:38:00 --> Final output sent to browser
DEBUG - 2020-08-26 01:38:00 --> Total execution time: 0.0584
INFO - 2020-08-26 02:01:37 --> Config Class Initialized
INFO - 2020-08-26 02:01:37 --> Hooks Class Initialized
DEBUG - 2020-08-26 02:01:37 --> UTF-8 Support Enabled
INFO - 2020-08-26 02:01:37 --> Utf8 Class Initialized
INFO - 2020-08-26 02:01:37 --> URI Class Initialized
DEBUG - 2020-08-26 02:01:37 --> No URI present. Default controller set.
INFO - 2020-08-26 02:01:37 --> Router Class Initialized
INFO - 2020-08-26 02:01:37 --> Output Class Initialized
INFO - 2020-08-26 02:01:37 --> Security Class Initialized
DEBUG - 2020-08-26 02:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 02:01:37 --> Input Class Initialized
INFO - 2020-08-26 02:01:37 --> Language Class Initialized
INFO - 2020-08-26 02:01:37 --> Language Class Initialized
INFO - 2020-08-26 02:01:37 --> Config Class Initialized
INFO - 2020-08-26 02:01:37 --> Loader Class Initialized
INFO - 2020-08-26 02:01:37 --> Helper loaded: url_helper
INFO - 2020-08-26 02:01:37 --> Helper loaded: form_helper
INFO - 2020-08-26 02:01:37 --> Helper loaded: file_helper
INFO - 2020-08-26 02:01:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 02:01:37 --> Database Driver Class Initialized
DEBUG - 2020-08-26 02:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 02:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 02:01:37 --> Upload Class Initialized
INFO - 2020-08-26 02:01:37 --> Controller Class Initialized
DEBUG - 2020-08-26 02:01:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 02:01:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 02:01:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 02:01:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 02:01:37 --> Final output sent to browser
DEBUG - 2020-08-26 02:01:37 --> Total execution time: 0.0517
INFO - 2020-08-26 02:12:11 --> Config Class Initialized
INFO - 2020-08-26 02:12:11 --> Hooks Class Initialized
DEBUG - 2020-08-26 02:12:11 --> UTF-8 Support Enabled
INFO - 2020-08-26 02:12:11 --> Utf8 Class Initialized
INFO - 2020-08-26 02:12:11 --> URI Class Initialized
DEBUG - 2020-08-26 02:12:11 --> No URI present. Default controller set.
INFO - 2020-08-26 02:12:11 --> Router Class Initialized
INFO - 2020-08-26 02:12:11 --> Output Class Initialized
INFO - 2020-08-26 02:12:11 --> Security Class Initialized
DEBUG - 2020-08-26 02:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 02:12:11 --> Input Class Initialized
INFO - 2020-08-26 02:12:11 --> Language Class Initialized
INFO - 2020-08-26 02:12:11 --> Language Class Initialized
INFO - 2020-08-26 02:12:11 --> Config Class Initialized
INFO - 2020-08-26 02:12:11 --> Loader Class Initialized
INFO - 2020-08-26 02:12:11 --> Helper loaded: url_helper
INFO - 2020-08-26 02:12:11 --> Helper loaded: form_helper
INFO - 2020-08-26 02:12:11 --> Helper loaded: file_helper
INFO - 2020-08-26 02:12:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 02:12:11 --> Database Driver Class Initialized
DEBUG - 2020-08-26 02:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 02:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 02:12:11 --> Upload Class Initialized
INFO - 2020-08-26 02:12:11 --> Controller Class Initialized
DEBUG - 2020-08-26 02:12:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 02:12:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 02:12:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 02:12:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 02:12:11 --> Final output sent to browser
DEBUG - 2020-08-26 02:12:11 --> Total execution time: 0.0500
INFO - 2020-08-26 02:15:51 --> Config Class Initialized
INFO - 2020-08-26 02:15:51 --> Hooks Class Initialized
DEBUG - 2020-08-26 02:15:51 --> UTF-8 Support Enabled
INFO - 2020-08-26 02:15:51 --> Utf8 Class Initialized
INFO - 2020-08-26 02:15:51 --> URI Class Initialized
INFO - 2020-08-26 02:15:51 --> Router Class Initialized
INFO - 2020-08-26 02:15:51 --> Output Class Initialized
INFO - 2020-08-26 02:15:51 --> Security Class Initialized
DEBUG - 2020-08-26 02:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 02:15:51 --> Input Class Initialized
INFO - 2020-08-26 02:15:51 --> Language Class Initialized
INFO - 2020-08-26 02:15:51 --> Language Class Initialized
INFO - 2020-08-26 02:15:51 --> Config Class Initialized
INFO - 2020-08-26 02:15:51 --> Loader Class Initialized
INFO - 2020-08-26 02:15:51 --> Helper loaded: url_helper
INFO - 2020-08-26 02:15:51 --> Helper loaded: form_helper
INFO - 2020-08-26 02:15:51 --> Helper loaded: file_helper
INFO - 2020-08-26 02:15:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 02:15:51 --> Database Driver Class Initialized
DEBUG - 2020-08-26 02:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 02:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 02:15:51 --> Upload Class Initialized
INFO - 2020-08-26 02:15:51 --> Controller Class Initialized
ERROR - 2020-08-26 02:15:51 --> 404 Page Not Found: /index
INFO - 2020-08-26 03:17:53 --> Config Class Initialized
INFO - 2020-08-26 03:17:53 --> Hooks Class Initialized
DEBUG - 2020-08-26 03:17:53 --> UTF-8 Support Enabled
INFO - 2020-08-26 03:17:53 --> Utf8 Class Initialized
INFO - 2020-08-26 03:17:53 --> URI Class Initialized
INFO - 2020-08-26 03:17:53 --> Router Class Initialized
INFO - 2020-08-26 03:17:53 --> Output Class Initialized
INFO - 2020-08-26 03:17:53 --> Security Class Initialized
DEBUG - 2020-08-26 03:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 03:17:53 --> Input Class Initialized
INFO - 2020-08-26 03:17:53 --> Language Class Initialized
INFO - 2020-08-26 03:17:53 --> Language Class Initialized
INFO - 2020-08-26 03:17:53 --> Config Class Initialized
INFO - 2020-08-26 03:17:53 --> Loader Class Initialized
INFO - 2020-08-26 03:17:53 --> Helper loaded: url_helper
INFO - 2020-08-26 03:17:53 --> Helper loaded: form_helper
INFO - 2020-08-26 03:17:53 --> Helper loaded: file_helper
INFO - 2020-08-26 03:17:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 03:17:53 --> Database Driver Class Initialized
DEBUG - 2020-08-26 03:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 03:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 03:17:53 --> Upload Class Initialized
INFO - 2020-08-26 03:17:53 --> Controller Class Initialized
ERROR - 2020-08-26 03:17:53 --> 404 Page Not Found: /index
INFO - 2020-08-26 03:47:37 --> Config Class Initialized
INFO - 2020-08-26 03:47:37 --> Hooks Class Initialized
DEBUG - 2020-08-26 03:47:37 --> UTF-8 Support Enabled
INFO - 2020-08-26 03:47:37 --> Utf8 Class Initialized
INFO - 2020-08-26 03:47:37 --> URI Class Initialized
DEBUG - 2020-08-26 03:47:37 --> No URI present. Default controller set.
INFO - 2020-08-26 03:47:37 --> Router Class Initialized
INFO - 2020-08-26 03:47:37 --> Output Class Initialized
INFO - 2020-08-26 03:47:37 --> Security Class Initialized
DEBUG - 2020-08-26 03:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 03:47:37 --> Input Class Initialized
INFO - 2020-08-26 03:47:37 --> Language Class Initialized
INFO - 2020-08-26 03:47:37 --> Language Class Initialized
INFO - 2020-08-26 03:47:37 --> Config Class Initialized
INFO - 2020-08-26 03:47:37 --> Loader Class Initialized
INFO - 2020-08-26 03:47:37 --> Helper loaded: url_helper
INFO - 2020-08-26 03:47:37 --> Helper loaded: form_helper
INFO - 2020-08-26 03:47:37 --> Helper loaded: file_helper
INFO - 2020-08-26 03:47:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 03:47:37 --> Database Driver Class Initialized
DEBUG - 2020-08-26 03:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 03:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 03:47:37 --> Upload Class Initialized
INFO - 2020-08-26 03:47:37 --> Controller Class Initialized
DEBUG - 2020-08-26 03:47:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 03:47:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 03:47:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 03:47:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 03:47:37 --> Final output sent to browser
DEBUG - 2020-08-26 03:47:37 --> Total execution time: 0.0499
INFO - 2020-08-26 04:27:58 --> Config Class Initialized
INFO - 2020-08-26 04:27:58 --> Hooks Class Initialized
DEBUG - 2020-08-26 04:27:58 --> UTF-8 Support Enabled
INFO - 2020-08-26 04:27:58 --> Utf8 Class Initialized
INFO - 2020-08-26 04:27:58 --> URI Class Initialized
INFO - 2020-08-26 04:27:58 --> Router Class Initialized
INFO - 2020-08-26 04:27:58 --> Output Class Initialized
INFO - 2020-08-26 04:27:58 --> Security Class Initialized
DEBUG - 2020-08-26 04:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 04:27:58 --> Input Class Initialized
INFO - 2020-08-26 04:27:58 --> Language Class Initialized
INFO - 2020-08-26 04:27:58 --> Language Class Initialized
INFO - 2020-08-26 04:27:58 --> Config Class Initialized
INFO - 2020-08-26 04:27:58 --> Loader Class Initialized
INFO - 2020-08-26 04:27:58 --> Helper loaded: url_helper
INFO - 2020-08-26 04:27:58 --> Helper loaded: form_helper
INFO - 2020-08-26 04:27:58 --> Helper loaded: file_helper
INFO - 2020-08-26 04:27:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 04:27:58 --> Database Driver Class Initialized
DEBUG - 2020-08-26 04:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 04:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 04:27:58 --> Upload Class Initialized
INFO - 2020-08-26 04:27:58 --> Controller Class Initialized
ERROR - 2020-08-26 04:27:58 --> 404 Page Not Found: /index
INFO - 2020-08-26 04:27:59 --> Config Class Initialized
INFO - 2020-08-26 04:27:59 --> Hooks Class Initialized
DEBUG - 2020-08-26 04:27:59 --> UTF-8 Support Enabled
INFO - 2020-08-26 04:27:59 --> Utf8 Class Initialized
INFO - 2020-08-26 04:27:59 --> URI Class Initialized
INFO - 2020-08-26 04:27:59 --> Router Class Initialized
INFO - 2020-08-26 04:27:59 --> Output Class Initialized
INFO - 2020-08-26 04:27:59 --> Security Class Initialized
DEBUG - 2020-08-26 04:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 04:27:59 --> Input Class Initialized
INFO - 2020-08-26 04:27:59 --> Language Class Initialized
INFO - 2020-08-26 04:27:59 --> Language Class Initialized
INFO - 2020-08-26 04:27:59 --> Config Class Initialized
INFO - 2020-08-26 04:27:59 --> Loader Class Initialized
INFO - 2020-08-26 04:27:59 --> Helper loaded: url_helper
INFO - 2020-08-26 04:27:59 --> Helper loaded: form_helper
INFO - 2020-08-26 04:27:59 --> Helper loaded: file_helper
INFO - 2020-08-26 04:27:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 04:27:59 --> Database Driver Class Initialized
DEBUG - 2020-08-26 04:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 04:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 04:27:59 --> Upload Class Initialized
INFO - 2020-08-26 04:27:59 --> Controller Class Initialized
ERROR - 2020-08-26 04:27:59 --> 404 Page Not Found: /index
INFO - 2020-08-26 04:28:01 --> Config Class Initialized
INFO - 2020-08-26 04:28:01 --> Hooks Class Initialized
DEBUG - 2020-08-26 04:28:01 --> UTF-8 Support Enabled
INFO - 2020-08-26 04:28:01 --> Utf8 Class Initialized
INFO - 2020-08-26 04:28:01 --> URI Class Initialized
DEBUG - 2020-08-26 04:28:01 --> No URI present. Default controller set.
INFO - 2020-08-26 04:28:01 --> Router Class Initialized
INFO - 2020-08-26 04:28:01 --> Output Class Initialized
INFO - 2020-08-26 04:28:01 --> Security Class Initialized
DEBUG - 2020-08-26 04:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 04:28:01 --> Input Class Initialized
INFO - 2020-08-26 04:28:01 --> Language Class Initialized
INFO - 2020-08-26 04:28:01 --> Language Class Initialized
INFO - 2020-08-26 04:28:01 --> Config Class Initialized
INFO - 2020-08-26 04:28:01 --> Loader Class Initialized
INFO - 2020-08-26 04:28:01 --> Helper loaded: url_helper
INFO - 2020-08-26 04:28:01 --> Helper loaded: form_helper
INFO - 2020-08-26 04:28:01 --> Helper loaded: file_helper
INFO - 2020-08-26 04:28:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 04:28:01 --> Database Driver Class Initialized
DEBUG - 2020-08-26 04:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 04:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 04:28:01 --> Upload Class Initialized
INFO - 2020-08-26 04:28:02 --> Controller Class Initialized
DEBUG - 2020-08-26 04:28:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 04:28:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 04:28:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 04:28:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 04:28:02 --> Final output sent to browser
DEBUG - 2020-08-26 04:28:02 --> Total execution time: 0.3121
INFO - 2020-08-26 04:28:05 --> Config Class Initialized
INFO - 2020-08-26 04:28:05 --> Hooks Class Initialized
DEBUG - 2020-08-26 04:28:05 --> UTF-8 Support Enabled
INFO - 2020-08-26 04:28:05 --> Utf8 Class Initialized
INFO - 2020-08-26 04:28:05 --> URI Class Initialized
INFO - 2020-08-26 04:28:05 --> Router Class Initialized
INFO - 2020-08-26 04:28:05 --> Output Class Initialized
INFO - 2020-08-26 04:28:05 --> Security Class Initialized
DEBUG - 2020-08-26 04:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 04:28:05 --> Input Class Initialized
INFO - 2020-08-26 04:28:05 --> Language Class Initialized
INFO - 2020-08-26 04:28:05 --> Language Class Initialized
INFO - 2020-08-26 04:28:05 --> Config Class Initialized
INFO - 2020-08-26 04:28:05 --> Loader Class Initialized
INFO - 2020-08-26 04:28:05 --> Helper loaded: url_helper
INFO - 2020-08-26 04:28:05 --> Helper loaded: form_helper
INFO - 2020-08-26 04:28:05 --> Helper loaded: file_helper
INFO - 2020-08-26 04:28:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 04:28:05 --> Database Driver Class Initialized
DEBUG - 2020-08-26 04:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 04:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 04:28:05 --> Upload Class Initialized
INFO - 2020-08-26 04:28:05 --> Controller Class Initialized
ERROR - 2020-08-26 04:28:05 --> 404 Page Not Found: /index
INFO - 2020-08-26 04:28:09 --> Config Class Initialized
INFO - 2020-08-26 04:28:09 --> Hooks Class Initialized
DEBUG - 2020-08-26 04:28:09 --> UTF-8 Support Enabled
INFO - 2020-08-26 04:28:09 --> Utf8 Class Initialized
INFO - 2020-08-26 04:28:09 --> URI Class Initialized
DEBUG - 2020-08-26 04:28:09 --> No URI present. Default controller set.
INFO - 2020-08-26 04:28:09 --> Router Class Initialized
INFO - 2020-08-26 04:28:09 --> Output Class Initialized
INFO - 2020-08-26 04:28:09 --> Security Class Initialized
DEBUG - 2020-08-26 04:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 04:28:09 --> Input Class Initialized
INFO - 2020-08-26 04:28:09 --> Language Class Initialized
INFO - 2020-08-26 04:28:09 --> Language Class Initialized
INFO - 2020-08-26 04:28:09 --> Config Class Initialized
INFO - 2020-08-26 04:28:09 --> Loader Class Initialized
INFO - 2020-08-26 04:28:09 --> Helper loaded: url_helper
INFO - 2020-08-26 04:28:09 --> Helper loaded: form_helper
INFO - 2020-08-26 04:28:09 --> Helper loaded: file_helper
INFO - 2020-08-26 04:28:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 04:28:09 --> Database Driver Class Initialized
DEBUG - 2020-08-26 04:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 04:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 04:28:09 --> Upload Class Initialized
INFO - 2020-08-26 04:28:09 --> Controller Class Initialized
DEBUG - 2020-08-26 04:28:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 04:28:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 04:28:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 04:28:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 04:28:09 --> Final output sent to browser
DEBUG - 2020-08-26 04:28:09 --> Total execution time: 0.0509
INFO - 2020-08-26 05:59:29 --> Config Class Initialized
INFO - 2020-08-26 05:59:29 --> Hooks Class Initialized
DEBUG - 2020-08-26 05:59:29 --> UTF-8 Support Enabled
INFO - 2020-08-26 05:59:29 --> Utf8 Class Initialized
INFO - 2020-08-26 05:59:29 --> URI Class Initialized
DEBUG - 2020-08-26 05:59:29 --> No URI present. Default controller set.
INFO - 2020-08-26 05:59:29 --> Router Class Initialized
INFO - 2020-08-26 05:59:29 --> Output Class Initialized
INFO - 2020-08-26 05:59:29 --> Security Class Initialized
DEBUG - 2020-08-26 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 05:59:29 --> Input Class Initialized
INFO - 2020-08-26 05:59:29 --> Language Class Initialized
INFO - 2020-08-26 05:59:29 --> Language Class Initialized
INFO - 2020-08-26 05:59:29 --> Config Class Initialized
INFO - 2020-08-26 05:59:29 --> Loader Class Initialized
INFO - 2020-08-26 05:59:29 --> Helper loaded: url_helper
INFO - 2020-08-26 05:59:29 --> Helper loaded: form_helper
INFO - 2020-08-26 05:59:29 --> Helper loaded: file_helper
INFO - 2020-08-26 05:59:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 05:59:29 --> Database Driver Class Initialized
DEBUG - 2020-08-26 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 05:59:29 --> Upload Class Initialized
INFO - 2020-08-26 05:59:29 --> Controller Class Initialized
DEBUG - 2020-08-26 05:59:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 05:59:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 05:59:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 05:59:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 05:59:29 --> Final output sent to browser
DEBUG - 2020-08-26 05:59:29 --> Total execution time: 0.0530
INFO - 2020-08-26 05:59:30 --> Config Class Initialized
INFO - 2020-08-26 05:59:30 --> Hooks Class Initialized
DEBUG - 2020-08-26 05:59:30 --> UTF-8 Support Enabled
INFO - 2020-08-26 05:59:30 --> Utf8 Class Initialized
INFO - 2020-08-26 05:59:30 --> URI Class Initialized
INFO - 2020-08-26 05:59:30 --> Router Class Initialized
INFO - 2020-08-26 05:59:30 --> Output Class Initialized
INFO - 2020-08-26 05:59:30 --> Security Class Initialized
DEBUG - 2020-08-26 05:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 05:59:30 --> Input Class Initialized
INFO - 2020-08-26 05:59:30 --> Language Class Initialized
INFO - 2020-08-26 05:59:30 --> Language Class Initialized
INFO - 2020-08-26 05:59:30 --> Config Class Initialized
INFO - 2020-08-26 05:59:30 --> Loader Class Initialized
INFO - 2020-08-26 05:59:30 --> Helper loaded: url_helper
INFO - 2020-08-26 05:59:30 --> Helper loaded: form_helper
INFO - 2020-08-26 05:59:30 --> Helper loaded: file_helper
INFO - 2020-08-26 05:59:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 05:59:30 --> Database Driver Class Initialized
DEBUG - 2020-08-26 05:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 05:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 05:59:30 --> Upload Class Initialized
INFO - 2020-08-26 05:59:30 --> Controller Class Initialized
ERROR - 2020-08-26 05:59:30 --> 404 Page Not Found: /index
INFO - 2020-08-26 05:59:31 --> Config Class Initialized
INFO - 2020-08-26 05:59:31 --> Hooks Class Initialized
DEBUG - 2020-08-26 05:59:31 --> UTF-8 Support Enabled
INFO - 2020-08-26 05:59:31 --> Utf8 Class Initialized
INFO - 2020-08-26 05:59:31 --> URI Class Initialized
DEBUG - 2020-08-26 05:59:31 --> No URI present. Default controller set.
INFO - 2020-08-26 05:59:31 --> Router Class Initialized
INFO - 2020-08-26 05:59:31 --> Output Class Initialized
INFO - 2020-08-26 05:59:31 --> Security Class Initialized
DEBUG - 2020-08-26 05:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 05:59:31 --> Input Class Initialized
INFO - 2020-08-26 05:59:31 --> Language Class Initialized
INFO - 2020-08-26 05:59:31 --> Language Class Initialized
INFO - 2020-08-26 05:59:31 --> Config Class Initialized
INFO - 2020-08-26 05:59:31 --> Loader Class Initialized
INFO - 2020-08-26 05:59:31 --> Helper loaded: url_helper
INFO - 2020-08-26 05:59:31 --> Helper loaded: form_helper
INFO - 2020-08-26 05:59:31 --> Helper loaded: file_helper
INFO - 2020-08-26 05:59:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 05:59:31 --> Database Driver Class Initialized
DEBUG - 2020-08-26 05:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 05:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 05:59:31 --> Upload Class Initialized
INFO - 2020-08-26 05:59:31 --> Controller Class Initialized
DEBUG - 2020-08-26 05:59:31 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 05:59:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 05:59:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 05:59:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 05:59:31 --> Final output sent to browser
DEBUG - 2020-08-26 05:59:31 --> Total execution time: 0.0515
INFO - 2020-08-26 05:59:33 --> Config Class Initialized
INFO - 2020-08-26 05:59:33 --> Hooks Class Initialized
DEBUG - 2020-08-26 05:59:33 --> UTF-8 Support Enabled
INFO - 2020-08-26 05:59:33 --> Utf8 Class Initialized
INFO - 2020-08-26 05:59:33 --> URI Class Initialized
INFO - 2020-08-26 05:59:33 --> Router Class Initialized
INFO - 2020-08-26 05:59:33 --> Output Class Initialized
INFO - 2020-08-26 05:59:33 --> Security Class Initialized
DEBUG - 2020-08-26 05:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 05:59:33 --> Input Class Initialized
INFO - 2020-08-26 05:59:33 --> Language Class Initialized
INFO - 2020-08-26 05:59:33 --> Language Class Initialized
INFO - 2020-08-26 05:59:33 --> Config Class Initialized
INFO - 2020-08-26 05:59:33 --> Loader Class Initialized
INFO - 2020-08-26 05:59:33 --> Helper loaded: url_helper
INFO - 2020-08-26 05:59:33 --> Helper loaded: form_helper
INFO - 2020-08-26 05:59:33 --> Helper loaded: file_helper
INFO - 2020-08-26 05:59:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 05:59:33 --> Database Driver Class Initialized
DEBUG - 2020-08-26 05:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 05:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 05:59:33 --> Upload Class Initialized
INFO - 2020-08-26 05:59:33 --> Controller Class Initialized
ERROR - 2020-08-26 05:59:33 --> 404 Page Not Found: /index
INFO - 2020-08-26 06:50:09 --> Config Class Initialized
INFO - 2020-08-26 06:50:09 --> Hooks Class Initialized
DEBUG - 2020-08-26 06:50:09 --> UTF-8 Support Enabled
INFO - 2020-08-26 06:50:09 --> Utf8 Class Initialized
INFO - 2020-08-26 06:50:09 --> URI Class Initialized
DEBUG - 2020-08-26 06:50:09 --> No URI present. Default controller set.
INFO - 2020-08-26 06:50:09 --> Router Class Initialized
INFO - 2020-08-26 06:50:09 --> Output Class Initialized
INFO - 2020-08-26 06:50:09 --> Security Class Initialized
DEBUG - 2020-08-26 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 06:50:09 --> Input Class Initialized
INFO - 2020-08-26 06:50:09 --> Language Class Initialized
INFO - 2020-08-26 06:50:09 --> Language Class Initialized
INFO - 2020-08-26 06:50:09 --> Config Class Initialized
INFO - 2020-08-26 06:50:09 --> Loader Class Initialized
INFO - 2020-08-26 06:50:09 --> Helper loaded: url_helper
INFO - 2020-08-26 06:50:09 --> Helper loaded: form_helper
INFO - 2020-08-26 06:50:09 --> Helper loaded: file_helper
INFO - 2020-08-26 06:50:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 06:50:09 --> Database Driver Class Initialized
DEBUG - 2020-08-26 06:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 06:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 06:50:09 --> Upload Class Initialized
INFO - 2020-08-26 06:50:09 --> Controller Class Initialized
DEBUG - 2020-08-26 06:50:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 06:50:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 06:50:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 06:50:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 06:50:09 --> Final output sent to browser
DEBUG - 2020-08-26 06:50:09 --> Total execution time: 0.0502
INFO - 2020-08-26 07:49:42 --> Config Class Initialized
INFO - 2020-08-26 07:49:42 --> Hooks Class Initialized
DEBUG - 2020-08-26 07:49:42 --> UTF-8 Support Enabled
INFO - 2020-08-26 07:49:42 --> Utf8 Class Initialized
INFO - 2020-08-26 07:49:42 --> URI Class Initialized
DEBUG - 2020-08-26 07:49:42 --> No URI present. Default controller set.
INFO - 2020-08-26 07:49:42 --> Router Class Initialized
INFO - 2020-08-26 07:49:42 --> Output Class Initialized
INFO - 2020-08-26 07:49:42 --> Security Class Initialized
DEBUG - 2020-08-26 07:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 07:49:42 --> Input Class Initialized
INFO - 2020-08-26 07:49:42 --> Language Class Initialized
INFO - 2020-08-26 07:49:42 --> Language Class Initialized
INFO - 2020-08-26 07:49:42 --> Config Class Initialized
INFO - 2020-08-26 07:49:42 --> Loader Class Initialized
INFO - 2020-08-26 07:49:42 --> Helper loaded: url_helper
INFO - 2020-08-26 07:49:42 --> Helper loaded: form_helper
INFO - 2020-08-26 07:49:42 --> Helper loaded: file_helper
INFO - 2020-08-26 07:49:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 07:49:42 --> Database Driver Class Initialized
DEBUG - 2020-08-26 07:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 07:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 07:49:42 --> Upload Class Initialized
INFO - 2020-08-26 07:49:42 --> Controller Class Initialized
DEBUG - 2020-08-26 07:49:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 07:49:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 07:49:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 07:49:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 07:49:42 --> Final output sent to browser
DEBUG - 2020-08-26 07:49:42 --> Total execution time: 0.0493
INFO - 2020-08-26 09:04:39 --> Config Class Initialized
INFO - 2020-08-26 09:04:39 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:04:39 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:04:39 --> Utf8 Class Initialized
INFO - 2020-08-26 09:04:39 --> URI Class Initialized
INFO - 2020-08-26 09:04:39 --> Router Class Initialized
INFO - 2020-08-26 09:04:39 --> Output Class Initialized
INFO - 2020-08-26 09:04:39 --> Security Class Initialized
DEBUG - 2020-08-26 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:04:39 --> Input Class Initialized
INFO - 2020-08-26 09:04:39 --> Language Class Initialized
INFO - 2020-08-26 09:04:39 --> Language Class Initialized
INFO - 2020-08-26 09:04:39 --> Config Class Initialized
INFO - 2020-08-26 09:04:39 --> Loader Class Initialized
INFO - 2020-08-26 09:04:39 --> Helper loaded: url_helper
INFO - 2020-08-26 09:04:39 --> Helper loaded: form_helper
INFO - 2020-08-26 09:04:39 --> Helper loaded: file_helper
INFO - 2020-08-26 09:04:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 09:04:39 --> Database Driver Class Initialized
DEBUG - 2020-08-26 09:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 09:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:04:39 --> Upload Class Initialized
INFO - 2020-08-26 09:04:39 --> Controller Class Initialized
DEBUG - 2020-08-26 09:04:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 09:04:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 09:04:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 09:04:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 09:04:39 --> Final output sent to browser
DEBUG - 2020-08-26 09:04:39 --> Total execution time: 0.1651
INFO - 2020-08-26 09:04:42 --> Config Class Initialized
INFO - 2020-08-26 09:04:42 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:04:42 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:04:42 --> Utf8 Class Initialized
INFO - 2020-08-26 09:04:42 --> URI Class Initialized
INFO - 2020-08-26 09:04:42 --> Router Class Initialized
INFO - 2020-08-26 09:04:42 --> Output Class Initialized
INFO - 2020-08-26 09:04:42 --> Security Class Initialized
DEBUG - 2020-08-26 09:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:04:42 --> Input Class Initialized
INFO - 2020-08-26 09:04:42 --> Language Class Initialized
INFO - 2020-08-26 09:04:42 --> Language Class Initialized
INFO - 2020-08-26 09:04:42 --> Config Class Initialized
INFO - 2020-08-26 09:04:42 --> Loader Class Initialized
INFO - 2020-08-26 09:04:42 --> Helper loaded: url_helper
INFO - 2020-08-26 09:04:42 --> Helper loaded: form_helper
INFO - 2020-08-26 09:04:42 --> Helper loaded: file_helper
INFO - 2020-08-26 09:04:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 09:04:42 --> Database Driver Class Initialized
DEBUG - 2020-08-26 09:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 09:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:04:42 --> Upload Class Initialized
INFO - 2020-08-26 09:04:42 --> Controller Class Initialized
ERROR - 2020-08-26 09:04:42 --> 404 Page Not Found: /index
INFO - 2020-08-26 09:57:54 --> Config Class Initialized
INFO - 2020-08-26 09:57:54 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:57:54 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:57:54 --> Utf8 Class Initialized
INFO - 2020-08-26 09:57:54 --> URI Class Initialized
DEBUG - 2020-08-26 09:57:54 --> No URI present. Default controller set.
INFO - 2020-08-26 09:57:54 --> Router Class Initialized
INFO - 2020-08-26 09:57:54 --> Output Class Initialized
INFO - 2020-08-26 09:57:54 --> Security Class Initialized
DEBUG - 2020-08-26 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:57:54 --> Input Class Initialized
INFO - 2020-08-26 09:57:54 --> Language Class Initialized
INFO - 2020-08-26 09:57:54 --> Language Class Initialized
INFO - 2020-08-26 09:57:54 --> Config Class Initialized
INFO - 2020-08-26 09:57:54 --> Loader Class Initialized
INFO - 2020-08-26 09:57:54 --> Helper loaded: url_helper
INFO - 2020-08-26 09:57:54 --> Helper loaded: form_helper
INFO - 2020-08-26 09:57:54 --> Helper loaded: file_helper
INFO - 2020-08-26 09:57:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 09:57:54 --> Database Driver Class Initialized
DEBUG - 2020-08-26 09:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 09:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:57:54 --> Upload Class Initialized
INFO - 2020-08-26 09:57:54 --> Controller Class Initialized
DEBUG - 2020-08-26 09:57:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 09:57:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 09:57:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 09:57:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 09:57:54 --> Final output sent to browser
DEBUG - 2020-08-26 09:57:54 --> Total execution time: 0.0678
INFO - 2020-08-26 10:48:13 --> Config Class Initialized
INFO - 2020-08-26 10:48:13 --> Hooks Class Initialized
DEBUG - 2020-08-26 10:48:13 --> UTF-8 Support Enabled
INFO - 2020-08-26 10:48:13 --> Utf8 Class Initialized
INFO - 2020-08-26 10:48:13 --> URI Class Initialized
DEBUG - 2020-08-26 10:48:13 --> No URI present. Default controller set.
INFO - 2020-08-26 10:48:13 --> Router Class Initialized
INFO - 2020-08-26 10:48:13 --> Output Class Initialized
INFO - 2020-08-26 10:48:13 --> Security Class Initialized
DEBUG - 2020-08-26 10:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 10:48:13 --> Input Class Initialized
INFO - 2020-08-26 10:48:13 --> Language Class Initialized
INFO - 2020-08-26 10:48:13 --> Language Class Initialized
INFO - 2020-08-26 10:48:13 --> Config Class Initialized
INFO - 2020-08-26 10:48:13 --> Loader Class Initialized
INFO - 2020-08-26 10:48:13 --> Helper loaded: url_helper
INFO - 2020-08-26 10:48:13 --> Helper loaded: form_helper
INFO - 2020-08-26 10:48:13 --> Helper loaded: file_helper
INFO - 2020-08-26 10:48:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 10:48:13 --> Database Driver Class Initialized
DEBUG - 2020-08-26 10:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 10:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 10:48:13 --> Upload Class Initialized
INFO - 2020-08-26 10:48:13 --> Controller Class Initialized
DEBUG - 2020-08-26 10:48:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 10:48:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 10:48:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 10:48:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 10:48:13 --> Final output sent to browser
DEBUG - 2020-08-26 10:48:13 --> Total execution time: 0.1248
INFO - 2020-08-26 10:48:14 --> Config Class Initialized
INFO - 2020-08-26 10:48:14 --> Hooks Class Initialized
DEBUG - 2020-08-26 10:48:14 --> UTF-8 Support Enabled
INFO - 2020-08-26 10:48:14 --> Utf8 Class Initialized
INFO - 2020-08-26 10:48:14 --> URI Class Initialized
INFO - 2020-08-26 10:48:14 --> Router Class Initialized
INFO - 2020-08-26 10:48:14 --> Output Class Initialized
INFO - 2020-08-26 10:48:14 --> Security Class Initialized
DEBUG - 2020-08-26 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 10:48:14 --> Input Class Initialized
INFO - 2020-08-26 10:48:14 --> Language Class Initialized
INFO - 2020-08-26 10:48:14 --> Language Class Initialized
INFO - 2020-08-26 10:48:14 --> Config Class Initialized
INFO - 2020-08-26 10:48:14 --> Loader Class Initialized
INFO - 2020-08-26 10:48:14 --> Helper loaded: url_helper
INFO - 2020-08-26 10:48:14 --> Helper loaded: form_helper
INFO - 2020-08-26 10:48:14 --> Helper loaded: file_helper
INFO - 2020-08-26 10:48:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 10:48:14 --> Database Driver Class Initialized
DEBUG - 2020-08-26 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 10:48:14 --> Upload Class Initialized
INFO - 2020-08-26 10:48:14 --> Controller Class Initialized
ERROR - 2020-08-26 10:48:14 --> 404 Page Not Found: /index
INFO - 2020-08-26 10:48:14 --> Config Class Initialized
INFO - 2020-08-26 10:48:14 --> Hooks Class Initialized
DEBUG - 2020-08-26 10:48:14 --> UTF-8 Support Enabled
INFO - 2020-08-26 10:48:14 --> Utf8 Class Initialized
INFO - 2020-08-26 10:48:14 --> URI Class Initialized
DEBUG - 2020-08-26 10:48:14 --> No URI present. Default controller set.
INFO - 2020-08-26 10:48:14 --> Router Class Initialized
INFO - 2020-08-26 10:48:14 --> Output Class Initialized
INFO - 2020-08-26 10:48:14 --> Security Class Initialized
DEBUG - 2020-08-26 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 10:48:14 --> Input Class Initialized
INFO - 2020-08-26 10:48:14 --> Language Class Initialized
INFO - 2020-08-26 10:48:14 --> Language Class Initialized
INFO - 2020-08-26 10:48:14 --> Config Class Initialized
INFO - 2020-08-26 10:48:14 --> Loader Class Initialized
INFO - 2020-08-26 10:48:14 --> Helper loaded: url_helper
INFO - 2020-08-26 10:48:14 --> Helper loaded: form_helper
INFO - 2020-08-26 10:48:14 --> Helper loaded: file_helper
INFO - 2020-08-26 10:48:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 10:48:14 --> Database Driver Class Initialized
DEBUG - 2020-08-26 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 10:48:14 --> Upload Class Initialized
INFO - 2020-08-26 10:48:14 --> Controller Class Initialized
DEBUG - 2020-08-26 10:48:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 10:48:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 10:48:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 10:48:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 10:48:14 --> Final output sent to browser
DEBUG - 2020-08-26 10:48:14 --> Total execution time: 0.0488
INFO - 2020-08-26 11:07:25 --> Config Class Initialized
INFO - 2020-08-26 11:07:25 --> Hooks Class Initialized
DEBUG - 2020-08-26 11:07:25 --> UTF-8 Support Enabled
INFO - 2020-08-26 11:07:25 --> Utf8 Class Initialized
INFO - 2020-08-26 11:07:25 --> URI Class Initialized
INFO - 2020-08-26 11:07:25 --> Router Class Initialized
INFO - 2020-08-26 11:07:25 --> Output Class Initialized
INFO - 2020-08-26 11:07:25 --> Security Class Initialized
DEBUG - 2020-08-26 11:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 11:07:25 --> Input Class Initialized
INFO - 2020-08-26 11:07:25 --> Language Class Initialized
INFO - 2020-08-26 11:07:25 --> Language Class Initialized
INFO - 2020-08-26 11:07:25 --> Config Class Initialized
INFO - 2020-08-26 11:07:25 --> Loader Class Initialized
INFO - 2020-08-26 11:07:25 --> Helper loaded: url_helper
INFO - 2020-08-26 11:07:25 --> Helper loaded: form_helper
INFO - 2020-08-26 11:07:25 --> Helper loaded: file_helper
INFO - 2020-08-26 11:07:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 11:07:25 --> Database Driver Class Initialized
DEBUG - 2020-08-26 11:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 11:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 11:07:25 --> Upload Class Initialized
INFO - 2020-08-26 11:07:25 --> Controller Class Initialized
ERROR - 2020-08-26 11:07:25 --> 404 Page Not Found: /index
INFO - 2020-08-26 12:08:45 --> Config Class Initialized
INFO - 2020-08-26 12:08:45 --> Hooks Class Initialized
DEBUG - 2020-08-26 12:08:45 --> UTF-8 Support Enabled
INFO - 2020-08-26 12:08:45 --> Utf8 Class Initialized
INFO - 2020-08-26 12:08:45 --> URI Class Initialized
INFO - 2020-08-26 12:08:45 --> Router Class Initialized
INFO - 2020-08-26 12:08:45 --> Output Class Initialized
INFO - 2020-08-26 12:08:45 --> Security Class Initialized
DEBUG - 2020-08-26 12:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 12:08:45 --> Input Class Initialized
INFO - 2020-08-26 12:08:45 --> Language Class Initialized
INFO - 2020-08-26 12:08:45 --> Language Class Initialized
INFO - 2020-08-26 12:08:45 --> Config Class Initialized
INFO - 2020-08-26 12:08:45 --> Loader Class Initialized
INFO - 2020-08-26 12:08:45 --> Helper loaded: url_helper
INFO - 2020-08-26 12:08:45 --> Helper loaded: form_helper
INFO - 2020-08-26 12:08:45 --> Helper loaded: file_helper
INFO - 2020-08-26 12:08:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 12:08:45 --> Database Driver Class Initialized
DEBUG - 2020-08-26 12:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 12:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 12:08:45 --> Upload Class Initialized
INFO - 2020-08-26 12:08:45 --> Controller Class Initialized
DEBUG - 2020-08-26 12:08:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 12:08:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-26 12:08:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 12:08:45 --> Final output sent to browser
DEBUG - 2020-08-26 12:08:45 --> Total execution time: 0.0549
INFO - 2020-08-26 12:08:52 --> Config Class Initialized
INFO - 2020-08-26 12:08:52 --> Hooks Class Initialized
DEBUG - 2020-08-26 12:08:52 --> UTF-8 Support Enabled
INFO - 2020-08-26 12:08:52 --> Utf8 Class Initialized
INFO - 2020-08-26 12:08:52 --> URI Class Initialized
INFO - 2020-08-26 12:08:52 --> Router Class Initialized
INFO - 2020-08-26 12:08:52 --> Output Class Initialized
INFO - 2020-08-26 12:08:52 --> Security Class Initialized
DEBUG - 2020-08-26 12:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 12:08:52 --> Input Class Initialized
INFO - 2020-08-26 12:08:52 --> Language Class Initialized
INFO - 2020-08-26 12:08:52 --> Language Class Initialized
INFO - 2020-08-26 12:08:52 --> Config Class Initialized
INFO - 2020-08-26 12:08:52 --> Loader Class Initialized
INFO - 2020-08-26 12:08:52 --> Helper loaded: url_helper
INFO - 2020-08-26 12:08:52 --> Helper loaded: form_helper
INFO - 2020-08-26 12:08:52 --> Helper loaded: file_helper
INFO - 2020-08-26 12:08:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 12:08:52 --> Database Driver Class Initialized
DEBUG - 2020-08-26 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 12:08:52 --> Upload Class Initialized
INFO - 2020-08-26 12:08:52 --> Controller Class Initialized
ERROR - 2020-08-26 12:08:52 --> 404 Page Not Found: /index
INFO - 2020-08-26 13:05:26 --> Config Class Initialized
INFO - 2020-08-26 13:05:26 --> Hooks Class Initialized
DEBUG - 2020-08-26 13:05:26 --> UTF-8 Support Enabled
INFO - 2020-08-26 13:05:26 --> Utf8 Class Initialized
INFO - 2020-08-26 13:05:26 --> URI Class Initialized
DEBUG - 2020-08-26 13:05:26 --> No URI present. Default controller set.
INFO - 2020-08-26 13:05:26 --> Router Class Initialized
INFO - 2020-08-26 13:05:26 --> Output Class Initialized
INFO - 2020-08-26 13:05:26 --> Security Class Initialized
DEBUG - 2020-08-26 13:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 13:05:26 --> Input Class Initialized
INFO - 2020-08-26 13:05:26 --> Language Class Initialized
INFO - 2020-08-26 13:05:26 --> Language Class Initialized
INFO - 2020-08-26 13:05:26 --> Config Class Initialized
INFO - 2020-08-26 13:05:26 --> Loader Class Initialized
INFO - 2020-08-26 13:05:26 --> Helper loaded: url_helper
INFO - 2020-08-26 13:05:26 --> Helper loaded: form_helper
INFO - 2020-08-26 13:05:26 --> Helper loaded: file_helper
INFO - 2020-08-26 13:05:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 13:05:26 --> Database Driver Class Initialized
DEBUG - 2020-08-26 13:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 13:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 13:05:26 --> Upload Class Initialized
INFO - 2020-08-26 13:05:26 --> Controller Class Initialized
DEBUG - 2020-08-26 13:05:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 13:05:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 13:05:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 13:05:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 13:05:26 --> Final output sent to browser
DEBUG - 2020-08-26 13:05:26 --> Total execution time: 0.0536
INFO - 2020-08-26 13:06:24 --> Config Class Initialized
INFO - 2020-08-26 13:06:24 --> Hooks Class Initialized
DEBUG - 2020-08-26 13:06:24 --> UTF-8 Support Enabled
INFO - 2020-08-26 13:06:24 --> Utf8 Class Initialized
INFO - 2020-08-26 13:06:24 --> URI Class Initialized
DEBUG - 2020-08-26 13:06:24 --> No URI present. Default controller set.
INFO - 2020-08-26 13:06:24 --> Router Class Initialized
INFO - 2020-08-26 13:06:24 --> Output Class Initialized
INFO - 2020-08-26 13:06:24 --> Security Class Initialized
DEBUG - 2020-08-26 13:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 13:06:24 --> Input Class Initialized
INFO - 2020-08-26 13:06:24 --> Language Class Initialized
INFO - 2020-08-26 13:06:24 --> Language Class Initialized
INFO - 2020-08-26 13:06:24 --> Config Class Initialized
INFO - 2020-08-26 13:06:24 --> Loader Class Initialized
INFO - 2020-08-26 13:06:24 --> Helper loaded: url_helper
INFO - 2020-08-26 13:06:24 --> Helper loaded: form_helper
INFO - 2020-08-26 13:06:24 --> Helper loaded: file_helper
INFO - 2020-08-26 13:06:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 13:06:24 --> Database Driver Class Initialized
DEBUG - 2020-08-26 13:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 13:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 13:06:24 --> Upload Class Initialized
INFO - 2020-08-26 13:06:24 --> Controller Class Initialized
DEBUG - 2020-08-26 13:06:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 13:06:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 13:06:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 13:06:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 13:06:24 --> Final output sent to browser
DEBUG - 2020-08-26 13:06:24 --> Total execution time: 0.0526
INFO - 2020-08-26 13:08:59 --> Config Class Initialized
INFO - 2020-08-26 13:08:59 --> Hooks Class Initialized
DEBUG - 2020-08-26 13:08:59 --> UTF-8 Support Enabled
INFO - 2020-08-26 13:08:59 --> Utf8 Class Initialized
INFO - 2020-08-26 13:08:59 --> URI Class Initialized
INFO - 2020-08-26 13:08:59 --> Router Class Initialized
INFO - 2020-08-26 13:08:59 --> Output Class Initialized
INFO - 2020-08-26 13:08:59 --> Security Class Initialized
DEBUG - 2020-08-26 13:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 13:08:59 --> Input Class Initialized
INFO - 2020-08-26 13:08:59 --> Language Class Initialized
INFO - 2020-08-26 13:08:59 --> Language Class Initialized
INFO - 2020-08-26 13:08:59 --> Config Class Initialized
INFO - 2020-08-26 13:08:59 --> Loader Class Initialized
INFO - 2020-08-26 13:08:59 --> Helper loaded: url_helper
INFO - 2020-08-26 13:09:00 --> Helper loaded: form_helper
INFO - 2020-08-26 13:09:00 --> Helper loaded: file_helper
INFO - 2020-08-26 13:09:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 13:09:00 --> Database Driver Class Initialized
DEBUG - 2020-08-26 13:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 13:09:00 --> Upload Class Initialized
INFO - 2020-08-26 13:09:00 --> Controller Class Initialized
ERROR - 2020-08-26 13:09:00 --> 404 Page Not Found: /index
INFO - 2020-08-26 13:44:09 --> Config Class Initialized
INFO - 2020-08-26 13:44:09 --> Hooks Class Initialized
DEBUG - 2020-08-26 13:44:09 --> UTF-8 Support Enabled
INFO - 2020-08-26 13:44:09 --> Utf8 Class Initialized
INFO - 2020-08-26 13:44:09 --> URI Class Initialized
INFO - 2020-08-26 13:44:09 --> Router Class Initialized
INFO - 2020-08-26 13:44:09 --> Output Class Initialized
INFO - 2020-08-26 13:44:09 --> Security Class Initialized
DEBUG - 2020-08-26 13:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 13:44:09 --> Input Class Initialized
INFO - 2020-08-26 13:44:09 --> Language Class Initialized
INFO - 2020-08-26 13:44:09 --> Language Class Initialized
INFO - 2020-08-26 13:44:09 --> Config Class Initialized
INFO - 2020-08-26 13:44:09 --> Loader Class Initialized
INFO - 2020-08-26 13:44:09 --> Helper loaded: url_helper
INFO - 2020-08-26 13:44:09 --> Helper loaded: form_helper
INFO - 2020-08-26 13:44:09 --> Helper loaded: file_helper
INFO - 2020-08-26 13:44:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 13:44:09 --> Database Driver Class Initialized
DEBUG - 2020-08-26 13:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 13:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 13:44:09 --> Upload Class Initialized
INFO - 2020-08-26 13:44:09 --> Controller Class Initialized
ERROR - 2020-08-26 13:44:09 --> 404 Page Not Found: /index
INFO - 2020-08-26 13:44:11 --> Config Class Initialized
INFO - 2020-08-26 13:44:11 --> Hooks Class Initialized
DEBUG - 2020-08-26 13:44:11 --> UTF-8 Support Enabled
INFO - 2020-08-26 13:44:11 --> Utf8 Class Initialized
INFO - 2020-08-26 13:44:11 --> URI Class Initialized
INFO - 2020-08-26 13:44:11 --> Router Class Initialized
INFO - 2020-08-26 13:44:11 --> Output Class Initialized
INFO - 2020-08-26 13:44:11 --> Security Class Initialized
DEBUG - 2020-08-26 13:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 13:44:11 --> Input Class Initialized
INFO - 2020-08-26 13:44:11 --> Language Class Initialized
INFO - 2020-08-26 13:44:11 --> Language Class Initialized
INFO - 2020-08-26 13:44:11 --> Config Class Initialized
INFO - 2020-08-26 13:44:11 --> Loader Class Initialized
INFO - 2020-08-26 13:44:11 --> Helper loaded: url_helper
INFO - 2020-08-26 13:44:11 --> Helper loaded: form_helper
INFO - 2020-08-26 13:44:11 --> Helper loaded: file_helper
INFO - 2020-08-26 13:44:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 13:44:11 --> Database Driver Class Initialized
DEBUG - 2020-08-26 13:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 13:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 13:44:11 --> Upload Class Initialized
INFO - 2020-08-26 13:44:11 --> Controller Class Initialized
ERROR - 2020-08-26 13:44:11 --> 404 Page Not Found: /index
INFO - 2020-08-26 14:11:37 --> Config Class Initialized
INFO - 2020-08-26 14:11:37 --> Hooks Class Initialized
DEBUG - 2020-08-26 14:11:37 --> UTF-8 Support Enabled
INFO - 2020-08-26 14:11:37 --> Utf8 Class Initialized
INFO - 2020-08-26 14:11:37 --> URI Class Initialized
INFO - 2020-08-26 14:11:37 --> Router Class Initialized
INFO - 2020-08-26 14:11:37 --> Output Class Initialized
INFO - 2020-08-26 14:11:37 --> Security Class Initialized
DEBUG - 2020-08-26 14:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 14:11:37 --> Input Class Initialized
INFO - 2020-08-26 14:11:37 --> Language Class Initialized
INFO - 2020-08-26 14:11:37 --> Language Class Initialized
INFO - 2020-08-26 14:11:37 --> Config Class Initialized
INFO - 2020-08-26 14:11:37 --> Loader Class Initialized
INFO - 2020-08-26 14:11:37 --> Helper loaded: url_helper
INFO - 2020-08-26 14:11:37 --> Helper loaded: form_helper
INFO - 2020-08-26 14:11:37 --> Helper loaded: file_helper
INFO - 2020-08-26 14:11:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 14:11:37 --> Database Driver Class Initialized
DEBUG - 2020-08-26 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 14:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 14:11:37 --> Upload Class Initialized
INFO - 2020-08-26 14:11:38 --> Controller Class Initialized
ERROR - 2020-08-26 14:11:38 --> 404 Page Not Found: /index
INFO - 2020-08-26 14:19:18 --> Config Class Initialized
INFO - 2020-08-26 14:19:18 --> Hooks Class Initialized
DEBUG - 2020-08-26 14:19:18 --> UTF-8 Support Enabled
INFO - 2020-08-26 14:19:18 --> Utf8 Class Initialized
INFO - 2020-08-26 14:19:18 --> URI Class Initialized
DEBUG - 2020-08-26 14:19:18 --> No URI present. Default controller set.
INFO - 2020-08-26 14:19:18 --> Router Class Initialized
INFO - 2020-08-26 14:19:18 --> Output Class Initialized
INFO - 2020-08-26 14:19:18 --> Security Class Initialized
DEBUG - 2020-08-26 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 14:19:18 --> Input Class Initialized
INFO - 2020-08-26 14:19:18 --> Language Class Initialized
INFO - 2020-08-26 14:19:18 --> Language Class Initialized
INFO - 2020-08-26 14:19:18 --> Config Class Initialized
INFO - 2020-08-26 14:19:18 --> Loader Class Initialized
INFO - 2020-08-26 14:19:18 --> Helper loaded: url_helper
INFO - 2020-08-26 14:19:18 --> Helper loaded: form_helper
INFO - 2020-08-26 14:19:18 --> Helper loaded: file_helper
INFO - 2020-08-26 14:19:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 14:19:18 --> Database Driver Class Initialized
DEBUG - 2020-08-26 14:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 14:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 14:19:18 --> Upload Class Initialized
INFO - 2020-08-26 14:19:18 --> Controller Class Initialized
DEBUG - 2020-08-26 14:19:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 14:19:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 14:19:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 14:19:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 14:19:18 --> Final output sent to browser
DEBUG - 2020-08-26 14:19:18 --> Total execution time: 0.0529
INFO - 2020-08-26 14:19:27 --> Config Class Initialized
INFO - 2020-08-26 14:19:27 --> Hooks Class Initialized
DEBUG - 2020-08-26 14:19:27 --> UTF-8 Support Enabled
INFO - 2020-08-26 14:19:27 --> Utf8 Class Initialized
INFO - 2020-08-26 14:19:27 --> URI Class Initialized
INFO - 2020-08-26 14:19:27 --> Router Class Initialized
INFO - 2020-08-26 14:19:27 --> Output Class Initialized
INFO - 2020-08-26 14:19:27 --> Security Class Initialized
DEBUG - 2020-08-26 14:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 14:19:27 --> Input Class Initialized
INFO - 2020-08-26 14:19:27 --> Language Class Initialized
INFO - 2020-08-26 14:19:27 --> Language Class Initialized
INFO - 2020-08-26 14:19:27 --> Config Class Initialized
INFO - 2020-08-26 14:19:27 --> Loader Class Initialized
INFO - 2020-08-26 14:19:27 --> Helper loaded: url_helper
INFO - 2020-08-26 14:19:27 --> Helper loaded: form_helper
INFO - 2020-08-26 14:19:27 --> Helper loaded: file_helper
INFO - 2020-08-26 14:19:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 14:19:27 --> Database Driver Class Initialized
DEBUG - 2020-08-26 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 14:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 14:19:27 --> Upload Class Initialized
INFO - 2020-08-26 14:19:27 --> Controller Class Initialized
ERROR - 2020-08-26 14:19:27 --> 404 Page Not Found: /index
INFO - 2020-08-26 14:31:29 --> Config Class Initialized
INFO - 2020-08-26 14:31:29 --> Hooks Class Initialized
DEBUG - 2020-08-26 14:31:29 --> UTF-8 Support Enabled
INFO - 2020-08-26 14:31:29 --> Utf8 Class Initialized
INFO - 2020-08-26 14:31:29 --> URI Class Initialized
INFO - 2020-08-26 14:31:29 --> Router Class Initialized
INFO - 2020-08-26 14:31:29 --> Output Class Initialized
INFO - 2020-08-26 14:31:29 --> Security Class Initialized
DEBUG - 2020-08-26 14:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 14:31:29 --> Input Class Initialized
INFO - 2020-08-26 14:31:29 --> Language Class Initialized
INFO - 2020-08-26 14:31:29 --> Language Class Initialized
INFO - 2020-08-26 14:31:29 --> Config Class Initialized
INFO - 2020-08-26 14:31:29 --> Loader Class Initialized
INFO - 2020-08-26 14:31:29 --> Helper loaded: url_helper
INFO - 2020-08-26 14:31:29 --> Helper loaded: form_helper
INFO - 2020-08-26 14:31:29 --> Helper loaded: file_helper
INFO - 2020-08-26 14:31:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 14:31:29 --> Database Driver Class Initialized
DEBUG - 2020-08-26 14:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 14:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 14:31:29 --> Upload Class Initialized
INFO - 2020-08-26 14:31:29 --> Controller Class Initialized
ERROR - 2020-08-26 14:31:29 --> 404 Page Not Found: /index
INFO - 2020-08-26 15:12:57 --> Config Class Initialized
INFO - 2020-08-26 15:12:57 --> Hooks Class Initialized
DEBUG - 2020-08-26 15:12:57 --> UTF-8 Support Enabled
INFO - 2020-08-26 15:12:57 --> Utf8 Class Initialized
INFO - 2020-08-26 15:12:57 --> URI Class Initialized
INFO - 2020-08-26 15:12:57 --> Router Class Initialized
INFO - 2020-08-26 15:12:57 --> Output Class Initialized
INFO - 2020-08-26 15:12:57 --> Security Class Initialized
DEBUG - 2020-08-26 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 15:12:57 --> Input Class Initialized
INFO - 2020-08-26 15:12:57 --> Language Class Initialized
INFO - 2020-08-26 15:12:57 --> Language Class Initialized
INFO - 2020-08-26 15:12:57 --> Config Class Initialized
INFO - 2020-08-26 15:12:57 --> Loader Class Initialized
INFO - 2020-08-26 15:12:57 --> Helper loaded: url_helper
INFO - 2020-08-26 15:12:57 --> Helper loaded: form_helper
INFO - 2020-08-26 15:12:57 --> Helper loaded: file_helper
INFO - 2020-08-26 15:12:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 15:12:57 --> Database Driver Class Initialized
DEBUG - 2020-08-26 15:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 15:12:57 --> Upload Class Initialized
INFO - 2020-08-26 15:12:57 --> Controller Class Initialized
ERROR - 2020-08-26 15:12:57 --> 404 Page Not Found: /index
INFO - 2020-08-26 15:12:59 --> Config Class Initialized
INFO - 2020-08-26 15:12:59 --> Hooks Class Initialized
DEBUG - 2020-08-26 15:12:59 --> UTF-8 Support Enabled
INFO - 2020-08-26 15:12:59 --> Utf8 Class Initialized
INFO - 2020-08-26 15:12:59 --> URI Class Initialized
INFO - 2020-08-26 15:12:59 --> Router Class Initialized
INFO - 2020-08-26 15:12:59 --> Output Class Initialized
INFO - 2020-08-26 15:12:59 --> Security Class Initialized
DEBUG - 2020-08-26 15:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 15:12:59 --> Input Class Initialized
INFO - 2020-08-26 15:12:59 --> Language Class Initialized
INFO - 2020-08-26 15:12:59 --> Language Class Initialized
INFO - 2020-08-26 15:12:59 --> Config Class Initialized
INFO - 2020-08-26 15:12:59 --> Loader Class Initialized
INFO - 2020-08-26 15:12:59 --> Helper loaded: url_helper
INFO - 2020-08-26 15:12:59 --> Helper loaded: form_helper
INFO - 2020-08-26 15:12:59 --> Helper loaded: file_helper
INFO - 2020-08-26 15:12:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 15:12:59 --> Database Driver Class Initialized
DEBUG - 2020-08-26 15:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 15:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 15:12:59 --> Upload Class Initialized
INFO - 2020-08-26 15:12:59 --> Controller Class Initialized
DEBUG - 2020-08-26 15:12:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 15:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-26 15:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 15:12:59 --> Final output sent to browser
DEBUG - 2020-08-26 15:12:59 --> Total execution time: 0.0627
INFO - 2020-08-26 16:53:42 --> Config Class Initialized
INFO - 2020-08-26 16:53:42 --> Hooks Class Initialized
DEBUG - 2020-08-26 16:53:42 --> UTF-8 Support Enabled
INFO - 2020-08-26 16:53:42 --> Utf8 Class Initialized
INFO - 2020-08-26 16:53:42 --> URI Class Initialized
DEBUG - 2020-08-26 16:53:42 --> No URI present. Default controller set.
INFO - 2020-08-26 16:53:42 --> Router Class Initialized
INFO - 2020-08-26 16:53:42 --> Output Class Initialized
INFO - 2020-08-26 16:53:42 --> Security Class Initialized
DEBUG - 2020-08-26 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 16:53:42 --> Input Class Initialized
INFO - 2020-08-26 16:53:42 --> Language Class Initialized
INFO - 2020-08-26 16:53:42 --> Language Class Initialized
INFO - 2020-08-26 16:53:42 --> Config Class Initialized
INFO - 2020-08-26 16:53:42 --> Loader Class Initialized
INFO - 2020-08-26 16:53:42 --> Helper loaded: url_helper
INFO - 2020-08-26 16:53:42 --> Helper loaded: form_helper
INFO - 2020-08-26 16:53:42 --> Helper loaded: file_helper
INFO - 2020-08-26 16:53:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 16:53:42 --> Database Driver Class Initialized
DEBUG - 2020-08-26 16:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 16:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 16:53:42 --> Upload Class Initialized
INFO - 2020-08-26 16:53:42 --> Controller Class Initialized
DEBUG - 2020-08-26 16:53:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 16:53:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 16:53:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 16:53:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 16:53:42 --> Final output sent to browser
DEBUG - 2020-08-26 16:53:42 --> Total execution time: 0.0547
INFO - 2020-08-26 16:53:44 --> Config Class Initialized
INFO - 2020-08-26 16:53:44 --> Hooks Class Initialized
DEBUG - 2020-08-26 16:53:44 --> UTF-8 Support Enabled
INFO - 2020-08-26 16:53:44 --> Utf8 Class Initialized
INFO - 2020-08-26 16:53:44 --> URI Class Initialized
INFO - 2020-08-26 16:53:44 --> Router Class Initialized
INFO - 2020-08-26 16:53:44 --> Output Class Initialized
INFO - 2020-08-26 16:53:44 --> Security Class Initialized
DEBUG - 2020-08-26 16:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 16:53:44 --> Input Class Initialized
INFO - 2020-08-26 16:53:44 --> Language Class Initialized
INFO - 2020-08-26 16:53:44 --> Language Class Initialized
INFO - 2020-08-26 16:53:44 --> Config Class Initialized
INFO - 2020-08-26 16:53:44 --> Loader Class Initialized
INFO - 2020-08-26 16:53:44 --> Helper loaded: url_helper
INFO - 2020-08-26 16:53:44 --> Helper loaded: form_helper
INFO - 2020-08-26 16:53:44 --> Helper loaded: file_helper
INFO - 2020-08-26 16:53:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 16:53:44 --> Database Driver Class Initialized
DEBUG - 2020-08-26 16:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 16:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 16:53:44 --> Upload Class Initialized
INFO - 2020-08-26 16:53:44 --> Controller Class Initialized
ERROR - 2020-08-26 16:53:44 --> 404 Page Not Found: /index
INFO - 2020-08-26 16:53:45 --> Config Class Initialized
INFO - 2020-08-26 16:53:45 --> Hooks Class Initialized
DEBUG - 2020-08-26 16:53:45 --> UTF-8 Support Enabled
INFO - 2020-08-26 16:53:45 --> Utf8 Class Initialized
INFO - 2020-08-26 16:53:45 --> URI Class Initialized
DEBUG - 2020-08-26 16:53:45 --> No URI present. Default controller set.
INFO - 2020-08-26 16:53:45 --> Router Class Initialized
INFO - 2020-08-26 16:53:45 --> Output Class Initialized
INFO - 2020-08-26 16:53:45 --> Security Class Initialized
DEBUG - 2020-08-26 16:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 16:53:45 --> Input Class Initialized
INFO - 2020-08-26 16:53:45 --> Language Class Initialized
INFO - 2020-08-26 16:53:45 --> Language Class Initialized
INFO - 2020-08-26 16:53:45 --> Config Class Initialized
INFO - 2020-08-26 16:53:45 --> Loader Class Initialized
INFO - 2020-08-26 16:53:45 --> Helper loaded: url_helper
INFO - 2020-08-26 16:53:45 --> Helper loaded: form_helper
INFO - 2020-08-26 16:53:45 --> Helper loaded: file_helper
INFO - 2020-08-26 16:53:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 16:53:45 --> Database Driver Class Initialized
DEBUG - 2020-08-26 16:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 16:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 16:53:45 --> Upload Class Initialized
INFO - 2020-08-26 16:53:45 --> Controller Class Initialized
DEBUG - 2020-08-26 16:53:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 16:53:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 16:53:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 16:53:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 16:53:45 --> Final output sent to browser
DEBUG - 2020-08-26 16:53:45 --> Total execution time: 0.0488
INFO - 2020-08-26 18:01:03 --> Config Class Initialized
INFO - 2020-08-26 18:01:03 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:01:03 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:01:03 --> Utf8 Class Initialized
INFO - 2020-08-26 18:01:03 --> URI Class Initialized
DEBUG - 2020-08-26 18:01:03 --> No URI present. Default controller set.
INFO - 2020-08-26 18:01:03 --> Router Class Initialized
INFO - 2020-08-26 18:01:03 --> Output Class Initialized
INFO - 2020-08-26 18:01:03 --> Security Class Initialized
DEBUG - 2020-08-26 18:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:01:03 --> Input Class Initialized
INFO - 2020-08-26 18:01:03 --> Language Class Initialized
INFO - 2020-08-26 18:01:03 --> Language Class Initialized
INFO - 2020-08-26 18:01:03 --> Config Class Initialized
INFO - 2020-08-26 18:01:03 --> Loader Class Initialized
INFO - 2020-08-26 18:01:03 --> Helper loaded: url_helper
INFO - 2020-08-26 18:01:03 --> Helper loaded: form_helper
INFO - 2020-08-26 18:01:03 --> Helper loaded: file_helper
INFO - 2020-08-26 18:01:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:01:03 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:01:03 --> Upload Class Initialized
INFO - 2020-08-26 18:01:03 --> Controller Class Initialized
DEBUG - 2020-08-26 18:01:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 18:01:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 18:01:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 18:01:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 18:01:03 --> Final output sent to browser
DEBUG - 2020-08-26 18:01:03 --> Total execution time: 0.1702
INFO - 2020-08-26 18:01:11 --> Config Class Initialized
INFO - 2020-08-26 18:01:11 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:01:11 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:01:12 --> Utf8 Class Initialized
INFO - 2020-08-26 18:01:12 --> URI Class Initialized
DEBUG - 2020-08-26 18:01:12 --> No URI present. Default controller set.
INFO - 2020-08-26 18:01:12 --> Router Class Initialized
INFO - 2020-08-26 18:01:12 --> Output Class Initialized
INFO - 2020-08-26 18:01:12 --> Security Class Initialized
DEBUG - 2020-08-26 18:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:01:12 --> Input Class Initialized
INFO - 2020-08-26 18:01:12 --> Language Class Initialized
INFO - 2020-08-26 18:01:12 --> Language Class Initialized
INFO - 2020-08-26 18:01:12 --> Config Class Initialized
INFO - 2020-08-26 18:01:12 --> Loader Class Initialized
INFO - 2020-08-26 18:01:12 --> Helper loaded: url_helper
INFO - 2020-08-26 18:01:12 --> Helper loaded: form_helper
INFO - 2020-08-26 18:01:12 --> Helper loaded: file_helper
INFO - 2020-08-26 18:01:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:01:12 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:01:12 --> Upload Class Initialized
INFO - 2020-08-26 18:01:12 --> Controller Class Initialized
DEBUG - 2020-08-26 18:01:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 18:01:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 18:01:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 18:01:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 18:01:12 --> Final output sent to browser
DEBUG - 2020-08-26 18:01:12 --> Total execution time: 0.0519
INFO - 2020-08-26 18:01:12 --> Config Class Initialized
INFO - 2020-08-26 18:01:12 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:01:12 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:01:12 --> Utf8 Class Initialized
INFO - 2020-08-26 18:01:12 --> URI Class Initialized
DEBUG - 2020-08-26 18:01:12 --> No URI present. Default controller set.
INFO - 2020-08-26 18:01:12 --> Router Class Initialized
INFO - 2020-08-26 18:01:12 --> Output Class Initialized
INFO - 2020-08-26 18:01:12 --> Security Class Initialized
DEBUG - 2020-08-26 18:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:01:12 --> Input Class Initialized
INFO - 2020-08-26 18:01:12 --> Language Class Initialized
INFO - 2020-08-26 18:01:12 --> Language Class Initialized
INFO - 2020-08-26 18:01:12 --> Config Class Initialized
INFO - 2020-08-26 18:01:12 --> Loader Class Initialized
INFO - 2020-08-26 18:01:12 --> Helper loaded: url_helper
INFO - 2020-08-26 18:01:12 --> Helper loaded: form_helper
INFO - 2020-08-26 18:01:12 --> Helper loaded: file_helper
INFO - 2020-08-26 18:01:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:01:12 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:01:12 --> Upload Class Initialized
INFO - 2020-08-26 18:01:12 --> Controller Class Initialized
DEBUG - 2020-08-26 18:01:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 18:01:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 18:01:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 18:01:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 18:01:12 --> Final output sent to browser
DEBUG - 2020-08-26 18:01:12 --> Total execution time: 0.0553
INFO - 2020-08-26 18:35:31 --> Config Class Initialized
INFO - 2020-08-26 18:35:31 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:35:31 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:35:31 --> Utf8 Class Initialized
INFO - 2020-08-26 18:35:31 --> URI Class Initialized
INFO - 2020-08-26 18:35:31 --> Router Class Initialized
INFO - 2020-08-26 18:35:31 --> Output Class Initialized
INFO - 2020-08-26 18:35:31 --> Security Class Initialized
DEBUG - 2020-08-26 18:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:35:31 --> Input Class Initialized
INFO - 2020-08-26 18:35:31 --> Language Class Initialized
INFO - 2020-08-26 18:35:31 --> Language Class Initialized
INFO - 2020-08-26 18:35:31 --> Config Class Initialized
INFO - 2020-08-26 18:35:31 --> Loader Class Initialized
INFO - 2020-08-26 18:35:31 --> Helper loaded: url_helper
INFO - 2020-08-26 18:35:31 --> Helper loaded: form_helper
INFO - 2020-08-26 18:35:31 --> Helper loaded: file_helper
INFO - 2020-08-26 18:35:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:35:31 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:35:31 --> Upload Class Initialized
INFO - 2020-08-26 18:35:31 --> Controller Class Initialized
ERROR - 2020-08-26 18:35:31 --> 404 Page Not Found: /index
INFO - 2020-08-26 18:35:32 --> Config Class Initialized
INFO - 2020-08-26 18:35:32 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:35:32 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:35:32 --> Utf8 Class Initialized
INFO - 2020-08-26 18:35:32 --> URI Class Initialized
INFO - 2020-08-26 18:35:32 --> Router Class Initialized
INFO - 2020-08-26 18:35:32 --> Output Class Initialized
INFO - 2020-08-26 18:35:32 --> Security Class Initialized
DEBUG - 2020-08-26 18:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:35:32 --> Input Class Initialized
INFO - 2020-08-26 18:35:32 --> Language Class Initialized
INFO - 2020-08-26 18:35:32 --> Language Class Initialized
INFO - 2020-08-26 18:35:32 --> Config Class Initialized
INFO - 2020-08-26 18:35:32 --> Loader Class Initialized
INFO - 2020-08-26 18:35:32 --> Helper loaded: url_helper
INFO - 2020-08-26 18:35:32 --> Helper loaded: form_helper
INFO - 2020-08-26 18:35:32 --> Helper loaded: file_helper
INFO - 2020-08-26 18:35:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:35:32 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:35:32 --> Upload Class Initialized
INFO - 2020-08-26 18:35:32 --> Controller Class Initialized
ERROR - 2020-08-26 18:35:32 --> 404 Page Not Found: /index
INFO - 2020-08-26 18:35:33 --> Config Class Initialized
INFO - 2020-08-26 18:35:33 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:35:33 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:35:33 --> Utf8 Class Initialized
INFO - 2020-08-26 18:35:33 --> URI Class Initialized
INFO - 2020-08-26 18:35:33 --> Router Class Initialized
INFO - 2020-08-26 18:35:33 --> Output Class Initialized
INFO - 2020-08-26 18:35:33 --> Security Class Initialized
DEBUG - 2020-08-26 18:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:35:33 --> Input Class Initialized
INFO - 2020-08-26 18:35:33 --> Language Class Initialized
INFO - 2020-08-26 18:35:33 --> Language Class Initialized
INFO - 2020-08-26 18:35:33 --> Config Class Initialized
INFO - 2020-08-26 18:35:33 --> Loader Class Initialized
INFO - 2020-08-26 18:35:33 --> Helper loaded: url_helper
INFO - 2020-08-26 18:35:33 --> Helper loaded: form_helper
INFO - 2020-08-26 18:35:33 --> Helper loaded: file_helper
INFO - 2020-08-26 18:35:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:35:33 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:35:33 --> Upload Class Initialized
INFO - 2020-08-26 18:35:33 --> Controller Class Initialized
ERROR - 2020-08-26 18:35:33 --> 404 Page Not Found: /index
INFO - 2020-08-26 18:35:34 --> Config Class Initialized
INFO - 2020-08-26 18:35:34 --> Hooks Class Initialized
DEBUG - 2020-08-26 18:35:34 --> UTF-8 Support Enabled
INFO - 2020-08-26 18:35:34 --> Utf8 Class Initialized
INFO - 2020-08-26 18:35:34 --> URI Class Initialized
DEBUG - 2020-08-26 18:35:34 --> No URI present. Default controller set.
INFO - 2020-08-26 18:35:34 --> Router Class Initialized
INFO - 2020-08-26 18:35:34 --> Output Class Initialized
INFO - 2020-08-26 18:35:34 --> Security Class Initialized
DEBUG - 2020-08-26 18:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 18:35:34 --> Input Class Initialized
INFO - 2020-08-26 18:35:34 --> Language Class Initialized
INFO - 2020-08-26 18:35:34 --> Language Class Initialized
INFO - 2020-08-26 18:35:34 --> Config Class Initialized
INFO - 2020-08-26 18:35:34 --> Loader Class Initialized
INFO - 2020-08-26 18:35:34 --> Helper loaded: url_helper
INFO - 2020-08-26 18:35:34 --> Helper loaded: form_helper
INFO - 2020-08-26 18:35:34 --> Helper loaded: file_helper
INFO - 2020-08-26 18:35:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 18:35:34 --> Database Driver Class Initialized
DEBUG - 2020-08-26 18:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 18:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 18:35:35 --> Upload Class Initialized
INFO - 2020-08-26 18:35:35 --> Controller Class Initialized
DEBUG - 2020-08-26 18:35:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 18:35:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 18:35:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 18:35:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 18:35:35 --> Final output sent to browser
DEBUG - 2020-08-26 18:35:35 --> Total execution time: 0.0609
INFO - 2020-08-26 19:06:04 --> Config Class Initialized
INFO - 2020-08-26 19:06:04 --> Hooks Class Initialized
DEBUG - 2020-08-26 19:06:04 --> UTF-8 Support Enabled
INFO - 2020-08-26 19:06:04 --> Utf8 Class Initialized
INFO - 2020-08-26 19:06:04 --> URI Class Initialized
INFO - 2020-08-26 19:06:04 --> Router Class Initialized
INFO - 2020-08-26 19:06:04 --> Output Class Initialized
INFO - 2020-08-26 19:06:04 --> Security Class Initialized
DEBUG - 2020-08-26 19:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 19:06:04 --> Input Class Initialized
INFO - 2020-08-26 19:06:04 --> Language Class Initialized
INFO - 2020-08-26 19:06:04 --> Language Class Initialized
INFO - 2020-08-26 19:06:04 --> Config Class Initialized
INFO - 2020-08-26 19:06:04 --> Loader Class Initialized
INFO - 2020-08-26 19:06:04 --> Helper loaded: url_helper
INFO - 2020-08-26 19:06:04 --> Helper loaded: form_helper
INFO - 2020-08-26 19:06:04 --> Helper loaded: file_helper
INFO - 2020-08-26 19:06:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 19:06:04 --> Database Driver Class Initialized
DEBUG - 2020-08-26 19:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 19:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 19:06:04 --> Upload Class Initialized
INFO - 2020-08-26 19:06:04 --> Controller Class Initialized
DEBUG - 2020-08-26 19:06:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 19:06:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 19:06:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 19:06:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 19:06:04 --> Final output sent to browser
DEBUG - 2020-08-26 19:06:04 --> Total execution time: 0.0891
INFO - 2020-08-26 19:06:06 --> Config Class Initialized
INFO - 2020-08-26 19:06:06 --> Hooks Class Initialized
DEBUG - 2020-08-26 19:06:06 --> UTF-8 Support Enabled
INFO - 2020-08-26 19:06:06 --> Utf8 Class Initialized
INFO - 2020-08-26 19:06:06 --> URI Class Initialized
INFO - 2020-08-26 19:06:06 --> Router Class Initialized
INFO - 2020-08-26 19:06:06 --> Output Class Initialized
INFO - 2020-08-26 19:06:06 --> Security Class Initialized
DEBUG - 2020-08-26 19:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 19:06:06 --> Input Class Initialized
INFO - 2020-08-26 19:06:06 --> Language Class Initialized
INFO - 2020-08-26 19:06:06 --> Language Class Initialized
INFO - 2020-08-26 19:06:06 --> Config Class Initialized
INFO - 2020-08-26 19:06:06 --> Loader Class Initialized
INFO - 2020-08-26 19:06:06 --> Helper loaded: url_helper
INFO - 2020-08-26 19:06:06 --> Helper loaded: form_helper
INFO - 2020-08-26 19:06:06 --> Helper loaded: file_helper
INFO - 2020-08-26 19:06:06 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 19:06:06 --> Database Driver Class Initialized
DEBUG - 2020-08-26 19:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 19:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 19:06:06 --> Upload Class Initialized
INFO - 2020-08-26 19:06:06 --> Controller Class Initialized
ERROR - 2020-08-26 19:06:06 --> 404 Page Not Found: /index
INFO - 2020-08-26 19:29:35 --> Config Class Initialized
INFO - 2020-08-26 19:29:35 --> Hooks Class Initialized
DEBUG - 2020-08-26 19:29:35 --> UTF-8 Support Enabled
INFO - 2020-08-26 19:29:35 --> Utf8 Class Initialized
INFO - 2020-08-26 19:29:35 --> URI Class Initialized
DEBUG - 2020-08-26 19:29:35 --> No URI present. Default controller set.
INFO - 2020-08-26 19:29:35 --> Router Class Initialized
INFO - 2020-08-26 19:29:35 --> Output Class Initialized
INFO - 2020-08-26 19:29:35 --> Security Class Initialized
DEBUG - 2020-08-26 19:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 19:29:35 --> Input Class Initialized
INFO - 2020-08-26 19:29:35 --> Language Class Initialized
INFO - 2020-08-26 19:29:35 --> Language Class Initialized
INFO - 2020-08-26 19:29:35 --> Config Class Initialized
INFO - 2020-08-26 19:29:35 --> Loader Class Initialized
INFO - 2020-08-26 19:29:35 --> Helper loaded: url_helper
INFO - 2020-08-26 19:29:35 --> Helper loaded: form_helper
INFO - 2020-08-26 19:29:35 --> Helper loaded: file_helper
INFO - 2020-08-26 19:29:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 19:29:35 --> Database Driver Class Initialized
DEBUG - 2020-08-26 19:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 19:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 19:29:35 --> Upload Class Initialized
INFO - 2020-08-26 19:29:35 --> Controller Class Initialized
DEBUG - 2020-08-26 19:29:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 19:29:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 19:29:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 19:29:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 19:29:35 --> Final output sent to browser
DEBUG - 2020-08-26 19:29:35 --> Total execution time: 0.0539
INFO - 2020-08-26 19:42:34 --> Config Class Initialized
INFO - 2020-08-26 19:42:34 --> Hooks Class Initialized
DEBUG - 2020-08-26 19:42:34 --> UTF-8 Support Enabled
INFO - 2020-08-26 19:42:34 --> Utf8 Class Initialized
INFO - 2020-08-26 19:42:34 --> URI Class Initialized
DEBUG - 2020-08-26 19:42:34 --> No URI present. Default controller set.
INFO - 2020-08-26 19:42:34 --> Router Class Initialized
INFO - 2020-08-26 19:42:34 --> Output Class Initialized
INFO - 2020-08-26 19:42:34 --> Security Class Initialized
DEBUG - 2020-08-26 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 19:42:34 --> Input Class Initialized
INFO - 2020-08-26 19:42:34 --> Language Class Initialized
INFO - 2020-08-26 19:42:34 --> Language Class Initialized
INFO - 2020-08-26 19:42:34 --> Config Class Initialized
INFO - 2020-08-26 19:42:34 --> Loader Class Initialized
INFO - 2020-08-26 19:42:34 --> Helper loaded: url_helper
INFO - 2020-08-26 19:42:34 --> Helper loaded: form_helper
INFO - 2020-08-26 19:42:34 --> Helper loaded: file_helper
INFO - 2020-08-26 19:42:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 19:42:34 --> Database Driver Class Initialized
DEBUG - 2020-08-26 19:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 19:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 19:42:34 --> Upload Class Initialized
INFO - 2020-08-26 19:42:34 --> Controller Class Initialized
DEBUG - 2020-08-26 19:42:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 19:42:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 19:42:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 19:42:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 19:42:34 --> Final output sent to browser
DEBUG - 2020-08-26 19:42:34 --> Total execution time: 0.0630
INFO - 2020-08-26 19:42:34 --> Config Class Initialized
INFO - 2020-08-26 19:42:34 --> Hooks Class Initialized
DEBUG - 2020-08-26 19:42:34 --> UTF-8 Support Enabled
INFO - 2020-08-26 19:42:34 --> Utf8 Class Initialized
INFO - 2020-08-26 19:42:34 --> URI Class Initialized
INFO - 2020-08-26 19:42:34 --> Router Class Initialized
INFO - 2020-08-26 19:42:34 --> Output Class Initialized
INFO - 2020-08-26 19:42:34 --> Security Class Initialized
DEBUG - 2020-08-26 19:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 19:42:34 --> Input Class Initialized
INFO - 2020-08-26 19:42:34 --> Language Class Initialized
INFO - 2020-08-26 19:42:34 --> Language Class Initialized
INFO - 2020-08-26 19:42:34 --> Config Class Initialized
INFO - 2020-08-26 19:42:34 --> Loader Class Initialized
INFO - 2020-08-26 19:42:34 --> Helper loaded: url_helper
INFO - 2020-08-26 19:42:34 --> Helper loaded: form_helper
INFO - 2020-08-26 19:42:34 --> Helper loaded: file_helper
INFO - 2020-08-26 19:42:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 19:42:34 --> Database Driver Class Initialized
DEBUG - 2020-08-26 19:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 19:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 19:42:34 --> Upload Class Initialized
INFO - 2020-08-26 19:42:34 --> Controller Class Initialized
ERROR - 2020-08-26 19:42:34 --> 404 Page Not Found: /index
INFO - 2020-08-26 19:42:36 --> Config Class Initialized
INFO - 2020-08-26 19:42:36 --> Hooks Class Initialized
DEBUG - 2020-08-26 19:42:36 --> UTF-8 Support Enabled
INFO - 2020-08-26 19:42:36 --> Utf8 Class Initialized
INFO - 2020-08-26 19:42:36 --> URI Class Initialized
DEBUG - 2020-08-26 19:42:36 --> No URI present. Default controller set.
INFO - 2020-08-26 19:42:36 --> Router Class Initialized
INFO - 2020-08-26 19:42:36 --> Output Class Initialized
INFO - 2020-08-26 19:42:36 --> Security Class Initialized
DEBUG - 2020-08-26 19:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 19:42:36 --> Input Class Initialized
INFO - 2020-08-26 19:42:36 --> Language Class Initialized
INFO - 2020-08-26 19:42:36 --> Language Class Initialized
INFO - 2020-08-26 19:42:36 --> Config Class Initialized
INFO - 2020-08-26 19:42:36 --> Loader Class Initialized
INFO - 2020-08-26 19:42:36 --> Helper loaded: url_helper
INFO - 2020-08-26 19:42:36 --> Helper loaded: form_helper
INFO - 2020-08-26 19:42:36 --> Helper loaded: file_helper
INFO - 2020-08-26 19:42:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 19:42:36 --> Database Driver Class Initialized
DEBUG - 2020-08-26 19:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 19:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 19:42:36 --> Upload Class Initialized
INFO - 2020-08-26 19:42:36 --> Controller Class Initialized
DEBUG - 2020-08-26 19:42:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 19:42:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 19:42:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 19:42:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 19:42:36 --> Final output sent to browser
DEBUG - 2020-08-26 19:42:36 --> Total execution time: 0.0531
INFO - 2020-08-26 21:02:09 --> Config Class Initialized
INFO - 2020-08-26 21:02:09 --> Hooks Class Initialized
DEBUG - 2020-08-26 21:02:09 --> UTF-8 Support Enabled
INFO - 2020-08-26 21:02:09 --> Utf8 Class Initialized
INFO - 2020-08-26 21:02:09 --> URI Class Initialized
DEBUG - 2020-08-26 21:02:09 --> No URI present. Default controller set.
INFO - 2020-08-26 21:02:09 --> Router Class Initialized
INFO - 2020-08-26 21:02:09 --> Output Class Initialized
INFO - 2020-08-26 21:02:09 --> Security Class Initialized
DEBUG - 2020-08-26 21:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 21:02:09 --> Input Class Initialized
INFO - 2020-08-26 21:02:09 --> Language Class Initialized
INFO - 2020-08-26 21:02:09 --> Language Class Initialized
INFO - 2020-08-26 21:02:09 --> Config Class Initialized
INFO - 2020-08-26 21:02:09 --> Loader Class Initialized
INFO - 2020-08-26 21:02:09 --> Helper loaded: url_helper
INFO - 2020-08-26 21:02:09 --> Helper loaded: form_helper
INFO - 2020-08-26 21:02:09 --> Helper loaded: file_helper
INFO - 2020-08-26 21:02:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 21:02:09 --> Database Driver Class Initialized
DEBUG - 2020-08-26 21:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 21:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 21:02:09 --> Upload Class Initialized
INFO - 2020-08-26 21:02:09 --> Controller Class Initialized
DEBUG - 2020-08-26 21:02:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 21:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 21:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 21:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 21:02:09 --> Final output sent to browser
DEBUG - 2020-08-26 21:02:09 --> Total execution time: 0.1476
INFO - 2020-08-26 22:28:58 --> Config Class Initialized
INFO - 2020-08-26 22:28:58 --> Hooks Class Initialized
DEBUG - 2020-08-26 22:28:58 --> UTF-8 Support Enabled
INFO - 2020-08-26 22:28:58 --> Utf8 Class Initialized
INFO - 2020-08-26 22:28:58 --> URI Class Initialized
DEBUG - 2020-08-26 22:28:58 --> No URI present. Default controller set.
INFO - 2020-08-26 22:28:58 --> Router Class Initialized
INFO - 2020-08-26 22:28:58 --> Output Class Initialized
INFO - 2020-08-26 22:28:58 --> Security Class Initialized
DEBUG - 2020-08-26 22:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 22:28:58 --> Input Class Initialized
INFO - 2020-08-26 22:28:58 --> Language Class Initialized
INFO - 2020-08-26 22:28:58 --> Language Class Initialized
INFO - 2020-08-26 22:28:58 --> Config Class Initialized
INFO - 2020-08-26 22:28:58 --> Loader Class Initialized
INFO - 2020-08-26 22:28:58 --> Helper loaded: url_helper
INFO - 2020-08-26 22:28:58 --> Helper loaded: form_helper
INFO - 2020-08-26 22:28:58 --> Helper loaded: file_helper
INFO - 2020-08-26 22:28:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 22:28:58 --> Database Driver Class Initialized
DEBUG - 2020-08-26 22:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 22:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 22:28:58 --> Upload Class Initialized
INFO - 2020-08-26 22:28:58 --> Controller Class Initialized
DEBUG - 2020-08-26 22:28:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 22:28:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 22:28:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 22:28:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 22:28:58 --> Final output sent to browser
DEBUG - 2020-08-26 22:28:58 --> Total execution time: 0.0524
INFO - 2020-08-26 22:29:01 --> Config Class Initialized
INFO - 2020-08-26 22:29:01 --> Hooks Class Initialized
DEBUG - 2020-08-26 22:29:01 --> UTF-8 Support Enabled
INFO - 2020-08-26 22:29:01 --> Utf8 Class Initialized
INFO - 2020-08-26 22:29:01 --> URI Class Initialized
INFO - 2020-08-26 22:29:01 --> Router Class Initialized
INFO - 2020-08-26 22:29:01 --> Output Class Initialized
INFO - 2020-08-26 22:29:01 --> Security Class Initialized
DEBUG - 2020-08-26 22:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 22:29:01 --> Input Class Initialized
INFO - 2020-08-26 22:29:01 --> Language Class Initialized
INFO - 2020-08-26 22:29:01 --> Language Class Initialized
INFO - 2020-08-26 22:29:01 --> Config Class Initialized
INFO - 2020-08-26 22:29:01 --> Loader Class Initialized
INFO - 2020-08-26 22:29:01 --> Helper loaded: url_helper
INFO - 2020-08-26 22:29:01 --> Helper loaded: form_helper
INFO - 2020-08-26 22:29:01 --> Helper loaded: file_helper
INFO - 2020-08-26 22:29:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 22:29:01 --> Database Driver Class Initialized
DEBUG - 2020-08-26 22:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 22:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 22:29:01 --> Upload Class Initialized
INFO - 2020-08-26 22:29:01 --> Controller Class Initialized
ERROR - 2020-08-26 22:29:01 --> 404 Page Not Found: /index
INFO - 2020-08-26 22:38:40 --> Config Class Initialized
INFO - 2020-08-26 22:38:40 --> Hooks Class Initialized
DEBUG - 2020-08-26 22:38:40 --> UTF-8 Support Enabled
INFO - 2020-08-26 22:38:40 --> Utf8 Class Initialized
INFO - 2020-08-26 22:38:40 --> URI Class Initialized
DEBUG - 2020-08-26 22:38:40 --> No URI present. Default controller set.
INFO - 2020-08-26 22:38:40 --> Router Class Initialized
INFO - 2020-08-26 22:38:40 --> Output Class Initialized
INFO - 2020-08-26 22:38:40 --> Security Class Initialized
DEBUG - 2020-08-26 22:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 22:38:40 --> Input Class Initialized
INFO - 2020-08-26 22:38:40 --> Language Class Initialized
INFO - 2020-08-26 22:38:40 --> Language Class Initialized
INFO - 2020-08-26 22:38:40 --> Config Class Initialized
INFO - 2020-08-26 22:38:40 --> Loader Class Initialized
INFO - 2020-08-26 22:38:40 --> Helper loaded: url_helper
INFO - 2020-08-26 22:38:40 --> Helper loaded: form_helper
INFO - 2020-08-26 22:38:40 --> Helper loaded: file_helper
INFO - 2020-08-26 22:38:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-26 22:38:40 --> Database Driver Class Initialized
DEBUG - 2020-08-26 22:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-26 22:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 22:38:40 --> Upload Class Initialized
INFO - 2020-08-26 22:38:40 --> Controller Class Initialized
DEBUG - 2020-08-26 22:38:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-26 22:38:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-26 22:38:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-26 22:38:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-26 22:38:40 --> Final output sent to browser
DEBUG - 2020-08-26 22:38:40 --> Total execution time: 0.0512
