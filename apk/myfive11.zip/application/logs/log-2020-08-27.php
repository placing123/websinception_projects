<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-27 00:41:01 --> Config Class Initialized
INFO - 2020-08-27 00:41:01 --> Hooks Class Initialized
DEBUG - 2020-08-27 00:41:01 --> UTF-8 Support Enabled
INFO - 2020-08-27 00:41:01 --> Utf8 Class Initialized
INFO - 2020-08-27 00:41:01 --> URI Class Initialized
DEBUG - 2020-08-27 00:41:01 --> No URI present. Default controller set.
INFO - 2020-08-27 00:41:01 --> Router Class Initialized
INFO - 2020-08-27 00:41:01 --> Output Class Initialized
INFO - 2020-08-27 00:41:01 --> Security Class Initialized
DEBUG - 2020-08-27 00:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 00:41:01 --> Input Class Initialized
INFO - 2020-08-27 00:41:01 --> Language Class Initialized
INFO - 2020-08-27 00:41:01 --> Language Class Initialized
INFO - 2020-08-27 00:41:01 --> Config Class Initialized
INFO - 2020-08-27 00:41:01 --> Loader Class Initialized
INFO - 2020-08-27 00:41:01 --> Helper loaded: url_helper
INFO - 2020-08-27 00:41:01 --> Helper loaded: form_helper
INFO - 2020-08-27 00:41:01 --> Helper loaded: file_helper
INFO - 2020-08-27 00:41:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 00:41:01 --> Database Driver Class Initialized
DEBUG - 2020-08-27 00:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 00:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 00:41:01 --> Upload Class Initialized
INFO - 2020-08-27 00:41:02 --> Controller Class Initialized
DEBUG - 2020-08-27 00:41:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 00:41:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 00:41:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 00:41:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 00:41:02 --> Final output sent to browser
DEBUG - 2020-08-27 00:41:02 --> Total execution time: 0.2876
INFO - 2020-08-27 00:45:25 --> Config Class Initialized
INFO - 2020-08-27 00:45:25 --> Hooks Class Initialized
DEBUG - 2020-08-27 00:45:25 --> UTF-8 Support Enabled
INFO - 2020-08-27 00:45:25 --> Utf8 Class Initialized
INFO - 2020-08-27 00:45:25 --> URI Class Initialized
DEBUG - 2020-08-27 00:45:25 --> No URI present. Default controller set.
INFO - 2020-08-27 00:45:25 --> Router Class Initialized
INFO - 2020-08-27 00:45:25 --> Output Class Initialized
INFO - 2020-08-27 00:45:25 --> Security Class Initialized
DEBUG - 2020-08-27 00:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 00:45:25 --> Input Class Initialized
INFO - 2020-08-27 00:45:25 --> Language Class Initialized
INFO - 2020-08-27 00:45:25 --> Language Class Initialized
INFO - 2020-08-27 00:45:25 --> Config Class Initialized
INFO - 2020-08-27 00:45:25 --> Loader Class Initialized
INFO - 2020-08-27 00:45:25 --> Helper loaded: url_helper
INFO - 2020-08-27 00:45:25 --> Helper loaded: form_helper
INFO - 2020-08-27 00:45:25 --> Helper loaded: file_helper
INFO - 2020-08-27 00:45:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 00:45:25 --> Database Driver Class Initialized
DEBUG - 2020-08-27 00:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 00:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 00:45:25 --> Upload Class Initialized
INFO - 2020-08-27 00:45:25 --> Controller Class Initialized
DEBUG - 2020-08-27 00:45:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 00:45:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 00:45:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 00:45:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 00:45:25 --> Final output sent to browser
DEBUG - 2020-08-27 00:45:25 --> Total execution time: 0.0504
INFO - 2020-08-27 00:53:14 --> Config Class Initialized
INFO - 2020-08-27 00:53:14 --> Hooks Class Initialized
DEBUG - 2020-08-27 00:53:14 --> UTF-8 Support Enabled
INFO - 2020-08-27 00:53:14 --> Utf8 Class Initialized
INFO - 2020-08-27 00:53:14 --> URI Class Initialized
DEBUG - 2020-08-27 00:53:14 --> No URI present. Default controller set.
INFO - 2020-08-27 00:53:14 --> Router Class Initialized
INFO - 2020-08-27 00:53:14 --> Output Class Initialized
INFO - 2020-08-27 00:53:14 --> Security Class Initialized
DEBUG - 2020-08-27 00:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 00:53:14 --> Input Class Initialized
INFO - 2020-08-27 00:53:14 --> Language Class Initialized
INFO - 2020-08-27 00:53:14 --> Language Class Initialized
INFO - 2020-08-27 00:53:14 --> Config Class Initialized
INFO - 2020-08-27 00:53:14 --> Loader Class Initialized
INFO - 2020-08-27 00:53:14 --> Helper loaded: url_helper
INFO - 2020-08-27 00:53:14 --> Helper loaded: form_helper
INFO - 2020-08-27 00:53:14 --> Helper loaded: file_helper
INFO - 2020-08-27 00:53:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 00:53:14 --> Database Driver Class Initialized
DEBUG - 2020-08-27 00:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 00:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 00:53:14 --> Upload Class Initialized
INFO - 2020-08-27 00:53:14 --> Controller Class Initialized
DEBUG - 2020-08-27 00:53:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 00:53:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 00:53:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 00:53:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 00:53:14 --> Final output sent to browser
DEBUG - 2020-08-27 00:53:14 --> Total execution time: 0.0503
INFO - 2020-08-27 01:06:49 --> Config Class Initialized
INFO - 2020-08-27 01:06:49 --> Hooks Class Initialized
DEBUG - 2020-08-27 01:06:49 --> UTF-8 Support Enabled
INFO - 2020-08-27 01:06:49 --> Utf8 Class Initialized
INFO - 2020-08-27 01:06:49 --> URI Class Initialized
INFO - 2020-08-27 01:06:49 --> Router Class Initialized
INFO - 2020-08-27 01:06:49 --> Output Class Initialized
INFO - 2020-08-27 01:06:49 --> Security Class Initialized
DEBUG - 2020-08-27 01:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 01:06:49 --> Input Class Initialized
INFO - 2020-08-27 01:06:49 --> Language Class Initialized
INFO - 2020-08-27 01:06:49 --> Language Class Initialized
INFO - 2020-08-27 01:06:49 --> Config Class Initialized
INFO - 2020-08-27 01:06:49 --> Loader Class Initialized
INFO - 2020-08-27 01:06:49 --> Helper loaded: url_helper
INFO - 2020-08-27 01:06:49 --> Helper loaded: form_helper
INFO - 2020-08-27 01:06:49 --> Helper loaded: file_helper
INFO - 2020-08-27 01:06:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 01:06:49 --> Database Driver Class Initialized
DEBUG - 2020-08-27 01:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 01:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 01:06:49 --> Upload Class Initialized
INFO - 2020-08-27 01:06:49 --> Controller Class Initialized
ERROR - 2020-08-27 01:06:49 --> 404 Page Not Found: /index
INFO - 2020-08-27 01:06:50 --> Config Class Initialized
INFO - 2020-08-27 01:06:50 --> Hooks Class Initialized
DEBUG - 2020-08-27 01:06:50 --> UTF-8 Support Enabled
INFO - 2020-08-27 01:06:50 --> Utf8 Class Initialized
INFO - 2020-08-27 01:06:50 --> URI Class Initialized
INFO - 2020-08-27 01:06:50 --> Router Class Initialized
INFO - 2020-08-27 01:06:50 --> Output Class Initialized
INFO - 2020-08-27 01:06:50 --> Security Class Initialized
DEBUG - 2020-08-27 01:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 01:06:50 --> Input Class Initialized
INFO - 2020-08-27 01:06:50 --> Language Class Initialized
INFO - 2020-08-27 01:06:50 --> Language Class Initialized
INFO - 2020-08-27 01:06:50 --> Config Class Initialized
INFO - 2020-08-27 01:06:50 --> Loader Class Initialized
INFO - 2020-08-27 01:06:50 --> Helper loaded: url_helper
INFO - 2020-08-27 01:06:50 --> Helper loaded: form_helper
INFO - 2020-08-27 01:06:50 --> Helper loaded: file_helper
INFO - 2020-08-27 01:06:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 01:06:50 --> Database Driver Class Initialized
DEBUG - 2020-08-27 01:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 01:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 01:06:50 --> Upload Class Initialized
INFO - 2020-08-27 01:06:50 --> Controller Class Initialized
DEBUG - 2020-08-27 01:06:50 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 01:06:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-27 01:06:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 01:06:50 --> Final output sent to browser
DEBUG - 2020-08-27 01:06:50 --> Total execution time: 0.0571
INFO - 2020-08-27 01:25:52 --> Config Class Initialized
INFO - 2020-08-27 01:25:52 --> Hooks Class Initialized
DEBUG - 2020-08-27 01:25:52 --> UTF-8 Support Enabled
INFO - 2020-08-27 01:25:52 --> Utf8 Class Initialized
INFO - 2020-08-27 01:25:52 --> URI Class Initialized
INFO - 2020-08-27 01:25:52 --> Router Class Initialized
INFO - 2020-08-27 01:25:52 --> Output Class Initialized
INFO - 2020-08-27 01:25:52 --> Security Class Initialized
DEBUG - 2020-08-27 01:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 01:25:52 --> Input Class Initialized
INFO - 2020-08-27 01:25:52 --> Language Class Initialized
INFO - 2020-08-27 01:25:52 --> Language Class Initialized
INFO - 2020-08-27 01:25:52 --> Config Class Initialized
INFO - 2020-08-27 01:25:52 --> Loader Class Initialized
INFO - 2020-08-27 01:25:52 --> Helper loaded: url_helper
INFO - 2020-08-27 01:25:52 --> Helper loaded: form_helper
INFO - 2020-08-27 01:25:52 --> Helper loaded: file_helper
INFO - 2020-08-27 01:25:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 01:25:52 --> Database Driver Class Initialized
DEBUG - 2020-08-27 01:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 01:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 01:25:52 --> Upload Class Initialized
INFO - 2020-08-27 01:25:52 --> Controller Class Initialized
DEBUG - 2020-08-27 01:25:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 01:25:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-27 01:25:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 01:25:52 --> Final output sent to browser
DEBUG - 2020-08-27 01:25:52 --> Total execution time: 0.0537
INFO - 2020-08-27 01:26:19 --> Config Class Initialized
INFO - 2020-08-27 01:26:19 --> Hooks Class Initialized
DEBUG - 2020-08-27 01:26:19 --> UTF-8 Support Enabled
INFO - 2020-08-27 01:26:19 --> Utf8 Class Initialized
INFO - 2020-08-27 01:26:19 --> URI Class Initialized
DEBUG - 2020-08-27 01:26:19 --> No URI present. Default controller set.
INFO - 2020-08-27 01:26:19 --> Router Class Initialized
INFO - 2020-08-27 01:26:19 --> Output Class Initialized
INFO - 2020-08-27 01:26:19 --> Security Class Initialized
DEBUG - 2020-08-27 01:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 01:26:19 --> Input Class Initialized
INFO - 2020-08-27 01:26:19 --> Language Class Initialized
INFO - 2020-08-27 01:26:19 --> Language Class Initialized
INFO - 2020-08-27 01:26:19 --> Config Class Initialized
INFO - 2020-08-27 01:26:19 --> Loader Class Initialized
INFO - 2020-08-27 01:26:19 --> Helper loaded: url_helper
INFO - 2020-08-27 01:26:19 --> Helper loaded: form_helper
INFO - 2020-08-27 01:26:19 --> Helper loaded: file_helper
INFO - 2020-08-27 01:26:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 01:26:19 --> Database Driver Class Initialized
DEBUG - 2020-08-27 01:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 01:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 01:26:19 --> Upload Class Initialized
INFO - 2020-08-27 01:26:19 --> Controller Class Initialized
DEBUG - 2020-08-27 01:26:19 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 01:26:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 01:26:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 01:26:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 01:26:19 --> Final output sent to browser
DEBUG - 2020-08-27 01:26:19 --> Total execution time: 0.0526
INFO - 2020-08-27 01:35:50 --> Config Class Initialized
INFO - 2020-08-27 01:35:50 --> Hooks Class Initialized
DEBUG - 2020-08-27 01:35:50 --> UTF-8 Support Enabled
INFO - 2020-08-27 01:35:50 --> Utf8 Class Initialized
INFO - 2020-08-27 01:35:50 --> URI Class Initialized
INFO - 2020-08-27 01:35:50 --> Router Class Initialized
INFO - 2020-08-27 01:35:50 --> Output Class Initialized
INFO - 2020-08-27 01:35:50 --> Security Class Initialized
DEBUG - 2020-08-27 01:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 01:35:50 --> Input Class Initialized
INFO - 2020-08-27 01:35:50 --> Language Class Initialized
INFO - 2020-08-27 01:35:50 --> Language Class Initialized
INFO - 2020-08-27 01:35:50 --> Config Class Initialized
INFO - 2020-08-27 01:35:50 --> Loader Class Initialized
INFO - 2020-08-27 01:35:50 --> Helper loaded: url_helper
INFO - 2020-08-27 01:35:50 --> Helper loaded: form_helper
INFO - 2020-08-27 01:35:50 --> Helper loaded: file_helper
INFO - 2020-08-27 01:35:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 01:35:50 --> Database Driver Class Initialized
DEBUG - 2020-08-27 01:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 01:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 01:35:50 --> Upload Class Initialized
INFO - 2020-08-27 01:35:50 --> Controller Class Initialized
ERROR - 2020-08-27 01:35:50 --> 404 Page Not Found: /index
INFO - 2020-08-27 01:40:47 --> Config Class Initialized
INFO - 2020-08-27 01:40:47 --> Hooks Class Initialized
DEBUG - 2020-08-27 01:40:47 --> UTF-8 Support Enabled
INFO - 2020-08-27 01:40:47 --> Utf8 Class Initialized
INFO - 2020-08-27 01:40:47 --> URI Class Initialized
INFO - 2020-08-27 01:40:47 --> Router Class Initialized
INFO - 2020-08-27 01:40:47 --> Output Class Initialized
INFO - 2020-08-27 01:40:47 --> Security Class Initialized
DEBUG - 2020-08-27 01:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 01:40:47 --> Input Class Initialized
INFO - 2020-08-27 01:40:47 --> Language Class Initialized
INFO - 2020-08-27 01:40:47 --> Language Class Initialized
INFO - 2020-08-27 01:40:47 --> Config Class Initialized
INFO - 2020-08-27 01:40:47 --> Loader Class Initialized
INFO - 2020-08-27 01:40:47 --> Helper loaded: url_helper
INFO - 2020-08-27 01:40:47 --> Helper loaded: form_helper
INFO - 2020-08-27 01:40:47 --> Helper loaded: file_helper
INFO - 2020-08-27 01:40:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 01:40:47 --> Database Driver Class Initialized
DEBUG - 2020-08-27 01:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 01:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 01:40:47 --> Upload Class Initialized
INFO - 2020-08-27 01:40:47 --> Controller Class Initialized
ERROR - 2020-08-27 01:40:47 --> 404 Page Not Found: /index
INFO - 2020-08-27 02:45:49 --> Config Class Initialized
INFO - 2020-08-27 02:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-27 02:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-27 02:45:49 --> Utf8 Class Initialized
INFO - 2020-08-27 02:45:49 --> URI Class Initialized
DEBUG - 2020-08-27 02:45:49 --> No URI present. Default controller set.
INFO - 2020-08-27 02:45:49 --> Router Class Initialized
INFO - 2020-08-27 02:45:49 --> Output Class Initialized
INFO - 2020-08-27 02:45:49 --> Security Class Initialized
DEBUG - 2020-08-27 02:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 02:45:49 --> Input Class Initialized
INFO - 2020-08-27 02:45:49 --> Language Class Initialized
INFO - 2020-08-27 02:45:49 --> Language Class Initialized
INFO - 2020-08-27 02:45:49 --> Config Class Initialized
INFO - 2020-08-27 02:45:49 --> Loader Class Initialized
INFO - 2020-08-27 02:45:49 --> Helper loaded: url_helper
INFO - 2020-08-27 02:45:49 --> Helper loaded: form_helper
INFO - 2020-08-27 02:45:49 --> Helper loaded: file_helper
INFO - 2020-08-27 02:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 02:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-27 02:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 02:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 02:45:49 --> Upload Class Initialized
INFO - 2020-08-27 02:45:49 --> Controller Class Initialized
DEBUG - 2020-08-27 02:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 02:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 02:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 02:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 02:45:49 --> Final output sent to browser
DEBUG - 2020-08-27 02:45:49 --> Total execution time: 0.0538
INFO - 2020-08-27 02:47:24 --> Config Class Initialized
INFO - 2020-08-27 02:47:24 --> Hooks Class Initialized
DEBUG - 2020-08-27 02:47:24 --> UTF-8 Support Enabled
INFO - 2020-08-27 02:47:24 --> Utf8 Class Initialized
INFO - 2020-08-27 02:47:24 --> URI Class Initialized
DEBUG - 2020-08-27 02:47:24 --> No URI present. Default controller set.
INFO - 2020-08-27 02:47:24 --> Router Class Initialized
INFO - 2020-08-27 02:47:24 --> Output Class Initialized
INFO - 2020-08-27 02:47:24 --> Security Class Initialized
DEBUG - 2020-08-27 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 02:47:24 --> Input Class Initialized
INFO - 2020-08-27 02:47:24 --> Language Class Initialized
INFO - 2020-08-27 02:47:24 --> Language Class Initialized
INFO - 2020-08-27 02:47:24 --> Config Class Initialized
INFO - 2020-08-27 02:47:24 --> Loader Class Initialized
INFO - 2020-08-27 02:47:24 --> Helper loaded: url_helper
INFO - 2020-08-27 02:47:24 --> Helper loaded: form_helper
INFO - 2020-08-27 02:47:24 --> Helper loaded: file_helper
INFO - 2020-08-27 02:47:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 02:47:24 --> Database Driver Class Initialized
DEBUG - 2020-08-27 02:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 02:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 02:47:24 --> Upload Class Initialized
INFO - 2020-08-27 02:47:24 --> Controller Class Initialized
DEBUG - 2020-08-27 02:47:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 02:47:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 02:47:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 02:47:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 02:47:24 --> Final output sent to browser
DEBUG - 2020-08-27 02:47:24 --> Total execution time: 0.0538
INFO - 2020-08-27 02:47:25 --> Config Class Initialized
INFO - 2020-08-27 02:47:25 --> Hooks Class Initialized
DEBUG - 2020-08-27 02:47:25 --> UTF-8 Support Enabled
INFO - 2020-08-27 02:47:25 --> Utf8 Class Initialized
INFO - 2020-08-27 02:47:25 --> URI Class Initialized
INFO - 2020-08-27 02:47:25 --> Router Class Initialized
INFO - 2020-08-27 02:47:25 --> Output Class Initialized
INFO - 2020-08-27 02:47:25 --> Security Class Initialized
DEBUG - 2020-08-27 02:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 02:47:25 --> Input Class Initialized
INFO - 2020-08-27 02:47:25 --> Language Class Initialized
INFO - 2020-08-27 02:47:25 --> Language Class Initialized
INFO - 2020-08-27 02:47:25 --> Config Class Initialized
INFO - 2020-08-27 02:47:25 --> Loader Class Initialized
INFO - 2020-08-27 02:47:25 --> Helper loaded: url_helper
INFO - 2020-08-27 02:47:25 --> Helper loaded: form_helper
INFO - 2020-08-27 02:47:25 --> Helper loaded: file_helper
INFO - 2020-08-27 02:47:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 02:47:25 --> Database Driver Class Initialized
DEBUG - 2020-08-27 02:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 02:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 02:47:25 --> Upload Class Initialized
INFO - 2020-08-27 02:47:25 --> Controller Class Initialized
ERROR - 2020-08-27 02:47:25 --> 404 Page Not Found: /index
INFO - 2020-08-27 02:47:25 --> Config Class Initialized
INFO - 2020-08-27 02:47:25 --> Hooks Class Initialized
DEBUG - 2020-08-27 02:47:25 --> UTF-8 Support Enabled
INFO - 2020-08-27 02:47:25 --> Utf8 Class Initialized
INFO - 2020-08-27 02:47:25 --> URI Class Initialized
DEBUG - 2020-08-27 02:47:25 --> No URI present. Default controller set.
INFO - 2020-08-27 02:47:25 --> Router Class Initialized
INFO - 2020-08-27 02:47:25 --> Output Class Initialized
INFO - 2020-08-27 02:47:25 --> Security Class Initialized
DEBUG - 2020-08-27 02:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 02:47:25 --> Input Class Initialized
INFO - 2020-08-27 02:47:25 --> Language Class Initialized
INFO - 2020-08-27 02:47:25 --> Language Class Initialized
INFO - 2020-08-27 02:47:25 --> Config Class Initialized
INFO - 2020-08-27 02:47:25 --> Loader Class Initialized
INFO - 2020-08-27 02:47:25 --> Helper loaded: url_helper
INFO - 2020-08-27 02:47:25 --> Helper loaded: form_helper
INFO - 2020-08-27 02:47:25 --> Helper loaded: file_helper
INFO - 2020-08-27 02:47:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 02:47:25 --> Database Driver Class Initialized
DEBUG - 2020-08-27 02:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 02:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 02:47:25 --> Upload Class Initialized
INFO - 2020-08-27 02:47:25 --> Controller Class Initialized
DEBUG - 2020-08-27 02:47:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 02:47:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 02:47:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 02:47:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 02:47:26 --> Final output sent to browser
DEBUG - 2020-08-27 02:47:26 --> Total execution time: 0.0513
INFO - 2020-08-27 07:31:55 --> Config Class Initialized
INFO - 2020-08-27 07:31:55 --> Hooks Class Initialized
DEBUG - 2020-08-27 07:31:55 --> UTF-8 Support Enabled
INFO - 2020-08-27 07:31:55 --> Utf8 Class Initialized
INFO - 2020-08-27 07:31:55 --> URI Class Initialized
DEBUG - 2020-08-27 07:31:55 --> No URI present. Default controller set.
INFO - 2020-08-27 07:31:55 --> Router Class Initialized
INFO - 2020-08-27 07:31:55 --> Output Class Initialized
INFO - 2020-08-27 07:31:55 --> Security Class Initialized
DEBUG - 2020-08-27 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 07:31:55 --> Input Class Initialized
INFO - 2020-08-27 07:31:55 --> Language Class Initialized
INFO - 2020-08-27 07:31:55 --> Language Class Initialized
INFO - 2020-08-27 07:31:55 --> Config Class Initialized
INFO - 2020-08-27 07:31:55 --> Loader Class Initialized
INFO - 2020-08-27 07:31:55 --> Helper loaded: url_helper
INFO - 2020-08-27 07:31:55 --> Helper loaded: form_helper
INFO - 2020-08-27 07:31:55 --> Helper loaded: file_helper
INFO - 2020-08-27 07:31:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 07:31:55 --> Database Driver Class Initialized
DEBUG - 2020-08-27 07:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 07:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 07:31:55 --> Upload Class Initialized
INFO - 2020-08-27 07:31:55 --> Controller Class Initialized
DEBUG - 2020-08-27 07:31:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 07:31:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 07:31:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 07:31:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 07:31:55 --> Final output sent to browser
DEBUG - 2020-08-27 07:31:55 --> Total execution time: 0.1210
INFO - 2020-08-27 07:44:27 --> Config Class Initialized
INFO - 2020-08-27 07:44:27 --> Hooks Class Initialized
DEBUG - 2020-08-27 07:44:27 --> UTF-8 Support Enabled
INFO - 2020-08-27 07:44:27 --> Utf8 Class Initialized
INFO - 2020-08-27 07:44:27 --> URI Class Initialized
INFO - 2020-08-27 07:44:27 --> Router Class Initialized
INFO - 2020-08-27 07:44:27 --> Output Class Initialized
INFO - 2020-08-27 07:44:27 --> Security Class Initialized
DEBUG - 2020-08-27 07:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 07:44:27 --> Input Class Initialized
INFO - 2020-08-27 07:44:27 --> Language Class Initialized
INFO - 2020-08-27 07:44:27 --> Language Class Initialized
INFO - 2020-08-27 07:44:27 --> Config Class Initialized
INFO - 2020-08-27 07:44:27 --> Loader Class Initialized
INFO - 2020-08-27 07:44:27 --> Helper loaded: url_helper
INFO - 2020-08-27 07:44:27 --> Helper loaded: form_helper
INFO - 2020-08-27 07:44:27 --> Helper loaded: file_helper
INFO - 2020-08-27 07:44:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 07:44:27 --> Database Driver Class Initialized
DEBUG - 2020-08-27 07:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 07:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 07:44:27 --> Upload Class Initialized
INFO - 2020-08-27 07:44:27 --> Controller Class Initialized
ERROR - 2020-08-27 07:44:27 --> 404 Page Not Found: /index
INFO - 2020-08-27 08:14:17 --> Config Class Initialized
INFO - 2020-08-27 08:14:17 --> Hooks Class Initialized
DEBUG - 2020-08-27 08:14:17 --> UTF-8 Support Enabled
INFO - 2020-08-27 08:14:17 --> Utf8 Class Initialized
INFO - 2020-08-27 08:14:17 --> URI Class Initialized
DEBUG - 2020-08-27 08:14:17 --> No URI present. Default controller set.
INFO - 2020-08-27 08:14:17 --> Router Class Initialized
INFO - 2020-08-27 08:14:17 --> Output Class Initialized
INFO - 2020-08-27 08:14:17 --> Security Class Initialized
DEBUG - 2020-08-27 08:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 08:14:17 --> Input Class Initialized
INFO - 2020-08-27 08:14:17 --> Language Class Initialized
INFO - 2020-08-27 08:14:17 --> Language Class Initialized
INFO - 2020-08-27 08:14:17 --> Config Class Initialized
INFO - 2020-08-27 08:14:17 --> Loader Class Initialized
INFO - 2020-08-27 08:14:17 --> Helper loaded: url_helper
INFO - 2020-08-27 08:14:17 --> Helper loaded: form_helper
INFO - 2020-08-27 08:14:17 --> Helper loaded: file_helper
INFO - 2020-08-27 08:14:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 08:14:17 --> Database Driver Class Initialized
DEBUG - 2020-08-27 08:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 08:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 08:14:17 --> Upload Class Initialized
INFO - 2020-08-27 08:14:17 --> Controller Class Initialized
DEBUG - 2020-08-27 08:14:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 08:14:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 08:14:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 08:14:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 08:14:17 --> Final output sent to browser
DEBUG - 2020-08-27 08:14:17 --> Total execution time: 0.0537
INFO - 2020-08-27 08:58:28 --> Config Class Initialized
INFO - 2020-08-27 08:58:28 --> Hooks Class Initialized
DEBUG - 2020-08-27 08:58:28 --> UTF-8 Support Enabled
INFO - 2020-08-27 08:58:28 --> Utf8 Class Initialized
INFO - 2020-08-27 08:58:28 --> URI Class Initialized
INFO - 2020-08-27 08:58:28 --> Router Class Initialized
INFO - 2020-08-27 08:58:28 --> Output Class Initialized
INFO - 2020-08-27 08:58:28 --> Security Class Initialized
DEBUG - 2020-08-27 08:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 08:58:28 --> Input Class Initialized
INFO - 2020-08-27 08:58:28 --> Language Class Initialized
INFO - 2020-08-27 08:58:28 --> Language Class Initialized
INFO - 2020-08-27 08:58:28 --> Config Class Initialized
INFO - 2020-08-27 08:58:28 --> Loader Class Initialized
INFO - 2020-08-27 08:58:28 --> Helper loaded: url_helper
INFO - 2020-08-27 08:58:28 --> Helper loaded: form_helper
INFO - 2020-08-27 08:58:28 --> Helper loaded: file_helper
INFO - 2020-08-27 08:58:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 08:58:29 --> Database Driver Class Initialized
DEBUG - 2020-08-27 08:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 08:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 08:58:29 --> Upload Class Initialized
INFO - 2020-08-27 08:58:30 --> Controller Class Initialized
DEBUG - 2020-08-27 08:58:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 08:58:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 08:58:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 08:58:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 08:58:30 --> Final output sent to browser
DEBUG - 2020-08-27 08:58:30 --> Total execution time: 2.4600
INFO - 2020-08-27 08:58:32 --> Config Class Initialized
INFO - 2020-08-27 08:58:32 --> Hooks Class Initialized
DEBUG - 2020-08-27 08:58:32 --> UTF-8 Support Enabled
INFO - 2020-08-27 08:58:32 --> Utf8 Class Initialized
INFO - 2020-08-27 08:58:32 --> URI Class Initialized
INFO - 2020-08-27 08:58:32 --> Router Class Initialized
INFO - 2020-08-27 08:58:32 --> Output Class Initialized
INFO - 2020-08-27 08:58:32 --> Security Class Initialized
DEBUG - 2020-08-27 08:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 08:58:32 --> Input Class Initialized
INFO - 2020-08-27 08:58:32 --> Language Class Initialized
INFO - 2020-08-27 08:58:32 --> Language Class Initialized
INFO - 2020-08-27 08:58:32 --> Config Class Initialized
INFO - 2020-08-27 08:58:32 --> Loader Class Initialized
INFO - 2020-08-27 08:58:32 --> Helper loaded: url_helper
INFO - 2020-08-27 08:58:32 --> Helper loaded: form_helper
INFO - 2020-08-27 08:58:32 --> Helper loaded: file_helper
INFO - 2020-08-27 08:58:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 08:58:32 --> Database Driver Class Initialized
DEBUG - 2020-08-27 08:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 08:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 08:58:32 --> Upload Class Initialized
INFO - 2020-08-27 08:58:32 --> Controller Class Initialized
ERROR - 2020-08-27 08:58:32 --> 404 Page Not Found: /index
INFO - 2020-08-27 09:00:00 --> Config Class Initialized
INFO - 2020-08-27 09:00:00 --> Hooks Class Initialized
DEBUG - 2020-08-27 09:00:00 --> UTF-8 Support Enabled
INFO - 2020-08-27 09:00:00 --> Utf8 Class Initialized
INFO - 2020-08-27 09:00:00 --> URI Class Initialized
INFO - 2020-08-27 09:00:00 --> Router Class Initialized
INFO - 2020-08-27 09:00:00 --> Output Class Initialized
INFO - 2020-08-27 09:00:00 --> Security Class Initialized
DEBUG - 2020-08-27 09:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 09:00:00 --> Input Class Initialized
INFO - 2020-08-27 09:00:00 --> Language Class Initialized
INFO - 2020-08-27 09:00:00 --> Language Class Initialized
INFO - 2020-08-27 09:00:00 --> Config Class Initialized
INFO - 2020-08-27 09:00:00 --> Loader Class Initialized
INFO - 2020-08-27 09:00:00 --> Helper loaded: url_helper
INFO - 2020-08-27 09:00:00 --> Helper loaded: form_helper
INFO - 2020-08-27 09:00:00 --> Helper loaded: file_helper
INFO - 2020-08-27 09:00:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 09:00:00 --> Database Driver Class Initialized
DEBUG - 2020-08-27 09:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 09:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 09:00:00 --> Upload Class Initialized
INFO - 2020-08-27 09:00:00 --> Controller Class Initialized
DEBUG - 2020-08-27 09:00:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 09:00:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 09:00:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 09:00:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 09:00:00 --> Final output sent to browser
DEBUG - 2020-08-27 09:00:00 --> Total execution time: 0.0495
INFO - 2020-08-27 09:00:04 --> Config Class Initialized
INFO - 2020-08-27 09:00:04 --> Hooks Class Initialized
DEBUG - 2020-08-27 09:00:04 --> UTF-8 Support Enabled
INFO - 2020-08-27 09:00:04 --> Utf8 Class Initialized
INFO - 2020-08-27 09:00:04 --> URI Class Initialized
INFO - 2020-08-27 09:00:04 --> Router Class Initialized
INFO - 2020-08-27 09:00:04 --> Output Class Initialized
INFO - 2020-08-27 09:00:04 --> Security Class Initialized
DEBUG - 2020-08-27 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 09:00:04 --> Input Class Initialized
INFO - 2020-08-27 09:00:04 --> Language Class Initialized
INFO - 2020-08-27 09:00:04 --> Language Class Initialized
INFO - 2020-08-27 09:00:04 --> Config Class Initialized
INFO - 2020-08-27 09:00:04 --> Loader Class Initialized
INFO - 2020-08-27 09:00:04 --> Helper loaded: url_helper
INFO - 2020-08-27 09:00:04 --> Helper loaded: form_helper
INFO - 2020-08-27 09:00:04 --> Helper loaded: file_helper
INFO - 2020-08-27 09:00:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 09:00:04 --> Database Driver Class Initialized
DEBUG - 2020-08-27 09:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 09:00:04 --> Upload Class Initialized
INFO - 2020-08-27 09:00:04 --> Controller Class Initialized
ERROR - 2020-08-27 09:00:04 --> 404 Page Not Found: /index
INFO - 2020-08-27 09:23:26 --> Config Class Initialized
INFO - 2020-08-27 09:23:26 --> Hooks Class Initialized
DEBUG - 2020-08-27 09:23:26 --> UTF-8 Support Enabled
INFO - 2020-08-27 09:23:26 --> Utf8 Class Initialized
INFO - 2020-08-27 09:23:26 --> URI Class Initialized
DEBUG - 2020-08-27 09:23:26 --> No URI present. Default controller set.
INFO - 2020-08-27 09:23:26 --> Router Class Initialized
INFO - 2020-08-27 09:23:26 --> Output Class Initialized
INFO - 2020-08-27 09:23:26 --> Security Class Initialized
DEBUG - 2020-08-27 09:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 09:23:26 --> Input Class Initialized
INFO - 2020-08-27 09:23:26 --> Language Class Initialized
INFO - 2020-08-27 09:23:26 --> Language Class Initialized
INFO - 2020-08-27 09:23:26 --> Config Class Initialized
INFO - 2020-08-27 09:23:26 --> Loader Class Initialized
INFO - 2020-08-27 09:23:26 --> Helper loaded: url_helper
INFO - 2020-08-27 09:23:26 --> Helper loaded: form_helper
INFO - 2020-08-27 09:23:26 --> Helper loaded: file_helper
INFO - 2020-08-27 09:23:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 09:23:26 --> Database Driver Class Initialized
DEBUG - 2020-08-27 09:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 09:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 09:23:26 --> Upload Class Initialized
INFO - 2020-08-27 09:23:26 --> Controller Class Initialized
DEBUG - 2020-08-27 09:23:26 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 09:23:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 09:23:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 09:23:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 09:23:26 --> Final output sent to browser
DEBUG - 2020-08-27 09:23:26 --> Total execution time: 0.0600
INFO - 2020-08-27 10:19:46 --> Config Class Initialized
INFO - 2020-08-27 10:19:46 --> Hooks Class Initialized
DEBUG - 2020-08-27 10:19:46 --> UTF-8 Support Enabled
INFO - 2020-08-27 10:19:46 --> Utf8 Class Initialized
INFO - 2020-08-27 10:19:46 --> URI Class Initialized
DEBUG - 2020-08-27 10:19:46 --> No URI present. Default controller set.
INFO - 2020-08-27 10:19:46 --> Router Class Initialized
INFO - 2020-08-27 10:19:46 --> Output Class Initialized
INFO - 2020-08-27 10:19:46 --> Security Class Initialized
DEBUG - 2020-08-27 10:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 10:19:46 --> Input Class Initialized
INFO - 2020-08-27 10:19:46 --> Language Class Initialized
INFO - 2020-08-27 10:19:46 --> Language Class Initialized
INFO - 2020-08-27 10:19:46 --> Config Class Initialized
INFO - 2020-08-27 10:19:46 --> Loader Class Initialized
INFO - 2020-08-27 10:19:46 --> Helper loaded: url_helper
INFO - 2020-08-27 10:19:46 --> Helper loaded: form_helper
INFO - 2020-08-27 10:19:46 --> Helper loaded: file_helper
INFO - 2020-08-27 10:19:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 10:19:46 --> Database Driver Class Initialized
DEBUG - 2020-08-27 10:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 10:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 10:19:46 --> Upload Class Initialized
INFO - 2020-08-27 10:19:46 --> Controller Class Initialized
DEBUG - 2020-08-27 10:19:46 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 10:19:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 10:19:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 10:19:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 10:19:46 --> Final output sent to browser
DEBUG - 2020-08-27 10:19:46 --> Total execution time: 0.1413
INFO - 2020-08-27 13:28:38 --> Config Class Initialized
INFO - 2020-08-27 13:28:38 --> Hooks Class Initialized
DEBUG - 2020-08-27 13:28:38 --> UTF-8 Support Enabled
INFO - 2020-08-27 13:28:38 --> Utf8 Class Initialized
INFO - 2020-08-27 13:28:38 --> URI Class Initialized
DEBUG - 2020-08-27 13:28:38 --> No URI present. Default controller set.
INFO - 2020-08-27 13:28:38 --> Router Class Initialized
INFO - 2020-08-27 13:28:38 --> Output Class Initialized
INFO - 2020-08-27 13:28:38 --> Security Class Initialized
DEBUG - 2020-08-27 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 13:28:38 --> Input Class Initialized
INFO - 2020-08-27 13:28:38 --> Language Class Initialized
INFO - 2020-08-27 13:28:38 --> Language Class Initialized
INFO - 2020-08-27 13:28:38 --> Config Class Initialized
INFO - 2020-08-27 13:28:38 --> Loader Class Initialized
INFO - 2020-08-27 13:28:38 --> Helper loaded: url_helper
INFO - 2020-08-27 13:28:38 --> Helper loaded: form_helper
INFO - 2020-08-27 13:28:38 --> Helper loaded: file_helper
INFO - 2020-08-27 13:28:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 13:28:38 --> Database Driver Class Initialized
DEBUG - 2020-08-27 13:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 13:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 13:28:38 --> Upload Class Initialized
INFO - 2020-08-27 13:28:38 --> Controller Class Initialized
DEBUG - 2020-08-27 13:28:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 13:28:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 13:28:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 13:28:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 13:28:38 --> Final output sent to browser
DEBUG - 2020-08-27 13:28:38 --> Total execution time: 0.0718
INFO - 2020-08-27 14:34:41 --> Config Class Initialized
INFO - 2020-08-27 14:34:41 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:34:41 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:34:41 --> Utf8 Class Initialized
INFO - 2020-08-27 14:34:41 --> URI Class Initialized
DEBUG - 2020-08-27 14:34:41 --> No URI present. Default controller set.
INFO - 2020-08-27 14:34:41 --> Router Class Initialized
INFO - 2020-08-27 14:34:41 --> Output Class Initialized
INFO - 2020-08-27 14:34:41 --> Security Class Initialized
DEBUG - 2020-08-27 14:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:34:41 --> Input Class Initialized
INFO - 2020-08-27 14:34:41 --> Language Class Initialized
INFO - 2020-08-27 14:34:41 --> Language Class Initialized
INFO - 2020-08-27 14:34:41 --> Config Class Initialized
INFO - 2020-08-27 14:34:41 --> Loader Class Initialized
INFO - 2020-08-27 14:34:41 --> Helper loaded: url_helper
INFO - 2020-08-27 14:34:41 --> Helper loaded: form_helper
INFO - 2020-08-27 14:34:41 --> Helper loaded: file_helper
INFO - 2020-08-27 14:34:41 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 14:34:41 --> Database Driver Class Initialized
DEBUG - 2020-08-27 14:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 14:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:34:41 --> Upload Class Initialized
INFO - 2020-08-27 14:34:41 --> Controller Class Initialized
DEBUG - 2020-08-27 14:34:41 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 14:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 14:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 14:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 14:34:41 --> Final output sent to browser
DEBUG - 2020-08-27 14:34:41 --> Total execution time: 0.1144
INFO - 2020-08-27 14:39:10 --> Config Class Initialized
INFO - 2020-08-27 14:39:10 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:39:10 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:39:10 --> Utf8 Class Initialized
INFO - 2020-08-27 14:39:10 --> URI Class Initialized
DEBUG - 2020-08-27 14:39:10 --> No URI present. Default controller set.
INFO - 2020-08-27 14:39:10 --> Router Class Initialized
INFO - 2020-08-27 14:39:10 --> Output Class Initialized
INFO - 2020-08-27 14:39:10 --> Security Class Initialized
DEBUG - 2020-08-27 14:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:39:10 --> Input Class Initialized
INFO - 2020-08-27 14:39:10 --> Language Class Initialized
INFO - 2020-08-27 14:39:10 --> Language Class Initialized
INFO - 2020-08-27 14:39:10 --> Config Class Initialized
INFO - 2020-08-27 14:39:10 --> Loader Class Initialized
INFO - 2020-08-27 14:39:10 --> Helper loaded: url_helper
INFO - 2020-08-27 14:39:10 --> Helper loaded: form_helper
INFO - 2020-08-27 14:39:10 --> Helper loaded: file_helper
INFO - 2020-08-27 14:39:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 14:39:10 --> Database Driver Class Initialized
DEBUG - 2020-08-27 14:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:39:10 --> Upload Class Initialized
INFO - 2020-08-27 14:39:10 --> Controller Class Initialized
DEBUG - 2020-08-27 14:39:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 14:39:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 14:39:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 14:39:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 14:39:10 --> Final output sent to browser
DEBUG - 2020-08-27 14:39:10 --> Total execution time: 0.0506
INFO - 2020-08-27 14:39:11 --> Config Class Initialized
INFO - 2020-08-27 14:39:11 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:39:11 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:39:11 --> Utf8 Class Initialized
INFO - 2020-08-27 14:39:11 --> URI Class Initialized
INFO - 2020-08-27 14:39:11 --> Router Class Initialized
INFO - 2020-08-27 14:39:11 --> Output Class Initialized
INFO - 2020-08-27 14:39:11 --> Security Class Initialized
DEBUG - 2020-08-27 14:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:39:11 --> Input Class Initialized
INFO - 2020-08-27 14:39:11 --> Language Class Initialized
INFO - 2020-08-27 14:39:11 --> Language Class Initialized
INFO - 2020-08-27 14:39:11 --> Config Class Initialized
INFO - 2020-08-27 14:39:11 --> Loader Class Initialized
INFO - 2020-08-27 14:39:11 --> Helper loaded: url_helper
INFO - 2020-08-27 14:39:11 --> Helper loaded: form_helper
INFO - 2020-08-27 14:39:11 --> Helper loaded: file_helper
INFO - 2020-08-27 14:39:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 14:39:11 --> Database Driver Class Initialized
DEBUG - 2020-08-27 14:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 14:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:39:11 --> Upload Class Initialized
INFO - 2020-08-27 14:39:11 --> Controller Class Initialized
ERROR - 2020-08-27 14:39:11 --> 404 Page Not Found: /index
INFO - 2020-08-27 14:39:12 --> Config Class Initialized
INFO - 2020-08-27 14:39:12 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:39:12 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:39:12 --> Utf8 Class Initialized
INFO - 2020-08-27 14:39:12 --> URI Class Initialized
DEBUG - 2020-08-27 14:39:12 --> No URI present. Default controller set.
INFO - 2020-08-27 14:39:12 --> Router Class Initialized
INFO - 2020-08-27 14:39:12 --> Output Class Initialized
INFO - 2020-08-27 14:39:12 --> Security Class Initialized
DEBUG - 2020-08-27 14:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:39:12 --> Input Class Initialized
INFO - 2020-08-27 14:39:12 --> Language Class Initialized
INFO - 2020-08-27 14:39:12 --> Language Class Initialized
INFO - 2020-08-27 14:39:12 --> Config Class Initialized
INFO - 2020-08-27 14:39:12 --> Loader Class Initialized
INFO - 2020-08-27 14:39:12 --> Helper loaded: url_helper
INFO - 2020-08-27 14:39:12 --> Helper loaded: form_helper
INFO - 2020-08-27 14:39:12 --> Helper loaded: file_helper
INFO - 2020-08-27 14:39:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 14:39:12 --> Database Driver Class Initialized
DEBUG - 2020-08-27 14:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 14:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:39:12 --> Upload Class Initialized
INFO - 2020-08-27 14:39:12 --> Controller Class Initialized
DEBUG - 2020-08-27 14:39:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 14:39:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 14:39:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 14:39:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 14:39:12 --> Final output sent to browser
DEBUG - 2020-08-27 14:39:12 --> Total execution time: 0.0504
INFO - 2020-08-27 14:54:22 --> Config Class Initialized
INFO - 2020-08-27 14:54:22 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:54:22 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:54:22 --> Utf8 Class Initialized
INFO - 2020-08-27 14:54:22 --> URI Class Initialized
DEBUG - 2020-08-27 14:54:22 --> No URI present. Default controller set.
INFO - 2020-08-27 14:54:22 --> Router Class Initialized
INFO - 2020-08-27 14:54:22 --> Output Class Initialized
INFO - 2020-08-27 14:54:22 --> Security Class Initialized
DEBUG - 2020-08-27 14:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:54:22 --> Input Class Initialized
INFO - 2020-08-27 14:54:22 --> Language Class Initialized
INFO - 2020-08-27 14:54:22 --> Language Class Initialized
INFO - 2020-08-27 14:54:22 --> Config Class Initialized
INFO - 2020-08-27 14:54:22 --> Loader Class Initialized
INFO - 2020-08-27 14:54:22 --> Helper loaded: url_helper
INFO - 2020-08-27 14:54:22 --> Helper loaded: form_helper
INFO - 2020-08-27 14:54:22 --> Helper loaded: file_helper
INFO - 2020-08-27 14:54:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 14:54:22 --> Database Driver Class Initialized
DEBUG - 2020-08-27 14:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 14:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:54:22 --> Upload Class Initialized
INFO - 2020-08-27 14:54:22 --> Controller Class Initialized
DEBUG - 2020-08-27 14:54:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 14:54:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 14:54:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 14:54:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 14:54:22 --> Final output sent to browser
DEBUG - 2020-08-27 14:54:22 --> Total execution time: 0.0517
INFO - 2020-08-27 16:15:25 --> Config Class Initialized
INFO - 2020-08-27 16:15:25 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:15:25 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:15:25 --> Utf8 Class Initialized
INFO - 2020-08-27 16:15:25 --> URI Class Initialized
DEBUG - 2020-08-27 16:15:25 --> No URI present. Default controller set.
INFO - 2020-08-27 16:15:25 --> Router Class Initialized
INFO - 2020-08-27 16:15:25 --> Output Class Initialized
INFO - 2020-08-27 16:15:25 --> Security Class Initialized
DEBUG - 2020-08-27 16:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:15:25 --> Input Class Initialized
INFO - 2020-08-27 16:15:25 --> Language Class Initialized
INFO - 2020-08-27 16:15:25 --> Language Class Initialized
INFO - 2020-08-27 16:15:25 --> Config Class Initialized
INFO - 2020-08-27 16:15:25 --> Loader Class Initialized
INFO - 2020-08-27 16:15:25 --> Helper loaded: url_helper
INFO - 2020-08-27 16:15:25 --> Helper loaded: form_helper
INFO - 2020-08-27 16:15:25 --> Helper loaded: file_helper
INFO - 2020-08-27 16:15:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 16:15:25 --> Database Driver Class Initialized
DEBUG - 2020-08-27 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 16:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:15:25 --> Upload Class Initialized
INFO - 2020-08-27 16:15:25 --> Controller Class Initialized
DEBUG - 2020-08-27 16:15:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 16:15:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 16:15:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 16:15:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 16:15:25 --> Final output sent to browser
DEBUG - 2020-08-27 16:15:25 --> Total execution time: 0.1929
INFO - 2020-08-27 16:59:22 --> Config Class Initialized
INFO - 2020-08-27 16:59:22 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:59:22 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:59:22 --> Utf8 Class Initialized
INFO - 2020-08-27 16:59:22 --> URI Class Initialized
INFO - 2020-08-27 16:59:22 --> Router Class Initialized
INFO - 2020-08-27 16:59:22 --> Output Class Initialized
INFO - 2020-08-27 16:59:22 --> Security Class Initialized
DEBUG - 2020-08-27 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:59:22 --> Input Class Initialized
INFO - 2020-08-27 16:59:22 --> Language Class Initialized
INFO - 2020-08-27 16:59:22 --> Language Class Initialized
INFO - 2020-08-27 16:59:22 --> Config Class Initialized
INFO - 2020-08-27 16:59:22 --> Loader Class Initialized
INFO - 2020-08-27 16:59:22 --> Helper loaded: url_helper
INFO - 2020-08-27 16:59:22 --> Helper loaded: form_helper
INFO - 2020-08-27 16:59:22 --> Helper loaded: file_helper
INFO - 2020-08-27 16:59:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 16:59:22 --> Database Driver Class Initialized
DEBUG - 2020-08-27 16:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:59:22 --> Upload Class Initialized
INFO - 2020-08-27 16:59:22 --> Controller Class Initialized
ERROR - 2020-08-27 16:59:22 --> 404 Page Not Found: /index
INFO - 2020-08-27 16:59:22 --> Config Class Initialized
INFO - 2020-08-27 16:59:22 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:59:22 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:59:22 --> Utf8 Class Initialized
INFO - 2020-08-27 16:59:22 --> URI Class Initialized
DEBUG - 2020-08-27 16:59:22 --> No URI present. Default controller set.
INFO - 2020-08-27 16:59:22 --> Router Class Initialized
INFO - 2020-08-27 16:59:22 --> Output Class Initialized
INFO - 2020-08-27 16:59:22 --> Security Class Initialized
DEBUG - 2020-08-27 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:59:22 --> Input Class Initialized
INFO - 2020-08-27 16:59:22 --> Language Class Initialized
INFO - 2020-08-27 16:59:22 --> Language Class Initialized
INFO - 2020-08-27 16:59:22 --> Config Class Initialized
INFO - 2020-08-27 16:59:22 --> Loader Class Initialized
INFO - 2020-08-27 16:59:22 --> Helper loaded: url_helper
INFO - 2020-08-27 16:59:22 --> Helper loaded: form_helper
INFO - 2020-08-27 16:59:22 --> Helper loaded: file_helper
INFO - 2020-08-27 16:59:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 16:59:22 --> Database Driver Class Initialized
DEBUG - 2020-08-27 16:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:59:22 --> Upload Class Initialized
INFO - 2020-08-27 16:59:22 --> Controller Class Initialized
DEBUG - 2020-08-27 16:59:22 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 16:59:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 16:59:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 16:59:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 16:59:22 --> Final output sent to browser
DEBUG - 2020-08-27 16:59:22 --> Total execution time: 0.0500
INFO - 2020-08-27 17:26:44 --> Config Class Initialized
INFO - 2020-08-27 17:26:44 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:26:44 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:26:44 --> Utf8 Class Initialized
INFO - 2020-08-27 17:26:44 --> URI Class Initialized
INFO - 2020-08-27 17:26:44 --> Router Class Initialized
INFO - 2020-08-27 17:26:44 --> Output Class Initialized
INFO - 2020-08-27 17:26:44 --> Security Class Initialized
DEBUG - 2020-08-27 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:26:44 --> Input Class Initialized
INFO - 2020-08-27 17:26:44 --> Language Class Initialized
INFO - 2020-08-27 17:26:44 --> Language Class Initialized
INFO - 2020-08-27 17:26:44 --> Config Class Initialized
INFO - 2020-08-27 17:26:44 --> Loader Class Initialized
INFO - 2020-08-27 17:26:44 --> Helper loaded: url_helper
INFO - 2020-08-27 17:26:44 --> Helper loaded: form_helper
INFO - 2020-08-27 17:26:44 --> Helper loaded: file_helper
INFO - 2020-08-27 17:26:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 17:26:44 --> Database Driver Class Initialized
DEBUG - 2020-08-27 17:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:26:44 --> Upload Class Initialized
INFO - 2020-08-27 17:26:44 --> Controller Class Initialized
ERROR - 2020-08-27 17:26:44 --> 404 Page Not Found: /index
INFO - 2020-08-27 18:35:16 --> Config Class Initialized
INFO - 2020-08-27 18:35:16 --> Hooks Class Initialized
DEBUG - 2020-08-27 18:35:16 --> UTF-8 Support Enabled
INFO - 2020-08-27 18:35:16 --> Utf8 Class Initialized
INFO - 2020-08-27 18:35:16 --> URI Class Initialized
INFO - 2020-08-27 18:35:16 --> Router Class Initialized
INFO - 2020-08-27 18:35:16 --> Output Class Initialized
INFO - 2020-08-27 18:35:16 --> Security Class Initialized
DEBUG - 2020-08-27 18:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 18:35:16 --> Input Class Initialized
INFO - 2020-08-27 18:35:16 --> Language Class Initialized
INFO - 2020-08-27 18:35:16 --> Language Class Initialized
INFO - 2020-08-27 18:35:16 --> Config Class Initialized
INFO - 2020-08-27 18:35:16 --> Loader Class Initialized
INFO - 2020-08-27 18:35:16 --> Helper loaded: url_helper
INFO - 2020-08-27 18:35:16 --> Helper loaded: form_helper
INFO - 2020-08-27 18:35:16 --> Helper loaded: file_helper
INFO - 2020-08-27 18:35:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 18:35:16 --> Database Driver Class Initialized
DEBUG - 2020-08-27 18:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 18:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 18:35:16 --> Upload Class Initialized
INFO - 2020-08-27 18:35:16 --> Controller Class Initialized
DEBUG - 2020-08-27 18:35:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 18:35:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 18:35:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 18:35:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 18:35:16 --> Final output sent to browser
DEBUG - 2020-08-27 18:35:16 --> Total execution time: 0.0546
INFO - 2020-08-27 18:35:18 --> Config Class Initialized
INFO - 2020-08-27 18:35:18 --> Hooks Class Initialized
DEBUG - 2020-08-27 18:35:18 --> UTF-8 Support Enabled
INFO - 2020-08-27 18:35:18 --> Utf8 Class Initialized
INFO - 2020-08-27 18:35:18 --> URI Class Initialized
INFO - 2020-08-27 18:35:18 --> Router Class Initialized
INFO - 2020-08-27 18:35:18 --> Output Class Initialized
INFO - 2020-08-27 18:35:18 --> Security Class Initialized
DEBUG - 2020-08-27 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 18:35:18 --> Input Class Initialized
INFO - 2020-08-27 18:35:18 --> Language Class Initialized
INFO - 2020-08-27 18:35:18 --> Language Class Initialized
INFO - 2020-08-27 18:35:18 --> Config Class Initialized
INFO - 2020-08-27 18:35:18 --> Loader Class Initialized
INFO - 2020-08-27 18:35:18 --> Helper loaded: url_helper
INFO - 2020-08-27 18:35:18 --> Helper loaded: form_helper
INFO - 2020-08-27 18:35:18 --> Helper loaded: file_helper
INFO - 2020-08-27 18:35:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 18:35:18 --> Database Driver Class Initialized
DEBUG - 2020-08-27 18:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 18:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 18:35:18 --> Upload Class Initialized
INFO - 2020-08-27 18:35:18 --> Controller Class Initialized
ERROR - 2020-08-27 18:35:18 --> 404 Page Not Found: /index
INFO - 2020-08-27 19:50:57 --> Config Class Initialized
INFO - 2020-08-27 19:50:57 --> Hooks Class Initialized
DEBUG - 2020-08-27 19:50:57 --> UTF-8 Support Enabled
INFO - 2020-08-27 19:50:57 --> Utf8 Class Initialized
INFO - 2020-08-27 19:50:57 --> URI Class Initialized
INFO - 2020-08-27 19:50:57 --> Router Class Initialized
INFO - 2020-08-27 19:50:57 --> Output Class Initialized
INFO - 2020-08-27 19:50:57 --> Security Class Initialized
DEBUG - 2020-08-27 19:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 19:50:57 --> Input Class Initialized
INFO - 2020-08-27 19:50:57 --> Language Class Initialized
INFO - 2020-08-27 19:50:57 --> Language Class Initialized
INFO - 2020-08-27 19:50:57 --> Config Class Initialized
INFO - 2020-08-27 19:50:57 --> Loader Class Initialized
INFO - 2020-08-27 19:50:57 --> Helper loaded: url_helper
INFO - 2020-08-27 19:50:57 --> Helper loaded: form_helper
INFO - 2020-08-27 19:50:57 --> Helper loaded: file_helper
INFO - 2020-08-27 19:50:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 19:50:57 --> Database Driver Class Initialized
DEBUG - 2020-08-27 19:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 19:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 19:50:57 --> Upload Class Initialized
INFO - 2020-08-27 19:50:57 --> Controller Class Initialized
ERROR - 2020-08-27 19:50:57 --> 404 Page Not Found: /index
INFO - 2020-08-27 19:51:00 --> Config Class Initialized
INFO - 2020-08-27 19:51:00 --> Hooks Class Initialized
DEBUG - 2020-08-27 19:51:00 --> UTF-8 Support Enabled
INFO - 2020-08-27 19:51:00 --> Utf8 Class Initialized
INFO - 2020-08-27 19:51:00 --> URI Class Initialized
DEBUG - 2020-08-27 19:51:00 --> No URI present. Default controller set.
INFO - 2020-08-27 19:51:00 --> Router Class Initialized
INFO - 2020-08-27 19:51:00 --> Output Class Initialized
INFO - 2020-08-27 19:51:00 --> Security Class Initialized
DEBUG - 2020-08-27 19:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 19:51:00 --> Input Class Initialized
INFO - 2020-08-27 19:51:00 --> Language Class Initialized
INFO - 2020-08-27 19:51:00 --> Language Class Initialized
INFO - 2020-08-27 19:51:00 --> Config Class Initialized
INFO - 2020-08-27 19:51:01 --> Loader Class Initialized
INFO - 2020-08-27 19:51:01 --> Helper loaded: url_helper
INFO - 2020-08-27 19:51:01 --> Helper loaded: form_helper
INFO - 2020-08-27 19:51:01 --> Helper loaded: file_helper
INFO - 2020-08-27 19:51:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 19:51:01 --> Database Driver Class Initialized
DEBUG - 2020-08-27 19:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 19:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 19:51:01 --> Upload Class Initialized
INFO - 2020-08-27 19:51:01 --> Controller Class Initialized
DEBUG - 2020-08-27 19:51:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 19:51:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 19:51:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 19:51:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 19:51:01 --> Final output sent to browser
DEBUG - 2020-08-27 19:51:01 --> Total execution time: 0.0500
INFO - 2020-08-27 20:16:08 --> Config Class Initialized
INFO - 2020-08-27 20:16:08 --> Hooks Class Initialized
DEBUG - 2020-08-27 20:16:08 --> UTF-8 Support Enabled
INFO - 2020-08-27 20:16:08 --> Utf8 Class Initialized
INFO - 2020-08-27 20:16:08 --> URI Class Initialized
DEBUG - 2020-08-27 20:16:08 --> No URI present. Default controller set.
INFO - 2020-08-27 20:16:08 --> Router Class Initialized
INFO - 2020-08-27 20:16:08 --> Output Class Initialized
INFO - 2020-08-27 20:16:08 --> Security Class Initialized
DEBUG - 2020-08-27 20:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 20:16:08 --> Input Class Initialized
INFO - 2020-08-27 20:16:08 --> Language Class Initialized
INFO - 2020-08-27 20:16:08 --> Language Class Initialized
INFO - 2020-08-27 20:16:08 --> Config Class Initialized
INFO - 2020-08-27 20:16:08 --> Loader Class Initialized
INFO - 2020-08-27 20:16:08 --> Helper loaded: url_helper
INFO - 2020-08-27 20:16:08 --> Helper loaded: form_helper
INFO - 2020-08-27 20:16:08 --> Helper loaded: file_helper
INFO - 2020-08-27 20:16:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 20:16:08 --> Database Driver Class Initialized
DEBUG - 2020-08-27 20:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 20:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 20:16:08 --> Upload Class Initialized
INFO - 2020-08-27 20:16:08 --> Controller Class Initialized
DEBUG - 2020-08-27 20:16:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 20:16:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 20:16:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 20:16:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 20:16:08 --> Final output sent to browser
DEBUG - 2020-08-27 20:16:08 --> Total execution time: 0.0510
INFO - 2020-08-27 20:16:16 --> Config Class Initialized
INFO - 2020-08-27 20:16:16 --> Hooks Class Initialized
DEBUG - 2020-08-27 20:16:16 --> UTF-8 Support Enabled
INFO - 2020-08-27 20:16:16 --> Utf8 Class Initialized
INFO - 2020-08-27 20:16:16 --> URI Class Initialized
INFO - 2020-08-27 20:16:16 --> Router Class Initialized
INFO - 2020-08-27 20:16:16 --> Output Class Initialized
INFO - 2020-08-27 20:16:16 --> Security Class Initialized
DEBUG - 2020-08-27 20:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 20:16:16 --> Input Class Initialized
INFO - 2020-08-27 20:16:16 --> Language Class Initialized
INFO - 2020-08-27 20:16:16 --> Language Class Initialized
INFO - 2020-08-27 20:16:16 --> Config Class Initialized
INFO - 2020-08-27 20:16:16 --> Loader Class Initialized
INFO - 2020-08-27 20:16:16 --> Helper loaded: url_helper
INFO - 2020-08-27 20:16:16 --> Helper loaded: form_helper
INFO - 2020-08-27 20:16:16 --> Helper loaded: file_helper
INFO - 2020-08-27 20:16:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 20:16:16 --> Database Driver Class Initialized
DEBUG - 2020-08-27 20:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 20:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 20:16:16 --> Upload Class Initialized
INFO - 2020-08-27 20:16:17 --> Controller Class Initialized
ERROR - 2020-08-27 20:16:17 --> 404 Page Not Found: /index
INFO - 2020-08-27 20:19:15 --> Config Class Initialized
INFO - 2020-08-27 20:19:15 --> Hooks Class Initialized
DEBUG - 2020-08-27 20:19:15 --> UTF-8 Support Enabled
INFO - 2020-08-27 20:19:15 --> Utf8 Class Initialized
INFO - 2020-08-27 20:19:15 --> URI Class Initialized
DEBUG - 2020-08-27 20:19:15 --> No URI present. Default controller set.
INFO - 2020-08-27 20:19:15 --> Router Class Initialized
INFO - 2020-08-27 20:19:15 --> Output Class Initialized
INFO - 2020-08-27 20:19:15 --> Security Class Initialized
DEBUG - 2020-08-27 20:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 20:19:15 --> Input Class Initialized
INFO - 2020-08-27 20:19:15 --> Language Class Initialized
INFO - 2020-08-27 20:19:15 --> Language Class Initialized
INFO - 2020-08-27 20:19:15 --> Config Class Initialized
INFO - 2020-08-27 20:19:15 --> Loader Class Initialized
INFO - 2020-08-27 20:19:15 --> Helper loaded: url_helper
INFO - 2020-08-27 20:19:15 --> Helper loaded: form_helper
INFO - 2020-08-27 20:19:15 --> Helper loaded: file_helper
INFO - 2020-08-27 20:19:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 20:19:15 --> Database Driver Class Initialized
DEBUG - 2020-08-27 20:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 20:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 20:19:15 --> Upload Class Initialized
INFO - 2020-08-27 20:19:15 --> Controller Class Initialized
DEBUG - 2020-08-27 20:19:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 20:19:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 20:19:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 20:19:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 20:19:15 --> Final output sent to browser
DEBUG - 2020-08-27 20:19:15 --> Total execution time: 0.0509
INFO - 2020-08-27 21:48:12 --> Config Class Initialized
INFO - 2020-08-27 21:48:12 --> Hooks Class Initialized
DEBUG - 2020-08-27 21:48:12 --> UTF-8 Support Enabled
INFO - 2020-08-27 21:48:12 --> Utf8 Class Initialized
INFO - 2020-08-27 21:48:12 --> URI Class Initialized
INFO - 2020-08-27 21:48:12 --> Router Class Initialized
INFO - 2020-08-27 21:48:12 --> Output Class Initialized
INFO - 2020-08-27 21:48:12 --> Security Class Initialized
DEBUG - 2020-08-27 21:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 21:48:12 --> Input Class Initialized
INFO - 2020-08-27 21:48:12 --> Language Class Initialized
INFO - 2020-08-27 21:48:12 --> Language Class Initialized
INFO - 2020-08-27 21:48:12 --> Config Class Initialized
INFO - 2020-08-27 21:48:12 --> Loader Class Initialized
INFO - 2020-08-27 21:48:12 --> Helper loaded: url_helper
INFO - 2020-08-27 21:48:12 --> Helper loaded: form_helper
INFO - 2020-08-27 21:48:12 --> Helper loaded: file_helper
INFO - 2020-08-27 21:48:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 21:48:12 --> Database Driver Class Initialized
DEBUG - 2020-08-27 21:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 21:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 21:48:12 --> Upload Class Initialized
INFO - 2020-08-27 21:48:13 --> Controller Class Initialized
DEBUG - 2020-08-27 21:48:13 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 21:48:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-27 21:48:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-27 21:48:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 21:48:13 --> Final output sent to browser
DEBUG - 2020-08-27 21:48:13 --> Total execution time: 0.0532
INFO - 2020-08-27 22:29:26 --> Config Class Initialized
INFO - 2020-08-27 22:29:26 --> Hooks Class Initialized
DEBUG - 2020-08-27 22:29:26 --> UTF-8 Support Enabled
INFO - 2020-08-27 22:29:26 --> Utf8 Class Initialized
INFO - 2020-08-27 22:29:26 --> URI Class Initialized
INFO - 2020-08-27 22:29:26 --> Router Class Initialized
INFO - 2020-08-27 22:29:26 --> Output Class Initialized
INFO - 2020-08-27 22:29:26 --> Security Class Initialized
DEBUG - 2020-08-27 22:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 22:29:26 --> Input Class Initialized
INFO - 2020-08-27 22:29:26 --> Language Class Initialized
INFO - 2020-08-27 22:29:26 --> Language Class Initialized
INFO - 2020-08-27 22:29:26 --> Config Class Initialized
INFO - 2020-08-27 22:29:26 --> Loader Class Initialized
INFO - 2020-08-27 22:29:26 --> Helper loaded: url_helper
INFO - 2020-08-27 22:29:26 --> Helper loaded: form_helper
INFO - 2020-08-27 22:29:26 --> Helper loaded: file_helper
INFO - 2020-08-27 22:29:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 22:29:26 --> Database Driver Class Initialized
DEBUG - 2020-08-27 22:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 22:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 22:29:26 --> Upload Class Initialized
INFO - 2020-08-27 22:29:26 --> Controller Class Initialized
ERROR - 2020-08-27 22:29:26 --> 404 Page Not Found: /index
INFO - 2020-08-27 22:29:30 --> Config Class Initialized
INFO - 2020-08-27 22:29:30 --> Hooks Class Initialized
DEBUG - 2020-08-27 22:29:30 --> UTF-8 Support Enabled
INFO - 2020-08-27 22:29:30 --> Utf8 Class Initialized
INFO - 2020-08-27 22:29:30 --> URI Class Initialized
INFO - 2020-08-27 22:29:30 --> Router Class Initialized
INFO - 2020-08-27 22:29:30 --> Output Class Initialized
INFO - 2020-08-27 22:29:30 --> Security Class Initialized
DEBUG - 2020-08-27 22:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 22:29:30 --> Input Class Initialized
INFO - 2020-08-27 22:29:30 --> Language Class Initialized
INFO - 2020-08-27 22:29:30 --> Language Class Initialized
INFO - 2020-08-27 22:29:30 --> Config Class Initialized
INFO - 2020-08-27 22:29:30 --> Loader Class Initialized
INFO - 2020-08-27 22:29:30 --> Helper loaded: url_helper
INFO - 2020-08-27 22:29:30 --> Helper loaded: form_helper
INFO - 2020-08-27 22:29:30 --> Helper loaded: file_helper
INFO - 2020-08-27 22:29:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 22:29:30 --> Database Driver Class Initialized
DEBUG - 2020-08-27 22:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 22:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 22:29:30 --> Upload Class Initialized
INFO - 2020-08-27 22:29:30 --> Controller Class Initialized
DEBUG - 2020-08-27 22:29:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-27 22:29:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-27 22:29:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-27 22:29:30 --> Final output sent to browser
DEBUG - 2020-08-27 22:29:30 --> Total execution time: 0.0589
INFO - 2020-08-27 22:36:01 --> Config Class Initialized
INFO - 2020-08-27 22:36:01 --> Hooks Class Initialized
DEBUG - 2020-08-27 22:36:01 --> UTF-8 Support Enabled
INFO - 2020-08-27 22:36:01 --> Utf8 Class Initialized
INFO - 2020-08-27 22:36:01 --> URI Class Initialized
INFO - 2020-08-27 22:36:01 --> Router Class Initialized
INFO - 2020-08-27 22:36:01 --> Output Class Initialized
INFO - 2020-08-27 22:36:01 --> Security Class Initialized
DEBUG - 2020-08-27 22:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 22:36:01 --> Input Class Initialized
INFO - 2020-08-27 22:36:01 --> Language Class Initialized
INFO - 2020-08-27 22:36:01 --> Language Class Initialized
INFO - 2020-08-27 22:36:01 --> Config Class Initialized
INFO - 2020-08-27 22:36:01 --> Loader Class Initialized
INFO - 2020-08-27 22:36:01 --> Helper loaded: url_helper
INFO - 2020-08-27 22:36:01 --> Helper loaded: form_helper
INFO - 2020-08-27 22:36:01 --> Helper loaded: file_helper
INFO - 2020-08-27 22:36:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 22:36:01 --> Database Driver Class Initialized
DEBUG - 2020-08-27 22:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 22:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 22:36:01 --> Upload Class Initialized
INFO - 2020-08-27 22:36:01 --> Controller Class Initialized
ERROR - 2020-08-27 22:36:01 --> 404 Page Not Found: /index
INFO - 2020-08-27 23:06:54 --> Config Class Initialized
INFO - 2020-08-27 23:06:54 --> Hooks Class Initialized
DEBUG - 2020-08-27 23:06:54 --> UTF-8 Support Enabled
INFO - 2020-08-27 23:06:54 --> Utf8 Class Initialized
INFO - 2020-08-27 23:06:54 --> URI Class Initialized
INFO - 2020-08-27 23:06:54 --> Router Class Initialized
INFO - 2020-08-27 23:06:54 --> Output Class Initialized
INFO - 2020-08-27 23:06:54 --> Security Class Initialized
DEBUG - 2020-08-27 23:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 23:06:54 --> Input Class Initialized
INFO - 2020-08-27 23:06:54 --> Language Class Initialized
INFO - 2020-08-27 23:06:54 --> Language Class Initialized
INFO - 2020-08-27 23:06:54 --> Config Class Initialized
INFO - 2020-08-27 23:06:54 --> Loader Class Initialized
INFO - 2020-08-27 23:06:54 --> Helper loaded: url_helper
INFO - 2020-08-27 23:06:54 --> Helper loaded: form_helper
INFO - 2020-08-27 23:06:54 --> Helper loaded: file_helper
INFO - 2020-08-27 23:06:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-27 23:06:54 --> Database Driver Class Initialized
DEBUG - 2020-08-27 23:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-27 23:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 23:06:54 --> Upload Class Initialized
INFO - 2020-08-27 23:06:54 --> Controller Class Initialized
ERROR - 2020-08-27 23:06:54 --> 404 Page Not Found: /index
