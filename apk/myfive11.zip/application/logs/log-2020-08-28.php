<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-28 01:31:04 --> Config Class Initialized
INFO - 2020-08-28 01:31:04 --> Hooks Class Initialized
DEBUG - 2020-08-28 01:31:04 --> UTF-8 Support Enabled
INFO - 2020-08-28 01:31:04 --> Utf8 Class Initialized
INFO - 2020-08-28 01:31:04 --> URI Class Initialized
INFO - 2020-08-28 01:31:04 --> Router Class Initialized
INFO - 2020-08-28 01:31:04 --> Output Class Initialized
INFO - 2020-08-28 01:31:04 --> Security Class Initialized
DEBUG - 2020-08-28 01:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 01:31:04 --> Input Class Initialized
INFO - 2020-08-28 01:31:04 --> Language Class Initialized
INFO - 2020-08-28 01:31:04 --> Language Class Initialized
INFO - 2020-08-28 01:31:04 --> Config Class Initialized
INFO - 2020-08-28 01:31:04 --> Loader Class Initialized
INFO - 2020-08-28 01:31:04 --> Helper loaded: url_helper
INFO - 2020-08-28 01:31:04 --> Helper loaded: form_helper
INFO - 2020-08-28 01:31:04 --> Helper loaded: file_helper
INFO - 2020-08-28 01:31:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 01:31:04 --> Database Driver Class Initialized
DEBUG - 2020-08-28 01:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 01:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 01:31:04 --> Upload Class Initialized
INFO - 2020-08-28 01:31:04 --> Controller Class Initialized
ERROR - 2020-08-28 01:31:04 --> 404 Page Not Found: /index
INFO - 2020-08-28 01:31:07 --> Config Class Initialized
INFO - 2020-08-28 01:31:07 --> Hooks Class Initialized
DEBUG - 2020-08-28 01:31:07 --> UTF-8 Support Enabled
INFO - 2020-08-28 01:31:07 --> Utf8 Class Initialized
INFO - 2020-08-28 01:31:07 --> URI Class Initialized
INFO - 2020-08-28 01:31:07 --> Router Class Initialized
INFO - 2020-08-28 01:31:07 --> Output Class Initialized
INFO - 2020-08-28 01:31:07 --> Security Class Initialized
DEBUG - 2020-08-28 01:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 01:31:07 --> Input Class Initialized
INFO - 2020-08-28 01:31:07 --> Language Class Initialized
INFO - 2020-08-28 01:31:07 --> Language Class Initialized
INFO - 2020-08-28 01:31:07 --> Config Class Initialized
INFO - 2020-08-28 01:31:07 --> Loader Class Initialized
INFO - 2020-08-28 01:31:07 --> Helper loaded: url_helper
INFO - 2020-08-28 01:31:07 --> Helper loaded: form_helper
INFO - 2020-08-28 01:31:07 --> Helper loaded: file_helper
INFO - 2020-08-28 01:31:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 01:31:07 --> Database Driver Class Initialized
DEBUG - 2020-08-28 01:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 01:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 01:31:07 --> Upload Class Initialized
INFO - 2020-08-28 01:31:07 --> Controller Class Initialized
DEBUG - 2020-08-28 01:31:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 01:31:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-28 01:31:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 01:31:07 --> Final output sent to browser
DEBUG - 2020-08-28 01:31:07 --> Total execution time: 0.0671
INFO - 2020-08-28 01:41:53 --> Config Class Initialized
INFO - 2020-08-28 01:41:53 --> Hooks Class Initialized
DEBUG - 2020-08-28 01:41:53 --> UTF-8 Support Enabled
INFO - 2020-08-28 01:41:53 --> Utf8 Class Initialized
INFO - 2020-08-28 01:41:53 --> URI Class Initialized
DEBUG - 2020-08-28 01:41:53 --> No URI present. Default controller set.
INFO - 2020-08-28 01:41:53 --> Router Class Initialized
INFO - 2020-08-28 01:41:53 --> Output Class Initialized
INFO - 2020-08-28 01:41:53 --> Security Class Initialized
DEBUG - 2020-08-28 01:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 01:41:53 --> Input Class Initialized
INFO - 2020-08-28 01:41:53 --> Language Class Initialized
INFO - 2020-08-28 01:41:53 --> Language Class Initialized
INFO - 2020-08-28 01:41:53 --> Config Class Initialized
INFO - 2020-08-28 01:41:53 --> Loader Class Initialized
INFO - 2020-08-28 01:41:53 --> Helper loaded: url_helper
INFO - 2020-08-28 01:41:53 --> Helper loaded: form_helper
INFO - 2020-08-28 01:41:53 --> Helper loaded: file_helper
INFO - 2020-08-28 01:41:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 01:41:53 --> Database Driver Class Initialized
DEBUG - 2020-08-28 01:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 01:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 01:41:53 --> Upload Class Initialized
INFO - 2020-08-28 01:41:53 --> Controller Class Initialized
DEBUG - 2020-08-28 01:41:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 01:41:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 01:41:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 01:41:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 01:41:53 --> Final output sent to browser
DEBUG - 2020-08-28 01:41:53 --> Total execution time: 0.0528
INFO - 2020-08-28 01:41:53 --> Config Class Initialized
INFO - 2020-08-28 01:41:53 --> Hooks Class Initialized
DEBUG - 2020-08-28 01:41:53 --> UTF-8 Support Enabled
INFO - 2020-08-28 01:41:53 --> Utf8 Class Initialized
INFO - 2020-08-28 01:41:53 --> URI Class Initialized
DEBUG - 2020-08-28 01:41:53 --> No URI present. Default controller set.
INFO - 2020-08-28 01:41:53 --> Router Class Initialized
INFO - 2020-08-28 01:41:53 --> Output Class Initialized
INFO - 2020-08-28 01:41:53 --> Security Class Initialized
DEBUG - 2020-08-28 01:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 01:41:53 --> Input Class Initialized
INFO - 2020-08-28 01:41:53 --> Language Class Initialized
INFO - 2020-08-28 01:41:53 --> Language Class Initialized
INFO - 2020-08-28 01:41:53 --> Config Class Initialized
INFO - 2020-08-28 01:41:53 --> Loader Class Initialized
INFO - 2020-08-28 01:41:53 --> Helper loaded: url_helper
INFO - 2020-08-28 01:41:53 --> Helper loaded: form_helper
INFO - 2020-08-28 01:41:53 --> Helper loaded: file_helper
INFO - 2020-08-28 01:41:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 01:41:53 --> Database Driver Class Initialized
DEBUG - 2020-08-28 01:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 01:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 01:41:53 --> Upload Class Initialized
INFO - 2020-08-28 01:41:53 --> Controller Class Initialized
DEBUG - 2020-08-28 01:41:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 01:41:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 01:41:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 01:41:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 01:41:53 --> Final output sent to browser
DEBUG - 2020-08-28 01:41:53 --> Total execution time: 0.0505
INFO - 2020-08-28 04:03:27 --> Config Class Initialized
INFO - 2020-08-28 04:03:27 --> Hooks Class Initialized
DEBUG - 2020-08-28 04:03:27 --> UTF-8 Support Enabled
INFO - 2020-08-28 04:03:27 --> Utf8 Class Initialized
INFO - 2020-08-28 04:03:27 --> URI Class Initialized
INFO - 2020-08-28 04:03:27 --> Router Class Initialized
INFO - 2020-08-28 04:03:27 --> Output Class Initialized
INFO - 2020-08-28 04:03:27 --> Security Class Initialized
DEBUG - 2020-08-28 04:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 04:03:27 --> Input Class Initialized
INFO - 2020-08-28 04:03:27 --> Language Class Initialized
INFO - 2020-08-28 04:03:27 --> Language Class Initialized
INFO - 2020-08-28 04:03:27 --> Config Class Initialized
INFO - 2020-08-28 04:03:27 --> Loader Class Initialized
INFO - 2020-08-28 04:03:27 --> Helper loaded: url_helper
INFO - 2020-08-28 04:03:27 --> Helper loaded: form_helper
INFO - 2020-08-28 04:03:27 --> Helper loaded: file_helper
INFO - 2020-08-28 04:03:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 04:03:27 --> Database Driver Class Initialized
DEBUG - 2020-08-28 04:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 04:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 04:03:27 --> Upload Class Initialized
INFO - 2020-08-28 04:03:28 --> Controller Class Initialized
ERROR - 2020-08-28 04:03:28 --> 404 Page Not Found: /index
INFO - 2020-08-28 06:00:16 --> Config Class Initialized
INFO - 2020-08-28 06:00:16 --> Hooks Class Initialized
DEBUG - 2020-08-28 06:00:16 --> UTF-8 Support Enabled
INFO - 2020-08-28 06:00:16 --> Utf8 Class Initialized
INFO - 2020-08-28 06:00:16 --> URI Class Initialized
DEBUG - 2020-08-28 06:00:16 --> No URI present. Default controller set.
INFO - 2020-08-28 06:00:16 --> Router Class Initialized
INFO - 2020-08-28 06:00:16 --> Output Class Initialized
INFO - 2020-08-28 06:00:16 --> Security Class Initialized
DEBUG - 2020-08-28 06:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 06:00:16 --> Input Class Initialized
INFO - 2020-08-28 06:00:16 --> Language Class Initialized
INFO - 2020-08-28 06:00:16 --> Language Class Initialized
INFO - 2020-08-28 06:00:16 --> Config Class Initialized
INFO - 2020-08-28 06:00:16 --> Loader Class Initialized
INFO - 2020-08-28 06:00:16 --> Helper loaded: url_helper
INFO - 2020-08-28 06:00:16 --> Helper loaded: form_helper
INFO - 2020-08-28 06:00:16 --> Helper loaded: file_helper
INFO - 2020-08-28 06:00:16 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 06:00:16 --> Database Driver Class Initialized
DEBUG - 2020-08-28 06:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 06:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 06:00:16 --> Upload Class Initialized
INFO - 2020-08-28 06:00:16 --> Controller Class Initialized
DEBUG - 2020-08-28 06:00:16 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 06:00:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 06:00:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 06:00:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 06:00:16 --> Final output sent to browser
DEBUG - 2020-08-28 06:00:16 --> Total execution time: 0.0613
INFO - 2020-08-28 07:45:59 --> Config Class Initialized
INFO - 2020-08-28 07:45:59 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:45:59 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:45:59 --> Utf8 Class Initialized
INFO - 2020-08-28 07:45:59 --> URI Class Initialized
DEBUG - 2020-08-28 07:45:59 --> No URI present. Default controller set.
INFO - 2020-08-28 07:45:59 --> Router Class Initialized
INFO - 2020-08-28 07:45:59 --> Output Class Initialized
INFO - 2020-08-28 07:45:59 --> Security Class Initialized
DEBUG - 2020-08-28 07:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:45:59 --> Input Class Initialized
INFO - 2020-08-28 07:45:59 --> Language Class Initialized
INFO - 2020-08-28 07:45:59 --> Language Class Initialized
INFO - 2020-08-28 07:45:59 --> Config Class Initialized
INFO - 2020-08-28 07:45:59 --> Loader Class Initialized
INFO - 2020-08-28 07:45:59 --> Helper loaded: url_helper
INFO - 2020-08-28 07:45:59 --> Helper loaded: form_helper
INFO - 2020-08-28 07:45:59 --> Helper loaded: file_helper
INFO - 2020-08-28 07:45:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 07:45:59 --> Database Driver Class Initialized
DEBUG - 2020-08-28 07:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 07:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:45:59 --> Upload Class Initialized
INFO - 2020-08-28 07:45:59 --> Controller Class Initialized
DEBUG - 2020-08-28 07:45:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 07:45:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 07:45:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 07:45:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 07:45:59 --> Final output sent to browser
DEBUG - 2020-08-28 07:45:59 --> Total execution time: 0.0505
INFO - 2020-08-28 08:00:55 --> Config Class Initialized
INFO - 2020-08-28 08:00:55 --> Hooks Class Initialized
DEBUG - 2020-08-28 08:00:55 --> UTF-8 Support Enabled
INFO - 2020-08-28 08:00:55 --> Utf8 Class Initialized
INFO - 2020-08-28 08:00:55 --> URI Class Initialized
DEBUG - 2020-08-28 08:00:55 --> No URI present. Default controller set.
INFO - 2020-08-28 08:00:55 --> Router Class Initialized
INFO - 2020-08-28 08:00:55 --> Output Class Initialized
INFO - 2020-08-28 08:00:55 --> Security Class Initialized
DEBUG - 2020-08-28 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 08:00:55 --> Input Class Initialized
INFO - 2020-08-28 08:00:55 --> Language Class Initialized
INFO - 2020-08-28 08:00:55 --> Language Class Initialized
INFO - 2020-08-28 08:00:55 --> Config Class Initialized
INFO - 2020-08-28 08:00:55 --> Loader Class Initialized
INFO - 2020-08-28 08:00:55 --> Helper loaded: url_helper
INFO - 2020-08-28 08:00:55 --> Helper loaded: form_helper
INFO - 2020-08-28 08:00:55 --> Helper loaded: file_helper
INFO - 2020-08-28 08:00:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 08:00:55 --> Database Driver Class Initialized
DEBUG - 2020-08-28 08:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 08:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 08:00:55 --> Upload Class Initialized
INFO - 2020-08-28 08:00:55 --> Controller Class Initialized
DEBUG - 2020-08-28 08:00:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 08:00:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 08:00:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 08:00:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 08:00:55 --> Final output sent to browser
DEBUG - 2020-08-28 08:00:55 --> Total execution time: 0.0524
INFO - 2020-08-28 08:00:57 --> Config Class Initialized
INFO - 2020-08-28 08:00:57 --> Hooks Class Initialized
DEBUG - 2020-08-28 08:00:57 --> UTF-8 Support Enabled
INFO - 2020-08-28 08:00:57 --> Utf8 Class Initialized
INFO - 2020-08-28 08:00:57 --> URI Class Initialized
INFO - 2020-08-28 08:00:57 --> Router Class Initialized
INFO - 2020-08-28 08:00:57 --> Output Class Initialized
INFO - 2020-08-28 08:00:57 --> Security Class Initialized
DEBUG - 2020-08-28 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 08:00:57 --> Input Class Initialized
INFO - 2020-08-28 08:00:57 --> Language Class Initialized
INFO - 2020-08-28 08:00:57 --> Language Class Initialized
INFO - 2020-08-28 08:00:57 --> Config Class Initialized
INFO - 2020-08-28 08:00:57 --> Loader Class Initialized
INFO - 2020-08-28 08:00:57 --> Helper loaded: url_helper
INFO - 2020-08-28 08:00:57 --> Helper loaded: form_helper
INFO - 2020-08-28 08:00:57 --> Helper loaded: file_helper
INFO - 2020-08-28 08:00:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 08:00:57 --> Database Driver Class Initialized
DEBUG - 2020-08-28 08:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 08:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 08:00:57 --> Upload Class Initialized
INFO - 2020-08-28 08:00:57 --> Controller Class Initialized
ERROR - 2020-08-28 08:00:57 --> 404 Page Not Found: /index
INFO - 2020-08-28 08:00:58 --> Config Class Initialized
INFO - 2020-08-28 08:00:58 --> Hooks Class Initialized
DEBUG - 2020-08-28 08:00:58 --> UTF-8 Support Enabled
INFO - 2020-08-28 08:00:58 --> Utf8 Class Initialized
INFO - 2020-08-28 08:00:58 --> URI Class Initialized
DEBUG - 2020-08-28 08:00:58 --> No URI present. Default controller set.
INFO - 2020-08-28 08:00:58 --> Router Class Initialized
INFO - 2020-08-28 08:00:58 --> Output Class Initialized
INFO - 2020-08-28 08:00:58 --> Security Class Initialized
DEBUG - 2020-08-28 08:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 08:00:58 --> Input Class Initialized
INFO - 2020-08-28 08:00:58 --> Language Class Initialized
INFO - 2020-08-28 08:00:58 --> Language Class Initialized
INFO - 2020-08-28 08:00:58 --> Config Class Initialized
INFO - 2020-08-28 08:00:58 --> Loader Class Initialized
INFO - 2020-08-28 08:00:58 --> Helper loaded: url_helper
INFO - 2020-08-28 08:00:58 --> Helper loaded: form_helper
INFO - 2020-08-28 08:00:58 --> Helper loaded: file_helper
INFO - 2020-08-28 08:00:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 08:00:58 --> Database Driver Class Initialized
DEBUG - 2020-08-28 08:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 08:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 08:00:58 --> Upload Class Initialized
INFO - 2020-08-28 08:00:58 --> Controller Class Initialized
DEBUG - 2020-08-28 08:00:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 08:00:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 08:00:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 08:00:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 08:00:58 --> Final output sent to browser
DEBUG - 2020-08-28 08:00:58 --> Total execution time: 0.0494
INFO - 2020-08-28 08:09:07 --> Config Class Initialized
INFO - 2020-08-28 08:09:07 --> Hooks Class Initialized
DEBUG - 2020-08-28 08:09:07 --> UTF-8 Support Enabled
INFO - 2020-08-28 08:09:07 --> Utf8 Class Initialized
INFO - 2020-08-28 08:09:07 --> URI Class Initialized
INFO - 2020-08-28 08:09:07 --> Router Class Initialized
INFO - 2020-08-28 08:09:07 --> Output Class Initialized
INFO - 2020-08-28 08:09:07 --> Security Class Initialized
DEBUG - 2020-08-28 08:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 08:09:07 --> Input Class Initialized
INFO - 2020-08-28 08:09:07 --> Language Class Initialized
INFO - 2020-08-28 08:09:07 --> Language Class Initialized
INFO - 2020-08-28 08:09:07 --> Config Class Initialized
INFO - 2020-08-28 08:09:07 --> Loader Class Initialized
INFO - 2020-08-28 08:09:07 --> Helper loaded: url_helper
INFO - 2020-08-28 08:09:07 --> Helper loaded: form_helper
INFO - 2020-08-28 08:09:07 --> Helper loaded: file_helper
INFO - 2020-08-28 08:09:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 08:09:07 --> Database Driver Class Initialized
DEBUG - 2020-08-28 08:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 08:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 08:09:07 --> Upload Class Initialized
INFO - 2020-08-28 08:09:07 --> Controller Class Initialized
ERROR - 2020-08-28 08:09:07 --> 404 Page Not Found: /index
INFO - 2020-08-28 09:24:32 --> Config Class Initialized
INFO - 2020-08-28 09:24:32 --> Hooks Class Initialized
DEBUG - 2020-08-28 09:24:32 --> UTF-8 Support Enabled
INFO - 2020-08-28 09:24:32 --> Utf8 Class Initialized
INFO - 2020-08-28 09:24:32 --> URI Class Initialized
INFO - 2020-08-28 09:24:32 --> Router Class Initialized
INFO - 2020-08-28 09:24:32 --> Output Class Initialized
INFO - 2020-08-28 09:24:32 --> Security Class Initialized
DEBUG - 2020-08-28 09:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 09:24:32 --> Input Class Initialized
INFO - 2020-08-28 09:24:32 --> Language Class Initialized
INFO - 2020-08-28 09:24:32 --> Language Class Initialized
INFO - 2020-08-28 09:24:32 --> Config Class Initialized
INFO - 2020-08-28 09:24:32 --> Loader Class Initialized
INFO - 2020-08-28 09:24:32 --> Helper loaded: url_helper
INFO - 2020-08-28 09:24:32 --> Helper loaded: form_helper
INFO - 2020-08-28 09:24:32 --> Helper loaded: file_helper
INFO - 2020-08-28 09:24:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 09:24:32 --> Database Driver Class Initialized
DEBUG - 2020-08-28 09:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 09:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 09:24:32 --> Upload Class Initialized
INFO - 2020-08-28 09:24:32 --> Controller Class Initialized
ERROR - 2020-08-28 09:24:32 --> 404 Page Not Found: /index
INFO - 2020-08-28 09:43:15 --> Config Class Initialized
INFO - 2020-08-28 09:43:15 --> Hooks Class Initialized
DEBUG - 2020-08-28 09:43:15 --> UTF-8 Support Enabled
INFO - 2020-08-28 09:43:15 --> Utf8 Class Initialized
INFO - 2020-08-28 09:43:15 --> URI Class Initialized
DEBUG - 2020-08-28 09:43:15 --> No URI present. Default controller set.
INFO - 2020-08-28 09:43:15 --> Router Class Initialized
INFO - 2020-08-28 09:43:15 --> Output Class Initialized
INFO - 2020-08-28 09:43:15 --> Security Class Initialized
DEBUG - 2020-08-28 09:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 09:43:15 --> Input Class Initialized
INFO - 2020-08-28 09:43:15 --> Language Class Initialized
INFO - 2020-08-28 09:43:15 --> Language Class Initialized
INFO - 2020-08-28 09:43:15 --> Config Class Initialized
INFO - 2020-08-28 09:43:15 --> Loader Class Initialized
INFO - 2020-08-28 09:43:15 --> Helper loaded: url_helper
INFO - 2020-08-28 09:43:15 --> Helper loaded: form_helper
INFO - 2020-08-28 09:43:15 --> Helper loaded: file_helper
INFO - 2020-08-28 09:43:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 09:43:15 --> Database Driver Class Initialized
DEBUG - 2020-08-28 09:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 09:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 09:43:15 --> Upload Class Initialized
INFO - 2020-08-28 09:43:15 --> Controller Class Initialized
DEBUG - 2020-08-28 09:43:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 09:43:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 09:43:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 09:43:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 09:43:16 --> Final output sent to browser
DEBUG - 2020-08-28 09:43:16 --> Total execution time: 0.0791
INFO - 2020-08-28 09:59:47 --> Config Class Initialized
INFO - 2020-08-28 09:59:47 --> Hooks Class Initialized
DEBUG - 2020-08-28 09:59:47 --> UTF-8 Support Enabled
INFO - 2020-08-28 09:59:47 --> Utf8 Class Initialized
INFO - 2020-08-28 09:59:47 --> URI Class Initialized
DEBUG - 2020-08-28 09:59:47 --> No URI present. Default controller set.
INFO - 2020-08-28 09:59:47 --> Router Class Initialized
INFO - 2020-08-28 09:59:47 --> Output Class Initialized
INFO - 2020-08-28 09:59:47 --> Security Class Initialized
DEBUG - 2020-08-28 09:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 09:59:47 --> Input Class Initialized
INFO - 2020-08-28 09:59:47 --> Language Class Initialized
INFO - 2020-08-28 09:59:47 --> Language Class Initialized
INFO - 2020-08-28 09:59:47 --> Config Class Initialized
INFO - 2020-08-28 09:59:47 --> Loader Class Initialized
INFO - 2020-08-28 09:59:47 --> Helper loaded: url_helper
INFO - 2020-08-28 09:59:47 --> Helper loaded: form_helper
INFO - 2020-08-28 09:59:47 --> Helper loaded: file_helper
INFO - 2020-08-28 09:59:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 09:59:47 --> Database Driver Class Initialized
DEBUG - 2020-08-28 09:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 09:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 09:59:47 --> Upload Class Initialized
INFO - 2020-08-28 09:59:47 --> Controller Class Initialized
DEBUG - 2020-08-28 09:59:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 09:59:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 09:59:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 09:59:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 09:59:47 --> Final output sent to browser
DEBUG - 2020-08-28 09:59:47 --> Total execution time: 0.0544
INFO - 2020-08-28 10:45:07 --> Config Class Initialized
INFO - 2020-08-28 10:45:07 --> Hooks Class Initialized
DEBUG - 2020-08-28 10:45:07 --> UTF-8 Support Enabled
INFO - 2020-08-28 10:45:07 --> Utf8 Class Initialized
INFO - 2020-08-28 10:45:07 --> URI Class Initialized
DEBUG - 2020-08-28 10:45:07 --> No URI present. Default controller set.
INFO - 2020-08-28 10:45:07 --> Router Class Initialized
INFO - 2020-08-28 10:45:07 --> Output Class Initialized
INFO - 2020-08-28 10:45:07 --> Security Class Initialized
DEBUG - 2020-08-28 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 10:45:07 --> Input Class Initialized
INFO - 2020-08-28 10:45:07 --> Language Class Initialized
INFO - 2020-08-28 10:45:07 --> Language Class Initialized
INFO - 2020-08-28 10:45:07 --> Config Class Initialized
INFO - 2020-08-28 10:45:07 --> Loader Class Initialized
INFO - 2020-08-28 10:45:07 --> Helper loaded: url_helper
INFO - 2020-08-28 10:45:07 --> Helper loaded: form_helper
INFO - 2020-08-28 10:45:07 --> Helper loaded: file_helper
INFO - 2020-08-28 10:45:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 10:45:07 --> Database Driver Class Initialized
DEBUG - 2020-08-28 10:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 10:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 10:45:07 --> Upload Class Initialized
INFO - 2020-08-28 10:45:07 --> Controller Class Initialized
DEBUG - 2020-08-28 10:45:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 10:45:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 10:45:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 10:45:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 10:45:07 --> Final output sent to browser
DEBUG - 2020-08-28 10:45:07 --> Total execution time: 0.0860
INFO - 2020-08-28 10:45:13 --> Config Class Initialized
INFO - 2020-08-28 10:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-28 10:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-28 10:45:13 --> Utf8 Class Initialized
INFO - 2020-08-28 10:45:13 --> URI Class Initialized
INFO - 2020-08-28 10:45:13 --> Router Class Initialized
INFO - 2020-08-28 10:45:13 --> Output Class Initialized
INFO - 2020-08-28 10:45:13 --> Security Class Initialized
DEBUG - 2020-08-28 10:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 10:45:13 --> Input Class Initialized
INFO - 2020-08-28 10:45:13 --> Language Class Initialized
INFO - 2020-08-28 10:45:13 --> Language Class Initialized
INFO - 2020-08-28 10:45:13 --> Config Class Initialized
INFO - 2020-08-28 10:45:13 --> Loader Class Initialized
INFO - 2020-08-28 10:45:13 --> Helper loaded: url_helper
INFO - 2020-08-28 10:45:13 --> Helper loaded: form_helper
INFO - 2020-08-28 10:45:13 --> Helper loaded: file_helper
INFO - 2020-08-28 10:45:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 10:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-28 10:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 10:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 10:45:13 --> Upload Class Initialized
INFO - 2020-08-28 10:45:13 --> Controller Class Initialized
ERROR - 2020-08-28 10:45:13 --> 404 Page Not Found: /index
INFO - 2020-08-28 10:52:11 --> Config Class Initialized
INFO - 2020-08-28 10:52:11 --> Hooks Class Initialized
DEBUG - 2020-08-28 10:52:11 --> UTF-8 Support Enabled
INFO - 2020-08-28 10:52:11 --> Utf8 Class Initialized
INFO - 2020-08-28 10:52:11 --> URI Class Initialized
INFO - 2020-08-28 10:52:11 --> Router Class Initialized
INFO - 2020-08-28 10:52:11 --> Output Class Initialized
INFO - 2020-08-28 10:52:11 --> Security Class Initialized
DEBUG - 2020-08-28 10:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 10:52:11 --> Input Class Initialized
INFO - 2020-08-28 10:52:11 --> Language Class Initialized
INFO - 2020-08-28 10:52:11 --> Language Class Initialized
INFO - 2020-08-28 10:52:11 --> Config Class Initialized
INFO - 2020-08-28 10:52:11 --> Loader Class Initialized
INFO - 2020-08-28 10:52:11 --> Helper loaded: url_helper
INFO - 2020-08-28 10:52:11 --> Helper loaded: form_helper
INFO - 2020-08-28 10:52:11 --> Helper loaded: file_helper
INFO - 2020-08-28 10:52:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 10:52:11 --> Database Driver Class Initialized
DEBUG - 2020-08-28 10:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 10:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 10:52:11 --> Upload Class Initialized
INFO - 2020-08-28 10:52:11 --> Controller Class Initialized
ERROR - 2020-08-28 10:52:11 --> 404 Page Not Found: /index
INFO - 2020-08-28 10:52:11 --> Config Class Initialized
INFO - 2020-08-28 10:52:11 --> Hooks Class Initialized
DEBUG - 2020-08-28 10:52:11 --> UTF-8 Support Enabled
INFO - 2020-08-28 10:52:11 --> Utf8 Class Initialized
INFO - 2020-08-28 10:52:11 --> URI Class Initialized
INFO - 2020-08-28 10:52:11 --> Router Class Initialized
INFO - 2020-08-28 10:52:11 --> Output Class Initialized
INFO - 2020-08-28 10:52:11 --> Security Class Initialized
DEBUG - 2020-08-28 10:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 10:52:11 --> Input Class Initialized
INFO - 2020-08-28 10:52:11 --> Language Class Initialized
INFO - 2020-08-28 10:52:11 --> Language Class Initialized
INFO - 2020-08-28 10:52:11 --> Config Class Initialized
INFO - 2020-08-28 10:52:11 --> Loader Class Initialized
INFO - 2020-08-28 10:52:11 --> Helper loaded: url_helper
INFO - 2020-08-28 10:52:11 --> Helper loaded: form_helper
INFO - 2020-08-28 10:52:11 --> Helper loaded: file_helper
INFO - 2020-08-28 10:52:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 10:52:11 --> Database Driver Class Initialized
DEBUG - 2020-08-28 10:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 10:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 10:52:11 --> Upload Class Initialized
INFO - 2020-08-28 10:52:11 --> Controller Class Initialized
DEBUG - 2020-08-28 10:52:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 10:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-28 10:52:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 10:52:11 --> Final output sent to browser
DEBUG - 2020-08-28 10:52:11 --> Total execution time: 0.0508
INFO - 2020-08-28 11:40:40 --> Config Class Initialized
INFO - 2020-08-28 11:40:40 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:40:40 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:40:40 --> Utf8 Class Initialized
INFO - 2020-08-28 11:40:40 --> URI Class Initialized
DEBUG - 2020-08-28 11:40:40 --> No URI present. Default controller set.
INFO - 2020-08-28 11:40:40 --> Router Class Initialized
INFO - 2020-08-28 11:40:40 --> Output Class Initialized
INFO - 2020-08-28 11:40:40 --> Security Class Initialized
DEBUG - 2020-08-28 11:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:40:40 --> Input Class Initialized
INFO - 2020-08-28 11:40:40 --> Language Class Initialized
INFO - 2020-08-28 11:40:40 --> Language Class Initialized
INFO - 2020-08-28 11:40:40 --> Config Class Initialized
INFO - 2020-08-28 11:40:40 --> Loader Class Initialized
INFO - 2020-08-28 11:40:40 --> Helper loaded: url_helper
INFO - 2020-08-28 11:40:40 --> Helper loaded: form_helper
INFO - 2020-08-28 11:40:40 --> Helper loaded: file_helper
INFO - 2020-08-28 11:40:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:40:40 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:40:40 --> Upload Class Initialized
INFO - 2020-08-28 11:40:40 --> Controller Class Initialized
DEBUG - 2020-08-28 11:40:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:40:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:40:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:40:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:40:40 --> Final output sent to browser
DEBUG - 2020-08-28 11:40:40 --> Total execution time: 0.0539
INFO - 2020-08-28 11:45:29 --> Config Class Initialized
INFO - 2020-08-28 11:45:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:29 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:29 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:29 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:29 --> Router Class Initialized
INFO - 2020-08-28 11:45:29 --> Output Class Initialized
INFO - 2020-08-28 11:45:29 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:29 --> Input Class Initialized
INFO - 2020-08-28 11:45:29 --> Language Class Initialized
INFO - 2020-08-28 11:45:29 --> Language Class Initialized
INFO - 2020-08-28 11:45:29 --> Config Class Initialized
INFO - 2020-08-28 11:45:29 --> Loader Class Initialized
INFO - 2020-08-28 11:45:29 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:29 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:29 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:29 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:29 --> Upload Class Initialized
INFO - 2020-08-28 11:45:29 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:29 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:29 --> Total execution time: 0.0514
INFO - 2020-08-28 11:45:29 --> Config Class Initialized
INFO - 2020-08-28 11:45:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:29 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:29 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:29 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:29 --> Router Class Initialized
INFO - 2020-08-28 11:45:29 --> Output Class Initialized
INFO - 2020-08-28 11:45:29 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:29 --> Input Class Initialized
INFO - 2020-08-28 11:45:29 --> Language Class Initialized
INFO - 2020-08-28 11:45:29 --> Language Class Initialized
INFO - 2020-08-28 11:45:29 --> Config Class Initialized
INFO - 2020-08-28 11:45:29 --> Loader Class Initialized
INFO - 2020-08-28 11:45:29 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:29 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:29 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:29 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:29 --> Upload Class Initialized
INFO - 2020-08-28 11:45:29 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:29 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:29 --> Total execution time: 0.0506
INFO - 2020-08-28 11:45:30 --> Config Class Initialized
INFO - 2020-08-28 11:45:30 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:30 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:30 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:30 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:30 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:30 --> Router Class Initialized
INFO - 2020-08-28 11:45:30 --> Output Class Initialized
INFO - 2020-08-28 11:45:30 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:30 --> Input Class Initialized
INFO - 2020-08-28 11:45:30 --> Language Class Initialized
INFO - 2020-08-28 11:45:30 --> Language Class Initialized
INFO - 2020-08-28 11:45:30 --> Config Class Initialized
INFO - 2020-08-28 11:45:30 --> Loader Class Initialized
INFO - 2020-08-28 11:45:30 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:30 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:30 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:30 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:30 --> Upload Class Initialized
INFO - 2020-08-28 11:45:30 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:30 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:30 --> Total execution time: 0.0485
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.1315
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.2168
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.2505
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.2214
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.2230
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.2139
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.2070
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.1815
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.1757
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.1198
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:49 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:49 --> URI Class Initialized
DEBUG - 2020-08-28 11:45:49 --> No URI present. Default controller set.
INFO - 2020-08-28 11:45:49 --> Router Class Initialized
INFO - 2020-08-28 11:45:49 --> Output Class Initialized
INFO - 2020-08-28 11:45:49 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:49 --> Input Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Language Class Initialized
INFO - 2020-08-28 11:45:49 --> Config Class Initialized
INFO - 2020-08-28 11:45:49 --> Loader Class Initialized
INFO - 2020-08-28 11:45:49 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:49 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:49 --> Upload Class Initialized
INFO - 2020-08-28 11:45:49 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 11:45:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:49 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:49 --> Total execution time: 0.0527
INFO - 2020-08-28 11:45:52 --> Config Class Initialized
INFO - 2020-08-28 11:45:52 --> Hooks Class Initialized
DEBUG - 2020-08-28 11:45:52 --> UTF-8 Support Enabled
INFO - 2020-08-28 11:45:52 --> Utf8 Class Initialized
INFO - 2020-08-28 11:45:52 --> URI Class Initialized
INFO - 2020-08-28 11:45:52 --> Router Class Initialized
INFO - 2020-08-28 11:45:52 --> Output Class Initialized
INFO - 2020-08-28 11:45:52 --> Security Class Initialized
DEBUG - 2020-08-28 11:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 11:45:52 --> Input Class Initialized
INFO - 2020-08-28 11:45:52 --> Language Class Initialized
INFO - 2020-08-28 11:45:52 --> Language Class Initialized
INFO - 2020-08-28 11:45:52 --> Config Class Initialized
INFO - 2020-08-28 11:45:52 --> Loader Class Initialized
INFO - 2020-08-28 11:45:52 --> Helper loaded: url_helper
INFO - 2020-08-28 11:45:52 --> Helper loaded: form_helper
INFO - 2020-08-28 11:45:52 --> Helper loaded: file_helper
INFO - 2020-08-28 11:45:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 11:45:52 --> Database Driver Class Initialized
DEBUG - 2020-08-28 11:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 11:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 11:45:52 --> Upload Class Initialized
INFO - 2020-08-28 11:45:52 --> Controller Class Initialized
DEBUG - 2020-08-28 11:45:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 11:45:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-28 11:45:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 11:45:52 --> Final output sent to browser
DEBUG - 2020-08-28 11:45:52 --> Total execution time: 0.0554
INFO - 2020-08-28 13:56:37 --> Config Class Initialized
INFO - 2020-08-28 13:56:37 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:56:37 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:56:37 --> Utf8 Class Initialized
INFO - 2020-08-28 13:56:37 --> URI Class Initialized
DEBUG - 2020-08-28 13:56:37 --> No URI present. Default controller set.
INFO - 2020-08-28 13:56:37 --> Router Class Initialized
INFO - 2020-08-28 13:56:37 --> Output Class Initialized
INFO - 2020-08-28 13:56:37 --> Security Class Initialized
DEBUG - 2020-08-28 13:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:56:37 --> Input Class Initialized
INFO - 2020-08-28 13:56:37 --> Language Class Initialized
INFO - 2020-08-28 13:56:37 --> Language Class Initialized
INFO - 2020-08-28 13:56:37 --> Config Class Initialized
INFO - 2020-08-28 13:56:37 --> Loader Class Initialized
INFO - 2020-08-28 13:56:37 --> Helper loaded: url_helper
INFO - 2020-08-28 13:56:37 --> Helper loaded: form_helper
INFO - 2020-08-28 13:56:37 --> Helper loaded: file_helper
INFO - 2020-08-28 13:56:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 13:56:37 --> Database Driver Class Initialized
DEBUG - 2020-08-28 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 13:56:37 --> Upload Class Initialized
INFO - 2020-08-28 13:56:37 --> Controller Class Initialized
DEBUG - 2020-08-28 13:56:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 13:56:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 13:56:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 13:56:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 13:56:37 --> Final output sent to browser
DEBUG - 2020-08-28 13:56:37 --> Total execution time: 0.0789
INFO - 2020-08-28 13:57:27 --> Config Class Initialized
INFO - 2020-08-28 13:57:27 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:57:27 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:57:27 --> Utf8 Class Initialized
INFO - 2020-08-28 13:57:27 --> URI Class Initialized
INFO - 2020-08-28 13:57:27 --> Router Class Initialized
INFO - 2020-08-28 13:57:27 --> Output Class Initialized
INFO - 2020-08-28 13:57:27 --> Security Class Initialized
DEBUG - 2020-08-28 13:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:57:27 --> Input Class Initialized
INFO - 2020-08-28 13:57:27 --> Language Class Initialized
INFO - 2020-08-28 13:57:27 --> Language Class Initialized
INFO - 2020-08-28 13:57:27 --> Config Class Initialized
INFO - 2020-08-28 13:57:27 --> Loader Class Initialized
INFO - 2020-08-28 13:57:27 --> Helper loaded: url_helper
INFO - 2020-08-28 13:57:27 --> Helper loaded: form_helper
INFO - 2020-08-28 13:57:27 --> Helper loaded: file_helper
INFO - 2020-08-28 13:57:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 13:57:27 --> Database Driver Class Initialized
DEBUG - 2020-08-28 13:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 13:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 13:57:27 --> Upload Class Initialized
INFO - 2020-08-28 13:57:27 --> Controller Class Initialized
ERROR - 2020-08-28 13:57:27 --> 404 Page Not Found: /index
INFO - 2020-08-28 13:57:30 --> Config Class Initialized
INFO - 2020-08-28 13:57:30 --> Hooks Class Initialized
DEBUG - 2020-08-28 13:57:30 --> UTF-8 Support Enabled
INFO - 2020-08-28 13:57:30 --> Utf8 Class Initialized
INFO - 2020-08-28 13:57:30 --> URI Class Initialized
INFO - 2020-08-28 13:57:30 --> Router Class Initialized
INFO - 2020-08-28 13:57:30 --> Output Class Initialized
INFO - 2020-08-28 13:57:30 --> Security Class Initialized
DEBUG - 2020-08-28 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 13:57:30 --> Input Class Initialized
INFO - 2020-08-28 13:57:30 --> Language Class Initialized
INFO - 2020-08-28 13:57:30 --> Language Class Initialized
INFO - 2020-08-28 13:57:30 --> Config Class Initialized
INFO - 2020-08-28 13:57:30 --> Loader Class Initialized
INFO - 2020-08-28 13:57:30 --> Helper loaded: url_helper
INFO - 2020-08-28 13:57:30 --> Helper loaded: form_helper
INFO - 2020-08-28 13:57:30 --> Helper loaded: file_helper
INFO - 2020-08-28 13:57:30 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 13:57:30 --> Database Driver Class Initialized
DEBUG - 2020-08-28 13:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 13:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 13:57:30 --> Upload Class Initialized
INFO - 2020-08-28 13:57:30 --> Controller Class Initialized
DEBUG - 2020-08-28 13:57:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 13:57:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-28 13:57:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 13:57:30 --> Final output sent to browser
DEBUG - 2020-08-28 13:57:30 --> Total execution time: 0.0540
INFO - 2020-08-28 16:05:07 --> Config Class Initialized
INFO - 2020-08-28 16:05:07 --> Hooks Class Initialized
DEBUG - 2020-08-28 16:05:07 --> UTF-8 Support Enabled
INFO - 2020-08-28 16:05:07 --> Utf8 Class Initialized
INFO - 2020-08-28 16:05:07 --> URI Class Initialized
DEBUG - 2020-08-28 16:05:07 --> No URI present. Default controller set.
INFO - 2020-08-28 16:05:07 --> Router Class Initialized
INFO - 2020-08-28 16:05:07 --> Output Class Initialized
INFO - 2020-08-28 16:05:07 --> Security Class Initialized
DEBUG - 2020-08-28 16:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 16:05:07 --> Input Class Initialized
INFO - 2020-08-28 16:05:07 --> Language Class Initialized
INFO - 2020-08-28 16:05:07 --> Language Class Initialized
INFO - 2020-08-28 16:05:07 --> Config Class Initialized
INFO - 2020-08-28 16:05:07 --> Loader Class Initialized
INFO - 2020-08-28 16:05:07 --> Helper loaded: url_helper
INFO - 2020-08-28 16:05:07 --> Helper loaded: form_helper
INFO - 2020-08-28 16:05:07 --> Helper loaded: file_helper
INFO - 2020-08-28 16:05:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 16:05:07 --> Database Driver Class Initialized
DEBUG - 2020-08-28 16:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 16:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 16:05:07 --> Upload Class Initialized
INFO - 2020-08-28 16:05:07 --> Controller Class Initialized
DEBUG - 2020-08-28 16:05:07 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 16:05:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 16:05:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 16:05:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 16:05:07 --> Final output sent to browser
DEBUG - 2020-08-28 16:05:07 --> Total execution time: 0.1661
INFO - 2020-08-28 18:59:35 --> Config Class Initialized
INFO - 2020-08-28 18:59:35 --> Hooks Class Initialized
DEBUG - 2020-08-28 18:59:35 --> UTF-8 Support Enabled
INFO - 2020-08-28 18:59:35 --> Utf8 Class Initialized
INFO - 2020-08-28 18:59:35 --> URI Class Initialized
DEBUG - 2020-08-28 18:59:35 --> No URI present. Default controller set.
INFO - 2020-08-28 18:59:35 --> Router Class Initialized
INFO - 2020-08-28 18:59:35 --> Output Class Initialized
INFO - 2020-08-28 18:59:35 --> Security Class Initialized
DEBUG - 2020-08-28 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 18:59:35 --> Input Class Initialized
INFO - 2020-08-28 18:59:35 --> Language Class Initialized
INFO - 2020-08-28 18:59:35 --> Language Class Initialized
INFO - 2020-08-28 18:59:35 --> Config Class Initialized
INFO - 2020-08-28 18:59:35 --> Loader Class Initialized
INFO - 2020-08-28 18:59:35 --> Helper loaded: url_helper
INFO - 2020-08-28 18:59:35 --> Helper loaded: form_helper
INFO - 2020-08-28 18:59:35 --> Helper loaded: file_helper
INFO - 2020-08-28 18:59:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 18:59:35 --> Database Driver Class Initialized
DEBUG - 2020-08-28 18:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 18:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 18:59:35 --> Upload Class Initialized
INFO - 2020-08-28 18:59:35 --> Controller Class Initialized
DEBUG - 2020-08-28 18:59:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 18:59:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 18:59:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 18:59:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 18:59:35 --> Final output sent to browser
DEBUG - 2020-08-28 18:59:35 --> Total execution time: 0.1427
INFO - 2020-08-28 18:59:37 --> Config Class Initialized
INFO - 2020-08-28 18:59:37 --> Hooks Class Initialized
DEBUG - 2020-08-28 18:59:37 --> UTF-8 Support Enabled
INFO - 2020-08-28 18:59:37 --> Utf8 Class Initialized
INFO - 2020-08-28 18:59:37 --> URI Class Initialized
DEBUG - 2020-08-28 18:59:37 --> No URI present. Default controller set.
INFO - 2020-08-28 18:59:37 --> Router Class Initialized
INFO - 2020-08-28 18:59:37 --> Output Class Initialized
INFO - 2020-08-28 18:59:37 --> Security Class Initialized
DEBUG - 2020-08-28 18:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 18:59:37 --> Input Class Initialized
INFO - 2020-08-28 18:59:37 --> Language Class Initialized
INFO - 2020-08-28 18:59:37 --> Language Class Initialized
INFO - 2020-08-28 18:59:37 --> Config Class Initialized
INFO - 2020-08-28 18:59:37 --> Loader Class Initialized
INFO - 2020-08-28 18:59:37 --> Helper loaded: url_helper
INFO - 2020-08-28 18:59:37 --> Helper loaded: form_helper
INFO - 2020-08-28 18:59:37 --> Helper loaded: file_helper
INFO - 2020-08-28 18:59:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 18:59:37 --> Database Driver Class Initialized
DEBUG - 2020-08-28 18:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 18:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 18:59:37 --> Upload Class Initialized
INFO - 2020-08-28 18:59:37 --> Controller Class Initialized
DEBUG - 2020-08-28 18:59:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 18:59:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 18:59:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 18:59:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 18:59:37 --> Final output sent to browser
DEBUG - 2020-08-28 18:59:37 --> Total execution time: 0.0514
INFO - 2020-08-28 18:59:44 --> Config Class Initialized
INFO - 2020-08-28 18:59:44 --> Hooks Class Initialized
DEBUG - 2020-08-28 18:59:44 --> UTF-8 Support Enabled
INFO - 2020-08-28 18:59:44 --> Utf8 Class Initialized
INFO - 2020-08-28 18:59:44 --> URI Class Initialized
INFO - 2020-08-28 18:59:44 --> Router Class Initialized
INFO - 2020-08-28 18:59:44 --> Output Class Initialized
INFO - 2020-08-28 18:59:44 --> Security Class Initialized
DEBUG - 2020-08-28 18:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 18:59:44 --> Input Class Initialized
INFO - 2020-08-28 18:59:44 --> Language Class Initialized
INFO - 2020-08-28 18:59:44 --> Language Class Initialized
INFO - 2020-08-28 18:59:44 --> Config Class Initialized
INFO - 2020-08-28 18:59:44 --> Loader Class Initialized
INFO - 2020-08-28 18:59:44 --> Helper loaded: url_helper
INFO - 2020-08-28 18:59:44 --> Helper loaded: form_helper
INFO - 2020-08-28 18:59:44 --> Helper loaded: file_helper
INFO - 2020-08-28 18:59:44 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 18:59:44 --> Database Driver Class Initialized
DEBUG - 2020-08-28 18:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 18:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 18:59:44 --> Upload Class Initialized
INFO - 2020-08-28 18:59:44 --> Controller Class Initialized
ERROR - 2020-08-28 18:59:44 --> 404 Page Not Found: /index
INFO - 2020-08-28 19:00:20 --> Config Class Initialized
INFO - 2020-08-28 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:00:20 --> Utf8 Class Initialized
INFO - 2020-08-28 19:00:20 --> URI Class Initialized
INFO - 2020-08-28 19:00:20 --> Router Class Initialized
INFO - 2020-08-28 19:00:20 --> Output Class Initialized
INFO - 2020-08-28 19:00:20 --> Security Class Initialized
DEBUG - 2020-08-28 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:00:20 --> Input Class Initialized
INFO - 2020-08-28 19:00:20 --> Language Class Initialized
INFO - 2020-08-28 19:00:20 --> Language Class Initialized
INFO - 2020-08-28 19:00:20 --> Config Class Initialized
INFO - 2020-08-28 19:00:20 --> Loader Class Initialized
INFO - 2020-08-28 19:00:20 --> Helper loaded: url_helper
INFO - 2020-08-28 19:00:20 --> Helper loaded: form_helper
INFO - 2020-08-28 19:00:20 --> Helper loaded: file_helper
INFO - 2020-08-28 19:00:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:00:20 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:00:20 --> Upload Class Initialized
INFO - 2020-08-28 19:00:20 --> Controller Class Initialized
ERROR - 2020-08-28 19:00:20 --> 404 Page Not Found: /index
INFO - 2020-08-28 19:00:20 --> Config Class Initialized
INFO - 2020-08-28 19:00:20 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:00:20 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:00:20 --> Utf8 Class Initialized
INFO - 2020-08-28 19:00:20 --> URI Class Initialized
INFO - 2020-08-28 19:00:20 --> Router Class Initialized
INFO - 2020-08-28 19:00:20 --> Output Class Initialized
INFO - 2020-08-28 19:00:20 --> Security Class Initialized
DEBUG - 2020-08-28 19:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:00:20 --> Input Class Initialized
INFO - 2020-08-28 19:00:20 --> Language Class Initialized
INFO - 2020-08-28 19:00:20 --> Language Class Initialized
INFO - 2020-08-28 19:00:20 --> Config Class Initialized
INFO - 2020-08-28 19:00:20 --> Loader Class Initialized
INFO - 2020-08-28 19:00:20 --> Helper loaded: url_helper
INFO - 2020-08-28 19:00:20 --> Helper loaded: form_helper
INFO - 2020-08-28 19:00:20 --> Helper loaded: file_helper
INFO - 2020-08-28 19:00:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:00:20 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:00:20 --> Upload Class Initialized
INFO - 2020-08-28 19:00:20 --> Controller Class Initialized
ERROR - 2020-08-28 19:00:20 --> 404 Page Not Found: /index
INFO - 2020-08-28 19:02:18 --> Config Class Initialized
INFO - 2020-08-28 19:02:18 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:02:18 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:02:18 --> Utf8 Class Initialized
INFO - 2020-08-28 19:02:18 --> URI Class Initialized
DEBUG - 2020-08-28 19:02:18 --> No URI present. Default controller set.
INFO - 2020-08-28 19:02:18 --> Router Class Initialized
INFO - 2020-08-28 19:02:18 --> Output Class Initialized
INFO - 2020-08-28 19:02:18 --> Security Class Initialized
DEBUG - 2020-08-28 19:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:02:18 --> Input Class Initialized
INFO - 2020-08-28 19:02:18 --> Language Class Initialized
INFO - 2020-08-28 19:02:18 --> Language Class Initialized
INFO - 2020-08-28 19:02:18 --> Config Class Initialized
INFO - 2020-08-28 19:02:18 --> Loader Class Initialized
INFO - 2020-08-28 19:02:18 --> Helper loaded: url_helper
INFO - 2020-08-28 19:02:18 --> Helper loaded: form_helper
INFO - 2020-08-28 19:02:18 --> Helper loaded: file_helper
INFO - 2020-08-28 19:02:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:02:18 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:02:18 --> Upload Class Initialized
INFO - 2020-08-28 19:02:18 --> Controller Class Initialized
DEBUG - 2020-08-28 19:02:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 19:02:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 19:02:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 19:02:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 19:02:18 --> Final output sent to browser
DEBUG - 2020-08-28 19:02:18 --> Total execution time: 0.0645
INFO - 2020-08-28 19:21:54 --> Config Class Initialized
INFO - 2020-08-28 19:21:54 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:21:54 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:21:54 --> Utf8 Class Initialized
INFO - 2020-08-28 19:21:54 --> URI Class Initialized
INFO - 2020-08-28 19:21:54 --> Router Class Initialized
INFO - 2020-08-28 19:21:54 --> Output Class Initialized
INFO - 2020-08-28 19:21:54 --> Security Class Initialized
DEBUG - 2020-08-28 19:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:21:54 --> Input Class Initialized
INFO - 2020-08-28 19:21:54 --> Language Class Initialized
INFO - 2020-08-28 19:21:54 --> Language Class Initialized
INFO - 2020-08-28 19:21:54 --> Config Class Initialized
INFO - 2020-08-28 19:21:54 --> Loader Class Initialized
INFO - 2020-08-28 19:21:54 --> Helper loaded: url_helper
INFO - 2020-08-28 19:21:54 --> Helper loaded: form_helper
INFO - 2020-08-28 19:21:54 --> Helper loaded: file_helper
INFO - 2020-08-28 19:21:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:21:54 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:21:54 --> Upload Class Initialized
INFO - 2020-08-28 19:21:54 --> Controller Class Initialized
ERROR - 2020-08-28 19:21:54 --> 404 Page Not Found: /index
INFO - 2020-08-28 19:21:55 --> Config Class Initialized
INFO - 2020-08-28 19:21:55 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:21:55 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:21:55 --> Utf8 Class Initialized
INFO - 2020-08-28 19:21:55 --> URI Class Initialized
INFO - 2020-08-28 19:21:55 --> Router Class Initialized
INFO - 2020-08-28 19:21:55 --> Output Class Initialized
INFO - 2020-08-28 19:21:55 --> Security Class Initialized
DEBUG - 2020-08-28 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:21:55 --> Input Class Initialized
INFO - 2020-08-28 19:21:55 --> Language Class Initialized
INFO - 2020-08-28 19:21:55 --> Language Class Initialized
INFO - 2020-08-28 19:21:55 --> Config Class Initialized
INFO - 2020-08-28 19:21:55 --> Loader Class Initialized
INFO - 2020-08-28 19:21:55 --> Helper loaded: url_helper
INFO - 2020-08-28 19:21:55 --> Helper loaded: form_helper
INFO - 2020-08-28 19:21:55 --> Helper loaded: file_helper
INFO - 2020-08-28 19:21:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:21:55 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:21:55 --> Upload Class Initialized
INFO - 2020-08-28 19:21:55 --> Controller Class Initialized
ERROR - 2020-08-28 19:21:55 --> 404 Page Not Found: /index
INFO - 2020-08-28 19:21:57 --> Config Class Initialized
INFO - 2020-08-28 19:21:57 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:21:57 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:21:57 --> Utf8 Class Initialized
INFO - 2020-08-28 19:21:57 --> URI Class Initialized
DEBUG - 2020-08-28 19:21:57 --> No URI present. Default controller set.
INFO - 2020-08-28 19:21:57 --> Router Class Initialized
INFO - 2020-08-28 19:21:57 --> Output Class Initialized
INFO - 2020-08-28 19:21:57 --> Security Class Initialized
DEBUG - 2020-08-28 19:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:21:57 --> Input Class Initialized
INFO - 2020-08-28 19:21:57 --> Language Class Initialized
INFO - 2020-08-28 19:21:57 --> Language Class Initialized
INFO - 2020-08-28 19:21:57 --> Config Class Initialized
INFO - 2020-08-28 19:21:57 --> Loader Class Initialized
INFO - 2020-08-28 19:21:57 --> Helper loaded: url_helper
INFO - 2020-08-28 19:21:57 --> Helper loaded: form_helper
INFO - 2020-08-28 19:21:57 --> Helper loaded: file_helper
INFO - 2020-08-28 19:21:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:21:57 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:21:57 --> Upload Class Initialized
INFO - 2020-08-28 19:21:57 --> Controller Class Initialized
DEBUG - 2020-08-28 19:21:57 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 19:21:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 19:21:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 19:21:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 19:21:57 --> Final output sent to browser
DEBUG - 2020-08-28 19:21:57 --> Total execution time: 0.0489
INFO - 2020-08-28 19:22:01 --> Config Class Initialized
INFO - 2020-08-28 19:22:01 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:22:01 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:22:01 --> Utf8 Class Initialized
INFO - 2020-08-28 19:22:01 --> URI Class Initialized
INFO - 2020-08-28 19:22:01 --> Router Class Initialized
INFO - 2020-08-28 19:22:01 --> Output Class Initialized
INFO - 2020-08-28 19:22:01 --> Security Class Initialized
DEBUG - 2020-08-28 19:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:22:01 --> Input Class Initialized
INFO - 2020-08-28 19:22:01 --> Language Class Initialized
INFO - 2020-08-28 19:22:01 --> Language Class Initialized
INFO - 2020-08-28 19:22:01 --> Config Class Initialized
INFO - 2020-08-28 19:22:01 --> Loader Class Initialized
INFO - 2020-08-28 19:22:01 --> Helper loaded: url_helper
INFO - 2020-08-28 19:22:01 --> Helper loaded: form_helper
INFO - 2020-08-28 19:22:01 --> Helper loaded: file_helper
INFO - 2020-08-28 19:22:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:22:01 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:22:01 --> Upload Class Initialized
INFO - 2020-08-28 19:22:02 --> Controller Class Initialized
ERROR - 2020-08-28 19:22:02 --> 404 Page Not Found: /index
INFO - 2020-08-28 19:22:05 --> Config Class Initialized
INFO - 2020-08-28 19:22:05 --> Hooks Class Initialized
DEBUG - 2020-08-28 19:22:05 --> UTF-8 Support Enabled
INFO - 2020-08-28 19:22:05 --> Utf8 Class Initialized
INFO - 2020-08-28 19:22:05 --> URI Class Initialized
DEBUG - 2020-08-28 19:22:05 --> No URI present. Default controller set.
INFO - 2020-08-28 19:22:05 --> Router Class Initialized
INFO - 2020-08-28 19:22:05 --> Output Class Initialized
INFO - 2020-08-28 19:22:05 --> Security Class Initialized
DEBUG - 2020-08-28 19:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 19:22:05 --> Input Class Initialized
INFO - 2020-08-28 19:22:05 --> Language Class Initialized
INFO - 2020-08-28 19:22:05 --> Language Class Initialized
INFO - 2020-08-28 19:22:05 --> Config Class Initialized
INFO - 2020-08-28 19:22:05 --> Loader Class Initialized
INFO - 2020-08-28 19:22:05 --> Helper loaded: url_helper
INFO - 2020-08-28 19:22:05 --> Helper loaded: form_helper
INFO - 2020-08-28 19:22:05 --> Helper loaded: file_helper
INFO - 2020-08-28 19:22:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 19:22:05 --> Database Driver Class Initialized
DEBUG - 2020-08-28 19:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 19:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 19:22:05 --> Upload Class Initialized
INFO - 2020-08-28 19:22:05 --> Controller Class Initialized
DEBUG - 2020-08-28 19:22:05 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 19:22:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 19:22:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 19:22:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 19:22:05 --> Final output sent to browser
DEBUG - 2020-08-28 19:22:05 --> Total execution time: 0.0521
INFO - 2020-08-28 20:40:02 --> Config Class Initialized
INFO - 2020-08-28 20:40:02 --> Hooks Class Initialized
DEBUG - 2020-08-28 20:40:02 --> UTF-8 Support Enabled
INFO - 2020-08-28 20:40:02 --> Utf8 Class Initialized
INFO - 2020-08-28 20:40:02 --> URI Class Initialized
DEBUG - 2020-08-28 20:40:02 --> No URI present. Default controller set.
INFO - 2020-08-28 20:40:02 --> Router Class Initialized
INFO - 2020-08-28 20:40:02 --> Output Class Initialized
INFO - 2020-08-28 20:40:02 --> Security Class Initialized
DEBUG - 2020-08-28 20:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 20:40:02 --> Input Class Initialized
INFO - 2020-08-28 20:40:02 --> Language Class Initialized
INFO - 2020-08-28 20:40:02 --> Language Class Initialized
INFO - 2020-08-28 20:40:02 --> Config Class Initialized
INFO - 2020-08-28 20:40:02 --> Loader Class Initialized
INFO - 2020-08-28 20:40:02 --> Helper loaded: url_helper
INFO - 2020-08-28 20:40:02 --> Helper loaded: form_helper
INFO - 2020-08-28 20:40:02 --> Helper loaded: file_helper
INFO - 2020-08-28 20:40:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 20:40:02 --> Database Driver Class Initialized
DEBUG - 2020-08-28 20:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 20:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 20:40:03 --> Upload Class Initialized
INFO - 2020-08-28 20:40:03 --> Controller Class Initialized
DEBUG - 2020-08-28 20:40:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 20:40:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 20:40:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 20:40:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 20:40:03 --> Final output sent to browser
DEBUG - 2020-08-28 20:40:03 --> Total execution time: 0.5537
INFO - 2020-08-28 20:40:29 --> Config Class Initialized
INFO - 2020-08-28 20:40:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 20:40:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 20:40:29 --> Utf8 Class Initialized
INFO - 2020-08-28 20:40:29 --> URI Class Initialized
DEBUG - 2020-08-28 20:40:29 --> No URI present. Default controller set.
INFO - 2020-08-28 20:40:29 --> Router Class Initialized
INFO - 2020-08-28 20:40:29 --> Output Class Initialized
INFO - 2020-08-28 20:40:29 --> Security Class Initialized
DEBUG - 2020-08-28 20:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 20:40:29 --> Input Class Initialized
INFO - 2020-08-28 20:40:29 --> Language Class Initialized
INFO - 2020-08-28 20:40:29 --> Language Class Initialized
INFO - 2020-08-28 20:40:29 --> Config Class Initialized
INFO - 2020-08-28 20:40:29 --> Loader Class Initialized
INFO - 2020-08-28 20:40:29 --> Helper loaded: url_helper
INFO - 2020-08-28 20:40:29 --> Helper loaded: form_helper
INFO - 2020-08-28 20:40:29 --> Helper loaded: file_helper
INFO - 2020-08-28 20:40:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 20:40:29 --> Database Driver Class Initialized
DEBUG - 2020-08-28 20:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 20:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 20:40:29 --> Upload Class Initialized
INFO - 2020-08-28 20:40:29 --> Controller Class Initialized
DEBUG - 2020-08-28 20:40:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 20:40:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-28 20:40:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-28 20:40:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 20:40:29 --> Final output sent to browser
DEBUG - 2020-08-28 20:40:29 --> Total execution time: 0.0564
INFO - 2020-08-28 23:40:29 --> Config Class Initialized
INFO - 2020-08-28 23:40:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 23:40:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 23:40:29 --> Utf8 Class Initialized
INFO - 2020-08-28 23:40:29 --> URI Class Initialized
INFO - 2020-08-28 23:40:29 --> Router Class Initialized
INFO - 2020-08-28 23:40:29 --> Output Class Initialized
INFO - 2020-08-28 23:40:29 --> Security Class Initialized
DEBUG - 2020-08-28 23:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 23:40:29 --> Input Class Initialized
INFO - 2020-08-28 23:40:29 --> Language Class Initialized
INFO - 2020-08-28 23:40:29 --> Language Class Initialized
INFO - 2020-08-28 23:40:29 --> Config Class Initialized
INFO - 2020-08-28 23:40:29 --> Loader Class Initialized
INFO - 2020-08-28 23:40:29 --> Helper loaded: url_helper
INFO - 2020-08-28 23:40:29 --> Helper loaded: form_helper
INFO - 2020-08-28 23:40:29 --> Helper loaded: file_helper
INFO - 2020-08-28 23:40:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 23:40:29 --> Database Driver Class Initialized
DEBUG - 2020-08-28 23:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 23:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 23:40:29 --> Upload Class Initialized
INFO - 2020-08-28 23:40:29 --> Controller Class Initialized
ERROR - 2020-08-28 23:40:29 --> 404 Page Not Found: /index
INFO - 2020-08-28 23:40:29 --> Config Class Initialized
INFO - 2020-08-28 23:40:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 23:40:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 23:40:29 --> Utf8 Class Initialized
INFO - 2020-08-28 23:40:29 --> URI Class Initialized
INFO - 2020-08-28 23:40:29 --> Router Class Initialized
INFO - 2020-08-28 23:40:29 --> Output Class Initialized
INFO - 2020-08-28 23:40:29 --> Security Class Initialized
DEBUG - 2020-08-28 23:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 23:40:29 --> Input Class Initialized
INFO - 2020-08-28 23:40:29 --> Language Class Initialized
INFO - 2020-08-28 23:40:29 --> Language Class Initialized
INFO - 2020-08-28 23:40:29 --> Config Class Initialized
INFO - 2020-08-28 23:40:29 --> Loader Class Initialized
INFO - 2020-08-28 23:40:29 --> Helper loaded: url_helper
INFO - 2020-08-28 23:40:29 --> Helper loaded: form_helper
INFO - 2020-08-28 23:40:29 --> Helper loaded: file_helper
INFO - 2020-08-28 23:40:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-28 23:40:29 --> Database Driver Class Initialized
DEBUG - 2020-08-28 23:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-28 23:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 23:40:29 --> Upload Class Initialized
INFO - 2020-08-28 23:40:30 --> Controller Class Initialized
DEBUG - 2020-08-28 23:40:30 --> Home MX_Controller Initialized
DEBUG - 2020-08-28 23:40:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-28 23:40:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-28 23:40:30 --> Final output sent to browser
DEBUG - 2020-08-28 23:40:30 --> Total execution time: 0.0784
