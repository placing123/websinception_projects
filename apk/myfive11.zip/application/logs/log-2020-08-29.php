<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-29 00:18:13 --> Config Class Initialized
INFO - 2020-08-29 00:18:13 --> Hooks Class Initialized
DEBUG - 2020-08-29 00:18:13 --> UTF-8 Support Enabled
INFO - 2020-08-29 00:18:13 --> Utf8 Class Initialized
INFO - 2020-08-29 00:18:13 --> URI Class Initialized
INFO - 2020-08-29 00:18:13 --> Router Class Initialized
INFO - 2020-08-29 00:18:13 --> Output Class Initialized
INFO - 2020-08-29 00:18:13 --> Security Class Initialized
DEBUG - 2020-08-29 00:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 00:18:13 --> Input Class Initialized
INFO - 2020-08-29 00:18:13 --> Language Class Initialized
INFO - 2020-08-29 00:18:13 --> Language Class Initialized
INFO - 2020-08-29 00:18:13 --> Config Class Initialized
INFO - 2020-08-29 00:18:13 --> Loader Class Initialized
INFO - 2020-08-29 00:18:13 --> Helper loaded: url_helper
INFO - 2020-08-29 00:18:13 --> Helper loaded: form_helper
INFO - 2020-08-29 00:18:13 --> Helper loaded: file_helper
INFO - 2020-08-29 00:18:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 00:18:13 --> Database Driver Class Initialized
DEBUG - 2020-08-29 00:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 00:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 00:18:13 --> Upload Class Initialized
INFO - 2020-08-29 00:18:13 --> Controller Class Initialized
ERROR - 2020-08-29 00:18:13 --> 404 Page Not Found: /index
INFO - 2020-08-29 01:06:58 --> Config Class Initialized
INFO - 2020-08-29 01:06:58 --> Hooks Class Initialized
DEBUG - 2020-08-29 01:06:58 --> UTF-8 Support Enabled
INFO - 2020-08-29 01:06:58 --> Utf8 Class Initialized
INFO - 2020-08-29 01:06:58 --> URI Class Initialized
DEBUG - 2020-08-29 01:06:58 --> No URI present. Default controller set.
INFO - 2020-08-29 01:06:58 --> Router Class Initialized
INFO - 2020-08-29 01:06:58 --> Output Class Initialized
INFO - 2020-08-29 01:06:58 --> Security Class Initialized
DEBUG - 2020-08-29 01:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 01:06:58 --> Input Class Initialized
INFO - 2020-08-29 01:06:58 --> Language Class Initialized
INFO - 2020-08-29 01:06:58 --> Language Class Initialized
INFO - 2020-08-29 01:06:58 --> Config Class Initialized
INFO - 2020-08-29 01:06:58 --> Loader Class Initialized
INFO - 2020-08-29 01:06:58 --> Helper loaded: url_helper
INFO - 2020-08-29 01:06:58 --> Helper loaded: form_helper
INFO - 2020-08-29 01:06:58 --> Helper loaded: file_helper
INFO - 2020-08-29 01:06:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 01:06:58 --> Database Driver Class Initialized
DEBUG - 2020-08-29 01:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 01:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 01:06:58 --> Upload Class Initialized
INFO - 2020-08-29 01:06:58 --> Controller Class Initialized
DEBUG - 2020-08-29 01:06:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 01:06:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 01:06:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 01:06:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 01:06:58 --> Final output sent to browser
DEBUG - 2020-08-29 01:06:58 --> Total execution time: 0.1413
INFO - 2020-08-29 02:29:11 --> Config Class Initialized
INFO - 2020-08-29 02:29:11 --> Hooks Class Initialized
DEBUG - 2020-08-29 02:29:11 --> UTF-8 Support Enabled
INFO - 2020-08-29 02:29:11 --> Utf8 Class Initialized
INFO - 2020-08-29 02:29:11 --> URI Class Initialized
INFO - 2020-08-29 02:29:11 --> Router Class Initialized
INFO - 2020-08-29 02:29:11 --> Output Class Initialized
INFO - 2020-08-29 02:29:11 --> Security Class Initialized
DEBUG - 2020-08-29 02:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 02:29:11 --> Input Class Initialized
INFO - 2020-08-29 02:29:11 --> Language Class Initialized
INFO - 2020-08-29 02:29:11 --> Language Class Initialized
INFO - 2020-08-29 02:29:11 --> Config Class Initialized
INFO - 2020-08-29 02:29:11 --> Loader Class Initialized
INFO - 2020-08-29 02:29:11 --> Helper loaded: url_helper
INFO - 2020-08-29 02:29:11 --> Helper loaded: form_helper
INFO - 2020-08-29 02:29:11 --> Helper loaded: file_helper
INFO - 2020-08-29 02:29:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 02:29:11 --> Database Driver Class Initialized
DEBUG - 2020-08-29 02:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 02:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 02:29:11 --> Upload Class Initialized
INFO - 2020-08-29 02:29:11 --> Controller Class Initialized
ERROR - 2020-08-29 02:29:11 --> 404 Page Not Found: /index
INFO - 2020-08-29 03:12:01 --> Config Class Initialized
INFO - 2020-08-29 03:12:01 --> Hooks Class Initialized
DEBUG - 2020-08-29 03:12:01 --> UTF-8 Support Enabled
INFO - 2020-08-29 03:12:01 --> Utf8 Class Initialized
INFO - 2020-08-29 03:12:01 --> URI Class Initialized
INFO - 2020-08-29 03:12:01 --> Router Class Initialized
INFO - 2020-08-29 03:12:01 --> Output Class Initialized
INFO - 2020-08-29 03:12:01 --> Security Class Initialized
DEBUG - 2020-08-29 03:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 03:12:01 --> Input Class Initialized
INFO - 2020-08-29 03:12:01 --> Language Class Initialized
INFO - 2020-08-29 03:12:01 --> Language Class Initialized
INFO - 2020-08-29 03:12:01 --> Config Class Initialized
INFO - 2020-08-29 03:12:01 --> Loader Class Initialized
INFO - 2020-08-29 03:12:01 --> Helper loaded: url_helper
INFO - 2020-08-29 03:12:01 --> Helper loaded: form_helper
INFO - 2020-08-29 03:12:01 --> Helper loaded: file_helper
INFO - 2020-08-29 03:12:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 03:12:01 --> Database Driver Class Initialized
DEBUG - 2020-08-29 03:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 03:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 03:12:01 --> Upload Class Initialized
INFO - 2020-08-29 03:12:01 --> Controller Class Initialized
ERROR - 2020-08-29 03:12:01 --> 404 Page Not Found: /index
INFO - 2020-08-29 03:49:42 --> Config Class Initialized
INFO - 2020-08-29 03:49:42 --> Hooks Class Initialized
DEBUG - 2020-08-29 03:49:42 --> UTF-8 Support Enabled
INFO - 2020-08-29 03:49:42 --> Utf8 Class Initialized
INFO - 2020-08-29 03:49:42 --> URI Class Initialized
DEBUG - 2020-08-29 03:49:42 --> No URI present. Default controller set.
INFO - 2020-08-29 03:49:42 --> Router Class Initialized
INFO - 2020-08-29 03:49:42 --> Output Class Initialized
INFO - 2020-08-29 03:49:42 --> Security Class Initialized
DEBUG - 2020-08-29 03:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 03:49:42 --> Input Class Initialized
INFO - 2020-08-29 03:49:42 --> Language Class Initialized
INFO - 2020-08-29 03:49:42 --> Language Class Initialized
INFO - 2020-08-29 03:49:42 --> Config Class Initialized
INFO - 2020-08-29 03:49:42 --> Loader Class Initialized
INFO - 2020-08-29 03:49:42 --> Helper loaded: url_helper
INFO - 2020-08-29 03:49:42 --> Helper loaded: form_helper
INFO - 2020-08-29 03:49:42 --> Helper loaded: file_helper
INFO - 2020-08-29 03:49:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 03:49:42 --> Database Driver Class Initialized
DEBUG - 2020-08-29 03:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 03:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 03:49:42 --> Upload Class Initialized
INFO - 2020-08-29 03:49:42 --> Controller Class Initialized
DEBUG - 2020-08-29 03:49:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 03:49:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 03:49:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 03:49:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 03:49:42 --> Final output sent to browser
DEBUG - 2020-08-29 03:49:42 --> Total execution time: 0.0506
INFO - 2020-08-29 04:05:04 --> Config Class Initialized
INFO - 2020-08-29 04:05:04 --> Hooks Class Initialized
DEBUG - 2020-08-29 04:05:04 --> UTF-8 Support Enabled
INFO - 2020-08-29 04:05:04 --> Utf8 Class Initialized
INFO - 2020-08-29 04:05:04 --> URI Class Initialized
DEBUG - 2020-08-29 04:05:04 --> No URI present. Default controller set.
INFO - 2020-08-29 04:05:04 --> Router Class Initialized
INFO - 2020-08-29 04:05:04 --> Output Class Initialized
INFO - 2020-08-29 04:05:04 --> Security Class Initialized
DEBUG - 2020-08-29 04:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 04:05:04 --> Input Class Initialized
INFO - 2020-08-29 04:05:04 --> Language Class Initialized
INFO - 2020-08-29 04:05:04 --> Language Class Initialized
INFO - 2020-08-29 04:05:04 --> Config Class Initialized
INFO - 2020-08-29 04:05:04 --> Loader Class Initialized
INFO - 2020-08-29 04:05:04 --> Helper loaded: url_helper
INFO - 2020-08-29 04:05:04 --> Helper loaded: form_helper
INFO - 2020-08-29 04:05:04 --> Helper loaded: file_helper
INFO - 2020-08-29 04:05:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 04:05:04 --> Database Driver Class Initialized
DEBUG - 2020-08-29 04:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 04:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 04:05:04 --> Upload Class Initialized
INFO - 2020-08-29 04:05:04 --> Controller Class Initialized
DEBUG - 2020-08-29 04:05:04 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 04:05:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 04:05:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 04:05:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 04:05:04 --> Final output sent to browser
DEBUG - 2020-08-29 04:05:04 --> Total execution time: 0.0540
INFO - 2020-08-29 04:23:49 --> Config Class Initialized
INFO - 2020-08-29 04:23:49 --> Hooks Class Initialized
DEBUG - 2020-08-29 04:23:49 --> UTF-8 Support Enabled
INFO - 2020-08-29 04:23:49 --> Utf8 Class Initialized
INFO - 2020-08-29 04:23:49 --> URI Class Initialized
DEBUG - 2020-08-29 04:23:49 --> No URI present. Default controller set.
INFO - 2020-08-29 04:23:49 --> Router Class Initialized
INFO - 2020-08-29 04:23:49 --> Output Class Initialized
INFO - 2020-08-29 04:23:49 --> Security Class Initialized
DEBUG - 2020-08-29 04:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 04:23:49 --> Input Class Initialized
INFO - 2020-08-29 04:23:49 --> Language Class Initialized
INFO - 2020-08-29 04:23:49 --> Language Class Initialized
INFO - 2020-08-29 04:23:49 --> Config Class Initialized
INFO - 2020-08-29 04:23:49 --> Loader Class Initialized
INFO - 2020-08-29 04:23:49 --> Helper loaded: url_helper
INFO - 2020-08-29 04:23:49 --> Helper loaded: form_helper
INFO - 2020-08-29 04:23:49 --> Helper loaded: file_helper
INFO - 2020-08-29 04:23:49 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 04:23:49 --> Database Driver Class Initialized
DEBUG - 2020-08-29 04:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 04:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 04:23:49 --> Upload Class Initialized
INFO - 2020-08-29 04:23:49 --> Controller Class Initialized
DEBUG - 2020-08-29 04:23:49 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 04:23:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 04:23:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 04:23:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 04:23:49 --> Final output sent to browser
DEBUG - 2020-08-29 04:23:49 --> Total execution time: 0.0510
INFO - 2020-08-29 04:24:08 --> Config Class Initialized
INFO - 2020-08-29 04:24:08 --> Hooks Class Initialized
DEBUG - 2020-08-29 04:24:08 --> UTF-8 Support Enabled
INFO - 2020-08-29 04:24:08 --> Utf8 Class Initialized
INFO - 2020-08-29 04:24:08 --> URI Class Initialized
INFO - 2020-08-29 04:24:08 --> Router Class Initialized
INFO - 2020-08-29 04:24:08 --> Output Class Initialized
INFO - 2020-08-29 04:24:08 --> Security Class Initialized
DEBUG - 2020-08-29 04:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 04:24:08 --> Input Class Initialized
INFO - 2020-08-29 04:24:08 --> Language Class Initialized
INFO - 2020-08-29 04:24:08 --> Language Class Initialized
INFO - 2020-08-29 04:24:08 --> Config Class Initialized
INFO - 2020-08-29 04:24:08 --> Loader Class Initialized
INFO - 2020-08-29 04:24:08 --> Helper loaded: url_helper
INFO - 2020-08-29 04:24:08 --> Helper loaded: form_helper
INFO - 2020-08-29 04:24:08 --> Helper loaded: file_helper
INFO - 2020-08-29 04:24:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 04:24:08 --> Database Driver Class Initialized
DEBUG - 2020-08-29 04:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 04:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 04:24:08 --> Upload Class Initialized
INFO - 2020-08-29 04:24:08 --> Controller Class Initialized
ERROR - 2020-08-29 04:24:08 --> 404 Page Not Found: /index
INFO - 2020-08-29 04:24:09 --> Config Class Initialized
INFO - 2020-08-29 04:24:09 --> Hooks Class Initialized
DEBUG - 2020-08-29 04:24:09 --> UTF-8 Support Enabled
INFO - 2020-08-29 04:24:09 --> Utf8 Class Initialized
INFO - 2020-08-29 04:24:09 --> URI Class Initialized
INFO - 2020-08-29 04:24:09 --> Router Class Initialized
INFO - 2020-08-29 04:24:09 --> Output Class Initialized
INFO - 2020-08-29 04:24:09 --> Security Class Initialized
DEBUG - 2020-08-29 04:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 04:24:09 --> Input Class Initialized
INFO - 2020-08-29 04:24:09 --> Language Class Initialized
INFO - 2020-08-29 04:24:09 --> Language Class Initialized
INFO - 2020-08-29 04:24:09 --> Config Class Initialized
INFO - 2020-08-29 04:24:09 --> Loader Class Initialized
INFO - 2020-08-29 04:24:09 --> Helper loaded: url_helper
INFO - 2020-08-29 04:24:09 --> Helper loaded: form_helper
INFO - 2020-08-29 04:24:09 --> Helper loaded: file_helper
INFO - 2020-08-29 04:24:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 04:24:09 --> Database Driver Class Initialized
DEBUG - 2020-08-29 04:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 04:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 04:24:09 --> Upload Class Initialized
INFO - 2020-08-29 04:24:09 --> Controller Class Initialized
ERROR - 2020-08-29 04:24:09 --> 404 Page Not Found: /index
INFO - 2020-08-29 04:24:10 --> Config Class Initialized
INFO - 2020-08-29 04:24:10 --> Hooks Class Initialized
DEBUG - 2020-08-29 04:24:10 --> UTF-8 Support Enabled
INFO - 2020-08-29 04:24:10 --> Utf8 Class Initialized
INFO - 2020-08-29 04:24:10 --> URI Class Initialized
INFO - 2020-08-29 04:24:10 --> Router Class Initialized
INFO - 2020-08-29 04:24:10 --> Output Class Initialized
INFO - 2020-08-29 04:24:10 --> Security Class Initialized
DEBUG - 2020-08-29 04:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 04:24:10 --> Input Class Initialized
INFO - 2020-08-29 04:24:10 --> Language Class Initialized
INFO - 2020-08-29 04:24:10 --> Language Class Initialized
INFO - 2020-08-29 04:24:10 --> Config Class Initialized
INFO - 2020-08-29 04:24:10 --> Loader Class Initialized
INFO - 2020-08-29 04:24:10 --> Helper loaded: url_helper
INFO - 2020-08-29 04:24:10 --> Helper loaded: form_helper
INFO - 2020-08-29 04:24:10 --> Helper loaded: file_helper
INFO - 2020-08-29 04:24:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 04:24:10 --> Database Driver Class Initialized
DEBUG - 2020-08-29 04:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 04:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 04:24:10 --> Upload Class Initialized
INFO - 2020-08-29 04:24:10 --> Controller Class Initialized
ERROR - 2020-08-29 04:24:10 --> 404 Page Not Found: /index
INFO - 2020-08-29 04:24:14 --> Config Class Initialized
INFO - 2020-08-29 04:24:14 --> Hooks Class Initialized
DEBUG - 2020-08-29 04:24:14 --> UTF-8 Support Enabled
INFO - 2020-08-29 04:24:14 --> Utf8 Class Initialized
INFO - 2020-08-29 04:24:14 --> URI Class Initialized
INFO - 2020-08-29 04:24:14 --> Router Class Initialized
INFO - 2020-08-29 04:24:14 --> Output Class Initialized
INFO - 2020-08-29 04:24:14 --> Security Class Initialized
DEBUG - 2020-08-29 04:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 04:24:14 --> Input Class Initialized
INFO - 2020-08-29 04:24:14 --> Language Class Initialized
INFO - 2020-08-29 04:24:14 --> Language Class Initialized
INFO - 2020-08-29 04:24:14 --> Config Class Initialized
INFO - 2020-08-29 04:24:14 --> Loader Class Initialized
INFO - 2020-08-29 04:24:14 --> Helper loaded: url_helper
INFO - 2020-08-29 04:24:14 --> Helper loaded: form_helper
INFO - 2020-08-29 04:24:14 --> Helper loaded: file_helper
INFO - 2020-08-29 04:24:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 04:24:14 --> Database Driver Class Initialized
DEBUG - 2020-08-29 04:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 04:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 04:24:14 --> Upload Class Initialized
INFO - 2020-08-29 04:24:14 --> Controller Class Initialized
ERROR - 2020-08-29 04:24:14 --> 404 Page Not Found: /index
INFO - 2020-08-29 06:32:55 --> Config Class Initialized
INFO - 2020-08-29 06:32:55 --> Hooks Class Initialized
DEBUG - 2020-08-29 06:32:55 --> UTF-8 Support Enabled
INFO - 2020-08-29 06:32:55 --> Utf8 Class Initialized
INFO - 2020-08-29 06:32:55 --> URI Class Initialized
DEBUG - 2020-08-29 06:32:55 --> No URI present. Default controller set.
INFO - 2020-08-29 06:32:55 --> Router Class Initialized
INFO - 2020-08-29 06:32:55 --> Output Class Initialized
INFO - 2020-08-29 06:32:55 --> Security Class Initialized
DEBUG - 2020-08-29 06:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 06:32:55 --> Input Class Initialized
INFO - 2020-08-29 06:32:55 --> Language Class Initialized
INFO - 2020-08-29 06:32:55 --> Language Class Initialized
INFO - 2020-08-29 06:32:55 --> Config Class Initialized
INFO - 2020-08-29 06:32:55 --> Loader Class Initialized
INFO - 2020-08-29 06:32:55 --> Helper loaded: url_helper
INFO - 2020-08-29 06:32:55 --> Helper loaded: form_helper
INFO - 2020-08-29 06:32:55 --> Helper loaded: file_helper
INFO - 2020-08-29 06:32:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 06:32:55 --> Database Driver Class Initialized
DEBUG - 2020-08-29 06:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 06:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 06:32:55 --> Upload Class Initialized
INFO - 2020-08-29 06:32:55 --> Controller Class Initialized
DEBUG - 2020-08-29 06:32:55 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 06:32:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 06:32:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 06:32:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 06:32:55 --> Final output sent to browser
DEBUG - 2020-08-29 06:32:55 --> Total execution time: 0.0575
INFO - 2020-08-29 07:07:11 --> Config Class Initialized
INFO - 2020-08-29 07:07:11 --> Hooks Class Initialized
DEBUG - 2020-08-29 07:07:11 --> UTF-8 Support Enabled
INFO - 2020-08-29 07:07:11 --> Utf8 Class Initialized
INFO - 2020-08-29 07:07:11 --> URI Class Initialized
DEBUG - 2020-08-29 07:07:11 --> No URI present. Default controller set.
INFO - 2020-08-29 07:07:11 --> Router Class Initialized
INFO - 2020-08-29 07:07:11 --> Output Class Initialized
INFO - 2020-08-29 07:07:11 --> Security Class Initialized
DEBUG - 2020-08-29 07:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 07:07:11 --> Input Class Initialized
INFO - 2020-08-29 07:07:11 --> Language Class Initialized
INFO - 2020-08-29 07:07:11 --> Language Class Initialized
INFO - 2020-08-29 07:07:11 --> Config Class Initialized
INFO - 2020-08-29 07:07:11 --> Loader Class Initialized
INFO - 2020-08-29 07:07:11 --> Helper loaded: url_helper
INFO - 2020-08-29 07:07:11 --> Helper loaded: form_helper
INFO - 2020-08-29 07:07:11 --> Helper loaded: file_helper
INFO - 2020-08-29 07:07:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 07:07:11 --> Database Driver Class Initialized
DEBUG - 2020-08-29 07:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 07:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 07:07:11 --> Upload Class Initialized
INFO - 2020-08-29 07:07:11 --> Controller Class Initialized
DEBUG - 2020-08-29 07:07:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 07:07:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 07:07:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 07:07:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 07:07:11 --> Final output sent to browser
DEBUG - 2020-08-29 07:07:11 --> Total execution time: 0.0507
INFO - 2020-08-29 07:07:13 --> Config Class Initialized
INFO - 2020-08-29 07:07:13 --> Hooks Class Initialized
DEBUG - 2020-08-29 07:07:13 --> UTF-8 Support Enabled
INFO - 2020-08-29 07:07:13 --> Utf8 Class Initialized
INFO - 2020-08-29 07:07:13 --> URI Class Initialized
INFO - 2020-08-29 07:07:13 --> Router Class Initialized
INFO - 2020-08-29 07:07:13 --> Output Class Initialized
INFO - 2020-08-29 07:07:13 --> Security Class Initialized
DEBUG - 2020-08-29 07:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 07:07:13 --> Input Class Initialized
INFO - 2020-08-29 07:07:13 --> Language Class Initialized
INFO - 2020-08-29 07:07:13 --> Language Class Initialized
INFO - 2020-08-29 07:07:13 --> Config Class Initialized
INFO - 2020-08-29 07:07:13 --> Loader Class Initialized
INFO - 2020-08-29 07:07:13 --> Helper loaded: url_helper
INFO - 2020-08-29 07:07:13 --> Helper loaded: form_helper
INFO - 2020-08-29 07:07:13 --> Helper loaded: file_helper
INFO - 2020-08-29 07:07:13 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 07:07:13 --> Database Driver Class Initialized
DEBUG - 2020-08-29 07:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 07:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 07:07:13 --> Upload Class Initialized
INFO - 2020-08-29 07:07:13 --> Controller Class Initialized
ERROR - 2020-08-29 07:07:13 --> 404 Page Not Found: /index
INFO - 2020-08-29 07:07:15 --> Config Class Initialized
INFO - 2020-08-29 07:07:15 --> Hooks Class Initialized
DEBUG - 2020-08-29 07:07:15 --> UTF-8 Support Enabled
INFO - 2020-08-29 07:07:15 --> Utf8 Class Initialized
INFO - 2020-08-29 07:07:15 --> URI Class Initialized
DEBUG - 2020-08-29 07:07:15 --> No URI present. Default controller set.
INFO - 2020-08-29 07:07:15 --> Router Class Initialized
INFO - 2020-08-29 07:07:15 --> Output Class Initialized
INFO - 2020-08-29 07:07:15 --> Security Class Initialized
DEBUG - 2020-08-29 07:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 07:07:15 --> Input Class Initialized
INFO - 2020-08-29 07:07:15 --> Language Class Initialized
INFO - 2020-08-29 07:07:15 --> Language Class Initialized
INFO - 2020-08-29 07:07:15 --> Config Class Initialized
INFO - 2020-08-29 07:07:15 --> Loader Class Initialized
INFO - 2020-08-29 07:07:15 --> Helper loaded: url_helper
INFO - 2020-08-29 07:07:15 --> Helper loaded: form_helper
INFO - 2020-08-29 07:07:15 --> Helper loaded: file_helper
INFO - 2020-08-29 07:07:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 07:07:15 --> Database Driver Class Initialized
DEBUG - 2020-08-29 07:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 07:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 07:07:15 --> Upload Class Initialized
INFO - 2020-08-29 07:07:15 --> Controller Class Initialized
DEBUG - 2020-08-29 07:07:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 07:07:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 07:07:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 07:07:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 07:07:15 --> Final output sent to browser
DEBUG - 2020-08-29 07:07:15 --> Total execution time: 0.0503
INFO - 2020-08-29 08:17:37 --> Config Class Initialized
INFO - 2020-08-29 08:17:37 --> Hooks Class Initialized
DEBUG - 2020-08-29 08:17:37 --> UTF-8 Support Enabled
INFO - 2020-08-29 08:17:37 --> Utf8 Class Initialized
INFO - 2020-08-29 08:17:37 --> URI Class Initialized
INFO - 2020-08-29 08:17:37 --> Router Class Initialized
INFO - 2020-08-29 08:17:37 --> Output Class Initialized
INFO - 2020-08-29 08:17:37 --> Security Class Initialized
DEBUG - 2020-08-29 08:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 08:17:37 --> Input Class Initialized
INFO - 2020-08-29 08:17:37 --> Language Class Initialized
INFO - 2020-08-29 08:17:37 --> Language Class Initialized
INFO - 2020-08-29 08:17:37 --> Config Class Initialized
INFO - 2020-08-29 08:17:37 --> Loader Class Initialized
INFO - 2020-08-29 08:17:37 --> Helper loaded: url_helper
INFO - 2020-08-29 08:17:37 --> Helper loaded: form_helper
INFO - 2020-08-29 08:17:37 --> Helper loaded: file_helper
INFO - 2020-08-29 08:17:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 08:17:37 --> Database Driver Class Initialized
DEBUG - 2020-08-29 08:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 08:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 08:17:37 --> Upload Class Initialized
INFO - 2020-08-29 08:17:37 --> Controller Class Initialized
ERROR - 2020-08-29 08:17:37 --> 404 Page Not Found: /index
INFO - 2020-08-29 10:17:21 --> Config Class Initialized
INFO - 2020-08-29 10:17:21 --> Hooks Class Initialized
DEBUG - 2020-08-29 10:17:21 --> UTF-8 Support Enabled
INFO - 2020-08-29 10:17:21 --> Utf8 Class Initialized
INFO - 2020-08-29 10:17:21 --> URI Class Initialized
DEBUG - 2020-08-29 10:17:21 --> No URI present. Default controller set.
INFO - 2020-08-29 10:17:21 --> Router Class Initialized
INFO - 2020-08-29 10:17:21 --> Output Class Initialized
INFO - 2020-08-29 10:17:21 --> Security Class Initialized
DEBUG - 2020-08-29 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 10:17:21 --> Input Class Initialized
INFO - 2020-08-29 10:17:21 --> Language Class Initialized
INFO - 2020-08-29 10:17:21 --> Language Class Initialized
INFO - 2020-08-29 10:17:21 --> Config Class Initialized
INFO - 2020-08-29 10:17:21 --> Loader Class Initialized
INFO - 2020-08-29 10:17:21 --> Helper loaded: url_helper
INFO - 2020-08-29 10:17:21 --> Helper loaded: form_helper
INFO - 2020-08-29 10:17:21 --> Helper loaded: file_helper
INFO - 2020-08-29 10:17:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 10:17:21 --> Database Driver Class Initialized
DEBUG - 2020-08-29 10:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 10:17:21 --> Upload Class Initialized
INFO - 2020-08-29 10:17:21 --> Controller Class Initialized
DEBUG - 2020-08-29 10:17:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 10:17:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 10:17:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 10:17:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 10:17:21 --> Final output sent to browser
DEBUG - 2020-08-29 10:17:21 --> Total execution time: 0.1440
INFO - 2020-08-29 11:02:47 --> Config Class Initialized
INFO - 2020-08-29 11:02:47 --> Hooks Class Initialized
DEBUG - 2020-08-29 11:02:47 --> UTF-8 Support Enabled
INFO - 2020-08-29 11:02:47 --> Utf8 Class Initialized
INFO - 2020-08-29 11:02:47 --> URI Class Initialized
DEBUG - 2020-08-29 11:02:47 --> No URI present. Default controller set.
INFO - 2020-08-29 11:02:47 --> Router Class Initialized
INFO - 2020-08-29 11:02:47 --> Output Class Initialized
INFO - 2020-08-29 11:02:47 --> Security Class Initialized
DEBUG - 2020-08-29 11:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 11:02:47 --> Input Class Initialized
INFO - 2020-08-29 11:02:47 --> Language Class Initialized
INFO - 2020-08-29 11:02:47 --> Language Class Initialized
INFO - 2020-08-29 11:02:47 --> Config Class Initialized
INFO - 2020-08-29 11:02:47 --> Loader Class Initialized
INFO - 2020-08-29 11:02:47 --> Helper loaded: url_helper
INFO - 2020-08-29 11:02:47 --> Helper loaded: form_helper
INFO - 2020-08-29 11:02:47 --> Helper loaded: file_helper
INFO - 2020-08-29 11:02:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 11:02:47 --> Database Driver Class Initialized
DEBUG - 2020-08-29 11:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 11:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 11:02:47 --> Upload Class Initialized
INFO - 2020-08-29 11:02:47 --> Controller Class Initialized
DEBUG - 2020-08-29 11:02:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 11:02:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 11:02:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 11:02:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 11:02:47 --> Final output sent to browser
DEBUG - 2020-08-29 11:02:47 --> Total execution time: 0.0493
INFO - 2020-08-29 12:47:18 --> Config Class Initialized
INFO - 2020-08-29 12:47:18 --> Hooks Class Initialized
DEBUG - 2020-08-29 12:47:18 --> UTF-8 Support Enabled
INFO - 2020-08-29 12:47:18 --> Utf8 Class Initialized
INFO - 2020-08-29 12:47:18 --> URI Class Initialized
DEBUG - 2020-08-29 12:47:18 --> No URI present. Default controller set.
INFO - 2020-08-29 12:47:18 --> Router Class Initialized
INFO - 2020-08-29 12:47:18 --> Output Class Initialized
INFO - 2020-08-29 12:47:18 --> Security Class Initialized
DEBUG - 2020-08-29 12:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 12:47:18 --> Input Class Initialized
INFO - 2020-08-29 12:47:18 --> Language Class Initialized
INFO - 2020-08-29 12:47:18 --> Language Class Initialized
INFO - 2020-08-29 12:47:18 --> Config Class Initialized
INFO - 2020-08-29 12:47:18 --> Loader Class Initialized
INFO - 2020-08-29 12:47:18 --> Helper loaded: url_helper
INFO - 2020-08-29 12:47:18 --> Helper loaded: form_helper
INFO - 2020-08-29 12:47:18 --> Helper loaded: file_helper
INFO - 2020-08-29 12:47:18 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 12:47:18 --> Database Driver Class Initialized
DEBUG - 2020-08-29 12:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 12:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 12:47:18 --> Upload Class Initialized
INFO - 2020-08-29 12:47:18 --> Controller Class Initialized
DEBUG - 2020-08-29 12:47:18 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 12:47:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 12:47:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 12:47:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 12:47:18 --> Final output sent to browser
DEBUG - 2020-08-29 12:47:18 --> Total execution time: 0.0576
INFO - 2020-08-29 12:47:38 --> Config Class Initialized
INFO - 2020-08-29 12:47:38 --> Hooks Class Initialized
DEBUG - 2020-08-29 12:47:38 --> UTF-8 Support Enabled
INFO - 2020-08-29 12:47:38 --> Utf8 Class Initialized
INFO - 2020-08-29 12:47:38 --> URI Class Initialized
INFO - 2020-08-29 12:47:38 --> Router Class Initialized
INFO - 2020-08-29 12:47:38 --> Output Class Initialized
INFO - 2020-08-29 12:47:38 --> Security Class Initialized
DEBUG - 2020-08-29 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 12:47:38 --> Input Class Initialized
INFO - 2020-08-29 12:47:38 --> Language Class Initialized
INFO - 2020-08-29 12:47:38 --> Language Class Initialized
INFO - 2020-08-29 12:47:38 --> Config Class Initialized
INFO - 2020-08-29 12:47:38 --> Loader Class Initialized
INFO - 2020-08-29 12:47:38 --> Helper loaded: url_helper
INFO - 2020-08-29 12:47:38 --> Helper loaded: form_helper
INFO - 2020-08-29 12:47:38 --> Helper loaded: file_helper
INFO - 2020-08-29 12:47:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 12:47:38 --> Database Driver Class Initialized
DEBUG - 2020-08-29 12:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 12:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 12:47:38 --> Upload Class Initialized
INFO - 2020-08-29 12:47:38 --> Controller Class Initialized
ERROR - 2020-08-29 12:47:38 --> 404 Page Not Found: /index
INFO - 2020-08-29 13:17:00 --> Config Class Initialized
INFO - 2020-08-29 13:17:00 --> Hooks Class Initialized
DEBUG - 2020-08-29 13:17:00 --> UTF-8 Support Enabled
INFO - 2020-08-29 13:17:00 --> Utf8 Class Initialized
INFO - 2020-08-29 13:17:00 --> URI Class Initialized
DEBUG - 2020-08-29 13:17:00 --> No URI present. Default controller set.
INFO - 2020-08-29 13:17:00 --> Router Class Initialized
INFO - 2020-08-29 13:17:00 --> Output Class Initialized
INFO - 2020-08-29 13:17:00 --> Security Class Initialized
DEBUG - 2020-08-29 13:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 13:17:00 --> Input Class Initialized
INFO - 2020-08-29 13:17:00 --> Language Class Initialized
INFO - 2020-08-29 13:17:00 --> Language Class Initialized
INFO - 2020-08-29 13:17:00 --> Config Class Initialized
INFO - 2020-08-29 13:17:00 --> Loader Class Initialized
INFO - 2020-08-29 13:17:00 --> Helper loaded: url_helper
INFO - 2020-08-29 13:17:00 --> Helper loaded: form_helper
INFO - 2020-08-29 13:17:00 --> Helper loaded: file_helper
INFO - 2020-08-29 13:17:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 13:17:00 --> Database Driver Class Initialized
DEBUG - 2020-08-29 13:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 13:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 13:17:00 --> Upload Class Initialized
INFO - 2020-08-29 13:17:00 --> Controller Class Initialized
DEBUG - 2020-08-29 13:17:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 13:17:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 13:17:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 13:17:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 13:17:00 --> Final output sent to browser
DEBUG - 2020-08-29 13:17:00 --> Total execution time: 0.0550
INFO - 2020-08-29 13:17:02 --> Config Class Initialized
INFO - 2020-08-29 13:17:02 --> Hooks Class Initialized
DEBUG - 2020-08-29 13:17:02 --> UTF-8 Support Enabled
INFO - 2020-08-29 13:17:02 --> Utf8 Class Initialized
INFO - 2020-08-29 13:17:02 --> URI Class Initialized
INFO - 2020-08-29 13:17:02 --> Router Class Initialized
INFO - 2020-08-29 13:17:02 --> Output Class Initialized
INFO - 2020-08-29 13:17:02 --> Security Class Initialized
DEBUG - 2020-08-29 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 13:17:02 --> Input Class Initialized
INFO - 2020-08-29 13:17:02 --> Language Class Initialized
INFO - 2020-08-29 13:17:02 --> Language Class Initialized
INFO - 2020-08-29 13:17:02 --> Config Class Initialized
INFO - 2020-08-29 13:17:02 --> Loader Class Initialized
INFO - 2020-08-29 13:17:02 --> Helper loaded: url_helper
INFO - 2020-08-29 13:17:02 --> Helper loaded: form_helper
INFO - 2020-08-29 13:17:02 --> Helper loaded: file_helper
INFO - 2020-08-29 13:17:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 13:17:02 --> Database Driver Class Initialized
DEBUG - 2020-08-29 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 13:17:02 --> Upload Class Initialized
INFO - 2020-08-29 13:17:02 --> Controller Class Initialized
ERROR - 2020-08-29 13:17:02 --> 404 Page Not Found: /index
INFO - 2020-08-29 13:24:23 --> Config Class Initialized
INFO - 2020-08-29 13:24:23 --> Hooks Class Initialized
DEBUG - 2020-08-29 13:24:23 --> UTF-8 Support Enabled
INFO - 2020-08-29 13:24:23 --> Utf8 Class Initialized
INFO - 2020-08-29 13:24:23 --> URI Class Initialized
DEBUG - 2020-08-29 13:24:23 --> No URI present. Default controller set.
INFO - 2020-08-29 13:24:23 --> Router Class Initialized
INFO - 2020-08-29 13:24:23 --> Output Class Initialized
INFO - 2020-08-29 13:24:23 --> Security Class Initialized
DEBUG - 2020-08-29 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 13:24:23 --> Input Class Initialized
INFO - 2020-08-29 13:24:23 --> Language Class Initialized
INFO - 2020-08-29 13:24:23 --> Language Class Initialized
INFO - 2020-08-29 13:24:23 --> Config Class Initialized
INFO - 2020-08-29 13:24:23 --> Loader Class Initialized
INFO - 2020-08-29 13:24:23 --> Helper loaded: url_helper
INFO - 2020-08-29 13:24:23 --> Helper loaded: form_helper
INFO - 2020-08-29 13:24:23 --> Helper loaded: file_helper
INFO - 2020-08-29 13:24:23 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 13:24:23 --> Database Driver Class Initialized
DEBUG - 2020-08-29 13:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 13:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 13:24:23 --> Upload Class Initialized
INFO - 2020-08-29 13:24:23 --> Controller Class Initialized
DEBUG - 2020-08-29 13:24:23 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 13:24:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 13:24:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 13:24:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 13:24:23 --> Final output sent to browser
DEBUG - 2020-08-29 13:24:23 --> Total execution time: 0.0531
INFO - 2020-08-29 14:09:57 --> Config Class Initialized
INFO - 2020-08-29 14:09:57 --> Hooks Class Initialized
DEBUG - 2020-08-29 14:09:57 --> UTF-8 Support Enabled
INFO - 2020-08-29 14:09:57 --> Utf8 Class Initialized
INFO - 2020-08-29 14:09:57 --> URI Class Initialized
INFO - 2020-08-29 14:09:57 --> Router Class Initialized
INFO - 2020-08-29 14:09:57 --> Output Class Initialized
INFO - 2020-08-29 14:09:57 --> Security Class Initialized
DEBUG - 2020-08-29 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 14:09:57 --> Input Class Initialized
INFO - 2020-08-29 14:09:57 --> Language Class Initialized
INFO - 2020-08-29 14:09:57 --> Language Class Initialized
INFO - 2020-08-29 14:09:57 --> Config Class Initialized
INFO - 2020-08-29 14:09:57 --> Loader Class Initialized
INFO - 2020-08-29 14:09:57 --> Helper loaded: url_helper
INFO - 2020-08-29 14:09:57 --> Helper loaded: form_helper
INFO - 2020-08-29 14:09:57 --> Helper loaded: file_helper
INFO - 2020-08-29 14:09:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 14:09:57 --> Database Driver Class Initialized
DEBUG - 2020-08-29 14:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 14:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 14:09:57 --> Upload Class Initialized
INFO - 2020-08-29 14:09:57 --> Controller Class Initialized
ERROR - 2020-08-29 14:09:57 --> 404 Page Not Found: /index
INFO - 2020-08-29 14:09:57 --> Config Class Initialized
INFO - 2020-08-29 14:09:57 --> Hooks Class Initialized
DEBUG - 2020-08-29 14:09:57 --> UTF-8 Support Enabled
INFO - 2020-08-29 14:09:57 --> Utf8 Class Initialized
INFO - 2020-08-29 14:09:57 --> URI Class Initialized
INFO - 2020-08-29 14:09:57 --> Router Class Initialized
INFO - 2020-08-29 14:09:57 --> Output Class Initialized
INFO - 2020-08-29 14:09:57 --> Security Class Initialized
DEBUG - 2020-08-29 14:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 14:09:57 --> Input Class Initialized
INFO - 2020-08-29 14:09:57 --> Language Class Initialized
INFO - 2020-08-29 14:09:57 --> Language Class Initialized
INFO - 2020-08-29 14:09:57 --> Config Class Initialized
INFO - 2020-08-29 14:09:57 --> Loader Class Initialized
INFO - 2020-08-29 14:09:57 --> Helper loaded: url_helper
INFO - 2020-08-29 14:09:57 --> Helper loaded: form_helper
INFO - 2020-08-29 14:09:57 --> Helper loaded: file_helper
INFO - 2020-08-29 14:09:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 14:09:57 --> Database Driver Class Initialized
DEBUG - 2020-08-29 14:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 14:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 14:09:57 --> Upload Class Initialized
INFO - 2020-08-29 14:09:57 --> Controller Class Initialized
ERROR - 2020-08-29 14:09:57 --> 404 Page Not Found: /index
INFO - 2020-08-29 17:34:36 --> Config Class Initialized
INFO - 2020-08-29 17:34:36 --> Hooks Class Initialized
DEBUG - 2020-08-29 17:34:36 --> UTF-8 Support Enabled
INFO - 2020-08-29 17:34:36 --> Utf8 Class Initialized
INFO - 2020-08-29 17:34:36 --> URI Class Initialized
DEBUG - 2020-08-29 17:34:36 --> No URI present. Default controller set.
INFO - 2020-08-29 17:34:36 --> Router Class Initialized
INFO - 2020-08-29 17:34:36 --> Output Class Initialized
INFO - 2020-08-29 17:34:36 --> Security Class Initialized
DEBUG - 2020-08-29 17:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 17:34:36 --> Input Class Initialized
INFO - 2020-08-29 17:34:36 --> Language Class Initialized
INFO - 2020-08-29 17:34:36 --> Language Class Initialized
INFO - 2020-08-29 17:34:36 --> Config Class Initialized
INFO - 2020-08-29 17:34:36 --> Loader Class Initialized
INFO - 2020-08-29 17:34:36 --> Helper loaded: url_helper
INFO - 2020-08-29 17:34:36 --> Helper loaded: form_helper
INFO - 2020-08-29 17:34:36 --> Helper loaded: file_helper
INFO - 2020-08-29 17:34:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 17:34:36 --> Database Driver Class Initialized
DEBUG - 2020-08-29 17:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 17:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 17:34:36 --> Upload Class Initialized
INFO - 2020-08-29 17:34:36 --> Controller Class Initialized
DEBUG - 2020-08-29 17:34:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 17:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 17:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 17:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 17:34:36 --> Final output sent to browser
DEBUG - 2020-08-29 17:34:36 --> Total execution time: 0.1475
INFO - 2020-08-29 19:24:00 --> Config Class Initialized
INFO - 2020-08-29 19:24:00 --> Hooks Class Initialized
DEBUG - 2020-08-29 19:24:00 --> UTF-8 Support Enabled
INFO - 2020-08-29 19:24:00 --> Utf8 Class Initialized
INFO - 2020-08-29 19:24:00 --> URI Class Initialized
DEBUG - 2020-08-29 19:24:00 --> No URI present. Default controller set.
INFO - 2020-08-29 19:24:00 --> Router Class Initialized
INFO - 2020-08-29 19:24:00 --> Output Class Initialized
INFO - 2020-08-29 19:24:00 --> Security Class Initialized
DEBUG - 2020-08-29 19:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 19:24:00 --> Input Class Initialized
INFO - 2020-08-29 19:24:00 --> Language Class Initialized
INFO - 2020-08-29 19:24:00 --> Language Class Initialized
INFO - 2020-08-29 19:24:00 --> Config Class Initialized
INFO - 2020-08-29 19:24:00 --> Loader Class Initialized
INFO - 2020-08-29 19:24:00 --> Helper loaded: url_helper
INFO - 2020-08-29 19:24:00 --> Helper loaded: form_helper
INFO - 2020-08-29 19:24:00 --> Helper loaded: file_helper
INFO - 2020-08-29 19:24:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 19:24:00 --> Database Driver Class Initialized
DEBUG - 2020-08-29 19:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 19:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 19:24:00 --> Upload Class Initialized
INFO - 2020-08-29 19:24:00 --> Controller Class Initialized
DEBUG - 2020-08-29 19:24:00 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 19:24:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 19:24:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 19:24:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 19:24:00 --> Final output sent to browser
DEBUG - 2020-08-29 19:24:00 --> Total execution time: 0.0534
INFO - 2020-08-29 20:01:17 --> Config Class Initialized
INFO - 2020-08-29 20:01:17 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:01:17 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:01:17 --> Utf8 Class Initialized
INFO - 2020-08-29 20:01:17 --> URI Class Initialized
INFO - 2020-08-29 20:01:17 --> Router Class Initialized
INFO - 2020-08-29 20:01:17 --> Output Class Initialized
INFO - 2020-08-29 20:01:17 --> Security Class Initialized
DEBUG - 2020-08-29 20:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:01:17 --> Input Class Initialized
INFO - 2020-08-29 20:01:17 --> Language Class Initialized
INFO - 2020-08-29 20:01:17 --> Language Class Initialized
INFO - 2020-08-29 20:01:17 --> Config Class Initialized
INFO - 2020-08-29 20:01:17 --> Loader Class Initialized
INFO - 2020-08-29 20:01:17 --> Helper loaded: url_helper
INFO - 2020-08-29 20:01:17 --> Helper loaded: form_helper
INFO - 2020-08-29 20:01:17 --> Helper loaded: file_helper
INFO - 2020-08-29 20:01:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:01:17 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:01:17 --> Upload Class Initialized
INFO - 2020-08-29 20:01:17 --> Controller Class Initialized
ERROR - 2020-08-29 20:01:17 --> 404 Page Not Found: /index
INFO - 2020-08-29 20:01:20 --> Config Class Initialized
INFO - 2020-08-29 20:01:20 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:01:20 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:01:20 --> Utf8 Class Initialized
INFO - 2020-08-29 20:01:20 --> URI Class Initialized
INFO - 2020-08-29 20:01:20 --> Router Class Initialized
INFO - 2020-08-29 20:01:20 --> Output Class Initialized
INFO - 2020-08-29 20:01:20 --> Security Class Initialized
DEBUG - 2020-08-29 20:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:01:20 --> Input Class Initialized
INFO - 2020-08-29 20:01:20 --> Language Class Initialized
INFO - 2020-08-29 20:01:20 --> Language Class Initialized
INFO - 2020-08-29 20:01:20 --> Config Class Initialized
INFO - 2020-08-29 20:01:20 --> Loader Class Initialized
INFO - 2020-08-29 20:01:20 --> Helper loaded: url_helper
INFO - 2020-08-29 20:01:20 --> Helper loaded: form_helper
INFO - 2020-08-29 20:01:20 --> Helper loaded: file_helper
INFO - 2020-08-29 20:01:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:01:20 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:01:20 --> Upload Class Initialized
INFO - 2020-08-29 20:01:20 --> Controller Class Initialized
ERROR - 2020-08-29 20:01:20 --> 404 Page Not Found: /index
INFO - 2020-08-29 20:01:22 --> Config Class Initialized
INFO - 2020-08-29 20:01:22 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:01:22 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:01:22 --> Utf8 Class Initialized
INFO - 2020-08-29 20:01:22 --> URI Class Initialized
INFO - 2020-08-29 20:01:22 --> Router Class Initialized
INFO - 2020-08-29 20:01:22 --> Output Class Initialized
INFO - 2020-08-29 20:01:22 --> Security Class Initialized
DEBUG - 2020-08-29 20:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:01:22 --> Input Class Initialized
INFO - 2020-08-29 20:01:22 --> Language Class Initialized
INFO - 2020-08-29 20:01:22 --> Language Class Initialized
INFO - 2020-08-29 20:01:22 --> Config Class Initialized
INFO - 2020-08-29 20:01:22 --> Loader Class Initialized
INFO - 2020-08-29 20:01:22 --> Helper loaded: url_helper
INFO - 2020-08-29 20:01:22 --> Helper loaded: form_helper
INFO - 2020-08-29 20:01:22 --> Helper loaded: file_helper
INFO - 2020-08-29 20:01:22 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:01:22 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:01:22 --> Upload Class Initialized
INFO - 2020-08-29 20:01:22 --> Controller Class Initialized
ERROR - 2020-08-29 20:01:22 --> 404 Page Not Found: /index
INFO - 2020-08-29 20:01:24 --> Config Class Initialized
INFO - 2020-08-29 20:01:24 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:01:24 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:01:24 --> Utf8 Class Initialized
INFO - 2020-08-29 20:01:24 --> URI Class Initialized
INFO - 2020-08-29 20:01:24 --> Router Class Initialized
INFO - 2020-08-29 20:01:24 --> Output Class Initialized
INFO - 2020-08-29 20:01:24 --> Security Class Initialized
DEBUG - 2020-08-29 20:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:01:24 --> Input Class Initialized
INFO - 2020-08-29 20:01:24 --> Language Class Initialized
INFO - 2020-08-29 20:01:24 --> Language Class Initialized
INFO - 2020-08-29 20:01:24 --> Config Class Initialized
INFO - 2020-08-29 20:01:24 --> Loader Class Initialized
INFO - 2020-08-29 20:01:24 --> Helper loaded: url_helper
INFO - 2020-08-29 20:01:24 --> Helper loaded: form_helper
INFO - 2020-08-29 20:01:24 --> Helper loaded: file_helper
INFO - 2020-08-29 20:01:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:01:24 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:01:24 --> Upload Class Initialized
INFO - 2020-08-29 20:01:24 --> Controller Class Initialized
ERROR - 2020-08-29 20:01:24 --> 404 Page Not Found: /index
INFO - 2020-08-29 20:01:25 --> Config Class Initialized
INFO - 2020-08-29 20:01:25 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:01:25 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:01:25 --> Utf8 Class Initialized
INFO - 2020-08-29 20:01:25 --> URI Class Initialized
INFO - 2020-08-29 20:01:25 --> Router Class Initialized
INFO - 2020-08-29 20:01:25 --> Output Class Initialized
INFO - 2020-08-29 20:01:25 --> Security Class Initialized
DEBUG - 2020-08-29 20:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:01:25 --> Input Class Initialized
INFO - 2020-08-29 20:01:25 --> Language Class Initialized
INFO - 2020-08-29 20:01:25 --> Language Class Initialized
INFO - 2020-08-29 20:01:25 --> Config Class Initialized
INFO - 2020-08-29 20:01:25 --> Loader Class Initialized
INFO - 2020-08-29 20:01:25 --> Helper loaded: url_helper
INFO - 2020-08-29 20:01:25 --> Helper loaded: form_helper
INFO - 2020-08-29 20:01:25 --> Helper loaded: file_helper
INFO - 2020-08-29 20:01:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:01:25 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:01:25 --> Upload Class Initialized
INFO - 2020-08-29 20:01:25 --> Controller Class Initialized
ERROR - 2020-08-29 20:01:25 --> 404 Page Not Found: /index
INFO - 2020-08-29 20:01:27 --> Config Class Initialized
INFO - 2020-08-29 20:01:27 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:01:27 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:01:27 --> Utf8 Class Initialized
INFO - 2020-08-29 20:01:27 --> URI Class Initialized
INFO - 2020-08-29 20:01:27 --> Router Class Initialized
INFO - 2020-08-29 20:01:27 --> Output Class Initialized
INFO - 2020-08-29 20:01:27 --> Security Class Initialized
DEBUG - 2020-08-29 20:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:01:27 --> Input Class Initialized
INFO - 2020-08-29 20:01:27 --> Language Class Initialized
INFO - 2020-08-29 20:01:27 --> Language Class Initialized
INFO - 2020-08-29 20:01:27 --> Config Class Initialized
INFO - 2020-08-29 20:01:27 --> Loader Class Initialized
INFO - 2020-08-29 20:01:27 --> Helper loaded: url_helper
INFO - 2020-08-29 20:01:27 --> Helper loaded: form_helper
INFO - 2020-08-29 20:01:27 --> Helper loaded: file_helper
INFO - 2020-08-29 20:01:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:01:27 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:01:27 --> Upload Class Initialized
INFO - 2020-08-29 20:01:27 --> Controller Class Initialized
ERROR - 2020-08-29 20:01:27 --> 404 Page Not Found: /index
INFO - 2020-08-29 20:38:59 --> Config Class Initialized
INFO - 2020-08-29 20:38:59 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:38:59 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:38:59 --> Utf8 Class Initialized
INFO - 2020-08-29 20:38:59 --> URI Class Initialized
DEBUG - 2020-08-29 20:38:59 --> No URI present. Default controller set.
INFO - 2020-08-29 20:38:59 --> Router Class Initialized
INFO - 2020-08-29 20:38:59 --> Output Class Initialized
INFO - 2020-08-29 20:38:59 --> Security Class Initialized
DEBUG - 2020-08-29 20:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:38:59 --> Input Class Initialized
INFO - 2020-08-29 20:38:59 --> Language Class Initialized
INFO - 2020-08-29 20:38:59 --> Language Class Initialized
INFO - 2020-08-29 20:38:59 --> Config Class Initialized
INFO - 2020-08-29 20:38:59 --> Loader Class Initialized
INFO - 2020-08-29 20:38:59 --> Helper loaded: url_helper
INFO - 2020-08-29 20:38:59 --> Helper loaded: form_helper
INFO - 2020-08-29 20:38:59 --> Helper loaded: file_helper
INFO - 2020-08-29 20:38:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:38:59 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:38:59 --> Upload Class Initialized
INFO - 2020-08-29 20:38:59 --> Controller Class Initialized
DEBUG - 2020-08-29 20:38:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 20:38:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 20:38:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 20:38:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 20:38:59 --> Final output sent to browser
DEBUG - 2020-08-29 20:38:59 --> Total execution time: 0.0508
INFO - 2020-08-29 20:39:02 --> Config Class Initialized
INFO - 2020-08-29 20:39:02 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:39:02 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:39:02 --> Utf8 Class Initialized
INFO - 2020-08-29 20:39:02 --> URI Class Initialized
INFO - 2020-08-29 20:39:02 --> Router Class Initialized
INFO - 2020-08-29 20:39:02 --> Output Class Initialized
INFO - 2020-08-29 20:39:02 --> Security Class Initialized
DEBUG - 2020-08-29 20:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:39:02 --> Input Class Initialized
INFO - 2020-08-29 20:39:02 --> Language Class Initialized
INFO - 2020-08-29 20:39:02 --> Language Class Initialized
INFO - 2020-08-29 20:39:02 --> Config Class Initialized
INFO - 2020-08-29 20:39:02 --> Loader Class Initialized
INFO - 2020-08-29 20:39:02 --> Helper loaded: url_helper
INFO - 2020-08-29 20:39:02 --> Helper loaded: form_helper
INFO - 2020-08-29 20:39:02 --> Helper loaded: file_helper
INFO - 2020-08-29 20:39:02 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:39:02 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:39:02 --> Upload Class Initialized
INFO - 2020-08-29 20:39:02 --> Controller Class Initialized
DEBUG - 2020-08-29 20:39:02 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 20:39:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 20:39:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 20:39:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 20:39:02 --> Final output sent to browser
DEBUG - 2020-08-29 20:39:02 --> Total execution time: 0.2250
INFO - 2020-08-29 20:39:31 --> Config Class Initialized
INFO - 2020-08-29 20:39:31 --> Hooks Class Initialized
DEBUG - 2020-08-29 20:39:31 --> UTF-8 Support Enabled
INFO - 2020-08-29 20:39:31 --> Utf8 Class Initialized
INFO - 2020-08-29 20:39:31 --> URI Class Initialized
INFO - 2020-08-29 20:39:31 --> Router Class Initialized
INFO - 2020-08-29 20:39:31 --> Output Class Initialized
INFO - 2020-08-29 20:39:31 --> Security Class Initialized
DEBUG - 2020-08-29 20:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 20:39:31 --> Input Class Initialized
INFO - 2020-08-29 20:39:31 --> Language Class Initialized
INFO - 2020-08-29 20:39:31 --> Language Class Initialized
INFO - 2020-08-29 20:39:31 --> Config Class Initialized
INFO - 2020-08-29 20:39:31 --> Loader Class Initialized
INFO - 2020-08-29 20:39:31 --> Helper loaded: url_helper
INFO - 2020-08-29 20:39:31 --> Helper loaded: form_helper
INFO - 2020-08-29 20:39:31 --> Helper loaded: file_helper
INFO - 2020-08-29 20:39:31 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 20:39:31 --> Database Driver Class Initialized
DEBUG - 2020-08-29 20:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 20:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 20:39:31 --> Upload Class Initialized
INFO - 2020-08-29 20:39:31 --> Controller Class Initialized
ERROR - 2020-08-29 20:39:31 --> 404 Page Not Found: /index
INFO - 2020-08-29 22:19:08 --> Config Class Initialized
INFO - 2020-08-29 22:19:08 --> Hooks Class Initialized
DEBUG - 2020-08-29 22:19:08 --> UTF-8 Support Enabled
INFO - 2020-08-29 22:19:08 --> Utf8 Class Initialized
INFO - 2020-08-29 22:19:08 --> URI Class Initialized
INFO - 2020-08-29 22:19:08 --> Router Class Initialized
INFO - 2020-08-29 22:19:08 --> Output Class Initialized
INFO - 2020-08-29 22:19:08 --> Security Class Initialized
DEBUG - 2020-08-29 22:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 22:19:08 --> Input Class Initialized
INFO - 2020-08-29 22:19:08 --> Language Class Initialized
INFO - 2020-08-29 22:19:08 --> Language Class Initialized
INFO - 2020-08-29 22:19:08 --> Config Class Initialized
INFO - 2020-08-29 22:19:08 --> Loader Class Initialized
INFO - 2020-08-29 22:19:08 --> Helper loaded: url_helper
INFO - 2020-08-29 22:19:08 --> Helper loaded: form_helper
INFO - 2020-08-29 22:19:08 --> Helper loaded: file_helper
INFO - 2020-08-29 22:19:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 22:19:08 --> Database Driver Class Initialized
DEBUG - 2020-08-29 22:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 22:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 22:19:08 --> Upload Class Initialized
INFO - 2020-08-29 22:19:08 --> Controller Class Initialized
ERROR - 2020-08-29 22:19:08 --> 404 Page Not Found: /index
INFO - 2020-08-29 23:41:50 --> Config Class Initialized
INFO - 2020-08-29 23:41:50 --> Hooks Class Initialized
DEBUG - 2020-08-29 23:41:50 --> UTF-8 Support Enabled
INFO - 2020-08-29 23:41:50 --> Utf8 Class Initialized
INFO - 2020-08-29 23:41:50 --> URI Class Initialized
INFO - 2020-08-29 23:41:50 --> Router Class Initialized
INFO - 2020-08-29 23:41:50 --> Output Class Initialized
INFO - 2020-08-29 23:41:50 --> Security Class Initialized
DEBUG - 2020-08-29 23:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 23:41:50 --> Input Class Initialized
INFO - 2020-08-29 23:41:50 --> Language Class Initialized
INFO - 2020-08-29 23:41:50 --> Language Class Initialized
INFO - 2020-08-29 23:41:50 --> Config Class Initialized
INFO - 2020-08-29 23:41:50 --> Loader Class Initialized
INFO - 2020-08-29 23:41:50 --> Helper loaded: url_helper
INFO - 2020-08-29 23:41:50 --> Helper loaded: form_helper
INFO - 2020-08-29 23:41:50 --> Helper loaded: file_helper
INFO - 2020-08-29 23:41:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 23:41:50 --> Database Driver Class Initialized
DEBUG - 2020-08-29 23:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 23:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 23:41:50 --> Upload Class Initialized
INFO - 2020-08-29 23:41:50 --> Controller Class Initialized
ERROR - 2020-08-29 23:41:50 --> 404 Page Not Found: /index
INFO - 2020-08-29 23:41:51 --> Config Class Initialized
INFO - 2020-08-29 23:41:51 --> Hooks Class Initialized
DEBUG - 2020-08-29 23:41:51 --> UTF-8 Support Enabled
INFO - 2020-08-29 23:41:51 --> Utf8 Class Initialized
INFO - 2020-08-29 23:41:51 --> URI Class Initialized
INFO - 2020-08-29 23:41:51 --> Router Class Initialized
INFO - 2020-08-29 23:41:51 --> Output Class Initialized
INFO - 2020-08-29 23:41:51 --> Security Class Initialized
DEBUG - 2020-08-29 23:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 23:41:51 --> Input Class Initialized
INFO - 2020-08-29 23:41:51 --> Language Class Initialized
INFO - 2020-08-29 23:41:51 --> Language Class Initialized
INFO - 2020-08-29 23:41:51 --> Config Class Initialized
INFO - 2020-08-29 23:41:51 --> Loader Class Initialized
INFO - 2020-08-29 23:41:51 --> Helper loaded: url_helper
INFO - 2020-08-29 23:41:51 --> Helper loaded: form_helper
INFO - 2020-08-29 23:41:51 --> Helper loaded: file_helper
INFO - 2020-08-29 23:41:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 23:41:51 --> Database Driver Class Initialized
DEBUG - 2020-08-29 23:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 23:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 23:41:51 --> Upload Class Initialized
INFO - 2020-08-29 23:41:51 --> Controller Class Initialized
ERROR - 2020-08-29 23:41:51 --> 404 Page Not Found: /index
INFO - 2020-08-29 23:42:31 --> Config Class Initialized
INFO - 2020-08-29 23:42:31 --> Hooks Class Initialized
DEBUG - 2020-08-29 23:42:31 --> UTF-8 Support Enabled
INFO - 2020-08-29 23:42:31 --> Utf8 Class Initialized
INFO - 2020-08-29 23:42:31 --> URI Class Initialized
DEBUG - 2020-08-29 23:42:32 --> No URI present. Default controller set.
INFO - 2020-08-29 23:42:32 --> Router Class Initialized
INFO - 2020-08-29 23:42:32 --> Output Class Initialized
INFO - 2020-08-29 23:42:32 --> Security Class Initialized
DEBUG - 2020-08-29 23:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 23:42:32 --> Input Class Initialized
INFO - 2020-08-29 23:42:32 --> Language Class Initialized
INFO - 2020-08-29 23:42:32 --> Language Class Initialized
INFO - 2020-08-29 23:42:32 --> Config Class Initialized
INFO - 2020-08-29 23:42:32 --> Loader Class Initialized
INFO - 2020-08-29 23:42:32 --> Helper loaded: url_helper
INFO - 2020-08-29 23:42:32 --> Helper loaded: form_helper
INFO - 2020-08-29 23:42:32 --> Helper loaded: file_helper
INFO - 2020-08-29 23:42:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 23:42:32 --> Database Driver Class Initialized
DEBUG - 2020-08-29 23:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 23:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 23:42:32 --> Upload Class Initialized
INFO - 2020-08-29 23:42:32 --> Controller Class Initialized
DEBUG - 2020-08-29 23:42:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 23:42:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 23:42:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 23:42:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 23:42:32 --> Final output sent to browser
DEBUG - 2020-08-29 23:42:32 --> Total execution time: 0.0663
INFO - 2020-08-29 23:43:29 --> Config Class Initialized
INFO - 2020-08-29 23:43:29 --> Hooks Class Initialized
DEBUG - 2020-08-29 23:43:29 --> UTF-8 Support Enabled
INFO - 2020-08-29 23:43:29 --> Utf8 Class Initialized
INFO - 2020-08-29 23:43:29 --> URI Class Initialized
DEBUG - 2020-08-29 23:43:29 --> No URI present. Default controller set.
INFO - 2020-08-29 23:43:29 --> Router Class Initialized
INFO - 2020-08-29 23:43:29 --> Output Class Initialized
INFO - 2020-08-29 23:43:29 --> Security Class Initialized
DEBUG - 2020-08-29 23:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 23:43:29 --> Input Class Initialized
INFO - 2020-08-29 23:43:29 --> Language Class Initialized
INFO - 2020-08-29 23:43:29 --> Language Class Initialized
INFO - 2020-08-29 23:43:29 --> Config Class Initialized
INFO - 2020-08-29 23:43:29 --> Loader Class Initialized
INFO - 2020-08-29 23:43:29 --> Helper loaded: url_helper
INFO - 2020-08-29 23:43:29 --> Helper loaded: form_helper
INFO - 2020-08-29 23:43:29 --> Helper loaded: file_helper
INFO - 2020-08-29 23:43:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 23:43:29 --> Database Driver Class Initialized
DEBUG - 2020-08-29 23:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 23:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 23:43:29 --> Upload Class Initialized
INFO - 2020-08-29 23:43:29 --> Controller Class Initialized
DEBUG - 2020-08-29 23:43:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-29 23:43:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-29 23:43:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-29 23:43:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-29 23:43:29 --> Final output sent to browser
DEBUG - 2020-08-29 23:43:29 --> Total execution time: 0.0491
INFO - 2020-08-29 23:51:04 --> Config Class Initialized
INFO - 2020-08-29 23:51:04 --> Hooks Class Initialized
DEBUG - 2020-08-29 23:51:04 --> UTF-8 Support Enabled
INFO - 2020-08-29 23:51:04 --> Utf8 Class Initialized
INFO - 2020-08-29 23:51:04 --> URI Class Initialized
INFO - 2020-08-29 23:51:04 --> Router Class Initialized
INFO - 2020-08-29 23:51:04 --> Output Class Initialized
INFO - 2020-08-29 23:51:04 --> Security Class Initialized
DEBUG - 2020-08-29 23:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-29 23:51:04 --> Input Class Initialized
INFO - 2020-08-29 23:51:04 --> Language Class Initialized
INFO - 2020-08-29 23:51:04 --> Language Class Initialized
INFO - 2020-08-29 23:51:04 --> Config Class Initialized
INFO - 2020-08-29 23:51:04 --> Loader Class Initialized
INFO - 2020-08-29 23:51:04 --> Helper loaded: url_helper
INFO - 2020-08-29 23:51:04 --> Helper loaded: form_helper
INFO - 2020-08-29 23:51:04 --> Helper loaded: file_helper
INFO - 2020-08-29 23:51:04 --> Helper loaded: myhelper_helper
INFO - 2020-08-29 23:51:04 --> Database Driver Class Initialized
DEBUG - 2020-08-29 23:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-29 23:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-29 23:51:04 --> Upload Class Initialized
INFO - 2020-08-29 23:51:04 --> Controller Class Initialized
ERROR - 2020-08-29 23:51:04 --> 404 Page Not Found: /index
