<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-30 00:48:19 --> Config Class Initialized
INFO - 2020-08-30 00:48:19 --> Hooks Class Initialized
DEBUG - 2020-08-30 00:48:19 --> UTF-8 Support Enabled
INFO - 2020-08-30 00:48:19 --> Utf8 Class Initialized
INFO - 2020-08-30 00:48:19 --> URI Class Initialized
INFO - 2020-08-30 00:48:19 --> Router Class Initialized
INFO - 2020-08-30 00:48:19 --> Output Class Initialized
INFO - 2020-08-30 00:48:19 --> Security Class Initialized
DEBUG - 2020-08-30 00:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 00:48:19 --> Input Class Initialized
INFO - 2020-08-30 00:48:19 --> Language Class Initialized
INFO - 2020-08-30 00:48:19 --> Language Class Initialized
INFO - 2020-08-30 00:48:19 --> Config Class Initialized
INFO - 2020-08-30 00:48:19 --> Loader Class Initialized
INFO - 2020-08-30 00:48:19 --> Helper loaded: url_helper
INFO - 2020-08-30 00:48:19 --> Helper loaded: form_helper
INFO - 2020-08-30 00:48:19 --> Helper loaded: file_helper
INFO - 2020-08-30 00:48:19 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 00:48:19 --> Database Driver Class Initialized
DEBUG - 2020-08-30 00:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 00:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 00:48:19 --> Upload Class Initialized
INFO - 2020-08-30 00:48:19 --> Controller Class Initialized
ERROR - 2020-08-30 00:48:19 --> 404 Page Not Found: /index
INFO - 2020-08-30 00:48:21 --> Config Class Initialized
INFO - 2020-08-30 00:48:21 --> Hooks Class Initialized
DEBUG - 2020-08-30 00:48:21 --> UTF-8 Support Enabled
INFO - 2020-08-30 00:48:21 --> Utf8 Class Initialized
INFO - 2020-08-30 00:48:21 --> URI Class Initialized
INFO - 2020-08-30 00:48:21 --> Router Class Initialized
INFO - 2020-08-30 00:48:21 --> Output Class Initialized
INFO - 2020-08-30 00:48:21 --> Security Class Initialized
DEBUG - 2020-08-30 00:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 00:48:21 --> Input Class Initialized
INFO - 2020-08-30 00:48:21 --> Language Class Initialized
INFO - 2020-08-30 00:48:21 --> Language Class Initialized
INFO - 2020-08-30 00:48:21 --> Config Class Initialized
INFO - 2020-08-30 00:48:21 --> Loader Class Initialized
INFO - 2020-08-30 00:48:21 --> Helper loaded: url_helper
INFO - 2020-08-30 00:48:21 --> Helper loaded: form_helper
INFO - 2020-08-30 00:48:21 --> Helper loaded: file_helper
INFO - 2020-08-30 00:48:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 00:48:21 --> Database Driver Class Initialized
DEBUG - 2020-08-30 00:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 00:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 00:48:21 --> Upload Class Initialized
INFO - 2020-08-30 00:48:21 --> Controller Class Initialized
ERROR - 2020-08-30 00:48:21 --> 404 Page Not Found: /index
INFO - 2020-08-30 01:28:09 --> Config Class Initialized
INFO - 2020-08-30 01:28:09 --> Hooks Class Initialized
DEBUG - 2020-08-30 01:28:09 --> UTF-8 Support Enabled
INFO - 2020-08-30 01:28:09 --> Utf8 Class Initialized
INFO - 2020-08-30 01:28:09 --> URI Class Initialized
DEBUG - 2020-08-30 01:28:09 --> No URI present. Default controller set.
INFO - 2020-08-30 01:28:09 --> Router Class Initialized
INFO - 2020-08-30 01:28:09 --> Output Class Initialized
INFO - 2020-08-30 01:28:09 --> Security Class Initialized
DEBUG - 2020-08-30 01:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 01:28:09 --> Input Class Initialized
INFO - 2020-08-30 01:28:09 --> Language Class Initialized
INFO - 2020-08-30 01:28:09 --> Language Class Initialized
INFO - 2020-08-30 01:28:09 --> Config Class Initialized
INFO - 2020-08-30 01:28:09 --> Loader Class Initialized
INFO - 2020-08-30 01:28:09 --> Helper loaded: url_helper
INFO - 2020-08-30 01:28:09 --> Helper loaded: form_helper
INFO - 2020-08-30 01:28:09 --> Helper loaded: file_helper
INFO - 2020-08-30 01:28:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 01:28:09 --> Database Driver Class Initialized
DEBUG - 2020-08-30 01:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 01:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 01:28:09 --> Upload Class Initialized
INFO - 2020-08-30 01:28:09 --> Controller Class Initialized
DEBUG - 2020-08-30 01:28:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 01:28:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 01:28:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 01:28:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 01:28:09 --> Final output sent to browser
DEBUG - 2020-08-30 01:28:09 --> Total execution time: 0.0514
INFO - 2020-08-30 01:28:10 --> Config Class Initialized
INFO - 2020-08-30 01:28:10 --> Hooks Class Initialized
DEBUG - 2020-08-30 01:28:10 --> UTF-8 Support Enabled
INFO - 2020-08-30 01:28:10 --> Utf8 Class Initialized
INFO - 2020-08-30 01:28:10 --> URI Class Initialized
INFO - 2020-08-30 01:28:10 --> Router Class Initialized
INFO - 2020-08-30 01:28:10 --> Output Class Initialized
INFO - 2020-08-30 01:28:10 --> Security Class Initialized
DEBUG - 2020-08-30 01:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 01:28:10 --> Input Class Initialized
INFO - 2020-08-30 01:28:10 --> Language Class Initialized
INFO - 2020-08-30 01:28:10 --> Language Class Initialized
INFO - 2020-08-30 01:28:10 --> Config Class Initialized
INFO - 2020-08-30 01:28:10 --> Loader Class Initialized
INFO - 2020-08-30 01:28:10 --> Helper loaded: url_helper
INFO - 2020-08-30 01:28:10 --> Helper loaded: form_helper
INFO - 2020-08-30 01:28:10 --> Helper loaded: file_helper
INFO - 2020-08-30 01:28:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 01:28:10 --> Database Driver Class Initialized
DEBUG - 2020-08-30 01:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 01:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 01:28:10 --> Upload Class Initialized
INFO - 2020-08-30 01:28:10 --> Controller Class Initialized
ERROR - 2020-08-30 01:28:10 --> 404 Page Not Found: /index
INFO - 2020-08-30 01:28:11 --> Config Class Initialized
INFO - 2020-08-30 01:28:11 --> Hooks Class Initialized
DEBUG - 2020-08-30 01:28:11 --> UTF-8 Support Enabled
INFO - 2020-08-30 01:28:11 --> Utf8 Class Initialized
INFO - 2020-08-30 01:28:11 --> URI Class Initialized
DEBUG - 2020-08-30 01:28:11 --> No URI present. Default controller set.
INFO - 2020-08-30 01:28:11 --> Router Class Initialized
INFO - 2020-08-30 01:28:11 --> Output Class Initialized
INFO - 2020-08-30 01:28:11 --> Security Class Initialized
DEBUG - 2020-08-30 01:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 01:28:11 --> Input Class Initialized
INFO - 2020-08-30 01:28:11 --> Language Class Initialized
INFO - 2020-08-30 01:28:11 --> Language Class Initialized
INFO - 2020-08-30 01:28:11 --> Config Class Initialized
INFO - 2020-08-30 01:28:11 --> Loader Class Initialized
INFO - 2020-08-30 01:28:11 --> Helper loaded: url_helper
INFO - 2020-08-30 01:28:11 --> Helper loaded: form_helper
INFO - 2020-08-30 01:28:11 --> Helper loaded: file_helper
INFO - 2020-08-30 01:28:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 01:28:11 --> Database Driver Class Initialized
DEBUG - 2020-08-30 01:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 01:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 01:28:11 --> Upload Class Initialized
INFO - 2020-08-30 01:28:11 --> Controller Class Initialized
DEBUG - 2020-08-30 01:28:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 01:28:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 01:28:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 01:28:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 01:28:11 --> Final output sent to browser
DEBUG - 2020-08-30 01:28:11 --> Total execution time: 0.0508
INFO - 2020-08-30 04:16:52 --> Config Class Initialized
INFO - 2020-08-30 04:16:52 --> Hooks Class Initialized
DEBUG - 2020-08-30 04:16:52 --> UTF-8 Support Enabled
INFO - 2020-08-30 04:16:52 --> Utf8 Class Initialized
INFO - 2020-08-30 04:16:52 --> URI Class Initialized
DEBUG - 2020-08-30 04:16:52 --> No URI present. Default controller set.
INFO - 2020-08-30 04:16:52 --> Router Class Initialized
INFO - 2020-08-30 04:16:52 --> Output Class Initialized
INFO - 2020-08-30 04:16:52 --> Security Class Initialized
DEBUG - 2020-08-30 04:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 04:16:52 --> Input Class Initialized
INFO - 2020-08-30 04:16:52 --> Language Class Initialized
INFO - 2020-08-30 04:16:52 --> Language Class Initialized
INFO - 2020-08-30 04:16:52 --> Config Class Initialized
INFO - 2020-08-30 04:16:52 --> Loader Class Initialized
INFO - 2020-08-30 04:16:52 --> Helper loaded: url_helper
INFO - 2020-08-30 04:16:52 --> Helper loaded: form_helper
INFO - 2020-08-30 04:16:52 --> Helper loaded: file_helper
INFO - 2020-08-30 04:16:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 04:16:52 --> Database Driver Class Initialized
DEBUG - 2020-08-30 04:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 04:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 04:16:52 --> Upload Class Initialized
INFO - 2020-08-30 04:16:52 --> Controller Class Initialized
DEBUG - 2020-08-30 04:16:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 04:16:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 04:16:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 04:16:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 04:16:52 --> Final output sent to browser
DEBUG - 2020-08-30 04:16:52 --> Total execution time: 0.0531
INFO - 2020-08-30 05:16:10 --> Config Class Initialized
INFO - 2020-08-30 05:16:10 --> Hooks Class Initialized
DEBUG - 2020-08-30 05:16:10 --> UTF-8 Support Enabled
INFO - 2020-08-30 05:16:10 --> Utf8 Class Initialized
INFO - 2020-08-30 05:16:10 --> URI Class Initialized
DEBUG - 2020-08-30 05:16:10 --> No URI present. Default controller set.
INFO - 2020-08-30 05:16:10 --> Router Class Initialized
INFO - 2020-08-30 05:16:10 --> Output Class Initialized
INFO - 2020-08-30 05:16:10 --> Security Class Initialized
DEBUG - 2020-08-30 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 05:16:10 --> Input Class Initialized
INFO - 2020-08-30 05:16:10 --> Language Class Initialized
INFO - 2020-08-30 05:16:10 --> Language Class Initialized
INFO - 2020-08-30 05:16:10 --> Config Class Initialized
INFO - 2020-08-30 05:16:10 --> Loader Class Initialized
INFO - 2020-08-30 05:16:10 --> Helper loaded: url_helper
INFO - 2020-08-30 05:16:10 --> Helper loaded: form_helper
INFO - 2020-08-30 05:16:10 --> Helper loaded: file_helper
INFO - 2020-08-30 05:16:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 05:16:10 --> Database Driver Class Initialized
DEBUG - 2020-08-30 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 05:16:10 --> Upload Class Initialized
INFO - 2020-08-30 05:16:10 --> Controller Class Initialized
DEBUG - 2020-08-30 05:16:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 05:16:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 05:16:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 05:16:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 05:16:10 --> Final output sent to browser
DEBUG - 2020-08-30 05:16:10 --> Total execution time: 0.0531
INFO - 2020-08-30 06:09:48 --> Config Class Initialized
INFO - 2020-08-30 06:09:48 --> Hooks Class Initialized
DEBUG - 2020-08-30 06:09:48 --> UTF-8 Support Enabled
INFO - 2020-08-30 06:09:48 --> Utf8 Class Initialized
INFO - 2020-08-30 06:09:48 --> URI Class Initialized
DEBUG - 2020-08-30 06:09:48 --> No URI present. Default controller set.
INFO - 2020-08-30 06:09:48 --> Router Class Initialized
INFO - 2020-08-30 06:09:48 --> Output Class Initialized
INFO - 2020-08-30 06:09:48 --> Security Class Initialized
DEBUG - 2020-08-30 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 06:09:48 --> Input Class Initialized
INFO - 2020-08-30 06:09:48 --> Language Class Initialized
INFO - 2020-08-30 06:09:48 --> Language Class Initialized
INFO - 2020-08-30 06:09:48 --> Config Class Initialized
INFO - 2020-08-30 06:09:48 --> Loader Class Initialized
INFO - 2020-08-30 06:09:48 --> Helper loaded: url_helper
INFO - 2020-08-30 06:09:48 --> Helper loaded: form_helper
INFO - 2020-08-30 06:09:48 --> Helper loaded: file_helper
INFO - 2020-08-30 06:09:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 06:09:48 --> Database Driver Class Initialized
DEBUG - 2020-08-30 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 06:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 06:09:48 --> Upload Class Initialized
INFO - 2020-08-30 06:09:48 --> Controller Class Initialized
DEBUG - 2020-08-30 06:09:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 06:09:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 06:09:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 06:09:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 06:09:48 --> Final output sent to browser
DEBUG - 2020-08-30 06:09:48 --> Total execution time: 0.0506
INFO - 2020-08-30 07:31:47 --> Config Class Initialized
INFO - 2020-08-30 07:31:47 --> Hooks Class Initialized
DEBUG - 2020-08-30 07:31:47 --> UTF-8 Support Enabled
INFO - 2020-08-30 07:31:47 --> Utf8 Class Initialized
INFO - 2020-08-30 07:31:47 --> URI Class Initialized
DEBUG - 2020-08-30 07:31:47 --> No URI present. Default controller set.
INFO - 2020-08-30 07:31:47 --> Router Class Initialized
INFO - 2020-08-30 07:31:47 --> Output Class Initialized
INFO - 2020-08-30 07:31:47 --> Security Class Initialized
DEBUG - 2020-08-30 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 07:31:47 --> Input Class Initialized
INFO - 2020-08-30 07:31:47 --> Language Class Initialized
INFO - 2020-08-30 07:31:47 --> Language Class Initialized
INFO - 2020-08-30 07:31:47 --> Config Class Initialized
INFO - 2020-08-30 07:31:47 --> Loader Class Initialized
INFO - 2020-08-30 07:31:47 --> Helper loaded: url_helper
INFO - 2020-08-30 07:31:47 --> Helper loaded: form_helper
INFO - 2020-08-30 07:31:47 --> Helper loaded: file_helper
INFO - 2020-08-30 07:31:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 07:31:47 --> Database Driver Class Initialized
DEBUG - 2020-08-30 07:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 07:31:47 --> Upload Class Initialized
INFO - 2020-08-30 07:31:47 --> Controller Class Initialized
DEBUG - 2020-08-30 07:31:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 07:31:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 07:31:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 07:31:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 07:31:47 --> Final output sent to browser
DEBUG - 2020-08-30 07:31:47 --> Total execution time: 0.0487
INFO - 2020-08-30 07:31:47 --> Config Class Initialized
INFO - 2020-08-30 07:31:47 --> Hooks Class Initialized
DEBUG - 2020-08-30 07:31:47 --> UTF-8 Support Enabled
INFO - 2020-08-30 07:31:47 --> Utf8 Class Initialized
INFO - 2020-08-30 07:31:47 --> URI Class Initialized
DEBUG - 2020-08-30 07:31:47 --> No URI present. Default controller set.
INFO - 2020-08-30 07:31:47 --> Router Class Initialized
INFO - 2020-08-30 07:31:47 --> Output Class Initialized
INFO - 2020-08-30 07:31:47 --> Security Class Initialized
DEBUG - 2020-08-30 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 07:31:47 --> Input Class Initialized
INFO - 2020-08-30 07:31:47 --> Language Class Initialized
INFO - 2020-08-30 07:31:47 --> Language Class Initialized
INFO - 2020-08-30 07:31:47 --> Config Class Initialized
INFO - 2020-08-30 07:31:47 --> Loader Class Initialized
INFO - 2020-08-30 07:31:47 --> Helper loaded: url_helper
INFO - 2020-08-30 07:31:47 --> Helper loaded: form_helper
INFO - 2020-08-30 07:31:47 --> Helper loaded: file_helper
INFO - 2020-08-30 07:31:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 07:31:47 --> Database Driver Class Initialized
DEBUG - 2020-08-30 07:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 07:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 07:31:47 --> Upload Class Initialized
INFO - 2020-08-30 07:31:47 --> Controller Class Initialized
DEBUG - 2020-08-30 07:31:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 07:31:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 07:31:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 07:31:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 07:31:47 --> Final output sent to browser
DEBUG - 2020-08-30 07:31:47 --> Total execution time: 0.0490
INFO - 2020-08-30 08:24:07 --> Config Class Initialized
INFO - 2020-08-30 08:24:07 --> Hooks Class Initialized
DEBUG - 2020-08-30 08:24:07 --> UTF-8 Support Enabled
INFO - 2020-08-30 08:24:07 --> Utf8 Class Initialized
INFO - 2020-08-30 08:24:07 --> URI Class Initialized
INFO - 2020-08-30 08:24:07 --> Router Class Initialized
INFO - 2020-08-30 08:24:07 --> Output Class Initialized
INFO - 2020-08-30 08:24:07 --> Security Class Initialized
DEBUG - 2020-08-30 08:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 08:24:07 --> Input Class Initialized
INFO - 2020-08-30 08:24:07 --> Language Class Initialized
INFO - 2020-08-30 08:24:07 --> Language Class Initialized
INFO - 2020-08-30 08:24:07 --> Config Class Initialized
INFO - 2020-08-30 08:24:07 --> Loader Class Initialized
INFO - 2020-08-30 08:24:07 --> Helper loaded: url_helper
INFO - 2020-08-30 08:24:07 --> Helper loaded: form_helper
INFO - 2020-08-30 08:24:07 --> Helper loaded: file_helper
INFO - 2020-08-30 08:24:07 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 08:24:07 --> Database Driver Class Initialized
DEBUG - 2020-08-30 08:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 08:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 08:24:07 --> Upload Class Initialized
INFO - 2020-08-30 08:24:07 --> Controller Class Initialized
ERROR - 2020-08-30 08:24:07 --> 404 Page Not Found: /index
INFO - 2020-08-30 08:32:32 --> Config Class Initialized
INFO - 2020-08-30 08:32:32 --> Hooks Class Initialized
DEBUG - 2020-08-30 08:32:32 --> UTF-8 Support Enabled
INFO - 2020-08-30 08:32:32 --> Utf8 Class Initialized
INFO - 2020-08-30 08:32:32 --> URI Class Initialized
DEBUG - 2020-08-30 08:32:32 --> No URI present. Default controller set.
INFO - 2020-08-30 08:32:32 --> Router Class Initialized
INFO - 2020-08-30 08:32:32 --> Output Class Initialized
INFO - 2020-08-30 08:32:32 --> Security Class Initialized
DEBUG - 2020-08-30 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 08:32:32 --> Input Class Initialized
INFO - 2020-08-30 08:32:32 --> Language Class Initialized
INFO - 2020-08-30 08:32:32 --> Language Class Initialized
INFO - 2020-08-30 08:32:32 --> Config Class Initialized
INFO - 2020-08-30 08:32:32 --> Loader Class Initialized
INFO - 2020-08-30 08:32:32 --> Helper loaded: url_helper
INFO - 2020-08-30 08:32:32 --> Helper loaded: form_helper
INFO - 2020-08-30 08:32:32 --> Helper loaded: file_helper
INFO - 2020-08-30 08:32:32 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 08:32:32 --> Database Driver Class Initialized
DEBUG - 2020-08-30 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 08:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 08:32:32 --> Upload Class Initialized
INFO - 2020-08-30 08:32:32 --> Controller Class Initialized
DEBUG - 2020-08-30 08:32:32 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 08:32:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 08:32:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 08:32:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 08:32:32 --> Final output sent to browser
DEBUG - 2020-08-30 08:32:32 --> Total execution time: 0.0536
INFO - 2020-08-30 09:04:54 --> Config Class Initialized
INFO - 2020-08-30 09:04:54 --> Hooks Class Initialized
DEBUG - 2020-08-30 09:04:54 --> UTF-8 Support Enabled
INFO - 2020-08-30 09:04:54 --> Utf8 Class Initialized
INFO - 2020-08-30 09:04:54 --> URI Class Initialized
DEBUG - 2020-08-30 09:04:54 --> No URI present. Default controller set.
INFO - 2020-08-30 09:04:54 --> Router Class Initialized
INFO - 2020-08-30 09:04:54 --> Output Class Initialized
INFO - 2020-08-30 09:04:54 --> Security Class Initialized
DEBUG - 2020-08-30 09:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 09:04:54 --> Input Class Initialized
INFO - 2020-08-30 09:04:54 --> Language Class Initialized
INFO - 2020-08-30 09:04:54 --> Language Class Initialized
INFO - 2020-08-30 09:04:54 --> Config Class Initialized
INFO - 2020-08-30 09:04:54 --> Loader Class Initialized
INFO - 2020-08-30 09:04:54 --> Helper loaded: url_helper
INFO - 2020-08-30 09:04:54 --> Helper loaded: form_helper
INFO - 2020-08-30 09:04:54 --> Helper loaded: file_helper
INFO - 2020-08-30 09:04:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 09:04:54 --> Database Driver Class Initialized
DEBUG - 2020-08-30 09:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 09:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 09:04:54 --> Upload Class Initialized
INFO - 2020-08-30 09:04:54 --> Controller Class Initialized
DEBUG - 2020-08-30 09:04:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 09:04:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 09:04:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 09:04:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 09:04:54 --> Final output sent to browser
DEBUG - 2020-08-30 09:04:54 --> Total execution time: 0.2013
INFO - 2020-08-30 11:42:28 --> Config Class Initialized
INFO - 2020-08-30 11:42:28 --> Hooks Class Initialized
DEBUG - 2020-08-30 11:42:28 --> UTF-8 Support Enabled
INFO - 2020-08-30 11:42:28 --> Utf8 Class Initialized
INFO - 2020-08-30 11:42:28 --> URI Class Initialized
INFO - 2020-08-30 11:42:28 --> Router Class Initialized
INFO - 2020-08-30 11:42:28 --> Output Class Initialized
INFO - 2020-08-30 11:42:28 --> Security Class Initialized
DEBUG - 2020-08-30 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 11:42:28 --> Input Class Initialized
INFO - 2020-08-30 11:42:28 --> Language Class Initialized
INFO - 2020-08-30 11:42:28 --> Language Class Initialized
INFO - 2020-08-30 11:42:28 --> Config Class Initialized
INFO - 2020-08-30 11:42:28 --> Loader Class Initialized
INFO - 2020-08-30 11:42:28 --> Helper loaded: url_helper
INFO - 2020-08-30 11:42:28 --> Helper loaded: form_helper
INFO - 2020-08-30 11:42:28 --> Helper loaded: file_helper
INFO - 2020-08-30 11:42:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 11:42:28 --> Database Driver Class Initialized
DEBUG - 2020-08-30 11:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 11:42:28 --> Upload Class Initialized
INFO - 2020-08-30 11:42:28 --> Controller Class Initialized
ERROR - 2020-08-30 11:42:28 --> 404 Page Not Found: /index
INFO - 2020-08-30 12:12:48 --> Config Class Initialized
INFO - 2020-08-30 12:12:48 --> Hooks Class Initialized
DEBUG - 2020-08-30 12:12:48 --> UTF-8 Support Enabled
INFO - 2020-08-30 12:12:48 --> Utf8 Class Initialized
INFO - 2020-08-30 12:12:48 --> URI Class Initialized
INFO - 2020-08-30 12:12:48 --> Router Class Initialized
INFO - 2020-08-30 12:12:48 --> Output Class Initialized
INFO - 2020-08-30 12:12:48 --> Security Class Initialized
DEBUG - 2020-08-30 12:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 12:12:48 --> Input Class Initialized
INFO - 2020-08-30 12:12:48 --> Language Class Initialized
INFO - 2020-08-30 12:12:48 --> Language Class Initialized
INFO - 2020-08-30 12:12:48 --> Config Class Initialized
INFO - 2020-08-30 12:12:48 --> Loader Class Initialized
INFO - 2020-08-30 12:12:48 --> Helper loaded: url_helper
INFO - 2020-08-30 12:12:48 --> Helper loaded: form_helper
INFO - 2020-08-30 12:12:48 --> Helper loaded: file_helper
INFO - 2020-08-30 12:12:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 12:12:48 --> Database Driver Class Initialized
DEBUG - 2020-08-30 12:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 12:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 12:12:48 --> Upload Class Initialized
INFO - 2020-08-30 12:12:48 --> Controller Class Initialized
ERROR - 2020-08-30 12:12:48 --> 404 Page Not Found: /index
INFO - 2020-08-30 12:19:12 --> Config Class Initialized
INFO - 2020-08-30 12:19:12 --> Hooks Class Initialized
DEBUG - 2020-08-30 12:19:12 --> UTF-8 Support Enabled
INFO - 2020-08-30 12:19:12 --> Utf8 Class Initialized
INFO - 2020-08-30 12:19:12 --> URI Class Initialized
DEBUG - 2020-08-30 12:19:12 --> No URI present. Default controller set.
INFO - 2020-08-30 12:19:12 --> Router Class Initialized
INFO - 2020-08-30 12:19:12 --> Output Class Initialized
INFO - 2020-08-30 12:19:12 --> Security Class Initialized
DEBUG - 2020-08-30 12:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 12:19:12 --> Input Class Initialized
INFO - 2020-08-30 12:19:12 --> Language Class Initialized
INFO - 2020-08-30 12:19:12 --> Language Class Initialized
INFO - 2020-08-30 12:19:12 --> Config Class Initialized
INFO - 2020-08-30 12:19:12 --> Loader Class Initialized
INFO - 2020-08-30 12:19:12 --> Helper loaded: url_helper
INFO - 2020-08-30 12:19:12 --> Helper loaded: form_helper
INFO - 2020-08-30 12:19:12 --> Helper loaded: file_helper
INFO - 2020-08-30 12:19:12 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 12:19:12 --> Database Driver Class Initialized
DEBUG - 2020-08-30 12:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 12:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 12:19:12 --> Upload Class Initialized
INFO - 2020-08-30 12:19:12 --> Controller Class Initialized
DEBUG - 2020-08-30 12:19:12 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 12:19:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 12:19:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 12:19:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 12:19:12 --> Final output sent to browser
DEBUG - 2020-08-30 12:19:12 --> Total execution time: 0.0749
INFO - 2020-08-30 13:29:52 --> Config Class Initialized
INFO - 2020-08-30 13:29:52 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:29:52 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:29:52 --> Utf8 Class Initialized
INFO - 2020-08-30 13:29:52 --> URI Class Initialized
DEBUG - 2020-08-30 13:29:52 --> No URI present. Default controller set.
INFO - 2020-08-30 13:29:52 --> Router Class Initialized
INFO - 2020-08-30 13:29:52 --> Output Class Initialized
INFO - 2020-08-30 13:29:52 --> Security Class Initialized
DEBUG - 2020-08-30 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:29:52 --> Input Class Initialized
INFO - 2020-08-30 13:29:52 --> Language Class Initialized
INFO - 2020-08-30 13:29:52 --> Language Class Initialized
INFO - 2020-08-30 13:29:52 --> Config Class Initialized
INFO - 2020-08-30 13:29:52 --> Loader Class Initialized
INFO - 2020-08-30 13:29:52 --> Helper loaded: url_helper
INFO - 2020-08-30 13:29:52 --> Helper loaded: form_helper
INFO - 2020-08-30 13:29:52 --> Helper loaded: file_helper
INFO - 2020-08-30 13:29:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:29:52 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:29:52 --> Upload Class Initialized
INFO - 2020-08-30 13:29:52 --> Controller Class Initialized
DEBUG - 2020-08-30 13:29:52 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 13:29:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 13:29:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 13:29:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 13:29:52 --> Final output sent to browser
DEBUG - 2020-08-30 13:29:52 --> Total execution time: 0.0605
INFO - 2020-08-30 13:29:55 --> Config Class Initialized
INFO - 2020-08-30 13:29:55 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:29:55 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:29:55 --> Utf8 Class Initialized
INFO - 2020-08-30 13:29:55 --> URI Class Initialized
INFO - 2020-08-30 13:29:55 --> Router Class Initialized
INFO - 2020-08-30 13:29:55 --> Output Class Initialized
INFO - 2020-08-30 13:29:55 --> Security Class Initialized
DEBUG - 2020-08-30 13:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:29:55 --> Input Class Initialized
INFO - 2020-08-30 13:29:55 --> Language Class Initialized
INFO - 2020-08-30 13:29:55 --> Language Class Initialized
INFO - 2020-08-30 13:29:55 --> Config Class Initialized
INFO - 2020-08-30 13:29:55 --> Loader Class Initialized
INFO - 2020-08-30 13:29:55 --> Helper loaded: url_helper
INFO - 2020-08-30 13:29:55 --> Helper loaded: form_helper
INFO - 2020-08-30 13:29:55 --> Helper loaded: file_helper
INFO - 2020-08-30 13:29:55 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:29:55 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:29:55 --> Upload Class Initialized
INFO - 2020-08-30 13:29:55 --> Controller Class Initialized
ERROR - 2020-08-30 13:29:55 --> 404 Page Not Found: /index
INFO - 2020-08-30 13:55:54 --> Config Class Initialized
INFO - 2020-08-30 13:55:54 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:55:54 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:55:54 --> Utf8 Class Initialized
INFO - 2020-08-30 13:55:54 --> URI Class Initialized
DEBUG - 2020-08-30 13:55:54 --> No URI present. Default controller set.
INFO - 2020-08-30 13:55:54 --> Router Class Initialized
INFO - 2020-08-30 13:55:54 --> Output Class Initialized
INFO - 2020-08-30 13:55:54 --> Security Class Initialized
DEBUG - 2020-08-30 13:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:55:54 --> Input Class Initialized
INFO - 2020-08-30 13:55:54 --> Language Class Initialized
INFO - 2020-08-30 13:55:54 --> Language Class Initialized
INFO - 2020-08-30 13:55:54 --> Config Class Initialized
INFO - 2020-08-30 13:55:54 --> Loader Class Initialized
INFO - 2020-08-30 13:55:54 --> Helper loaded: url_helper
INFO - 2020-08-30 13:55:54 --> Helper loaded: form_helper
INFO - 2020-08-30 13:55:54 --> Helper loaded: file_helper
INFO - 2020-08-30 13:55:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:55:54 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:55:54 --> Upload Class Initialized
INFO - 2020-08-30 13:55:54 --> Controller Class Initialized
DEBUG - 2020-08-30 13:55:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 13:55:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 13:55:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 13:55:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 13:55:54 --> Final output sent to browser
DEBUG - 2020-08-30 13:55:54 --> Total execution time: 0.0772
INFO - 2020-08-30 13:55:56 --> Config Class Initialized
INFO - 2020-08-30 13:55:56 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:55:56 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:55:56 --> Utf8 Class Initialized
INFO - 2020-08-30 13:55:56 --> URI Class Initialized
DEBUG - 2020-08-30 13:55:56 --> No URI present. Default controller set.
INFO - 2020-08-30 13:55:56 --> Router Class Initialized
INFO - 2020-08-30 13:55:56 --> Output Class Initialized
INFO - 2020-08-30 13:55:56 --> Security Class Initialized
DEBUG - 2020-08-30 13:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:55:56 --> Input Class Initialized
INFO - 2020-08-30 13:55:56 --> Language Class Initialized
INFO - 2020-08-30 13:55:56 --> Language Class Initialized
INFO - 2020-08-30 13:55:56 --> Config Class Initialized
INFO - 2020-08-30 13:55:56 --> Loader Class Initialized
INFO - 2020-08-30 13:55:56 --> Helper loaded: url_helper
INFO - 2020-08-30 13:55:56 --> Helper loaded: form_helper
INFO - 2020-08-30 13:55:56 --> Helper loaded: file_helper
INFO - 2020-08-30 13:55:56 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:55:56 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:55:56 --> Upload Class Initialized
INFO - 2020-08-30 13:55:56 --> Controller Class Initialized
DEBUG - 2020-08-30 13:55:56 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 13:55:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 13:55:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 13:55:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 13:55:56 --> Final output sent to browser
DEBUG - 2020-08-30 13:55:56 --> Total execution time: 0.0513
INFO - 2020-08-30 13:55:57 --> Config Class Initialized
INFO - 2020-08-30 13:55:57 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:55:57 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:55:57 --> Utf8 Class Initialized
INFO - 2020-08-30 13:55:57 --> URI Class Initialized
INFO - 2020-08-30 13:55:57 --> Router Class Initialized
INFO - 2020-08-30 13:55:57 --> Output Class Initialized
INFO - 2020-08-30 13:55:57 --> Security Class Initialized
DEBUG - 2020-08-30 13:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:55:57 --> Input Class Initialized
INFO - 2020-08-30 13:55:57 --> Language Class Initialized
INFO - 2020-08-30 13:55:57 --> Language Class Initialized
INFO - 2020-08-30 13:55:57 --> Config Class Initialized
INFO - 2020-08-30 13:55:57 --> Loader Class Initialized
INFO - 2020-08-30 13:55:57 --> Helper loaded: url_helper
INFO - 2020-08-30 13:55:57 --> Helper loaded: form_helper
INFO - 2020-08-30 13:55:57 --> Helper loaded: file_helper
INFO - 2020-08-30 13:55:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:55:57 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:55:57 --> Upload Class Initialized
INFO - 2020-08-30 13:55:57 --> Controller Class Initialized
ERROR - 2020-08-30 13:55:57 --> 404 Page Not Found: /index
INFO - 2020-08-30 13:56:58 --> Config Class Initialized
INFO - 2020-08-30 13:56:58 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:56:58 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:56:58 --> Utf8 Class Initialized
INFO - 2020-08-30 13:56:58 --> URI Class Initialized
DEBUG - 2020-08-30 13:56:58 --> No URI present. Default controller set.
INFO - 2020-08-30 13:56:58 --> Router Class Initialized
INFO - 2020-08-30 13:56:58 --> Output Class Initialized
INFO - 2020-08-30 13:56:58 --> Security Class Initialized
DEBUG - 2020-08-30 13:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:56:58 --> Input Class Initialized
INFO - 2020-08-30 13:56:58 --> Language Class Initialized
INFO - 2020-08-30 13:56:58 --> Language Class Initialized
INFO - 2020-08-30 13:56:58 --> Config Class Initialized
INFO - 2020-08-30 13:56:58 --> Loader Class Initialized
INFO - 2020-08-30 13:56:58 --> Helper loaded: url_helper
INFO - 2020-08-30 13:56:58 --> Helper loaded: form_helper
INFO - 2020-08-30 13:56:58 --> Helper loaded: file_helper
INFO - 2020-08-30 13:56:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:56:58 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:56:58 --> Upload Class Initialized
INFO - 2020-08-30 13:56:58 --> Controller Class Initialized
DEBUG - 2020-08-30 13:56:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 13:56:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 13:56:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 13:56:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 13:56:58 --> Final output sent to browser
DEBUG - 2020-08-30 13:56:58 --> Total execution time: 0.0518
INFO - 2020-08-30 13:57:00 --> Config Class Initialized
INFO - 2020-08-30 13:57:00 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:57:00 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:57:00 --> Utf8 Class Initialized
INFO - 2020-08-30 13:57:00 --> URI Class Initialized
INFO - 2020-08-30 13:57:00 --> Router Class Initialized
INFO - 2020-08-30 13:57:00 --> Output Class Initialized
INFO - 2020-08-30 13:57:00 --> Security Class Initialized
DEBUG - 2020-08-30 13:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:57:00 --> Input Class Initialized
INFO - 2020-08-30 13:57:00 --> Language Class Initialized
INFO - 2020-08-30 13:57:00 --> Language Class Initialized
INFO - 2020-08-30 13:57:00 --> Config Class Initialized
INFO - 2020-08-30 13:57:00 --> Loader Class Initialized
INFO - 2020-08-30 13:57:00 --> Helper loaded: url_helper
INFO - 2020-08-30 13:57:00 --> Helper loaded: form_helper
INFO - 2020-08-30 13:57:00 --> Helper loaded: file_helper
INFO - 2020-08-30 13:57:00 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:57:00 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:57:00 --> Upload Class Initialized
INFO - 2020-08-30 13:57:00 --> Controller Class Initialized
ERROR - 2020-08-30 13:57:00 --> 404 Page Not Found: /index
INFO - 2020-08-30 13:57:21 --> Config Class Initialized
INFO - 2020-08-30 13:57:21 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:57:21 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:57:21 --> Utf8 Class Initialized
INFO - 2020-08-30 13:57:21 --> URI Class Initialized
DEBUG - 2020-08-30 13:57:21 --> No URI present. Default controller set.
INFO - 2020-08-30 13:57:21 --> Router Class Initialized
INFO - 2020-08-30 13:57:21 --> Output Class Initialized
INFO - 2020-08-30 13:57:21 --> Security Class Initialized
DEBUG - 2020-08-30 13:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:57:21 --> Input Class Initialized
INFO - 2020-08-30 13:57:21 --> Language Class Initialized
INFO - 2020-08-30 13:57:21 --> Language Class Initialized
INFO - 2020-08-30 13:57:21 --> Config Class Initialized
INFO - 2020-08-30 13:57:21 --> Loader Class Initialized
INFO - 2020-08-30 13:57:21 --> Helper loaded: url_helper
INFO - 2020-08-30 13:57:21 --> Helper loaded: form_helper
INFO - 2020-08-30 13:57:21 --> Helper loaded: file_helper
INFO - 2020-08-30 13:57:21 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:57:21 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:57:21 --> Upload Class Initialized
INFO - 2020-08-30 13:57:21 --> Controller Class Initialized
DEBUG - 2020-08-30 13:57:21 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 13:57:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 13:57:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 13:57:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 13:57:21 --> Final output sent to browser
DEBUG - 2020-08-30 13:57:21 --> Total execution time: 0.0506
INFO - 2020-08-30 13:57:24 --> Config Class Initialized
INFO - 2020-08-30 13:57:24 --> Hooks Class Initialized
DEBUG - 2020-08-30 13:57:24 --> UTF-8 Support Enabled
INFO - 2020-08-30 13:57:24 --> Utf8 Class Initialized
INFO - 2020-08-30 13:57:24 --> URI Class Initialized
INFO - 2020-08-30 13:57:24 --> Router Class Initialized
INFO - 2020-08-30 13:57:24 --> Output Class Initialized
INFO - 2020-08-30 13:57:24 --> Security Class Initialized
DEBUG - 2020-08-30 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 13:57:24 --> Input Class Initialized
INFO - 2020-08-30 13:57:24 --> Language Class Initialized
INFO - 2020-08-30 13:57:24 --> Language Class Initialized
INFO - 2020-08-30 13:57:24 --> Config Class Initialized
INFO - 2020-08-30 13:57:24 --> Loader Class Initialized
INFO - 2020-08-30 13:57:24 --> Helper loaded: url_helper
INFO - 2020-08-30 13:57:24 --> Helper loaded: form_helper
INFO - 2020-08-30 13:57:24 --> Helper loaded: file_helper
INFO - 2020-08-30 13:57:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 13:57:24 --> Database Driver Class Initialized
DEBUG - 2020-08-30 13:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 13:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 13:57:24 --> Upload Class Initialized
INFO - 2020-08-30 13:57:24 --> Controller Class Initialized
ERROR - 2020-08-30 13:57:24 --> 404 Page Not Found: /index
INFO - 2020-08-30 15:04:08 --> Config Class Initialized
INFO - 2020-08-30 15:04:08 --> Hooks Class Initialized
DEBUG - 2020-08-30 15:04:08 --> UTF-8 Support Enabled
INFO - 2020-08-30 15:04:08 --> Utf8 Class Initialized
INFO - 2020-08-30 15:04:08 --> URI Class Initialized
INFO - 2020-08-30 15:04:08 --> Router Class Initialized
INFO - 2020-08-30 15:04:08 --> Output Class Initialized
INFO - 2020-08-30 15:04:08 --> Security Class Initialized
DEBUG - 2020-08-30 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 15:04:08 --> Input Class Initialized
INFO - 2020-08-30 15:04:08 --> Language Class Initialized
INFO - 2020-08-30 15:04:08 --> Language Class Initialized
INFO - 2020-08-30 15:04:08 --> Config Class Initialized
INFO - 2020-08-30 15:04:08 --> Loader Class Initialized
INFO - 2020-08-30 15:04:08 --> Helper loaded: url_helper
INFO - 2020-08-30 15:04:08 --> Helper loaded: form_helper
INFO - 2020-08-30 15:04:08 --> Helper loaded: file_helper
INFO - 2020-08-30 15:04:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 15:04:08 --> Database Driver Class Initialized
DEBUG - 2020-08-30 15:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 15:04:08 --> Upload Class Initialized
INFO - 2020-08-30 15:04:08 --> Controller Class Initialized
ERROR - 2020-08-30 15:04:08 --> 404 Page Not Found: /index
INFO - 2020-08-30 16:05:53 --> Config Class Initialized
INFO - 2020-08-30 16:05:53 --> Hooks Class Initialized
DEBUG - 2020-08-30 16:05:53 --> UTF-8 Support Enabled
INFO - 2020-08-30 16:05:53 --> Utf8 Class Initialized
INFO - 2020-08-30 16:05:53 --> URI Class Initialized
INFO - 2020-08-30 16:05:53 --> Router Class Initialized
INFO - 2020-08-30 16:05:53 --> Output Class Initialized
INFO - 2020-08-30 16:05:53 --> Security Class Initialized
DEBUG - 2020-08-30 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 16:05:53 --> Input Class Initialized
INFO - 2020-08-30 16:05:53 --> Language Class Initialized
INFO - 2020-08-30 16:05:53 --> Language Class Initialized
INFO - 2020-08-30 16:05:53 --> Config Class Initialized
INFO - 2020-08-30 16:05:53 --> Loader Class Initialized
INFO - 2020-08-30 16:05:53 --> Helper loaded: url_helper
INFO - 2020-08-30 16:05:53 --> Helper loaded: form_helper
INFO - 2020-08-30 16:05:53 --> Helper loaded: file_helper
INFO - 2020-08-30 16:05:53 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 16:05:53 --> Database Driver Class Initialized
DEBUG - 2020-08-30 16:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 16:05:53 --> Upload Class Initialized
INFO - 2020-08-30 16:05:53 --> Controller Class Initialized
DEBUG - 2020-08-30 16:05:53 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 16:05:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-30 16:05:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 16:05:53 --> Final output sent to browser
DEBUG - 2020-08-30 16:05:53 --> Total execution time: 0.1457
INFO - 2020-08-30 16:05:57 --> Config Class Initialized
INFO - 2020-08-30 16:05:57 --> Hooks Class Initialized
DEBUG - 2020-08-30 16:05:57 --> UTF-8 Support Enabled
INFO - 2020-08-30 16:05:57 --> Utf8 Class Initialized
INFO - 2020-08-30 16:05:57 --> URI Class Initialized
INFO - 2020-08-30 16:05:57 --> Router Class Initialized
INFO - 2020-08-30 16:05:57 --> Output Class Initialized
INFO - 2020-08-30 16:05:57 --> Security Class Initialized
DEBUG - 2020-08-30 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 16:05:57 --> Input Class Initialized
INFO - 2020-08-30 16:05:57 --> Language Class Initialized
INFO - 2020-08-30 16:05:57 --> Language Class Initialized
INFO - 2020-08-30 16:05:57 --> Config Class Initialized
INFO - 2020-08-30 16:05:57 --> Loader Class Initialized
INFO - 2020-08-30 16:05:57 --> Helper loaded: url_helper
INFO - 2020-08-30 16:05:57 --> Helper loaded: form_helper
INFO - 2020-08-30 16:05:57 --> Helper loaded: file_helper
INFO - 2020-08-30 16:05:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 16:05:57 --> Database Driver Class Initialized
DEBUG - 2020-08-30 16:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 16:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 16:05:57 --> Upload Class Initialized
INFO - 2020-08-30 16:05:57 --> Controller Class Initialized
ERROR - 2020-08-30 16:05:57 --> 404 Page Not Found: /index
INFO - 2020-08-30 16:05:59 --> Config Class Initialized
INFO - 2020-08-30 16:05:59 --> Hooks Class Initialized
DEBUG - 2020-08-30 16:05:59 --> UTF-8 Support Enabled
INFO - 2020-08-30 16:05:59 --> Utf8 Class Initialized
INFO - 2020-08-30 16:05:59 --> URI Class Initialized
INFO - 2020-08-30 16:05:59 --> Router Class Initialized
INFO - 2020-08-30 16:05:59 --> Output Class Initialized
INFO - 2020-08-30 16:05:59 --> Security Class Initialized
DEBUG - 2020-08-30 16:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 16:05:59 --> Input Class Initialized
INFO - 2020-08-30 16:05:59 --> Language Class Initialized
INFO - 2020-08-30 16:05:59 --> Language Class Initialized
INFO - 2020-08-30 16:05:59 --> Config Class Initialized
INFO - 2020-08-30 16:05:59 --> Loader Class Initialized
INFO - 2020-08-30 16:05:59 --> Helper loaded: url_helper
INFO - 2020-08-30 16:05:59 --> Helper loaded: form_helper
INFO - 2020-08-30 16:05:59 --> Helper loaded: file_helper
INFO - 2020-08-30 16:05:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 16:05:59 --> Database Driver Class Initialized
DEBUG - 2020-08-30 16:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 16:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 16:05:59 --> Upload Class Initialized
INFO - 2020-08-30 16:05:59 --> Controller Class Initialized
DEBUG - 2020-08-30 16:05:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 16:05:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 16:05:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 16:05:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 16:05:59 --> Final output sent to browser
DEBUG - 2020-08-30 16:05:59 --> Total execution time: 0.0523
INFO - 2020-08-30 16:11:42 --> Config Class Initialized
INFO - 2020-08-30 16:11:42 --> Hooks Class Initialized
DEBUG - 2020-08-30 16:11:42 --> UTF-8 Support Enabled
INFO - 2020-08-30 16:11:42 --> Utf8 Class Initialized
INFO - 2020-08-30 16:11:42 --> URI Class Initialized
DEBUG - 2020-08-30 16:11:42 --> No URI present. Default controller set.
INFO - 2020-08-30 16:11:42 --> Router Class Initialized
INFO - 2020-08-30 16:11:42 --> Output Class Initialized
INFO - 2020-08-30 16:11:42 --> Security Class Initialized
DEBUG - 2020-08-30 16:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 16:11:42 --> Input Class Initialized
INFO - 2020-08-30 16:11:42 --> Language Class Initialized
INFO - 2020-08-30 16:11:42 --> Language Class Initialized
INFO - 2020-08-30 16:11:42 --> Config Class Initialized
INFO - 2020-08-30 16:11:42 --> Loader Class Initialized
INFO - 2020-08-30 16:11:42 --> Helper loaded: url_helper
INFO - 2020-08-30 16:11:42 --> Helper loaded: form_helper
INFO - 2020-08-30 16:11:42 --> Helper loaded: file_helper
INFO - 2020-08-30 16:11:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 16:11:42 --> Database Driver Class Initialized
DEBUG - 2020-08-30 16:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 16:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 16:11:42 --> Upload Class Initialized
INFO - 2020-08-30 16:11:42 --> Controller Class Initialized
DEBUG - 2020-08-30 16:11:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 16:11:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 16:11:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 16:11:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 16:11:42 --> Final output sent to browser
DEBUG - 2020-08-30 16:11:42 --> Total execution time: 0.0547
INFO - 2020-08-30 16:11:46 --> Config Class Initialized
INFO - 2020-08-30 16:11:46 --> Hooks Class Initialized
DEBUG - 2020-08-30 16:11:46 --> UTF-8 Support Enabled
INFO - 2020-08-30 16:11:46 --> Utf8 Class Initialized
INFO - 2020-08-30 16:11:46 --> URI Class Initialized
INFO - 2020-08-30 16:11:46 --> Router Class Initialized
INFO - 2020-08-30 16:11:46 --> Output Class Initialized
INFO - 2020-08-30 16:11:46 --> Security Class Initialized
DEBUG - 2020-08-30 16:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 16:11:46 --> Input Class Initialized
INFO - 2020-08-30 16:11:46 --> Language Class Initialized
INFO - 2020-08-30 16:11:46 --> Language Class Initialized
INFO - 2020-08-30 16:11:46 --> Config Class Initialized
INFO - 2020-08-30 16:11:46 --> Loader Class Initialized
INFO - 2020-08-30 16:11:46 --> Helper loaded: url_helper
INFO - 2020-08-30 16:11:46 --> Helper loaded: form_helper
INFO - 2020-08-30 16:11:46 --> Helper loaded: file_helper
INFO - 2020-08-30 16:11:46 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 16:11:46 --> Database Driver Class Initialized
DEBUG - 2020-08-30 16:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 16:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 16:11:46 --> Upload Class Initialized
INFO - 2020-08-30 16:11:46 --> Controller Class Initialized
ERROR - 2020-08-30 16:11:46 --> 404 Page Not Found: /index
INFO - 2020-08-30 16:12:59 --> Config Class Initialized
INFO - 2020-08-30 16:12:59 --> Hooks Class Initialized
DEBUG - 2020-08-30 16:12:59 --> UTF-8 Support Enabled
INFO - 2020-08-30 16:12:59 --> Utf8 Class Initialized
INFO - 2020-08-30 16:12:59 --> URI Class Initialized
DEBUG - 2020-08-30 16:12:59 --> No URI present. Default controller set.
INFO - 2020-08-30 16:12:59 --> Router Class Initialized
INFO - 2020-08-30 16:12:59 --> Output Class Initialized
INFO - 2020-08-30 16:12:59 --> Security Class Initialized
DEBUG - 2020-08-30 16:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 16:12:59 --> Input Class Initialized
INFO - 2020-08-30 16:12:59 --> Language Class Initialized
INFO - 2020-08-30 16:12:59 --> Language Class Initialized
INFO - 2020-08-30 16:12:59 --> Config Class Initialized
INFO - 2020-08-30 16:12:59 --> Loader Class Initialized
INFO - 2020-08-30 16:12:59 --> Helper loaded: url_helper
INFO - 2020-08-30 16:12:59 --> Helper loaded: form_helper
INFO - 2020-08-30 16:12:59 --> Helper loaded: file_helper
INFO - 2020-08-30 16:12:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 16:12:59 --> Database Driver Class Initialized
DEBUG - 2020-08-30 16:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 16:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 16:12:59 --> Upload Class Initialized
INFO - 2020-08-30 16:12:59 --> Controller Class Initialized
DEBUG - 2020-08-30 16:12:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 16:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 16:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 16:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 16:12:59 --> Final output sent to browser
DEBUG - 2020-08-30 16:12:59 --> Total execution time: 0.0537
INFO - 2020-08-30 18:19:20 --> Config Class Initialized
INFO - 2020-08-30 18:19:20 --> Hooks Class Initialized
DEBUG - 2020-08-30 18:19:20 --> UTF-8 Support Enabled
INFO - 2020-08-30 18:19:20 --> Utf8 Class Initialized
INFO - 2020-08-30 18:19:20 --> URI Class Initialized
DEBUG - 2020-08-30 18:19:20 --> No URI present. Default controller set.
INFO - 2020-08-30 18:19:20 --> Router Class Initialized
INFO - 2020-08-30 18:19:20 --> Output Class Initialized
INFO - 2020-08-30 18:19:20 --> Security Class Initialized
DEBUG - 2020-08-30 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 18:19:20 --> Input Class Initialized
INFO - 2020-08-30 18:19:20 --> Language Class Initialized
INFO - 2020-08-30 18:19:20 --> Language Class Initialized
INFO - 2020-08-30 18:19:20 --> Config Class Initialized
INFO - 2020-08-30 18:19:20 --> Loader Class Initialized
INFO - 2020-08-30 18:19:20 --> Helper loaded: url_helper
INFO - 2020-08-30 18:19:20 --> Helper loaded: form_helper
INFO - 2020-08-30 18:19:20 --> Helper loaded: file_helper
INFO - 2020-08-30 18:19:20 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 18:19:20 --> Database Driver Class Initialized
DEBUG - 2020-08-30 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 18:19:20 --> Upload Class Initialized
INFO - 2020-08-30 18:19:20 --> Controller Class Initialized
DEBUG - 2020-08-30 18:19:20 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 18:19:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 18:19:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 18:19:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 18:19:20 --> Final output sent to browser
DEBUG - 2020-08-30 18:19:20 --> Total execution time: 0.0524
INFO - 2020-08-30 19:09:47 --> Config Class Initialized
INFO - 2020-08-30 19:09:47 --> Hooks Class Initialized
DEBUG - 2020-08-30 19:09:47 --> UTF-8 Support Enabled
INFO - 2020-08-30 19:09:47 --> Utf8 Class Initialized
INFO - 2020-08-30 19:09:47 --> URI Class Initialized
INFO - 2020-08-30 19:09:47 --> Router Class Initialized
INFO - 2020-08-30 19:09:47 --> Output Class Initialized
INFO - 2020-08-30 19:09:47 --> Security Class Initialized
DEBUG - 2020-08-30 19:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 19:09:47 --> Input Class Initialized
INFO - 2020-08-30 19:09:47 --> Language Class Initialized
INFO - 2020-08-30 19:09:47 --> Language Class Initialized
INFO - 2020-08-30 19:09:47 --> Config Class Initialized
INFO - 2020-08-30 19:09:47 --> Loader Class Initialized
INFO - 2020-08-30 19:09:47 --> Helper loaded: url_helper
INFO - 2020-08-30 19:09:47 --> Helper loaded: form_helper
INFO - 2020-08-30 19:09:47 --> Helper loaded: file_helper
INFO - 2020-08-30 19:09:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 19:09:47 --> Database Driver Class Initialized
DEBUG - 2020-08-30 19:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 19:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 19:09:47 --> Upload Class Initialized
INFO - 2020-08-30 19:09:47 --> Controller Class Initialized
ERROR - 2020-08-30 19:09:47 --> 404 Page Not Found: /index
INFO - 2020-08-30 19:09:50 --> Config Class Initialized
INFO - 2020-08-30 19:09:50 --> Hooks Class Initialized
DEBUG - 2020-08-30 19:09:50 --> UTF-8 Support Enabled
INFO - 2020-08-30 19:09:50 --> Utf8 Class Initialized
INFO - 2020-08-30 19:09:50 --> URI Class Initialized
INFO - 2020-08-30 19:09:50 --> Router Class Initialized
INFO - 2020-08-30 19:09:50 --> Output Class Initialized
INFO - 2020-08-30 19:09:50 --> Security Class Initialized
DEBUG - 2020-08-30 19:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 19:09:50 --> Input Class Initialized
INFO - 2020-08-30 19:09:50 --> Language Class Initialized
INFO - 2020-08-30 19:09:50 --> Language Class Initialized
INFO - 2020-08-30 19:09:50 --> Config Class Initialized
INFO - 2020-08-30 19:09:50 --> Loader Class Initialized
INFO - 2020-08-30 19:09:50 --> Helper loaded: url_helper
INFO - 2020-08-30 19:09:50 --> Helper loaded: form_helper
INFO - 2020-08-30 19:09:50 --> Helper loaded: file_helper
INFO - 2020-08-30 19:09:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 19:09:50 --> Database Driver Class Initialized
DEBUG - 2020-08-30 19:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 19:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 19:09:50 --> Upload Class Initialized
INFO - 2020-08-30 19:09:50 --> Controller Class Initialized
ERROR - 2020-08-30 19:09:50 --> 404 Page Not Found: /index
INFO - 2020-08-30 20:23:08 --> Config Class Initialized
INFO - 2020-08-30 20:23:08 --> Hooks Class Initialized
DEBUG - 2020-08-30 20:23:08 --> UTF-8 Support Enabled
INFO - 2020-08-30 20:23:08 --> Utf8 Class Initialized
INFO - 2020-08-30 20:23:08 --> URI Class Initialized
INFO - 2020-08-30 20:23:08 --> Router Class Initialized
INFO - 2020-08-30 20:23:08 --> Output Class Initialized
INFO - 2020-08-30 20:23:08 --> Security Class Initialized
DEBUG - 2020-08-30 20:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 20:23:08 --> Input Class Initialized
INFO - 2020-08-30 20:23:08 --> Language Class Initialized
INFO - 2020-08-30 20:23:08 --> Language Class Initialized
INFO - 2020-08-30 20:23:08 --> Config Class Initialized
INFO - 2020-08-30 20:23:08 --> Loader Class Initialized
INFO - 2020-08-30 20:23:08 --> Helper loaded: url_helper
INFO - 2020-08-30 20:23:08 --> Helper loaded: form_helper
INFO - 2020-08-30 20:23:08 --> Helper loaded: file_helper
INFO - 2020-08-30 20:23:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 20:23:08 --> Database Driver Class Initialized
DEBUG - 2020-08-30 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 20:23:08 --> Upload Class Initialized
INFO - 2020-08-30 20:23:08 --> Controller Class Initialized
DEBUG - 2020-08-30 20:23:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 20:23:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 20:23:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 20:23:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 20:23:08 --> Final output sent to browser
DEBUG - 2020-08-30 20:23:08 --> Total execution time: 0.0614
INFO - 2020-08-30 20:23:17 --> Config Class Initialized
INFO - 2020-08-30 20:23:17 --> Hooks Class Initialized
DEBUG - 2020-08-30 20:23:17 --> UTF-8 Support Enabled
INFO - 2020-08-30 20:23:17 --> Utf8 Class Initialized
INFO - 2020-08-30 20:23:17 --> URI Class Initialized
INFO - 2020-08-30 20:23:17 --> Router Class Initialized
INFO - 2020-08-30 20:23:17 --> Output Class Initialized
INFO - 2020-08-30 20:23:17 --> Security Class Initialized
DEBUG - 2020-08-30 20:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 20:23:17 --> Input Class Initialized
INFO - 2020-08-30 20:23:17 --> Language Class Initialized
INFO - 2020-08-30 20:23:17 --> Language Class Initialized
INFO - 2020-08-30 20:23:17 --> Config Class Initialized
INFO - 2020-08-30 20:23:17 --> Loader Class Initialized
INFO - 2020-08-30 20:23:17 --> Helper loaded: url_helper
INFO - 2020-08-30 20:23:17 --> Helper loaded: form_helper
INFO - 2020-08-30 20:23:17 --> Helper loaded: file_helper
INFO - 2020-08-30 20:23:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 20:23:17 --> Database Driver Class Initialized
DEBUG - 2020-08-30 20:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 20:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 20:23:17 --> Upload Class Initialized
INFO - 2020-08-30 20:23:17 --> Controller Class Initialized
ERROR - 2020-08-30 20:23:17 --> 404 Page Not Found: /index
INFO - 2020-08-30 20:26:14 --> Config Class Initialized
INFO - 2020-08-30 20:26:14 --> Hooks Class Initialized
DEBUG - 2020-08-30 20:26:14 --> UTF-8 Support Enabled
INFO - 2020-08-30 20:26:14 --> Utf8 Class Initialized
INFO - 2020-08-30 20:26:14 --> URI Class Initialized
DEBUG - 2020-08-30 20:26:14 --> No URI present. Default controller set.
INFO - 2020-08-30 20:26:14 --> Router Class Initialized
INFO - 2020-08-30 20:26:14 --> Output Class Initialized
INFO - 2020-08-30 20:26:14 --> Security Class Initialized
DEBUG - 2020-08-30 20:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 20:26:14 --> Input Class Initialized
INFO - 2020-08-30 20:26:14 --> Language Class Initialized
INFO - 2020-08-30 20:26:14 --> Language Class Initialized
INFO - 2020-08-30 20:26:14 --> Config Class Initialized
INFO - 2020-08-30 20:26:14 --> Loader Class Initialized
INFO - 2020-08-30 20:26:14 --> Helper loaded: url_helper
INFO - 2020-08-30 20:26:14 --> Helper loaded: form_helper
INFO - 2020-08-30 20:26:14 --> Helper loaded: file_helper
INFO - 2020-08-30 20:26:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 20:26:14 --> Database Driver Class Initialized
DEBUG - 2020-08-30 20:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 20:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 20:26:14 --> Upload Class Initialized
INFO - 2020-08-30 20:26:14 --> Controller Class Initialized
DEBUG - 2020-08-30 20:26:14 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 20:26:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 20:26:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 20:26:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 20:26:14 --> Final output sent to browser
DEBUG - 2020-08-30 20:26:14 --> Total execution time: 0.0497
INFO - 2020-08-30 21:07:11 --> Config Class Initialized
INFO - 2020-08-30 21:07:11 --> Hooks Class Initialized
DEBUG - 2020-08-30 21:07:11 --> UTF-8 Support Enabled
INFO - 2020-08-30 21:07:11 --> Utf8 Class Initialized
INFO - 2020-08-30 21:07:11 --> URI Class Initialized
DEBUG - 2020-08-30 21:07:11 --> No URI present. Default controller set.
INFO - 2020-08-30 21:07:11 --> Router Class Initialized
INFO - 2020-08-30 21:07:11 --> Output Class Initialized
INFO - 2020-08-30 21:07:11 --> Security Class Initialized
DEBUG - 2020-08-30 21:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 21:07:11 --> Input Class Initialized
INFO - 2020-08-30 21:07:11 --> Language Class Initialized
INFO - 2020-08-30 21:07:11 --> Language Class Initialized
INFO - 2020-08-30 21:07:11 --> Config Class Initialized
INFO - 2020-08-30 21:07:11 --> Loader Class Initialized
INFO - 2020-08-30 21:07:11 --> Helper loaded: url_helper
INFO - 2020-08-30 21:07:11 --> Helper loaded: form_helper
INFO - 2020-08-30 21:07:11 --> Helper loaded: file_helper
INFO - 2020-08-30 21:07:11 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 21:07:11 --> Database Driver Class Initialized
DEBUG - 2020-08-30 21:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 21:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 21:07:11 --> Upload Class Initialized
INFO - 2020-08-30 21:07:11 --> Controller Class Initialized
DEBUG - 2020-08-30 21:07:11 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 21:07:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-30 21:07:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-30 21:07:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 21:07:11 --> Final output sent to browser
DEBUG - 2020-08-30 21:07:11 --> Total execution time: 0.0532
INFO - 2020-08-30 22:35:25 --> Config Class Initialized
INFO - 2020-08-30 22:35:25 --> Hooks Class Initialized
DEBUG - 2020-08-30 22:35:25 --> UTF-8 Support Enabled
INFO - 2020-08-30 22:35:25 --> Utf8 Class Initialized
INFO - 2020-08-30 22:35:25 --> URI Class Initialized
INFO - 2020-08-30 22:35:25 --> Router Class Initialized
INFO - 2020-08-30 22:35:25 --> Output Class Initialized
INFO - 2020-08-30 22:35:25 --> Security Class Initialized
DEBUG - 2020-08-30 22:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 22:35:25 --> Input Class Initialized
INFO - 2020-08-30 22:35:25 --> Language Class Initialized
INFO - 2020-08-30 22:35:25 --> Language Class Initialized
INFO - 2020-08-30 22:35:25 --> Config Class Initialized
INFO - 2020-08-30 22:35:25 --> Loader Class Initialized
INFO - 2020-08-30 22:35:25 --> Helper loaded: url_helper
INFO - 2020-08-30 22:35:25 --> Helper loaded: form_helper
INFO - 2020-08-30 22:35:25 --> Helper loaded: file_helper
INFO - 2020-08-30 22:35:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 22:35:25 --> Database Driver Class Initialized
DEBUG - 2020-08-30 22:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 22:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 22:35:25 --> Upload Class Initialized
INFO - 2020-08-30 22:35:25 --> Controller Class Initialized
ERROR - 2020-08-30 22:35:25 --> 404 Page Not Found: /index
INFO - 2020-08-30 22:35:28 --> Config Class Initialized
INFO - 2020-08-30 22:35:28 --> Hooks Class Initialized
DEBUG - 2020-08-30 22:35:28 --> UTF-8 Support Enabled
INFO - 2020-08-30 22:35:28 --> Utf8 Class Initialized
INFO - 2020-08-30 22:35:28 --> URI Class Initialized
INFO - 2020-08-30 22:35:28 --> Router Class Initialized
INFO - 2020-08-30 22:35:28 --> Output Class Initialized
INFO - 2020-08-30 22:35:28 --> Security Class Initialized
DEBUG - 2020-08-30 22:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-30 22:35:28 --> Input Class Initialized
INFO - 2020-08-30 22:35:28 --> Language Class Initialized
INFO - 2020-08-30 22:35:28 --> Language Class Initialized
INFO - 2020-08-30 22:35:28 --> Config Class Initialized
INFO - 2020-08-30 22:35:28 --> Loader Class Initialized
INFO - 2020-08-30 22:35:28 --> Helper loaded: url_helper
INFO - 2020-08-30 22:35:28 --> Helper loaded: form_helper
INFO - 2020-08-30 22:35:28 --> Helper loaded: file_helper
INFO - 2020-08-30 22:35:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-30 22:35:28 --> Database Driver Class Initialized
DEBUG - 2020-08-30 22:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-30 22:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-30 22:35:28 --> Upload Class Initialized
INFO - 2020-08-30 22:35:28 --> Controller Class Initialized
DEBUG - 2020-08-30 22:35:28 --> Home MX_Controller Initialized
DEBUG - 2020-08-30 22:35:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-30 22:35:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-30 22:35:28 --> Final output sent to browser
DEBUG - 2020-08-30 22:35:28 --> Total execution time: 0.0523
