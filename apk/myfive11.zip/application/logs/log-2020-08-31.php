<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-31 00:20:15 --> Config Class Initialized
INFO - 2020-08-31 00:20:15 --> Hooks Class Initialized
DEBUG - 2020-08-31 00:20:15 --> UTF-8 Support Enabled
INFO - 2020-08-31 00:20:15 --> Utf8 Class Initialized
INFO - 2020-08-31 00:20:15 --> URI Class Initialized
DEBUG - 2020-08-31 00:20:15 --> No URI present. Default controller set.
INFO - 2020-08-31 00:20:15 --> Router Class Initialized
INFO - 2020-08-31 00:20:15 --> Output Class Initialized
INFO - 2020-08-31 00:20:15 --> Security Class Initialized
DEBUG - 2020-08-31 00:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 00:20:15 --> Input Class Initialized
INFO - 2020-08-31 00:20:15 --> Language Class Initialized
INFO - 2020-08-31 00:20:15 --> Language Class Initialized
INFO - 2020-08-31 00:20:15 --> Config Class Initialized
INFO - 2020-08-31 00:20:15 --> Loader Class Initialized
INFO - 2020-08-31 00:20:15 --> Helper loaded: url_helper
INFO - 2020-08-31 00:20:15 --> Helper loaded: form_helper
INFO - 2020-08-31 00:20:15 --> Helper loaded: file_helper
INFO - 2020-08-31 00:20:15 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 00:20:15 --> Database Driver Class Initialized
DEBUG - 2020-08-31 00:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 00:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 00:20:15 --> Upload Class Initialized
INFO - 2020-08-31 00:20:15 --> Controller Class Initialized
DEBUG - 2020-08-31 00:20:15 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 00:20:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 00:20:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 00:20:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 00:20:15 --> Final output sent to browser
DEBUG - 2020-08-31 00:20:15 --> Total execution time: 0.1811
INFO - 2020-08-31 00:25:54 --> Config Class Initialized
INFO - 2020-08-31 00:25:54 --> Hooks Class Initialized
DEBUG - 2020-08-31 00:25:54 --> UTF-8 Support Enabled
INFO - 2020-08-31 00:25:54 --> Utf8 Class Initialized
INFO - 2020-08-31 00:25:54 --> URI Class Initialized
DEBUG - 2020-08-31 00:25:54 --> No URI present. Default controller set.
INFO - 2020-08-31 00:25:54 --> Router Class Initialized
INFO - 2020-08-31 00:25:54 --> Output Class Initialized
INFO - 2020-08-31 00:25:54 --> Security Class Initialized
DEBUG - 2020-08-31 00:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 00:25:54 --> Input Class Initialized
INFO - 2020-08-31 00:25:54 --> Language Class Initialized
INFO - 2020-08-31 00:25:54 --> Language Class Initialized
INFO - 2020-08-31 00:25:54 --> Config Class Initialized
INFO - 2020-08-31 00:25:54 --> Loader Class Initialized
INFO - 2020-08-31 00:25:54 --> Helper loaded: url_helper
INFO - 2020-08-31 00:25:54 --> Helper loaded: form_helper
INFO - 2020-08-31 00:25:54 --> Helper loaded: file_helper
INFO - 2020-08-31 00:25:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 00:25:54 --> Database Driver Class Initialized
DEBUG - 2020-08-31 00:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 00:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 00:25:54 --> Upload Class Initialized
INFO - 2020-08-31 00:25:54 --> Controller Class Initialized
DEBUG - 2020-08-31 00:25:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 00:25:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 00:25:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 00:25:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 00:25:54 --> Final output sent to browser
DEBUG - 2020-08-31 00:25:54 --> Total execution time: 0.0500
INFO - 2020-08-31 00:37:05 --> Config Class Initialized
INFO - 2020-08-31 00:37:05 --> Hooks Class Initialized
DEBUG - 2020-08-31 00:37:05 --> UTF-8 Support Enabled
INFO - 2020-08-31 00:37:05 --> Utf8 Class Initialized
INFO - 2020-08-31 00:37:05 --> URI Class Initialized
INFO - 2020-08-31 00:37:05 --> Router Class Initialized
INFO - 2020-08-31 00:37:05 --> Output Class Initialized
INFO - 2020-08-31 00:37:05 --> Security Class Initialized
DEBUG - 2020-08-31 00:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 00:37:05 --> Input Class Initialized
INFO - 2020-08-31 00:37:05 --> Language Class Initialized
INFO - 2020-08-31 00:37:05 --> Language Class Initialized
INFO - 2020-08-31 00:37:05 --> Config Class Initialized
INFO - 2020-08-31 00:37:05 --> Loader Class Initialized
INFO - 2020-08-31 00:37:05 --> Helper loaded: url_helper
INFO - 2020-08-31 00:37:05 --> Helper loaded: form_helper
INFO - 2020-08-31 00:37:05 --> Helper loaded: file_helper
INFO - 2020-08-31 00:37:05 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 00:37:05 --> Database Driver Class Initialized
DEBUG - 2020-08-31 00:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 00:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 00:37:05 --> Upload Class Initialized
INFO - 2020-08-31 00:37:05 --> Controller Class Initialized
ERROR - 2020-08-31 00:37:05 --> 404 Page Not Found: /index
INFO - 2020-08-31 01:46:59 --> Config Class Initialized
INFO - 2020-08-31 01:46:59 --> Hooks Class Initialized
DEBUG - 2020-08-31 01:46:59 --> UTF-8 Support Enabled
INFO - 2020-08-31 01:46:59 --> Utf8 Class Initialized
INFO - 2020-08-31 01:46:59 --> URI Class Initialized
INFO - 2020-08-31 01:46:59 --> Router Class Initialized
INFO - 2020-08-31 01:46:59 --> Output Class Initialized
INFO - 2020-08-31 01:46:59 --> Security Class Initialized
DEBUG - 2020-08-31 01:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 01:46:59 --> Input Class Initialized
INFO - 2020-08-31 01:46:59 --> Language Class Initialized
INFO - 2020-08-31 01:46:59 --> Language Class Initialized
INFO - 2020-08-31 01:46:59 --> Config Class Initialized
INFO - 2020-08-31 01:46:59 --> Loader Class Initialized
INFO - 2020-08-31 01:46:59 --> Helper loaded: url_helper
INFO - 2020-08-31 01:46:59 --> Helper loaded: form_helper
INFO - 2020-08-31 01:46:59 --> Helper loaded: file_helper
INFO - 2020-08-31 01:46:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 01:46:59 --> Database Driver Class Initialized
DEBUG - 2020-08-31 01:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 01:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 01:46:59 --> Upload Class Initialized
INFO - 2020-08-31 01:46:59 --> Controller Class Initialized
ERROR - 2020-08-31 01:46:59 --> 404 Page Not Found: /index
INFO - 2020-08-31 01:47:03 --> Config Class Initialized
INFO - 2020-08-31 01:47:03 --> Hooks Class Initialized
DEBUG - 2020-08-31 01:47:03 --> UTF-8 Support Enabled
INFO - 2020-08-31 01:47:03 --> Utf8 Class Initialized
INFO - 2020-08-31 01:47:03 --> URI Class Initialized
INFO - 2020-08-31 01:47:03 --> Router Class Initialized
INFO - 2020-08-31 01:47:03 --> Output Class Initialized
INFO - 2020-08-31 01:47:03 --> Security Class Initialized
DEBUG - 2020-08-31 01:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 01:47:03 --> Input Class Initialized
INFO - 2020-08-31 01:47:03 --> Language Class Initialized
INFO - 2020-08-31 01:47:03 --> Language Class Initialized
INFO - 2020-08-31 01:47:03 --> Config Class Initialized
INFO - 2020-08-31 01:47:03 --> Loader Class Initialized
INFO - 2020-08-31 01:47:03 --> Helper loaded: url_helper
INFO - 2020-08-31 01:47:03 --> Helper loaded: form_helper
INFO - 2020-08-31 01:47:03 --> Helper loaded: file_helper
INFO - 2020-08-31 01:47:03 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 01:47:03 --> Database Driver Class Initialized
DEBUG - 2020-08-31 01:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 01:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 01:47:03 --> Upload Class Initialized
INFO - 2020-08-31 01:47:03 --> Controller Class Initialized
DEBUG - 2020-08-31 01:47:03 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 01:47:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-31 01:47:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 01:47:03 --> Final output sent to browser
DEBUG - 2020-08-31 01:47:03 --> Total execution time: 0.1281
INFO - 2020-08-31 06:02:14 --> Config Class Initialized
INFO - 2020-08-31 06:02:14 --> Hooks Class Initialized
DEBUG - 2020-08-31 06:02:14 --> UTF-8 Support Enabled
INFO - 2020-08-31 06:02:14 --> Utf8 Class Initialized
INFO - 2020-08-31 06:02:14 --> URI Class Initialized
INFO - 2020-08-31 06:02:14 --> Router Class Initialized
INFO - 2020-08-31 06:02:14 --> Output Class Initialized
INFO - 2020-08-31 06:02:14 --> Security Class Initialized
DEBUG - 2020-08-31 06:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 06:02:14 --> Input Class Initialized
INFO - 2020-08-31 06:02:14 --> Language Class Initialized
INFO - 2020-08-31 06:02:14 --> Language Class Initialized
INFO - 2020-08-31 06:02:14 --> Config Class Initialized
INFO - 2020-08-31 06:02:14 --> Loader Class Initialized
INFO - 2020-08-31 06:02:14 --> Helper loaded: url_helper
INFO - 2020-08-31 06:02:14 --> Helper loaded: form_helper
INFO - 2020-08-31 06:02:14 --> Helper loaded: file_helper
INFO - 2020-08-31 06:02:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 06:02:14 --> Database Driver Class Initialized
DEBUG - 2020-08-31 06:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 06:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 06:02:14 --> Upload Class Initialized
INFO - 2020-08-31 06:02:14 --> Controller Class Initialized
ERROR - 2020-08-31 06:02:14 --> 404 Page Not Found: /index
INFO - 2020-08-31 06:02:17 --> Config Class Initialized
INFO - 2020-08-31 06:02:17 --> Hooks Class Initialized
DEBUG - 2020-08-31 06:02:17 --> UTF-8 Support Enabled
INFO - 2020-08-31 06:02:17 --> Utf8 Class Initialized
INFO - 2020-08-31 06:02:17 --> URI Class Initialized
INFO - 2020-08-31 06:02:17 --> Router Class Initialized
INFO - 2020-08-31 06:02:17 --> Output Class Initialized
INFO - 2020-08-31 06:02:17 --> Security Class Initialized
DEBUG - 2020-08-31 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 06:02:17 --> Input Class Initialized
INFO - 2020-08-31 06:02:17 --> Language Class Initialized
INFO - 2020-08-31 06:02:17 --> Language Class Initialized
INFO - 2020-08-31 06:02:17 --> Config Class Initialized
INFO - 2020-08-31 06:02:17 --> Loader Class Initialized
INFO - 2020-08-31 06:02:17 --> Helper loaded: url_helper
INFO - 2020-08-31 06:02:17 --> Helper loaded: form_helper
INFO - 2020-08-31 06:02:17 --> Helper loaded: file_helper
INFO - 2020-08-31 06:02:17 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 06:02:17 --> Database Driver Class Initialized
DEBUG - 2020-08-31 06:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 06:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 06:02:17 --> Upload Class Initialized
INFO - 2020-08-31 06:02:17 --> Controller Class Initialized
DEBUG - 2020-08-31 06:02:17 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 06:02:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-31 06:02:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 06:02:17 --> Final output sent to browser
DEBUG - 2020-08-31 06:02:17 --> Total execution time: 0.0624
INFO - 2020-08-31 08:14:45 --> Config Class Initialized
INFO - 2020-08-31 08:14:45 --> Hooks Class Initialized
DEBUG - 2020-08-31 08:14:45 --> UTF-8 Support Enabled
INFO - 2020-08-31 08:14:45 --> Utf8 Class Initialized
INFO - 2020-08-31 08:14:45 --> URI Class Initialized
DEBUG - 2020-08-31 08:14:45 --> No URI present. Default controller set.
INFO - 2020-08-31 08:14:45 --> Router Class Initialized
INFO - 2020-08-31 08:14:45 --> Output Class Initialized
INFO - 2020-08-31 08:14:45 --> Security Class Initialized
DEBUG - 2020-08-31 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 08:14:45 --> Input Class Initialized
INFO - 2020-08-31 08:14:45 --> Language Class Initialized
INFO - 2020-08-31 08:14:45 --> Language Class Initialized
INFO - 2020-08-31 08:14:45 --> Config Class Initialized
INFO - 2020-08-31 08:14:45 --> Loader Class Initialized
INFO - 2020-08-31 08:14:45 --> Helper loaded: url_helper
INFO - 2020-08-31 08:14:45 --> Helper loaded: form_helper
INFO - 2020-08-31 08:14:45 --> Helper loaded: file_helper
INFO - 2020-08-31 08:14:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 08:14:45 --> Database Driver Class Initialized
DEBUG - 2020-08-31 08:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 08:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 08:14:45 --> Upload Class Initialized
INFO - 2020-08-31 08:14:45 --> Controller Class Initialized
DEBUG - 2020-08-31 08:14:45 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 08:14:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 08:14:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 08:14:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 08:14:45 --> Final output sent to browser
DEBUG - 2020-08-31 08:14:45 --> Total execution time: 0.0587
INFO - 2020-08-31 08:31:33 --> Config Class Initialized
INFO - 2020-08-31 08:31:33 --> Hooks Class Initialized
DEBUG - 2020-08-31 08:31:33 --> UTF-8 Support Enabled
INFO - 2020-08-31 08:31:33 --> Utf8 Class Initialized
INFO - 2020-08-31 08:31:33 --> URI Class Initialized
DEBUG - 2020-08-31 08:31:33 --> No URI present. Default controller set.
INFO - 2020-08-31 08:31:33 --> Router Class Initialized
INFO - 2020-08-31 08:31:33 --> Output Class Initialized
INFO - 2020-08-31 08:31:33 --> Security Class Initialized
DEBUG - 2020-08-31 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 08:31:33 --> Input Class Initialized
INFO - 2020-08-31 08:31:33 --> Language Class Initialized
INFO - 2020-08-31 08:31:33 --> Language Class Initialized
INFO - 2020-08-31 08:31:33 --> Config Class Initialized
INFO - 2020-08-31 08:31:33 --> Loader Class Initialized
INFO - 2020-08-31 08:31:33 --> Helper loaded: url_helper
INFO - 2020-08-31 08:31:33 --> Helper loaded: form_helper
INFO - 2020-08-31 08:31:33 --> Helper loaded: file_helper
INFO - 2020-08-31 08:31:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 08:31:33 --> Database Driver Class Initialized
DEBUG - 2020-08-31 08:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 08:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 08:31:33 --> Upload Class Initialized
INFO - 2020-08-31 08:31:33 --> Controller Class Initialized
DEBUG - 2020-08-31 08:31:33 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 08:31:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 08:31:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 08:31:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 08:31:33 --> Final output sent to browser
DEBUG - 2020-08-31 08:31:33 --> Total execution time: 0.0622
INFO - 2020-08-31 09:33:47 --> Config Class Initialized
INFO - 2020-08-31 09:33:47 --> Hooks Class Initialized
DEBUG - 2020-08-31 09:33:47 --> UTF-8 Support Enabled
INFO - 2020-08-31 09:33:47 --> Utf8 Class Initialized
INFO - 2020-08-31 09:33:47 --> URI Class Initialized
INFO - 2020-08-31 09:33:47 --> Router Class Initialized
INFO - 2020-08-31 09:33:47 --> Output Class Initialized
INFO - 2020-08-31 09:33:47 --> Security Class Initialized
DEBUG - 2020-08-31 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 09:33:47 --> Input Class Initialized
INFO - 2020-08-31 09:33:47 --> Language Class Initialized
INFO - 2020-08-31 09:33:47 --> Language Class Initialized
INFO - 2020-08-31 09:33:47 --> Config Class Initialized
INFO - 2020-08-31 09:33:47 --> Loader Class Initialized
INFO - 2020-08-31 09:33:47 --> Helper loaded: url_helper
INFO - 2020-08-31 09:33:47 --> Helper loaded: form_helper
INFO - 2020-08-31 09:33:47 --> Helper loaded: file_helper
INFO - 2020-08-31 09:33:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 09:33:47 --> Database Driver Class Initialized
DEBUG - 2020-08-31 09:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 09:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 09:33:47 --> Upload Class Initialized
INFO - 2020-08-31 09:33:47 --> Controller Class Initialized
ERROR - 2020-08-31 09:33:47 --> 404 Page Not Found: /index
INFO - 2020-08-31 09:33:47 --> Config Class Initialized
INFO - 2020-08-31 09:33:47 --> Hooks Class Initialized
DEBUG - 2020-08-31 09:33:47 --> UTF-8 Support Enabled
INFO - 2020-08-31 09:33:47 --> Utf8 Class Initialized
INFO - 2020-08-31 09:33:47 --> URI Class Initialized
INFO - 2020-08-31 09:33:47 --> Router Class Initialized
INFO - 2020-08-31 09:33:47 --> Output Class Initialized
INFO - 2020-08-31 09:33:47 --> Security Class Initialized
DEBUG - 2020-08-31 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 09:33:47 --> Input Class Initialized
INFO - 2020-08-31 09:33:47 --> Language Class Initialized
INFO - 2020-08-31 09:33:47 --> Language Class Initialized
INFO - 2020-08-31 09:33:47 --> Config Class Initialized
INFO - 2020-08-31 09:33:47 --> Loader Class Initialized
INFO - 2020-08-31 09:33:47 --> Helper loaded: url_helper
INFO - 2020-08-31 09:33:47 --> Helper loaded: form_helper
INFO - 2020-08-31 09:33:47 --> Helper loaded: file_helper
INFO - 2020-08-31 09:33:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 09:33:47 --> Database Driver Class Initialized
DEBUG - 2020-08-31 09:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 09:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 09:33:47 --> Upload Class Initialized
INFO - 2020-08-31 09:33:47 --> Controller Class Initialized
DEBUG - 2020-08-31 09:33:47 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 09:33:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-31 09:33:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 09:33:47 --> Final output sent to browser
DEBUG - 2020-08-31 09:33:47 --> Total execution time: 0.0699
INFO - 2020-08-31 09:36:10 --> Config Class Initialized
INFO - 2020-08-31 09:36:10 --> Hooks Class Initialized
DEBUG - 2020-08-31 09:36:10 --> UTF-8 Support Enabled
INFO - 2020-08-31 09:36:10 --> Utf8 Class Initialized
INFO - 2020-08-31 09:36:10 --> URI Class Initialized
DEBUG - 2020-08-31 09:36:10 --> No URI present. Default controller set.
INFO - 2020-08-31 09:36:10 --> Router Class Initialized
INFO - 2020-08-31 09:36:10 --> Output Class Initialized
INFO - 2020-08-31 09:36:10 --> Security Class Initialized
DEBUG - 2020-08-31 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 09:36:10 --> Input Class Initialized
INFO - 2020-08-31 09:36:10 --> Language Class Initialized
INFO - 2020-08-31 09:36:10 --> Language Class Initialized
INFO - 2020-08-31 09:36:10 --> Config Class Initialized
INFO - 2020-08-31 09:36:10 --> Loader Class Initialized
INFO - 2020-08-31 09:36:10 --> Helper loaded: url_helper
INFO - 2020-08-31 09:36:10 --> Helper loaded: form_helper
INFO - 2020-08-31 09:36:10 --> Helper loaded: file_helper
INFO - 2020-08-31 09:36:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 09:36:10 --> Database Driver Class Initialized
DEBUG - 2020-08-31 09:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 09:36:10 --> Upload Class Initialized
INFO - 2020-08-31 09:36:10 --> Controller Class Initialized
DEBUG - 2020-08-31 09:36:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 09:36:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 09:36:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 09:36:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 09:36:10 --> Final output sent to browser
DEBUG - 2020-08-31 09:36:10 --> Total execution time: 0.0622
INFO - 2020-08-31 09:36:10 --> Config Class Initialized
INFO - 2020-08-31 09:36:10 --> Hooks Class Initialized
DEBUG - 2020-08-31 09:36:10 --> UTF-8 Support Enabled
INFO - 2020-08-31 09:36:10 --> Utf8 Class Initialized
INFO - 2020-08-31 09:36:10 --> URI Class Initialized
DEBUG - 2020-08-31 09:36:10 --> No URI present. Default controller set.
INFO - 2020-08-31 09:36:10 --> Router Class Initialized
INFO - 2020-08-31 09:36:10 --> Output Class Initialized
INFO - 2020-08-31 09:36:10 --> Security Class Initialized
DEBUG - 2020-08-31 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 09:36:10 --> Input Class Initialized
INFO - 2020-08-31 09:36:10 --> Language Class Initialized
INFO - 2020-08-31 09:36:10 --> Language Class Initialized
INFO - 2020-08-31 09:36:10 --> Config Class Initialized
INFO - 2020-08-31 09:36:10 --> Loader Class Initialized
INFO - 2020-08-31 09:36:10 --> Helper loaded: url_helper
INFO - 2020-08-31 09:36:10 --> Helper loaded: form_helper
INFO - 2020-08-31 09:36:10 --> Helper loaded: file_helper
INFO - 2020-08-31 09:36:10 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 09:36:10 --> Database Driver Class Initialized
DEBUG - 2020-08-31 09:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 09:36:10 --> Upload Class Initialized
INFO - 2020-08-31 09:36:10 --> Controller Class Initialized
DEBUG - 2020-08-31 09:36:10 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 09:36:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 09:36:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 09:36:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 09:36:10 --> Final output sent to browser
DEBUG - 2020-08-31 09:36:10 --> Total execution time: 0.0524
INFO - 2020-08-31 09:40:09 --> Config Class Initialized
INFO - 2020-08-31 09:40:09 --> Hooks Class Initialized
DEBUG - 2020-08-31 09:40:09 --> UTF-8 Support Enabled
INFO - 2020-08-31 09:40:09 --> Utf8 Class Initialized
INFO - 2020-08-31 09:40:09 --> URI Class Initialized
DEBUG - 2020-08-31 09:40:09 --> No URI present. Default controller set.
INFO - 2020-08-31 09:40:09 --> Router Class Initialized
INFO - 2020-08-31 09:40:09 --> Output Class Initialized
INFO - 2020-08-31 09:40:09 --> Security Class Initialized
DEBUG - 2020-08-31 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 09:40:09 --> Input Class Initialized
INFO - 2020-08-31 09:40:09 --> Language Class Initialized
INFO - 2020-08-31 09:40:09 --> Language Class Initialized
INFO - 2020-08-31 09:40:09 --> Config Class Initialized
INFO - 2020-08-31 09:40:09 --> Loader Class Initialized
INFO - 2020-08-31 09:40:09 --> Helper loaded: url_helper
INFO - 2020-08-31 09:40:09 --> Helper loaded: form_helper
INFO - 2020-08-31 09:40:09 --> Helper loaded: file_helper
INFO - 2020-08-31 09:40:09 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 09:40:09 --> Database Driver Class Initialized
DEBUG - 2020-08-31 09:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 09:40:09 --> Upload Class Initialized
INFO - 2020-08-31 09:40:09 --> Controller Class Initialized
DEBUG - 2020-08-31 09:40:09 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 09:40:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 09:40:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 09:40:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 09:40:09 --> Final output sent to browser
DEBUG - 2020-08-31 09:40:09 --> Total execution time: 0.0996
INFO - 2020-08-31 10:09:14 --> Config Class Initialized
INFO - 2020-08-31 10:09:14 --> Hooks Class Initialized
DEBUG - 2020-08-31 10:09:14 --> UTF-8 Support Enabled
INFO - 2020-08-31 10:09:14 --> Utf8 Class Initialized
INFO - 2020-08-31 10:09:14 --> URI Class Initialized
INFO - 2020-08-31 10:09:14 --> Router Class Initialized
INFO - 2020-08-31 10:09:14 --> Output Class Initialized
INFO - 2020-08-31 10:09:14 --> Security Class Initialized
DEBUG - 2020-08-31 10:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 10:09:14 --> Input Class Initialized
INFO - 2020-08-31 10:09:14 --> Language Class Initialized
INFO - 2020-08-31 10:09:14 --> Language Class Initialized
INFO - 2020-08-31 10:09:14 --> Config Class Initialized
INFO - 2020-08-31 10:09:14 --> Loader Class Initialized
INFO - 2020-08-31 10:09:14 --> Helper loaded: url_helper
INFO - 2020-08-31 10:09:14 --> Helper loaded: form_helper
INFO - 2020-08-31 10:09:14 --> Helper loaded: file_helper
INFO - 2020-08-31 10:09:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 10:09:14 --> Database Driver Class Initialized
DEBUG - 2020-08-31 10:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 10:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 10:09:14 --> Upload Class Initialized
INFO - 2020-08-31 10:09:14 --> Controller Class Initialized
ERROR - 2020-08-31 10:09:14 --> 404 Page Not Found: /index
INFO - 2020-08-31 10:17:39 --> Config Class Initialized
INFO - 2020-08-31 10:17:39 --> Hooks Class Initialized
DEBUG - 2020-08-31 10:17:39 --> UTF-8 Support Enabled
INFO - 2020-08-31 10:17:39 --> Utf8 Class Initialized
INFO - 2020-08-31 10:17:39 --> URI Class Initialized
INFO - 2020-08-31 10:17:39 --> Router Class Initialized
INFO - 2020-08-31 10:17:39 --> Output Class Initialized
INFO - 2020-08-31 10:17:39 --> Security Class Initialized
DEBUG - 2020-08-31 10:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 10:17:39 --> Input Class Initialized
INFO - 2020-08-31 10:17:39 --> Language Class Initialized
INFO - 2020-08-31 10:17:39 --> Language Class Initialized
INFO - 2020-08-31 10:17:39 --> Config Class Initialized
INFO - 2020-08-31 10:17:39 --> Loader Class Initialized
INFO - 2020-08-31 10:17:39 --> Helper loaded: url_helper
INFO - 2020-08-31 10:17:39 --> Helper loaded: form_helper
INFO - 2020-08-31 10:17:39 --> Helper loaded: file_helper
INFO - 2020-08-31 10:17:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 10:17:39 --> Database Driver Class Initialized
DEBUG - 2020-08-31 10:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 10:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 10:17:39 --> Upload Class Initialized
INFO - 2020-08-31 10:17:39 --> Controller Class Initialized
ERROR - 2020-08-31 10:17:39 --> 404 Page Not Found: /index
INFO - 2020-08-31 10:17:42 --> Config Class Initialized
INFO - 2020-08-31 10:17:42 --> Hooks Class Initialized
DEBUG - 2020-08-31 10:17:42 --> UTF-8 Support Enabled
INFO - 2020-08-31 10:17:42 --> Utf8 Class Initialized
INFO - 2020-08-31 10:17:42 --> URI Class Initialized
INFO - 2020-08-31 10:17:42 --> Router Class Initialized
INFO - 2020-08-31 10:17:42 --> Output Class Initialized
INFO - 2020-08-31 10:17:42 --> Security Class Initialized
DEBUG - 2020-08-31 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 10:17:42 --> Input Class Initialized
INFO - 2020-08-31 10:17:42 --> Language Class Initialized
INFO - 2020-08-31 10:17:42 --> Language Class Initialized
INFO - 2020-08-31 10:17:42 --> Config Class Initialized
INFO - 2020-08-31 10:17:42 --> Loader Class Initialized
INFO - 2020-08-31 10:17:42 --> Helper loaded: url_helper
INFO - 2020-08-31 10:17:42 --> Helper loaded: form_helper
INFO - 2020-08-31 10:17:42 --> Helper loaded: file_helper
INFO - 2020-08-31 10:17:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 10:17:42 --> Database Driver Class Initialized
DEBUG - 2020-08-31 10:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 10:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 10:17:42 --> Upload Class Initialized
INFO - 2020-08-31 10:17:42 --> Controller Class Initialized
DEBUG - 2020-08-31 10:17:42 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 10:17:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-31 10:17:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 10:17:42 --> Final output sent to browser
DEBUG - 2020-08-31 10:17:42 --> Total execution time: 0.0508
INFO - 2020-08-31 10:45:59 --> Config Class Initialized
INFO - 2020-08-31 10:45:59 --> Hooks Class Initialized
DEBUG - 2020-08-31 10:45:59 --> UTF-8 Support Enabled
INFO - 2020-08-31 10:45:59 --> Utf8 Class Initialized
INFO - 2020-08-31 10:45:59 --> URI Class Initialized
INFO - 2020-08-31 10:45:59 --> Router Class Initialized
INFO - 2020-08-31 10:45:59 --> Output Class Initialized
INFO - 2020-08-31 10:45:59 --> Security Class Initialized
DEBUG - 2020-08-31 10:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 10:45:59 --> Input Class Initialized
INFO - 2020-08-31 10:45:59 --> Language Class Initialized
INFO - 2020-08-31 10:45:59 --> Language Class Initialized
INFO - 2020-08-31 10:45:59 --> Config Class Initialized
INFO - 2020-08-31 10:45:59 --> Loader Class Initialized
INFO - 2020-08-31 10:45:59 --> Helper loaded: url_helper
INFO - 2020-08-31 10:45:59 --> Helper loaded: form_helper
INFO - 2020-08-31 10:45:59 --> Helper loaded: file_helper
INFO - 2020-08-31 10:45:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 10:45:59 --> Database Driver Class Initialized
DEBUG - 2020-08-31 10:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 10:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 10:45:59 --> Upload Class Initialized
INFO - 2020-08-31 10:45:59 --> Controller Class Initialized
ERROR - 2020-08-31 10:45:59 --> 404 Page Not Found: /index
INFO - 2020-08-31 10:48:08 --> Config Class Initialized
INFO - 2020-08-31 10:48:08 --> Hooks Class Initialized
DEBUG - 2020-08-31 10:48:08 --> UTF-8 Support Enabled
INFO - 2020-08-31 10:48:08 --> Utf8 Class Initialized
INFO - 2020-08-31 10:48:08 --> URI Class Initialized
INFO - 2020-08-31 10:48:08 --> Router Class Initialized
INFO - 2020-08-31 10:48:08 --> Output Class Initialized
INFO - 2020-08-31 10:48:08 --> Security Class Initialized
DEBUG - 2020-08-31 10:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 10:48:08 --> Input Class Initialized
INFO - 2020-08-31 10:48:08 --> Language Class Initialized
INFO - 2020-08-31 10:48:08 --> Language Class Initialized
INFO - 2020-08-31 10:48:08 --> Config Class Initialized
INFO - 2020-08-31 10:48:08 --> Loader Class Initialized
INFO - 2020-08-31 10:48:08 --> Helper loaded: url_helper
INFO - 2020-08-31 10:48:08 --> Helper loaded: form_helper
INFO - 2020-08-31 10:48:08 --> Helper loaded: file_helper
INFO - 2020-08-31 10:48:08 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 10:48:08 --> Database Driver Class Initialized
DEBUG - 2020-08-31 10:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 10:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 10:48:08 --> Upload Class Initialized
INFO - 2020-08-31 10:48:08 --> Controller Class Initialized
DEBUG - 2020-08-31 10:48:08 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 10:48:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-31 10:48:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 10:48:08 --> Final output sent to browser
DEBUG - 2020-08-31 10:48:08 --> Total execution time: 0.0788
INFO - 2020-08-31 10:48:14 --> Config Class Initialized
INFO - 2020-08-31 10:48:14 --> Hooks Class Initialized
DEBUG - 2020-08-31 10:48:14 --> UTF-8 Support Enabled
INFO - 2020-08-31 10:48:14 --> Utf8 Class Initialized
INFO - 2020-08-31 10:48:14 --> URI Class Initialized
INFO - 2020-08-31 10:48:14 --> Router Class Initialized
INFO - 2020-08-31 10:48:14 --> Output Class Initialized
INFO - 2020-08-31 10:48:14 --> Security Class Initialized
DEBUG - 2020-08-31 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 10:48:14 --> Input Class Initialized
INFO - 2020-08-31 10:48:14 --> Language Class Initialized
INFO - 2020-08-31 10:48:14 --> Language Class Initialized
INFO - 2020-08-31 10:48:14 --> Config Class Initialized
INFO - 2020-08-31 10:48:14 --> Loader Class Initialized
INFO - 2020-08-31 10:48:14 --> Helper loaded: url_helper
INFO - 2020-08-31 10:48:14 --> Helper loaded: form_helper
INFO - 2020-08-31 10:48:14 --> Helper loaded: file_helper
INFO - 2020-08-31 10:48:14 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 10:48:14 --> Database Driver Class Initialized
DEBUG - 2020-08-31 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 10:48:14 --> Upload Class Initialized
INFO - 2020-08-31 10:48:14 --> Controller Class Initialized
ERROR - 2020-08-31 10:48:14 --> 404 Page Not Found: /index
INFO - 2020-08-31 11:16:28 --> Config Class Initialized
INFO - 2020-08-31 11:16:28 --> Hooks Class Initialized
DEBUG - 2020-08-31 11:16:28 --> UTF-8 Support Enabled
INFO - 2020-08-31 11:16:28 --> Utf8 Class Initialized
INFO - 2020-08-31 11:16:28 --> URI Class Initialized
INFO - 2020-08-31 11:16:28 --> Router Class Initialized
INFO - 2020-08-31 11:16:28 --> Output Class Initialized
INFO - 2020-08-31 11:16:28 --> Security Class Initialized
DEBUG - 2020-08-31 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 11:16:28 --> Input Class Initialized
INFO - 2020-08-31 11:16:28 --> Language Class Initialized
INFO - 2020-08-31 11:16:28 --> Language Class Initialized
INFO - 2020-08-31 11:16:28 --> Config Class Initialized
INFO - 2020-08-31 11:16:28 --> Loader Class Initialized
INFO - 2020-08-31 11:16:28 --> Helper loaded: url_helper
INFO - 2020-08-31 11:16:28 --> Helper loaded: form_helper
INFO - 2020-08-31 11:16:28 --> Helper loaded: file_helper
INFO - 2020-08-31 11:16:28 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 11:16:28 --> Database Driver Class Initialized
DEBUG - 2020-08-31 11:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 11:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 11:16:28 --> Upload Class Initialized
INFO - 2020-08-31 11:16:28 --> Controller Class Initialized
ERROR - 2020-08-31 11:16:28 --> 404 Page Not Found: /index
INFO - 2020-08-31 11:20:34 --> Config Class Initialized
INFO - 2020-08-31 11:20:34 --> Hooks Class Initialized
DEBUG - 2020-08-31 11:20:34 --> UTF-8 Support Enabled
INFO - 2020-08-31 11:20:34 --> Utf8 Class Initialized
INFO - 2020-08-31 11:20:34 --> URI Class Initialized
DEBUG - 2020-08-31 11:20:34 --> No URI present. Default controller set.
INFO - 2020-08-31 11:20:34 --> Router Class Initialized
INFO - 2020-08-31 11:20:34 --> Output Class Initialized
INFO - 2020-08-31 11:20:34 --> Security Class Initialized
DEBUG - 2020-08-31 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 11:20:34 --> Input Class Initialized
INFO - 2020-08-31 11:20:34 --> Language Class Initialized
INFO - 2020-08-31 11:20:34 --> Language Class Initialized
INFO - 2020-08-31 11:20:34 --> Config Class Initialized
INFO - 2020-08-31 11:20:34 --> Loader Class Initialized
INFO - 2020-08-31 11:20:34 --> Helper loaded: url_helper
INFO - 2020-08-31 11:20:34 --> Helper loaded: form_helper
INFO - 2020-08-31 11:20:34 --> Helper loaded: file_helper
INFO - 2020-08-31 11:20:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 11:20:34 --> Database Driver Class Initialized
DEBUG - 2020-08-31 11:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 11:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 11:20:34 --> Upload Class Initialized
INFO - 2020-08-31 11:20:34 --> Controller Class Initialized
DEBUG - 2020-08-31 11:20:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 11:20:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 11:20:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 11:20:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 11:20:34 --> Final output sent to browser
DEBUG - 2020-08-31 11:20:34 --> Total execution time: 0.0671
INFO - 2020-08-31 11:20:34 --> Config Class Initialized
INFO - 2020-08-31 11:20:34 --> Hooks Class Initialized
DEBUG - 2020-08-31 11:20:34 --> UTF-8 Support Enabled
INFO - 2020-08-31 11:20:34 --> Utf8 Class Initialized
INFO - 2020-08-31 11:20:34 --> URI Class Initialized
DEBUG - 2020-08-31 11:20:34 --> No URI present. Default controller set.
INFO - 2020-08-31 11:20:34 --> Router Class Initialized
INFO - 2020-08-31 11:20:34 --> Output Class Initialized
INFO - 2020-08-31 11:20:34 --> Security Class Initialized
DEBUG - 2020-08-31 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 11:20:34 --> Input Class Initialized
INFO - 2020-08-31 11:20:34 --> Language Class Initialized
INFO - 2020-08-31 11:20:34 --> Language Class Initialized
INFO - 2020-08-31 11:20:34 --> Config Class Initialized
INFO - 2020-08-31 11:20:34 --> Loader Class Initialized
INFO - 2020-08-31 11:20:34 --> Helper loaded: url_helper
INFO - 2020-08-31 11:20:34 --> Helper loaded: form_helper
INFO - 2020-08-31 11:20:34 --> Helper loaded: file_helper
INFO - 2020-08-31 11:20:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 11:20:34 --> Database Driver Class Initialized
DEBUG - 2020-08-31 11:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 11:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 11:20:34 --> Upload Class Initialized
INFO - 2020-08-31 11:20:34 --> Controller Class Initialized
DEBUG - 2020-08-31 11:20:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 11:20:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 11:20:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 11:20:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 11:20:34 --> Final output sent to browser
DEBUG - 2020-08-31 11:20:34 --> Total execution time: 0.0708
INFO - 2020-08-31 11:27:39 --> Config Class Initialized
INFO - 2020-08-31 11:27:39 --> Hooks Class Initialized
DEBUG - 2020-08-31 11:27:39 --> UTF-8 Support Enabled
INFO - 2020-08-31 11:27:39 --> Utf8 Class Initialized
INFO - 2020-08-31 11:27:39 --> URI Class Initialized
INFO - 2020-08-31 11:27:39 --> Router Class Initialized
INFO - 2020-08-31 11:27:39 --> Output Class Initialized
INFO - 2020-08-31 11:27:39 --> Security Class Initialized
DEBUG - 2020-08-31 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 11:27:39 --> Input Class Initialized
INFO - 2020-08-31 11:27:39 --> Language Class Initialized
INFO - 2020-08-31 11:27:39 --> Language Class Initialized
INFO - 2020-08-31 11:27:39 --> Config Class Initialized
INFO - 2020-08-31 11:27:39 --> Loader Class Initialized
INFO - 2020-08-31 11:27:39 --> Helper loaded: url_helper
INFO - 2020-08-31 11:27:39 --> Helper loaded: form_helper
INFO - 2020-08-31 11:27:39 --> Helper loaded: file_helper
INFO - 2020-08-31 11:27:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 11:27:39 --> Database Driver Class Initialized
DEBUG - 2020-08-31 11:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 11:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 11:27:39 --> Upload Class Initialized
INFO - 2020-08-31 11:27:39 --> Controller Class Initialized
DEBUG - 2020-08-31 11:27:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 11:27:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-31 11:27:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 11:27:39 --> Final output sent to browser
DEBUG - 2020-08-31 11:27:39 --> Total execution time: 0.0572
INFO - 2020-08-31 13:41:50 --> Config Class Initialized
INFO - 2020-08-31 13:41:50 --> Hooks Class Initialized
DEBUG - 2020-08-31 13:41:50 --> UTF-8 Support Enabled
INFO - 2020-08-31 13:41:50 --> Utf8 Class Initialized
INFO - 2020-08-31 13:41:50 --> URI Class Initialized
INFO - 2020-08-31 13:41:50 --> Router Class Initialized
INFO - 2020-08-31 13:41:50 --> Output Class Initialized
INFO - 2020-08-31 13:41:50 --> Security Class Initialized
DEBUG - 2020-08-31 13:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 13:41:50 --> Input Class Initialized
INFO - 2020-08-31 13:41:50 --> Language Class Initialized
INFO - 2020-08-31 13:41:50 --> Language Class Initialized
INFO - 2020-08-31 13:41:50 --> Config Class Initialized
INFO - 2020-08-31 13:41:50 --> Loader Class Initialized
INFO - 2020-08-31 13:41:50 --> Helper loaded: url_helper
INFO - 2020-08-31 13:41:50 --> Helper loaded: form_helper
INFO - 2020-08-31 13:41:50 --> Helper loaded: file_helper
INFO - 2020-08-31 13:41:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 13:41:50 --> Database Driver Class Initialized
DEBUG - 2020-08-31 13:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 13:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 13:41:50 --> Upload Class Initialized
INFO - 2020-08-31 13:41:50 --> Controller Class Initialized
ERROR - 2020-08-31 13:41:50 --> 404 Page Not Found: /index
INFO - 2020-08-31 13:41:51 --> Config Class Initialized
INFO - 2020-08-31 13:41:51 --> Hooks Class Initialized
DEBUG - 2020-08-31 13:41:51 --> UTF-8 Support Enabled
INFO - 2020-08-31 13:41:51 --> Utf8 Class Initialized
INFO - 2020-08-31 13:41:51 --> URI Class Initialized
INFO - 2020-08-31 13:41:51 --> Router Class Initialized
INFO - 2020-08-31 13:41:51 --> Output Class Initialized
INFO - 2020-08-31 13:41:51 --> Security Class Initialized
DEBUG - 2020-08-31 13:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 13:41:51 --> Input Class Initialized
INFO - 2020-08-31 13:41:51 --> Language Class Initialized
INFO - 2020-08-31 13:41:51 --> Language Class Initialized
INFO - 2020-08-31 13:41:51 --> Config Class Initialized
INFO - 2020-08-31 13:41:51 --> Loader Class Initialized
INFO - 2020-08-31 13:41:51 --> Helper loaded: url_helper
INFO - 2020-08-31 13:41:51 --> Helper loaded: form_helper
INFO - 2020-08-31 13:41:51 --> Helper loaded: file_helper
INFO - 2020-08-31 13:41:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 13:41:51 --> Database Driver Class Initialized
DEBUG - 2020-08-31 13:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 13:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 13:41:51 --> Upload Class Initialized
INFO - 2020-08-31 13:41:51 --> Controller Class Initialized
ERROR - 2020-08-31 13:41:51 --> 404 Page Not Found: /index
INFO - 2020-08-31 13:41:52 --> Config Class Initialized
INFO - 2020-08-31 13:41:52 --> Hooks Class Initialized
DEBUG - 2020-08-31 13:41:52 --> UTF-8 Support Enabled
INFO - 2020-08-31 13:41:52 --> Utf8 Class Initialized
INFO - 2020-08-31 13:41:52 --> URI Class Initialized
INFO - 2020-08-31 13:41:52 --> Router Class Initialized
INFO - 2020-08-31 13:41:52 --> Output Class Initialized
INFO - 2020-08-31 13:41:52 --> Security Class Initialized
DEBUG - 2020-08-31 13:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 13:41:52 --> Input Class Initialized
INFO - 2020-08-31 13:41:52 --> Language Class Initialized
INFO - 2020-08-31 13:41:52 --> Language Class Initialized
INFO - 2020-08-31 13:41:52 --> Config Class Initialized
INFO - 2020-08-31 13:41:52 --> Loader Class Initialized
INFO - 2020-08-31 13:41:52 --> Helper loaded: url_helper
INFO - 2020-08-31 13:41:52 --> Helper loaded: form_helper
INFO - 2020-08-31 13:41:52 --> Helper loaded: file_helper
INFO - 2020-08-31 13:41:52 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 13:41:52 --> Database Driver Class Initialized
DEBUG - 2020-08-31 13:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 13:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 13:41:52 --> Upload Class Initialized
INFO - 2020-08-31 13:41:52 --> Controller Class Initialized
ERROR - 2020-08-31 13:41:52 --> 404 Page Not Found: /index
INFO - 2020-08-31 13:41:54 --> Config Class Initialized
INFO - 2020-08-31 13:41:54 --> Hooks Class Initialized
DEBUG - 2020-08-31 13:41:54 --> UTF-8 Support Enabled
INFO - 2020-08-31 13:41:54 --> Utf8 Class Initialized
INFO - 2020-08-31 13:41:54 --> URI Class Initialized
DEBUG - 2020-08-31 13:41:54 --> No URI present. Default controller set.
INFO - 2020-08-31 13:41:54 --> Router Class Initialized
INFO - 2020-08-31 13:41:54 --> Output Class Initialized
INFO - 2020-08-31 13:41:54 --> Security Class Initialized
DEBUG - 2020-08-31 13:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 13:41:54 --> Input Class Initialized
INFO - 2020-08-31 13:41:54 --> Language Class Initialized
INFO - 2020-08-31 13:41:54 --> Language Class Initialized
INFO - 2020-08-31 13:41:54 --> Config Class Initialized
INFO - 2020-08-31 13:41:54 --> Loader Class Initialized
INFO - 2020-08-31 13:41:54 --> Helper loaded: url_helper
INFO - 2020-08-31 13:41:54 --> Helper loaded: form_helper
INFO - 2020-08-31 13:41:54 --> Helper loaded: file_helper
INFO - 2020-08-31 13:41:54 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 13:41:54 --> Database Driver Class Initialized
DEBUG - 2020-08-31 13:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 13:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 13:41:54 --> Upload Class Initialized
INFO - 2020-08-31 13:41:54 --> Controller Class Initialized
DEBUG - 2020-08-31 13:41:54 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 13:41:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 13:41:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 13:41:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 13:41:54 --> Final output sent to browser
DEBUG - 2020-08-31 13:41:54 --> Total execution time: 0.0590
INFO - 2020-08-31 14:58:48 --> Config Class Initialized
INFO - 2020-08-31 14:58:48 --> Hooks Class Initialized
DEBUG - 2020-08-31 14:58:48 --> UTF-8 Support Enabled
INFO - 2020-08-31 14:58:48 --> Utf8 Class Initialized
INFO - 2020-08-31 14:58:48 --> URI Class Initialized
INFO - 2020-08-31 14:58:48 --> Router Class Initialized
INFO - 2020-08-31 14:58:48 --> Output Class Initialized
INFO - 2020-08-31 14:58:48 --> Security Class Initialized
DEBUG - 2020-08-31 14:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 14:58:48 --> Input Class Initialized
INFO - 2020-08-31 14:58:48 --> Language Class Initialized
INFO - 2020-08-31 14:58:48 --> Language Class Initialized
INFO - 2020-08-31 14:58:48 --> Config Class Initialized
INFO - 2020-08-31 14:58:48 --> Loader Class Initialized
INFO - 2020-08-31 14:58:48 --> Helper loaded: url_helper
INFO - 2020-08-31 14:58:48 --> Helper loaded: form_helper
INFO - 2020-08-31 14:58:48 --> Helper loaded: file_helper
INFO - 2020-08-31 14:58:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 14:58:48 --> Database Driver Class Initialized
DEBUG - 2020-08-31 14:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 14:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 14:58:48 --> Upload Class Initialized
INFO - 2020-08-31 14:58:48 --> Controller Class Initialized
ERROR - 2020-08-31 14:58:48 --> 404 Page Not Found: /index
INFO - 2020-08-31 14:58:48 --> Config Class Initialized
INFO - 2020-08-31 14:58:48 --> Hooks Class Initialized
DEBUG - 2020-08-31 14:58:48 --> UTF-8 Support Enabled
INFO - 2020-08-31 14:58:48 --> Utf8 Class Initialized
INFO - 2020-08-31 14:58:48 --> URI Class Initialized
DEBUG - 2020-08-31 14:58:48 --> No URI present. Default controller set.
INFO - 2020-08-31 14:58:48 --> Router Class Initialized
INFO - 2020-08-31 14:58:48 --> Output Class Initialized
INFO - 2020-08-31 14:58:48 --> Security Class Initialized
DEBUG - 2020-08-31 14:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 14:58:48 --> Input Class Initialized
INFO - 2020-08-31 14:58:48 --> Language Class Initialized
INFO - 2020-08-31 14:58:48 --> Language Class Initialized
INFO - 2020-08-31 14:58:48 --> Config Class Initialized
INFO - 2020-08-31 14:58:48 --> Loader Class Initialized
INFO - 2020-08-31 14:58:48 --> Helper loaded: url_helper
INFO - 2020-08-31 14:58:48 --> Helper loaded: form_helper
INFO - 2020-08-31 14:58:48 --> Helper loaded: file_helper
INFO - 2020-08-31 14:58:48 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 14:58:48 --> Database Driver Class Initialized
DEBUG - 2020-08-31 14:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 14:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 14:58:48 --> Upload Class Initialized
INFO - 2020-08-31 14:58:48 --> Controller Class Initialized
DEBUG - 2020-08-31 14:58:48 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 14:58:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 14:58:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 14:58:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 14:58:48 --> Final output sent to browser
DEBUG - 2020-08-31 14:58:48 --> Total execution time: 0.0526
INFO - 2020-08-31 16:50:33 --> Config Class Initialized
INFO - 2020-08-31 16:50:33 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:33 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:33 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:33 --> URI Class Initialized
DEBUG - 2020-08-31 16:50:33 --> No URI present. Default controller set.
INFO - 2020-08-31 16:50:33 --> Router Class Initialized
INFO - 2020-08-31 16:50:33 --> Output Class Initialized
INFO - 2020-08-31 16:50:33 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:33 --> Input Class Initialized
INFO - 2020-08-31 16:50:33 --> Language Class Initialized
INFO - 2020-08-31 16:50:33 --> Language Class Initialized
INFO - 2020-08-31 16:50:33 --> Config Class Initialized
INFO - 2020-08-31 16:50:33 --> Loader Class Initialized
INFO - 2020-08-31 16:50:33 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:33 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:33 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:33 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:33 --> Upload Class Initialized
INFO - 2020-08-31 16:50:33 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:33 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 16:50:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 16:50:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:33 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:33 --> Total execution time: 0.1483
INFO - 2020-08-31 16:50:34 --> Config Class Initialized
INFO - 2020-08-31 16:50:34 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:34 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:34 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:34 --> URI Class Initialized
DEBUG - 2020-08-31 16:50:34 --> No URI present. Default controller set.
INFO - 2020-08-31 16:50:34 --> Router Class Initialized
INFO - 2020-08-31 16:50:34 --> Output Class Initialized
INFO - 2020-08-31 16:50:34 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:34 --> Input Class Initialized
INFO - 2020-08-31 16:50:34 --> Language Class Initialized
INFO - 2020-08-31 16:50:34 --> Language Class Initialized
INFO - 2020-08-31 16:50:34 --> Config Class Initialized
INFO - 2020-08-31 16:50:34 --> Loader Class Initialized
INFO - 2020-08-31 16:50:34 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:34 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:34 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:34 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:34 --> Upload Class Initialized
INFO - 2020-08-31 16:50:34 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 16:50:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 16:50:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:34 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:34 --> Total execution time: 0.0530
INFO - 2020-08-31 16:50:34 --> Config Class Initialized
INFO - 2020-08-31 16:50:34 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:34 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:34 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:34 --> URI Class Initialized
INFO - 2020-08-31 16:50:34 --> Router Class Initialized
INFO - 2020-08-31 16:50:34 --> Output Class Initialized
INFO - 2020-08-31 16:50:34 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:34 --> Input Class Initialized
INFO - 2020-08-31 16:50:34 --> Language Class Initialized
INFO - 2020-08-31 16:50:34 --> Language Class Initialized
INFO - 2020-08-31 16:50:34 --> Config Class Initialized
INFO - 2020-08-31 16:50:34 --> Loader Class Initialized
INFO - 2020-08-31 16:50:34 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:34 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:34 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:34 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:34 --> Upload Class Initialized
INFO - 2020-08-31 16:50:34 --> Controller Class Initialized
ERROR - 2020-08-31 16:50:34 --> 404 Page Not Found: /index
INFO - 2020-08-31 16:50:35 --> Config Class Initialized
INFO - 2020-08-31 16:50:35 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:35 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:35 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:35 --> URI Class Initialized
INFO - 2020-08-31 16:50:35 --> Router Class Initialized
INFO - 2020-08-31 16:50:35 --> Output Class Initialized
INFO - 2020-08-31 16:50:35 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:35 --> Input Class Initialized
INFO - 2020-08-31 16:50:35 --> Language Class Initialized
INFO - 2020-08-31 16:50:35 --> Language Class Initialized
INFO - 2020-08-31 16:50:35 --> Config Class Initialized
INFO - 2020-08-31 16:50:35 --> Loader Class Initialized
INFO - 2020-08-31 16:50:35 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:35 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:35 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:35 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:35 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:35 --> Upload Class Initialized
INFO - 2020-08-31 16:50:35 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:35 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 16:50:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 16:50:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:35 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:35 --> Total execution time: 0.0498
INFO - 2020-08-31 16:50:36 --> Config Class Initialized
INFO - 2020-08-31 16:50:36 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:36 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:36 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:36 --> URI Class Initialized
INFO - 2020-08-31 16:50:36 --> Router Class Initialized
INFO - 2020-08-31 16:50:36 --> Output Class Initialized
INFO - 2020-08-31 16:50:36 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:36 --> Input Class Initialized
INFO - 2020-08-31 16:50:36 --> Language Class Initialized
INFO - 2020-08-31 16:50:36 --> Language Class Initialized
INFO - 2020-08-31 16:50:36 --> Config Class Initialized
INFO - 2020-08-31 16:50:36 --> Loader Class Initialized
INFO - 2020-08-31 16:50:36 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:36 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:36 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:36 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:36 --> Upload Class Initialized
INFO - 2020-08-31 16:50:36 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-31 16:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:36 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:36 --> Total execution time: 0.0538
INFO - 2020-08-31 16:50:36 --> Config Class Initialized
INFO - 2020-08-31 16:50:36 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:36 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:36 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:36 --> URI Class Initialized
INFO - 2020-08-31 16:50:36 --> Router Class Initialized
INFO - 2020-08-31 16:50:36 --> Output Class Initialized
INFO - 2020-08-31 16:50:36 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:36 --> Input Class Initialized
INFO - 2020-08-31 16:50:36 --> Language Class Initialized
INFO - 2020-08-31 16:50:36 --> Language Class Initialized
INFO - 2020-08-31 16:50:36 --> Config Class Initialized
INFO - 2020-08-31 16:50:36 --> Loader Class Initialized
INFO - 2020-08-31 16:50:36 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:36 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:36 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:36 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:36 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:36 --> Upload Class Initialized
INFO - 2020-08-31 16:50:36 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:36 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-08-31 16:50:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:36 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:36 --> Total execution time: 0.0542
INFO - 2020-08-31 16:50:37 --> Config Class Initialized
INFO - 2020-08-31 16:50:37 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:37 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:37 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:37 --> URI Class Initialized
INFO - 2020-08-31 16:50:37 --> Router Class Initialized
INFO - 2020-08-31 16:50:37 --> Output Class Initialized
INFO - 2020-08-31 16:50:37 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:37 --> Input Class Initialized
INFO - 2020-08-31 16:50:37 --> Language Class Initialized
INFO - 2020-08-31 16:50:37 --> Language Class Initialized
INFO - 2020-08-31 16:50:37 --> Config Class Initialized
INFO - 2020-08-31 16:50:37 --> Loader Class Initialized
INFO - 2020-08-31 16:50:37 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:37 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:37 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:37 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:37 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:37 --> Upload Class Initialized
INFO - 2020-08-31 16:50:37 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:37 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-08-31 16:50:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:37 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:37 --> Total execution time: 0.0677
INFO - 2020-08-31 16:50:38 --> Config Class Initialized
INFO - 2020-08-31 16:50:38 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:38 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:38 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:38 --> URI Class Initialized
INFO - 2020-08-31 16:50:38 --> Router Class Initialized
INFO - 2020-08-31 16:50:38 --> Output Class Initialized
INFO - 2020-08-31 16:50:38 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:38 --> Input Class Initialized
INFO - 2020-08-31 16:50:38 --> Language Class Initialized
INFO - 2020-08-31 16:50:38 --> Language Class Initialized
INFO - 2020-08-31 16:50:38 --> Config Class Initialized
INFO - 2020-08-31 16:50:38 --> Loader Class Initialized
INFO - 2020-08-31 16:50:38 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:38 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:38 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:38 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:38 --> Upload Class Initialized
INFO - 2020-08-31 16:50:38 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-08-31 16:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:38 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:38 --> Total execution time: 0.0526
INFO - 2020-08-31 16:50:38 --> Config Class Initialized
INFO - 2020-08-31 16:50:38 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:38 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:38 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:38 --> URI Class Initialized
INFO - 2020-08-31 16:50:38 --> Router Class Initialized
INFO - 2020-08-31 16:50:38 --> Output Class Initialized
INFO - 2020-08-31 16:50:38 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:38 --> Input Class Initialized
INFO - 2020-08-31 16:50:38 --> Language Class Initialized
INFO - 2020-08-31 16:50:38 --> Language Class Initialized
INFO - 2020-08-31 16:50:38 --> Config Class Initialized
INFO - 2020-08-31 16:50:38 --> Loader Class Initialized
INFO - 2020-08-31 16:50:38 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:38 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:38 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:38 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:38 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:38 --> Upload Class Initialized
INFO - 2020-08-31 16:50:38 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:38 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-08-31 16:50:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:38 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:38 --> Total execution time: 0.0508
INFO - 2020-08-31 16:50:39 --> Config Class Initialized
INFO - 2020-08-31 16:50:39 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:39 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:39 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:39 --> URI Class Initialized
INFO - 2020-08-31 16:50:39 --> Router Class Initialized
INFO - 2020-08-31 16:50:39 --> Output Class Initialized
INFO - 2020-08-31 16:50:39 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:39 --> Input Class Initialized
INFO - 2020-08-31 16:50:39 --> Language Class Initialized
INFO - 2020-08-31 16:50:39 --> Language Class Initialized
INFO - 2020-08-31 16:50:39 --> Config Class Initialized
INFO - 2020-08-31 16:50:39 --> Loader Class Initialized
INFO - 2020-08-31 16:50:39 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:39 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:39 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:39 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:39 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:39 --> Upload Class Initialized
INFO - 2020-08-31 16:50:39 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:39 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-08-31 16:50:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:39 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:39 --> Total execution time: 0.0513
INFO - 2020-08-31 16:50:40 --> Config Class Initialized
INFO - 2020-08-31 16:50:40 --> Hooks Class Initialized
DEBUG - 2020-08-31 16:50:40 --> UTF-8 Support Enabled
INFO - 2020-08-31 16:50:40 --> Utf8 Class Initialized
INFO - 2020-08-31 16:50:40 --> URI Class Initialized
INFO - 2020-08-31 16:50:40 --> Router Class Initialized
INFO - 2020-08-31 16:50:40 --> Output Class Initialized
INFO - 2020-08-31 16:50:40 --> Security Class Initialized
DEBUG - 2020-08-31 16:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 16:50:40 --> Input Class Initialized
INFO - 2020-08-31 16:50:40 --> Language Class Initialized
INFO - 2020-08-31 16:50:40 --> Language Class Initialized
INFO - 2020-08-31 16:50:40 --> Config Class Initialized
INFO - 2020-08-31 16:50:40 --> Loader Class Initialized
INFO - 2020-08-31 16:50:40 --> Helper loaded: url_helper
INFO - 2020-08-31 16:50:40 --> Helper loaded: form_helper
INFO - 2020-08-31 16:50:40 --> Helper loaded: file_helper
INFO - 2020-08-31 16:50:40 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 16:50:40 --> Database Driver Class Initialized
DEBUG - 2020-08-31 16:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 16:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 16:50:40 --> Upload Class Initialized
INFO - 2020-08-31 16:50:40 --> Controller Class Initialized
DEBUG - 2020-08-31 16:50:40 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 16:50:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-08-31 16:50:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 16:50:40 --> Final output sent to browser
DEBUG - 2020-08-31 16:50:40 --> Total execution time: 0.0505
INFO - 2020-08-31 17:34:47 --> Config Class Initialized
INFO - 2020-08-31 17:34:47 --> Hooks Class Initialized
DEBUG - 2020-08-31 17:34:47 --> UTF-8 Support Enabled
INFO - 2020-08-31 17:34:47 --> Utf8 Class Initialized
INFO - 2020-08-31 17:34:47 --> URI Class Initialized
INFO - 2020-08-31 17:34:47 --> Router Class Initialized
INFO - 2020-08-31 17:34:47 --> Output Class Initialized
INFO - 2020-08-31 17:34:47 --> Security Class Initialized
DEBUG - 2020-08-31 17:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 17:34:47 --> Input Class Initialized
INFO - 2020-08-31 17:34:47 --> Language Class Initialized
INFO - 2020-08-31 17:34:47 --> Language Class Initialized
INFO - 2020-08-31 17:34:47 --> Config Class Initialized
INFO - 2020-08-31 17:34:47 --> Loader Class Initialized
INFO - 2020-08-31 17:34:47 --> Helper loaded: url_helper
INFO - 2020-08-31 17:34:47 --> Helper loaded: form_helper
INFO - 2020-08-31 17:34:47 --> Helper loaded: file_helper
INFO - 2020-08-31 17:34:47 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 17:34:47 --> Database Driver Class Initialized
DEBUG - 2020-08-31 17:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 17:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 17:34:47 --> Upload Class Initialized
INFO - 2020-08-31 17:34:47 --> Controller Class Initialized
ERROR - 2020-08-31 17:34:47 --> 404 Page Not Found: /index
INFO - 2020-08-31 17:34:51 --> Config Class Initialized
INFO - 2020-08-31 17:34:51 --> Hooks Class Initialized
DEBUG - 2020-08-31 17:34:51 --> UTF-8 Support Enabled
INFO - 2020-08-31 17:34:51 --> Utf8 Class Initialized
INFO - 2020-08-31 17:34:51 --> URI Class Initialized
INFO - 2020-08-31 17:34:51 --> Router Class Initialized
INFO - 2020-08-31 17:34:51 --> Output Class Initialized
INFO - 2020-08-31 17:34:51 --> Security Class Initialized
DEBUG - 2020-08-31 17:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 17:34:51 --> Input Class Initialized
INFO - 2020-08-31 17:34:51 --> Language Class Initialized
INFO - 2020-08-31 17:34:51 --> Language Class Initialized
INFO - 2020-08-31 17:34:51 --> Config Class Initialized
INFO - 2020-08-31 17:34:51 --> Loader Class Initialized
INFO - 2020-08-31 17:34:51 --> Helper loaded: url_helper
INFO - 2020-08-31 17:34:51 --> Helper loaded: form_helper
INFO - 2020-08-31 17:34:51 --> Helper loaded: file_helper
INFO - 2020-08-31 17:34:51 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 17:34:51 --> Database Driver Class Initialized
DEBUG - 2020-08-31 17:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 17:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 17:34:51 --> Upload Class Initialized
INFO - 2020-08-31 17:34:51 --> Controller Class Initialized
DEBUG - 2020-08-31 17:34:51 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 17:34:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 17:34:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 17:34:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 17:34:51 --> Final output sent to browser
DEBUG - 2020-08-31 17:34:51 --> Total execution time: 0.0503
INFO - 2020-08-31 19:33:59 --> Config Class Initialized
INFO - 2020-08-31 19:33:59 --> Hooks Class Initialized
DEBUG - 2020-08-31 19:33:59 --> UTF-8 Support Enabled
INFO - 2020-08-31 19:33:59 --> Utf8 Class Initialized
INFO - 2020-08-31 19:33:59 --> URI Class Initialized
DEBUG - 2020-08-31 19:33:59 --> No URI present. Default controller set.
INFO - 2020-08-31 19:33:59 --> Router Class Initialized
INFO - 2020-08-31 19:33:59 --> Output Class Initialized
INFO - 2020-08-31 19:33:59 --> Security Class Initialized
DEBUG - 2020-08-31 19:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 19:33:59 --> Input Class Initialized
INFO - 2020-08-31 19:33:59 --> Language Class Initialized
INFO - 2020-08-31 19:33:59 --> Language Class Initialized
INFO - 2020-08-31 19:33:59 --> Config Class Initialized
INFO - 2020-08-31 19:33:59 --> Loader Class Initialized
INFO - 2020-08-31 19:33:59 --> Helper loaded: url_helper
INFO - 2020-08-31 19:33:59 --> Helper loaded: form_helper
INFO - 2020-08-31 19:33:59 --> Helper loaded: file_helper
INFO - 2020-08-31 19:33:59 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 19:33:59 --> Database Driver Class Initialized
DEBUG - 2020-08-31 19:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 19:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 19:33:59 --> Upload Class Initialized
INFO - 2020-08-31 19:33:59 --> Controller Class Initialized
DEBUG - 2020-08-31 19:33:59 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 19:33:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 19:33:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 19:33:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 19:33:59 --> Final output sent to browser
DEBUG - 2020-08-31 19:33:59 --> Total execution time: 0.0568
INFO - 2020-08-31 20:45:34 --> Config Class Initialized
INFO - 2020-08-31 20:45:34 --> Hooks Class Initialized
DEBUG - 2020-08-31 20:45:34 --> UTF-8 Support Enabled
INFO - 2020-08-31 20:45:34 --> Utf8 Class Initialized
INFO - 2020-08-31 20:45:34 --> URI Class Initialized
DEBUG - 2020-08-31 20:45:34 --> No URI present. Default controller set.
INFO - 2020-08-31 20:45:34 --> Router Class Initialized
INFO - 2020-08-31 20:45:34 --> Output Class Initialized
INFO - 2020-08-31 20:45:34 --> Security Class Initialized
DEBUG - 2020-08-31 20:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 20:45:34 --> Input Class Initialized
INFO - 2020-08-31 20:45:34 --> Language Class Initialized
INFO - 2020-08-31 20:45:34 --> Language Class Initialized
INFO - 2020-08-31 20:45:34 --> Config Class Initialized
INFO - 2020-08-31 20:45:34 --> Loader Class Initialized
INFO - 2020-08-31 20:45:34 --> Helper loaded: url_helper
INFO - 2020-08-31 20:45:34 --> Helper loaded: form_helper
INFO - 2020-08-31 20:45:34 --> Helper loaded: file_helper
INFO - 2020-08-31 20:45:34 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 20:45:34 --> Database Driver Class Initialized
DEBUG - 2020-08-31 20:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 20:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 20:45:34 --> Upload Class Initialized
INFO - 2020-08-31 20:45:34 --> Controller Class Initialized
DEBUG - 2020-08-31 20:45:34 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 20:45:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 20:45:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 20:45:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 20:45:34 --> Final output sent to browser
DEBUG - 2020-08-31 20:45:34 --> Total execution time: 0.0581
INFO - 2020-08-31 21:52:58 --> Config Class Initialized
INFO - 2020-08-31 21:52:58 --> Hooks Class Initialized
DEBUG - 2020-08-31 21:52:58 --> UTF-8 Support Enabled
INFO - 2020-08-31 21:52:58 --> Utf8 Class Initialized
INFO - 2020-08-31 21:52:58 --> URI Class Initialized
DEBUG - 2020-08-31 21:52:58 --> No URI present. Default controller set.
INFO - 2020-08-31 21:52:58 --> Router Class Initialized
INFO - 2020-08-31 21:52:58 --> Output Class Initialized
INFO - 2020-08-31 21:52:58 --> Security Class Initialized
DEBUG - 2020-08-31 21:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 21:52:58 --> Input Class Initialized
INFO - 2020-08-31 21:52:58 --> Language Class Initialized
INFO - 2020-08-31 21:52:58 --> Language Class Initialized
INFO - 2020-08-31 21:52:58 --> Config Class Initialized
INFO - 2020-08-31 21:52:58 --> Loader Class Initialized
INFO - 2020-08-31 21:52:58 --> Helper loaded: url_helper
INFO - 2020-08-31 21:52:58 --> Helper loaded: form_helper
INFO - 2020-08-31 21:52:58 --> Helper loaded: file_helper
INFO - 2020-08-31 21:52:58 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 21:52:58 --> Database Driver Class Initialized
DEBUG - 2020-08-31 21:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 21:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 21:52:58 --> Upload Class Initialized
INFO - 2020-08-31 21:52:58 --> Controller Class Initialized
DEBUG - 2020-08-31 21:52:58 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 21:52:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 21:52:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 21:52:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 21:52:58 --> Final output sent to browser
DEBUG - 2020-08-31 21:52:58 --> Total execution time: 0.0547
INFO - 2020-08-31 22:11:45 --> Config Class Initialized
INFO - 2020-08-31 22:11:45 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:11:45 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:11:45 --> Utf8 Class Initialized
INFO - 2020-08-31 22:11:45 --> URI Class Initialized
INFO - 2020-08-31 22:11:45 --> Router Class Initialized
INFO - 2020-08-31 22:11:45 --> Output Class Initialized
INFO - 2020-08-31 22:11:45 --> Security Class Initialized
DEBUG - 2020-08-31 22:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:11:45 --> Input Class Initialized
INFO - 2020-08-31 22:11:45 --> Language Class Initialized
INFO - 2020-08-31 22:11:45 --> Language Class Initialized
INFO - 2020-08-31 22:11:45 --> Config Class Initialized
INFO - 2020-08-31 22:11:45 --> Loader Class Initialized
INFO - 2020-08-31 22:11:45 --> Helper loaded: url_helper
INFO - 2020-08-31 22:11:45 --> Helper loaded: form_helper
INFO - 2020-08-31 22:11:45 --> Helper loaded: file_helper
INFO - 2020-08-31 22:11:45 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:11:45 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:11:45 --> Upload Class Initialized
INFO - 2020-08-31 22:11:45 --> Controller Class Initialized
ERROR - 2020-08-31 22:11:45 --> 404 Page Not Found: /index
INFO - 2020-08-31 22:17:33 --> Config Class Initialized
INFO - 2020-08-31 22:17:33 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:17:33 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:17:33 --> Utf8 Class Initialized
INFO - 2020-08-31 22:17:33 --> URI Class Initialized
INFO - 2020-08-31 22:17:33 --> Router Class Initialized
INFO - 2020-08-31 22:17:33 --> Output Class Initialized
INFO - 2020-08-31 22:17:33 --> Security Class Initialized
DEBUG - 2020-08-31 22:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:17:33 --> Input Class Initialized
INFO - 2020-08-31 22:17:33 --> Language Class Initialized
INFO - 2020-08-31 22:17:33 --> Language Class Initialized
INFO - 2020-08-31 22:17:33 --> Config Class Initialized
INFO - 2020-08-31 22:17:33 --> Loader Class Initialized
INFO - 2020-08-31 22:17:33 --> Helper loaded: url_helper
INFO - 2020-08-31 22:17:33 --> Helper loaded: form_helper
INFO - 2020-08-31 22:17:33 --> Helper loaded: file_helper
INFO - 2020-08-31 22:17:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:17:33 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:17:33 --> Upload Class Initialized
INFO - 2020-08-31 22:17:33 --> Controller Class Initialized
ERROR - 2020-08-31 22:17:33 --> 404 Page Not Found: /index
INFO - 2020-08-31 22:17:41 --> Config Class Initialized
INFO - 2020-08-31 22:17:41 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:17:41 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:17:41 --> Utf8 Class Initialized
INFO - 2020-08-31 22:17:41 --> URI Class Initialized
INFO - 2020-08-31 22:17:41 --> Router Class Initialized
INFO - 2020-08-31 22:17:41 --> Output Class Initialized
INFO - 2020-08-31 22:17:41 --> Security Class Initialized
DEBUG - 2020-08-31 22:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:17:41 --> Input Class Initialized
INFO - 2020-08-31 22:17:41 --> Language Class Initialized
INFO - 2020-08-31 22:17:41 --> Language Class Initialized
INFO - 2020-08-31 22:17:41 --> Config Class Initialized
INFO - 2020-08-31 22:17:42 --> Loader Class Initialized
INFO - 2020-08-31 22:17:42 --> Helper loaded: url_helper
INFO - 2020-08-31 22:17:42 --> Helper loaded: form_helper
INFO - 2020-08-31 22:17:42 --> Helper loaded: file_helper
INFO - 2020-08-31 22:17:42 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:17:42 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:17:42 --> Upload Class Initialized
INFO - 2020-08-31 22:17:42 --> Controller Class Initialized
ERROR - 2020-08-31 22:17:42 --> 404 Page Not Found: /index
INFO - 2020-08-31 22:28:24 --> Config Class Initialized
INFO - 2020-08-31 22:28:24 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:28:24 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:24 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:24 --> URI Class Initialized
DEBUG - 2020-08-31 22:28:24 --> No URI present. Default controller set.
INFO - 2020-08-31 22:28:24 --> Router Class Initialized
INFO - 2020-08-31 22:28:24 --> Output Class Initialized
INFO - 2020-08-31 22:28:24 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:24 --> Input Class Initialized
INFO - 2020-08-31 22:28:24 --> Language Class Initialized
INFO - 2020-08-31 22:28:24 --> Language Class Initialized
INFO - 2020-08-31 22:28:24 --> Config Class Initialized
INFO - 2020-08-31 22:28:24 --> Loader Class Initialized
INFO - 2020-08-31 22:28:24 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:24 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:24 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:24 --> Config Class Initialized
INFO - 2020-08-31 22:28:24 --> Hooks Class Initialized
INFO - 2020-08-31 22:28:24 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:24 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:24 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:24 --> URI Class Initialized
DEBUG - 2020-08-31 22:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-31 22:28:24 --> No URI present. Default controller set.
INFO - 2020-08-31 22:28:24 --> Router Class Initialized
INFO - 2020-08-31 22:28:24 --> Upload Class Initialized
INFO - 2020-08-31 22:28:24 --> Output Class Initialized
INFO - 2020-08-31 22:28:24 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:24 --> Input Class Initialized
INFO - 2020-08-31 22:28:24 --> Language Class Initialized
INFO - 2020-08-31 22:28:24 --> Language Class Initialized
INFO - 2020-08-31 22:28:24 --> Config Class Initialized
INFO - 2020-08-31 22:28:24 --> Loader Class Initialized
INFO - 2020-08-31 22:28:24 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:24 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:24 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:24 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:24 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:28:24 --> Upload Class Initialized
INFO - 2020-08-31 22:28:24 --> Controller Class Initialized
DEBUG - 2020-08-31 22:28:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 22:28:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 22:28:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 22:28:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 22:28:24 --> Final output sent to browser
DEBUG - 2020-08-31 22:28:24 --> Total execution time: 0.0500
INFO - 2020-08-31 22:28:24 --> Controller Class Initialized
DEBUG - 2020-08-31 22:28:24 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 22:28:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 22:28:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 22:28:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 22:28:24 --> Final output sent to browser
DEBUG - 2020-08-31 22:28:24 --> Total execution time: 0.0503
INFO - 2020-08-31 22:28:25 --> Config Class Initialized
INFO - 2020-08-31 22:28:25 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:28:25 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:25 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:25 --> URI Class Initialized
DEBUG - 2020-08-31 22:28:25 --> No URI present. Default controller set.
INFO - 2020-08-31 22:28:25 --> Router Class Initialized
INFO - 2020-08-31 22:28:25 --> Output Class Initialized
INFO - 2020-08-31 22:28:25 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:25 --> Input Class Initialized
INFO - 2020-08-31 22:28:25 --> Language Class Initialized
INFO - 2020-08-31 22:28:25 --> Language Class Initialized
INFO - 2020-08-31 22:28:25 --> Config Class Initialized
INFO - 2020-08-31 22:28:25 --> Loader Class Initialized
INFO - 2020-08-31 22:28:25 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:25 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:25 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:25 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:25 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:28:25 --> Upload Class Initialized
INFO - 2020-08-31 22:28:25 --> Controller Class Initialized
DEBUG - 2020-08-31 22:28:25 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 22:28:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 22:28:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 22:28:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 22:28:25 --> Final output sent to browser
DEBUG - 2020-08-31 22:28:25 --> Total execution time: 0.0524
INFO - 2020-08-31 22:28:26 --> Config Class Initialized
INFO - 2020-08-31 22:28:26 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:28:26 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:26 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:26 --> URI Class Initialized
INFO - 2020-08-31 22:28:26 --> Router Class Initialized
INFO - 2020-08-31 22:28:26 --> Output Class Initialized
INFO - 2020-08-31 22:28:26 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:26 --> Input Class Initialized
INFO - 2020-08-31 22:28:26 --> Language Class Initialized
INFO - 2020-08-31 22:28:26 --> Language Class Initialized
INFO - 2020-08-31 22:28:26 --> Config Class Initialized
INFO - 2020-08-31 22:28:26 --> Loader Class Initialized
INFO - 2020-08-31 22:28:26 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:26 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:26 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:26 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:26 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:28:26 --> Upload Class Initialized
INFO - 2020-08-31 22:28:26 --> Controller Class Initialized
ERROR - 2020-08-31 22:28:26 --> 404 Page Not Found: /index
INFO - 2020-08-31 22:28:27 --> Config Class Initialized
INFO - 2020-08-31 22:28:27 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:28:27 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:27 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:27 --> URI Class Initialized
INFO - 2020-08-31 22:28:27 --> Router Class Initialized
INFO - 2020-08-31 22:28:27 --> Output Class Initialized
INFO - 2020-08-31 22:28:27 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:27 --> Input Class Initialized
INFO - 2020-08-31 22:28:27 --> Language Class Initialized
INFO - 2020-08-31 22:28:27 --> Language Class Initialized
INFO - 2020-08-31 22:28:27 --> Config Class Initialized
INFO - 2020-08-31 22:28:27 --> Loader Class Initialized
INFO - 2020-08-31 22:28:27 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:27 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:27 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:27 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:28:27 --> Upload Class Initialized
INFO - 2020-08-31 22:28:27 --> Controller Class Initialized
ERROR - 2020-08-31 22:28:27 --> 404 Page Not Found: /index
INFO - 2020-08-31 22:28:27 --> Config Class Initialized
INFO - 2020-08-31 22:28:27 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:28:27 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:27 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:27 --> URI Class Initialized
INFO - 2020-08-31 22:28:27 --> Router Class Initialized
INFO - 2020-08-31 22:28:27 --> Output Class Initialized
INFO - 2020-08-31 22:28:27 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:27 --> Input Class Initialized
INFO - 2020-08-31 22:28:27 --> Language Class Initialized
INFO - 2020-08-31 22:28:27 --> Language Class Initialized
INFO - 2020-08-31 22:28:27 --> Config Class Initialized
INFO - 2020-08-31 22:28:27 --> Loader Class Initialized
INFO - 2020-08-31 22:28:27 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:27 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:27 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:27 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:27 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:28:27 --> Upload Class Initialized
INFO - 2020-08-31 22:28:27 --> Controller Class Initialized
DEBUG - 2020-08-31 22:28:27 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 22:28:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-08-31 22:28:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 22:28:27 --> Final output sent to browser
DEBUG - 2020-08-31 22:28:27 --> Total execution time: 0.0533
INFO - 2020-08-31 22:28:29 --> Config Class Initialized
INFO - 2020-08-31 22:28:29 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:28:29 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:28:29 --> Utf8 Class Initialized
INFO - 2020-08-31 22:28:29 --> URI Class Initialized
INFO - 2020-08-31 22:28:29 --> Router Class Initialized
INFO - 2020-08-31 22:28:29 --> Output Class Initialized
INFO - 2020-08-31 22:28:29 --> Security Class Initialized
DEBUG - 2020-08-31 22:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:28:29 --> Input Class Initialized
INFO - 2020-08-31 22:28:29 --> Language Class Initialized
INFO - 2020-08-31 22:28:29 --> Language Class Initialized
INFO - 2020-08-31 22:28:29 --> Config Class Initialized
INFO - 2020-08-31 22:28:29 --> Loader Class Initialized
INFO - 2020-08-31 22:28:29 --> Helper loaded: url_helper
INFO - 2020-08-31 22:28:29 --> Helper loaded: form_helper
INFO - 2020-08-31 22:28:29 --> Helper loaded: file_helper
INFO - 2020-08-31 22:28:29 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:28:29 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:28:29 --> Upload Class Initialized
INFO - 2020-08-31 22:28:29 --> Controller Class Initialized
DEBUG - 2020-08-31 22:28:29 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 22:28:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 22:28:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 22:28:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 22:28:29 --> Final output sent to browser
DEBUG - 2020-08-31 22:28:29 --> Total execution time: 0.0523
INFO - 2020-08-31 22:58:50 --> Config Class Initialized
INFO - 2020-08-31 22:58:50 --> Hooks Class Initialized
DEBUG - 2020-08-31 22:58:50 --> UTF-8 Support Enabled
INFO - 2020-08-31 22:58:50 --> Utf8 Class Initialized
INFO - 2020-08-31 22:58:50 --> URI Class Initialized
INFO - 2020-08-31 22:58:50 --> Router Class Initialized
INFO - 2020-08-31 22:58:50 --> Output Class Initialized
INFO - 2020-08-31 22:58:50 --> Security Class Initialized
DEBUG - 2020-08-31 22:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 22:58:50 --> Input Class Initialized
INFO - 2020-08-31 22:58:50 --> Language Class Initialized
INFO - 2020-08-31 22:58:50 --> Language Class Initialized
INFO - 2020-08-31 22:58:50 --> Config Class Initialized
INFO - 2020-08-31 22:58:50 --> Loader Class Initialized
INFO - 2020-08-31 22:58:50 --> Helper loaded: url_helper
INFO - 2020-08-31 22:58:50 --> Helper loaded: form_helper
INFO - 2020-08-31 22:58:50 --> Helper loaded: file_helper
INFO - 2020-08-31 22:58:50 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 22:58:50 --> Database Driver Class Initialized
DEBUG - 2020-08-31 22:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 22:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 22:58:50 --> Upload Class Initialized
INFO - 2020-08-31 22:58:50 --> Controller Class Initialized
ERROR - 2020-08-31 22:58:50 --> 404 Page Not Found: /index
INFO - 2020-08-31 23:42:57 --> Config Class Initialized
INFO - 2020-08-31 23:42:57 --> Hooks Class Initialized
DEBUG - 2020-08-31 23:42:57 --> UTF-8 Support Enabled
INFO - 2020-08-31 23:42:57 --> Utf8 Class Initialized
INFO - 2020-08-31 23:42:57 --> URI Class Initialized
INFO - 2020-08-31 23:42:57 --> Router Class Initialized
INFO - 2020-08-31 23:42:57 --> Output Class Initialized
INFO - 2020-08-31 23:42:57 --> Security Class Initialized
DEBUG - 2020-08-31 23:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 23:42:57 --> Input Class Initialized
INFO - 2020-08-31 23:42:57 --> Language Class Initialized
INFO - 2020-08-31 23:42:57 --> Language Class Initialized
INFO - 2020-08-31 23:42:57 --> Config Class Initialized
INFO - 2020-08-31 23:42:57 --> Loader Class Initialized
INFO - 2020-08-31 23:42:57 --> Helper loaded: url_helper
INFO - 2020-08-31 23:42:57 --> Helper loaded: form_helper
INFO - 2020-08-31 23:42:57 --> Helper loaded: file_helper
INFO - 2020-08-31 23:42:57 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 23:42:57 --> Database Driver Class Initialized
DEBUG - 2020-08-31 23:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 23:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 23:42:57 --> Upload Class Initialized
INFO - 2020-08-31 23:42:57 --> Controller Class Initialized
ERROR - 2020-08-31 23:42:57 --> 404 Page Not Found: /index
INFO - 2020-08-31 23:43:01 --> Config Class Initialized
INFO - 2020-08-31 23:43:01 --> Hooks Class Initialized
DEBUG - 2020-08-31 23:43:01 --> UTF-8 Support Enabled
INFO - 2020-08-31 23:43:01 --> Utf8 Class Initialized
INFO - 2020-08-31 23:43:01 --> URI Class Initialized
DEBUG - 2020-08-31 23:43:01 --> No URI present. Default controller set.
INFO - 2020-08-31 23:43:01 --> Router Class Initialized
INFO - 2020-08-31 23:43:01 --> Output Class Initialized
INFO - 2020-08-31 23:43:01 --> Security Class Initialized
DEBUG - 2020-08-31 23:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 23:43:01 --> Input Class Initialized
INFO - 2020-08-31 23:43:01 --> Language Class Initialized
INFO - 2020-08-31 23:43:01 --> Language Class Initialized
INFO - 2020-08-31 23:43:01 --> Config Class Initialized
INFO - 2020-08-31 23:43:01 --> Loader Class Initialized
INFO - 2020-08-31 23:43:01 --> Helper loaded: url_helper
INFO - 2020-08-31 23:43:01 --> Helper loaded: form_helper
INFO - 2020-08-31 23:43:01 --> Helper loaded: file_helper
INFO - 2020-08-31 23:43:01 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 23:43:01 --> Database Driver Class Initialized
DEBUG - 2020-08-31 23:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 23:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 23:43:01 --> Upload Class Initialized
INFO - 2020-08-31 23:43:01 --> Controller Class Initialized
DEBUG - 2020-08-31 23:43:01 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 23:43:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 23:43:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 23:43:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 23:43:01 --> Final output sent to browser
DEBUG - 2020-08-31 23:43:01 --> Total execution time: 0.1103
INFO - 2020-08-31 23:50:33 --> Config Class Initialized
INFO - 2020-08-31 23:50:33 --> Hooks Class Initialized
DEBUG - 2020-08-31 23:50:33 --> UTF-8 Support Enabled
INFO - 2020-08-31 23:50:33 --> Utf8 Class Initialized
INFO - 2020-08-31 23:50:33 --> URI Class Initialized
DEBUG - 2020-08-31 23:50:33 --> No URI present. Default controller set.
INFO - 2020-08-31 23:50:33 --> Router Class Initialized
INFO - 2020-08-31 23:50:33 --> Output Class Initialized
INFO - 2020-08-31 23:50:33 --> Security Class Initialized
DEBUG - 2020-08-31 23:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-31 23:50:33 --> Input Class Initialized
INFO - 2020-08-31 23:50:33 --> Language Class Initialized
INFO - 2020-08-31 23:50:33 --> Language Class Initialized
INFO - 2020-08-31 23:50:33 --> Config Class Initialized
INFO - 2020-08-31 23:50:33 --> Loader Class Initialized
INFO - 2020-08-31 23:50:33 --> Helper loaded: url_helper
INFO - 2020-08-31 23:50:33 --> Helper loaded: form_helper
INFO - 2020-08-31 23:50:33 --> Helper loaded: file_helper
INFO - 2020-08-31 23:50:33 --> Helper loaded: myhelper_helper
INFO - 2020-08-31 23:50:33 --> Database Driver Class Initialized
DEBUG - 2020-08-31 23:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-31 23:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-31 23:50:33 --> Upload Class Initialized
INFO - 2020-08-31 23:50:33 --> Controller Class Initialized
DEBUG - 2020-08-31 23:50:33 --> Home MX_Controller Initialized
DEBUG - 2020-08-31 23:50:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-08-31 23:50:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-08-31 23:50:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-08-31 23:50:33 --> Final output sent to browser
DEBUG - 2020-08-31 23:50:33 --> Total execution time: 0.0510
