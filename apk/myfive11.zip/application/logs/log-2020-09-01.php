<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-01 00:03:32 --> Config Class Initialized
INFO - 2020-09-01 00:03:32 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:03:32 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:03:32 --> Utf8 Class Initialized
INFO - 2020-09-01 00:03:32 --> URI Class Initialized
INFO - 2020-09-01 00:03:32 --> Router Class Initialized
INFO - 2020-09-01 00:03:32 --> Output Class Initialized
INFO - 2020-09-01 00:03:32 --> Security Class Initialized
DEBUG - 2020-09-01 00:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:03:32 --> Input Class Initialized
INFO - 2020-09-01 00:03:32 --> Language Class Initialized
INFO - 2020-09-01 00:03:32 --> Language Class Initialized
INFO - 2020-09-01 00:03:32 --> Config Class Initialized
INFO - 2020-09-01 00:03:32 --> Loader Class Initialized
INFO - 2020-09-01 00:03:32 --> Helper loaded: url_helper
INFO - 2020-09-01 00:03:32 --> Helper loaded: form_helper
INFO - 2020-09-01 00:03:32 --> Helper loaded: file_helper
INFO - 2020-09-01 00:03:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:03:32 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:03:32 --> Upload Class Initialized
INFO - 2020-09-01 00:03:32 --> Controller Class Initialized
ERROR - 2020-09-01 00:03:32 --> 404 Page Not Found: /index
INFO - 2020-09-01 00:14:11 --> Config Class Initialized
INFO - 2020-09-01 00:14:11 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:14:11 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:14:11 --> Utf8 Class Initialized
INFO - 2020-09-01 00:14:11 --> URI Class Initialized
DEBUG - 2020-09-01 00:14:11 --> No URI present. Default controller set.
INFO - 2020-09-01 00:14:11 --> Router Class Initialized
INFO - 2020-09-01 00:14:11 --> Output Class Initialized
INFO - 2020-09-01 00:14:11 --> Security Class Initialized
DEBUG - 2020-09-01 00:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:14:11 --> Input Class Initialized
INFO - 2020-09-01 00:14:11 --> Language Class Initialized
INFO - 2020-09-01 00:14:11 --> Language Class Initialized
INFO - 2020-09-01 00:14:11 --> Config Class Initialized
INFO - 2020-09-01 00:14:11 --> Loader Class Initialized
INFO - 2020-09-01 00:14:11 --> Helper loaded: url_helper
INFO - 2020-09-01 00:14:11 --> Helper loaded: form_helper
INFO - 2020-09-01 00:14:11 --> Helper loaded: file_helper
INFO - 2020-09-01 00:14:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:14:11 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:14:11 --> Upload Class Initialized
INFO - 2020-09-01 00:14:11 --> Controller Class Initialized
DEBUG - 2020-09-01 00:14:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 00:14:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 00:14:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 00:14:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 00:14:11 --> Final output sent to browser
DEBUG - 2020-09-01 00:14:11 --> Total execution time: 0.0519
INFO - 2020-09-01 00:14:18 --> Config Class Initialized
INFO - 2020-09-01 00:14:18 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:14:18 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:14:18 --> Utf8 Class Initialized
INFO - 2020-09-01 00:14:18 --> URI Class Initialized
INFO - 2020-09-01 00:14:18 --> Router Class Initialized
INFO - 2020-09-01 00:14:18 --> Output Class Initialized
INFO - 2020-09-01 00:14:18 --> Security Class Initialized
DEBUG - 2020-09-01 00:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:14:18 --> Input Class Initialized
INFO - 2020-09-01 00:14:18 --> Language Class Initialized
INFO - 2020-09-01 00:14:18 --> Language Class Initialized
INFO - 2020-09-01 00:14:18 --> Config Class Initialized
INFO - 2020-09-01 00:14:18 --> Loader Class Initialized
INFO - 2020-09-01 00:14:18 --> Helper loaded: url_helper
INFO - 2020-09-01 00:14:18 --> Helper loaded: form_helper
INFO - 2020-09-01 00:14:18 --> Helper loaded: file_helper
INFO - 2020-09-01 00:14:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:14:18 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:14:18 --> Upload Class Initialized
INFO - 2020-09-01 00:14:18 --> Controller Class Initialized
ERROR - 2020-09-01 00:14:18 --> 404 Page Not Found: /index
INFO - 2020-09-01 00:51:44 --> Config Class Initialized
INFO - 2020-09-01 00:51:44 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:51:44 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:51:44 --> Utf8 Class Initialized
INFO - 2020-09-01 00:51:44 --> URI Class Initialized
INFO - 2020-09-01 00:51:44 --> Router Class Initialized
INFO - 2020-09-01 00:51:44 --> Output Class Initialized
INFO - 2020-09-01 00:51:44 --> Security Class Initialized
DEBUG - 2020-09-01 00:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:51:44 --> Input Class Initialized
INFO - 2020-09-01 00:51:44 --> Language Class Initialized
INFO - 2020-09-01 00:51:44 --> Language Class Initialized
INFO - 2020-09-01 00:51:44 --> Config Class Initialized
INFO - 2020-09-01 00:51:44 --> Loader Class Initialized
INFO - 2020-09-01 00:51:44 --> Helper loaded: url_helper
INFO - 2020-09-01 00:51:44 --> Helper loaded: form_helper
INFO - 2020-09-01 00:51:44 --> Helper loaded: file_helper
INFO - 2020-09-01 00:51:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:51:44 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:51:44 --> Upload Class Initialized
INFO - 2020-09-01 00:51:44 --> Controller Class Initialized
ERROR - 2020-09-01 00:51:44 --> 404 Page Not Found: /index
INFO - 2020-09-01 00:51:44 --> Config Class Initialized
INFO - 2020-09-01 00:51:44 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:51:44 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:51:44 --> Utf8 Class Initialized
INFO - 2020-09-01 00:51:44 --> URI Class Initialized
INFO - 2020-09-01 00:51:44 --> Router Class Initialized
INFO - 2020-09-01 00:51:44 --> Output Class Initialized
INFO - 2020-09-01 00:51:44 --> Security Class Initialized
DEBUG - 2020-09-01 00:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:51:44 --> Input Class Initialized
INFO - 2020-09-01 00:51:44 --> Language Class Initialized
INFO - 2020-09-01 00:51:44 --> Language Class Initialized
INFO - 2020-09-01 00:51:44 --> Config Class Initialized
INFO - 2020-09-01 00:51:44 --> Loader Class Initialized
INFO - 2020-09-01 00:51:44 --> Helper loaded: url_helper
INFO - 2020-09-01 00:51:44 --> Helper loaded: form_helper
INFO - 2020-09-01 00:51:44 --> Helper loaded: file_helper
INFO - 2020-09-01 00:51:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:51:44 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:51:44 --> Upload Class Initialized
INFO - 2020-09-01 00:51:44 --> Controller Class Initialized
ERROR - 2020-09-01 00:51:44 --> 404 Page Not Found: /index
INFO - 2020-09-01 00:51:47 --> Config Class Initialized
INFO - 2020-09-01 00:51:47 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:51:47 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:51:47 --> Utf8 Class Initialized
INFO - 2020-09-01 00:51:47 --> URI Class Initialized
INFO - 2020-09-01 00:51:47 --> Router Class Initialized
INFO - 2020-09-01 00:51:47 --> Output Class Initialized
INFO - 2020-09-01 00:51:47 --> Security Class Initialized
DEBUG - 2020-09-01 00:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:51:47 --> Input Class Initialized
INFO - 2020-09-01 00:51:47 --> Language Class Initialized
INFO - 2020-09-01 00:51:47 --> Language Class Initialized
INFO - 2020-09-01 00:51:47 --> Config Class Initialized
INFO - 2020-09-01 00:51:47 --> Loader Class Initialized
INFO - 2020-09-01 00:51:47 --> Helper loaded: url_helper
INFO - 2020-09-01 00:51:47 --> Helper loaded: form_helper
INFO - 2020-09-01 00:51:47 --> Helper loaded: file_helper
INFO - 2020-09-01 00:51:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:51:47 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:51:47 --> Upload Class Initialized
INFO - 2020-09-01 00:51:47 --> Controller Class Initialized
DEBUG - 2020-09-01 00:51:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 00:51:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-01 00:51:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 00:51:47 --> Final output sent to browser
DEBUG - 2020-09-01 00:51:47 --> Total execution time: 0.0886
INFO - 2020-09-01 00:51:48 --> Config Class Initialized
INFO - 2020-09-01 00:51:48 --> Hooks Class Initialized
DEBUG - 2020-09-01 00:51:48 --> UTF-8 Support Enabled
INFO - 2020-09-01 00:51:48 --> Utf8 Class Initialized
INFO - 2020-09-01 00:51:48 --> URI Class Initialized
INFO - 2020-09-01 00:51:48 --> Router Class Initialized
INFO - 2020-09-01 00:51:48 --> Output Class Initialized
INFO - 2020-09-01 00:51:48 --> Security Class Initialized
DEBUG - 2020-09-01 00:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 00:51:48 --> Input Class Initialized
INFO - 2020-09-01 00:51:48 --> Language Class Initialized
INFO - 2020-09-01 00:51:48 --> Language Class Initialized
INFO - 2020-09-01 00:51:48 --> Config Class Initialized
INFO - 2020-09-01 00:51:48 --> Loader Class Initialized
INFO - 2020-09-01 00:51:48 --> Helper loaded: url_helper
INFO - 2020-09-01 00:51:48 --> Helper loaded: form_helper
INFO - 2020-09-01 00:51:48 --> Helper loaded: file_helper
INFO - 2020-09-01 00:51:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 00:51:48 --> Database Driver Class Initialized
DEBUG - 2020-09-01 00:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 00:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 00:51:48 --> Upload Class Initialized
INFO - 2020-09-01 00:51:48 --> Controller Class Initialized
DEBUG - 2020-09-01 00:51:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 00:51:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-01 00:51:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 00:51:48 --> Final output sent to browser
DEBUG - 2020-09-01 00:51:48 --> Total execution time: 0.0529
INFO - 2020-09-01 02:05:21 --> Config Class Initialized
INFO - 2020-09-01 02:05:21 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:05:21 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:05:21 --> Utf8 Class Initialized
INFO - 2020-09-01 02:05:21 --> URI Class Initialized
INFO - 2020-09-01 02:05:21 --> Router Class Initialized
INFO - 2020-09-01 02:05:21 --> Output Class Initialized
INFO - 2020-09-01 02:05:21 --> Security Class Initialized
DEBUG - 2020-09-01 02:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:05:21 --> Input Class Initialized
INFO - 2020-09-01 02:05:21 --> Language Class Initialized
INFO - 2020-09-01 02:05:21 --> Language Class Initialized
INFO - 2020-09-01 02:05:21 --> Config Class Initialized
INFO - 2020-09-01 02:05:21 --> Loader Class Initialized
INFO - 2020-09-01 02:05:21 --> Helper loaded: url_helper
INFO - 2020-09-01 02:05:21 --> Helper loaded: form_helper
INFO - 2020-09-01 02:05:21 --> Helper loaded: file_helper
INFO - 2020-09-01 02:05:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:05:21 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:05:21 --> Upload Class Initialized
INFO - 2020-09-01 02:05:21 --> Controller Class Initialized
ERROR - 2020-09-01 02:05:21 --> 404 Page Not Found: /index
INFO - 2020-09-01 02:05:21 --> Config Class Initialized
INFO - 2020-09-01 02:05:21 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:05:21 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:05:21 --> Utf8 Class Initialized
INFO - 2020-09-01 02:05:21 --> URI Class Initialized
DEBUG - 2020-09-01 02:05:21 --> No URI present. Default controller set.
INFO - 2020-09-01 02:05:21 --> Router Class Initialized
INFO - 2020-09-01 02:05:21 --> Output Class Initialized
INFO - 2020-09-01 02:05:21 --> Security Class Initialized
DEBUG - 2020-09-01 02:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:05:21 --> Input Class Initialized
INFO - 2020-09-01 02:05:21 --> Language Class Initialized
INFO - 2020-09-01 02:05:21 --> Language Class Initialized
INFO - 2020-09-01 02:05:21 --> Config Class Initialized
INFO - 2020-09-01 02:05:21 --> Loader Class Initialized
INFO - 2020-09-01 02:05:21 --> Helper loaded: url_helper
INFO - 2020-09-01 02:05:21 --> Helper loaded: form_helper
INFO - 2020-09-01 02:05:21 --> Helper loaded: file_helper
INFO - 2020-09-01 02:05:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:05:21 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:05:21 --> Upload Class Initialized
INFO - 2020-09-01 02:05:21 --> Controller Class Initialized
DEBUG - 2020-09-01 02:05:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 02:05:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 02:05:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 02:05:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 02:05:21 --> Final output sent to browser
DEBUG - 2020-09-01 02:05:21 --> Total execution time: 0.0482
INFO - 2020-09-01 02:11:10 --> Config Class Initialized
INFO - 2020-09-01 02:11:10 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:11:10 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:11:10 --> Utf8 Class Initialized
INFO - 2020-09-01 02:11:10 --> URI Class Initialized
DEBUG - 2020-09-01 02:11:10 --> No URI present. Default controller set.
INFO - 2020-09-01 02:11:10 --> Router Class Initialized
INFO - 2020-09-01 02:11:10 --> Output Class Initialized
INFO - 2020-09-01 02:11:10 --> Security Class Initialized
DEBUG - 2020-09-01 02:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:11:10 --> Input Class Initialized
INFO - 2020-09-01 02:11:10 --> Language Class Initialized
INFO - 2020-09-01 02:11:10 --> Language Class Initialized
INFO - 2020-09-01 02:11:10 --> Config Class Initialized
INFO - 2020-09-01 02:11:10 --> Loader Class Initialized
INFO - 2020-09-01 02:11:10 --> Helper loaded: url_helper
INFO - 2020-09-01 02:11:10 --> Helper loaded: form_helper
INFO - 2020-09-01 02:11:10 --> Helper loaded: file_helper
INFO - 2020-09-01 02:11:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:11:10 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:11:10 --> Upload Class Initialized
INFO - 2020-09-01 02:11:10 --> Controller Class Initialized
DEBUG - 2020-09-01 02:11:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 02:11:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 02:11:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 02:11:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 02:11:10 --> Final output sent to browser
DEBUG - 2020-09-01 02:11:10 --> Total execution time: 0.0501
INFO - 2020-09-01 02:11:30 --> Config Class Initialized
INFO - 2020-09-01 02:11:30 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:11:30 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:11:30 --> Utf8 Class Initialized
INFO - 2020-09-01 02:11:30 --> URI Class Initialized
INFO - 2020-09-01 02:11:30 --> Router Class Initialized
INFO - 2020-09-01 02:11:30 --> Output Class Initialized
INFO - 2020-09-01 02:11:30 --> Security Class Initialized
DEBUG - 2020-09-01 02:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:11:30 --> Input Class Initialized
INFO - 2020-09-01 02:11:30 --> Language Class Initialized
INFO - 2020-09-01 02:11:30 --> Language Class Initialized
INFO - 2020-09-01 02:11:30 --> Config Class Initialized
INFO - 2020-09-01 02:11:30 --> Loader Class Initialized
INFO - 2020-09-01 02:11:30 --> Helper loaded: url_helper
INFO - 2020-09-01 02:11:30 --> Helper loaded: form_helper
INFO - 2020-09-01 02:11:30 --> Helper loaded: file_helper
INFO - 2020-09-01 02:11:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:11:30 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:11:30 --> Upload Class Initialized
INFO - 2020-09-01 02:11:30 --> Controller Class Initialized
ERROR - 2020-09-01 02:11:30 --> 404 Page Not Found: /index
INFO - 2020-09-01 02:11:35 --> Config Class Initialized
INFO - 2020-09-01 02:11:35 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:11:35 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:11:35 --> Utf8 Class Initialized
INFO - 2020-09-01 02:11:35 --> URI Class Initialized
INFO - 2020-09-01 02:11:35 --> Router Class Initialized
INFO - 2020-09-01 02:11:35 --> Output Class Initialized
INFO - 2020-09-01 02:11:35 --> Security Class Initialized
DEBUG - 2020-09-01 02:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:11:35 --> Input Class Initialized
INFO - 2020-09-01 02:11:35 --> Language Class Initialized
INFO - 2020-09-01 02:11:35 --> Language Class Initialized
INFO - 2020-09-01 02:11:35 --> Config Class Initialized
INFO - 2020-09-01 02:11:35 --> Loader Class Initialized
INFO - 2020-09-01 02:11:35 --> Helper loaded: url_helper
INFO - 2020-09-01 02:11:35 --> Helper loaded: form_helper
INFO - 2020-09-01 02:11:35 --> Helper loaded: file_helper
INFO - 2020-09-01 02:11:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:11:35 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:11:35 --> Upload Class Initialized
INFO - 2020-09-01 02:11:35 --> Controller Class Initialized
ERROR - 2020-09-01 02:11:35 --> 404 Page Not Found: /index
INFO - 2020-09-01 02:11:38 --> Config Class Initialized
INFO - 2020-09-01 02:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:11:38 --> Utf8 Class Initialized
INFO - 2020-09-01 02:11:38 --> URI Class Initialized
INFO - 2020-09-01 02:11:38 --> Router Class Initialized
INFO - 2020-09-01 02:11:38 --> Output Class Initialized
INFO - 2020-09-01 02:11:38 --> Security Class Initialized
DEBUG - 2020-09-01 02:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:11:38 --> Input Class Initialized
INFO - 2020-09-01 02:11:38 --> Language Class Initialized
INFO - 2020-09-01 02:11:38 --> Language Class Initialized
INFO - 2020-09-01 02:11:38 --> Config Class Initialized
INFO - 2020-09-01 02:11:38 --> Loader Class Initialized
INFO - 2020-09-01 02:11:38 --> Helper loaded: url_helper
INFO - 2020-09-01 02:11:38 --> Helper loaded: form_helper
INFO - 2020-09-01 02:11:38 --> Helper loaded: file_helper
INFO - 2020-09-01 02:11:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:11:38 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:11:38 --> Upload Class Initialized
INFO - 2020-09-01 02:11:38 --> Controller Class Initialized
ERROR - 2020-09-01 02:11:38 --> 404 Page Not Found: /index
INFO - 2020-09-01 02:11:46 --> Config Class Initialized
INFO - 2020-09-01 02:11:46 --> Hooks Class Initialized
DEBUG - 2020-09-01 02:11:46 --> UTF-8 Support Enabled
INFO - 2020-09-01 02:11:46 --> Utf8 Class Initialized
INFO - 2020-09-01 02:11:46 --> URI Class Initialized
INFO - 2020-09-01 02:11:46 --> Router Class Initialized
INFO - 2020-09-01 02:11:46 --> Output Class Initialized
INFO - 2020-09-01 02:11:46 --> Security Class Initialized
DEBUG - 2020-09-01 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 02:11:46 --> Input Class Initialized
INFO - 2020-09-01 02:11:46 --> Language Class Initialized
INFO - 2020-09-01 02:11:46 --> Language Class Initialized
INFO - 2020-09-01 02:11:46 --> Config Class Initialized
INFO - 2020-09-01 02:11:46 --> Loader Class Initialized
INFO - 2020-09-01 02:11:46 --> Helper loaded: url_helper
INFO - 2020-09-01 02:11:46 --> Helper loaded: form_helper
INFO - 2020-09-01 02:11:46 --> Helper loaded: file_helper
INFO - 2020-09-01 02:11:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 02:11:46 --> Database Driver Class Initialized
DEBUG - 2020-09-01 02:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 02:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 02:11:46 --> Upload Class Initialized
INFO - 2020-09-01 02:11:46 --> Controller Class Initialized
ERROR - 2020-09-01 02:11:46 --> 404 Page Not Found: /index
INFO - 2020-09-01 03:30:35 --> Config Class Initialized
INFO - 2020-09-01 03:30:35 --> Hooks Class Initialized
DEBUG - 2020-09-01 03:30:35 --> UTF-8 Support Enabled
INFO - 2020-09-01 03:30:35 --> Utf8 Class Initialized
INFO - 2020-09-01 03:30:35 --> URI Class Initialized
DEBUG - 2020-09-01 03:30:35 --> No URI present. Default controller set.
INFO - 2020-09-01 03:30:35 --> Router Class Initialized
INFO - 2020-09-01 03:30:35 --> Output Class Initialized
INFO - 2020-09-01 03:30:35 --> Security Class Initialized
DEBUG - 2020-09-01 03:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 03:30:35 --> Input Class Initialized
INFO - 2020-09-01 03:30:35 --> Language Class Initialized
INFO - 2020-09-01 03:30:35 --> Language Class Initialized
INFO - 2020-09-01 03:30:35 --> Config Class Initialized
INFO - 2020-09-01 03:30:35 --> Loader Class Initialized
INFO - 2020-09-01 03:30:35 --> Helper loaded: url_helper
INFO - 2020-09-01 03:30:35 --> Helper loaded: form_helper
INFO - 2020-09-01 03:30:35 --> Helper loaded: file_helper
INFO - 2020-09-01 03:30:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 03:30:35 --> Database Driver Class Initialized
DEBUG - 2020-09-01 03:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 03:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 03:30:35 --> Upload Class Initialized
INFO - 2020-09-01 03:30:35 --> Controller Class Initialized
DEBUG - 2020-09-01 03:30:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 03:30:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 03:30:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 03:30:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 03:30:35 --> Final output sent to browser
DEBUG - 2020-09-01 03:30:35 --> Total execution time: 0.0524
INFO - 2020-09-01 04:43:37 --> Config Class Initialized
INFO - 2020-09-01 04:43:37 --> Hooks Class Initialized
DEBUG - 2020-09-01 04:43:37 --> UTF-8 Support Enabled
INFO - 2020-09-01 04:43:37 --> Utf8 Class Initialized
INFO - 2020-09-01 04:43:37 --> URI Class Initialized
INFO - 2020-09-01 04:43:37 --> Router Class Initialized
INFO - 2020-09-01 04:43:37 --> Output Class Initialized
INFO - 2020-09-01 04:43:37 --> Security Class Initialized
DEBUG - 2020-09-01 04:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 04:43:37 --> Input Class Initialized
INFO - 2020-09-01 04:43:37 --> Language Class Initialized
INFO - 2020-09-01 04:43:37 --> Language Class Initialized
INFO - 2020-09-01 04:43:37 --> Config Class Initialized
INFO - 2020-09-01 04:43:37 --> Loader Class Initialized
INFO - 2020-09-01 04:43:37 --> Helper loaded: url_helper
INFO - 2020-09-01 04:43:37 --> Helper loaded: form_helper
INFO - 2020-09-01 04:43:37 --> Helper loaded: file_helper
INFO - 2020-09-01 04:43:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 04:43:37 --> Database Driver Class Initialized
DEBUG - 2020-09-01 04:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 04:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 04:43:37 --> Upload Class Initialized
INFO - 2020-09-01 04:43:37 --> Controller Class Initialized
ERROR - 2020-09-01 04:43:37 --> 404 Page Not Found: /index
INFO - 2020-09-01 04:43:37 --> Config Class Initialized
INFO - 2020-09-01 04:43:37 --> Hooks Class Initialized
DEBUG - 2020-09-01 04:43:37 --> UTF-8 Support Enabled
INFO - 2020-09-01 04:43:37 --> Utf8 Class Initialized
INFO - 2020-09-01 04:43:37 --> URI Class Initialized
DEBUG - 2020-09-01 04:43:37 --> No URI present. Default controller set.
INFO - 2020-09-01 04:43:37 --> Router Class Initialized
INFO - 2020-09-01 04:43:37 --> Output Class Initialized
INFO - 2020-09-01 04:43:37 --> Security Class Initialized
DEBUG - 2020-09-01 04:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 04:43:37 --> Input Class Initialized
INFO - 2020-09-01 04:43:37 --> Language Class Initialized
INFO - 2020-09-01 04:43:37 --> Language Class Initialized
INFO - 2020-09-01 04:43:37 --> Config Class Initialized
INFO - 2020-09-01 04:43:37 --> Loader Class Initialized
INFO - 2020-09-01 04:43:37 --> Helper loaded: url_helper
INFO - 2020-09-01 04:43:37 --> Helper loaded: form_helper
INFO - 2020-09-01 04:43:37 --> Helper loaded: file_helper
INFO - 2020-09-01 04:43:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 04:43:37 --> Database Driver Class Initialized
DEBUG - 2020-09-01 04:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 04:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 04:43:37 --> Upload Class Initialized
INFO - 2020-09-01 04:43:37 --> Controller Class Initialized
DEBUG - 2020-09-01 04:43:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 04:43:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 04:43:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 04:43:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 04:43:37 --> Final output sent to browser
DEBUG - 2020-09-01 04:43:37 --> Total execution time: 0.0503
INFO - 2020-09-01 04:43:43 --> Config Class Initialized
INFO - 2020-09-01 04:43:43 --> Hooks Class Initialized
DEBUG - 2020-09-01 04:43:43 --> UTF-8 Support Enabled
INFO - 2020-09-01 04:43:43 --> Utf8 Class Initialized
INFO - 2020-09-01 04:43:43 --> URI Class Initialized
DEBUG - 2020-09-01 04:43:43 --> No URI present. Default controller set.
INFO - 2020-09-01 04:43:43 --> Router Class Initialized
INFO - 2020-09-01 04:43:43 --> Output Class Initialized
INFO - 2020-09-01 04:43:43 --> Security Class Initialized
DEBUG - 2020-09-01 04:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 04:43:43 --> Input Class Initialized
INFO - 2020-09-01 04:43:43 --> Language Class Initialized
INFO - 2020-09-01 04:43:43 --> Language Class Initialized
INFO - 2020-09-01 04:43:43 --> Config Class Initialized
INFO - 2020-09-01 04:43:43 --> Loader Class Initialized
INFO - 2020-09-01 04:43:43 --> Helper loaded: url_helper
INFO - 2020-09-01 04:43:43 --> Helper loaded: form_helper
INFO - 2020-09-01 04:43:43 --> Helper loaded: file_helper
INFO - 2020-09-01 04:43:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 04:43:43 --> Database Driver Class Initialized
DEBUG - 2020-09-01 04:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 04:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 04:43:43 --> Upload Class Initialized
INFO - 2020-09-01 04:43:43 --> Controller Class Initialized
DEBUG - 2020-09-01 04:43:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 04:43:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 04:43:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 04:43:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 04:43:43 --> Final output sent to browser
DEBUG - 2020-09-01 04:43:43 --> Total execution time: 0.0509
INFO - 2020-09-01 05:31:37 --> Config Class Initialized
INFO - 2020-09-01 05:31:37 --> Hooks Class Initialized
DEBUG - 2020-09-01 05:31:37 --> UTF-8 Support Enabled
INFO - 2020-09-01 05:31:37 --> Utf8 Class Initialized
INFO - 2020-09-01 05:31:37 --> URI Class Initialized
INFO - 2020-09-01 05:31:37 --> Router Class Initialized
INFO - 2020-09-01 05:31:37 --> Output Class Initialized
INFO - 2020-09-01 05:31:37 --> Security Class Initialized
DEBUG - 2020-09-01 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 05:31:37 --> Input Class Initialized
INFO - 2020-09-01 05:31:37 --> Language Class Initialized
INFO - 2020-09-01 05:31:37 --> Language Class Initialized
INFO - 2020-09-01 05:31:37 --> Config Class Initialized
INFO - 2020-09-01 05:31:38 --> Loader Class Initialized
INFO - 2020-09-01 05:31:38 --> Helper loaded: url_helper
INFO - 2020-09-01 05:31:38 --> Helper loaded: form_helper
INFO - 2020-09-01 05:31:38 --> Helper loaded: file_helper
INFO - 2020-09-01 05:31:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 05:31:38 --> Database Driver Class Initialized
DEBUG - 2020-09-01 05:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 05:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 05:31:38 --> Upload Class Initialized
INFO - 2020-09-01 05:31:38 --> Controller Class Initialized
ERROR - 2020-09-01 05:31:38 --> 404 Page Not Found: /index
INFO - 2020-09-01 07:11:09 --> Config Class Initialized
INFO - 2020-09-01 07:11:09 --> Hooks Class Initialized
DEBUG - 2020-09-01 07:11:09 --> UTF-8 Support Enabled
INFO - 2020-09-01 07:11:09 --> Utf8 Class Initialized
INFO - 2020-09-01 07:11:09 --> URI Class Initialized
INFO - 2020-09-01 07:11:09 --> Router Class Initialized
INFO - 2020-09-01 07:11:09 --> Output Class Initialized
INFO - 2020-09-01 07:11:09 --> Security Class Initialized
DEBUG - 2020-09-01 07:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 07:11:09 --> Input Class Initialized
INFO - 2020-09-01 07:11:09 --> Language Class Initialized
INFO - 2020-09-01 07:11:09 --> Language Class Initialized
INFO - 2020-09-01 07:11:09 --> Config Class Initialized
INFO - 2020-09-01 07:11:09 --> Loader Class Initialized
INFO - 2020-09-01 07:11:09 --> Helper loaded: url_helper
INFO - 2020-09-01 07:11:09 --> Helper loaded: form_helper
INFO - 2020-09-01 07:11:09 --> Helper loaded: file_helper
INFO - 2020-09-01 07:11:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 07:11:09 --> Database Driver Class Initialized
DEBUG - 2020-09-01 07:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 07:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 07:11:09 --> Upload Class Initialized
INFO - 2020-09-01 07:11:09 --> Controller Class Initialized
ERROR - 2020-09-01 07:11:09 --> 404 Page Not Found: /index
INFO - 2020-09-01 07:27:15 --> Config Class Initialized
INFO - 2020-09-01 07:27:15 --> Hooks Class Initialized
DEBUG - 2020-09-01 07:27:15 --> UTF-8 Support Enabled
INFO - 2020-09-01 07:27:15 --> Utf8 Class Initialized
INFO - 2020-09-01 07:27:15 --> URI Class Initialized
INFO - 2020-09-01 07:27:15 --> Router Class Initialized
INFO - 2020-09-01 07:27:15 --> Output Class Initialized
INFO - 2020-09-01 07:27:15 --> Security Class Initialized
DEBUG - 2020-09-01 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 07:27:15 --> Input Class Initialized
INFO - 2020-09-01 07:27:15 --> Language Class Initialized
INFO - 2020-09-01 07:27:15 --> Language Class Initialized
INFO - 2020-09-01 07:27:15 --> Config Class Initialized
INFO - 2020-09-01 07:27:15 --> Loader Class Initialized
INFO - 2020-09-01 07:27:15 --> Helper loaded: url_helper
INFO - 2020-09-01 07:27:15 --> Helper loaded: form_helper
INFO - 2020-09-01 07:27:15 --> Helper loaded: file_helper
INFO - 2020-09-01 07:27:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 07:27:15 --> Database Driver Class Initialized
DEBUG - 2020-09-01 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 07:27:15 --> Upload Class Initialized
INFO - 2020-09-01 07:27:15 --> Controller Class Initialized
ERROR - 2020-09-01 07:27:15 --> 404 Page Not Found: /index
INFO - 2020-09-01 07:37:03 --> Config Class Initialized
INFO - 2020-09-01 07:37:03 --> Hooks Class Initialized
DEBUG - 2020-09-01 07:37:03 --> UTF-8 Support Enabled
INFO - 2020-09-01 07:37:03 --> Utf8 Class Initialized
INFO - 2020-09-01 07:37:03 --> URI Class Initialized
INFO - 2020-09-01 07:37:03 --> Router Class Initialized
INFO - 2020-09-01 07:37:03 --> Output Class Initialized
INFO - 2020-09-01 07:37:03 --> Security Class Initialized
DEBUG - 2020-09-01 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 07:37:03 --> Input Class Initialized
INFO - 2020-09-01 07:37:03 --> Language Class Initialized
INFO - 2020-09-01 07:37:03 --> Language Class Initialized
INFO - 2020-09-01 07:37:03 --> Config Class Initialized
INFO - 2020-09-01 07:37:03 --> Loader Class Initialized
INFO - 2020-09-01 07:37:03 --> Helper loaded: url_helper
INFO - 2020-09-01 07:37:03 --> Helper loaded: form_helper
INFO - 2020-09-01 07:37:03 --> Helper loaded: file_helper
INFO - 2020-09-01 07:37:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 07:37:03 --> Database Driver Class Initialized
DEBUG - 2020-09-01 07:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 07:37:03 --> Upload Class Initialized
INFO - 2020-09-01 07:37:03 --> Controller Class Initialized
ERROR - 2020-09-01 07:37:03 --> 404 Page Not Found: /index
INFO - 2020-09-01 08:00:56 --> Config Class Initialized
INFO - 2020-09-01 08:00:56 --> Hooks Class Initialized
DEBUG - 2020-09-01 08:00:56 --> UTF-8 Support Enabled
INFO - 2020-09-01 08:00:56 --> Utf8 Class Initialized
INFO - 2020-09-01 08:00:56 --> URI Class Initialized
INFO - 2020-09-01 08:00:56 --> Router Class Initialized
INFO - 2020-09-01 08:00:56 --> Output Class Initialized
INFO - 2020-09-01 08:00:56 --> Security Class Initialized
DEBUG - 2020-09-01 08:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 08:00:56 --> Input Class Initialized
INFO - 2020-09-01 08:00:56 --> Language Class Initialized
INFO - 2020-09-01 08:00:56 --> Language Class Initialized
INFO - 2020-09-01 08:00:56 --> Config Class Initialized
INFO - 2020-09-01 08:00:56 --> Loader Class Initialized
INFO - 2020-09-01 08:00:56 --> Helper loaded: url_helper
INFO - 2020-09-01 08:00:56 --> Helper loaded: form_helper
INFO - 2020-09-01 08:00:56 --> Helper loaded: file_helper
INFO - 2020-09-01 08:00:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 08:00:56 --> Database Driver Class Initialized
DEBUG - 2020-09-01 08:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 08:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 08:00:56 --> Upload Class Initialized
INFO - 2020-09-01 08:00:56 --> Controller Class Initialized
ERROR - 2020-09-01 08:00:56 --> 404 Page Not Found: /index
INFO - 2020-09-01 08:39:01 --> Config Class Initialized
INFO - 2020-09-01 08:39:02 --> Hooks Class Initialized
DEBUG - 2020-09-01 08:39:02 --> UTF-8 Support Enabled
INFO - 2020-09-01 08:39:02 --> Utf8 Class Initialized
INFO - 2020-09-01 08:39:02 --> URI Class Initialized
DEBUG - 2020-09-01 08:39:02 --> No URI present. Default controller set.
INFO - 2020-09-01 08:39:02 --> Router Class Initialized
INFO - 2020-09-01 08:39:02 --> Output Class Initialized
INFO - 2020-09-01 08:39:02 --> Security Class Initialized
DEBUG - 2020-09-01 08:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 08:39:02 --> Input Class Initialized
INFO - 2020-09-01 08:39:02 --> Language Class Initialized
INFO - 2020-09-01 08:39:02 --> Language Class Initialized
INFO - 2020-09-01 08:39:02 --> Config Class Initialized
INFO - 2020-09-01 08:39:02 --> Loader Class Initialized
INFO - 2020-09-01 08:39:02 --> Helper loaded: url_helper
INFO - 2020-09-01 08:39:02 --> Helper loaded: form_helper
INFO - 2020-09-01 08:39:02 --> Helper loaded: file_helper
INFO - 2020-09-01 08:39:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 08:39:02 --> Database Driver Class Initialized
DEBUG - 2020-09-01 08:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 08:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 08:39:02 --> Upload Class Initialized
INFO - 2020-09-01 08:39:02 --> Controller Class Initialized
DEBUG - 2020-09-01 08:39:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 08:39:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 08:39:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 08:39:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 08:39:02 --> Final output sent to browser
DEBUG - 2020-09-01 08:39:02 --> Total execution time: 1.0008
INFO - 2020-09-01 10:09:29 --> Config Class Initialized
INFO - 2020-09-01 10:09:29 --> Hooks Class Initialized
DEBUG - 2020-09-01 10:09:29 --> UTF-8 Support Enabled
INFO - 2020-09-01 10:09:29 --> Utf8 Class Initialized
INFO - 2020-09-01 10:09:29 --> URI Class Initialized
INFO - 2020-09-01 10:09:29 --> Router Class Initialized
INFO - 2020-09-01 10:09:29 --> Output Class Initialized
INFO - 2020-09-01 10:09:29 --> Security Class Initialized
DEBUG - 2020-09-01 10:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 10:09:29 --> Input Class Initialized
INFO - 2020-09-01 10:09:29 --> Language Class Initialized
INFO - 2020-09-01 10:09:29 --> Language Class Initialized
INFO - 2020-09-01 10:09:29 --> Config Class Initialized
INFO - 2020-09-01 10:09:29 --> Loader Class Initialized
INFO - 2020-09-01 10:09:29 --> Helper loaded: url_helper
INFO - 2020-09-01 10:09:29 --> Helper loaded: form_helper
INFO - 2020-09-01 10:09:29 --> Helper loaded: file_helper
INFO - 2020-09-01 10:09:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 10:09:29 --> Database Driver Class Initialized
DEBUG - 2020-09-01 10:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 10:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 10:09:29 --> Upload Class Initialized
INFO - 2020-09-01 10:09:29 --> Controller Class Initialized
ERROR - 2020-09-01 10:09:29 --> 404 Page Not Found: /index
INFO - 2020-09-01 10:37:04 --> Config Class Initialized
INFO - 2020-09-01 10:37:04 --> Hooks Class Initialized
DEBUG - 2020-09-01 10:37:04 --> UTF-8 Support Enabled
INFO - 2020-09-01 10:37:04 --> Utf8 Class Initialized
INFO - 2020-09-01 10:37:04 --> URI Class Initialized
INFO - 2020-09-01 10:37:04 --> Router Class Initialized
INFO - 2020-09-01 10:37:04 --> Output Class Initialized
INFO - 2020-09-01 10:37:04 --> Security Class Initialized
DEBUG - 2020-09-01 10:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 10:37:04 --> Input Class Initialized
INFO - 2020-09-01 10:37:04 --> Language Class Initialized
INFO - 2020-09-01 10:37:04 --> Language Class Initialized
INFO - 2020-09-01 10:37:04 --> Config Class Initialized
INFO - 2020-09-01 10:37:04 --> Loader Class Initialized
INFO - 2020-09-01 10:37:04 --> Helper loaded: url_helper
INFO - 2020-09-01 10:37:04 --> Helper loaded: form_helper
INFO - 2020-09-01 10:37:04 --> Helper loaded: file_helper
INFO - 2020-09-01 10:37:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 10:37:04 --> Database Driver Class Initialized
DEBUG - 2020-09-01 10:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 10:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 10:37:04 --> Upload Class Initialized
INFO - 2020-09-01 10:37:04 --> Controller Class Initialized
ERROR - 2020-09-01 10:37:04 --> 404 Page Not Found: /index
INFO - 2020-09-01 10:37:05 --> Config Class Initialized
INFO - 2020-09-01 10:37:05 --> Hooks Class Initialized
DEBUG - 2020-09-01 10:37:05 --> UTF-8 Support Enabled
INFO - 2020-09-01 10:37:05 --> Utf8 Class Initialized
INFO - 2020-09-01 10:37:05 --> URI Class Initialized
INFO - 2020-09-01 10:37:05 --> Router Class Initialized
INFO - 2020-09-01 10:37:05 --> Output Class Initialized
INFO - 2020-09-01 10:37:05 --> Security Class Initialized
DEBUG - 2020-09-01 10:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 10:37:05 --> Input Class Initialized
INFO - 2020-09-01 10:37:05 --> Language Class Initialized
INFO - 2020-09-01 10:37:05 --> Language Class Initialized
INFO - 2020-09-01 10:37:05 --> Config Class Initialized
INFO - 2020-09-01 10:37:05 --> Loader Class Initialized
INFO - 2020-09-01 10:37:05 --> Helper loaded: url_helper
INFO - 2020-09-01 10:37:05 --> Helper loaded: form_helper
INFO - 2020-09-01 10:37:05 --> Helper loaded: file_helper
INFO - 2020-09-01 10:37:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 10:37:05 --> Database Driver Class Initialized
DEBUG - 2020-09-01 10:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 10:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 10:37:05 --> Upload Class Initialized
INFO - 2020-09-01 10:37:05 --> Controller Class Initialized
DEBUG - 2020-09-01 10:37:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 10:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-01 10:37:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 10:37:05 --> Final output sent to browser
DEBUG - 2020-09-01 10:37:05 --> Total execution time: 0.0730
INFO - 2020-09-01 12:15:24 --> Config Class Initialized
INFO - 2020-09-01 12:15:24 --> Hooks Class Initialized
DEBUG - 2020-09-01 12:15:24 --> UTF-8 Support Enabled
INFO - 2020-09-01 12:15:24 --> Utf8 Class Initialized
INFO - 2020-09-01 12:15:24 --> URI Class Initialized
DEBUG - 2020-09-01 12:15:24 --> No URI present. Default controller set.
INFO - 2020-09-01 12:15:24 --> Router Class Initialized
INFO - 2020-09-01 12:15:24 --> Output Class Initialized
INFO - 2020-09-01 12:15:24 --> Security Class Initialized
DEBUG - 2020-09-01 12:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 12:15:24 --> Input Class Initialized
INFO - 2020-09-01 12:15:24 --> Language Class Initialized
INFO - 2020-09-01 12:15:24 --> Language Class Initialized
INFO - 2020-09-01 12:15:24 --> Config Class Initialized
INFO - 2020-09-01 12:15:24 --> Loader Class Initialized
INFO - 2020-09-01 12:15:24 --> Helper loaded: url_helper
INFO - 2020-09-01 12:15:24 --> Helper loaded: form_helper
INFO - 2020-09-01 12:15:24 --> Helper loaded: file_helper
INFO - 2020-09-01 12:15:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 12:15:24 --> Database Driver Class Initialized
DEBUG - 2020-09-01 12:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 12:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 12:15:24 --> Upload Class Initialized
INFO - 2020-09-01 12:15:24 --> Controller Class Initialized
DEBUG - 2020-09-01 12:15:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 12:15:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 12:15:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 12:15:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 12:15:24 --> Final output sent to browser
DEBUG - 2020-09-01 12:15:24 --> Total execution time: 0.0701
INFO - 2020-09-01 13:19:44 --> Config Class Initialized
INFO - 2020-09-01 13:19:44 --> Hooks Class Initialized
DEBUG - 2020-09-01 13:19:44 --> UTF-8 Support Enabled
INFO - 2020-09-01 13:19:44 --> Utf8 Class Initialized
INFO - 2020-09-01 13:19:44 --> URI Class Initialized
DEBUG - 2020-09-01 13:19:44 --> No URI present. Default controller set.
INFO - 2020-09-01 13:19:44 --> Router Class Initialized
INFO - 2020-09-01 13:19:44 --> Output Class Initialized
INFO - 2020-09-01 13:19:44 --> Security Class Initialized
DEBUG - 2020-09-01 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 13:19:44 --> Input Class Initialized
INFO - 2020-09-01 13:19:44 --> Language Class Initialized
INFO - 2020-09-01 13:19:44 --> Language Class Initialized
INFO - 2020-09-01 13:19:44 --> Config Class Initialized
INFO - 2020-09-01 13:19:44 --> Loader Class Initialized
INFO - 2020-09-01 13:19:44 --> Helper loaded: url_helper
INFO - 2020-09-01 13:19:44 --> Helper loaded: form_helper
INFO - 2020-09-01 13:19:44 --> Helper loaded: file_helper
INFO - 2020-09-01 13:19:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 13:19:44 --> Database Driver Class Initialized
DEBUG - 2020-09-01 13:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 13:19:44 --> Upload Class Initialized
INFO - 2020-09-01 13:19:44 --> Controller Class Initialized
DEBUG - 2020-09-01 13:19:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 13:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 13:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 13:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 13:19:44 --> Final output sent to browser
DEBUG - 2020-09-01 13:19:44 --> Total execution time: 0.0609
INFO - 2020-09-01 13:19:44 --> Config Class Initialized
INFO - 2020-09-01 13:19:44 --> Hooks Class Initialized
DEBUG - 2020-09-01 13:19:44 --> UTF-8 Support Enabled
INFO - 2020-09-01 13:19:44 --> Utf8 Class Initialized
INFO - 2020-09-01 13:19:44 --> URI Class Initialized
DEBUG - 2020-09-01 13:19:44 --> No URI present. Default controller set.
INFO - 2020-09-01 13:19:44 --> Router Class Initialized
INFO - 2020-09-01 13:19:44 --> Output Class Initialized
INFO - 2020-09-01 13:19:44 --> Security Class Initialized
DEBUG - 2020-09-01 13:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 13:19:44 --> Input Class Initialized
INFO - 2020-09-01 13:19:44 --> Language Class Initialized
INFO - 2020-09-01 13:19:44 --> Language Class Initialized
INFO - 2020-09-01 13:19:44 --> Config Class Initialized
INFO - 2020-09-01 13:19:44 --> Loader Class Initialized
INFO - 2020-09-01 13:19:44 --> Helper loaded: url_helper
INFO - 2020-09-01 13:19:44 --> Helper loaded: form_helper
INFO - 2020-09-01 13:19:44 --> Helper loaded: file_helper
INFO - 2020-09-01 13:19:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 13:19:44 --> Database Driver Class Initialized
DEBUG - 2020-09-01 13:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 13:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 13:19:44 --> Upload Class Initialized
INFO - 2020-09-01 13:19:44 --> Controller Class Initialized
DEBUG - 2020-09-01 13:19:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 13:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 13:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 13:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 13:19:44 --> Final output sent to browser
DEBUG - 2020-09-01 13:19:44 --> Total execution time: 0.0487
INFO - 2020-09-01 13:19:54 --> Config Class Initialized
INFO - 2020-09-01 13:19:54 --> Hooks Class Initialized
DEBUG - 2020-09-01 13:19:54 --> UTF-8 Support Enabled
INFO - 2020-09-01 13:19:54 --> Utf8 Class Initialized
INFO - 2020-09-01 13:19:54 --> URI Class Initialized
DEBUG - 2020-09-01 13:19:54 --> No URI present. Default controller set.
INFO - 2020-09-01 13:19:54 --> Router Class Initialized
INFO - 2020-09-01 13:19:54 --> Output Class Initialized
INFO - 2020-09-01 13:19:54 --> Security Class Initialized
DEBUG - 2020-09-01 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 13:19:54 --> Input Class Initialized
INFO - 2020-09-01 13:19:54 --> Language Class Initialized
INFO - 2020-09-01 13:19:54 --> Language Class Initialized
INFO - 2020-09-01 13:19:54 --> Config Class Initialized
INFO - 2020-09-01 13:19:54 --> Loader Class Initialized
INFO - 2020-09-01 13:19:54 --> Helper loaded: url_helper
INFO - 2020-09-01 13:19:54 --> Helper loaded: form_helper
INFO - 2020-09-01 13:19:54 --> Helper loaded: file_helper
INFO - 2020-09-01 13:19:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 13:19:54 --> Database Driver Class Initialized
DEBUG - 2020-09-01 13:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 13:19:54 --> Upload Class Initialized
INFO - 2020-09-01 13:19:54 --> Controller Class Initialized
DEBUG - 2020-09-01 13:19:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 13:19:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 13:19:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 13:19:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 13:19:54 --> Final output sent to browser
DEBUG - 2020-09-01 13:19:54 --> Total execution time: 0.0522
INFO - 2020-09-01 13:32:55 --> Config Class Initialized
INFO - 2020-09-01 13:32:55 --> Hooks Class Initialized
DEBUG - 2020-09-01 13:32:55 --> UTF-8 Support Enabled
INFO - 2020-09-01 13:32:55 --> Utf8 Class Initialized
INFO - 2020-09-01 13:32:55 --> URI Class Initialized
INFO - 2020-09-01 13:32:55 --> Router Class Initialized
INFO - 2020-09-01 13:32:55 --> Output Class Initialized
INFO - 2020-09-01 13:32:55 --> Security Class Initialized
DEBUG - 2020-09-01 13:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 13:32:55 --> Input Class Initialized
INFO - 2020-09-01 13:32:55 --> Language Class Initialized
INFO - 2020-09-01 13:32:55 --> Language Class Initialized
INFO - 2020-09-01 13:32:55 --> Config Class Initialized
INFO - 2020-09-01 13:32:55 --> Loader Class Initialized
INFO - 2020-09-01 13:32:55 --> Helper loaded: url_helper
INFO - 2020-09-01 13:32:55 --> Helper loaded: form_helper
INFO - 2020-09-01 13:32:55 --> Helper loaded: file_helper
INFO - 2020-09-01 13:32:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 13:32:55 --> Database Driver Class Initialized
DEBUG - 2020-09-01 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 13:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 13:32:55 --> Upload Class Initialized
INFO - 2020-09-01 13:32:55 --> Controller Class Initialized
ERROR - 2020-09-01 13:32:55 --> 404 Page Not Found: /index
INFO - 2020-09-01 13:32:55 --> Config Class Initialized
INFO - 2020-09-01 13:32:55 --> Hooks Class Initialized
DEBUG - 2020-09-01 13:32:55 --> UTF-8 Support Enabled
INFO - 2020-09-01 13:32:55 --> Utf8 Class Initialized
INFO - 2020-09-01 13:32:55 --> URI Class Initialized
INFO - 2020-09-01 13:32:55 --> Router Class Initialized
INFO - 2020-09-01 13:32:55 --> Output Class Initialized
INFO - 2020-09-01 13:32:55 --> Security Class Initialized
DEBUG - 2020-09-01 13:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 13:32:55 --> Input Class Initialized
INFO - 2020-09-01 13:32:55 --> Language Class Initialized
INFO - 2020-09-01 13:32:55 --> Language Class Initialized
INFO - 2020-09-01 13:32:55 --> Config Class Initialized
INFO - 2020-09-01 13:32:55 --> Loader Class Initialized
INFO - 2020-09-01 13:32:55 --> Helper loaded: url_helper
INFO - 2020-09-01 13:32:55 --> Helper loaded: form_helper
INFO - 2020-09-01 13:32:55 --> Helper loaded: file_helper
INFO - 2020-09-01 13:32:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 13:32:55 --> Database Driver Class Initialized
DEBUG - 2020-09-01 13:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 13:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 13:32:55 --> Upload Class Initialized
INFO - 2020-09-01 13:32:55 --> Controller Class Initialized
ERROR - 2020-09-01 13:32:55 --> 404 Page Not Found: /index
INFO - 2020-09-01 14:51:43 --> Config Class Initialized
INFO - 2020-09-01 14:51:43 --> Hooks Class Initialized
DEBUG - 2020-09-01 14:51:43 --> UTF-8 Support Enabled
INFO - 2020-09-01 14:51:43 --> Utf8 Class Initialized
INFO - 2020-09-01 14:51:43 --> URI Class Initialized
INFO - 2020-09-01 14:51:43 --> Router Class Initialized
INFO - 2020-09-01 14:51:43 --> Output Class Initialized
INFO - 2020-09-01 14:51:43 --> Security Class Initialized
DEBUG - 2020-09-01 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 14:51:43 --> Input Class Initialized
INFO - 2020-09-01 14:51:43 --> Language Class Initialized
INFO - 2020-09-01 14:51:43 --> Language Class Initialized
INFO - 2020-09-01 14:51:43 --> Config Class Initialized
INFO - 2020-09-01 14:51:43 --> Loader Class Initialized
INFO - 2020-09-01 14:51:43 --> Helper loaded: url_helper
INFO - 2020-09-01 14:51:43 --> Helper loaded: form_helper
INFO - 2020-09-01 14:51:43 --> Helper loaded: file_helper
INFO - 2020-09-01 14:51:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 14:51:43 --> Database Driver Class Initialized
DEBUG - 2020-09-01 14:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 14:51:43 --> Upload Class Initialized
INFO - 2020-09-01 14:51:43 --> Controller Class Initialized
ERROR - 2020-09-01 14:51:43 --> 404 Page Not Found: /index
INFO - 2020-09-01 14:51:49 --> Config Class Initialized
INFO - 2020-09-01 14:51:49 --> Hooks Class Initialized
DEBUG - 2020-09-01 14:51:49 --> UTF-8 Support Enabled
INFO - 2020-09-01 14:51:49 --> Utf8 Class Initialized
INFO - 2020-09-01 14:51:49 --> URI Class Initialized
INFO - 2020-09-01 14:51:49 --> Router Class Initialized
INFO - 2020-09-01 14:51:49 --> Output Class Initialized
INFO - 2020-09-01 14:51:49 --> Security Class Initialized
DEBUG - 2020-09-01 14:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 14:51:49 --> Input Class Initialized
INFO - 2020-09-01 14:51:49 --> Language Class Initialized
INFO - 2020-09-01 14:51:49 --> Language Class Initialized
INFO - 2020-09-01 14:51:49 --> Config Class Initialized
INFO - 2020-09-01 14:51:49 --> Loader Class Initialized
INFO - 2020-09-01 14:51:49 --> Helper loaded: url_helper
INFO - 2020-09-01 14:51:49 --> Helper loaded: form_helper
INFO - 2020-09-01 14:51:49 --> Helper loaded: file_helper
INFO - 2020-09-01 14:51:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 14:51:49 --> Database Driver Class Initialized
DEBUG - 2020-09-01 14:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 14:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 14:51:49 --> Upload Class Initialized
INFO - 2020-09-01 14:51:49 --> Controller Class Initialized
ERROR - 2020-09-01 14:51:49 --> 404 Page Not Found: /index
INFO - 2020-09-01 14:51:53 --> Config Class Initialized
INFO - 2020-09-01 14:51:53 --> Hooks Class Initialized
DEBUG - 2020-09-01 14:51:53 --> UTF-8 Support Enabled
INFO - 2020-09-01 14:51:53 --> Utf8 Class Initialized
INFO - 2020-09-01 14:51:53 --> URI Class Initialized
DEBUG - 2020-09-01 14:51:53 --> No URI present. Default controller set.
INFO - 2020-09-01 14:51:53 --> Router Class Initialized
INFO - 2020-09-01 14:51:53 --> Output Class Initialized
INFO - 2020-09-01 14:51:53 --> Security Class Initialized
DEBUG - 2020-09-01 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 14:51:53 --> Input Class Initialized
INFO - 2020-09-01 14:51:53 --> Language Class Initialized
INFO - 2020-09-01 14:51:53 --> Language Class Initialized
INFO - 2020-09-01 14:51:53 --> Config Class Initialized
INFO - 2020-09-01 14:51:53 --> Loader Class Initialized
INFO - 2020-09-01 14:51:53 --> Helper loaded: url_helper
INFO - 2020-09-01 14:51:53 --> Helper loaded: form_helper
INFO - 2020-09-01 14:51:53 --> Helper loaded: file_helper
INFO - 2020-09-01 14:51:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 14:51:53 --> Database Driver Class Initialized
DEBUG - 2020-09-01 14:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 14:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 14:51:53 --> Upload Class Initialized
INFO - 2020-09-01 14:51:53 --> Controller Class Initialized
DEBUG - 2020-09-01 14:51:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 14:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 14:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 14:51:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 14:51:53 --> Final output sent to browser
DEBUG - 2020-09-01 14:51:53 --> Total execution time: 0.0541
INFO - 2020-09-01 15:33:07 --> Config Class Initialized
INFO - 2020-09-01 15:33:07 --> Hooks Class Initialized
DEBUG - 2020-09-01 15:33:07 --> UTF-8 Support Enabled
INFO - 2020-09-01 15:33:07 --> Utf8 Class Initialized
INFO - 2020-09-01 15:33:07 --> URI Class Initialized
DEBUG - 2020-09-01 15:33:07 --> No URI present. Default controller set.
INFO - 2020-09-01 15:33:07 --> Router Class Initialized
INFO - 2020-09-01 15:33:07 --> Output Class Initialized
INFO - 2020-09-01 15:33:07 --> Security Class Initialized
DEBUG - 2020-09-01 15:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 15:33:07 --> Input Class Initialized
INFO - 2020-09-01 15:33:07 --> Language Class Initialized
INFO - 2020-09-01 15:33:07 --> Language Class Initialized
INFO - 2020-09-01 15:33:07 --> Config Class Initialized
INFO - 2020-09-01 15:33:07 --> Loader Class Initialized
INFO - 2020-09-01 15:33:07 --> Helper loaded: url_helper
INFO - 2020-09-01 15:33:07 --> Helper loaded: form_helper
INFO - 2020-09-01 15:33:07 --> Helper loaded: file_helper
INFO - 2020-09-01 15:33:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 15:33:07 --> Database Driver Class Initialized
DEBUG - 2020-09-01 15:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 15:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 15:33:07 --> Upload Class Initialized
INFO - 2020-09-01 15:33:07 --> Controller Class Initialized
DEBUG - 2020-09-01 15:33:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 15:33:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 15:33:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 15:33:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 15:33:07 --> Final output sent to browser
DEBUG - 2020-09-01 15:33:07 --> Total execution time: 0.0575
INFO - 2020-09-01 17:18:49 --> Config Class Initialized
INFO - 2020-09-01 17:18:49 --> Hooks Class Initialized
DEBUG - 2020-09-01 17:18:49 --> UTF-8 Support Enabled
INFO - 2020-09-01 17:18:49 --> Utf8 Class Initialized
INFO - 2020-09-01 17:18:49 --> URI Class Initialized
DEBUG - 2020-09-01 17:18:49 --> No URI present. Default controller set.
INFO - 2020-09-01 17:18:49 --> Router Class Initialized
INFO - 2020-09-01 17:18:49 --> Output Class Initialized
INFO - 2020-09-01 17:18:49 --> Security Class Initialized
DEBUG - 2020-09-01 17:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 17:18:49 --> Input Class Initialized
INFO - 2020-09-01 17:18:49 --> Language Class Initialized
INFO - 2020-09-01 17:18:49 --> Language Class Initialized
INFO - 2020-09-01 17:18:49 --> Config Class Initialized
INFO - 2020-09-01 17:18:49 --> Loader Class Initialized
INFO - 2020-09-01 17:18:49 --> Helper loaded: url_helper
INFO - 2020-09-01 17:18:49 --> Helper loaded: form_helper
INFO - 2020-09-01 17:18:49 --> Helper loaded: file_helper
INFO - 2020-09-01 17:18:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 17:18:49 --> Database Driver Class Initialized
DEBUG - 2020-09-01 17:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 17:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 17:18:49 --> Upload Class Initialized
INFO - 2020-09-01 17:18:49 --> Controller Class Initialized
DEBUG - 2020-09-01 17:18:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 17:18:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 17:18:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 17:18:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 17:18:49 --> Final output sent to browser
DEBUG - 2020-09-01 17:18:49 --> Total execution time: 0.1599
INFO - 2020-09-01 17:18:53 --> Config Class Initialized
INFO - 2020-09-01 17:18:53 --> Hooks Class Initialized
DEBUG - 2020-09-01 17:18:53 --> UTF-8 Support Enabled
INFO - 2020-09-01 17:18:53 --> Utf8 Class Initialized
INFO - 2020-09-01 17:18:53 --> URI Class Initialized
INFO - 2020-09-01 17:18:53 --> Router Class Initialized
INFO - 2020-09-01 17:18:53 --> Output Class Initialized
INFO - 2020-09-01 17:18:53 --> Security Class Initialized
DEBUG - 2020-09-01 17:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 17:18:53 --> Input Class Initialized
INFO - 2020-09-01 17:18:53 --> Language Class Initialized
INFO - 2020-09-01 17:18:53 --> Language Class Initialized
INFO - 2020-09-01 17:18:53 --> Config Class Initialized
INFO - 2020-09-01 17:18:53 --> Loader Class Initialized
INFO - 2020-09-01 17:18:53 --> Helper loaded: url_helper
INFO - 2020-09-01 17:18:53 --> Helper loaded: form_helper
INFO - 2020-09-01 17:18:53 --> Helper loaded: file_helper
INFO - 2020-09-01 17:18:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 17:18:53 --> Database Driver Class Initialized
DEBUG - 2020-09-01 17:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 17:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 17:18:53 --> Upload Class Initialized
INFO - 2020-09-01 17:18:53 --> Controller Class Initialized
ERROR - 2020-09-01 17:18:53 --> 404 Page Not Found: /index
INFO - 2020-09-01 18:18:50 --> Config Class Initialized
INFO - 2020-09-01 18:18:50 --> Hooks Class Initialized
DEBUG - 2020-09-01 18:18:50 --> UTF-8 Support Enabled
INFO - 2020-09-01 18:18:50 --> Utf8 Class Initialized
INFO - 2020-09-01 18:18:50 --> URI Class Initialized
INFO - 2020-09-01 18:18:50 --> Router Class Initialized
INFO - 2020-09-01 18:18:50 --> Output Class Initialized
INFO - 2020-09-01 18:18:50 --> Security Class Initialized
DEBUG - 2020-09-01 18:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 18:18:50 --> Input Class Initialized
INFO - 2020-09-01 18:18:50 --> Language Class Initialized
INFO - 2020-09-01 18:18:50 --> Language Class Initialized
INFO - 2020-09-01 18:18:50 --> Config Class Initialized
INFO - 2020-09-01 18:18:50 --> Loader Class Initialized
INFO - 2020-09-01 18:18:50 --> Helper loaded: url_helper
INFO - 2020-09-01 18:18:50 --> Helper loaded: form_helper
INFO - 2020-09-01 18:18:50 --> Helper loaded: file_helper
INFO - 2020-09-01 18:18:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 18:18:50 --> Database Driver Class Initialized
DEBUG - 2020-09-01 18:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 18:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 18:18:50 --> Upload Class Initialized
INFO - 2020-09-01 18:18:50 --> Controller Class Initialized
ERROR - 2020-09-01 18:18:50 --> 404 Page Not Found: /index
INFO - 2020-09-01 18:51:06 --> Config Class Initialized
INFO - 2020-09-01 18:51:06 --> Hooks Class Initialized
DEBUG - 2020-09-01 18:51:06 --> UTF-8 Support Enabled
INFO - 2020-09-01 18:51:06 --> Utf8 Class Initialized
INFO - 2020-09-01 18:51:06 --> URI Class Initialized
INFO - 2020-09-01 18:51:06 --> Router Class Initialized
INFO - 2020-09-01 18:51:06 --> Output Class Initialized
INFO - 2020-09-01 18:51:06 --> Security Class Initialized
DEBUG - 2020-09-01 18:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 18:51:06 --> Input Class Initialized
INFO - 2020-09-01 18:51:06 --> Language Class Initialized
INFO - 2020-09-01 18:51:06 --> Language Class Initialized
INFO - 2020-09-01 18:51:06 --> Config Class Initialized
INFO - 2020-09-01 18:51:06 --> Loader Class Initialized
INFO - 2020-09-01 18:51:06 --> Helper loaded: url_helper
INFO - 2020-09-01 18:51:06 --> Helper loaded: form_helper
INFO - 2020-09-01 18:51:06 --> Helper loaded: file_helper
INFO - 2020-09-01 18:51:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 18:51:06 --> Database Driver Class Initialized
DEBUG - 2020-09-01 18:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 18:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 18:51:06 --> Upload Class Initialized
INFO - 2020-09-01 18:51:06 --> Controller Class Initialized
ERROR - 2020-09-01 18:51:06 --> 404 Page Not Found: /index
INFO - 2020-09-01 18:51:10 --> Config Class Initialized
INFO - 2020-09-01 18:51:10 --> Hooks Class Initialized
DEBUG - 2020-09-01 18:51:10 --> UTF-8 Support Enabled
INFO - 2020-09-01 18:51:10 --> Utf8 Class Initialized
INFO - 2020-09-01 18:51:10 --> URI Class Initialized
INFO - 2020-09-01 18:51:10 --> Router Class Initialized
INFO - 2020-09-01 18:51:10 --> Output Class Initialized
INFO - 2020-09-01 18:51:10 --> Security Class Initialized
DEBUG - 2020-09-01 18:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 18:51:10 --> Input Class Initialized
INFO - 2020-09-01 18:51:10 --> Language Class Initialized
INFO - 2020-09-01 18:51:10 --> Language Class Initialized
INFO - 2020-09-01 18:51:10 --> Config Class Initialized
INFO - 2020-09-01 18:51:10 --> Loader Class Initialized
INFO - 2020-09-01 18:51:10 --> Helper loaded: url_helper
INFO - 2020-09-01 18:51:10 --> Helper loaded: form_helper
INFO - 2020-09-01 18:51:10 --> Helper loaded: file_helper
INFO - 2020-09-01 18:51:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 18:51:10 --> Database Driver Class Initialized
DEBUG - 2020-09-01 18:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 18:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 18:51:10 --> Upload Class Initialized
INFO - 2020-09-01 18:51:10 --> Controller Class Initialized
DEBUG - 2020-09-01 18:51:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 18:51:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 18:51:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 18:51:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 18:51:10 --> Final output sent to browser
DEBUG - 2020-09-01 18:51:10 --> Total execution time: 0.0607
INFO - 2020-09-01 20:38:44 --> Config Class Initialized
INFO - 2020-09-01 20:38:44 --> Hooks Class Initialized
DEBUG - 2020-09-01 20:38:44 --> UTF-8 Support Enabled
INFO - 2020-09-01 20:38:44 --> Utf8 Class Initialized
INFO - 2020-09-01 20:38:44 --> URI Class Initialized
DEBUG - 2020-09-01 20:38:44 --> No URI present. Default controller set.
INFO - 2020-09-01 20:38:44 --> Router Class Initialized
INFO - 2020-09-01 20:38:44 --> Output Class Initialized
INFO - 2020-09-01 20:38:44 --> Security Class Initialized
DEBUG - 2020-09-01 20:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 20:38:44 --> Input Class Initialized
INFO - 2020-09-01 20:38:44 --> Language Class Initialized
INFO - 2020-09-01 20:38:44 --> Language Class Initialized
INFO - 2020-09-01 20:38:44 --> Config Class Initialized
INFO - 2020-09-01 20:38:44 --> Loader Class Initialized
INFO - 2020-09-01 20:38:44 --> Helper loaded: url_helper
INFO - 2020-09-01 20:38:44 --> Helper loaded: form_helper
INFO - 2020-09-01 20:38:44 --> Helper loaded: file_helper
INFO - 2020-09-01 20:38:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 20:38:44 --> Database Driver Class Initialized
DEBUG - 2020-09-01 20:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 20:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 20:38:44 --> Upload Class Initialized
INFO - 2020-09-01 20:38:44 --> Controller Class Initialized
DEBUG - 2020-09-01 20:38:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 20:38:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 20:38:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 20:38:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 20:38:44 --> Final output sent to browser
DEBUG - 2020-09-01 20:38:44 --> Total execution time: 0.0754
INFO - 2020-09-01 20:59:10 --> Config Class Initialized
INFO - 2020-09-01 20:59:10 --> Hooks Class Initialized
DEBUG - 2020-09-01 20:59:10 --> UTF-8 Support Enabled
INFO - 2020-09-01 20:59:10 --> Utf8 Class Initialized
INFO - 2020-09-01 20:59:10 --> URI Class Initialized
DEBUG - 2020-09-01 20:59:10 --> No URI present. Default controller set.
INFO - 2020-09-01 20:59:10 --> Router Class Initialized
INFO - 2020-09-01 20:59:10 --> Output Class Initialized
INFO - 2020-09-01 20:59:10 --> Security Class Initialized
DEBUG - 2020-09-01 20:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 20:59:10 --> Input Class Initialized
INFO - 2020-09-01 20:59:10 --> Language Class Initialized
INFO - 2020-09-01 20:59:10 --> Language Class Initialized
INFO - 2020-09-01 20:59:10 --> Config Class Initialized
INFO - 2020-09-01 20:59:10 --> Loader Class Initialized
INFO - 2020-09-01 20:59:10 --> Helper loaded: url_helper
INFO - 2020-09-01 20:59:10 --> Helper loaded: form_helper
INFO - 2020-09-01 20:59:10 --> Helper loaded: file_helper
INFO - 2020-09-01 20:59:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 20:59:10 --> Database Driver Class Initialized
DEBUG - 2020-09-01 20:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 20:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 20:59:10 --> Upload Class Initialized
INFO - 2020-09-01 20:59:10 --> Controller Class Initialized
DEBUG - 2020-09-01 20:59:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 20:59:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 20:59:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 20:59:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 20:59:10 --> Final output sent to browser
DEBUG - 2020-09-01 20:59:10 --> Total execution time: 0.0516
INFO - 2020-09-01 21:32:57 --> Config Class Initialized
INFO - 2020-09-01 21:32:57 --> Hooks Class Initialized
DEBUG - 2020-09-01 21:32:57 --> UTF-8 Support Enabled
INFO - 2020-09-01 21:32:57 --> Utf8 Class Initialized
INFO - 2020-09-01 21:32:57 --> URI Class Initialized
DEBUG - 2020-09-01 21:32:57 --> No URI present. Default controller set.
INFO - 2020-09-01 21:32:57 --> Router Class Initialized
INFO - 2020-09-01 21:32:57 --> Output Class Initialized
INFO - 2020-09-01 21:32:57 --> Security Class Initialized
DEBUG - 2020-09-01 21:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 21:32:57 --> Input Class Initialized
INFO - 2020-09-01 21:32:57 --> Language Class Initialized
INFO - 2020-09-01 21:32:57 --> Language Class Initialized
INFO - 2020-09-01 21:32:57 --> Config Class Initialized
INFO - 2020-09-01 21:32:57 --> Loader Class Initialized
INFO - 2020-09-01 21:32:57 --> Helper loaded: url_helper
INFO - 2020-09-01 21:32:57 --> Helper loaded: form_helper
INFO - 2020-09-01 21:32:57 --> Helper loaded: file_helper
INFO - 2020-09-01 21:32:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 21:32:57 --> Database Driver Class Initialized
DEBUG - 2020-09-01 21:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 21:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 21:32:57 --> Upload Class Initialized
INFO - 2020-09-01 21:32:57 --> Controller Class Initialized
DEBUG - 2020-09-01 21:32:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 21:32:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 21:32:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 21:32:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 21:32:57 --> Final output sent to browser
DEBUG - 2020-09-01 21:32:57 --> Total execution time: 0.0513
INFO - 2020-09-01 22:25:10 --> Config Class Initialized
INFO - 2020-09-01 22:25:10 --> Hooks Class Initialized
DEBUG - 2020-09-01 22:25:10 --> UTF-8 Support Enabled
INFO - 2020-09-01 22:25:10 --> Utf8 Class Initialized
INFO - 2020-09-01 22:25:10 --> URI Class Initialized
INFO - 2020-09-01 22:25:10 --> Router Class Initialized
INFO - 2020-09-01 22:25:10 --> Output Class Initialized
INFO - 2020-09-01 22:25:10 --> Security Class Initialized
DEBUG - 2020-09-01 22:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 22:25:10 --> Input Class Initialized
INFO - 2020-09-01 22:25:10 --> Language Class Initialized
INFO - 2020-09-01 22:25:10 --> Language Class Initialized
INFO - 2020-09-01 22:25:10 --> Config Class Initialized
INFO - 2020-09-01 22:25:10 --> Loader Class Initialized
INFO - 2020-09-01 22:25:10 --> Helper loaded: url_helper
INFO - 2020-09-01 22:25:10 --> Helper loaded: form_helper
INFO - 2020-09-01 22:25:10 --> Helper loaded: file_helper
INFO - 2020-09-01 22:25:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 22:25:10 --> Database Driver Class Initialized
DEBUG - 2020-09-01 22:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 22:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 22:25:10 --> Upload Class Initialized
INFO - 2020-09-01 22:25:10 --> Controller Class Initialized
ERROR - 2020-09-01 22:25:10 --> 404 Page Not Found: /index
INFO - 2020-09-01 22:35:48 --> Config Class Initialized
INFO - 2020-09-01 22:35:48 --> Hooks Class Initialized
DEBUG - 2020-09-01 22:35:48 --> UTF-8 Support Enabled
INFO - 2020-09-01 22:35:48 --> Utf8 Class Initialized
INFO - 2020-09-01 22:35:48 --> URI Class Initialized
DEBUG - 2020-09-01 22:35:48 --> No URI present. Default controller set.
INFO - 2020-09-01 22:35:48 --> Router Class Initialized
INFO - 2020-09-01 22:35:48 --> Output Class Initialized
INFO - 2020-09-01 22:35:48 --> Security Class Initialized
DEBUG - 2020-09-01 22:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 22:35:48 --> Input Class Initialized
INFO - 2020-09-01 22:35:48 --> Language Class Initialized
INFO - 2020-09-01 22:35:48 --> Language Class Initialized
INFO - 2020-09-01 22:35:48 --> Config Class Initialized
INFO - 2020-09-01 22:35:48 --> Loader Class Initialized
INFO - 2020-09-01 22:35:48 --> Helper loaded: url_helper
INFO - 2020-09-01 22:35:48 --> Helper loaded: form_helper
INFO - 2020-09-01 22:35:48 --> Helper loaded: file_helper
INFO - 2020-09-01 22:35:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-01 22:35:48 --> Database Driver Class Initialized
DEBUG - 2020-09-01 22:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-01 22:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 22:35:48 --> Upload Class Initialized
INFO - 2020-09-01 22:35:48 --> Controller Class Initialized
DEBUG - 2020-09-01 22:35:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-01 22:35:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-01 22:35:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-01 22:35:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-01 22:35:48 --> Final output sent to browser
DEBUG - 2020-09-01 22:35:48 --> Total execution time: 0.1554
