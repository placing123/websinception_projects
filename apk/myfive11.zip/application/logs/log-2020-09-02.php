<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-02 00:18:54 --> Config Class Initialized
INFO - 2020-09-02 00:18:54 --> Hooks Class Initialized
DEBUG - 2020-09-02 00:18:54 --> UTF-8 Support Enabled
INFO - 2020-09-02 00:18:54 --> Utf8 Class Initialized
INFO - 2020-09-02 00:18:54 --> URI Class Initialized
INFO - 2020-09-02 00:18:54 --> Router Class Initialized
INFO - 2020-09-02 00:18:54 --> Output Class Initialized
INFO - 2020-09-02 00:18:54 --> Security Class Initialized
DEBUG - 2020-09-02 00:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 00:18:54 --> Input Class Initialized
INFO - 2020-09-02 00:18:54 --> Language Class Initialized
INFO - 2020-09-02 00:18:54 --> Language Class Initialized
INFO - 2020-09-02 00:18:54 --> Config Class Initialized
INFO - 2020-09-02 00:18:54 --> Loader Class Initialized
INFO - 2020-09-02 00:18:54 --> Helper loaded: url_helper
INFO - 2020-09-02 00:18:54 --> Helper loaded: form_helper
INFO - 2020-09-02 00:18:54 --> Helper loaded: file_helper
INFO - 2020-09-02 00:18:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 00:18:54 --> Database Driver Class Initialized
DEBUG - 2020-09-02 00:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 00:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 00:18:54 --> Upload Class Initialized
INFO - 2020-09-02 00:18:54 --> Controller Class Initialized
ERROR - 2020-09-02 00:18:54 --> 404 Page Not Found: /index
INFO - 2020-09-02 00:26:14 --> Config Class Initialized
INFO - 2020-09-02 00:26:14 --> Hooks Class Initialized
DEBUG - 2020-09-02 00:26:14 --> UTF-8 Support Enabled
INFO - 2020-09-02 00:26:14 --> Utf8 Class Initialized
INFO - 2020-09-02 00:26:14 --> URI Class Initialized
INFO - 2020-09-02 00:26:14 --> Router Class Initialized
INFO - 2020-09-02 00:26:14 --> Output Class Initialized
INFO - 2020-09-02 00:26:14 --> Security Class Initialized
DEBUG - 2020-09-02 00:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 00:26:14 --> Input Class Initialized
INFO - 2020-09-02 00:26:14 --> Language Class Initialized
INFO - 2020-09-02 00:26:14 --> Language Class Initialized
INFO - 2020-09-02 00:26:14 --> Config Class Initialized
INFO - 2020-09-02 00:26:14 --> Loader Class Initialized
INFO - 2020-09-02 00:26:14 --> Helper loaded: url_helper
INFO - 2020-09-02 00:26:14 --> Helper loaded: form_helper
INFO - 2020-09-02 00:26:14 --> Helper loaded: file_helper
INFO - 2020-09-02 00:26:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 00:26:14 --> Database Driver Class Initialized
DEBUG - 2020-09-02 00:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 00:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 00:26:14 --> Upload Class Initialized
INFO - 2020-09-02 00:26:14 --> Controller Class Initialized
ERROR - 2020-09-02 00:26:14 --> 404 Page Not Found: /index
INFO - 2020-09-02 00:38:59 --> Config Class Initialized
INFO - 2020-09-02 00:38:59 --> Hooks Class Initialized
DEBUG - 2020-09-02 00:38:59 --> UTF-8 Support Enabled
INFO - 2020-09-02 00:38:59 --> Utf8 Class Initialized
INFO - 2020-09-02 00:38:59 --> URI Class Initialized
DEBUG - 2020-09-02 00:38:59 --> No URI present. Default controller set.
INFO - 2020-09-02 00:38:59 --> Router Class Initialized
INFO - 2020-09-02 00:38:59 --> Output Class Initialized
INFO - 2020-09-02 00:38:59 --> Security Class Initialized
DEBUG - 2020-09-02 00:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 00:38:59 --> Input Class Initialized
INFO - 2020-09-02 00:38:59 --> Language Class Initialized
INFO - 2020-09-02 00:38:59 --> Language Class Initialized
INFO - 2020-09-02 00:38:59 --> Config Class Initialized
INFO - 2020-09-02 00:38:59 --> Loader Class Initialized
INFO - 2020-09-02 00:38:59 --> Helper loaded: url_helper
INFO - 2020-09-02 00:38:59 --> Helper loaded: form_helper
INFO - 2020-09-02 00:38:59 --> Helper loaded: file_helper
INFO - 2020-09-02 00:38:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 00:38:59 --> Database Driver Class Initialized
DEBUG - 2020-09-02 00:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 00:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 00:38:59 --> Upload Class Initialized
INFO - 2020-09-02 00:38:59 --> Controller Class Initialized
DEBUG - 2020-09-02 00:38:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 00:38:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 00:38:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 00:38:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 00:38:59 --> Final output sent to browser
DEBUG - 2020-09-02 00:38:59 --> Total execution time: 0.1362
INFO - 2020-09-02 00:39:03 --> Config Class Initialized
INFO - 2020-09-02 00:39:03 --> Hooks Class Initialized
DEBUG - 2020-09-02 00:39:03 --> UTF-8 Support Enabled
INFO - 2020-09-02 00:39:03 --> Utf8 Class Initialized
INFO - 2020-09-02 00:39:03 --> URI Class Initialized
INFO - 2020-09-02 00:39:03 --> Router Class Initialized
INFO - 2020-09-02 00:39:03 --> Output Class Initialized
INFO - 2020-09-02 00:39:03 --> Security Class Initialized
DEBUG - 2020-09-02 00:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 00:39:03 --> Input Class Initialized
INFO - 2020-09-02 00:39:03 --> Language Class Initialized
INFO - 2020-09-02 00:39:03 --> Language Class Initialized
INFO - 2020-09-02 00:39:03 --> Config Class Initialized
INFO - 2020-09-02 00:39:03 --> Loader Class Initialized
INFO - 2020-09-02 00:39:03 --> Helper loaded: url_helper
INFO - 2020-09-02 00:39:03 --> Helper loaded: form_helper
INFO - 2020-09-02 00:39:03 --> Helper loaded: file_helper
INFO - 2020-09-02 00:39:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 00:39:03 --> Database Driver Class Initialized
DEBUG - 2020-09-02 00:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 00:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 00:39:04 --> Upload Class Initialized
INFO - 2020-09-02 00:39:04 --> Controller Class Initialized
ERROR - 2020-09-02 00:39:04 --> 404 Page Not Found: /index
INFO - 2020-09-02 01:37:37 --> Config Class Initialized
INFO - 2020-09-02 01:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-02 01:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-02 01:37:37 --> Utf8 Class Initialized
INFO - 2020-09-02 01:37:37 --> URI Class Initialized
DEBUG - 2020-09-02 01:37:37 --> No URI present. Default controller set.
INFO - 2020-09-02 01:37:37 --> Router Class Initialized
INFO - 2020-09-02 01:37:37 --> Output Class Initialized
INFO - 2020-09-02 01:37:37 --> Security Class Initialized
DEBUG - 2020-09-02 01:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 01:37:37 --> Input Class Initialized
INFO - 2020-09-02 01:37:37 --> Language Class Initialized
INFO - 2020-09-02 01:37:38 --> Language Class Initialized
INFO - 2020-09-02 01:37:38 --> Config Class Initialized
INFO - 2020-09-02 01:37:38 --> Loader Class Initialized
INFO - 2020-09-02 01:37:38 --> Helper loaded: url_helper
INFO - 2020-09-02 01:37:38 --> Helper loaded: form_helper
INFO - 2020-09-02 01:37:38 --> Helper loaded: file_helper
INFO - 2020-09-02 01:37:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 01:37:38 --> Database Driver Class Initialized
DEBUG - 2020-09-02 01:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 01:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 01:37:38 --> Upload Class Initialized
INFO - 2020-09-02 01:37:38 --> Controller Class Initialized
DEBUG - 2020-09-02 01:37:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 01:37:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 01:37:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 01:37:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 01:37:38 --> Final output sent to browser
DEBUG - 2020-09-02 01:37:38 --> Total execution time: 0.1372
INFO - 2020-09-02 02:56:08 --> Config Class Initialized
INFO - 2020-09-02 02:56:08 --> Hooks Class Initialized
DEBUG - 2020-09-02 02:56:08 --> UTF-8 Support Enabled
INFO - 2020-09-02 02:56:08 --> Utf8 Class Initialized
INFO - 2020-09-02 02:56:08 --> URI Class Initialized
DEBUG - 2020-09-02 02:56:08 --> No URI present. Default controller set.
INFO - 2020-09-02 02:56:08 --> Router Class Initialized
INFO - 2020-09-02 02:56:08 --> Output Class Initialized
INFO - 2020-09-02 02:56:08 --> Security Class Initialized
DEBUG - 2020-09-02 02:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 02:56:08 --> Input Class Initialized
INFO - 2020-09-02 02:56:08 --> Language Class Initialized
INFO - 2020-09-02 02:56:08 --> Language Class Initialized
INFO - 2020-09-02 02:56:08 --> Config Class Initialized
INFO - 2020-09-02 02:56:08 --> Loader Class Initialized
INFO - 2020-09-02 02:56:08 --> Helper loaded: url_helper
INFO - 2020-09-02 02:56:08 --> Helper loaded: form_helper
INFO - 2020-09-02 02:56:08 --> Helper loaded: file_helper
INFO - 2020-09-02 02:56:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 02:56:08 --> Database Driver Class Initialized
DEBUG - 2020-09-02 02:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 02:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 02:56:08 --> Upload Class Initialized
INFO - 2020-09-02 02:56:08 --> Controller Class Initialized
DEBUG - 2020-09-02 02:56:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 02:56:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 02:56:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 02:56:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 02:56:08 --> Final output sent to browser
DEBUG - 2020-09-02 02:56:08 --> Total execution time: 0.0508
INFO - 2020-09-02 07:31:40 --> Config Class Initialized
INFO - 2020-09-02 07:31:40 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:31:40 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:31:40 --> Utf8 Class Initialized
INFO - 2020-09-02 07:31:40 --> URI Class Initialized
DEBUG - 2020-09-02 07:31:40 --> No URI present. Default controller set.
INFO - 2020-09-02 07:31:40 --> Router Class Initialized
INFO - 2020-09-02 07:31:40 --> Output Class Initialized
INFO - 2020-09-02 07:31:40 --> Security Class Initialized
DEBUG - 2020-09-02 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:31:40 --> Input Class Initialized
INFO - 2020-09-02 07:31:40 --> Language Class Initialized
INFO - 2020-09-02 07:31:40 --> Language Class Initialized
INFO - 2020-09-02 07:31:40 --> Config Class Initialized
INFO - 2020-09-02 07:31:40 --> Loader Class Initialized
INFO - 2020-09-02 07:31:40 --> Helper loaded: url_helper
INFO - 2020-09-02 07:31:40 --> Helper loaded: form_helper
INFO - 2020-09-02 07:31:40 --> Helper loaded: file_helper
INFO - 2020-09-02 07:31:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 07:31:40 --> Database Driver Class Initialized
DEBUG - 2020-09-02 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:31:40 --> Upload Class Initialized
INFO - 2020-09-02 07:31:40 --> Controller Class Initialized
DEBUG - 2020-09-02 07:31:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 07:31:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 07:31:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 07:31:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 07:31:40 --> Final output sent to browser
DEBUG - 2020-09-02 07:31:40 --> Total execution time: 0.0540
INFO - 2020-09-02 09:16:17 --> Config Class Initialized
INFO - 2020-09-02 09:16:17 --> Hooks Class Initialized
DEBUG - 2020-09-02 09:16:17 --> UTF-8 Support Enabled
INFO - 2020-09-02 09:16:17 --> Utf8 Class Initialized
INFO - 2020-09-02 09:16:17 --> URI Class Initialized
DEBUG - 2020-09-02 09:16:17 --> No URI present. Default controller set.
INFO - 2020-09-02 09:16:17 --> Router Class Initialized
INFO - 2020-09-02 09:16:17 --> Output Class Initialized
INFO - 2020-09-02 09:16:17 --> Security Class Initialized
DEBUG - 2020-09-02 09:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 09:16:17 --> Input Class Initialized
INFO - 2020-09-02 09:16:17 --> Language Class Initialized
INFO - 2020-09-02 09:16:17 --> Language Class Initialized
INFO - 2020-09-02 09:16:17 --> Config Class Initialized
INFO - 2020-09-02 09:16:17 --> Loader Class Initialized
INFO - 2020-09-02 09:16:17 --> Helper loaded: url_helper
INFO - 2020-09-02 09:16:17 --> Helper loaded: form_helper
INFO - 2020-09-02 09:16:17 --> Helper loaded: file_helper
INFO - 2020-09-02 09:16:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 09:16:17 --> Database Driver Class Initialized
DEBUG - 2020-09-02 09:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 09:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 09:16:17 --> Upload Class Initialized
INFO - 2020-09-02 09:16:17 --> Controller Class Initialized
DEBUG - 2020-09-02 09:16:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 09:16:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 09:16:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 09:16:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 09:16:17 --> Final output sent to browser
DEBUG - 2020-09-02 09:16:17 --> Total execution time: 0.1721
INFO - 2020-09-02 10:07:43 --> Config Class Initialized
INFO - 2020-09-02 10:07:43 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:07:43 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:07:43 --> Utf8 Class Initialized
INFO - 2020-09-02 10:07:43 --> URI Class Initialized
DEBUG - 2020-09-02 10:07:43 --> No URI present. Default controller set.
INFO - 2020-09-02 10:07:43 --> Router Class Initialized
INFO - 2020-09-02 10:07:43 --> Output Class Initialized
INFO - 2020-09-02 10:07:43 --> Security Class Initialized
DEBUG - 2020-09-02 10:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:07:43 --> Input Class Initialized
INFO - 2020-09-02 10:07:43 --> Language Class Initialized
INFO - 2020-09-02 10:07:43 --> Language Class Initialized
INFO - 2020-09-02 10:07:43 --> Config Class Initialized
INFO - 2020-09-02 10:07:43 --> Loader Class Initialized
INFO - 2020-09-02 10:07:43 --> Helper loaded: url_helper
INFO - 2020-09-02 10:07:43 --> Helper loaded: form_helper
INFO - 2020-09-02 10:07:43 --> Helper loaded: file_helper
INFO - 2020-09-02 10:07:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:07:43 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:07:43 --> Upload Class Initialized
INFO - 2020-09-02 10:07:43 --> Controller Class Initialized
DEBUG - 2020-09-02 10:07:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 10:07:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 10:07:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 10:07:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 10:07:43 --> Final output sent to browser
DEBUG - 2020-09-02 10:07:43 --> Total execution time: 0.0735
INFO - 2020-09-02 10:07:43 --> Config Class Initialized
INFO - 2020-09-02 10:07:43 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:07:43 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:07:43 --> Utf8 Class Initialized
INFO - 2020-09-02 10:07:43 --> URI Class Initialized
DEBUG - 2020-09-02 10:07:43 --> No URI present. Default controller set.
INFO - 2020-09-02 10:07:43 --> Router Class Initialized
INFO - 2020-09-02 10:07:43 --> Output Class Initialized
INFO - 2020-09-02 10:07:43 --> Security Class Initialized
DEBUG - 2020-09-02 10:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:07:43 --> Input Class Initialized
INFO - 2020-09-02 10:07:43 --> Language Class Initialized
INFO - 2020-09-02 10:07:43 --> Language Class Initialized
INFO - 2020-09-02 10:07:43 --> Config Class Initialized
INFO - 2020-09-02 10:07:43 --> Loader Class Initialized
INFO - 2020-09-02 10:07:43 --> Helper loaded: url_helper
INFO - 2020-09-02 10:07:43 --> Helper loaded: form_helper
INFO - 2020-09-02 10:07:43 --> Helper loaded: file_helper
INFO - 2020-09-02 10:07:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:07:43 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:07:43 --> Upload Class Initialized
INFO - 2020-09-02 10:07:43 --> Controller Class Initialized
DEBUG - 2020-09-02 10:07:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 10:07:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 10:07:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 10:07:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 10:07:43 --> Final output sent to browser
DEBUG - 2020-09-02 10:07:43 --> Total execution time: 0.0737
INFO - 2020-09-02 10:39:44 --> Config Class Initialized
INFO - 2020-09-02 10:39:44 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:39:44 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:39:44 --> Utf8 Class Initialized
INFO - 2020-09-02 10:39:44 --> URI Class Initialized
INFO - 2020-09-02 10:39:44 --> Router Class Initialized
INFO - 2020-09-02 10:39:44 --> Output Class Initialized
INFO - 2020-09-02 10:39:44 --> Security Class Initialized
DEBUG - 2020-09-02 10:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:39:44 --> Input Class Initialized
INFO - 2020-09-02 10:39:44 --> Language Class Initialized
INFO - 2020-09-02 10:39:44 --> Language Class Initialized
INFO - 2020-09-02 10:39:44 --> Config Class Initialized
INFO - 2020-09-02 10:39:44 --> Loader Class Initialized
INFO - 2020-09-02 10:39:44 --> Helper loaded: url_helper
INFO - 2020-09-02 10:39:44 --> Helper loaded: form_helper
INFO - 2020-09-02 10:39:44 --> Helper loaded: file_helper
INFO - 2020-09-02 10:39:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:39:44 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:39:44 --> Upload Class Initialized
INFO - 2020-09-02 10:39:44 --> Controller Class Initialized
ERROR - 2020-09-02 10:39:44 --> 404 Page Not Found: /index
INFO - 2020-09-02 10:39:44 --> Config Class Initialized
INFO - 2020-09-02 10:39:44 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:39:44 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:39:44 --> Utf8 Class Initialized
INFO - 2020-09-02 10:39:44 --> URI Class Initialized
INFO - 2020-09-02 10:39:44 --> Router Class Initialized
INFO - 2020-09-02 10:39:44 --> Output Class Initialized
INFO - 2020-09-02 10:39:44 --> Security Class Initialized
DEBUG - 2020-09-02 10:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:39:44 --> Input Class Initialized
INFO - 2020-09-02 10:39:44 --> Language Class Initialized
INFO - 2020-09-02 10:39:44 --> Language Class Initialized
INFO - 2020-09-02 10:39:44 --> Config Class Initialized
INFO - 2020-09-02 10:39:44 --> Loader Class Initialized
INFO - 2020-09-02 10:39:44 --> Helper loaded: url_helper
INFO - 2020-09-02 10:39:44 --> Helper loaded: form_helper
INFO - 2020-09-02 10:39:44 --> Helper loaded: file_helper
INFO - 2020-09-02 10:39:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:39:44 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:39:44 --> Upload Class Initialized
INFO - 2020-09-02 10:39:44 --> Controller Class Initialized
ERROR - 2020-09-02 10:39:44 --> 404 Page Not Found: /index
INFO - 2020-09-02 10:39:45 --> Config Class Initialized
INFO - 2020-09-02 10:39:45 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:39:45 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:39:45 --> Utf8 Class Initialized
INFO - 2020-09-02 10:39:45 --> URI Class Initialized
INFO - 2020-09-02 10:39:45 --> Router Class Initialized
INFO - 2020-09-02 10:39:45 --> Output Class Initialized
INFO - 2020-09-02 10:39:45 --> Security Class Initialized
DEBUG - 2020-09-02 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:39:45 --> Input Class Initialized
INFO - 2020-09-02 10:39:45 --> Language Class Initialized
INFO - 2020-09-02 10:39:45 --> Language Class Initialized
INFO - 2020-09-02 10:39:45 --> Config Class Initialized
INFO - 2020-09-02 10:39:45 --> Loader Class Initialized
INFO - 2020-09-02 10:39:45 --> Helper loaded: url_helper
INFO - 2020-09-02 10:39:45 --> Helper loaded: form_helper
INFO - 2020-09-02 10:39:45 --> Helper loaded: file_helper
INFO - 2020-09-02 10:39:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:39:45 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:39:45 --> Upload Class Initialized
INFO - 2020-09-02 10:39:45 --> Controller Class Initialized
ERROR - 2020-09-02 10:39:45 --> 404 Page Not Found: /index
INFO - 2020-09-02 10:39:45 --> Config Class Initialized
INFO - 2020-09-02 10:39:45 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:39:45 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:39:45 --> Utf8 Class Initialized
INFO - 2020-09-02 10:39:45 --> URI Class Initialized
INFO - 2020-09-02 10:39:45 --> Router Class Initialized
INFO - 2020-09-02 10:39:45 --> Output Class Initialized
INFO - 2020-09-02 10:39:45 --> Security Class Initialized
DEBUG - 2020-09-02 10:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:39:45 --> Input Class Initialized
INFO - 2020-09-02 10:39:45 --> Language Class Initialized
INFO - 2020-09-02 10:39:45 --> Language Class Initialized
INFO - 2020-09-02 10:39:45 --> Config Class Initialized
INFO - 2020-09-02 10:39:45 --> Loader Class Initialized
INFO - 2020-09-02 10:39:45 --> Helper loaded: url_helper
INFO - 2020-09-02 10:39:45 --> Helper loaded: form_helper
INFO - 2020-09-02 10:39:45 --> Helper loaded: file_helper
INFO - 2020-09-02 10:39:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:39:45 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:39:45 --> Upload Class Initialized
INFO - 2020-09-02 10:39:45 --> Controller Class Initialized
ERROR - 2020-09-02 10:39:45 --> 404 Page Not Found: /index
INFO - 2020-09-02 10:39:46 --> Config Class Initialized
INFO - 2020-09-02 10:39:46 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:39:46 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:39:46 --> Utf8 Class Initialized
INFO - 2020-09-02 10:39:46 --> URI Class Initialized
INFO - 2020-09-02 10:39:46 --> Router Class Initialized
INFO - 2020-09-02 10:39:46 --> Output Class Initialized
INFO - 2020-09-02 10:39:46 --> Security Class Initialized
DEBUG - 2020-09-02 10:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:39:46 --> Input Class Initialized
INFO - 2020-09-02 10:39:46 --> Language Class Initialized
INFO - 2020-09-02 10:39:46 --> Language Class Initialized
INFO - 2020-09-02 10:39:46 --> Config Class Initialized
INFO - 2020-09-02 10:39:46 --> Loader Class Initialized
INFO - 2020-09-02 10:39:46 --> Helper loaded: url_helper
INFO - 2020-09-02 10:39:46 --> Helper loaded: form_helper
INFO - 2020-09-02 10:39:46 --> Helper loaded: file_helper
INFO - 2020-09-02 10:39:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:39:46 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:39:46 --> Upload Class Initialized
INFO - 2020-09-02 10:39:46 --> Controller Class Initialized
ERROR - 2020-09-02 10:39:46 --> 404 Page Not Found: /index
INFO - 2020-09-02 10:39:47 --> Config Class Initialized
INFO - 2020-09-02 10:39:47 --> Hooks Class Initialized
DEBUG - 2020-09-02 10:39:47 --> UTF-8 Support Enabled
INFO - 2020-09-02 10:39:47 --> Utf8 Class Initialized
INFO - 2020-09-02 10:39:47 --> URI Class Initialized
INFO - 2020-09-02 10:39:47 --> Router Class Initialized
INFO - 2020-09-02 10:39:47 --> Output Class Initialized
INFO - 2020-09-02 10:39:47 --> Security Class Initialized
DEBUG - 2020-09-02 10:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 10:39:47 --> Input Class Initialized
INFO - 2020-09-02 10:39:47 --> Language Class Initialized
INFO - 2020-09-02 10:39:47 --> Language Class Initialized
INFO - 2020-09-02 10:39:47 --> Config Class Initialized
INFO - 2020-09-02 10:39:47 --> Loader Class Initialized
INFO - 2020-09-02 10:39:47 --> Helper loaded: url_helper
INFO - 2020-09-02 10:39:47 --> Helper loaded: form_helper
INFO - 2020-09-02 10:39:47 --> Helper loaded: file_helper
INFO - 2020-09-02 10:39:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 10:39:47 --> Database Driver Class Initialized
DEBUG - 2020-09-02 10:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 10:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 10:39:47 --> Upload Class Initialized
INFO - 2020-09-02 10:39:47 --> Controller Class Initialized
ERROR - 2020-09-02 10:39:47 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:01:39 --> Config Class Initialized
INFO - 2020-09-02 11:01:39 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:01:39 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:01:39 --> Utf8 Class Initialized
INFO - 2020-09-02 11:01:39 --> URI Class Initialized
INFO - 2020-09-02 11:01:39 --> Router Class Initialized
INFO - 2020-09-02 11:01:39 --> Output Class Initialized
INFO - 2020-09-02 11:01:39 --> Security Class Initialized
DEBUG - 2020-09-02 11:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:01:39 --> Input Class Initialized
INFO - 2020-09-02 11:01:39 --> Language Class Initialized
INFO - 2020-09-02 11:01:39 --> Language Class Initialized
INFO - 2020-09-02 11:01:39 --> Config Class Initialized
INFO - 2020-09-02 11:01:39 --> Loader Class Initialized
INFO - 2020-09-02 11:01:39 --> Helper loaded: url_helper
INFO - 2020-09-02 11:01:39 --> Helper loaded: form_helper
INFO - 2020-09-02 11:01:39 --> Helper loaded: file_helper
INFO - 2020-09-02 11:01:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:01:39 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:01:39 --> Upload Class Initialized
INFO - 2020-09-02 11:01:39 --> Controller Class Initialized
ERROR - 2020-09-02 11:01:39 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:15:15 --> Config Class Initialized
INFO - 2020-09-02 11:15:15 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:15:15 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:15:15 --> Utf8 Class Initialized
INFO - 2020-09-02 11:15:15 --> URI Class Initialized
DEBUG - 2020-09-02 11:15:15 --> No URI present. Default controller set.
INFO - 2020-09-02 11:15:15 --> Router Class Initialized
INFO - 2020-09-02 11:15:15 --> Output Class Initialized
INFO - 2020-09-02 11:15:15 --> Security Class Initialized
DEBUG - 2020-09-02 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:15:15 --> Input Class Initialized
INFO - 2020-09-02 11:15:15 --> Language Class Initialized
INFO - 2020-09-02 11:15:15 --> Language Class Initialized
INFO - 2020-09-02 11:15:15 --> Config Class Initialized
INFO - 2020-09-02 11:15:15 --> Loader Class Initialized
INFO - 2020-09-02 11:15:15 --> Helper loaded: url_helper
INFO - 2020-09-02 11:15:15 --> Helper loaded: form_helper
INFO - 2020-09-02 11:15:15 --> Helper loaded: file_helper
INFO - 2020-09-02 11:15:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:15:15 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:15:15 --> Upload Class Initialized
INFO - 2020-09-02 11:15:15 --> Controller Class Initialized
DEBUG - 2020-09-02 11:15:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:15:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:15:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:15:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:15:15 --> Final output sent to browser
DEBUG - 2020-09-02 11:15:15 --> Total execution time: 0.1021
INFO - 2020-09-02 11:15:25 --> Config Class Initialized
INFO - 2020-09-02 11:15:25 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:15:25 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:15:25 --> Utf8 Class Initialized
INFO - 2020-09-02 11:15:25 --> URI Class Initialized
INFO - 2020-09-02 11:15:25 --> Router Class Initialized
INFO - 2020-09-02 11:15:25 --> Output Class Initialized
INFO - 2020-09-02 11:15:25 --> Security Class Initialized
DEBUG - 2020-09-02 11:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:15:25 --> Input Class Initialized
INFO - 2020-09-02 11:15:25 --> Language Class Initialized
INFO - 2020-09-02 11:15:25 --> Language Class Initialized
INFO - 2020-09-02 11:15:25 --> Config Class Initialized
INFO - 2020-09-02 11:15:25 --> Loader Class Initialized
INFO - 2020-09-02 11:15:25 --> Helper loaded: url_helper
INFO - 2020-09-02 11:15:25 --> Helper loaded: form_helper
INFO - 2020-09-02 11:15:25 --> Helper loaded: file_helper
INFO - 2020-09-02 11:15:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:15:26 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:15:26 --> Upload Class Initialized
INFO - 2020-09-02 11:15:26 --> Controller Class Initialized
ERROR - 2020-09-02 11:15:26 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:16:08 --> Config Class Initialized
INFO - 2020-09-02 11:16:08 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:16:08 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:16:08 --> Utf8 Class Initialized
INFO - 2020-09-02 11:16:08 --> URI Class Initialized
INFO - 2020-09-02 11:16:08 --> Router Class Initialized
INFO - 2020-09-02 11:16:08 --> Output Class Initialized
INFO - 2020-09-02 11:16:08 --> Security Class Initialized
DEBUG - 2020-09-02 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:16:08 --> Input Class Initialized
INFO - 2020-09-02 11:16:08 --> Language Class Initialized
INFO - 2020-09-02 11:16:08 --> Language Class Initialized
INFO - 2020-09-02 11:16:08 --> Config Class Initialized
INFO - 2020-09-02 11:16:08 --> Loader Class Initialized
INFO - 2020-09-02 11:16:08 --> Helper loaded: url_helper
INFO - 2020-09-02 11:16:08 --> Helper loaded: form_helper
INFO - 2020-09-02 11:16:08 --> Helper loaded: file_helper
INFO - 2020-09-02 11:16:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:16:08 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:16:08 --> Upload Class Initialized
INFO - 2020-09-02 11:16:08 --> Controller Class Initialized
DEBUG - 2020-09-02 11:16:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:16:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-02 11:16:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:16:08 --> Final output sent to browser
DEBUG - 2020-09-02 11:16:08 --> Total execution time: 0.0647
INFO - 2020-09-02 11:16:09 --> Config Class Initialized
INFO - 2020-09-02 11:16:09 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:16:09 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:16:09 --> Utf8 Class Initialized
INFO - 2020-09-02 11:16:09 --> URI Class Initialized
INFO - 2020-09-02 11:16:09 --> Router Class Initialized
INFO - 2020-09-02 11:16:09 --> Output Class Initialized
INFO - 2020-09-02 11:16:09 --> Security Class Initialized
DEBUG - 2020-09-02 11:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:16:09 --> Input Class Initialized
INFO - 2020-09-02 11:16:09 --> Language Class Initialized
INFO - 2020-09-02 11:16:09 --> Language Class Initialized
INFO - 2020-09-02 11:16:09 --> Config Class Initialized
INFO - 2020-09-02 11:16:09 --> Loader Class Initialized
INFO - 2020-09-02 11:16:09 --> Helper loaded: url_helper
INFO - 2020-09-02 11:16:09 --> Helper loaded: form_helper
INFO - 2020-09-02 11:16:09 --> Helper loaded: file_helper
INFO - 2020-09-02 11:16:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:16:09 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:16:09 --> Upload Class Initialized
INFO - 2020-09-02 11:16:09 --> Controller Class Initialized
ERROR - 2020-09-02 11:16:09 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:19:22 --> Config Class Initialized
INFO - 2020-09-02 11:19:22 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:19:22 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:19:22 --> Utf8 Class Initialized
INFO - 2020-09-02 11:19:22 --> URI Class Initialized
DEBUG - 2020-09-02 11:19:22 --> No URI present. Default controller set.
INFO - 2020-09-02 11:19:22 --> Router Class Initialized
INFO - 2020-09-02 11:19:22 --> Output Class Initialized
INFO - 2020-09-02 11:19:22 --> Security Class Initialized
DEBUG - 2020-09-02 11:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:19:22 --> Input Class Initialized
INFO - 2020-09-02 11:19:22 --> Language Class Initialized
INFO - 2020-09-02 11:19:22 --> Language Class Initialized
INFO - 2020-09-02 11:19:22 --> Config Class Initialized
INFO - 2020-09-02 11:19:22 --> Loader Class Initialized
INFO - 2020-09-02 11:19:22 --> Helper loaded: url_helper
INFO - 2020-09-02 11:19:22 --> Helper loaded: form_helper
INFO - 2020-09-02 11:19:22 --> Helper loaded: file_helper
INFO - 2020-09-02 11:19:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:19:22 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:19:22 --> Upload Class Initialized
INFO - 2020-09-02 11:19:22 --> Controller Class Initialized
DEBUG - 2020-09-02 11:19:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:19:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:19:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:19:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:19:22 --> Final output sent to browser
DEBUG - 2020-09-02 11:19:22 --> Total execution time: 0.0501
INFO - 2020-09-02 11:19:25 --> Config Class Initialized
INFO - 2020-09-02 11:19:25 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:19:25 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:19:25 --> Utf8 Class Initialized
INFO - 2020-09-02 11:19:25 --> URI Class Initialized
INFO - 2020-09-02 11:19:25 --> Router Class Initialized
INFO - 2020-09-02 11:19:25 --> Output Class Initialized
INFO - 2020-09-02 11:19:25 --> Security Class Initialized
DEBUG - 2020-09-02 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:19:25 --> Input Class Initialized
INFO - 2020-09-02 11:19:25 --> Language Class Initialized
INFO - 2020-09-02 11:19:25 --> Language Class Initialized
INFO - 2020-09-02 11:19:25 --> Config Class Initialized
INFO - 2020-09-02 11:19:25 --> Loader Class Initialized
INFO - 2020-09-02 11:19:25 --> Helper loaded: url_helper
INFO - 2020-09-02 11:19:25 --> Helper loaded: form_helper
INFO - 2020-09-02 11:19:25 --> Helper loaded: file_helper
INFO - 2020-09-02 11:19:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:19:25 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:19:25 --> Upload Class Initialized
INFO - 2020-09-02 11:19:25 --> Controller Class Initialized
DEBUG - 2020-09-02 11:19:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:19:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-02 11:19:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:19:25 --> Final output sent to browser
DEBUG - 2020-09-02 11:19:25 --> Total execution time: 0.0692
INFO - 2020-09-02 11:20:23 --> Config Class Initialized
INFO - 2020-09-02 11:20:23 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:20:23 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:20:23 --> Utf8 Class Initialized
INFO - 2020-09-02 11:20:23 --> URI Class Initialized
INFO - 2020-09-02 11:20:23 --> Router Class Initialized
INFO - 2020-09-02 11:20:23 --> Output Class Initialized
INFO - 2020-09-02 11:20:23 --> Security Class Initialized
DEBUG - 2020-09-02 11:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:20:23 --> Input Class Initialized
INFO - 2020-09-02 11:20:23 --> Language Class Initialized
INFO - 2020-09-02 11:20:23 --> Language Class Initialized
INFO - 2020-09-02 11:20:23 --> Config Class Initialized
INFO - 2020-09-02 11:20:23 --> Loader Class Initialized
INFO - 2020-09-02 11:20:23 --> Helper loaded: url_helper
INFO - 2020-09-02 11:20:23 --> Helper loaded: form_helper
INFO - 2020-09-02 11:20:23 --> Helper loaded: file_helper
INFO - 2020-09-02 11:20:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:20:23 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:20:23 --> Upload Class Initialized
INFO - 2020-09-02 11:20:23 --> Controller Class Initialized
DEBUG - 2020-09-02 11:20:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:20:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-02 11:20:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:20:23 --> Final output sent to browser
DEBUG - 2020-09-02 11:20:23 --> Total execution time: 0.0610
INFO - 2020-09-02 11:21:51 --> Config Class Initialized
INFO - 2020-09-02 11:21:51 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:21:51 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:21:51 --> Utf8 Class Initialized
INFO - 2020-09-02 11:21:51 --> URI Class Initialized
INFO - 2020-09-02 11:21:51 --> Router Class Initialized
INFO - 2020-09-02 11:21:51 --> Output Class Initialized
INFO - 2020-09-02 11:21:51 --> Security Class Initialized
DEBUG - 2020-09-02 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:21:51 --> Input Class Initialized
INFO - 2020-09-02 11:21:51 --> Language Class Initialized
INFO - 2020-09-02 11:21:51 --> Language Class Initialized
INFO - 2020-09-02 11:21:51 --> Config Class Initialized
INFO - 2020-09-02 11:21:51 --> Loader Class Initialized
INFO - 2020-09-02 11:21:51 --> Helper loaded: url_helper
INFO - 2020-09-02 11:21:51 --> Helper loaded: form_helper
INFO - 2020-09-02 11:21:51 --> Helper loaded: file_helper
INFO - 2020-09-02 11:21:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:21:51 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:21:51 --> Upload Class Initialized
INFO - 2020-09-02 11:21:51 --> Controller Class Initialized
DEBUG - 2020-09-02 11:21:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:21:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-02 11:21:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:21:51 --> Final output sent to browser
DEBUG - 2020-09-02 11:21:51 --> Total execution time: 0.0555
INFO - 2020-09-02 11:24:49 --> Config Class Initialized
INFO - 2020-09-02 11:24:49 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:24:49 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:24:49 --> Utf8 Class Initialized
INFO - 2020-09-02 11:24:49 --> URI Class Initialized
INFO - 2020-09-02 11:24:49 --> Router Class Initialized
INFO - 2020-09-02 11:24:49 --> Output Class Initialized
INFO - 2020-09-02 11:24:49 --> Security Class Initialized
DEBUG - 2020-09-02 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:24:49 --> Input Class Initialized
INFO - 2020-09-02 11:24:49 --> Language Class Initialized
INFO - 2020-09-02 11:24:49 --> Language Class Initialized
INFO - 2020-09-02 11:24:49 --> Config Class Initialized
INFO - 2020-09-02 11:24:49 --> Loader Class Initialized
INFO - 2020-09-02 11:24:49 --> Helper loaded: url_helper
INFO - 2020-09-02 11:24:49 --> Helper loaded: form_helper
INFO - 2020-09-02 11:24:49 --> Helper loaded: file_helper
INFO - 2020-09-02 11:24:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:24:49 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:24:49 --> Upload Class Initialized
INFO - 2020-09-02 11:24:49 --> Controller Class Initialized
DEBUG - 2020-09-02 11:24:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:24:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-02 11:24:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:24:49 --> Final output sent to browser
DEBUG - 2020-09-02 11:24:49 --> Total execution time: 0.0649
INFO - 2020-09-02 11:24:59 --> Config Class Initialized
INFO - 2020-09-02 11:24:59 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:24:59 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:24:59 --> Utf8 Class Initialized
INFO - 2020-09-02 11:24:59 --> URI Class Initialized
INFO - 2020-09-02 11:24:59 --> Router Class Initialized
INFO - 2020-09-02 11:24:59 --> Output Class Initialized
INFO - 2020-09-02 11:24:59 --> Security Class Initialized
DEBUG - 2020-09-02 11:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:24:59 --> Input Class Initialized
INFO - 2020-09-02 11:24:59 --> Language Class Initialized
INFO - 2020-09-02 11:24:59 --> Language Class Initialized
INFO - 2020-09-02 11:24:59 --> Config Class Initialized
INFO - 2020-09-02 11:24:59 --> Loader Class Initialized
INFO - 2020-09-02 11:24:59 --> Helper loaded: url_helper
INFO - 2020-09-02 11:24:59 --> Helper loaded: form_helper
INFO - 2020-09-02 11:24:59 --> Helper loaded: file_helper
INFO - 2020-09-02 11:24:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:24:59 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:24:59 --> Upload Class Initialized
INFO - 2020-09-02 11:24:59 --> Controller Class Initialized
DEBUG - 2020-09-02 11:24:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:24:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-02 11:24:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:24:59 --> Final output sent to browser
DEBUG - 2020-09-02 11:24:59 --> Total execution time: 0.0537
INFO - 2020-09-02 11:27:55 --> Config Class Initialized
INFO - 2020-09-02 11:27:55 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:27:55 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:27:55 --> Utf8 Class Initialized
INFO - 2020-09-02 11:27:55 --> URI Class Initialized
DEBUG - 2020-09-02 11:27:55 --> No URI present. Default controller set.
INFO - 2020-09-02 11:27:55 --> Router Class Initialized
INFO - 2020-09-02 11:27:55 --> Output Class Initialized
INFO - 2020-09-02 11:27:55 --> Security Class Initialized
DEBUG - 2020-09-02 11:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:27:55 --> Input Class Initialized
INFO - 2020-09-02 11:27:55 --> Language Class Initialized
INFO - 2020-09-02 11:27:55 --> Language Class Initialized
INFO - 2020-09-02 11:27:55 --> Config Class Initialized
INFO - 2020-09-02 11:27:55 --> Loader Class Initialized
INFO - 2020-09-02 11:27:55 --> Helper loaded: url_helper
INFO - 2020-09-02 11:27:55 --> Helper loaded: form_helper
INFO - 2020-09-02 11:27:55 --> Helper loaded: file_helper
INFO - 2020-09-02 11:27:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:27:55 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:27:55 --> Upload Class Initialized
INFO - 2020-09-02 11:27:55 --> Controller Class Initialized
DEBUG - 2020-09-02 11:27:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:27:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:27:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:27:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:27:55 --> Final output sent to browser
DEBUG - 2020-09-02 11:27:55 --> Total execution time: 0.0517
INFO - 2020-09-02 11:28:01 --> Config Class Initialized
INFO - 2020-09-02 11:28:01 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:28:01 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:28:01 --> Utf8 Class Initialized
INFO - 2020-09-02 11:28:01 --> URI Class Initialized
INFO - 2020-09-02 11:28:01 --> Router Class Initialized
INFO - 2020-09-02 11:28:01 --> Output Class Initialized
INFO - 2020-09-02 11:28:01 --> Security Class Initialized
DEBUG - 2020-09-02 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:28:01 --> Input Class Initialized
INFO - 2020-09-02 11:28:01 --> Language Class Initialized
INFO - 2020-09-02 11:28:01 --> Language Class Initialized
INFO - 2020-09-02 11:28:01 --> Config Class Initialized
INFO - 2020-09-02 11:28:01 --> Loader Class Initialized
INFO - 2020-09-02 11:28:01 --> Helper loaded: url_helper
INFO - 2020-09-02 11:28:01 --> Helper loaded: form_helper
INFO - 2020-09-02 11:28:01 --> Helper loaded: file_helper
INFO - 2020-09-02 11:28:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:28:01 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:28:01 --> Upload Class Initialized
INFO - 2020-09-02 11:28:01 --> Controller Class Initialized
ERROR - 2020-09-02 11:28:01 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:30:34 --> Config Class Initialized
INFO - 2020-09-02 11:30:34 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:30:34 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:30:34 --> Utf8 Class Initialized
INFO - 2020-09-02 11:30:34 --> URI Class Initialized
DEBUG - 2020-09-02 11:30:34 --> No URI present. Default controller set.
INFO - 2020-09-02 11:30:34 --> Router Class Initialized
INFO - 2020-09-02 11:30:34 --> Output Class Initialized
INFO - 2020-09-02 11:30:34 --> Security Class Initialized
DEBUG - 2020-09-02 11:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:30:34 --> Input Class Initialized
INFO - 2020-09-02 11:30:34 --> Language Class Initialized
INFO - 2020-09-02 11:30:34 --> Language Class Initialized
INFO - 2020-09-02 11:30:34 --> Config Class Initialized
INFO - 2020-09-02 11:30:34 --> Loader Class Initialized
INFO - 2020-09-02 11:30:34 --> Helper loaded: url_helper
INFO - 2020-09-02 11:30:34 --> Helper loaded: form_helper
INFO - 2020-09-02 11:30:34 --> Helper loaded: file_helper
INFO - 2020-09-02 11:30:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:30:34 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:30:34 --> Upload Class Initialized
INFO - 2020-09-02 11:30:34 --> Controller Class Initialized
DEBUG - 2020-09-02 11:30:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:30:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:30:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:30:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:30:34 --> Final output sent to browser
DEBUG - 2020-09-02 11:30:34 --> Total execution time: 0.0562
INFO - 2020-09-02 11:33:21 --> Config Class Initialized
INFO - 2020-09-02 11:33:21 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:33:21 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:33:21 --> Utf8 Class Initialized
INFO - 2020-09-02 11:33:21 --> URI Class Initialized
DEBUG - 2020-09-02 11:33:21 --> No URI present. Default controller set.
INFO - 2020-09-02 11:33:21 --> Router Class Initialized
INFO - 2020-09-02 11:33:21 --> Output Class Initialized
INFO - 2020-09-02 11:33:21 --> Security Class Initialized
DEBUG - 2020-09-02 11:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:33:21 --> Input Class Initialized
INFO - 2020-09-02 11:33:21 --> Language Class Initialized
INFO - 2020-09-02 11:33:21 --> Language Class Initialized
INFO - 2020-09-02 11:33:21 --> Config Class Initialized
INFO - 2020-09-02 11:33:21 --> Loader Class Initialized
INFO - 2020-09-02 11:33:21 --> Helper loaded: url_helper
INFO - 2020-09-02 11:33:21 --> Helper loaded: form_helper
INFO - 2020-09-02 11:33:21 --> Helper loaded: file_helper
INFO - 2020-09-02 11:33:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:33:21 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:33:21 --> Upload Class Initialized
INFO - 2020-09-02 11:33:21 --> Controller Class Initialized
DEBUG - 2020-09-02 11:33:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:33:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:33:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:33:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:33:21 --> Final output sent to browser
DEBUG - 2020-09-02 11:33:21 --> Total execution time: 0.0542
INFO - 2020-09-02 11:34:23 --> Config Class Initialized
INFO - 2020-09-02 11:34:23 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:34:23 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:34:23 --> Utf8 Class Initialized
INFO - 2020-09-02 11:34:23 --> URI Class Initialized
DEBUG - 2020-09-02 11:34:23 --> No URI present. Default controller set.
INFO - 2020-09-02 11:34:23 --> Router Class Initialized
INFO - 2020-09-02 11:34:23 --> Output Class Initialized
INFO - 2020-09-02 11:34:23 --> Security Class Initialized
DEBUG - 2020-09-02 11:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:34:23 --> Input Class Initialized
INFO - 2020-09-02 11:34:23 --> Language Class Initialized
INFO - 2020-09-02 11:34:23 --> Language Class Initialized
INFO - 2020-09-02 11:34:23 --> Config Class Initialized
INFO - 2020-09-02 11:34:23 --> Loader Class Initialized
INFO - 2020-09-02 11:34:23 --> Helper loaded: url_helper
INFO - 2020-09-02 11:34:23 --> Helper loaded: form_helper
INFO - 2020-09-02 11:34:23 --> Helper loaded: file_helper
INFO - 2020-09-02 11:34:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:34:23 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:34:23 --> Upload Class Initialized
INFO - 2020-09-02 11:34:23 --> Controller Class Initialized
DEBUG - 2020-09-02 11:34:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:34:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:34:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:34:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:34:23 --> Final output sent to browser
DEBUG - 2020-09-02 11:34:23 --> Total execution time: 0.0522
INFO - 2020-09-02 11:35:06 --> Config Class Initialized
INFO - 2020-09-02 11:35:06 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:35:06 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:35:06 --> Utf8 Class Initialized
INFO - 2020-09-02 11:35:06 --> URI Class Initialized
DEBUG - 2020-09-02 11:35:06 --> No URI present. Default controller set.
INFO - 2020-09-02 11:35:06 --> Router Class Initialized
INFO - 2020-09-02 11:35:06 --> Output Class Initialized
INFO - 2020-09-02 11:35:06 --> Security Class Initialized
DEBUG - 2020-09-02 11:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:35:06 --> Input Class Initialized
INFO - 2020-09-02 11:35:06 --> Language Class Initialized
INFO - 2020-09-02 11:35:06 --> Language Class Initialized
INFO - 2020-09-02 11:35:06 --> Config Class Initialized
INFO - 2020-09-02 11:35:07 --> Loader Class Initialized
INFO - 2020-09-02 11:35:07 --> Helper loaded: url_helper
INFO - 2020-09-02 11:35:07 --> Helper loaded: form_helper
INFO - 2020-09-02 11:35:07 --> Helper loaded: file_helper
INFO - 2020-09-02 11:35:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:35:07 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:35:07 --> Upload Class Initialized
INFO - 2020-09-02 11:35:07 --> Controller Class Initialized
DEBUG - 2020-09-02 11:35:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:35:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:35:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:35:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:35:07 --> Final output sent to browser
DEBUG - 2020-09-02 11:35:07 --> Total execution time: 0.0506
INFO - 2020-09-02 11:35:27 --> Config Class Initialized
INFO - 2020-09-02 11:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:35:27 --> Utf8 Class Initialized
INFO - 2020-09-02 11:35:27 --> URI Class Initialized
DEBUG - 2020-09-02 11:35:27 --> No URI present. Default controller set.
INFO - 2020-09-02 11:35:27 --> Router Class Initialized
INFO - 2020-09-02 11:35:27 --> Output Class Initialized
INFO - 2020-09-02 11:35:27 --> Security Class Initialized
DEBUG - 2020-09-02 11:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:35:27 --> Input Class Initialized
INFO - 2020-09-02 11:35:27 --> Language Class Initialized
INFO - 2020-09-02 11:35:27 --> Language Class Initialized
INFO - 2020-09-02 11:35:27 --> Config Class Initialized
INFO - 2020-09-02 11:35:27 --> Loader Class Initialized
INFO - 2020-09-02 11:35:27 --> Helper loaded: url_helper
INFO - 2020-09-02 11:35:27 --> Helper loaded: form_helper
INFO - 2020-09-02 11:35:27 --> Helper loaded: file_helper
INFO - 2020-09-02 11:35:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:35:27 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:35:27 --> Upload Class Initialized
INFO - 2020-09-02 11:35:27 --> Controller Class Initialized
DEBUG - 2020-09-02 11:35:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:35:27 --> Final output sent to browser
DEBUG - 2020-09-02 11:35:27 --> Total execution time: 0.0669
INFO - 2020-09-02 11:36:15 --> Config Class Initialized
INFO - 2020-09-02 11:36:15 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:36:15 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:36:15 --> Utf8 Class Initialized
INFO - 2020-09-02 11:36:15 --> URI Class Initialized
DEBUG - 2020-09-02 11:36:15 --> No URI present. Default controller set.
INFO - 2020-09-02 11:36:15 --> Router Class Initialized
INFO - 2020-09-02 11:36:15 --> Output Class Initialized
INFO - 2020-09-02 11:36:15 --> Security Class Initialized
DEBUG - 2020-09-02 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:36:16 --> Input Class Initialized
INFO - 2020-09-02 11:36:16 --> Language Class Initialized
INFO - 2020-09-02 11:36:16 --> Language Class Initialized
INFO - 2020-09-02 11:36:16 --> Config Class Initialized
INFO - 2020-09-02 11:36:16 --> Loader Class Initialized
INFO - 2020-09-02 11:36:16 --> Helper loaded: url_helper
INFO - 2020-09-02 11:36:16 --> Helper loaded: form_helper
INFO - 2020-09-02 11:36:16 --> Helper loaded: file_helper
INFO - 2020-09-02 11:36:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:36:16 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:36:16 --> Upload Class Initialized
INFO - 2020-09-02 11:36:16 --> Controller Class Initialized
DEBUG - 2020-09-02 11:36:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:36:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:36:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:36:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:36:16 --> Final output sent to browser
DEBUG - 2020-09-02 11:36:16 --> Total execution time: 0.0533
INFO - 2020-09-02 11:36:39 --> Config Class Initialized
INFO - 2020-09-02 11:36:39 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:36:39 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:36:39 --> Utf8 Class Initialized
INFO - 2020-09-02 11:36:39 --> URI Class Initialized
INFO - 2020-09-02 11:36:39 --> Router Class Initialized
INFO - 2020-09-02 11:36:39 --> Output Class Initialized
INFO - 2020-09-02 11:36:39 --> Security Class Initialized
DEBUG - 2020-09-02 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:36:39 --> Input Class Initialized
INFO - 2020-09-02 11:36:39 --> Language Class Initialized
INFO - 2020-09-02 11:36:39 --> Language Class Initialized
INFO - 2020-09-02 11:36:39 --> Config Class Initialized
INFO - 2020-09-02 11:36:39 --> Loader Class Initialized
INFO - 2020-09-02 11:36:39 --> Helper loaded: url_helper
INFO - 2020-09-02 11:36:39 --> Helper loaded: form_helper
INFO - 2020-09-02 11:36:39 --> Helper loaded: file_helper
INFO - 2020-09-02 11:36:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:36:39 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:36:39 --> Upload Class Initialized
INFO - 2020-09-02 11:36:39 --> Controller Class Initialized
ERROR - 2020-09-02 11:36:39 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:37:35 --> Config Class Initialized
INFO - 2020-09-02 11:37:35 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:37:35 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:37:35 --> Utf8 Class Initialized
INFO - 2020-09-02 11:37:35 --> URI Class Initialized
INFO - 2020-09-02 11:37:35 --> Router Class Initialized
INFO - 2020-09-02 11:37:35 --> Output Class Initialized
INFO - 2020-09-02 11:37:35 --> Security Class Initialized
DEBUG - 2020-09-02 11:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:37:35 --> Input Class Initialized
INFO - 2020-09-02 11:37:35 --> Language Class Initialized
INFO - 2020-09-02 11:37:35 --> Language Class Initialized
INFO - 2020-09-02 11:37:35 --> Config Class Initialized
INFO - 2020-09-02 11:37:35 --> Loader Class Initialized
INFO - 2020-09-02 11:37:35 --> Helper loaded: url_helper
INFO - 2020-09-02 11:37:35 --> Helper loaded: form_helper
INFO - 2020-09-02 11:37:35 --> Helper loaded: file_helper
INFO - 2020-09-02 11:37:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:37:35 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:37:35 --> Upload Class Initialized
INFO - 2020-09-02 11:37:35 --> Controller Class Initialized
ERROR - 2020-09-02 11:37:35 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:37:35 --> Config Class Initialized
INFO - 2020-09-02 11:37:35 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:37:35 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:37:35 --> Utf8 Class Initialized
INFO - 2020-09-02 11:37:35 --> URI Class Initialized
DEBUG - 2020-09-02 11:37:35 --> No URI present. Default controller set.
INFO - 2020-09-02 11:37:35 --> Router Class Initialized
INFO - 2020-09-02 11:37:35 --> Output Class Initialized
INFO - 2020-09-02 11:37:35 --> Security Class Initialized
DEBUG - 2020-09-02 11:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:37:35 --> Input Class Initialized
INFO - 2020-09-02 11:37:35 --> Language Class Initialized
INFO - 2020-09-02 11:37:35 --> Language Class Initialized
INFO - 2020-09-02 11:37:35 --> Config Class Initialized
INFO - 2020-09-02 11:37:35 --> Loader Class Initialized
INFO - 2020-09-02 11:37:35 --> Helper loaded: url_helper
INFO - 2020-09-02 11:37:35 --> Helper loaded: form_helper
INFO - 2020-09-02 11:37:35 --> Helper loaded: file_helper
INFO - 2020-09-02 11:37:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:37:35 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:37:35 --> Upload Class Initialized
INFO - 2020-09-02 11:37:35 --> Controller Class Initialized
DEBUG - 2020-09-02 11:37:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:37:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:37:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:37:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:37:35 --> Final output sent to browser
DEBUG - 2020-09-02 11:37:35 --> Total execution time: 0.0688
INFO - 2020-09-02 11:38:27 --> Config Class Initialized
INFO - 2020-09-02 11:38:27 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:38:27 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:38:27 --> Utf8 Class Initialized
INFO - 2020-09-02 11:38:27 --> URI Class Initialized
DEBUG - 2020-09-02 11:38:27 --> No URI present. Default controller set.
INFO - 2020-09-02 11:38:27 --> Router Class Initialized
INFO - 2020-09-02 11:38:27 --> Output Class Initialized
INFO - 2020-09-02 11:38:27 --> Security Class Initialized
DEBUG - 2020-09-02 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:38:27 --> Input Class Initialized
INFO - 2020-09-02 11:38:27 --> Language Class Initialized
INFO - 2020-09-02 11:38:27 --> Language Class Initialized
INFO - 2020-09-02 11:38:27 --> Config Class Initialized
INFO - 2020-09-02 11:38:27 --> Loader Class Initialized
INFO - 2020-09-02 11:38:27 --> Helper loaded: url_helper
INFO - 2020-09-02 11:38:27 --> Helper loaded: form_helper
INFO - 2020-09-02 11:38:27 --> Helper loaded: file_helper
INFO - 2020-09-02 11:38:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:38:27 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:38:27 --> Upload Class Initialized
INFO - 2020-09-02 11:38:28 --> Controller Class Initialized
DEBUG - 2020-09-02 11:38:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:38:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:38:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:38:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:38:28 --> Final output sent to browser
DEBUG - 2020-09-02 11:38:28 --> Total execution time: 0.0543
INFO - 2020-09-02 11:38:46 --> Config Class Initialized
INFO - 2020-09-02 11:38:46 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:38:46 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:38:46 --> Utf8 Class Initialized
INFO - 2020-09-02 11:38:46 --> URI Class Initialized
INFO - 2020-09-02 11:38:46 --> Router Class Initialized
INFO - 2020-09-02 11:38:46 --> Output Class Initialized
INFO - 2020-09-02 11:38:46 --> Security Class Initialized
DEBUG - 2020-09-02 11:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:38:46 --> Input Class Initialized
INFO - 2020-09-02 11:38:46 --> Language Class Initialized
INFO - 2020-09-02 11:38:46 --> Language Class Initialized
INFO - 2020-09-02 11:38:46 --> Config Class Initialized
INFO - 2020-09-02 11:38:46 --> Loader Class Initialized
INFO - 2020-09-02 11:38:46 --> Helper loaded: url_helper
INFO - 2020-09-02 11:38:46 --> Helper loaded: form_helper
INFO - 2020-09-02 11:38:46 --> Helper loaded: file_helper
INFO - 2020-09-02 11:38:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:38:46 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:38:46 --> Upload Class Initialized
INFO - 2020-09-02 11:38:46 --> Controller Class Initialized
ERROR - 2020-09-02 11:38:46 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:38:49 --> Config Class Initialized
INFO - 2020-09-02 11:38:49 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:38:49 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:38:49 --> Utf8 Class Initialized
INFO - 2020-09-02 11:38:49 --> URI Class Initialized
INFO - 2020-09-02 11:38:49 --> Router Class Initialized
INFO - 2020-09-02 11:38:49 --> Output Class Initialized
INFO - 2020-09-02 11:38:49 --> Security Class Initialized
DEBUG - 2020-09-02 11:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:38:49 --> Input Class Initialized
INFO - 2020-09-02 11:38:49 --> Language Class Initialized
INFO - 2020-09-02 11:38:49 --> Language Class Initialized
INFO - 2020-09-02 11:38:49 --> Config Class Initialized
INFO - 2020-09-02 11:38:49 --> Loader Class Initialized
INFO - 2020-09-02 11:38:49 --> Helper loaded: url_helper
INFO - 2020-09-02 11:38:49 --> Helper loaded: form_helper
INFO - 2020-09-02 11:38:49 --> Helper loaded: file_helper
INFO - 2020-09-02 11:38:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:38:49 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:38:49 --> Upload Class Initialized
INFO - 2020-09-02 11:38:49 --> Controller Class Initialized
ERROR - 2020-09-02 11:38:49 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:38:57 --> Config Class Initialized
INFO - 2020-09-02 11:38:57 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:38:57 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:38:57 --> Utf8 Class Initialized
INFO - 2020-09-02 11:38:57 --> URI Class Initialized
INFO - 2020-09-02 11:38:57 --> Router Class Initialized
INFO - 2020-09-02 11:38:57 --> Output Class Initialized
INFO - 2020-09-02 11:38:57 --> Security Class Initialized
DEBUG - 2020-09-02 11:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:38:57 --> Input Class Initialized
INFO - 2020-09-02 11:38:57 --> Language Class Initialized
INFO - 2020-09-02 11:38:57 --> Language Class Initialized
INFO - 2020-09-02 11:38:57 --> Config Class Initialized
INFO - 2020-09-02 11:38:57 --> Loader Class Initialized
INFO - 2020-09-02 11:38:57 --> Helper loaded: url_helper
INFO - 2020-09-02 11:38:57 --> Helper loaded: form_helper
INFO - 2020-09-02 11:38:57 --> Helper loaded: file_helper
INFO - 2020-09-02 11:38:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:38:57 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:38:57 --> Upload Class Initialized
INFO - 2020-09-02 11:38:57 --> Controller Class Initialized
ERROR - 2020-09-02 11:38:57 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:39:32 --> Config Class Initialized
INFO - 2020-09-02 11:39:32 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:39:32 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:39:32 --> Utf8 Class Initialized
INFO - 2020-09-02 11:39:32 --> URI Class Initialized
INFO - 2020-09-02 11:39:32 --> Router Class Initialized
INFO - 2020-09-02 11:39:32 --> Output Class Initialized
INFO - 2020-09-02 11:39:32 --> Security Class Initialized
DEBUG - 2020-09-02 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:39:32 --> Input Class Initialized
INFO - 2020-09-02 11:39:32 --> Language Class Initialized
INFO - 2020-09-02 11:39:32 --> Language Class Initialized
INFO - 2020-09-02 11:39:32 --> Config Class Initialized
INFO - 2020-09-02 11:39:32 --> Loader Class Initialized
INFO - 2020-09-02 11:39:32 --> Helper loaded: url_helper
INFO - 2020-09-02 11:39:32 --> Helper loaded: form_helper
INFO - 2020-09-02 11:39:32 --> Helper loaded: file_helper
INFO - 2020-09-02 11:39:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:39:32 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:39:32 --> Upload Class Initialized
INFO - 2020-09-02 11:39:32 --> Controller Class Initialized
ERROR - 2020-09-02 11:39:32 --> 404 Page Not Found: /index
INFO - 2020-09-02 11:43:00 --> Config Class Initialized
INFO - 2020-09-02 11:43:00 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:43:00 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:43:00 --> Utf8 Class Initialized
INFO - 2020-09-02 11:43:00 --> URI Class Initialized
DEBUG - 2020-09-02 11:43:00 --> No URI present. Default controller set.
INFO - 2020-09-02 11:43:00 --> Router Class Initialized
INFO - 2020-09-02 11:43:00 --> Output Class Initialized
INFO - 2020-09-02 11:43:00 --> Security Class Initialized
DEBUG - 2020-09-02 11:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:43:00 --> Input Class Initialized
INFO - 2020-09-02 11:43:00 --> Language Class Initialized
INFO - 2020-09-02 11:43:00 --> Language Class Initialized
INFO - 2020-09-02 11:43:00 --> Config Class Initialized
INFO - 2020-09-02 11:43:00 --> Loader Class Initialized
INFO - 2020-09-02 11:43:00 --> Helper loaded: url_helper
INFO - 2020-09-02 11:43:00 --> Helper loaded: form_helper
INFO - 2020-09-02 11:43:00 --> Helper loaded: file_helper
INFO - 2020-09-02 11:43:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:43:00 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:43:00 --> Upload Class Initialized
INFO - 2020-09-02 11:43:00 --> Controller Class Initialized
DEBUG - 2020-09-02 11:43:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 11:43:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 11:43:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 11:43:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 11:43:00 --> Final output sent to browser
DEBUG - 2020-09-02 11:43:00 --> Total execution time: 0.0614
INFO - 2020-09-02 11:43:04 --> Config Class Initialized
INFO - 2020-09-02 11:43:04 --> Hooks Class Initialized
DEBUG - 2020-09-02 11:43:04 --> UTF-8 Support Enabled
INFO - 2020-09-02 11:43:04 --> Utf8 Class Initialized
INFO - 2020-09-02 11:43:04 --> URI Class Initialized
INFO - 2020-09-02 11:43:04 --> Router Class Initialized
INFO - 2020-09-02 11:43:04 --> Output Class Initialized
INFO - 2020-09-02 11:43:04 --> Security Class Initialized
DEBUG - 2020-09-02 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 11:43:04 --> Input Class Initialized
INFO - 2020-09-02 11:43:04 --> Language Class Initialized
INFO - 2020-09-02 11:43:04 --> Language Class Initialized
INFO - 2020-09-02 11:43:04 --> Config Class Initialized
INFO - 2020-09-02 11:43:04 --> Loader Class Initialized
INFO - 2020-09-02 11:43:04 --> Helper loaded: url_helper
INFO - 2020-09-02 11:43:04 --> Helper loaded: form_helper
INFO - 2020-09-02 11:43:04 --> Helper loaded: file_helper
INFO - 2020-09-02 11:43:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 11:43:04 --> Database Driver Class Initialized
DEBUG - 2020-09-02 11:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 11:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 11:43:04 --> Upload Class Initialized
INFO - 2020-09-02 11:43:04 --> Controller Class Initialized
ERROR - 2020-09-02 11:43:04 --> 404 Page Not Found: /index
INFO - 2020-09-02 12:49:29 --> Config Class Initialized
INFO - 2020-09-02 12:49:29 --> Hooks Class Initialized
DEBUG - 2020-09-02 12:49:29 --> UTF-8 Support Enabled
INFO - 2020-09-02 12:49:29 --> Utf8 Class Initialized
INFO - 2020-09-02 12:49:29 --> URI Class Initialized
DEBUG - 2020-09-02 12:49:29 --> No URI present. Default controller set.
INFO - 2020-09-02 12:49:29 --> Router Class Initialized
INFO - 2020-09-02 12:49:29 --> Output Class Initialized
INFO - 2020-09-02 12:49:29 --> Security Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 12:49:29 --> Input Class Initialized
INFO - 2020-09-02 12:49:29 --> Language Class Initialized
INFO - 2020-09-02 12:49:29 --> Language Class Initialized
INFO - 2020-09-02 12:49:29 --> Config Class Initialized
INFO - 2020-09-02 12:49:29 --> Loader Class Initialized
INFO - 2020-09-02 12:49:29 --> Helper loaded: url_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: form_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: file_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 12:49:29 --> Database Driver Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 12:49:29 --> Upload Class Initialized
INFO - 2020-09-02 12:49:29 --> Controller Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 12:49:29 --> Final output sent to browser
DEBUG - 2020-09-02 12:49:29 --> Total execution time: 0.0503
INFO - 2020-09-02 12:49:29 --> Config Class Initialized
INFO - 2020-09-02 12:49:29 --> Hooks Class Initialized
DEBUG - 2020-09-02 12:49:29 --> UTF-8 Support Enabled
INFO - 2020-09-02 12:49:29 --> Utf8 Class Initialized
INFO - 2020-09-02 12:49:29 --> URI Class Initialized
DEBUG - 2020-09-02 12:49:29 --> No URI present. Default controller set.
INFO - 2020-09-02 12:49:29 --> Router Class Initialized
INFO - 2020-09-02 12:49:29 --> Output Class Initialized
INFO - 2020-09-02 12:49:29 --> Security Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 12:49:29 --> Input Class Initialized
INFO - 2020-09-02 12:49:29 --> Language Class Initialized
INFO - 2020-09-02 12:49:29 --> Language Class Initialized
INFO - 2020-09-02 12:49:29 --> Config Class Initialized
INFO - 2020-09-02 12:49:29 --> Loader Class Initialized
INFO - 2020-09-02 12:49:29 --> Helper loaded: url_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: form_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: file_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 12:49:29 --> Database Driver Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 12:49:29 --> Upload Class Initialized
INFO - 2020-09-02 12:49:29 --> Controller Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 12:49:29 --> Final output sent to browser
DEBUG - 2020-09-02 12:49:29 --> Total execution time: 0.0502
INFO - 2020-09-02 12:49:29 --> Config Class Initialized
INFO - 2020-09-02 12:49:29 --> Hooks Class Initialized
DEBUG - 2020-09-02 12:49:29 --> UTF-8 Support Enabled
INFO - 2020-09-02 12:49:29 --> Utf8 Class Initialized
INFO - 2020-09-02 12:49:29 --> URI Class Initialized
DEBUG - 2020-09-02 12:49:29 --> No URI present. Default controller set.
INFO - 2020-09-02 12:49:29 --> Router Class Initialized
INFO - 2020-09-02 12:49:29 --> Output Class Initialized
INFO - 2020-09-02 12:49:29 --> Security Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 12:49:29 --> Input Class Initialized
INFO - 2020-09-02 12:49:29 --> Language Class Initialized
INFO - 2020-09-02 12:49:29 --> Language Class Initialized
INFO - 2020-09-02 12:49:29 --> Config Class Initialized
INFO - 2020-09-02 12:49:29 --> Loader Class Initialized
INFO - 2020-09-02 12:49:29 --> Helper loaded: url_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: form_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: file_helper
INFO - 2020-09-02 12:49:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 12:49:29 --> Database Driver Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 12:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 12:49:29 --> Upload Class Initialized
INFO - 2020-09-02 12:49:29 --> Controller Class Initialized
DEBUG - 2020-09-02 12:49:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 12:49:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 12:49:29 --> Final output sent to browser
DEBUG - 2020-09-02 12:49:29 --> Total execution time: 0.0525
INFO - 2020-09-02 13:00:19 --> Config Class Initialized
INFO - 2020-09-02 13:00:19 --> Hooks Class Initialized
DEBUG - 2020-09-02 13:00:19 --> UTF-8 Support Enabled
INFO - 2020-09-02 13:00:19 --> Utf8 Class Initialized
INFO - 2020-09-02 13:00:19 --> URI Class Initialized
INFO - 2020-09-02 13:00:19 --> Router Class Initialized
INFO - 2020-09-02 13:00:19 --> Output Class Initialized
INFO - 2020-09-02 13:00:19 --> Security Class Initialized
DEBUG - 2020-09-02 13:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 13:00:19 --> Input Class Initialized
INFO - 2020-09-02 13:00:19 --> Language Class Initialized
INFO - 2020-09-02 13:00:19 --> Language Class Initialized
INFO - 2020-09-02 13:00:19 --> Config Class Initialized
INFO - 2020-09-02 13:00:19 --> Loader Class Initialized
INFO - 2020-09-02 13:00:19 --> Helper loaded: url_helper
INFO - 2020-09-02 13:00:19 --> Helper loaded: form_helper
INFO - 2020-09-02 13:00:19 --> Helper loaded: file_helper
INFO - 2020-09-02 13:00:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 13:00:19 --> Database Driver Class Initialized
DEBUG - 2020-09-02 13:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 13:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 13:00:19 --> Upload Class Initialized
INFO - 2020-09-02 13:00:19 --> Controller Class Initialized
ERROR - 2020-09-02 13:00:19 --> 404 Page Not Found: /index
INFO - 2020-09-02 13:09:47 --> Config Class Initialized
INFO - 2020-09-02 13:09:47 --> Hooks Class Initialized
DEBUG - 2020-09-02 13:09:47 --> UTF-8 Support Enabled
INFO - 2020-09-02 13:09:47 --> Utf8 Class Initialized
INFO - 2020-09-02 13:09:47 --> URI Class Initialized
DEBUG - 2020-09-02 13:09:47 --> No URI present. Default controller set.
INFO - 2020-09-02 13:09:47 --> Router Class Initialized
INFO - 2020-09-02 13:09:47 --> Output Class Initialized
INFO - 2020-09-02 13:09:47 --> Security Class Initialized
DEBUG - 2020-09-02 13:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 13:09:47 --> Input Class Initialized
INFO - 2020-09-02 13:09:47 --> Language Class Initialized
INFO - 2020-09-02 13:09:47 --> Language Class Initialized
INFO - 2020-09-02 13:09:47 --> Config Class Initialized
INFO - 2020-09-02 13:09:47 --> Loader Class Initialized
INFO - 2020-09-02 13:09:47 --> Helper loaded: url_helper
INFO - 2020-09-02 13:09:47 --> Helper loaded: form_helper
INFO - 2020-09-02 13:09:47 --> Helper loaded: file_helper
INFO - 2020-09-02 13:09:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 13:09:47 --> Database Driver Class Initialized
DEBUG - 2020-09-02 13:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 13:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 13:09:47 --> Upload Class Initialized
INFO - 2020-09-02 13:09:47 --> Controller Class Initialized
DEBUG - 2020-09-02 13:09:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 13:09:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 13:09:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 13:09:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 13:09:47 --> Final output sent to browser
DEBUG - 2020-09-02 13:09:47 --> Total execution time: 0.0563
INFO - 2020-09-02 13:09:48 --> Config Class Initialized
INFO - 2020-09-02 13:09:48 --> Hooks Class Initialized
DEBUG - 2020-09-02 13:09:48 --> UTF-8 Support Enabled
INFO - 2020-09-02 13:09:48 --> Utf8 Class Initialized
INFO - 2020-09-02 13:09:48 --> URI Class Initialized
DEBUG - 2020-09-02 13:09:48 --> No URI present. Default controller set.
INFO - 2020-09-02 13:09:48 --> Router Class Initialized
INFO - 2020-09-02 13:09:48 --> Output Class Initialized
INFO - 2020-09-02 13:09:48 --> Security Class Initialized
DEBUG - 2020-09-02 13:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 13:09:48 --> Input Class Initialized
INFO - 2020-09-02 13:09:48 --> Language Class Initialized
INFO - 2020-09-02 13:09:48 --> Language Class Initialized
INFO - 2020-09-02 13:09:48 --> Config Class Initialized
INFO - 2020-09-02 13:09:48 --> Loader Class Initialized
INFO - 2020-09-02 13:09:48 --> Helper loaded: url_helper
INFO - 2020-09-02 13:09:48 --> Helper loaded: form_helper
INFO - 2020-09-02 13:09:48 --> Helper loaded: file_helper
INFO - 2020-09-02 13:09:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 13:09:48 --> Database Driver Class Initialized
DEBUG - 2020-09-02 13:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 13:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 13:09:48 --> Upload Class Initialized
INFO - 2020-09-02 13:09:48 --> Controller Class Initialized
DEBUG - 2020-09-02 13:09:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 13:09:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 13:09:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 13:09:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 13:09:48 --> Final output sent to browser
DEBUG - 2020-09-02 13:09:48 --> Total execution time: 0.0532
INFO - 2020-09-02 13:22:35 --> Config Class Initialized
INFO - 2020-09-02 13:22:35 --> Hooks Class Initialized
DEBUG - 2020-09-02 13:22:35 --> UTF-8 Support Enabled
INFO - 2020-09-02 13:22:35 --> Utf8 Class Initialized
INFO - 2020-09-02 13:22:35 --> URI Class Initialized
DEBUG - 2020-09-02 13:22:35 --> No URI present. Default controller set.
INFO - 2020-09-02 13:22:35 --> Router Class Initialized
INFO - 2020-09-02 13:22:35 --> Output Class Initialized
INFO - 2020-09-02 13:22:35 --> Security Class Initialized
DEBUG - 2020-09-02 13:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 13:22:35 --> Input Class Initialized
INFO - 2020-09-02 13:22:35 --> Language Class Initialized
INFO - 2020-09-02 13:22:35 --> Language Class Initialized
INFO - 2020-09-02 13:22:35 --> Config Class Initialized
INFO - 2020-09-02 13:22:35 --> Loader Class Initialized
INFO - 2020-09-02 13:22:35 --> Helper loaded: url_helper
INFO - 2020-09-02 13:22:35 --> Helper loaded: form_helper
INFO - 2020-09-02 13:22:35 --> Helper loaded: file_helper
INFO - 2020-09-02 13:22:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 13:22:35 --> Database Driver Class Initialized
DEBUG - 2020-09-02 13:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 13:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 13:22:35 --> Upload Class Initialized
INFO - 2020-09-02 13:22:35 --> Controller Class Initialized
DEBUG - 2020-09-02 13:22:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 13:22:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 13:22:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 13:22:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 13:22:35 --> Final output sent to browser
DEBUG - 2020-09-02 13:22:35 --> Total execution time: 0.0573
INFO - 2020-09-02 13:58:04 --> Config Class Initialized
INFO - 2020-09-02 13:58:04 --> Hooks Class Initialized
DEBUG - 2020-09-02 13:58:04 --> UTF-8 Support Enabled
INFO - 2020-09-02 13:58:04 --> Utf8 Class Initialized
INFO - 2020-09-02 13:58:04 --> URI Class Initialized
INFO - 2020-09-02 13:58:04 --> Router Class Initialized
INFO - 2020-09-02 13:58:04 --> Output Class Initialized
INFO - 2020-09-02 13:58:04 --> Security Class Initialized
DEBUG - 2020-09-02 13:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 13:58:04 --> Input Class Initialized
INFO - 2020-09-02 13:58:04 --> Language Class Initialized
INFO - 2020-09-02 13:58:04 --> Language Class Initialized
INFO - 2020-09-02 13:58:04 --> Config Class Initialized
INFO - 2020-09-02 13:58:04 --> Loader Class Initialized
INFO - 2020-09-02 13:58:04 --> Helper loaded: url_helper
INFO - 2020-09-02 13:58:04 --> Helper loaded: form_helper
INFO - 2020-09-02 13:58:04 --> Helper loaded: file_helper
INFO - 2020-09-02 13:58:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 13:58:04 --> Database Driver Class Initialized
DEBUG - 2020-09-02 13:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 13:58:04 --> Upload Class Initialized
INFO - 2020-09-02 13:58:04 --> Controller Class Initialized
DEBUG - 2020-09-02 13:58:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 13:58:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 13:58:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 13:58:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 13:58:04 --> Final output sent to browser
DEBUG - 2020-09-02 13:58:04 --> Total execution time: 0.0607
INFO - 2020-09-02 13:58:08 --> Config Class Initialized
INFO - 2020-09-02 13:58:08 --> Hooks Class Initialized
DEBUG - 2020-09-02 13:58:08 --> UTF-8 Support Enabled
INFO - 2020-09-02 13:58:08 --> Utf8 Class Initialized
INFO - 2020-09-02 13:58:08 --> URI Class Initialized
INFO - 2020-09-02 13:58:08 --> Router Class Initialized
INFO - 2020-09-02 13:58:08 --> Output Class Initialized
INFO - 2020-09-02 13:58:08 --> Security Class Initialized
DEBUG - 2020-09-02 13:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 13:58:08 --> Input Class Initialized
INFO - 2020-09-02 13:58:08 --> Language Class Initialized
INFO - 2020-09-02 13:58:08 --> Language Class Initialized
INFO - 2020-09-02 13:58:08 --> Config Class Initialized
INFO - 2020-09-02 13:58:08 --> Loader Class Initialized
INFO - 2020-09-02 13:58:08 --> Helper loaded: url_helper
INFO - 2020-09-02 13:58:08 --> Helper loaded: form_helper
INFO - 2020-09-02 13:58:08 --> Helper loaded: file_helper
INFO - 2020-09-02 13:58:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 13:58:08 --> Database Driver Class Initialized
DEBUG - 2020-09-02 13:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 13:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 13:58:08 --> Upload Class Initialized
INFO - 2020-09-02 13:58:08 --> Controller Class Initialized
ERROR - 2020-09-02 13:58:08 --> 404 Page Not Found: /index
INFO - 2020-09-02 14:30:56 --> Config Class Initialized
INFO - 2020-09-02 14:30:56 --> Hooks Class Initialized
DEBUG - 2020-09-02 14:30:56 --> UTF-8 Support Enabled
INFO - 2020-09-02 14:30:56 --> Utf8 Class Initialized
INFO - 2020-09-02 14:30:56 --> URI Class Initialized
DEBUG - 2020-09-02 14:30:56 --> No URI present. Default controller set.
INFO - 2020-09-02 14:30:56 --> Router Class Initialized
INFO - 2020-09-02 14:30:56 --> Output Class Initialized
INFO - 2020-09-02 14:30:56 --> Security Class Initialized
DEBUG - 2020-09-02 14:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 14:30:56 --> Input Class Initialized
INFO - 2020-09-02 14:30:56 --> Language Class Initialized
INFO - 2020-09-02 14:30:56 --> Language Class Initialized
INFO - 2020-09-02 14:30:56 --> Config Class Initialized
INFO - 2020-09-02 14:30:56 --> Loader Class Initialized
INFO - 2020-09-02 14:30:56 --> Helper loaded: url_helper
INFO - 2020-09-02 14:30:56 --> Helper loaded: form_helper
INFO - 2020-09-02 14:30:56 --> Helper loaded: file_helper
INFO - 2020-09-02 14:30:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 14:30:56 --> Database Driver Class Initialized
DEBUG - 2020-09-02 14:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 14:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 14:30:56 --> Upload Class Initialized
INFO - 2020-09-02 14:30:56 --> Controller Class Initialized
DEBUG - 2020-09-02 14:30:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 14:30:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 14:30:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 14:30:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 14:30:56 --> Final output sent to browser
DEBUG - 2020-09-02 14:30:56 --> Total execution time: 0.0666
INFO - 2020-09-02 14:30:56 --> Config Class Initialized
INFO - 2020-09-02 14:30:56 --> Hooks Class Initialized
DEBUG - 2020-09-02 14:30:56 --> UTF-8 Support Enabled
INFO - 2020-09-02 14:30:56 --> Utf8 Class Initialized
INFO - 2020-09-02 14:30:56 --> URI Class Initialized
DEBUG - 2020-09-02 14:30:56 --> No URI present. Default controller set.
INFO - 2020-09-02 14:30:56 --> Router Class Initialized
INFO - 2020-09-02 14:30:56 --> Output Class Initialized
INFO - 2020-09-02 14:30:56 --> Security Class Initialized
DEBUG - 2020-09-02 14:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 14:30:56 --> Input Class Initialized
INFO - 2020-09-02 14:30:56 --> Language Class Initialized
INFO - 2020-09-02 14:30:56 --> Language Class Initialized
INFO - 2020-09-02 14:30:56 --> Config Class Initialized
INFO - 2020-09-02 14:30:56 --> Loader Class Initialized
INFO - 2020-09-02 14:30:56 --> Helper loaded: url_helper
INFO - 2020-09-02 14:30:56 --> Helper loaded: form_helper
INFO - 2020-09-02 14:30:56 --> Helper loaded: file_helper
INFO - 2020-09-02 14:30:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 14:30:56 --> Database Driver Class Initialized
DEBUG - 2020-09-02 14:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 14:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 14:30:56 --> Upload Class Initialized
INFO - 2020-09-02 14:30:56 --> Controller Class Initialized
DEBUG - 2020-09-02 14:30:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 14:30:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 14:30:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 14:30:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 14:30:56 --> Final output sent to browser
DEBUG - 2020-09-02 14:30:56 --> Total execution time: 0.0517
INFO - 2020-09-02 15:02:03 --> Config Class Initialized
INFO - 2020-09-02 15:02:03 --> Hooks Class Initialized
DEBUG - 2020-09-02 15:02:03 --> UTF-8 Support Enabled
INFO - 2020-09-02 15:02:03 --> Utf8 Class Initialized
INFO - 2020-09-02 15:02:03 --> URI Class Initialized
DEBUG - 2020-09-02 15:02:03 --> No URI present. Default controller set.
INFO - 2020-09-02 15:02:03 --> Router Class Initialized
INFO - 2020-09-02 15:02:03 --> Output Class Initialized
INFO - 2020-09-02 15:02:03 --> Security Class Initialized
DEBUG - 2020-09-02 15:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 15:02:03 --> Input Class Initialized
INFO - 2020-09-02 15:02:03 --> Language Class Initialized
INFO - 2020-09-02 15:02:03 --> Language Class Initialized
INFO - 2020-09-02 15:02:03 --> Config Class Initialized
INFO - 2020-09-02 15:02:03 --> Loader Class Initialized
INFO - 2020-09-02 15:02:03 --> Helper loaded: url_helper
INFO - 2020-09-02 15:02:03 --> Helper loaded: form_helper
INFO - 2020-09-02 15:02:03 --> Helper loaded: file_helper
INFO - 2020-09-02 15:02:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 15:02:03 --> Database Driver Class Initialized
DEBUG - 2020-09-02 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 15:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 15:02:03 --> Upload Class Initialized
INFO - 2020-09-02 15:02:03 --> Controller Class Initialized
DEBUG - 2020-09-02 15:02:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 15:02:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 15:02:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 15:02:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 15:02:03 --> Final output sent to browser
DEBUG - 2020-09-02 15:02:03 --> Total execution time: 0.1465
INFO - 2020-09-02 15:40:10 --> Config Class Initialized
INFO - 2020-09-02 15:40:10 --> Hooks Class Initialized
DEBUG - 2020-09-02 15:40:10 --> UTF-8 Support Enabled
INFO - 2020-09-02 15:40:10 --> Utf8 Class Initialized
INFO - 2020-09-02 15:40:10 --> URI Class Initialized
DEBUG - 2020-09-02 15:40:10 --> No URI present. Default controller set.
INFO - 2020-09-02 15:40:10 --> Router Class Initialized
INFO - 2020-09-02 15:40:10 --> Output Class Initialized
INFO - 2020-09-02 15:40:10 --> Security Class Initialized
DEBUG - 2020-09-02 15:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 15:40:10 --> Input Class Initialized
INFO - 2020-09-02 15:40:10 --> Language Class Initialized
INFO - 2020-09-02 15:40:10 --> Language Class Initialized
INFO - 2020-09-02 15:40:10 --> Config Class Initialized
INFO - 2020-09-02 15:40:10 --> Loader Class Initialized
INFO - 2020-09-02 15:40:10 --> Helper loaded: url_helper
INFO - 2020-09-02 15:40:10 --> Helper loaded: form_helper
INFO - 2020-09-02 15:40:10 --> Helper loaded: file_helper
INFO - 2020-09-02 15:40:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 15:40:10 --> Database Driver Class Initialized
DEBUG - 2020-09-02 15:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 15:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 15:40:10 --> Upload Class Initialized
INFO - 2020-09-02 15:40:10 --> Controller Class Initialized
DEBUG - 2020-09-02 15:40:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 15:40:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 15:40:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 15:40:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 15:40:10 --> Final output sent to browser
DEBUG - 2020-09-02 15:40:10 --> Total execution time: 0.0517
INFO - 2020-09-02 15:40:20 --> Config Class Initialized
INFO - 2020-09-02 15:40:20 --> Hooks Class Initialized
DEBUG - 2020-09-02 15:40:20 --> UTF-8 Support Enabled
INFO - 2020-09-02 15:40:20 --> Utf8 Class Initialized
INFO - 2020-09-02 15:40:20 --> URI Class Initialized
INFO - 2020-09-02 15:40:20 --> Router Class Initialized
INFO - 2020-09-02 15:40:20 --> Output Class Initialized
INFO - 2020-09-02 15:40:20 --> Security Class Initialized
DEBUG - 2020-09-02 15:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 15:40:20 --> Input Class Initialized
INFO - 2020-09-02 15:40:20 --> Language Class Initialized
INFO - 2020-09-02 15:40:20 --> Language Class Initialized
INFO - 2020-09-02 15:40:20 --> Config Class Initialized
INFO - 2020-09-02 15:40:20 --> Loader Class Initialized
INFO - 2020-09-02 15:40:20 --> Helper loaded: url_helper
INFO - 2020-09-02 15:40:20 --> Helper loaded: form_helper
INFO - 2020-09-02 15:40:20 --> Helper loaded: file_helper
INFO - 2020-09-02 15:40:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 15:40:20 --> Database Driver Class Initialized
DEBUG - 2020-09-02 15:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 15:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 15:40:20 --> Upload Class Initialized
INFO - 2020-09-02 15:40:20 --> Controller Class Initialized
ERROR - 2020-09-02 15:40:20 --> 404 Page Not Found: /index
INFO - 2020-09-02 15:53:33 --> Config Class Initialized
INFO - 2020-09-02 15:53:33 --> Hooks Class Initialized
DEBUG - 2020-09-02 15:53:33 --> UTF-8 Support Enabled
INFO - 2020-09-02 15:53:33 --> Utf8 Class Initialized
INFO - 2020-09-02 15:53:33 --> URI Class Initialized
DEBUG - 2020-09-02 15:53:33 --> No URI present. Default controller set.
INFO - 2020-09-02 15:53:33 --> Router Class Initialized
INFO - 2020-09-02 15:53:33 --> Output Class Initialized
INFO - 2020-09-02 15:53:33 --> Security Class Initialized
DEBUG - 2020-09-02 15:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 15:53:33 --> Input Class Initialized
INFO - 2020-09-02 15:53:33 --> Language Class Initialized
INFO - 2020-09-02 15:53:33 --> Language Class Initialized
INFO - 2020-09-02 15:53:33 --> Config Class Initialized
INFO - 2020-09-02 15:53:33 --> Loader Class Initialized
INFO - 2020-09-02 15:53:33 --> Helper loaded: url_helper
INFO - 2020-09-02 15:53:33 --> Helper loaded: form_helper
INFO - 2020-09-02 15:53:33 --> Helper loaded: file_helper
INFO - 2020-09-02 15:53:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 15:53:33 --> Database Driver Class Initialized
DEBUG - 2020-09-02 15:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 15:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 15:53:33 --> Upload Class Initialized
INFO - 2020-09-02 15:53:33 --> Controller Class Initialized
DEBUG - 2020-09-02 15:53:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 15:53:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 15:53:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 15:53:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 15:53:33 --> Final output sent to browser
DEBUG - 2020-09-02 15:53:33 --> Total execution time: 0.0508
INFO - 2020-09-02 15:53:39 --> Config Class Initialized
INFO - 2020-09-02 15:53:39 --> Hooks Class Initialized
DEBUG - 2020-09-02 15:53:39 --> UTF-8 Support Enabled
INFO - 2020-09-02 15:53:39 --> Utf8 Class Initialized
INFO - 2020-09-02 15:53:40 --> URI Class Initialized
INFO - 2020-09-02 15:53:40 --> Router Class Initialized
INFO - 2020-09-02 15:53:40 --> Output Class Initialized
INFO - 2020-09-02 15:53:40 --> Security Class Initialized
DEBUG - 2020-09-02 15:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 15:53:40 --> Input Class Initialized
INFO - 2020-09-02 15:53:40 --> Language Class Initialized
INFO - 2020-09-02 15:53:40 --> Language Class Initialized
INFO - 2020-09-02 15:53:40 --> Config Class Initialized
INFO - 2020-09-02 15:53:40 --> Loader Class Initialized
INFO - 2020-09-02 15:53:40 --> Helper loaded: url_helper
INFO - 2020-09-02 15:53:40 --> Helper loaded: form_helper
INFO - 2020-09-02 15:53:40 --> Helper loaded: file_helper
INFO - 2020-09-02 15:53:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 15:53:40 --> Database Driver Class Initialized
DEBUG - 2020-09-02 15:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 15:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 15:53:40 --> Upload Class Initialized
INFO - 2020-09-02 15:53:40 --> Controller Class Initialized
ERROR - 2020-09-02 15:53:40 --> 404 Page Not Found: /index
INFO - 2020-09-02 16:36:05 --> Config Class Initialized
INFO - 2020-09-02 16:36:05 --> Hooks Class Initialized
DEBUG - 2020-09-02 16:36:05 --> UTF-8 Support Enabled
INFO - 2020-09-02 16:36:05 --> Utf8 Class Initialized
INFO - 2020-09-02 16:36:05 --> URI Class Initialized
DEBUG - 2020-09-02 16:36:05 --> No URI present. Default controller set.
INFO - 2020-09-02 16:36:05 --> Router Class Initialized
INFO - 2020-09-02 16:36:05 --> Output Class Initialized
INFO - 2020-09-02 16:36:05 --> Security Class Initialized
DEBUG - 2020-09-02 16:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 16:36:05 --> Input Class Initialized
INFO - 2020-09-02 16:36:05 --> Language Class Initialized
INFO - 2020-09-02 16:36:05 --> Language Class Initialized
INFO - 2020-09-02 16:36:05 --> Config Class Initialized
INFO - 2020-09-02 16:36:05 --> Loader Class Initialized
INFO - 2020-09-02 16:36:05 --> Helper loaded: url_helper
INFO - 2020-09-02 16:36:05 --> Helper loaded: form_helper
INFO - 2020-09-02 16:36:05 --> Helper loaded: file_helper
INFO - 2020-09-02 16:36:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 16:36:05 --> Database Driver Class Initialized
DEBUG - 2020-09-02 16:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 16:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 16:36:05 --> Upload Class Initialized
INFO - 2020-09-02 16:36:05 --> Controller Class Initialized
DEBUG - 2020-09-02 16:36:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 16:36:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 16:36:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 16:36:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 16:36:05 --> Final output sent to browser
DEBUG - 2020-09-02 16:36:05 --> Total execution time: 0.1039
INFO - 2020-09-02 16:42:40 --> Config Class Initialized
INFO - 2020-09-02 16:42:40 --> Hooks Class Initialized
DEBUG - 2020-09-02 16:42:40 --> UTF-8 Support Enabled
INFO - 2020-09-02 16:42:40 --> Utf8 Class Initialized
INFO - 2020-09-02 16:42:40 --> URI Class Initialized
DEBUG - 2020-09-02 16:42:40 --> No URI present. Default controller set.
INFO - 2020-09-02 16:42:40 --> Router Class Initialized
INFO - 2020-09-02 16:42:40 --> Output Class Initialized
INFO - 2020-09-02 16:42:40 --> Security Class Initialized
DEBUG - 2020-09-02 16:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 16:42:40 --> Input Class Initialized
INFO - 2020-09-02 16:42:40 --> Language Class Initialized
INFO - 2020-09-02 16:42:40 --> Language Class Initialized
INFO - 2020-09-02 16:42:40 --> Config Class Initialized
INFO - 2020-09-02 16:42:40 --> Loader Class Initialized
INFO - 2020-09-02 16:42:40 --> Helper loaded: url_helper
INFO - 2020-09-02 16:42:40 --> Helper loaded: form_helper
INFO - 2020-09-02 16:42:40 --> Helper loaded: file_helper
INFO - 2020-09-02 16:42:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 16:42:40 --> Database Driver Class Initialized
DEBUG - 2020-09-02 16:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 16:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 16:42:40 --> Upload Class Initialized
INFO - 2020-09-02 16:42:40 --> Controller Class Initialized
DEBUG - 2020-09-02 16:42:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 16:42:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 16:42:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 16:42:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 16:42:40 --> Final output sent to browser
DEBUG - 2020-09-02 16:42:40 --> Total execution time: 0.0528
INFO - 2020-09-02 16:42:43 --> Config Class Initialized
INFO - 2020-09-02 16:42:43 --> Hooks Class Initialized
DEBUG - 2020-09-02 16:42:43 --> UTF-8 Support Enabled
INFO - 2020-09-02 16:42:43 --> Utf8 Class Initialized
INFO - 2020-09-02 16:42:43 --> URI Class Initialized
INFO - 2020-09-02 16:42:43 --> Router Class Initialized
INFO - 2020-09-02 16:42:43 --> Output Class Initialized
INFO - 2020-09-02 16:42:43 --> Security Class Initialized
DEBUG - 2020-09-02 16:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 16:42:43 --> Input Class Initialized
INFO - 2020-09-02 16:42:43 --> Language Class Initialized
INFO - 2020-09-02 16:42:43 --> Language Class Initialized
INFO - 2020-09-02 16:42:43 --> Config Class Initialized
INFO - 2020-09-02 16:42:43 --> Loader Class Initialized
INFO - 2020-09-02 16:42:43 --> Helper loaded: url_helper
INFO - 2020-09-02 16:42:43 --> Helper loaded: form_helper
INFO - 2020-09-02 16:42:43 --> Helper loaded: file_helper
INFO - 2020-09-02 16:42:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 16:42:43 --> Database Driver Class Initialized
DEBUG - 2020-09-02 16:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 16:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 16:42:43 --> Upload Class Initialized
INFO - 2020-09-02 16:42:43 --> Controller Class Initialized
ERROR - 2020-09-02 16:42:43 --> 404 Page Not Found: /index
INFO - 2020-09-02 17:19:59 --> Config Class Initialized
INFO - 2020-09-02 17:19:59 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:19:59 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:19:59 --> Utf8 Class Initialized
INFO - 2020-09-02 17:19:59 --> URI Class Initialized
DEBUG - 2020-09-02 17:19:59 --> No URI present. Default controller set.
INFO - 2020-09-02 17:19:59 --> Router Class Initialized
INFO - 2020-09-02 17:19:59 --> Output Class Initialized
INFO - 2020-09-02 17:19:59 --> Security Class Initialized
DEBUG - 2020-09-02 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:19:59 --> Input Class Initialized
INFO - 2020-09-02 17:19:59 --> Language Class Initialized
INFO - 2020-09-02 17:19:59 --> Language Class Initialized
INFO - 2020-09-02 17:19:59 --> Config Class Initialized
INFO - 2020-09-02 17:19:59 --> Loader Class Initialized
INFO - 2020-09-02 17:19:59 --> Helper loaded: url_helper
INFO - 2020-09-02 17:19:59 --> Helper loaded: form_helper
INFO - 2020-09-02 17:19:59 --> Helper loaded: file_helper
INFO - 2020-09-02 17:19:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:19:59 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:19:59 --> Upload Class Initialized
INFO - 2020-09-02 17:19:59 --> Controller Class Initialized
DEBUG - 2020-09-02 17:19:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 17:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 17:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 17:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:19:59 --> Final output sent to browser
DEBUG - 2020-09-02 17:19:59 --> Total execution time: 0.0631
INFO - 2020-09-02 17:19:59 --> Config Class Initialized
INFO - 2020-09-02 17:19:59 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:19:59 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:19:59 --> Utf8 Class Initialized
INFO - 2020-09-02 17:19:59 --> URI Class Initialized
DEBUG - 2020-09-02 17:19:59 --> No URI present. Default controller set.
INFO - 2020-09-02 17:19:59 --> Router Class Initialized
INFO - 2020-09-02 17:19:59 --> Output Class Initialized
INFO - 2020-09-02 17:19:59 --> Security Class Initialized
DEBUG - 2020-09-02 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:19:59 --> Input Class Initialized
INFO - 2020-09-02 17:19:59 --> Language Class Initialized
INFO - 2020-09-02 17:19:59 --> Language Class Initialized
INFO - 2020-09-02 17:19:59 --> Config Class Initialized
INFO - 2020-09-02 17:19:59 --> Loader Class Initialized
INFO - 2020-09-02 17:19:59 --> Helper loaded: url_helper
INFO - 2020-09-02 17:19:59 --> Helper loaded: form_helper
INFO - 2020-09-02 17:19:59 --> Helper loaded: file_helper
INFO - 2020-09-02 17:19:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:19:59 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:19:59 --> Upload Class Initialized
INFO - 2020-09-02 17:19:59 --> Controller Class Initialized
DEBUG - 2020-09-02 17:19:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 17:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 17:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 17:19:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:19:59 --> Final output sent to browser
DEBUG - 2020-09-02 17:19:59 --> Total execution time: 0.0537
INFO - 2020-09-02 17:33:42 --> Config Class Initialized
INFO - 2020-09-02 17:33:42 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:33:42 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:33:42 --> Utf8 Class Initialized
INFO - 2020-09-02 17:33:42 --> URI Class Initialized
DEBUG - 2020-09-02 17:33:42 --> No URI present. Default controller set.
INFO - 2020-09-02 17:33:42 --> Router Class Initialized
INFO - 2020-09-02 17:33:42 --> Config Class Initialized
INFO - 2020-09-02 17:33:42 --> Hooks Class Initialized
INFO - 2020-09-02 17:33:42 --> Output Class Initialized
DEBUG - 2020-09-02 17:33:42 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:33:42 --> Utf8 Class Initialized
INFO - 2020-09-02 17:33:42 --> Security Class Initialized
INFO - 2020-09-02 17:33:42 --> URI Class Initialized
DEBUG - 2020-09-02 17:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:33:42 --> Input Class Initialized
INFO - 2020-09-02 17:33:42 --> Language Class Initialized
INFO - 2020-09-02 17:33:42 --> Language Class Initialized
INFO - 2020-09-02 17:33:42 --> Config Class Initialized
DEBUG - 2020-09-02 17:33:42 --> No URI present. Default controller set.
INFO - 2020-09-02 17:33:42 --> Router Class Initialized
INFO - 2020-09-02 17:33:42 --> Output Class Initialized
INFO - 2020-09-02 17:33:42 --> Loader Class Initialized
INFO - 2020-09-02 17:33:42 --> Security Class Initialized
INFO - 2020-09-02 17:33:42 --> Helper loaded: url_helper
DEBUG - 2020-09-02 17:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:33:42 --> Input Class Initialized
INFO - 2020-09-02 17:33:42 --> Language Class Initialized
INFO - 2020-09-02 17:33:42 --> Language Class Initialized
INFO - 2020-09-02 17:33:42 --> Config Class Initialized
INFO - 2020-09-02 17:33:42 --> Helper loaded: form_helper
INFO - 2020-09-02 17:33:42 --> Helper loaded: file_helper
INFO - 2020-09-02 17:33:42 --> Loader Class Initialized
INFO - 2020-09-02 17:33:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:33:42 --> Helper loaded: url_helper
INFO - 2020-09-02 17:33:42 --> Helper loaded: form_helper
INFO - 2020-09-02 17:33:42 --> Helper loaded: file_helper
INFO - 2020-09-02 17:33:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:33:42 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:33:42 --> Database Driver Class Initialized
INFO - 2020-09-02 17:33:42 --> Upload Class Initialized
DEBUG - 2020-09-02 17:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:33:42 --> Upload Class Initialized
INFO - 2020-09-02 17:33:42 --> Controller Class Initialized
DEBUG - 2020-09-02 17:33:42 --> Home MX_Controller Initialized
INFO - 2020-09-02 17:33:42 --> Controller Class Initialized
DEBUG - 2020-09-02 17:33:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 17:33:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 17:33:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 17:33:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:33:42 --> Final output sent to browser
DEBUG - 2020-09-02 17:33:42 --> Total execution time: 0.0865
DEBUG - 2020-09-02 17:33:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 17:33:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 17:33:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:33:42 --> Final output sent to browser
DEBUG - 2020-09-02 17:33:42 --> Total execution time: 0.0819
INFO - 2020-09-02 17:33:43 --> Config Class Initialized
INFO - 2020-09-02 17:33:43 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:33:43 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:33:43 --> Utf8 Class Initialized
INFO - 2020-09-02 17:33:43 --> URI Class Initialized
DEBUG - 2020-09-02 17:33:43 --> No URI present. Default controller set.
INFO - 2020-09-02 17:33:43 --> Router Class Initialized
INFO - 2020-09-02 17:33:43 --> Output Class Initialized
INFO - 2020-09-02 17:33:43 --> Security Class Initialized
DEBUG - 2020-09-02 17:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:33:43 --> Input Class Initialized
INFO - 2020-09-02 17:33:43 --> Language Class Initialized
INFO - 2020-09-02 17:33:43 --> Language Class Initialized
INFO - 2020-09-02 17:33:43 --> Config Class Initialized
INFO - 2020-09-02 17:33:43 --> Loader Class Initialized
INFO - 2020-09-02 17:33:43 --> Helper loaded: url_helper
INFO - 2020-09-02 17:33:43 --> Helper loaded: form_helper
INFO - 2020-09-02 17:33:43 --> Helper loaded: file_helper
INFO - 2020-09-02 17:33:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:33:43 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:33:43 --> Upload Class Initialized
INFO - 2020-09-02 17:33:43 --> Controller Class Initialized
DEBUG - 2020-09-02 17:33:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 17:33:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 17:33:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 17:33:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:33:43 --> Final output sent to browser
DEBUG - 2020-09-02 17:33:43 --> Total execution time: 0.0520
INFO - 2020-09-02 17:34:36 --> Config Class Initialized
INFO - 2020-09-02 17:34:36 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:34:36 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:34:36 --> Utf8 Class Initialized
INFO - 2020-09-02 17:34:36 --> URI Class Initialized
DEBUG - 2020-09-02 17:34:36 --> No URI present. Default controller set.
INFO - 2020-09-02 17:34:36 --> Router Class Initialized
INFO - 2020-09-02 17:34:36 --> Output Class Initialized
INFO - 2020-09-02 17:34:36 --> Security Class Initialized
DEBUG - 2020-09-02 17:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:34:36 --> Input Class Initialized
INFO - 2020-09-02 17:34:36 --> Language Class Initialized
INFO - 2020-09-02 17:34:36 --> Language Class Initialized
INFO - 2020-09-02 17:34:36 --> Config Class Initialized
INFO - 2020-09-02 17:34:36 --> Loader Class Initialized
INFO - 2020-09-02 17:34:36 --> Helper loaded: url_helper
INFO - 2020-09-02 17:34:36 --> Helper loaded: form_helper
INFO - 2020-09-02 17:34:36 --> Helper loaded: file_helper
INFO - 2020-09-02 17:34:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:34:36 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:34:36 --> Upload Class Initialized
INFO - 2020-09-02 17:34:36 --> Controller Class Initialized
DEBUG - 2020-09-02 17:34:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 17:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 17:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 17:34:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:34:36 --> Final output sent to browser
DEBUG - 2020-09-02 17:34:36 --> Total execution time: 0.0536
INFO - 2020-09-02 17:51:55 --> Config Class Initialized
INFO - 2020-09-02 17:51:55 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:51:55 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:51:55 --> Utf8 Class Initialized
INFO - 2020-09-02 17:51:55 --> URI Class Initialized
INFO - 2020-09-02 17:51:55 --> Router Class Initialized
INFO - 2020-09-02 17:51:55 --> Output Class Initialized
INFO - 2020-09-02 17:51:55 --> Security Class Initialized
DEBUG - 2020-09-02 17:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:51:55 --> Input Class Initialized
INFO - 2020-09-02 17:51:55 --> Language Class Initialized
INFO - 2020-09-02 17:51:55 --> Language Class Initialized
INFO - 2020-09-02 17:51:55 --> Config Class Initialized
INFO - 2020-09-02 17:51:55 --> Loader Class Initialized
INFO - 2020-09-02 17:51:55 --> Helper loaded: url_helper
INFO - 2020-09-02 17:51:55 --> Helper loaded: form_helper
INFO - 2020-09-02 17:51:55 --> Helper loaded: file_helper
INFO - 2020-09-02 17:51:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:51:55 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:51:55 --> Upload Class Initialized
INFO - 2020-09-02 17:51:55 --> Controller Class Initialized
DEBUG - 2020-09-02 17:51:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 17:51:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-02 17:51:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 17:51:55 --> Final output sent to browser
DEBUG - 2020-09-02 17:51:55 --> Total execution time: 0.0507
INFO - 2020-09-02 17:52:01 --> Config Class Initialized
INFO - 2020-09-02 17:52:01 --> Hooks Class Initialized
DEBUG - 2020-09-02 17:52:01 --> UTF-8 Support Enabled
INFO - 2020-09-02 17:52:01 --> Utf8 Class Initialized
INFO - 2020-09-02 17:52:01 --> URI Class Initialized
INFO - 2020-09-02 17:52:01 --> Router Class Initialized
INFO - 2020-09-02 17:52:01 --> Output Class Initialized
INFO - 2020-09-02 17:52:01 --> Security Class Initialized
DEBUG - 2020-09-02 17:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 17:52:01 --> Input Class Initialized
INFO - 2020-09-02 17:52:01 --> Language Class Initialized
INFO - 2020-09-02 17:52:01 --> Language Class Initialized
INFO - 2020-09-02 17:52:01 --> Config Class Initialized
INFO - 2020-09-02 17:52:01 --> Loader Class Initialized
INFO - 2020-09-02 17:52:01 --> Helper loaded: url_helper
INFO - 2020-09-02 17:52:01 --> Helper loaded: form_helper
INFO - 2020-09-02 17:52:01 --> Helper loaded: file_helper
INFO - 2020-09-02 17:52:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 17:52:01 --> Database Driver Class Initialized
DEBUG - 2020-09-02 17:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 17:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 17:52:01 --> Upload Class Initialized
INFO - 2020-09-02 17:52:01 --> Controller Class Initialized
ERROR - 2020-09-02 17:52:01 --> 404 Page Not Found: /index
INFO - 2020-09-02 18:08:03 --> Config Class Initialized
INFO - 2020-09-02 18:08:03 --> Hooks Class Initialized
DEBUG - 2020-09-02 18:08:03 --> UTF-8 Support Enabled
INFO - 2020-09-02 18:08:03 --> Utf8 Class Initialized
INFO - 2020-09-02 18:08:03 --> URI Class Initialized
INFO - 2020-09-02 18:08:03 --> Router Class Initialized
INFO - 2020-09-02 18:08:03 --> Output Class Initialized
INFO - 2020-09-02 18:08:03 --> Security Class Initialized
DEBUG - 2020-09-02 18:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 18:08:03 --> Input Class Initialized
INFO - 2020-09-02 18:08:03 --> Language Class Initialized
INFO - 2020-09-02 18:08:03 --> Language Class Initialized
INFO - 2020-09-02 18:08:03 --> Config Class Initialized
INFO - 2020-09-02 18:08:03 --> Loader Class Initialized
INFO - 2020-09-02 18:08:03 --> Helper loaded: url_helper
INFO - 2020-09-02 18:08:03 --> Helper loaded: form_helper
INFO - 2020-09-02 18:08:03 --> Helper loaded: file_helper
INFO - 2020-09-02 18:08:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 18:08:03 --> Database Driver Class Initialized
DEBUG - 2020-09-02 18:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 18:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 18:08:03 --> Upload Class Initialized
INFO - 2020-09-02 18:08:03 --> Controller Class Initialized
DEBUG - 2020-09-02 18:08:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 18:08:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-02 18:08:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 18:08:03 --> Final output sent to browser
DEBUG - 2020-09-02 18:08:03 --> Total execution time: 0.1480
INFO - 2020-09-02 18:08:06 --> Config Class Initialized
INFO - 2020-09-02 18:08:06 --> Hooks Class Initialized
DEBUG - 2020-09-02 18:08:06 --> UTF-8 Support Enabled
INFO - 2020-09-02 18:08:06 --> Utf8 Class Initialized
INFO - 2020-09-02 18:08:06 --> URI Class Initialized
INFO - 2020-09-02 18:08:06 --> Router Class Initialized
INFO - 2020-09-02 18:08:06 --> Output Class Initialized
INFO - 2020-09-02 18:08:06 --> Security Class Initialized
DEBUG - 2020-09-02 18:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 18:08:06 --> Input Class Initialized
INFO - 2020-09-02 18:08:06 --> Language Class Initialized
INFO - 2020-09-02 18:08:06 --> Language Class Initialized
INFO - 2020-09-02 18:08:06 --> Config Class Initialized
INFO - 2020-09-02 18:08:06 --> Loader Class Initialized
INFO - 2020-09-02 18:08:06 --> Helper loaded: url_helper
INFO - 2020-09-02 18:08:06 --> Helper loaded: form_helper
INFO - 2020-09-02 18:08:06 --> Helper loaded: file_helper
INFO - 2020-09-02 18:08:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 18:08:06 --> Database Driver Class Initialized
DEBUG - 2020-09-02 18:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 18:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 18:08:06 --> Upload Class Initialized
INFO - 2020-09-02 18:08:06 --> Controller Class Initialized
ERROR - 2020-09-02 18:08:06 --> 404 Page Not Found: /index
INFO - 2020-09-02 18:14:08 --> Config Class Initialized
INFO - 2020-09-02 18:14:08 --> Hooks Class Initialized
DEBUG - 2020-09-02 18:14:08 --> UTF-8 Support Enabled
INFO - 2020-09-02 18:14:08 --> Utf8 Class Initialized
INFO - 2020-09-02 18:14:08 --> URI Class Initialized
DEBUG - 2020-09-02 18:14:08 --> No URI present. Default controller set.
INFO - 2020-09-02 18:14:08 --> Router Class Initialized
INFO - 2020-09-02 18:14:08 --> Output Class Initialized
INFO - 2020-09-02 18:14:08 --> Security Class Initialized
DEBUG - 2020-09-02 18:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 18:14:08 --> Input Class Initialized
INFO - 2020-09-02 18:14:08 --> Language Class Initialized
INFO - 2020-09-02 18:14:08 --> Language Class Initialized
INFO - 2020-09-02 18:14:08 --> Config Class Initialized
INFO - 2020-09-02 18:14:08 --> Loader Class Initialized
INFO - 2020-09-02 18:14:08 --> Helper loaded: url_helper
INFO - 2020-09-02 18:14:08 --> Helper loaded: form_helper
INFO - 2020-09-02 18:14:08 --> Helper loaded: file_helper
INFO - 2020-09-02 18:14:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 18:14:08 --> Database Driver Class Initialized
DEBUG - 2020-09-02 18:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 18:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 18:14:08 --> Upload Class Initialized
INFO - 2020-09-02 18:14:08 --> Controller Class Initialized
DEBUG - 2020-09-02 18:14:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 18:14:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 18:14:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 18:14:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 18:14:08 --> Final output sent to browser
DEBUG - 2020-09-02 18:14:08 --> Total execution time: 0.0533
INFO - 2020-09-02 19:00:03 --> Config Class Initialized
INFO - 2020-09-02 19:00:03 --> Hooks Class Initialized
DEBUG - 2020-09-02 19:00:03 --> UTF-8 Support Enabled
INFO - 2020-09-02 19:00:03 --> Utf8 Class Initialized
INFO - 2020-09-02 19:00:03 --> URI Class Initialized
DEBUG - 2020-09-02 19:00:03 --> No URI present. Default controller set.
INFO - 2020-09-02 19:00:03 --> Router Class Initialized
INFO - 2020-09-02 19:00:03 --> Output Class Initialized
INFO - 2020-09-02 19:00:03 --> Security Class Initialized
DEBUG - 2020-09-02 19:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 19:00:03 --> Input Class Initialized
INFO - 2020-09-02 19:00:03 --> Language Class Initialized
INFO - 2020-09-02 19:00:03 --> Language Class Initialized
INFO - 2020-09-02 19:00:03 --> Config Class Initialized
INFO - 2020-09-02 19:00:03 --> Loader Class Initialized
INFO - 2020-09-02 19:00:03 --> Helper loaded: url_helper
INFO - 2020-09-02 19:00:03 --> Helper loaded: form_helper
INFO - 2020-09-02 19:00:03 --> Helper loaded: file_helper
INFO - 2020-09-02 19:00:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 19:00:03 --> Database Driver Class Initialized
DEBUG - 2020-09-02 19:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 19:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 19:00:03 --> Upload Class Initialized
INFO - 2020-09-02 19:00:03 --> Controller Class Initialized
DEBUG - 2020-09-02 19:00:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 19:00:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 19:00:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 19:00:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 19:00:03 --> Final output sent to browser
DEBUG - 2020-09-02 19:00:03 --> Total execution time: 0.5326
INFO - 2020-09-02 19:00:04 --> Config Class Initialized
INFO - 2020-09-02 19:00:04 --> Hooks Class Initialized
DEBUG - 2020-09-02 19:00:04 --> UTF-8 Support Enabled
INFO - 2020-09-02 19:00:04 --> Utf8 Class Initialized
INFO - 2020-09-02 19:00:04 --> URI Class Initialized
INFO - 2020-09-02 19:00:04 --> Router Class Initialized
INFO - 2020-09-02 19:00:04 --> Output Class Initialized
INFO - 2020-09-02 19:00:04 --> Security Class Initialized
DEBUG - 2020-09-02 19:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 19:00:04 --> Input Class Initialized
INFO - 2020-09-02 19:00:04 --> Language Class Initialized
INFO - 2020-09-02 19:00:04 --> Language Class Initialized
INFO - 2020-09-02 19:00:04 --> Config Class Initialized
INFO - 2020-09-02 19:00:04 --> Loader Class Initialized
INFO - 2020-09-02 19:00:04 --> Helper loaded: url_helper
INFO - 2020-09-02 19:00:04 --> Helper loaded: form_helper
INFO - 2020-09-02 19:00:04 --> Helper loaded: file_helper
INFO - 2020-09-02 19:00:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 19:00:04 --> Database Driver Class Initialized
DEBUG - 2020-09-02 19:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 19:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 19:00:04 --> Upload Class Initialized
INFO - 2020-09-02 19:00:04 --> Controller Class Initialized
ERROR - 2020-09-02 19:00:04 --> 404 Page Not Found: /index
INFO - 2020-09-02 19:59:51 --> Config Class Initialized
INFO - 2020-09-02 19:59:51 --> Hooks Class Initialized
DEBUG - 2020-09-02 19:59:51 --> UTF-8 Support Enabled
INFO - 2020-09-02 19:59:51 --> Utf8 Class Initialized
INFO - 2020-09-02 19:59:51 --> URI Class Initialized
INFO - 2020-09-02 19:59:51 --> Router Class Initialized
INFO - 2020-09-02 19:59:51 --> Output Class Initialized
INFO - 2020-09-02 19:59:51 --> Security Class Initialized
DEBUG - 2020-09-02 19:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 19:59:51 --> Input Class Initialized
INFO - 2020-09-02 19:59:51 --> Language Class Initialized
INFO - 2020-09-02 19:59:51 --> Language Class Initialized
INFO - 2020-09-02 19:59:51 --> Config Class Initialized
INFO - 2020-09-02 19:59:51 --> Loader Class Initialized
INFO - 2020-09-02 19:59:51 --> Helper loaded: url_helper
INFO - 2020-09-02 19:59:51 --> Helper loaded: form_helper
INFO - 2020-09-02 19:59:51 --> Helper loaded: file_helper
INFO - 2020-09-02 19:59:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 19:59:51 --> Database Driver Class Initialized
DEBUG - 2020-09-02 19:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 19:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 19:59:51 --> Upload Class Initialized
INFO - 2020-09-02 19:59:51 --> Controller Class Initialized
ERROR - 2020-09-02 19:59:51 --> 404 Page Not Found: /index
INFO - 2020-09-02 19:59:52 --> Config Class Initialized
INFO - 2020-09-02 19:59:52 --> Hooks Class Initialized
DEBUG - 2020-09-02 19:59:52 --> UTF-8 Support Enabled
INFO - 2020-09-02 19:59:52 --> Utf8 Class Initialized
INFO - 2020-09-02 19:59:52 --> URI Class Initialized
DEBUG - 2020-09-02 19:59:52 --> No URI present. Default controller set.
INFO - 2020-09-02 19:59:52 --> Router Class Initialized
INFO - 2020-09-02 19:59:52 --> Output Class Initialized
INFO - 2020-09-02 19:59:52 --> Security Class Initialized
DEBUG - 2020-09-02 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 19:59:52 --> Input Class Initialized
INFO - 2020-09-02 19:59:52 --> Language Class Initialized
INFO - 2020-09-02 19:59:52 --> Language Class Initialized
INFO - 2020-09-02 19:59:52 --> Config Class Initialized
INFO - 2020-09-02 19:59:52 --> Loader Class Initialized
INFO - 2020-09-02 19:59:52 --> Helper loaded: url_helper
INFO - 2020-09-02 19:59:52 --> Helper loaded: form_helper
INFO - 2020-09-02 19:59:52 --> Helper loaded: file_helper
INFO - 2020-09-02 19:59:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 19:59:52 --> Database Driver Class Initialized
DEBUG - 2020-09-02 19:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 19:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 19:59:52 --> Upload Class Initialized
INFO - 2020-09-02 19:59:52 --> Controller Class Initialized
DEBUG - 2020-09-02 19:59:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 19:59:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 19:59:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 19:59:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 19:59:52 --> Final output sent to browser
DEBUG - 2020-09-02 19:59:52 --> Total execution time: 0.0673
INFO - 2020-09-02 21:12:26 --> Config Class Initialized
INFO - 2020-09-02 21:12:26 --> Hooks Class Initialized
DEBUG - 2020-09-02 21:12:26 --> UTF-8 Support Enabled
INFO - 2020-09-02 21:12:26 --> Utf8 Class Initialized
INFO - 2020-09-02 21:12:26 --> URI Class Initialized
INFO - 2020-09-02 21:12:26 --> Router Class Initialized
INFO - 2020-09-02 21:12:26 --> Output Class Initialized
INFO - 2020-09-02 21:12:26 --> Security Class Initialized
DEBUG - 2020-09-02 21:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 21:12:26 --> Input Class Initialized
INFO - 2020-09-02 21:12:26 --> Language Class Initialized
INFO - 2020-09-02 21:12:26 --> Language Class Initialized
INFO - 2020-09-02 21:12:26 --> Config Class Initialized
INFO - 2020-09-02 21:12:26 --> Loader Class Initialized
INFO - 2020-09-02 21:12:26 --> Helper loaded: url_helper
INFO - 2020-09-02 21:12:26 --> Helper loaded: form_helper
INFO - 2020-09-02 21:12:26 --> Helper loaded: file_helper
INFO - 2020-09-02 21:12:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 21:12:26 --> Database Driver Class Initialized
DEBUG - 2020-09-02 21:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 21:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 21:12:26 --> Upload Class Initialized
INFO - 2020-09-02 21:12:26 --> Controller Class Initialized
ERROR - 2020-09-02 21:12:26 --> 404 Page Not Found: /index
INFO - 2020-09-02 21:24:04 --> Config Class Initialized
INFO - 2020-09-02 21:24:04 --> Hooks Class Initialized
DEBUG - 2020-09-02 21:24:04 --> UTF-8 Support Enabled
INFO - 2020-09-02 21:24:04 --> Utf8 Class Initialized
INFO - 2020-09-02 21:24:04 --> URI Class Initialized
DEBUG - 2020-09-02 21:24:04 --> No URI present. Default controller set.
INFO - 2020-09-02 21:24:04 --> Router Class Initialized
INFO - 2020-09-02 21:24:04 --> Output Class Initialized
INFO - 2020-09-02 21:24:04 --> Security Class Initialized
DEBUG - 2020-09-02 21:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 21:24:04 --> Input Class Initialized
INFO - 2020-09-02 21:24:04 --> Language Class Initialized
INFO - 2020-09-02 21:24:04 --> Language Class Initialized
INFO - 2020-09-02 21:24:04 --> Config Class Initialized
INFO - 2020-09-02 21:24:04 --> Loader Class Initialized
INFO - 2020-09-02 21:24:04 --> Helper loaded: url_helper
INFO - 2020-09-02 21:24:04 --> Helper loaded: form_helper
INFO - 2020-09-02 21:24:04 --> Helper loaded: file_helper
INFO - 2020-09-02 21:24:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 21:24:04 --> Database Driver Class Initialized
DEBUG - 2020-09-02 21:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 21:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 21:24:04 --> Upload Class Initialized
INFO - 2020-09-02 21:24:04 --> Controller Class Initialized
DEBUG - 2020-09-02 21:24:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 21:24:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 21:24:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 21:24:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 21:24:04 --> Final output sent to browser
DEBUG - 2020-09-02 21:24:04 --> Total execution time: 0.3376
INFO - 2020-09-02 22:58:16 --> Config Class Initialized
INFO - 2020-09-02 22:58:16 --> Hooks Class Initialized
DEBUG - 2020-09-02 22:58:16 --> UTF-8 Support Enabled
INFO - 2020-09-02 22:58:16 --> Utf8 Class Initialized
INFO - 2020-09-02 22:58:16 --> URI Class Initialized
INFO - 2020-09-02 22:58:16 --> Router Class Initialized
INFO - 2020-09-02 22:58:16 --> Output Class Initialized
INFO - 2020-09-02 22:58:16 --> Security Class Initialized
DEBUG - 2020-09-02 22:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 22:58:16 --> Input Class Initialized
INFO - 2020-09-02 22:58:16 --> Language Class Initialized
INFO - 2020-09-02 22:58:16 --> Language Class Initialized
INFO - 2020-09-02 22:58:16 --> Config Class Initialized
INFO - 2020-09-02 22:58:16 --> Loader Class Initialized
INFO - 2020-09-02 22:58:16 --> Helper loaded: url_helper
INFO - 2020-09-02 22:58:16 --> Helper loaded: form_helper
INFO - 2020-09-02 22:58:16 --> Helper loaded: file_helper
INFO - 2020-09-02 22:58:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 22:58:16 --> Database Driver Class Initialized
DEBUG - 2020-09-02 22:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 22:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 22:58:16 --> Upload Class Initialized
INFO - 2020-09-02 22:58:16 --> Controller Class Initialized
DEBUG - 2020-09-02 22:58:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 22:58:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-02 22:58:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 22:58:16 --> Final output sent to browser
DEBUG - 2020-09-02 22:58:16 --> Total execution time: 0.1479
INFO - 2020-09-02 22:58:18 --> Config Class Initialized
INFO - 2020-09-02 22:58:18 --> Hooks Class Initialized
DEBUG - 2020-09-02 22:58:18 --> UTF-8 Support Enabled
INFO - 2020-09-02 22:58:18 --> Utf8 Class Initialized
INFO - 2020-09-02 22:58:18 --> URI Class Initialized
INFO - 2020-09-02 22:58:18 --> Router Class Initialized
INFO - 2020-09-02 22:58:18 --> Output Class Initialized
INFO - 2020-09-02 22:58:18 --> Security Class Initialized
DEBUG - 2020-09-02 22:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 22:58:18 --> Input Class Initialized
INFO - 2020-09-02 22:58:18 --> Language Class Initialized
INFO - 2020-09-02 22:58:18 --> Language Class Initialized
INFO - 2020-09-02 22:58:18 --> Config Class Initialized
INFO - 2020-09-02 22:58:18 --> Loader Class Initialized
INFO - 2020-09-02 22:58:18 --> Helper loaded: url_helper
INFO - 2020-09-02 22:58:18 --> Helper loaded: form_helper
INFO - 2020-09-02 22:58:18 --> Helper loaded: file_helper
INFO - 2020-09-02 22:58:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 22:58:18 --> Database Driver Class Initialized
DEBUG - 2020-09-02 22:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 22:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 22:58:18 --> Upload Class Initialized
INFO - 2020-09-02 22:58:18 --> Controller Class Initialized
ERROR - 2020-09-02 22:58:18 --> 404 Page Not Found: /index
INFO - 2020-09-02 23:13:54 --> Config Class Initialized
INFO - 2020-09-02 23:13:54 --> Hooks Class Initialized
DEBUG - 2020-09-02 23:13:54 --> UTF-8 Support Enabled
INFO - 2020-09-02 23:13:54 --> Utf8 Class Initialized
INFO - 2020-09-02 23:13:54 --> URI Class Initialized
INFO - 2020-09-02 23:13:54 --> Router Class Initialized
INFO - 2020-09-02 23:13:54 --> Output Class Initialized
INFO - 2020-09-02 23:13:54 --> Security Class Initialized
DEBUG - 2020-09-02 23:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 23:13:54 --> Input Class Initialized
INFO - 2020-09-02 23:13:54 --> Language Class Initialized
INFO - 2020-09-02 23:13:54 --> Language Class Initialized
INFO - 2020-09-02 23:13:54 --> Config Class Initialized
INFO - 2020-09-02 23:13:54 --> Loader Class Initialized
INFO - 2020-09-02 23:13:54 --> Helper loaded: url_helper
INFO - 2020-09-02 23:13:54 --> Helper loaded: form_helper
INFO - 2020-09-02 23:13:54 --> Helper loaded: file_helper
INFO - 2020-09-02 23:13:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 23:13:54 --> Database Driver Class Initialized
DEBUG - 2020-09-02 23:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 23:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 23:13:54 --> Upload Class Initialized
INFO - 2020-09-02 23:13:54 --> Controller Class Initialized
ERROR - 2020-09-02 23:13:54 --> 404 Page Not Found: /index
INFO - 2020-09-02 23:13:54 --> Config Class Initialized
INFO - 2020-09-02 23:13:54 --> Hooks Class Initialized
DEBUG - 2020-09-02 23:13:54 --> UTF-8 Support Enabled
INFO - 2020-09-02 23:13:54 --> Utf8 Class Initialized
INFO - 2020-09-02 23:13:54 --> URI Class Initialized
DEBUG - 2020-09-02 23:13:54 --> No URI present. Default controller set.
INFO - 2020-09-02 23:13:54 --> Router Class Initialized
INFO - 2020-09-02 23:13:54 --> Output Class Initialized
INFO - 2020-09-02 23:13:54 --> Security Class Initialized
DEBUG - 2020-09-02 23:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 23:13:54 --> Input Class Initialized
INFO - 2020-09-02 23:13:54 --> Language Class Initialized
INFO - 2020-09-02 23:13:54 --> Language Class Initialized
INFO - 2020-09-02 23:13:54 --> Config Class Initialized
INFO - 2020-09-02 23:13:54 --> Loader Class Initialized
INFO - 2020-09-02 23:13:54 --> Helper loaded: url_helper
INFO - 2020-09-02 23:13:54 --> Helper loaded: form_helper
INFO - 2020-09-02 23:13:54 --> Helper loaded: file_helper
INFO - 2020-09-02 23:13:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 23:13:54 --> Database Driver Class Initialized
DEBUG - 2020-09-02 23:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 23:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 23:13:54 --> Upload Class Initialized
INFO - 2020-09-02 23:13:54 --> Controller Class Initialized
DEBUG - 2020-09-02 23:13:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-02 23:13:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-02 23:13:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-02 23:13:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-02 23:13:54 --> Final output sent to browser
DEBUG - 2020-09-02 23:13:54 --> Total execution time: 0.0614
INFO - 2020-09-02 23:14:12 --> Config Class Initialized
INFO - 2020-09-02 23:14:12 --> Hooks Class Initialized
DEBUG - 2020-09-02 23:14:12 --> UTF-8 Support Enabled
INFO - 2020-09-02 23:14:12 --> Utf8 Class Initialized
INFO - 2020-09-02 23:14:12 --> URI Class Initialized
INFO - 2020-09-02 23:14:12 --> Router Class Initialized
INFO - 2020-09-02 23:14:12 --> Output Class Initialized
INFO - 2020-09-02 23:14:12 --> Security Class Initialized
DEBUG - 2020-09-02 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 23:14:12 --> Input Class Initialized
INFO - 2020-09-02 23:14:12 --> Language Class Initialized
INFO - 2020-09-02 23:14:12 --> Language Class Initialized
INFO - 2020-09-02 23:14:12 --> Config Class Initialized
INFO - 2020-09-02 23:14:12 --> Loader Class Initialized
INFO - 2020-09-02 23:14:12 --> Helper loaded: url_helper
INFO - 2020-09-02 23:14:12 --> Helper loaded: form_helper
INFO - 2020-09-02 23:14:12 --> Helper loaded: file_helper
INFO - 2020-09-02 23:14:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-02 23:14:12 --> Database Driver Class Initialized
DEBUG - 2020-09-02 23:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-02 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 23:14:12 --> Upload Class Initialized
INFO - 2020-09-02 23:14:12 --> Controller Class Initialized
ERROR - 2020-09-02 23:14:12 --> 404 Page Not Found: /index
