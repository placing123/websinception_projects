<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-03 00:18:09 --> Config Class Initialized
INFO - 2020-09-03 00:18:09 --> Hooks Class Initialized
DEBUG - 2020-09-03 00:18:09 --> UTF-8 Support Enabled
INFO - 2020-09-03 00:18:09 --> Utf8 Class Initialized
INFO - 2020-09-03 00:18:09 --> URI Class Initialized
DEBUG - 2020-09-03 00:18:09 --> No URI present. Default controller set.
INFO - 2020-09-03 00:18:09 --> Router Class Initialized
INFO - 2020-09-03 00:18:09 --> Output Class Initialized
INFO - 2020-09-03 00:18:09 --> Security Class Initialized
DEBUG - 2020-09-03 00:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 00:18:09 --> Input Class Initialized
INFO - 2020-09-03 00:18:09 --> Language Class Initialized
INFO - 2020-09-03 00:18:09 --> Language Class Initialized
INFO - 2020-09-03 00:18:09 --> Config Class Initialized
INFO - 2020-09-03 00:18:09 --> Loader Class Initialized
INFO - 2020-09-03 00:18:09 --> Helper loaded: url_helper
INFO - 2020-09-03 00:18:09 --> Helper loaded: form_helper
INFO - 2020-09-03 00:18:09 --> Helper loaded: file_helper
INFO - 2020-09-03 00:18:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 00:18:09 --> Database Driver Class Initialized
DEBUG - 2020-09-03 00:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 00:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 00:18:09 --> Upload Class Initialized
INFO - 2020-09-03 00:18:09 --> Controller Class Initialized
DEBUG - 2020-09-03 00:18:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 00:18:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 00:18:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 00:18:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 00:18:09 --> Final output sent to browser
DEBUG - 2020-09-03 00:18:09 --> Total execution time: 0.0813
INFO - 2020-09-03 01:02:46 --> Config Class Initialized
INFO - 2020-09-03 01:02:46 --> Hooks Class Initialized
DEBUG - 2020-09-03 01:02:46 --> UTF-8 Support Enabled
INFO - 2020-09-03 01:02:46 --> Utf8 Class Initialized
INFO - 2020-09-03 01:02:46 --> URI Class Initialized
INFO - 2020-09-03 01:02:46 --> Router Class Initialized
INFO - 2020-09-03 01:02:46 --> Output Class Initialized
INFO - 2020-09-03 01:02:46 --> Security Class Initialized
DEBUG - 2020-09-03 01:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 01:02:46 --> Input Class Initialized
INFO - 2020-09-03 01:02:46 --> Language Class Initialized
INFO - 2020-09-03 01:02:46 --> Language Class Initialized
INFO - 2020-09-03 01:02:46 --> Config Class Initialized
INFO - 2020-09-03 01:02:46 --> Loader Class Initialized
INFO - 2020-09-03 01:02:46 --> Helper loaded: url_helper
INFO - 2020-09-03 01:02:46 --> Helper loaded: form_helper
INFO - 2020-09-03 01:02:46 --> Helper loaded: file_helper
INFO - 2020-09-03 01:02:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 01:02:46 --> Database Driver Class Initialized
DEBUG - 2020-09-03 01:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 01:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 01:02:46 --> Upload Class Initialized
INFO - 2020-09-03 01:02:46 --> Controller Class Initialized
ERROR - 2020-09-03 01:02:46 --> 404 Page Not Found: /index
INFO - 2020-09-03 01:02:47 --> Config Class Initialized
INFO - 2020-09-03 01:02:47 --> Hooks Class Initialized
DEBUG - 2020-09-03 01:02:47 --> UTF-8 Support Enabled
INFO - 2020-09-03 01:02:47 --> Utf8 Class Initialized
INFO - 2020-09-03 01:02:47 --> URI Class Initialized
DEBUG - 2020-09-03 01:02:47 --> No URI present. Default controller set.
INFO - 2020-09-03 01:02:47 --> Router Class Initialized
INFO - 2020-09-03 01:02:47 --> Output Class Initialized
INFO - 2020-09-03 01:02:47 --> Security Class Initialized
DEBUG - 2020-09-03 01:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 01:02:47 --> Input Class Initialized
INFO - 2020-09-03 01:02:47 --> Language Class Initialized
INFO - 2020-09-03 01:02:47 --> Language Class Initialized
INFO - 2020-09-03 01:02:47 --> Config Class Initialized
INFO - 2020-09-03 01:02:47 --> Loader Class Initialized
INFO - 2020-09-03 01:02:47 --> Helper loaded: url_helper
INFO - 2020-09-03 01:02:47 --> Helper loaded: form_helper
INFO - 2020-09-03 01:02:47 --> Helper loaded: file_helper
INFO - 2020-09-03 01:02:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 01:02:47 --> Database Driver Class Initialized
DEBUG - 2020-09-03 01:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 01:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 01:02:47 --> Upload Class Initialized
INFO - 2020-09-03 01:02:47 --> Controller Class Initialized
DEBUG - 2020-09-03 01:02:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 01:02:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 01:02:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 01:02:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 01:02:47 --> Final output sent to browser
DEBUG - 2020-09-03 01:02:47 --> Total execution time: 0.0585
INFO - 2020-09-03 01:30:51 --> Config Class Initialized
INFO - 2020-09-03 01:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-03 01:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-03 01:30:51 --> Utf8 Class Initialized
INFO - 2020-09-03 01:30:51 --> URI Class Initialized
DEBUG - 2020-09-03 01:30:51 --> No URI present. Default controller set.
INFO - 2020-09-03 01:30:51 --> Router Class Initialized
INFO - 2020-09-03 01:30:51 --> Output Class Initialized
INFO - 2020-09-03 01:30:51 --> Security Class Initialized
DEBUG - 2020-09-03 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 01:30:51 --> Input Class Initialized
INFO - 2020-09-03 01:30:51 --> Language Class Initialized
INFO - 2020-09-03 01:30:51 --> Language Class Initialized
INFO - 2020-09-03 01:30:51 --> Config Class Initialized
INFO - 2020-09-03 01:30:51 --> Loader Class Initialized
INFO - 2020-09-03 01:30:51 --> Helper loaded: url_helper
INFO - 2020-09-03 01:30:51 --> Helper loaded: form_helper
INFO - 2020-09-03 01:30:51 --> Helper loaded: file_helper
INFO - 2020-09-03 01:30:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 01:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-03 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 01:30:51 --> Upload Class Initialized
INFO - 2020-09-03 01:30:51 --> Controller Class Initialized
DEBUG - 2020-09-03 01:30:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 01:30:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 01:30:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 01:30:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 01:30:51 --> Final output sent to browser
DEBUG - 2020-09-03 01:30:51 --> Total execution time: 0.0755
INFO - 2020-09-03 02:27:30 --> Config Class Initialized
INFO - 2020-09-03 02:27:30 --> Hooks Class Initialized
DEBUG - 2020-09-03 02:27:30 --> UTF-8 Support Enabled
INFO - 2020-09-03 02:27:30 --> Utf8 Class Initialized
INFO - 2020-09-03 02:27:30 --> URI Class Initialized
INFO - 2020-09-03 02:27:30 --> Router Class Initialized
INFO - 2020-09-03 02:27:30 --> Output Class Initialized
INFO - 2020-09-03 02:27:30 --> Security Class Initialized
DEBUG - 2020-09-03 02:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 02:27:30 --> Input Class Initialized
INFO - 2020-09-03 02:27:30 --> Language Class Initialized
INFO - 2020-09-03 02:27:30 --> Language Class Initialized
INFO - 2020-09-03 02:27:30 --> Config Class Initialized
INFO - 2020-09-03 02:27:30 --> Loader Class Initialized
INFO - 2020-09-03 02:27:30 --> Helper loaded: url_helper
INFO - 2020-09-03 02:27:30 --> Helper loaded: form_helper
INFO - 2020-09-03 02:27:30 --> Helper loaded: file_helper
INFO - 2020-09-03 02:27:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 02:27:30 --> Database Driver Class Initialized
DEBUG - 2020-09-03 02:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 02:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 02:27:30 --> Upload Class Initialized
INFO - 2020-09-03 02:27:30 --> Controller Class Initialized
ERROR - 2020-09-03 02:27:30 --> 404 Page Not Found: /index
INFO - 2020-09-03 02:29:07 --> Config Class Initialized
INFO - 2020-09-03 02:29:07 --> Hooks Class Initialized
DEBUG - 2020-09-03 02:29:07 --> UTF-8 Support Enabled
INFO - 2020-09-03 02:29:07 --> Utf8 Class Initialized
INFO - 2020-09-03 02:29:07 --> URI Class Initialized
INFO - 2020-09-03 02:29:07 --> Router Class Initialized
INFO - 2020-09-03 02:29:07 --> Output Class Initialized
INFO - 2020-09-03 02:29:07 --> Security Class Initialized
DEBUG - 2020-09-03 02:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 02:29:07 --> Input Class Initialized
INFO - 2020-09-03 02:29:07 --> Language Class Initialized
INFO - 2020-09-03 02:29:07 --> Language Class Initialized
INFO - 2020-09-03 02:29:07 --> Config Class Initialized
INFO - 2020-09-03 02:29:07 --> Loader Class Initialized
INFO - 2020-09-03 02:29:07 --> Helper loaded: url_helper
INFO - 2020-09-03 02:29:07 --> Helper loaded: form_helper
INFO - 2020-09-03 02:29:07 --> Helper loaded: file_helper
INFO - 2020-09-03 02:29:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 02:29:07 --> Database Driver Class Initialized
DEBUG - 2020-09-03 02:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 02:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 02:29:07 --> Upload Class Initialized
INFO - 2020-09-03 02:29:07 --> Controller Class Initialized
ERROR - 2020-09-03 02:29:07 --> 404 Page Not Found: /index
INFO - 2020-09-03 02:32:07 --> Config Class Initialized
INFO - 2020-09-03 02:32:07 --> Hooks Class Initialized
DEBUG - 2020-09-03 02:32:07 --> UTF-8 Support Enabled
INFO - 2020-09-03 02:32:07 --> Utf8 Class Initialized
INFO - 2020-09-03 02:32:07 --> URI Class Initialized
DEBUG - 2020-09-03 02:32:07 --> No URI present. Default controller set.
INFO - 2020-09-03 02:32:07 --> Router Class Initialized
INFO - 2020-09-03 02:32:07 --> Output Class Initialized
INFO - 2020-09-03 02:32:07 --> Security Class Initialized
DEBUG - 2020-09-03 02:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 02:32:07 --> Input Class Initialized
INFO - 2020-09-03 02:32:07 --> Language Class Initialized
INFO - 2020-09-03 02:32:07 --> Language Class Initialized
INFO - 2020-09-03 02:32:07 --> Config Class Initialized
INFO - 2020-09-03 02:32:07 --> Loader Class Initialized
INFO - 2020-09-03 02:32:07 --> Helper loaded: url_helper
INFO - 2020-09-03 02:32:07 --> Helper loaded: form_helper
INFO - 2020-09-03 02:32:07 --> Helper loaded: file_helper
INFO - 2020-09-03 02:32:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 02:32:07 --> Database Driver Class Initialized
DEBUG - 2020-09-03 02:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 02:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 02:32:07 --> Upload Class Initialized
INFO - 2020-09-03 02:32:07 --> Controller Class Initialized
DEBUG - 2020-09-03 02:32:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 02:32:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 02:32:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 02:32:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 02:32:07 --> Final output sent to browser
DEBUG - 2020-09-03 02:32:07 --> Total execution time: 0.0559
INFO - 2020-09-03 04:07:26 --> Config Class Initialized
INFO - 2020-09-03 04:07:26 --> Hooks Class Initialized
DEBUG - 2020-09-03 04:07:26 --> UTF-8 Support Enabled
INFO - 2020-09-03 04:07:26 --> Utf8 Class Initialized
INFO - 2020-09-03 04:07:26 --> URI Class Initialized
INFO - 2020-09-03 04:07:26 --> Router Class Initialized
INFO - 2020-09-03 04:07:26 --> Output Class Initialized
INFO - 2020-09-03 04:07:26 --> Security Class Initialized
DEBUG - 2020-09-03 04:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 04:07:26 --> Input Class Initialized
INFO - 2020-09-03 04:07:26 --> Language Class Initialized
INFO - 2020-09-03 04:07:26 --> Language Class Initialized
INFO - 2020-09-03 04:07:26 --> Config Class Initialized
INFO - 2020-09-03 04:07:26 --> Loader Class Initialized
INFO - 2020-09-03 04:07:26 --> Helper loaded: url_helper
INFO - 2020-09-03 04:07:26 --> Helper loaded: form_helper
INFO - 2020-09-03 04:07:26 --> Helper loaded: file_helper
INFO - 2020-09-03 04:07:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 04:07:26 --> Database Driver Class Initialized
DEBUG - 2020-09-03 04:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 04:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 04:07:26 --> Upload Class Initialized
INFO - 2020-09-03 04:07:26 --> Controller Class Initialized
ERROR - 2020-09-03 04:07:26 --> 404 Page Not Found: /index
INFO - 2020-09-03 04:07:26 --> Config Class Initialized
INFO - 2020-09-03 04:07:26 --> Hooks Class Initialized
DEBUG - 2020-09-03 04:07:26 --> UTF-8 Support Enabled
INFO - 2020-09-03 04:07:26 --> Utf8 Class Initialized
INFO - 2020-09-03 04:07:26 --> URI Class Initialized
INFO - 2020-09-03 04:07:26 --> Router Class Initialized
INFO - 2020-09-03 04:07:26 --> Output Class Initialized
INFO - 2020-09-03 04:07:26 --> Security Class Initialized
DEBUG - 2020-09-03 04:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 04:07:26 --> Input Class Initialized
INFO - 2020-09-03 04:07:26 --> Language Class Initialized
INFO - 2020-09-03 04:07:26 --> Language Class Initialized
INFO - 2020-09-03 04:07:26 --> Config Class Initialized
INFO - 2020-09-03 04:07:26 --> Loader Class Initialized
INFO - 2020-09-03 04:07:26 --> Helper loaded: url_helper
INFO - 2020-09-03 04:07:26 --> Helper loaded: form_helper
INFO - 2020-09-03 04:07:26 --> Helper loaded: file_helper
INFO - 2020-09-03 04:07:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 04:07:26 --> Database Driver Class Initialized
DEBUG - 2020-09-03 04:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 04:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 04:07:26 --> Upload Class Initialized
INFO - 2020-09-03 04:07:26 --> Controller Class Initialized
ERROR - 2020-09-03 04:07:26 --> 404 Page Not Found: /index
INFO - 2020-09-03 04:07:30 --> Config Class Initialized
INFO - 2020-09-03 04:07:30 --> Hooks Class Initialized
DEBUG - 2020-09-03 04:07:30 --> UTF-8 Support Enabled
INFO - 2020-09-03 04:07:30 --> Utf8 Class Initialized
INFO - 2020-09-03 04:07:30 --> URI Class Initialized
DEBUG - 2020-09-03 04:07:30 --> No URI present. Default controller set.
INFO - 2020-09-03 04:07:30 --> Router Class Initialized
INFO - 2020-09-03 04:07:30 --> Output Class Initialized
INFO - 2020-09-03 04:07:30 --> Security Class Initialized
DEBUG - 2020-09-03 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 04:07:30 --> Input Class Initialized
INFO - 2020-09-03 04:07:30 --> Language Class Initialized
INFO - 2020-09-03 04:07:30 --> Language Class Initialized
INFO - 2020-09-03 04:07:30 --> Config Class Initialized
INFO - 2020-09-03 04:07:30 --> Loader Class Initialized
INFO - 2020-09-03 04:07:30 --> Helper loaded: url_helper
INFO - 2020-09-03 04:07:30 --> Helper loaded: form_helper
INFO - 2020-09-03 04:07:30 --> Helper loaded: file_helper
INFO - 2020-09-03 04:07:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 04:07:30 --> Database Driver Class Initialized
DEBUG - 2020-09-03 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 04:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 04:07:30 --> Upload Class Initialized
INFO - 2020-09-03 04:07:30 --> Controller Class Initialized
DEBUG - 2020-09-03 04:07:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 04:07:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 04:07:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 04:07:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 04:07:30 --> Final output sent to browser
DEBUG - 2020-09-03 04:07:30 --> Total execution time: 0.0524
INFO - 2020-09-03 04:07:30 --> Config Class Initialized
INFO - 2020-09-03 04:07:30 --> Hooks Class Initialized
DEBUG - 2020-09-03 04:07:30 --> UTF-8 Support Enabled
INFO - 2020-09-03 04:07:30 --> Utf8 Class Initialized
INFO - 2020-09-03 04:07:30 --> URI Class Initialized
DEBUG - 2020-09-03 04:07:30 --> No URI present. Default controller set.
INFO - 2020-09-03 04:07:30 --> Router Class Initialized
INFO - 2020-09-03 04:07:30 --> Output Class Initialized
INFO - 2020-09-03 04:07:30 --> Security Class Initialized
DEBUG - 2020-09-03 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 04:07:30 --> Input Class Initialized
INFO - 2020-09-03 04:07:30 --> Language Class Initialized
INFO - 2020-09-03 04:07:30 --> Language Class Initialized
INFO - 2020-09-03 04:07:30 --> Config Class Initialized
INFO - 2020-09-03 04:07:30 --> Loader Class Initialized
INFO - 2020-09-03 04:07:30 --> Helper loaded: url_helper
INFO - 2020-09-03 04:07:30 --> Helper loaded: form_helper
INFO - 2020-09-03 04:07:30 --> Helper loaded: file_helper
INFO - 2020-09-03 04:07:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 04:07:30 --> Database Driver Class Initialized
DEBUG - 2020-09-03 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 04:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 04:07:30 --> Upload Class Initialized
INFO - 2020-09-03 04:07:30 --> Controller Class Initialized
DEBUG - 2020-09-03 04:07:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 04:07:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 04:07:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 04:07:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 04:07:30 --> Final output sent to browser
DEBUG - 2020-09-03 04:07:30 --> Total execution time: 0.0552
INFO - 2020-09-03 05:47:40 --> Config Class Initialized
INFO - 2020-09-03 05:47:40 --> Hooks Class Initialized
DEBUG - 2020-09-03 05:47:40 --> UTF-8 Support Enabled
INFO - 2020-09-03 05:47:40 --> Utf8 Class Initialized
INFO - 2020-09-03 05:47:40 --> URI Class Initialized
DEBUG - 2020-09-03 05:47:40 --> No URI present. Default controller set.
INFO - 2020-09-03 05:47:40 --> Router Class Initialized
INFO - 2020-09-03 05:47:40 --> Output Class Initialized
INFO - 2020-09-03 05:47:40 --> Security Class Initialized
DEBUG - 2020-09-03 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 05:47:40 --> Input Class Initialized
INFO - 2020-09-03 05:47:40 --> Language Class Initialized
INFO - 2020-09-03 05:47:40 --> Language Class Initialized
INFO - 2020-09-03 05:47:40 --> Config Class Initialized
INFO - 2020-09-03 05:47:40 --> Loader Class Initialized
INFO - 2020-09-03 05:47:40 --> Helper loaded: url_helper
INFO - 2020-09-03 05:47:40 --> Helper loaded: form_helper
INFO - 2020-09-03 05:47:40 --> Helper loaded: file_helper
INFO - 2020-09-03 05:47:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 05:47:40 --> Database Driver Class Initialized
DEBUG - 2020-09-03 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 05:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 05:47:40 --> Upload Class Initialized
INFO - 2020-09-03 05:47:40 --> Controller Class Initialized
DEBUG - 2020-09-03 05:47:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 05:47:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 05:47:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 05:47:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 05:47:40 --> Final output sent to browser
DEBUG - 2020-09-03 05:47:40 --> Total execution time: 0.0532
INFO - 2020-09-03 07:13:10 --> Config Class Initialized
INFO - 2020-09-03 07:13:10 --> Hooks Class Initialized
DEBUG - 2020-09-03 07:13:10 --> UTF-8 Support Enabled
INFO - 2020-09-03 07:13:10 --> Utf8 Class Initialized
INFO - 2020-09-03 07:13:10 --> URI Class Initialized
INFO - 2020-09-03 07:13:10 --> Router Class Initialized
INFO - 2020-09-03 07:13:10 --> Output Class Initialized
INFO - 2020-09-03 07:13:10 --> Security Class Initialized
DEBUG - 2020-09-03 07:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 07:13:10 --> Input Class Initialized
INFO - 2020-09-03 07:13:10 --> Language Class Initialized
INFO - 2020-09-03 07:13:10 --> Language Class Initialized
INFO - 2020-09-03 07:13:10 --> Config Class Initialized
INFO - 2020-09-03 07:13:10 --> Loader Class Initialized
INFO - 2020-09-03 07:13:10 --> Helper loaded: url_helper
INFO - 2020-09-03 07:13:10 --> Helper loaded: form_helper
INFO - 2020-09-03 07:13:10 --> Helper loaded: file_helper
INFO - 2020-09-03 07:13:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 07:13:10 --> Database Driver Class Initialized
DEBUG - 2020-09-03 07:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 07:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 07:13:10 --> Upload Class Initialized
INFO - 2020-09-03 07:13:10 --> Controller Class Initialized
ERROR - 2020-09-03 07:13:10 --> 404 Page Not Found: /index
INFO - 2020-09-03 07:13:13 --> Config Class Initialized
INFO - 2020-09-03 07:13:13 --> Hooks Class Initialized
DEBUG - 2020-09-03 07:13:13 --> UTF-8 Support Enabled
INFO - 2020-09-03 07:13:13 --> Utf8 Class Initialized
INFO - 2020-09-03 07:13:13 --> URI Class Initialized
DEBUG - 2020-09-03 07:13:13 --> No URI present. Default controller set.
INFO - 2020-09-03 07:13:13 --> Router Class Initialized
INFO - 2020-09-03 07:13:13 --> Output Class Initialized
INFO - 2020-09-03 07:13:13 --> Security Class Initialized
DEBUG - 2020-09-03 07:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 07:13:13 --> Input Class Initialized
INFO - 2020-09-03 07:13:13 --> Language Class Initialized
INFO - 2020-09-03 07:13:13 --> Language Class Initialized
INFO - 2020-09-03 07:13:13 --> Config Class Initialized
INFO - 2020-09-03 07:13:13 --> Loader Class Initialized
INFO - 2020-09-03 07:13:13 --> Helper loaded: url_helper
INFO - 2020-09-03 07:13:13 --> Helper loaded: form_helper
INFO - 2020-09-03 07:13:13 --> Helper loaded: file_helper
INFO - 2020-09-03 07:13:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 07:13:13 --> Database Driver Class Initialized
DEBUG - 2020-09-03 07:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 07:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 07:13:13 --> Upload Class Initialized
INFO - 2020-09-03 07:13:13 --> Controller Class Initialized
DEBUG - 2020-09-03 07:13:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 07:13:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 07:13:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 07:13:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 07:13:13 --> Final output sent to browser
DEBUG - 2020-09-03 07:13:13 --> Total execution time: 0.0517
INFO - 2020-09-03 08:48:30 --> Config Class Initialized
INFO - 2020-09-03 08:48:30 --> Hooks Class Initialized
DEBUG - 2020-09-03 08:48:30 --> UTF-8 Support Enabled
INFO - 2020-09-03 08:48:30 --> Utf8 Class Initialized
INFO - 2020-09-03 08:48:30 --> URI Class Initialized
DEBUG - 2020-09-03 08:48:30 --> No URI present. Default controller set.
INFO - 2020-09-03 08:48:30 --> Router Class Initialized
INFO - 2020-09-03 08:48:30 --> Output Class Initialized
INFO - 2020-09-03 08:48:30 --> Security Class Initialized
DEBUG - 2020-09-03 08:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 08:48:30 --> Input Class Initialized
INFO - 2020-09-03 08:48:30 --> Language Class Initialized
INFO - 2020-09-03 08:48:30 --> Language Class Initialized
INFO - 2020-09-03 08:48:30 --> Config Class Initialized
INFO - 2020-09-03 08:48:30 --> Loader Class Initialized
INFO - 2020-09-03 08:48:30 --> Helper loaded: url_helper
INFO - 2020-09-03 08:48:30 --> Helper loaded: form_helper
INFO - 2020-09-03 08:48:30 --> Helper loaded: file_helper
INFO - 2020-09-03 08:48:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 08:48:30 --> Database Driver Class Initialized
DEBUG - 2020-09-03 08:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 08:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 08:48:30 --> Upload Class Initialized
INFO - 2020-09-03 08:48:30 --> Controller Class Initialized
DEBUG - 2020-09-03 08:48:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 08:48:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 08:48:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 08:48:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 08:48:30 --> Final output sent to browser
DEBUG - 2020-09-03 08:48:30 --> Total execution time: 0.1276
INFO - 2020-09-03 09:23:04 --> Config Class Initialized
INFO - 2020-09-03 09:23:04 --> Hooks Class Initialized
DEBUG - 2020-09-03 09:23:04 --> UTF-8 Support Enabled
INFO - 2020-09-03 09:23:04 --> Utf8 Class Initialized
INFO - 2020-09-03 09:23:04 --> URI Class Initialized
DEBUG - 2020-09-03 09:23:04 --> No URI present. Default controller set.
INFO - 2020-09-03 09:23:04 --> Router Class Initialized
INFO - 2020-09-03 09:23:04 --> Output Class Initialized
INFO - 2020-09-03 09:23:04 --> Security Class Initialized
DEBUG - 2020-09-03 09:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 09:23:04 --> Input Class Initialized
INFO - 2020-09-03 09:23:04 --> Language Class Initialized
INFO - 2020-09-03 09:23:04 --> Language Class Initialized
INFO - 2020-09-03 09:23:04 --> Config Class Initialized
INFO - 2020-09-03 09:23:04 --> Loader Class Initialized
INFO - 2020-09-03 09:23:04 --> Helper loaded: url_helper
INFO - 2020-09-03 09:23:04 --> Helper loaded: form_helper
INFO - 2020-09-03 09:23:04 --> Helper loaded: file_helper
INFO - 2020-09-03 09:23:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 09:23:04 --> Database Driver Class Initialized
DEBUG - 2020-09-03 09:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 09:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 09:23:04 --> Upload Class Initialized
INFO - 2020-09-03 09:23:04 --> Controller Class Initialized
DEBUG - 2020-09-03 09:23:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 09:23:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 09:23:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 09:23:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 09:23:04 --> Final output sent to browser
DEBUG - 2020-09-03 09:23:04 --> Total execution time: 0.0595
INFO - 2020-09-03 09:23:04 --> Config Class Initialized
INFO - 2020-09-03 09:23:04 --> Hooks Class Initialized
DEBUG - 2020-09-03 09:23:04 --> UTF-8 Support Enabled
INFO - 2020-09-03 09:23:04 --> Utf8 Class Initialized
INFO - 2020-09-03 09:23:04 --> URI Class Initialized
DEBUG - 2020-09-03 09:23:04 --> No URI present. Default controller set.
INFO - 2020-09-03 09:23:04 --> Router Class Initialized
INFO - 2020-09-03 09:23:04 --> Output Class Initialized
INFO - 2020-09-03 09:23:04 --> Security Class Initialized
DEBUG - 2020-09-03 09:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 09:23:04 --> Input Class Initialized
INFO - 2020-09-03 09:23:04 --> Language Class Initialized
INFO - 2020-09-03 09:23:04 --> Language Class Initialized
INFO - 2020-09-03 09:23:04 --> Config Class Initialized
INFO - 2020-09-03 09:23:04 --> Loader Class Initialized
INFO - 2020-09-03 09:23:04 --> Helper loaded: url_helper
INFO - 2020-09-03 09:23:04 --> Helper loaded: form_helper
INFO - 2020-09-03 09:23:04 --> Helper loaded: file_helper
INFO - 2020-09-03 09:23:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 09:23:04 --> Database Driver Class Initialized
DEBUG - 2020-09-03 09:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 09:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 09:23:04 --> Upload Class Initialized
INFO - 2020-09-03 09:23:05 --> Controller Class Initialized
DEBUG - 2020-09-03 09:23:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 09:23:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 09:23:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 09:23:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 09:23:05 --> Final output sent to browser
DEBUG - 2020-09-03 09:23:05 --> Total execution time: 0.0552
INFO - 2020-09-03 09:24:36 --> Config Class Initialized
INFO - 2020-09-03 09:24:36 --> Hooks Class Initialized
DEBUG - 2020-09-03 09:24:36 --> UTF-8 Support Enabled
INFO - 2020-09-03 09:24:36 --> Utf8 Class Initialized
INFO - 2020-09-03 09:24:36 --> URI Class Initialized
INFO - 2020-09-03 09:24:36 --> Router Class Initialized
INFO - 2020-09-03 09:24:36 --> Output Class Initialized
INFO - 2020-09-03 09:24:36 --> Security Class Initialized
DEBUG - 2020-09-03 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 09:24:36 --> Input Class Initialized
INFO - 2020-09-03 09:24:36 --> Language Class Initialized
INFO - 2020-09-03 09:24:36 --> Language Class Initialized
INFO - 2020-09-03 09:24:36 --> Config Class Initialized
INFO - 2020-09-03 09:24:36 --> Loader Class Initialized
INFO - 2020-09-03 09:24:36 --> Helper loaded: url_helper
INFO - 2020-09-03 09:24:36 --> Helper loaded: form_helper
INFO - 2020-09-03 09:24:36 --> Helper loaded: file_helper
INFO - 2020-09-03 09:24:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 09:24:36 --> Database Driver Class Initialized
DEBUG - 2020-09-03 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 09:24:36 --> Upload Class Initialized
INFO - 2020-09-03 09:24:36 --> Controller Class Initialized
ERROR - 2020-09-03 09:24:36 --> 404 Page Not Found: /index
INFO - 2020-09-03 09:24:36 --> Config Class Initialized
INFO - 2020-09-03 09:24:36 --> Hooks Class Initialized
DEBUG - 2020-09-03 09:24:36 --> UTF-8 Support Enabled
INFO - 2020-09-03 09:24:36 --> Utf8 Class Initialized
INFO - 2020-09-03 09:24:36 --> URI Class Initialized
INFO - 2020-09-03 09:24:36 --> Router Class Initialized
INFO - 2020-09-03 09:24:36 --> Output Class Initialized
INFO - 2020-09-03 09:24:36 --> Security Class Initialized
DEBUG - 2020-09-03 09:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 09:24:36 --> Input Class Initialized
INFO - 2020-09-03 09:24:36 --> Language Class Initialized
INFO - 2020-09-03 09:24:36 --> Language Class Initialized
INFO - 2020-09-03 09:24:36 --> Config Class Initialized
INFO - 2020-09-03 09:24:36 --> Loader Class Initialized
INFO - 2020-09-03 09:24:36 --> Helper loaded: url_helper
INFO - 2020-09-03 09:24:36 --> Helper loaded: form_helper
INFO - 2020-09-03 09:24:36 --> Helper loaded: file_helper
INFO - 2020-09-03 09:24:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 09:24:36 --> Database Driver Class Initialized
DEBUG - 2020-09-03 09:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 09:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 09:24:36 --> Upload Class Initialized
INFO - 2020-09-03 09:24:36 --> Controller Class Initialized
DEBUG - 2020-09-03 09:24:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 09:24:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 09:24:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 09:24:36 --> Final output sent to browser
DEBUG - 2020-09-03 09:24:36 --> Total execution time: 0.0495
INFO - 2020-09-03 09:43:59 --> Config Class Initialized
INFO - 2020-09-03 09:43:59 --> Hooks Class Initialized
DEBUG - 2020-09-03 09:43:59 --> UTF-8 Support Enabled
INFO - 2020-09-03 09:43:59 --> Utf8 Class Initialized
INFO - 2020-09-03 09:43:59 --> URI Class Initialized
DEBUG - 2020-09-03 09:43:59 --> No URI present. Default controller set.
INFO - 2020-09-03 09:43:59 --> Router Class Initialized
INFO - 2020-09-03 09:43:59 --> Output Class Initialized
INFO - 2020-09-03 09:43:59 --> Security Class Initialized
DEBUG - 2020-09-03 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 09:43:59 --> Input Class Initialized
INFO - 2020-09-03 09:43:59 --> Language Class Initialized
INFO - 2020-09-03 09:43:59 --> Language Class Initialized
INFO - 2020-09-03 09:43:59 --> Config Class Initialized
INFO - 2020-09-03 09:43:59 --> Loader Class Initialized
INFO - 2020-09-03 09:43:59 --> Helper loaded: url_helper
INFO - 2020-09-03 09:43:59 --> Helper loaded: form_helper
INFO - 2020-09-03 09:43:59 --> Helper loaded: file_helper
INFO - 2020-09-03 09:43:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 09:43:59 --> Database Driver Class Initialized
DEBUG - 2020-09-03 09:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 09:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 09:43:59 --> Upload Class Initialized
INFO - 2020-09-03 09:43:59 --> Controller Class Initialized
DEBUG - 2020-09-03 09:43:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 09:43:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 09:43:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 09:43:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 09:43:59 --> Final output sent to browser
DEBUG - 2020-09-03 09:43:59 --> Total execution time: 0.0654
INFO - 2020-09-03 09:51:51 --> Config Class Initialized
INFO - 2020-09-03 09:51:51 --> Hooks Class Initialized
DEBUG - 2020-09-03 09:51:51 --> UTF-8 Support Enabled
INFO - 2020-09-03 09:51:51 --> Utf8 Class Initialized
INFO - 2020-09-03 09:51:51 --> URI Class Initialized
DEBUG - 2020-09-03 09:51:51 --> No URI present. Default controller set.
INFO - 2020-09-03 09:51:51 --> Router Class Initialized
INFO - 2020-09-03 09:51:51 --> Output Class Initialized
INFO - 2020-09-03 09:51:51 --> Security Class Initialized
DEBUG - 2020-09-03 09:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 09:51:51 --> Input Class Initialized
INFO - 2020-09-03 09:51:51 --> Language Class Initialized
INFO - 2020-09-03 09:51:51 --> Language Class Initialized
INFO - 2020-09-03 09:51:51 --> Config Class Initialized
INFO - 2020-09-03 09:51:51 --> Loader Class Initialized
INFO - 2020-09-03 09:51:51 --> Helper loaded: url_helper
INFO - 2020-09-03 09:51:51 --> Helper loaded: form_helper
INFO - 2020-09-03 09:51:51 --> Helper loaded: file_helper
INFO - 2020-09-03 09:51:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 09:51:51 --> Database Driver Class Initialized
DEBUG - 2020-09-03 09:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 09:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 09:51:51 --> Upload Class Initialized
INFO - 2020-09-03 09:51:51 --> Controller Class Initialized
DEBUG - 2020-09-03 09:51:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 09:51:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 09:51:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 09:51:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 09:51:51 --> Final output sent to browser
DEBUG - 2020-09-03 09:51:51 --> Total execution time: 0.0522
INFO - 2020-09-03 10:02:09 --> Config Class Initialized
INFO - 2020-09-03 10:02:09 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:02:09 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:02:09 --> Utf8 Class Initialized
INFO - 2020-09-03 10:02:09 --> URI Class Initialized
DEBUG - 2020-09-03 10:02:09 --> No URI present. Default controller set.
INFO - 2020-09-03 10:02:09 --> Router Class Initialized
INFO - 2020-09-03 10:02:09 --> Output Class Initialized
INFO - 2020-09-03 10:02:09 --> Security Class Initialized
DEBUG - 2020-09-03 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:02:09 --> Input Class Initialized
INFO - 2020-09-03 10:02:09 --> Language Class Initialized
INFO - 2020-09-03 10:02:09 --> Language Class Initialized
INFO - 2020-09-03 10:02:09 --> Config Class Initialized
INFO - 2020-09-03 10:02:09 --> Loader Class Initialized
INFO - 2020-09-03 10:02:09 --> Helper loaded: url_helper
INFO - 2020-09-03 10:02:09 --> Helper loaded: form_helper
INFO - 2020-09-03 10:02:09 --> Helper loaded: file_helper
INFO - 2020-09-03 10:02:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:02:09 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:02:09 --> Upload Class Initialized
INFO - 2020-09-03 10:02:09 --> Controller Class Initialized
DEBUG - 2020-09-03 10:02:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 10:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 10:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:02:09 --> Final output sent to browser
DEBUG - 2020-09-03 10:02:09 --> Total execution time: 0.0568
INFO - 2020-09-03 10:02:09 --> Config Class Initialized
INFO - 2020-09-03 10:02:09 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:02:09 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:02:09 --> Utf8 Class Initialized
INFO - 2020-09-03 10:02:09 --> URI Class Initialized
DEBUG - 2020-09-03 10:02:09 --> No URI present. Default controller set.
INFO - 2020-09-03 10:02:09 --> Router Class Initialized
INFO - 2020-09-03 10:02:09 --> Output Class Initialized
INFO - 2020-09-03 10:02:09 --> Security Class Initialized
DEBUG - 2020-09-03 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:02:09 --> Input Class Initialized
INFO - 2020-09-03 10:02:09 --> Language Class Initialized
INFO - 2020-09-03 10:02:09 --> Language Class Initialized
INFO - 2020-09-03 10:02:09 --> Config Class Initialized
INFO - 2020-09-03 10:02:09 --> Loader Class Initialized
INFO - 2020-09-03 10:02:09 --> Helper loaded: url_helper
INFO - 2020-09-03 10:02:09 --> Helper loaded: form_helper
INFO - 2020-09-03 10:02:09 --> Helper loaded: file_helper
INFO - 2020-09-03 10:02:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:02:09 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:02:09 --> Upload Class Initialized
INFO - 2020-09-03 10:02:09 --> Controller Class Initialized
DEBUG - 2020-09-03 10:02:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 10:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 10:02:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:02:09 --> Final output sent to browser
DEBUG - 2020-09-03 10:02:09 --> Total execution time: 0.0528
INFO - 2020-09-03 10:23:45 --> Config Class Initialized
INFO - 2020-09-03 10:23:45 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:23:45 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:23:45 --> Utf8 Class Initialized
INFO - 2020-09-03 10:23:45 --> URI Class Initialized
DEBUG - 2020-09-03 10:23:45 --> No URI present. Default controller set.
INFO - 2020-09-03 10:23:45 --> Router Class Initialized
INFO - 2020-09-03 10:23:45 --> Output Class Initialized
INFO - 2020-09-03 10:23:45 --> Security Class Initialized
DEBUG - 2020-09-03 10:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:23:45 --> Input Class Initialized
INFO - 2020-09-03 10:23:45 --> Language Class Initialized
INFO - 2020-09-03 10:23:45 --> Language Class Initialized
INFO - 2020-09-03 10:23:45 --> Config Class Initialized
INFO - 2020-09-03 10:23:45 --> Loader Class Initialized
INFO - 2020-09-03 10:23:45 --> Helper loaded: url_helper
INFO - 2020-09-03 10:23:45 --> Helper loaded: form_helper
INFO - 2020-09-03 10:23:45 --> Helper loaded: file_helper
INFO - 2020-09-03 10:23:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:23:45 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:23:45 --> Upload Class Initialized
INFO - 2020-09-03 10:23:45 --> Controller Class Initialized
DEBUG - 2020-09-03 10:23:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:23:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 10:23:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 10:23:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:23:45 --> Final output sent to browser
DEBUG - 2020-09-03 10:23:45 --> Total execution time: 0.0520
INFO - 2020-09-03 10:27:02 --> Config Class Initialized
INFO - 2020-09-03 10:27:02 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:27:02 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:27:02 --> Utf8 Class Initialized
INFO - 2020-09-03 10:27:02 --> URI Class Initialized
INFO - 2020-09-03 10:27:02 --> Router Class Initialized
INFO - 2020-09-03 10:27:02 --> Output Class Initialized
INFO - 2020-09-03 10:27:02 --> Security Class Initialized
DEBUG - 2020-09-03 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:27:02 --> Input Class Initialized
INFO - 2020-09-03 10:27:02 --> Language Class Initialized
INFO - 2020-09-03 10:27:02 --> Language Class Initialized
INFO - 2020-09-03 10:27:02 --> Config Class Initialized
INFO - 2020-09-03 10:27:02 --> Loader Class Initialized
INFO - 2020-09-03 10:27:02 --> Helper loaded: url_helper
INFO - 2020-09-03 10:27:02 --> Helper loaded: form_helper
INFO - 2020-09-03 10:27:02 --> Helper loaded: file_helper
INFO - 2020-09-03 10:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:27:02 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:27:02 --> Upload Class Initialized
INFO - 2020-09-03 10:27:02 --> Controller Class Initialized
ERROR - 2020-09-03 10:27:02 --> 404 Page Not Found: /index
INFO - 2020-09-03 10:34:30 --> Config Class Initialized
INFO - 2020-09-03 10:34:30 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:34:30 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:34:30 --> Utf8 Class Initialized
INFO - 2020-09-03 10:34:30 --> URI Class Initialized
DEBUG - 2020-09-03 10:34:30 --> No URI present. Default controller set.
INFO - 2020-09-03 10:34:30 --> Router Class Initialized
INFO - 2020-09-03 10:34:30 --> Output Class Initialized
INFO - 2020-09-03 10:34:30 --> Security Class Initialized
DEBUG - 2020-09-03 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:34:30 --> Input Class Initialized
INFO - 2020-09-03 10:34:30 --> Language Class Initialized
INFO - 2020-09-03 10:34:30 --> Language Class Initialized
INFO - 2020-09-03 10:34:30 --> Config Class Initialized
INFO - 2020-09-03 10:34:30 --> Loader Class Initialized
INFO - 2020-09-03 10:34:30 --> Helper loaded: url_helper
INFO - 2020-09-03 10:34:30 --> Helper loaded: form_helper
INFO - 2020-09-03 10:34:30 --> Helper loaded: file_helper
INFO - 2020-09-03 10:34:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:34:30 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:34:30 --> Upload Class Initialized
INFO - 2020-09-03 10:34:30 --> Controller Class Initialized
DEBUG - 2020-09-03 10:34:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:34:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 10:34:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 10:34:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:34:30 --> Final output sent to browser
DEBUG - 2020-09-03 10:34:30 --> Total execution time: 0.0650
INFO - 2020-09-03 10:34:41 --> Config Class Initialized
INFO - 2020-09-03 10:34:41 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:34:41 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:34:41 --> Utf8 Class Initialized
INFO - 2020-09-03 10:34:41 --> URI Class Initialized
INFO - 2020-09-03 10:34:41 --> Router Class Initialized
INFO - 2020-09-03 10:34:41 --> Output Class Initialized
INFO - 2020-09-03 10:34:41 --> Security Class Initialized
DEBUG - 2020-09-03 10:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:34:41 --> Input Class Initialized
INFO - 2020-09-03 10:34:41 --> Language Class Initialized
INFO - 2020-09-03 10:34:41 --> Language Class Initialized
INFO - 2020-09-03 10:34:41 --> Config Class Initialized
INFO - 2020-09-03 10:34:41 --> Loader Class Initialized
INFO - 2020-09-03 10:34:41 --> Helper loaded: url_helper
INFO - 2020-09-03 10:34:41 --> Helper loaded: form_helper
INFO - 2020-09-03 10:34:41 --> Helper loaded: file_helper
INFO - 2020-09-03 10:34:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:34:41 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:34:41 --> Upload Class Initialized
INFO - 2020-09-03 10:34:41 --> Controller Class Initialized
DEBUG - 2020-09-03 10:34:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:34:41 --> Final output sent to browser
DEBUG - 2020-09-03 10:34:41 --> Total execution time: 0.0695
INFO - 2020-09-03 10:34:43 --> Config Class Initialized
INFO - 2020-09-03 10:34:43 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:34:43 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:34:43 --> Utf8 Class Initialized
INFO - 2020-09-03 10:34:43 --> URI Class Initialized
INFO - 2020-09-03 10:34:43 --> Router Class Initialized
INFO - 2020-09-03 10:34:43 --> Output Class Initialized
INFO - 2020-09-03 10:34:43 --> Security Class Initialized
DEBUG - 2020-09-03 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:34:43 --> Input Class Initialized
INFO - 2020-09-03 10:34:43 --> Language Class Initialized
INFO - 2020-09-03 10:34:43 --> Language Class Initialized
INFO - 2020-09-03 10:34:43 --> Config Class Initialized
INFO - 2020-09-03 10:34:43 --> Loader Class Initialized
INFO - 2020-09-03 10:34:43 --> Helper loaded: url_helper
INFO - 2020-09-03 10:34:43 --> Helper loaded: form_helper
INFO - 2020-09-03 10:34:43 --> Helper loaded: file_helper
INFO - 2020-09-03 10:34:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:34:43 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:34:43 --> Upload Class Initialized
INFO - 2020-09-03 10:34:43 --> Controller Class Initialized
ERROR - 2020-09-03 10:34:43 --> 404 Page Not Found: /index
INFO - 2020-09-03 10:43:00 --> Config Class Initialized
INFO - 2020-09-03 10:43:00 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:43:00 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:43:00 --> Utf8 Class Initialized
INFO - 2020-09-03 10:43:00 --> URI Class Initialized
INFO - 2020-09-03 10:43:00 --> Router Class Initialized
INFO - 2020-09-03 10:43:00 --> Output Class Initialized
INFO - 2020-09-03 10:43:00 --> Security Class Initialized
DEBUG - 2020-09-03 10:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:43:00 --> Input Class Initialized
INFO - 2020-09-03 10:43:00 --> Language Class Initialized
INFO - 2020-09-03 10:43:00 --> Language Class Initialized
INFO - 2020-09-03 10:43:00 --> Config Class Initialized
INFO - 2020-09-03 10:43:00 --> Loader Class Initialized
INFO - 2020-09-03 10:43:00 --> Helper loaded: url_helper
INFO - 2020-09-03 10:43:00 --> Helper loaded: form_helper
INFO - 2020-09-03 10:43:00 --> Helper loaded: file_helper
INFO - 2020-09-03 10:43:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:43:00 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:43:00 --> Upload Class Initialized
INFO - 2020-09-03 10:43:00 --> Controller Class Initialized
DEBUG - 2020-09-03 10:43:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:43:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:43:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:43:00 --> Final output sent to browser
DEBUG - 2020-09-03 10:43:00 --> Total execution time: 0.0847
INFO - 2020-09-03 10:48:05 --> Config Class Initialized
INFO - 2020-09-03 10:48:05 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:48:05 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:48:05 --> Utf8 Class Initialized
INFO - 2020-09-03 10:48:05 --> URI Class Initialized
INFO - 2020-09-03 10:48:05 --> Router Class Initialized
INFO - 2020-09-03 10:48:05 --> Output Class Initialized
INFO - 2020-09-03 10:48:05 --> Security Class Initialized
DEBUG - 2020-09-03 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:48:05 --> Input Class Initialized
INFO - 2020-09-03 10:48:05 --> Language Class Initialized
INFO - 2020-09-03 10:48:05 --> Language Class Initialized
INFO - 2020-09-03 10:48:05 --> Config Class Initialized
INFO - 2020-09-03 10:48:05 --> Loader Class Initialized
INFO - 2020-09-03 10:48:05 --> Helper loaded: url_helper
INFO - 2020-09-03 10:48:05 --> Helper loaded: form_helper
INFO - 2020-09-03 10:48:05 --> Helper loaded: file_helper
INFO - 2020-09-03 10:48:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:48:05 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:48:05 --> Upload Class Initialized
INFO - 2020-09-03 10:48:05 --> Controller Class Initialized
DEBUG - 2020-09-03 10:48:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:48:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:48:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:48:05 --> Final output sent to browser
DEBUG - 2020-09-03 10:48:05 --> Total execution time: 0.0729
INFO - 2020-09-03 10:51:33 --> Config Class Initialized
INFO - 2020-09-03 10:51:33 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:51:33 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:51:33 --> Utf8 Class Initialized
INFO - 2020-09-03 10:51:33 --> URI Class Initialized
INFO - 2020-09-03 10:51:33 --> Router Class Initialized
INFO - 2020-09-03 10:51:33 --> Output Class Initialized
INFO - 2020-09-03 10:51:33 --> Security Class Initialized
DEBUG - 2020-09-03 10:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:51:33 --> Input Class Initialized
INFO - 2020-09-03 10:51:33 --> Language Class Initialized
INFO - 2020-09-03 10:51:33 --> Language Class Initialized
INFO - 2020-09-03 10:51:33 --> Config Class Initialized
INFO - 2020-09-03 10:51:33 --> Loader Class Initialized
INFO - 2020-09-03 10:51:33 --> Helper loaded: url_helper
INFO - 2020-09-03 10:51:33 --> Helper loaded: form_helper
INFO - 2020-09-03 10:51:33 --> Helper loaded: file_helper
INFO - 2020-09-03 10:51:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:51:33 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:51:33 --> Upload Class Initialized
INFO - 2020-09-03 10:51:33 --> Controller Class Initialized
DEBUG - 2020-09-03 10:51:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:51:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:51:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:51:33 --> Final output sent to browser
DEBUG - 2020-09-03 10:51:33 --> Total execution time: 0.0524
INFO - 2020-09-03 10:55:14 --> Config Class Initialized
INFO - 2020-09-03 10:55:14 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:55:14 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:55:14 --> Utf8 Class Initialized
INFO - 2020-09-03 10:55:14 --> URI Class Initialized
INFO - 2020-09-03 10:55:14 --> Router Class Initialized
INFO - 2020-09-03 10:55:14 --> Output Class Initialized
INFO - 2020-09-03 10:55:14 --> Security Class Initialized
DEBUG - 2020-09-03 10:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:55:14 --> Input Class Initialized
INFO - 2020-09-03 10:55:14 --> Language Class Initialized
INFO - 2020-09-03 10:55:14 --> Language Class Initialized
INFO - 2020-09-03 10:55:14 --> Config Class Initialized
INFO - 2020-09-03 10:55:14 --> Loader Class Initialized
INFO - 2020-09-03 10:55:14 --> Helper loaded: url_helper
INFO - 2020-09-03 10:55:14 --> Helper loaded: form_helper
INFO - 2020-09-03 10:55:14 --> Helper loaded: file_helper
INFO - 2020-09-03 10:55:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:55:14 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:55:14 --> Upload Class Initialized
INFO - 2020-09-03 10:55:14 --> Controller Class Initialized
DEBUG - 2020-09-03 10:55:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:55:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:55:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:55:14 --> Final output sent to browser
DEBUG - 2020-09-03 10:55:14 --> Total execution time: 0.0546
INFO - 2020-09-03 10:56:32 --> Config Class Initialized
INFO - 2020-09-03 10:56:32 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:56:32 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:56:32 --> Utf8 Class Initialized
INFO - 2020-09-03 10:56:32 --> URI Class Initialized
INFO - 2020-09-03 10:56:32 --> Router Class Initialized
INFO - 2020-09-03 10:56:32 --> Output Class Initialized
INFO - 2020-09-03 10:56:32 --> Security Class Initialized
DEBUG - 2020-09-03 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:56:32 --> Input Class Initialized
INFO - 2020-09-03 10:56:32 --> Language Class Initialized
INFO - 2020-09-03 10:56:32 --> Language Class Initialized
INFO - 2020-09-03 10:56:32 --> Config Class Initialized
INFO - 2020-09-03 10:56:32 --> Loader Class Initialized
INFO - 2020-09-03 10:56:32 --> Helper loaded: url_helper
INFO - 2020-09-03 10:56:32 --> Helper loaded: form_helper
INFO - 2020-09-03 10:56:32 --> Helper loaded: file_helper
INFO - 2020-09-03 10:56:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:56:32 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:56:32 --> Upload Class Initialized
INFO - 2020-09-03 10:56:32 --> Controller Class Initialized
DEBUG - 2020-09-03 10:56:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:56:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:56:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:56:32 --> Final output sent to browser
DEBUG - 2020-09-03 10:56:32 --> Total execution time: 0.0526
INFO - 2020-09-03 10:59:50 --> Config Class Initialized
INFO - 2020-09-03 10:59:50 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:59:50 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:59:50 --> Utf8 Class Initialized
INFO - 2020-09-03 10:59:50 --> URI Class Initialized
INFO - 2020-09-03 10:59:50 --> Router Class Initialized
INFO - 2020-09-03 10:59:50 --> Output Class Initialized
INFO - 2020-09-03 10:59:50 --> Security Class Initialized
DEBUG - 2020-09-03 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:59:50 --> Input Class Initialized
INFO - 2020-09-03 10:59:50 --> Language Class Initialized
INFO - 2020-09-03 10:59:50 --> Language Class Initialized
INFO - 2020-09-03 10:59:50 --> Config Class Initialized
INFO - 2020-09-03 10:59:50 --> Loader Class Initialized
INFO - 2020-09-03 10:59:50 --> Helper loaded: url_helper
INFO - 2020-09-03 10:59:50 --> Helper loaded: form_helper
INFO - 2020-09-03 10:59:50 --> Helper loaded: file_helper
INFO - 2020-09-03 10:59:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:59:50 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:59:50 --> Upload Class Initialized
INFO - 2020-09-03 10:59:50 --> Controller Class Initialized
DEBUG - 2020-09-03 10:59:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 10:59:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 10:59:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 10:59:50 --> Final output sent to browser
DEBUG - 2020-09-03 10:59:50 --> Total execution time: 0.0508
INFO - 2020-09-03 10:59:53 --> Config Class Initialized
INFO - 2020-09-03 10:59:53 --> Hooks Class Initialized
DEBUG - 2020-09-03 10:59:53 --> UTF-8 Support Enabled
INFO - 2020-09-03 10:59:53 --> Utf8 Class Initialized
INFO - 2020-09-03 10:59:53 --> URI Class Initialized
INFO - 2020-09-03 10:59:53 --> Router Class Initialized
INFO - 2020-09-03 10:59:53 --> Output Class Initialized
INFO - 2020-09-03 10:59:53 --> Security Class Initialized
DEBUG - 2020-09-03 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 10:59:53 --> Input Class Initialized
INFO - 2020-09-03 10:59:53 --> Language Class Initialized
INFO - 2020-09-03 10:59:53 --> Language Class Initialized
INFO - 2020-09-03 10:59:53 --> Config Class Initialized
INFO - 2020-09-03 10:59:53 --> Loader Class Initialized
INFO - 2020-09-03 10:59:53 --> Helper loaded: url_helper
INFO - 2020-09-03 10:59:53 --> Helper loaded: form_helper
INFO - 2020-09-03 10:59:53 --> Helper loaded: file_helper
INFO - 2020-09-03 10:59:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 10:59:53 --> Database Driver Class Initialized
DEBUG - 2020-09-03 10:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 10:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 10:59:53 --> Upload Class Initialized
INFO - 2020-09-03 10:59:53 --> Controller Class Initialized
ERROR - 2020-09-03 10:59:53 --> 404 Page Not Found: /index
INFO - 2020-09-03 11:11:10 --> Config Class Initialized
INFO - 2020-09-03 11:11:10 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:11:10 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:11:10 --> Utf8 Class Initialized
INFO - 2020-09-03 11:11:10 --> URI Class Initialized
DEBUG - 2020-09-03 11:11:10 --> No URI present. Default controller set.
INFO - 2020-09-03 11:11:10 --> Router Class Initialized
INFO - 2020-09-03 11:11:10 --> Output Class Initialized
INFO - 2020-09-03 11:11:10 --> Security Class Initialized
DEBUG - 2020-09-03 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:11:10 --> Input Class Initialized
INFO - 2020-09-03 11:11:10 --> Language Class Initialized
INFO - 2020-09-03 11:11:10 --> Language Class Initialized
INFO - 2020-09-03 11:11:10 --> Config Class Initialized
INFO - 2020-09-03 11:11:10 --> Loader Class Initialized
INFO - 2020-09-03 11:11:10 --> Helper loaded: url_helper
INFO - 2020-09-03 11:11:10 --> Helper loaded: form_helper
INFO - 2020-09-03 11:11:10 --> Helper loaded: file_helper
INFO - 2020-09-03 11:11:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:11:10 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:11:10 --> Upload Class Initialized
INFO - 2020-09-03 11:11:10 --> Controller Class Initialized
DEBUG - 2020-09-03 11:11:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 11:11:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 11:11:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 11:11:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 11:11:10 --> Final output sent to browser
DEBUG - 2020-09-03 11:11:10 --> Total execution time: 0.0536
INFO - 2020-09-03 11:11:19 --> Config Class Initialized
INFO - 2020-09-03 11:11:19 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:11:19 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:11:19 --> Utf8 Class Initialized
INFO - 2020-09-03 11:11:19 --> URI Class Initialized
INFO - 2020-09-03 11:11:19 --> Router Class Initialized
INFO - 2020-09-03 11:11:19 --> Output Class Initialized
INFO - 2020-09-03 11:11:19 --> Security Class Initialized
DEBUG - 2020-09-03 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:11:19 --> Input Class Initialized
INFO - 2020-09-03 11:11:19 --> Language Class Initialized
INFO - 2020-09-03 11:11:19 --> Language Class Initialized
INFO - 2020-09-03 11:11:19 --> Config Class Initialized
INFO - 2020-09-03 11:11:19 --> Loader Class Initialized
INFO - 2020-09-03 11:11:19 --> Helper loaded: url_helper
INFO - 2020-09-03 11:11:19 --> Helper loaded: form_helper
INFO - 2020-09-03 11:11:19 --> Helper loaded: file_helper
INFO - 2020-09-03 11:11:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:11:19 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:11:19 --> Upload Class Initialized
INFO - 2020-09-03 11:11:19 --> Controller Class Initialized
ERROR - 2020-09-03 11:11:19 --> 404 Page Not Found: /index
INFO - 2020-09-03 11:11:24 --> Config Class Initialized
INFO - 2020-09-03 11:11:24 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:11:24 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:11:24 --> Utf8 Class Initialized
INFO - 2020-09-03 11:11:24 --> URI Class Initialized
INFO - 2020-09-03 11:11:24 --> Router Class Initialized
INFO - 2020-09-03 11:11:24 --> Output Class Initialized
INFO - 2020-09-03 11:11:24 --> Security Class Initialized
DEBUG - 2020-09-03 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:11:24 --> Input Class Initialized
INFO - 2020-09-03 11:11:24 --> Language Class Initialized
INFO - 2020-09-03 11:11:24 --> Language Class Initialized
INFO - 2020-09-03 11:11:24 --> Config Class Initialized
INFO - 2020-09-03 11:11:24 --> Loader Class Initialized
INFO - 2020-09-03 11:11:24 --> Helper loaded: url_helper
INFO - 2020-09-03 11:11:24 --> Helper loaded: form_helper
INFO - 2020-09-03 11:11:24 --> Helper loaded: file_helper
INFO - 2020-09-03 11:11:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:11:24 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:11:24 --> Upload Class Initialized
INFO - 2020-09-03 11:11:24 --> Controller Class Initialized
DEBUG - 2020-09-03 11:11:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 11:11:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-03 11:11:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 11:11:24 --> Final output sent to browser
DEBUG - 2020-09-03 11:11:24 --> Total execution time: 0.0572
INFO - 2020-09-03 11:11:24 --> Config Class Initialized
INFO - 2020-09-03 11:11:24 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:11:24 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:11:24 --> Utf8 Class Initialized
INFO - 2020-09-03 11:11:24 --> URI Class Initialized
INFO - 2020-09-03 11:11:24 --> Router Class Initialized
INFO - 2020-09-03 11:11:24 --> Output Class Initialized
INFO - 2020-09-03 11:11:24 --> Security Class Initialized
DEBUG - 2020-09-03 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:11:24 --> Input Class Initialized
INFO - 2020-09-03 11:11:24 --> Language Class Initialized
INFO - 2020-09-03 11:11:24 --> Language Class Initialized
INFO - 2020-09-03 11:11:24 --> Config Class Initialized
INFO - 2020-09-03 11:11:24 --> Loader Class Initialized
INFO - 2020-09-03 11:11:24 --> Helper loaded: url_helper
INFO - 2020-09-03 11:11:24 --> Helper loaded: form_helper
INFO - 2020-09-03 11:11:24 --> Helper loaded: file_helper
INFO - 2020-09-03 11:11:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:11:24 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:11:24 --> Upload Class Initialized
INFO - 2020-09-03 11:11:24 --> Controller Class Initialized
DEBUG - 2020-09-03 11:11:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 11:11:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-03 11:11:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 11:11:25 --> Final output sent to browser
DEBUG - 2020-09-03 11:11:25 --> Total execution time: 0.0589
INFO - 2020-09-03 11:11:25 --> Config Class Initialized
INFO - 2020-09-03 11:11:25 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:11:25 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:11:25 --> Utf8 Class Initialized
INFO - 2020-09-03 11:11:25 --> URI Class Initialized
INFO - 2020-09-03 11:11:25 --> Router Class Initialized
INFO - 2020-09-03 11:11:25 --> Output Class Initialized
INFO - 2020-09-03 11:11:25 --> Security Class Initialized
DEBUG - 2020-09-03 11:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:11:25 --> Input Class Initialized
INFO - 2020-09-03 11:11:25 --> Language Class Initialized
INFO - 2020-09-03 11:11:25 --> Language Class Initialized
INFO - 2020-09-03 11:11:25 --> Config Class Initialized
INFO - 2020-09-03 11:11:25 --> Loader Class Initialized
INFO - 2020-09-03 11:11:25 --> Helper loaded: url_helper
INFO - 2020-09-03 11:11:25 --> Helper loaded: form_helper
INFO - 2020-09-03 11:11:25 --> Helper loaded: file_helper
INFO - 2020-09-03 11:11:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:11:25 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:11:25 --> Upload Class Initialized
INFO - 2020-09-03 11:11:25 --> Controller Class Initialized
DEBUG - 2020-09-03 11:11:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 11:11:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 11:11:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 11:11:25 --> Final output sent to browser
DEBUG - 2020-09-03 11:11:25 --> Total execution time: 0.0503
INFO - 2020-09-03 11:11:49 --> Config Class Initialized
INFO - 2020-09-03 11:11:49 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:11:49 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:11:49 --> Utf8 Class Initialized
INFO - 2020-09-03 11:11:49 --> URI Class Initialized
INFO - 2020-09-03 11:11:49 --> Router Class Initialized
INFO - 2020-09-03 11:11:49 --> Output Class Initialized
INFO - 2020-09-03 11:11:49 --> Security Class Initialized
DEBUG - 2020-09-03 11:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:11:49 --> Input Class Initialized
INFO - 2020-09-03 11:11:49 --> Language Class Initialized
INFO - 2020-09-03 11:11:49 --> Language Class Initialized
INFO - 2020-09-03 11:11:49 --> Config Class Initialized
INFO - 2020-09-03 11:11:49 --> Loader Class Initialized
INFO - 2020-09-03 11:11:49 --> Helper loaded: url_helper
INFO - 2020-09-03 11:11:49 --> Helper loaded: form_helper
INFO - 2020-09-03 11:11:49 --> Helper loaded: file_helper
INFO - 2020-09-03 11:11:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:11:49 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:11:49 --> Upload Class Initialized
INFO - 2020-09-03 11:11:49 --> Controller Class Initialized
ERROR - 2020-09-03 11:11:49 --> 404 Page Not Found: /index
INFO - 2020-09-03 11:42:20 --> Config Class Initialized
INFO - 2020-09-03 11:42:20 --> Hooks Class Initialized
DEBUG - 2020-09-03 11:42:20 --> UTF-8 Support Enabled
INFO - 2020-09-03 11:42:20 --> Utf8 Class Initialized
INFO - 2020-09-03 11:42:20 --> URI Class Initialized
DEBUG - 2020-09-03 11:42:20 --> No URI present. Default controller set.
INFO - 2020-09-03 11:42:20 --> Router Class Initialized
INFO - 2020-09-03 11:42:20 --> Output Class Initialized
INFO - 2020-09-03 11:42:20 --> Security Class Initialized
DEBUG - 2020-09-03 11:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 11:42:20 --> Input Class Initialized
INFO - 2020-09-03 11:42:20 --> Language Class Initialized
INFO - 2020-09-03 11:42:20 --> Language Class Initialized
INFO - 2020-09-03 11:42:20 --> Config Class Initialized
INFO - 2020-09-03 11:42:20 --> Loader Class Initialized
INFO - 2020-09-03 11:42:20 --> Helper loaded: url_helper
INFO - 2020-09-03 11:42:20 --> Helper loaded: form_helper
INFO - 2020-09-03 11:42:20 --> Helper loaded: file_helper
INFO - 2020-09-03 11:42:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 11:42:20 --> Database Driver Class Initialized
DEBUG - 2020-09-03 11:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 11:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 11:42:20 --> Upload Class Initialized
INFO - 2020-09-03 11:42:20 --> Controller Class Initialized
DEBUG - 2020-09-03 11:42:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 11:42:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 11:42:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 11:42:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 11:42:20 --> Final output sent to browser
DEBUG - 2020-09-03 11:42:20 --> Total execution time: 0.0489
INFO - 2020-09-03 12:52:18 --> Config Class Initialized
INFO - 2020-09-03 12:52:18 --> Hooks Class Initialized
DEBUG - 2020-09-03 12:52:18 --> UTF-8 Support Enabled
INFO - 2020-09-03 12:52:18 --> Utf8 Class Initialized
INFO - 2020-09-03 12:52:18 --> URI Class Initialized
DEBUG - 2020-09-03 12:52:18 --> No URI present. Default controller set.
INFO - 2020-09-03 12:52:18 --> Router Class Initialized
INFO - 2020-09-03 12:52:18 --> Output Class Initialized
INFO - 2020-09-03 12:52:18 --> Security Class Initialized
DEBUG - 2020-09-03 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 12:52:18 --> Input Class Initialized
INFO - 2020-09-03 12:52:18 --> Language Class Initialized
INFO - 2020-09-03 12:52:18 --> Language Class Initialized
INFO - 2020-09-03 12:52:18 --> Config Class Initialized
INFO - 2020-09-03 12:52:18 --> Loader Class Initialized
INFO - 2020-09-03 12:52:18 --> Helper loaded: url_helper
INFO - 2020-09-03 12:52:18 --> Helper loaded: form_helper
INFO - 2020-09-03 12:52:18 --> Helper loaded: file_helper
INFO - 2020-09-03 12:52:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 12:52:18 --> Database Driver Class Initialized
DEBUG - 2020-09-03 12:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 12:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 12:52:18 --> Upload Class Initialized
INFO - 2020-09-03 12:52:18 --> Controller Class Initialized
DEBUG - 2020-09-03 12:52:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 12:52:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 12:52:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 12:52:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 12:52:18 --> Final output sent to browser
DEBUG - 2020-09-03 12:52:18 --> Total execution time: 0.0557
INFO - 2020-09-03 12:53:05 --> Config Class Initialized
INFO - 2020-09-03 12:53:05 --> Hooks Class Initialized
DEBUG - 2020-09-03 12:53:05 --> UTF-8 Support Enabled
INFO - 2020-09-03 12:53:05 --> Utf8 Class Initialized
INFO - 2020-09-03 12:53:05 --> URI Class Initialized
DEBUG - 2020-09-03 12:53:05 --> No URI present. Default controller set.
INFO - 2020-09-03 12:53:05 --> Router Class Initialized
INFO - 2020-09-03 12:53:05 --> Output Class Initialized
INFO - 2020-09-03 12:53:05 --> Security Class Initialized
DEBUG - 2020-09-03 12:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 12:53:05 --> Input Class Initialized
INFO - 2020-09-03 12:53:05 --> Language Class Initialized
INFO - 2020-09-03 12:53:05 --> Language Class Initialized
INFO - 2020-09-03 12:53:05 --> Config Class Initialized
INFO - 2020-09-03 12:53:05 --> Loader Class Initialized
INFO - 2020-09-03 12:53:05 --> Helper loaded: url_helper
INFO - 2020-09-03 12:53:05 --> Helper loaded: form_helper
INFO - 2020-09-03 12:53:05 --> Helper loaded: file_helper
INFO - 2020-09-03 12:53:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 12:53:05 --> Database Driver Class Initialized
DEBUG - 2020-09-03 12:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 12:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 12:53:05 --> Upload Class Initialized
INFO - 2020-09-03 12:53:05 --> Controller Class Initialized
DEBUG - 2020-09-03 12:53:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 12:53:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 12:53:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 12:53:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 12:53:05 --> Final output sent to browser
DEBUG - 2020-09-03 12:53:05 --> Total execution time: 0.0653
INFO - 2020-09-03 12:53:06 --> Config Class Initialized
INFO - 2020-09-03 12:53:06 --> Hooks Class Initialized
DEBUG - 2020-09-03 12:53:06 --> UTF-8 Support Enabled
INFO - 2020-09-03 12:53:06 --> Utf8 Class Initialized
INFO - 2020-09-03 12:53:06 --> URI Class Initialized
DEBUG - 2020-09-03 12:53:06 --> No URI present. Default controller set.
INFO - 2020-09-03 12:53:06 --> Router Class Initialized
INFO - 2020-09-03 12:53:06 --> Output Class Initialized
INFO - 2020-09-03 12:53:06 --> Security Class Initialized
DEBUG - 2020-09-03 12:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 12:53:06 --> Input Class Initialized
INFO - 2020-09-03 12:53:06 --> Language Class Initialized
INFO - 2020-09-03 12:53:06 --> Language Class Initialized
INFO - 2020-09-03 12:53:06 --> Config Class Initialized
INFO - 2020-09-03 12:53:06 --> Loader Class Initialized
INFO - 2020-09-03 12:53:06 --> Helper loaded: url_helper
INFO - 2020-09-03 12:53:06 --> Helper loaded: form_helper
INFO - 2020-09-03 12:53:06 --> Helper loaded: file_helper
INFO - 2020-09-03 12:53:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 12:53:06 --> Database Driver Class Initialized
DEBUG - 2020-09-03 12:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 12:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 12:53:06 --> Upload Class Initialized
INFO - 2020-09-03 12:53:06 --> Controller Class Initialized
DEBUG - 2020-09-03 12:53:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 12:53:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 12:53:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 12:53:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 12:53:06 --> Final output sent to browser
DEBUG - 2020-09-03 12:53:06 --> Total execution time: 0.0708
INFO - 2020-09-03 14:06:33 --> Config Class Initialized
INFO - 2020-09-03 14:06:33 --> Hooks Class Initialized
DEBUG - 2020-09-03 14:06:33 --> UTF-8 Support Enabled
INFO - 2020-09-03 14:06:33 --> Utf8 Class Initialized
INFO - 2020-09-03 14:06:33 --> URI Class Initialized
DEBUG - 2020-09-03 14:06:33 --> No URI present. Default controller set.
INFO - 2020-09-03 14:06:33 --> Router Class Initialized
INFO - 2020-09-03 14:06:33 --> Output Class Initialized
INFO - 2020-09-03 14:06:33 --> Security Class Initialized
DEBUG - 2020-09-03 14:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 14:06:33 --> Input Class Initialized
INFO - 2020-09-03 14:06:33 --> Language Class Initialized
INFO - 2020-09-03 14:06:33 --> Language Class Initialized
INFO - 2020-09-03 14:06:33 --> Config Class Initialized
INFO - 2020-09-03 14:06:33 --> Loader Class Initialized
INFO - 2020-09-03 14:06:33 --> Helper loaded: url_helper
INFO - 2020-09-03 14:06:33 --> Helper loaded: form_helper
INFO - 2020-09-03 14:06:33 --> Helper loaded: file_helper
INFO - 2020-09-03 14:06:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 14:06:33 --> Database Driver Class Initialized
DEBUG - 2020-09-03 14:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 14:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 14:06:33 --> Upload Class Initialized
INFO - 2020-09-03 14:06:33 --> Controller Class Initialized
DEBUG - 2020-09-03 14:06:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 14:06:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 14:06:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 14:06:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 14:06:33 --> Final output sent to browser
DEBUG - 2020-09-03 14:06:33 --> Total execution time: 0.0528
INFO - 2020-09-03 14:20:36 --> Config Class Initialized
INFO - 2020-09-03 14:20:36 --> Hooks Class Initialized
DEBUG - 2020-09-03 14:20:36 --> UTF-8 Support Enabled
INFO - 2020-09-03 14:20:36 --> Utf8 Class Initialized
INFO - 2020-09-03 14:20:36 --> URI Class Initialized
INFO - 2020-09-03 14:20:36 --> Router Class Initialized
INFO - 2020-09-03 14:20:36 --> Output Class Initialized
INFO - 2020-09-03 14:20:36 --> Security Class Initialized
DEBUG - 2020-09-03 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 14:20:36 --> Input Class Initialized
INFO - 2020-09-03 14:20:36 --> Language Class Initialized
INFO - 2020-09-03 14:20:36 --> Language Class Initialized
INFO - 2020-09-03 14:20:36 --> Config Class Initialized
INFO - 2020-09-03 14:20:36 --> Loader Class Initialized
INFO - 2020-09-03 14:20:36 --> Helper loaded: url_helper
INFO - 2020-09-03 14:20:36 --> Helper loaded: form_helper
INFO - 2020-09-03 14:20:36 --> Helper loaded: file_helper
INFO - 2020-09-03 14:20:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 14:20:36 --> Database Driver Class Initialized
DEBUG - 2020-09-03 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 14:20:36 --> Upload Class Initialized
INFO - 2020-09-03 14:20:36 --> Controller Class Initialized
ERROR - 2020-09-03 14:20:36 --> 404 Page Not Found: /index
INFO - 2020-09-03 15:48:16 --> Config Class Initialized
INFO - 2020-09-03 15:48:16 --> Hooks Class Initialized
DEBUG - 2020-09-03 15:48:16 --> UTF-8 Support Enabled
INFO - 2020-09-03 15:48:16 --> Utf8 Class Initialized
INFO - 2020-09-03 15:48:16 --> URI Class Initialized
DEBUG - 2020-09-03 15:48:16 --> No URI present. Default controller set.
INFO - 2020-09-03 15:48:16 --> Router Class Initialized
INFO - 2020-09-03 15:48:16 --> Output Class Initialized
INFO - 2020-09-03 15:48:16 --> Security Class Initialized
DEBUG - 2020-09-03 15:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 15:48:16 --> Input Class Initialized
INFO - 2020-09-03 15:48:16 --> Language Class Initialized
INFO - 2020-09-03 15:48:16 --> Language Class Initialized
INFO - 2020-09-03 15:48:16 --> Config Class Initialized
INFO - 2020-09-03 15:48:16 --> Loader Class Initialized
INFO - 2020-09-03 15:48:16 --> Helper loaded: url_helper
INFO - 2020-09-03 15:48:16 --> Helper loaded: form_helper
INFO - 2020-09-03 15:48:16 --> Helper loaded: file_helper
INFO - 2020-09-03 15:48:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 15:48:16 --> Database Driver Class Initialized
DEBUG - 2020-09-03 15:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 15:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 15:48:16 --> Upload Class Initialized
INFO - 2020-09-03 15:48:16 --> Controller Class Initialized
DEBUG - 2020-09-03 15:48:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 15:48:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 15:48:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 15:48:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 15:48:16 --> Final output sent to browser
DEBUG - 2020-09-03 15:48:16 --> Total execution time: 0.0556
INFO - 2020-09-03 15:48:19 --> Config Class Initialized
INFO - 2020-09-03 15:48:19 --> Hooks Class Initialized
DEBUG - 2020-09-03 15:48:19 --> UTF-8 Support Enabled
INFO - 2020-09-03 15:48:19 --> Utf8 Class Initialized
INFO - 2020-09-03 15:48:19 --> URI Class Initialized
INFO - 2020-09-03 15:48:19 --> Router Class Initialized
INFO - 2020-09-03 15:48:19 --> Output Class Initialized
INFO - 2020-09-03 15:48:19 --> Security Class Initialized
DEBUG - 2020-09-03 15:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 15:48:19 --> Input Class Initialized
INFO - 2020-09-03 15:48:19 --> Language Class Initialized
INFO - 2020-09-03 15:48:19 --> Language Class Initialized
INFO - 2020-09-03 15:48:19 --> Config Class Initialized
INFO - 2020-09-03 15:48:19 --> Loader Class Initialized
INFO - 2020-09-03 15:48:19 --> Helper loaded: url_helper
INFO - 2020-09-03 15:48:19 --> Helper loaded: form_helper
INFO - 2020-09-03 15:48:19 --> Helper loaded: file_helper
INFO - 2020-09-03 15:48:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 15:48:19 --> Database Driver Class Initialized
DEBUG - 2020-09-03 15:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 15:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 15:48:19 --> Upload Class Initialized
INFO - 2020-09-03 15:48:19 --> Controller Class Initialized
ERROR - 2020-09-03 15:48:19 --> 404 Page Not Found: /index
INFO - 2020-09-03 16:14:16 --> Config Class Initialized
INFO - 2020-09-03 16:14:16 --> Hooks Class Initialized
DEBUG - 2020-09-03 16:14:16 --> UTF-8 Support Enabled
INFO - 2020-09-03 16:14:16 --> Utf8 Class Initialized
INFO - 2020-09-03 16:14:16 --> URI Class Initialized
INFO - 2020-09-03 16:14:16 --> Router Class Initialized
INFO - 2020-09-03 16:14:16 --> Output Class Initialized
INFO - 2020-09-03 16:14:16 --> Security Class Initialized
DEBUG - 2020-09-03 16:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 16:14:16 --> Input Class Initialized
INFO - 2020-09-03 16:14:16 --> Language Class Initialized
INFO - 2020-09-03 16:14:16 --> Language Class Initialized
INFO - 2020-09-03 16:14:16 --> Config Class Initialized
INFO - 2020-09-03 16:14:16 --> Loader Class Initialized
INFO - 2020-09-03 16:14:16 --> Helper loaded: url_helper
INFO - 2020-09-03 16:14:16 --> Helper loaded: form_helper
INFO - 2020-09-03 16:14:16 --> Helper loaded: file_helper
INFO - 2020-09-03 16:14:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 16:14:16 --> Database Driver Class Initialized
DEBUG - 2020-09-03 16:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 16:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 16:14:16 --> Upload Class Initialized
INFO - 2020-09-03 16:14:16 --> Controller Class Initialized
ERROR - 2020-09-03 16:14:16 --> 404 Page Not Found: /index
INFO - 2020-09-03 16:14:19 --> Config Class Initialized
INFO - 2020-09-03 16:14:19 --> Hooks Class Initialized
DEBUG - 2020-09-03 16:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-03 16:14:19 --> Utf8 Class Initialized
INFO - 2020-09-03 16:14:19 --> URI Class Initialized
DEBUG - 2020-09-03 16:14:19 --> No URI present. Default controller set.
INFO - 2020-09-03 16:14:19 --> Router Class Initialized
INFO - 2020-09-03 16:14:19 --> Output Class Initialized
INFO - 2020-09-03 16:14:19 --> Security Class Initialized
DEBUG - 2020-09-03 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 16:14:19 --> Input Class Initialized
INFO - 2020-09-03 16:14:19 --> Language Class Initialized
INFO - 2020-09-03 16:14:19 --> Language Class Initialized
INFO - 2020-09-03 16:14:19 --> Config Class Initialized
INFO - 2020-09-03 16:14:19 --> Loader Class Initialized
INFO - 2020-09-03 16:14:19 --> Helper loaded: url_helper
INFO - 2020-09-03 16:14:19 --> Helper loaded: form_helper
INFO - 2020-09-03 16:14:19 --> Helper loaded: file_helper
INFO - 2020-09-03 16:14:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 16:14:19 --> Database Driver Class Initialized
DEBUG - 2020-09-03 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 16:14:19 --> Upload Class Initialized
INFO - 2020-09-03 16:14:19 --> Controller Class Initialized
DEBUG - 2020-09-03 16:14:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 16:14:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 16:14:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 16:14:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 16:14:19 --> Final output sent to browser
DEBUG - 2020-09-03 16:14:19 --> Total execution time: 0.0624
INFO - 2020-09-03 16:26:02 --> Config Class Initialized
INFO - 2020-09-03 16:26:02 --> Hooks Class Initialized
DEBUG - 2020-09-03 16:26:02 --> UTF-8 Support Enabled
INFO - 2020-09-03 16:26:02 --> Utf8 Class Initialized
INFO - 2020-09-03 16:26:02 --> URI Class Initialized
DEBUG - 2020-09-03 16:26:02 --> No URI present. Default controller set.
INFO - 2020-09-03 16:26:02 --> Router Class Initialized
INFO - 2020-09-03 16:26:02 --> Output Class Initialized
INFO - 2020-09-03 16:26:02 --> Security Class Initialized
DEBUG - 2020-09-03 16:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 16:26:02 --> Input Class Initialized
INFO - 2020-09-03 16:26:02 --> Language Class Initialized
INFO - 2020-09-03 16:26:02 --> Language Class Initialized
INFO - 2020-09-03 16:26:02 --> Config Class Initialized
INFO - 2020-09-03 16:26:02 --> Loader Class Initialized
INFO - 2020-09-03 16:26:02 --> Helper loaded: url_helper
INFO - 2020-09-03 16:26:02 --> Helper loaded: form_helper
INFO - 2020-09-03 16:26:02 --> Helper loaded: file_helper
INFO - 2020-09-03 16:26:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 16:26:02 --> Database Driver Class Initialized
DEBUG - 2020-09-03 16:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 16:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 16:26:02 --> Upload Class Initialized
INFO - 2020-09-03 16:26:02 --> Controller Class Initialized
DEBUG - 2020-09-03 16:26:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 16:26:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 16:26:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 16:26:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 16:26:02 --> Final output sent to browser
DEBUG - 2020-09-03 16:26:02 --> Total execution time: 0.1950
INFO - 2020-09-03 16:30:31 --> Config Class Initialized
INFO - 2020-09-03 16:30:31 --> Hooks Class Initialized
DEBUG - 2020-09-03 16:30:31 --> UTF-8 Support Enabled
INFO - 2020-09-03 16:30:31 --> Utf8 Class Initialized
INFO - 2020-09-03 16:30:31 --> URI Class Initialized
INFO - 2020-09-03 16:30:31 --> Router Class Initialized
INFO - 2020-09-03 16:30:31 --> Output Class Initialized
INFO - 2020-09-03 16:30:31 --> Security Class Initialized
DEBUG - 2020-09-03 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 16:30:31 --> Input Class Initialized
INFO - 2020-09-03 16:30:31 --> Language Class Initialized
INFO - 2020-09-03 16:30:31 --> Language Class Initialized
INFO - 2020-09-03 16:30:31 --> Config Class Initialized
INFO - 2020-09-03 16:30:31 --> Loader Class Initialized
INFO - 2020-09-03 16:30:31 --> Helper loaded: url_helper
INFO - 2020-09-03 16:30:31 --> Helper loaded: form_helper
INFO - 2020-09-03 16:30:31 --> Helper loaded: file_helper
INFO - 2020-09-03 16:30:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 16:30:31 --> Database Driver Class Initialized
DEBUG - 2020-09-03 16:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 16:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 16:30:31 --> Upload Class Initialized
INFO - 2020-09-03 16:30:31 --> Controller Class Initialized
ERROR - 2020-09-03 16:30:31 --> 404 Page Not Found: /index
INFO - 2020-09-03 16:31:08 --> Config Class Initialized
INFO - 2020-09-03 16:31:08 --> Hooks Class Initialized
DEBUG - 2020-09-03 16:31:08 --> UTF-8 Support Enabled
INFO - 2020-09-03 16:31:08 --> Utf8 Class Initialized
INFO - 2020-09-03 16:31:08 --> URI Class Initialized
DEBUG - 2020-09-03 16:31:08 --> No URI present. Default controller set.
INFO - 2020-09-03 16:31:08 --> Router Class Initialized
INFO - 2020-09-03 16:31:08 --> Output Class Initialized
INFO - 2020-09-03 16:31:08 --> Security Class Initialized
DEBUG - 2020-09-03 16:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 16:31:08 --> Input Class Initialized
INFO - 2020-09-03 16:31:08 --> Language Class Initialized
INFO - 2020-09-03 16:31:08 --> Language Class Initialized
INFO - 2020-09-03 16:31:08 --> Config Class Initialized
INFO - 2020-09-03 16:31:08 --> Loader Class Initialized
INFO - 2020-09-03 16:31:08 --> Helper loaded: url_helper
INFO - 2020-09-03 16:31:08 --> Helper loaded: form_helper
INFO - 2020-09-03 16:31:08 --> Helper loaded: file_helper
INFO - 2020-09-03 16:31:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 16:31:08 --> Database Driver Class Initialized
DEBUG - 2020-09-03 16:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 16:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 16:31:08 --> Upload Class Initialized
INFO - 2020-09-03 16:31:08 --> Controller Class Initialized
DEBUG - 2020-09-03 16:31:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 16:31:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 16:31:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 16:31:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 16:31:08 --> Final output sent to browser
DEBUG - 2020-09-03 16:31:08 --> Total execution time: 0.0692
INFO - 2020-09-03 17:12:06 --> Config Class Initialized
INFO - 2020-09-03 17:12:06 --> Hooks Class Initialized
DEBUG - 2020-09-03 17:12:06 --> UTF-8 Support Enabled
INFO - 2020-09-03 17:12:06 --> Utf8 Class Initialized
INFO - 2020-09-03 17:12:06 --> URI Class Initialized
DEBUG - 2020-09-03 17:12:06 --> No URI present. Default controller set.
INFO - 2020-09-03 17:12:06 --> Router Class Initialized
INFO - 2020-09-03 17:12:06 --> Output Class Initialized
INFO - 2020-09-03 17:12:06 --> Security Class Initialized
DEBUG - 2020-09-03 17:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 17:12:06 --> Input Class Initialized
INFO - 2020-09-03 17:12:06 --> Language Class Initialized
INFO - 2020-09-03 17:12:06 --> Language Class Initialized
INFO - 2020-09-03 17:12:06 --> Config Class Initialized
INFO - 2020-09-03 17:12:06 --> Loader Class Initialized
INFO - 2020-09-03 17:12:06 --> Helper loaded: url_helper
INFO - 2020-09-03 17:12:06 --> Helper loaded: form_helper
INFO - 2020-09-03 17:12:06 --> Helper loaded: file_helper
INFO - 2020-09-03 17:12:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 17:12:06 --> Database Driver Class Initialized
DEBUG - 2020-09-03 17:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 17:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 17:12:06 --> Upload Class Initialized
INFO - 2020-09-03 17:12:06 --> Controller Class Initialized
DEBUG - 2020-09-03 17:12:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 17:12:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 17:12:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 17:12:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 17:12:06 --> Final output sent to browser
DEBUG - 2020-09-03 17:12:06 --> Total execution time: 0.1880
INFO - 2020-09-03 17:12:09 --> Config Class Initialized
INFO - 2020-09-03 17:12:09 --> Hooks Class Initialized
DEBUG - 2020-09-03 17:12:09 --> UTF-8 Support Enabled
INFO - 2020-09-03 17:12:09 --> Utf8 Class Initialized
INFO - 2020-09-03 17:12:09 --> URI Class Initialized
INFO - 2020-09-03 17:12:09 --> Router Class Initialized
INFO - 2020-09-03 17:12:09 --> Output Class Initialized
INFO - 2020-09-03 17:12:09 --> Security Class Initialized
DEBUG - 2020-09-03 17:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 17:12:09 --> Input Class Initialized
INFO - 2020-09-03 17:12:09 --> Language Class Initialized
INFO - 2020-09-03 17:12:09 --> Language Class Initialized
INFO - 2020-09-03 17:12:09 --> Config Class Initialized
INFO - 2020-09-03 17:12:09 --> Loader Class Initialized
INFO - 2020-09-03 17:12:09 --> Helper loaded: url_helper
INFO - 2020-09-03 17:12:09 --> Helper loaded: form_helper
INFO - 2020-09-03 17:12:09 --> Helper loaded: file_helper
INFO - 2020-09-03 17:12:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 17:12:09 --> Database Driver Class Initialized
DEBUG - 2020-09-03 17:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 17:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 17:12:09 --> Upload Class Initialized
INFO - 2020-09-03 17:12:09 --> Controller Class Initialized
ERROR - 2020-09-03 17:12:09 --> 404 Page Not Found: /index
INFO - 2020-09-03 18:04:16 --> Config Class Initialized
INFO - 2020-09-03 18:04:16 --> Hooks Class Initialized
DEBUG - 2020-09-03 18:04:16 --> UTF-8 Support Enabled
INFO - 2020-09-03 18:04:16 --> Utf8 Class Initialized
INFO - 2020-09-03 18:04:16 --> URI Class Initialized
DEBUG - 2020-09-03 18:04:16 --> No URI present. Default controller set.
INFO - 2020-09-03 18:04:16 --> Router Class Initialized
INFO - 2020-09-03 18:04:16 --> Output Class Initialized
INFO - 2020-09-03 18:04:16 --> Security Class Initialized
DEBUG - 2020-09-03 18:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 18:04:16 --> Input Class Initialized
INFO - 2020-09-03 18:04:16 --> Language Class Initialized
INFO - 2020-09-03 18:04:16 --> Language Class Initialized
INFO - 2020-09-03 18:04:16 --> Config Class Initialized
INFO - 2020-09-03 18:04:16 --> Loader Class Initialized
INFO - 2020-09-03 18:04:16 --> Helper loaded: url_helper
INFO - 2020-09-03 18:04:16 --> Helper loaded: form_helper
INFO - 2020-09-03 18:04:16 --> Helper loaded: file_helper
INFO - 2020-09-03 18:04:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 18:04:16 --> Database Driver Class Initialized
DEBUG - 2020-09-03 18:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 18:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 18:04:16 --> Upload Class Initialized
INFO - 2020-09-03 18:04:16 --> Controller Class Initialized
DEBUG - 2020-09-03 18:04:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 18:04:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 18:04:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 18:04:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 18:04:16 --> Final output sent to browser
DEBUG - 2020-09-03 18:04:16 --> Total execution time: 0.0507
INFO - 2020-09-03 18:15:01 --> Config Class Initialized
INFO - 2020-09-03 18:15:01 --> Hooks Class Initialized
DEBUG - 2020-09-03 18:15:01 --> UTF-8 Support Enabled
INFO - 2020-09-03 18:15:01 --> Utf8 Class Initialized
INFO - 2020-09-03 18:15:01 --> URI Class Initialized
INFO - 2020-09-03 18:15:01 --> Router Class Initialized
INFO - 2020-09-03 18:15:01 --> Output Class Initialized
INFO - 2020-09-03 18:15:01 --> Security Class Initialized
DEBUG - 2020-09-03 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 18:15:01 --> Input Class Initialized
INFO - 2020-09-03 18:15:01 --> Language Class Initialized
INFO - 2020-09-03 18:15:01 --> Language Class Initialized
INFO - 2020-09-03 18:15:01 --> Config Class Initialized
INFO - 2020-09-03 18:15:01 --> Loader Class Initialized
INFO - 2020-09-03 18:15:01 --> Helper loaded: url_helper
INFO - 2020-09-03 18:15:01 --> Helper loaded: form_helper
INFO - 2020-09-03 18:15:01 --> Helper loaded: file_helper
INFO - 2020-09-03 18:15:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 18:15:01 --> Database Driver Class Initialized
DEBUG - 2020-09-03 18:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 18:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 18:15:01 --> Upload Class Initialized
INFO - 2020-09-03 18:15:01 --> Controller Class Initialized
ERROR - 2020-09-03 18:15:01 --> 404 Page Not Found: /index
INFO - 2020-09-03 19:58:30 --> Config Class Initialized
INFO - 2020-09-03 19:58:30 --> Hooks Class Initialized
DEBUG - 2020-09-03 19:58:30 --> UTF-8 Support Enabled
INFO - 2020-09-03 19:58:30 --> Utf8 Class Initialized
INFO - 2020-09-03 19:58:30 --> URI Class Initialized
DEBUG - 2020-09-03 19:58:30 --> No URI present. Default controller set.
INFO - 2020-09-03 19:58:30 --> Router Class Initialized
INFO - 2020-09-03 19:58:30 --> Output Class Initialized
INFO - 2020-09-03 19:58:30 --> Security Class Initialized
DEBUG - 2020-09-03 19:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 19:58:30 --> Input Class Initialized
INFO - 2020-09-03 19:58:30 --> Language Class Initialized
INFO - 2020-09-03 19:58:30 --> Language Class Initialized
INFO - 2020-09-03 19:58:30 --> Config Class Initialized
INFO - 2020-09-03 19:58:30 --> Loader Class Initialized
INFO - 2020-09-03 19:58:30 --> Helper loaded: url_helper
INFO - 2020-09-03 19:58:30 --> Helper loaded: form_helper
INFO - 2020-09-03 19:58:30 --> Helper loaded: file_helper
INFO - 2020-09-03 19:58:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 19:58:30 --> Database Driver Class Initialized
DEBUG - 2020-09-03 19:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 19:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 19:58:30 --> Upload Class Initialized
INFO - 2020-09-03 19:58:30 --> Controller Class Initialized
DEBUG - 2020-09-03 19:58:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 19:58:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 19:58:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 19:58:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 19:58:30 --> Final output sent to browser
DEBUG - 2020-09-03 19:58:30 --> Total execution time: 0.0521
INFO - 2020-09-03 20:44:52 --> Config Class Initialized
INFO - 2020-09-03 20:44:52 --> Hooks Class Initialized
DEBUG - 2020-09-03 20:44:52 --> UTF-8 Support Enabled
INFO - 2020-09-03 20:44:52 --> Utf8 Class Initialized
INFO - 2020-09-03 20:44:52 --> URI Class Initialized
DEBUG - 2020-09-03 20:44:52 --> No URI present. Default controller set.
INFO - 2020-09-03 20:44:52 --> Router Class Initialized
INFO - 2020-09-03 20:44:52 --> Output Class Initialized
INFO - 2020-09-03 20:44:52 --> Security Class Initialized
DEBUG - 2020-09-03 20:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 20:44:52 --> Input Class Initialized
INFO - 2020-09-03 20:44:52 --> Language Class Initialized
INFO - 2020-09-03 20:44:52 --> Language Class Initialized
INFO - 2020-09-03 20:44:52 --> Config Class Initialized
INFO - 2020-09-03 20:44:52 --> Loader Class Initialized
INFO - 2020-09-03 20:44:52 --> Helper loaded: url_helper
INFO - 2020-09-03 20:44:52 --> Helper loaded: form_helper
INFO - 2020-09-03 20:44:52 --> Helper loaded: file_helper
INFO - 2020-09-03 20:44:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 20:44:52 --> Database Driver Class Initialized
DEBUG - 2020-09-03 20:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 20:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 20:44:52 --> Upload Class Initialized
INFO - 2020-09-03 20:44:52 --> Controller Class Initialized
DEBUG - 2020-09-03 20:44:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 20:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 20:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 20:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 20:44:52 --> Final output sent to browser
DEBUG - 2020-09-03 20:44:52 --> Total execution time: 0.0509
INFO - 2020-09-03 20:44:52 --> Config Class Initialized
INFO - 2020-09-03 20:44:52 --> Hooks Class Initialized
DEBUG - 2020-09-03 20:44:52 --> UTF-8 Support Enabled
INFO - 2020-09-03 20:44:52 --> Utf8 Class Initialized
INFO - 2020-09-03 20:44:52 --> URI Class Initialized
DEBUG - 2020-09-03 20:44:52 --> No URI present. Default controller set.
INFO - 2020-09-03 20:44:52 --> Router Class Initialized
INFO - 2020-09-03 20:44:52 --> Output Class Initialized
INFO - 2020-09-03 20:44:52 --> Security Class Initialized
DEBUG - 2020-09-03 20:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 20:44:52 --> Input Class Initialized
INFO - 2020-09-03 20:44:52 --> Language Class Initialized
INFO - 2020-09-03 20:44:52 --> Language Class Initialized
INFO - 2020-09-03 20:44:52 --> Config Class Initialized
INFO - 2020-09-03 20:44:52 --> Loader Class Initialized
INFO - 2020-09-03 20:44:52 --> Helper loaded: url_helper
INFO - 2020-09-03 20:44:52 --> Helper loaded: form_helper
INFO - 2020-09-03 20:44:52 --> Helper loaded: file_helper
INFO - 2020-09-03 20:44:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 20:44:52 --> Database Driver Class Initialized
DEBUG - 2020-09-03 20:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 20:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 20:44:52 --> Upload Class Initialized
INFO - 2020-09-03 20:44:52 --> Controller Class Initialized
DEBUG - 2020-09-03 20:44:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 20:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 20:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 20:44:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 20:44:52 --> Final output sent to browser
DEBUG - 2020-09-03 20:44:52 --> Total execution time: 0.0521
INFO - 2020-09-03 21:28:03 --> Config Class Initialized
INFO - 2020-09-03 21:28:03 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:28:03 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:28:03 --> Utf8 Class Initialized
INFO - 2020-09-03 21:28:03 --> URI Class Initialized
INFO - 2020-09-03 21:28:03 --> Router Class Initialized
INFO - 2020-09-03 21:28:03 --> Output Class Initialized
INFO - 2020-09-03 21:28:03 --> Security Class Initialized
DEBUG - 2020-09-03 21:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:28:03 --> Input Class Initialized
INFO - 2020-09-03 21:28:03 --> Language Class Initialized
INFO - 2020-09-03 21:28:03 --> Language Class Initialized
INFO - 2020-09-03 21:28:03 --> Config Class Initialized
INFO - 2020-09-03 21:28:03 --> Loader Class Initialized
INFO - 2020-09-03 21:28:03 --> Helper loaded: url_helper
INFO - 2020-09-03 21:28:03 --> Helper loaded: form_helper
INFO - 2020-09-03 21:28:03 --> Helper loaded: file_helper
INFO - 2020-09-03 21:28:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:28:03 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:28:03 --> Upload Class Initialized
INFO - 2020-09-03 21:28:03 --> Controller Class Initialized
ERROR - 2020-09-03 21:28:03 --> 404 Page Not Found: /index
INFO - 2020-09-03 21:54:55 --> Config Class Initialized
INFO - 2020-09-03 21:54:55 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:54:55 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:54:55 --> Utf8 Class Initialized
INFO - 2020-09-03 21:54:55 --> URI Class Initialized
INFO - 2020-09-03 21:54:55 --> Router Class Initialized
INFO - 2020-09-03 21:54:55 --> Output Class Initialized
INFO - 2020-09-03 21:54:55 --> Security Class Initialized
DEBUG - 2020-09-03 21:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:54:55 --> Input Class Initialized
INFO - 2020-09-03 21:54:55 --> Language Class Initialized
INFO - 2020-09-03 21:54:55 --> Language Class Initialized
INFO - 2020-09-03 21:54:55 --> Config Class Initialized
INFO - 2020-09-03 21:54:55 --> Loader Class Initialized
INFO - 2020-09-03 21:54:55 --> Helper loaded: url_helper
INFO - 2020-09-03 21:54:55 --> Helper loaded: form_helper
INFO - 2020-09-03 21:54:55 --> Helper loaded: file_helper
INFO - 2020-09-03 21:54:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:54:55 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:54:55 --> Upload Class Initialized
INFO - 2020-09-03 21:54:55 --> Controller Class Initialized
DEBUG - 2020-09-03 21:54:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 21:54:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-03 21:54:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 21:54:55 --> Final output sent to browser
DEBUG - 2020-09-03 21:54:55 --> Total execution time: 0.0682
INFO - 2020-09-03 21:54:57 --> Config Class Initialized
INFO - 2020-09-03 21:54:57 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:54:57 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:54:57 --> Utf8 Class Initialized
INFO - 2020-09-03 21:54:57 --> URI Class Initialized
INFO - 2020-09-03 21:54:57 --> Router Class Initialized
INFO - 2020-09-03 21:54:57 --> Output Class Initialized
INFO - 2020-09-03 21:54:57 --> Security Class Initialized
DEBUG - 2020-09-03 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:54:57 --> Input Class Initialized
INFO - 2020-09-03 21:54:57 --> Language Class Initialized
INFO - 2020-09-03 21:54:57 --> Language Class Initialized
INFO - 2020-09-03 21:54:57 --> Config Class Initialized
INFO - 2020-09-03 21:54:57 --> Loader Class Initialized
INFO - 2020-09-03 21:54:57 --> Helper loaded: url_helper
INFO - 2020-09-03 21:54:57 --> Helper loaded: form_helper
INFO - 2020-09-03 21:54:57 --> Helper loaded: file_helper
INFO - 2020-09-03 21:54:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:54:57 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:54:57 --> Upload Class Initialized
INFO - 2020-09-03 21:54:57 --> Controller Class Initialized
ERROR - 2020-09-03 21:54:57 --> 404 Page Not Found: /index
INFO - 2020-09-03 21:56:03 --> Config Class Initialized
INFO - 2020-09-03 21:56:03 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:03 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:03 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:03 --> URI Class Initialized
DEBUG - 2020-09-03 21:56:03 --> No URI present. Default controller set.
INFO - 2020-09-03 21:56:03 --> Router Class Initialized
INFO - 2020-09-03 21:56:03 --> Output Class Initialized
INFO - 2020-09-03 21:56:03 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:03 --> Input Class Initialized
INFO - 2020-09-03 21:56:03 --> Language Class Initialized
INFO - 2020-09-03 21:56:03 --> Language Class Initialized
INFO - 2020-09-03 21:56:03 --> Config Class Initialized
INFO - 2020-09-03 21:56:03 --> Loader Class Initialized
INFO - 2020-09-03 21:56:03 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:03 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:03 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:03 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:03 --> Upload Class Initialized
INFO - 2020-09-03 21:56:03 --> Controller Class Initialized
DEBUG - 2020-09-03 21:56:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 21:56:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 21:56:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 21:56:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 21:56:03 --> Final output sent to browser
DEBUG - 2020-09-03 21:56:03 --> Total execution time: 0.0840
INFO - 2020-09-03 21:56:05 --> Config Class Initialized
INFO - 2020-09-03 21:56:05 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:05 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:05 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:05 --> URI Class Initialized
DEBUG - 2020-09-03 21:56:05 --> No URI present. Default controller set.
INFO - 2020-09-03 21:56:05 --> Router Class Initialized
INFO - 2020-09-03 21:56:05 --> Output Class Initialized
INFO - 2020-09-03 21:56:05 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:05 --> Input Class Initialized
INFO - 2020-09-03 21:56:05 --> Language Class Initialized
INFO - 2020-09-03 21:56:05 --> Language Class Initialized
INFO - 2020-09-03 21:56:05 --> Config Class Initialized
INFO - 2020-09-03 21:56:05 --> Loader Class Initialized
INFO - 2020-09-03 21:56:05 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:05 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:05 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:05 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:05 --> Upload Class Initialized
INFO - 2020-09-03 21:56:05 --> Controller Class Initialized
DEBUG - 2020-09-03 21:56:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 21:56:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 21:56:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 21:56:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 21:56:05 --> Final output sent to browser
DEBUG - 2020-09-03 21:56:05 --> Total execution time: 0.0687
INFO - 2020-09-03 21:56:12 --> Config Class Initialized
INFO - 2020-09-03 21:56:12 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:12 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:12 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:12 --> URI Class Initialized
INFO - 2020-09-03 21:56:12 --> Router Class Initialized
INFO - 2020-09-03 21:56:12 --> Output Class Initialized
INFO - 2020-09-03 21:56:12 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:12 --> Input Class Initialized
INFO - 2020-09-03 21:56:12 --> Language Class Initialized
INFO - 2020-09-03 21:56:12 --> Language Class Initialized
INFO - 2020-09-03 21:56:12 --> Config Class Initialized
INFO - 2020-09-03 21:56:12 --> Loader Class Initialized
INFO - 2020-09-03 21:56:12 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:12 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:12 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:12 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:12 --> Upload Class Initialized
INFO - 2020-09-03 21:56:12 --> Controller Class Initialized
ERROR - 2020-09-03 21:56:12 --> 404 Page Not Found: /index
INFO - 2020-09-03 21:56:17 --> Config Class Initialized
INFO - 2020-09-03 21:56:17 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:17 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:17 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:17 --> URI Class Initialized
INFO - 2020-09-03 21:56:17 --> Router Class Initialized
INFO - 2020-09-03 21:56:17 --> Output Class Initialized
INFO - 2020-09-03 21:56:17 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:17 --> Input Class Initialized
INFO - 2020-09-03 21:56:17 --> Language Class Initialized
INFO - 2020-09-03 21:56:17 --> Language Class Initialized
INFO - 2020-09-03 21:56:17 --> Config Class Initialized
INFO - 2020-09-03 21:56:17 --> Loader Class Initialized
INFO - 2020-09-03 21:56:17 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:17 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:17 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:17 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:17 --> Upload Class Initialized
INFO - 2020-09-03 21:56:17 --> Controller Class Initialized
ERROR - 2020-09-03 21:56:17 --> 404 Page Not Found: /index
INFO - 2020-09-03 21:56:19 --> Config Class Initialized
INFO - 2020-09-03 21:56:19 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:19 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:19 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:19 --> URI Class Initialized
DEBUG - 2020-09-03 21:56:19 --> No URI present. Default controller set.
INFO - 2020-09-03 21:56:19 --> Router Class Initialized
INFO - 2020-09-03 21:56:19 --> Output Class Initialized
INFO - 2020-09-03 21:56:19 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:19 --> Input Class Initialized
INFO - 2020-09-03 21:56:19 --> Language Class Initialized
INFO - 2020-09-03 21:56:19 --> Language Class Initialized
INFO - 2020-09-03 21:56:19 --> Config Class Initialized
INFO - 2020-09-03 21:56:19 --> Loader Class Initialized
INFO - 2020-09-03 21:56:19 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:19 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:19 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:19 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:19 --> Upload Class Initialized
INFO - 2020-09-03 21:56:19 --> Controller Class Initialized
DEBUG - 2020-09-03 21:56:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 21:56:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 21:56:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 21:56:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 21:56:19 --> Final output sent to browser
DEBUG - 2020-09-03 21:56:19 --> Total execution time: 0.0897
INFO - 2020-09-03 21:56:29 --> Config Class Initialized
INFO - 2020-09-03 21:56:29 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:29 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:29 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:29 --> URI Class Initialized
INFO - 2020-09-03 21:56:29 --> Router Class Initialized
INFO - 2020-09-03 21:56:29 --> Output Class Initialized
INFO - 2020-09-03 21:56:29 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:29 --> Input Class Initialized
INFO - 2020-09-03 21:56:29 --> Language Class Initialized
INFO - 2020-09-03 21:56:29 --> Language Class Initialized
INFO - 2020-09-03 21:56:29 --> Config Class Initialized
INFO - 2020-09-03 21:56:29 --> Loader Class Initialized
INFO - 2020-09-03 21:56:29 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:29 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:29 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:29 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:29 --> Upload Class Initialized
INFO - 2020-09-03 21:56:29 --> Controller Class Initialized
ERROR - 2020-09-03 21:56:29 --> 404 Page Not Found: /index
INFO - 2020-09-03 21:56:31 --> Config Class Initialized
INFO - 2020-09-03 21:56:31 --> Hooks Class Initialized
DEBUG - 2020-09-03 21:56:31 --> UTF-8 Support Enabled
INFO - 2020-09-03 21:56:31 --> Utf8 Class Initialized
INFO - 2020-09-03 21:56:31 --> URI Class Initialized
DEBUG - 2020-09-03 21:56:31 --> No URI present. Default controller set.
INFO - 2020-09-03 21:56:31 --> Router Class Initialized
INFO - 2020-09-03 21:56:31 --> Output Class Initialized
INFO - 2020-09-03 21:56:31 --> Security Class Initialized
DEBUG - 2020-09-03 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 21:56:31 --> Input Class Initialized
INFO - 2020-09-03 21:56:31 --> Language Class Initialized
INFO - 2020-09-03 21:56:31 --> Language Class Initialized
INFO - 2020-09-03 21:56:31 --> Config Class Initialized
INFO - 2020-09-03 21:56:31 --> Loader Class Initialized
INFO - 2020-09-03 21:56:31 --> Helper loaded: url_helper
INFO - 2020-09-03 21:56:31 --> Helper loaded: form_helper
INFO - 2020-09-03 21:56:31 --> Helper loaded: file_helper
INFO - 2020-09-03 21:56:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 21:56:31 --> Database Driver Class Initialized
DEBUG - 2020-09-03 21:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 21:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 21:56:31 --> Upload Class Initialized
INFO - 2020-09-03 21:56:31 --> Controller Class Initialized
DEBUG - 2020-09-03 21:56:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 21:56:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 21:56:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 21:56:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 21:56:31 --> Final output sent to browser
DEBUG - 2020-09-03 21:56:31 --> Total execution time: 0.0536
INFO - 2020-09-03 23:12:44 --> Config Class Initialized
INFO - 2020-09-03 23:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-03 23:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-03 23:12:44 --> Utf8 Class Initialized
INFO - 2020-09-03 23:12:44 --> URI Class Initialized
DEBUG - 2020-09-03 23:12:44 --> No URI present. Default controller set.
INFO - 2020-09-03 23:12:44 --> Router Class Initialized
INFO - 2020-09-03 23:12:44 --> Output Class Initialized
INFO - 2020-09-03 23:12:44 --> Security Class Initialized
DEBUG - 2020-09-03 23:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 23:12:44 --> Input Class Initialized
INFO - 2020-09-03 23:12:44 --> Language Class Initialized
INFO - 2020-09-03 23:12:44 --> Language Class Initialized
INFO - 2020-09-03 23:12:44 --> Config Class Initialized
INFO - 2020-09-03 23:12:44 --> Loader Class Initialized
INFO - 2020-09-03 23:12:44 --> Helper loaded: url_helper
INFO - 2020-09-03 23:12:44 --> Helper loaded: form_helper
INFO - 2020-09-03 23:12:44 --> Helper loaded: file_helper
INFO - 2020-09-03 23:12:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 23:12:44 --> Database Driver Class Initialized
DEBUG - 2020-09-03 23:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 23:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 23:12:44 --> Upload Class Initialized
INFO - 2020-09-03 23:12:44 --> Controller Class Initialized
DEBUG - 2020-09-03 23:12:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 23:12:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 23:12:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 23:12:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 23:12:44 --> Final output sent to browser
DEBUG - 2020-09-03 23:12:44 --> Total execution time: 0.0564
INFO - 2020-09-03 23:17:39 --> Config Class Initialized
INFO - 2020-09-03 23:17:39 --> Hooks Class Initialized
DEBUG - 2020-09-03 23:17:39 --> UTF-8 Support Enabled
INFO - 2020-09-03 23:17:39 --> Utf8 Class Initialized
INFO - 2020-09-03 23:17:39 --> URI Class Initialized
DEBUG - 2020-09-03 23:17:39 --> No URI present. Default controller set.
INFO - 2020-09-03 23:17:39 --> Router Class Initialized
INFO - 2020-09-03 23:17:39 --> Output Class Initialized
INFO - 2020-09-03 23:17:39 --> Security Class Initialized
DEBUG - 2020-09-03 23:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 23:17:39 --> Input Class Initialized
INFO - 2020-09-03 23:17:39 --> Language Class Initialized
INFO - 2020-09-03 23:17:39 --> Language Class Initialized
INFO - 2020-09-03 23:17:39 --> Config Class Initialized
INFO - 2020-09-03 23:17:39 --> Loader Class Initialized
INFO - 2020-09-03 23:17:39 --> Helper loaded: url_helper
INFO - 2020-09-03 23:17:39 --> Helper loaded: form_helper
INFO - 2020-09-03 23:17:39 --> Helper loaded: file_helper
INFO - 2020-09-03 23:17:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-03 23:17:39 --> Database Driver Class Initialized
DEBUG - 2020-09-03 23:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-03 23:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 23:17:39 --> Upload Class Initialized
INFO - 2020-09-03 23:17:39 --> Controller Class Initialized
DEBUG - 2020-09-03 23:17:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-03 23:17:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-03 23:17:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-03 23:17:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-03 23:17:39 --> Final output sent to browser
DEBUG - 2020-09-03 23:17:39 --> Total execution time: 0.0568
