<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-04 00:23:41 --> Config Class Initialized
INFO - 2020-09-04 00:23:41 --> Hooks Class Initialized
DEBUG - 2020-09-04 00:23:41 --> UTF-8 Support Enabled
INFO - 2020-09-04 00:23:41 --> Utf8 Class Initialized
INFO - 2020-09-04 00:23:41 --> URI Class Initialized
INFO - 2020-09-04 00:23:41 --> Router Class Initialized
INFO - 2020-09-04 00:23:41 --> Output Class Initialized
INFO - 2020-09-04 00:23:41 --> Security Class Initialized
DEBUG - 2020-09-04 00:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 00:23:41 --> Input Class Initialized
INFO - 2020-09-04 00:23:41 --> Language Class Initialized
INFO - 2020-09-04 00:23:41 --> Language Class Initialized
INFO - 2020-09-04 00:23:41 --> Config Class Initialized
INFO - 2020-09-04 00:23:41 --> Loader Class Initialized
INFO - 2020-09-04 00:23:41 --> Helper loaded: url_helper
INFO - 2020-09-04 00:23:41 --> Helper loaded: form_helper
INFO - 2020-09-04 00:23:41 --> Helper loaded: file_helper
INFO - 2020-09-04 00:23:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 00:23:42 --> Database Driver Class Initialized
DEBUG - 2020-09-04 00:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 00:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 00:23:42 --> Upload Class Initialized
INFO - 2020-09-04 00:23:42 --> Controller Class Initialized
ERROR - 2020-09-04 00:23:42 --> 404 Page Not Found: /index
INFO - 2020-09-04 00:23:42 --> Config Class Initialized
INFO - 2020-09-04 00:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-04 00:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-04 00:23:42 --> Utf8 Class Initialized
INFO - 2020-09-04 00:23:42 --> URI Class Initialized
INFO - 2020-09-04 00:23:42 --> Router Class Initialized
INFO - 2020-09-04 00:23:42 --> Output Class Initialized
INFO - 2020-09-04 00:23:42 --> Security Class Initialized
DEBUG - 2020-09-04 00:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 00:23:42 --> Input Class Initialized
INFO - 2020-09-04 00:23:42 --> Language Class Initialized
INFO - 2020-09-04 00:23:42 --> Language Class Initialized
INFO - 2020-09-04 00:23:42 --> Config Class Initialized
INFO - 2020-09-04 00:23:42 --> Loader Class Initialized
INFO - 2020-09-04 00:23:42 --> Helper loaded: url_helper
INFO - 2020-09-04 00:23:42 --> Helper loaded: form_helper
INFO - 2020-09-04 00:23:42 --> Helper loaded: file_helper
INFO - 2020-09-04 00:23:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 00:23:42 --> Database Driver Class Initialized
DEBUG - 2020-09-04 00:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 00:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 00:23:42 --> Upload Class Initialized
INFO - 2020-09-04 00:23:42 --> Controller Class Initialized
ERROR - 2020-09-04 00:23:42 --> 404 Page Not Found: /index
INFO - 2020-09-04 00:47:54 --> Config Class Initialized
INFO - 2020-09-04 00:47:54 --> Hooks Class Initialized
DEBUG - 2020-09-04 00:47:54 --> UTF-8 Support Enabled
INFO - 2020-09-04 00:47:54 --> Utf8 Class Initialized
INFO - 2020-09-04 00:47:54 --> URI Class Initialized
DEBUG - 2020-09-04 00:47:54 --> No URI present. Default controller set.
INFO - 2020-09-04 00:47:54 --> Router Class Initialized
INFO - 2020-09-04 00:47:54 --> Output Class Initialized
INFO - 2020-09-04 00:47:54 --> Security Class Initialized
DEBUG - 2020-09-04 00:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 00:47:54 --> Input Class Initialized
INFO - 2020-09-04 00:47:54 --> Language Class Initialized
INFO - 2020-09-04 00:47:54 --> Language Class Initialized
INFO - 2020-09-04 00:47:54 --> Config Class Initialized
INFO - 2020-09-04 00:47:54 --> Loader Class Initialized
INFO - 2020-09-04 00:47:54 --> Helper loaded: url_helper
INFO - 2020-09-04 00:47:54 --> Helper loaded: form_helper
INFO - 2020-09-04 00:47:54 --> Helper loaded: file_helper
INFO - 2020-09-04 00:47:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 00:47:54 --> Database Driver Class Initialized
DEBUG - 2020-09-04 00:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 00:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 00:47:54 --> Upload Class Initialized
INFO - 2020-09-04 00:47:54 --> Controller Class Initialized
DEBUG - 2020-09-04 00:47:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 00:47:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 00:47:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 00:47:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 00:47:54 --> Final output sent to browser
DEBUG - 2020-09-04 00:47:54 --> Total execution time: 0.0522
INFO - 2020-09-04 01:12:07 --> Config Class Initialized
INFO - 2020-09-04 01:12:07 --> Hooks Class Initialized
DEBUG - 2020-09-04 01:12:07 --> UTF-8 Support Enabled
INFO - 2020-09-04 01:12:07 --> Utf8 Class Initialized
INFO - 2020-09-04 01:12:07 --> URI Class Initialized
DEBUG - 2020-09-04 01:12:07 --> No URI present. Default controller set.
INFO - 2020-09-04 01:12:07 --> Router Class Initialized
INFO - 2020-09-04 01:12:07 --> Output Class Initialized
INFO - 2020-09-04 01:12:07 --> Security Class Initialized
DEBUG - 2020-09-04 01:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 01:12:07 --> Input Class Initialized
INFO - 2020-09-04 01:12:07 --> Language Class Initialized
INFO - 2020-09-04 01:12:07 --> Language Class Initialized
INFO - 2020-09-04 01:12:07 --> Config Class Initialized
INFO - 2020-09-04 01:12:07 --> Loader Class Initialized
INFO - 2020-09-04 01:12:07 --> Helper loaded: url_helper
INFO - 2020-09-04 01:12:07 --> Helper loaded: form_helper
INFO - 2020-09-04 01:12:07 --> Helper loaded: file_helper
INFO - 2020-09-04 01:12:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 01:12:07 --> Database Driver Class Initialized
DEBUG - 2020-09-04 01:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 01:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 01:12:07 --> Upload Class Initialized
INFO - 2020-09-04 01:12:07 --> Controller Class Initialized
DEBUG - 2020-09-04 01:12:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 01:12:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 01:12:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 01:12:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 01:12:07 --> Final output sent to browser
DEBUG - 2020-09-04 01:12:07 --> Total execution time: 0.0604
INFO - 2020-09-04 02:36:57 --> Config Class Initialized
INFO - 2020-09-04 02:36:57 --> Hooks Class Initialized
DEBUG - 2020-09-04 02:36:57 --> UTF-8 Support Enabled
INFO - 2020-09-04 02:36:57 --> Utf8 Class Initialized
INFO - 2020-09-04 02:36:57 --> URI Class Initialized
DEBUG - 2020-09-04 02:36:57 --> No URI present. Default controller set.
INFO - 2020-09-04 02:36:57 --> Router Class Initialized
INFO - 2020-09-04 02:36:57 --> Output Class Initialized
INFO - 2020-09-04 02:36:57 --> Security Class Initialized
DEBUG - 2020-09-04 02:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 02:36:57 --> Input Class Initialized
INFO - 2020-09-04 02:36:57 --> Language Class Initialized
INFO - 2020-09-04 02:36:57 --> Language Class Initialized
INFO - 2020-09-04 02:36:57 --> Config Class Initialized
INFO - 2020-09-04 02:36:57 --> Loader Class Initialized
INFO - 2020-09-04 02:36:57 --> Helper loaded: url_helper
INFO - 2020-09-04 02:36:57 --> Helper loaded: form_helper
INFO - 2020-09-04 02:36:57 --> Helper loaded: file_helper
INFO - 2020-09-04 02:36:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 02:36:57 --> Database Driver Class Initialized
DEBUG - 2020-09-04 02:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 02:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 02:36:57 --> Upload Class Initialized
INFO - 2020-09-04 02:36:57 --> Controller Class Initialized
DEBUG - 2020-09-04 02:36:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 02:36:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 02:36:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 02:36:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 02:36:57 --> Final output sent to browser
DEBUG - 2020-09-04 02:36:57 --> Total execution time: 0.0539
INFO - 2020-09-04 02:37:16 --> Config Class Initialized
INFO - 2020-09-04 02:37:16 --> Hooks Class Initialized
DEBUG - 2020-09-04 02:37:16 --> UTF-8 Support Enabled
INFO - 2020-09-04 02:37:16 --> Utf8 Class Initialized
INFO - 2020-09-04 02:37:16 --> URI Class Initialized
DEBUG - 2020-09-04 02:37:16 --> No URI present. Default controller set.
INFO - 2020-09-04 02:37:16 --> Router Class Initialized
INFO - 2020-09-04 02:37:16 --> Output Class Initialized
INFO - 2020-09-04 02:37:16 --> Security Class Initialized
DEBUG - 2020-09-04 02:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 02:37:16 --> Input Class Initialized
INFO - 2020-09-04 02:37:16 --> Language Class Initialized
INFO - 2020-09-04 02:37:16 --> Language Class Initialized
INFO - 2020-09-04 02:37:16 --> Config Class Initialized
INFO - 2020-09-04 02:37:16 --> Loader Class Initialized
INFO - 2020-09-04 02:37:16 --> Helper loaded: url_helper
INFO - 2020-09-04 02:37:16 --> Helper loaded: form_helper
INFO - 2020-09-04 02:37:16 --> Helper loaded: file_helper
INFO - 2020-09-04 02:37:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 02:37:16 --> Database Driver Class Initialized
DEBUG - 2020-09-04 02:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 02:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 02:37:16 --> Upload Class Initialized
INFO - 2020-09-04 02:37:16 --> Controller Class Initialized
DEBUG - 2020-09-04 02:37:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 02:37:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 02:37:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 02:37:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 02:37:16 --> Final output sent to browser
DEBUG - 2020-09-04 02:37:16 --> Total execution time: 0.0502
INFO - 2020-09-04 02:44:33 --> Config Class Initialized
INFO - 2020-09-04 02:44:33 --> Hooks Class Initialized
DEBUG - 2020-09-04 02:44:33 --> UTF-8 Support Enabled
INFO - 2020-09-04 02:44:33 --> Utf8 Class Initialized
INFO - 2020-09-04 02:44:33 --> URI Class Initialized
DEBUG - 2020-09-04 02:44:33 --> No URI present. Default controller set.
INFO - 2020-09-04 02:44:33 --> Router Class Initialized
INFO - 2020-09-04 02:44:33 --> Output Class Initialized
INFO - 2020-09-04 02:44:33 --> Security Class Initialized
DEBUG - 2020-09-04 02:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 02:44:33 --> Input Class Initialized
INFO - 2020-09-04 02:44:33 --> Language Class Initialized
INFO - 2020-09-04 02:44:33 --> Language Class Initialized
INFO - 2020-09-04 02:44:33 --> Config Class Initialized
INFO - 2020-09-04 02:44:33 --> Loader Class Initialized
INFO - 2020-09-04 02:44:33 --> Helper loaded: url_helper
INFO - 2020-09-04 02:44:33 --> Helper loaded: form_helper
INFO - 2020-09-04 02:44:33 --> Helper loaded: file_helper
INFO - 2020-09-04 02:44:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 02:44:33 --> Database Driver Class Initialized
DEBUG - 2020-09-04 02:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 02:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 02:44:33 --> Upload Class Initialized
INFO - 2020-09-04 02:44:33 --> Controller Class Initialized
DEBUG - 2020-09-04 02:44:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 02:44:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 02:44:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 02:44:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 02:44:33 --> Final output sent to browser
DEBUG - 2020-09-04 02:44:33 --> Total execution time: 0.0505
INFO - 2020-09-04 02:44:34 --> Config Class Initialized
INFO - 2020-09-04 02:44:34 --> Hooks Class Initialized
DEBUG - 2020-09-04 02:44:34 --> UTF-8 Support Enabled
INFO - 2020-09-04 02:44:34 --> Utf8 Class Initialized
INFO - 2020-09-04 02:44:34 --> URI Class Initialized
DEBUG - 2020-09-04 02:44:34 --> No URI present. Default controller set.
INFO - 2020-09-04 02:44:34 --> Router Class Initialized
INFO - 2020-09-04 02:44:34 --> Output Class Initialized
INFO - 2020-09-04 02:44:34 --> Security Class Initialized
DEBUG - 2020-09-04 02:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 02:44:34 --> Input Class Initialized
INFO - 2020-09-04 02:44:34 --> Language Class Initialized
INFO - 2020-09-04 02:44:34 --> Language Class Initialized
INFO - 2020-09-04 02:44:34 --> Config Class Initialized
INFO - 2020-09-04 02:44:34 --> Loader Class Initialized
INFO - 2020-09-04 02:44:34 --> Helper loaded: url_helper
INFO - 2020-09-04 02:44:34 --> Helper loaded: form_helper
INFO - 2020-09-04 02:44:34 --> Helper loaded: file_helper
INFO - 2020-09-04 02:44:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 02:44:34 --> Database Driver Class Initialized
DEBUG - 2020-09-04 02:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 02:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 02:44:34 --> Upload Class Initialized
INFO - 2020-09-04 02:44:34 --> Controller Class Initialized
DEBUG - 2020-09-04 02:44:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 02:44:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 02:44:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 02:44:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 02:44:34 --> Final output sent to browser
DEBUG - 2020-09-04 02:44:34 --> Total execution time: 0.0497
INFO - 2020-09-04 02:45:50 --> Config Class Initialized
INFO - 2020-09-04 02:45:50 --> Hooks Class Initialized
DEBUG - 2020-09-04 02:45:50 --> UTF-8 Support Enabled
INFO - 2020-09-04 02:45:50 --> Utf8 Class Initialized
INFO - 2020-09-04 02:45:50 --> URI Class Initialized
DEBUG - 2020-09-04 02:45:50 --> No URI present. Default controller set.
INFO - 2020-09-04 02:45:50 --> Router Class Initialized
INFO - 2020-09-04 02:45:50 --> Output Class Initialized
INFO - 2020-09-04 02:45:50 --> Security Class Initialized
DEBUG - 2020-09-04 02:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 02:45:50 --> Input Class Initialized
INFO - 2020-09-04 02:45:50 --> Language Class Initialized
INFO - 2020-09-04 02:45:50 --> Language Class Initialized
INFO - 2020-09-04 02:45:50 --> Config Class Initialized
INFO - 2020-09-04 02:45:50 --> Loader Class Initialized
INFO - 2020-09-04 02:45:50 --> Helper loaded: url_helper
INFO - 2020-09-04 02:45:50 --> Helper loaded: form_helper
INFO - 2020-09-04 02:45:50 --> Helper loaded: file_helper
INFO - 2020-09-04 02:45:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 02:45:50 --> Database Driver Class Initialized
DEBUG - 2020-09-04 02:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 02:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 02:45:50 --> Upload Class Initialized
INFO - 2020-09-04 02:45:50 --> Controller Class Initialized
DEBUG - 2020-09-04 02:45:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 02:45:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 02:45:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 02:45:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 02:45:50 --> Final output sent to browser
DEBUG - 2020-09-04 02:45:50 --> Total execution time: 0.0493
INFO - 2020-09-04 03:08:35 --> Config Class Initialized
INFO - 2020-09-04 03:08:35 --> Hooks Class Initialized
DEBUG - 2020-09-04 03:08:35 --> UTF-8 Support Enabled
INFO - 2020-09-04 03:08:35 --> Utf8 Class Initialized
INFO - 2020-09-04 03:08:35 --> URI Class Initialized
DEBUG - 2020-09-04 03:08:35 --> No URI present. Default controller set.
INFO - 2020-09-04 03:08:35 --> Router Class Initialized
INFO - 2020-09-04 03:08:35 --> Output Class Initialized
INFO - 2020-09-04 03:08:35 --> Security Class Initialized
DEBUG - 2020-09-04 03:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 03:08:35 --> Input Class Initialized
INFO - 2020-09-04 03:08:35 --> Language Class Initialized
INFO - 2020-09-04 03:08:35 --> Language Class Initialized
INFO - 2020-09-04 03:08:35 --> Config Class Initialized
INFO - 2020-09-04 03:08:35 --> Loader Class Initialized
INFO - 2020-09-04 03:08:35 --> Helper loaded: url_helper
INFO - 2020-09-04 03:08:35 --> Helper loaded: form_helper
INFO - 2020-09-04 03:08:35 --> Helper loaded: file_helper
INFO - 2020-09-04 03:08:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 03:08:35 --> Database Driver Class Initialized
DEBUG - 2020-09-04 03:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 03:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 03:08:35 --> Upload Class Initialized
INFO - 2020-09-04 03:08:35 --> Controller Class Initialized
DEBUG - 2020-09-04 03:08:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 03:08:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 03:08:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 03:08:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 03:08:35 --> Final output sent to browser
DEBUG - 2020-09-04 03:08:35 --> Total execution time: 0.0898
INFO - 2020-09-04 03:37:19 --> Config Class Initialized
INFO - 2020-09-04 03:37:19 --> Hooks Class Initialized
DEBUG - 2020-09-04 03:37:19 --> UTF-8 Support Enabled
INFO - 2020-09-04 03:37:19 --> Utf8 Class Initialized
INFO - 2020-09-04 03:37:19 --> URI Class Initialized
INFO - 2020-09-04 03:37:19 --> Router Class Initialized
INFO - 2020-09-04 03:37:19 --> Output Class Initialized
INFO - 2020-09-04 03:37:19 --> Security Class Initialized
DEBUG - 2020-09-04 03:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 03:37:19 --> Input Class Initialized
INFO - 2020-09-04 03:37:19 --> Language Class Initialized
INFO - 2020-09-04 03:37:19 --> Language Class Initialized
INFO - 2020-09-04 03:37:19 --> Config Class Initialized
INFO - 2020-09-04 03:37:19 --> Loader Class Initialized
INFO - 2020-09-04 03:37:19 --> Helper loaded: url_helper
INFO - 2020-09-04 03:37:19 --> Helper loaded: form_helper
INFO - 2020-09-04 03:37:19 --> Helper loaded: file_helper
INFO - 2020-09-04 03:37:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 03:37:19 --> Database Driver Class Initialized
DEBUG - 2020-09-04 03:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 03:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 03:37:19 --> Upload Class Initialized
INFO - 2020-09-04 03:37:19 --> Controller Class Initialized
ERROR - 2020-09-04 03:37:19 --> 404 Page Not Found: /index
INFO - 2020-09-04 03:37:20 --> Config Class Initialized
INFO - 2020-09-04 03:37:20 --> Hooks Class Initialized
DEBUG - 2020-09-04 03:37:20 --> UTF-8 Support Enabled
INFO - 2020-09-04 03:37:20 --> Utf8 Class Initialized
INFO - 2020-09-04 03:37:20 --> URI Class Initialized
DEBUG - 2020-09-04 03:37:20 --> No URI present. Default controller set.
INFO - 2020-09-04 03:37:20 --> Router Class Initialized
INFO - 2020-09-04 03:37:20 --> Output Class Initialized
INFO - 2020-09-04 03:37:20 --> Security Class Initialized
DEBUG - 2020-09-04 03:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 03:37:20 --> Input Class Initialized
INFO - 2020-09-04 03:37:20 --> Language Class Initialized
INFO - 2020-09-04 03:37:20 --> Language Class Initialized
INFO - 2020-09-04 03:37:20 --> Config Class Initialized
INFO - 2020-09-04 03:37:20 --> Loader Class Initialized
INFO - 2020-09-04 03:37:20 --> Helper loaded: url_helper
INFO - 2020-09-04 03:37:20 --> Helper loaded: form_helper
INFO - 2020-09-04 03:37:20 --> Helper loaded: file_helper
INFO - 2020-09-04 03:37:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 03:37:20 --> Database Driver Class Initialized
DEBUG - 2020-09-04 03:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 03:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 03:37:20 --> Upload Class Initialized
INFO - 2020-09-04 03:37:20 --> Controller Class Initialized
DEBUG - 2020-09-04 03:37:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 03:37:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 03:37:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 03:37:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 03:37:20 --> Final output sent to browser
DEBUG - 2020-09-04 03:37:20 --> Total execution time: 0.0499
INFO - 2020-09-04 04:44:47 --> Config Class Initialized
INFO - 2020-09-04 04:44:47 --> Hooks Class Initialized
DEBUG - 2020-09-04 04:44:47 --> UTF-8 Support Enabled
INFO - 2020-09-04 04:44:47 --> Utf8 Class Initialized
INFO - 2020-09-04 04:44:47 --> URI Class Initialized
DEBUG - 2020-09-04 04:44:47 --> No URI present. Default controller set.
INFO - 2020-09-04 04:44:47 --> Router Class Initialized
INFO - 2020-09-04 04:44:47 --> Output Class Initialized
INFO - 2020-09-04 04:44:47 --> Security Class Initialized
DEBUG - 2020-09-04 04:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 04:44:47 --> Input Class Initialized
INFO - 2020-09-04 04:44:47 --> Language Class Initialized
INFO - 2020-09-04 04:44:47 --> Language Class Initialized
INFO - 2020-09-04 04:44:47 --> Config Class Initialized
INFO - 2020-09-04 04:44:47 --> Loader Class Initialized
INFO - 2020-09-04 04:44:47 --> Helper loaded: url_helper
INFO - 2020-09-04 04:44:47 --> Helper loaded: form_helper
INFO - 2020-09-04 04:44:47 --> Helper loaded: file_helper
INFO - 2020-09-04 04:44:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 04:44:47 --> Database Driver Class Initialized
DEBUG - 2020-09-04 04:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 04:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 04:44:47 --> Upload Class Initialized
INFO - 2020-09-04 04:44:47 --> Controller Class Initialized
DEBUG - 2020-09-04 04:44:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 04:44:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 04:44:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 04:44:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 04:44:47 --> Final output sent to browser
DEBUG - 2020-09-04 04:44:47 --> Total execution time: 0.0499
INFO - 2020-09-04 06:43:31 --> Config Class Initialized
INFO - 2020-09-04 06:43:31 --> Hooks Class Initialized
DEBUG - 2020-09-04 06:43:31 --> UTF-8 Support Enabled
INFO - 2020-09-04 06:43:31 --> Utf8 Class Initialized
INFO - 2020-09-04 06:43:31 --> URI Class Initialized
DEBUG - 2020-09-04 06:43:31 --> No URI present. Default controller set.
INFO - 2020-09-04 06:43:31 --> Router Class Initialized
INFO - 2020-09-04 06:43:31 --> Output Class Initialized
INFO - 2020-09-04 06:43:31 --> Security Class Initialized
DEBUG - 2020-09-04 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 06:43:31 --> Input Class Initialized
INFO - 2020-09-04 06:43:31 --> Language Class Initialized
INFO - 2020-09-04 06:43:31 --> Language Class Initialized
INFO - 2020-09-04 06:43:31 --> Config Class Initialized
INFO - 2020-09-04 06:43:31 --> Loader Class Initialized
INFO - 2020-09-04 06:43:31 --> Helper loaded: url_helper
INFO - 2020-09-04 06:43:31 --> Helper loaded: form_helper
INFO - 2020-09-04 06:43:31 --> Helper loaded: file_helper
INFO - 2020-09-04 06:43:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 06:43:31 --> Database Driver Class Initialized
DEBUG - 2020-09-04 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 06:43:31 --> Upload Class Initialized
INFO - 2020-09-04 06:43:31 --> Controller Class Initialized
DEBUG - 2020-09-04 06:43:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 06:43:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 06:43:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 06:43:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 06:43:31 --> Final output sent to browser
DEBUG - 2020-09-04 06:43:31 --> Total execution time: 0.0542
INFO - 2020-09-04 07:29:31 --> Config Class Initialized
INFO - 2020-09-04 07:29:31 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:29:31 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:29:31 --> Utf8 Class Initialized
INFO - 2020-09-04 07:29:31 --> URI Class Initialized
DEBUG - 2020-09-04 07:29:31 --> No URI present. Default controller set.
INFO - 2020-09-04 07:29:31 --> Router Class Initialized
INFO - 2020-09-04 07:29:31 --> Output Class Initialized
INFO - 2020-09-04 07:29:31 --> Security Class Initialized
DEBUG - 2020-09-04 07:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:29:31 --> Input Class Initialized
INFO - 2020-09-04 07:29:31 --> Language Class Initialized
INFO - 2020-09-04 07:29:31 --> Language Class Initialized
INFO - 2020-09-04 07:29:31 --> Config Class Initialized
INFO - 2020-09-04 07:29:31 --> Loader Class Initialized
INFO - 2020-09-04 07:29:31 --> Helper loaded: url_helper
INFO - 2020-09-04 07:29:31 --> Helper loaded: form_helper
INFO - 2020-09-04 07:29:31 --> Helper loaded: file_helper
INFO - 2020-09-04 07:29:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 07:29:31 --> Database Driver Class Initialized
DEBUG - 2020-09-04 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 07:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:29:31 --> Upload Class Initialized
INFO - 2020-09-04 07:29:31 --> Controller Class Initialized
DEBUG - 2020-09-04 07:29:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 07:29:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 07:29:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 07:29:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 07:29:31 --> Final output sent to browser
DEBUG - 2020-09-04 07:29:31 --> Total execution time: 0.0506
INFO - 2020-09-04 07:41:34 --> Config Class Initialized
INFO - 2020-09-04 07:41:34 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:41:34 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:41:34 --> Utf8 Class Initialized
INFO - 2020-09-04 07:41:34 --> URI Class Initialized
DEBUG - 2020-09-04 07:41:34 --> No URI present. Default controller set.
INFO - 2020-09-04 07:41:34 --> Router Class Initialized
INFO - 2020-09-04 07:41:34 --> Output Class Initialized
INFO - 2020-09-04 07:41:34 --> Security Class Initialized
DEBUG - 2020-09-04 07:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:41:34 --> Input Class Initialized
INFO - 2020-09-04 07:41:34 --> Language Class Initialized
INFO - 2020-09-04 07:41:34 --> Language Class Initialized
INFO - 2020-09-04 07:41:34 --> Config Class Initialized
INFO - 2020-09-04 07:41:34 --> Loader Class Initialized
INFO - 2020-09-04 07:41:34 --> Helper loaded: url_helper
INFO - 2020-09-04 07:41:34 --> Helper loaded: form_helper
INFO - 2020-09-04 07:41:34 --> Helper loaded: file_helper
INFO - 2020-09-04 07:41:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 07:41:34 --> Database Driver Class Initialized
DEBUG - 2020-09-04 07:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 07:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:41:34 --> Upload Class Initialized
INFO - 2020-09-04 07:41:34 --> Controller Class Initialized
DEBUG - 2020-09-04 07:41:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 07:41:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 07:41:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 07:41:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 07:41:34 --> Final output sent to browser
DEBUG - 2020-09-04 07:41:34 --> Total execution time: 0.0542
INFO - 2020-09-04 08:20:24 --> Config Class Initialized
INFO - 2020-09-04 08:20:24 --> Hooks Class Initialized
DEBUG - 2020-09-04 08:20:24 --> UTF-8 Support Enabled
INFO - 2020-09-04 08:20:24 --> Utf8 Class Initialized
INFO - 2020-09-04 08:20:24 --> URI Class Initialized
INFO - 2020-09-04 08:20:24 --> Router Class Initialized
INFO - 2020-09-04 08:20:24 --> Output Class Initialized
INFO - 2020-09-04 08:20:24 --> Security Class Initialized
DEBUG - 2020-09-04 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 08:20:24 --> Input Class Initialized
INFO - 2020-09-04 08:20:24 --> Language Class Initialized
INFO - 2020-09-04 08:20:24 --> Language Class Initialized
INFO - 2020-09-04 08:20:24 --> Config Class Initialized
INFO - 2020-09-04 08:20:24 --> Loader Class Initialized
INFO - 2020-09-04 08:20:24 --> Helper loaded: url_helper
INFO - 2020-09-04 08:20:24 --> Helper loaded: form_helper
INFO - 2020-09-04 08:20:24 --> Helper loaded: file_helper
INFO - 2020-09-04 08:20:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 08:20:24 --> Database Driver Class Initialized
DEBUG - 2020-09-04 08:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 08:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 08:20:24 --> Upload Class Initialized
INFO - 2020-09-04 08:20:24 --> Controller Class Initialized
ERROR - 2020-09-04 08:20:24 --> 404 Page Not Found: /index
INFO - 2020-09-04 08:20:24 --> Config Class Initialized
INFO - 2020-09-04 08:20:24 --> Hooks Class Initialized
DEBUG - 2020-09-04 08:20:24 --> UTF-8 Support Enabled
INFO - 2020-09-04 08:20:24 --> Utf8 Class Initialized
INFO - 2020-09-04 08:20:24 --> URI Class Initialized
INFO - 2020-09-04 08:20:24 --> Router Class Initialized
INFO - 2020-09-04 08:20:24 --> Output Class Initialized
INFO - 2020-09-04 08:20:24 --> Security Class Initialized
DEBUG - 2020-09-04 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 08:20:24 --> Input Class Initialized
INFO - 2020-09-04 08:20:24 --> Language Class Initialized
INFO - 2020-09-04 08:20:24 --> Language Class Initialized
INFO - 2020-09-04 08:20:24 --> Config Class Initialized
INFO - 2020-09-04 08:20:24 --> Loader Class Initialized
INFO - 2020-09-04 08:20:24 --> Helper loaded: url_helper
INFO - 2020-09-04 08:20:24 --> Helper loaded: form_helper
INFO - 2020-09-04 08:20:24 --> Helper loaded: file_helper
INFO - 2020-09-04 08:20:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 08:20:24 --> Database Driver Class Initialized
DEBUG - 2020-09-04 08:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 08:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 08:20:24 --> Upload Class Initialized
INFO - 2020-09-04 08:20:24 --> Controller Class Initialized
DEBUG - 2020-09-04 08:20:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 08:20:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 08:20:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 08:20:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 08:20:24 --> Final output sent to browser
DEBUG - 2020-09-04 08:20:24 --> Total execution time: 0.0508
INFO - 2020-09-04 09:17:18 --> Config Class Initialized
INFO - 2020-09-04 09:17:18 --> Hooks Class Initialized
DEBUG - 2020-09-04 09:17:18 --> UTF-8 Support Enabled
INFO - 2020-09-04 09:17:18 --> Utf8 Class Initialized
INFO - 2020-09-04 09:17:18 --> URI Class Initialized
DEBUG - 2020-09-04 09:17:18 --> No URI present. Default controller set.
INFO - 2020-09-04 09:17:18 --> Router Class Initialized
INFO - 2020-09-04 09:17:18 --> Output Class Initialized
INFO - 2020-09-04 09:17:18 --> Security Class Initialized
DEBUG - 2020-09-04 09:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 09:17:18 --> Input Class Initialized
INFO - 2020-09-04 09:17:18 --> Language Class Initialized
INFO - 2020-09-04 09:17:18 --> Language Class Initialized
INFO - 2020-09-04 09:17:18 --> Config Class Initialized
INFO - 2020-09-04 09:17:18 --> Loader Class Initialized
INFO - 2020-09-04 09:17:18 --> Helper loaded: url_helper
INFO - 2020-09-04 09:17:18 --> Helper loaded: form_helper
INFO - 2020-09-04 09:17:18 --> Helper loaded: file_helper
INFO - 2020-09-04 09:17:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 09:17:18 --> Database Driver Class Initialized
DEBUG - 2020-09-04 09:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 09:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 09:17:18 --> Upload Class Initialized
INFO - 2020-09-04 09:17:18 --> Controller Class Initialized
DEBUG - 2020-09-04 09:17:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 09:17:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 09:17:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 09:17:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 09:17:18 --> Final output sent to browser
DEBUG - 2020-09-04 09:17:18 --> Total execution time: 0.1535
INFO - 2020-09-04 09:34:24 --> Config Class Initialized
INFO - 2020-09-04 09:34:24 --> Hooks Class Initialized
DEBUG - 2020-09-04 09:34:24 --> UTF-8 Support Enabled
INFO - 2020-09-04 09:34:24 --> Utf8 Class Initialized
INFO - 2020-09-04 09:34:24 --> URI Class Initialized
INFO - 2020-09-04 09:34:24 --> Router Class Initialized
INFO - 2020-09-04 09:34:24 --> Output Class Initialized
INFO - 2020-09-04 09:34:24 --> Security Class Initialized
DEBUG - 2020-09-04 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 09:34:24 --> Input Class Initialized
INFO - 2020-09-04 09:34:24 --> Language Class Initialized
INFO - 2020-09-04 09:34:24 --> Language Class Initialized
INFO - 2020-09-04 09:34:24 --> Config Class Initialized
INFO - 2020-09-04 09:34:24 --> Loader Class Initialized
INFO - 2020-09-04 09:34:24 --> Helper loaded: url_helper
INFO - 2020-09-04 09:34:24 --> Helper loaded: form_helper
INFO - 2020-09-04 09:34:24 --> Helper loaded: file_helper
INFO - 2020-09-04 09:34:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 09:34:24 --> Database Driver Class Initialized
DEBUG - 2020-09-04 09:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 09:34:24 --> Upload Class Initialized
INFO - 2020-09-04 09:34:24 --> Controller Class Initialized
DEBUG - 2020-09-04 09:34:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 09:34:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-04 09:34:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 09:34:24 --> Final output sent to browser
DEBUG - 2020-09-04 09:34:24 --> Total execution time: 0.0545
INFO - 2020-09-04 10:07:09 --> Config Class Initialized
INFO - 2020-09-04 10:07:09 --> Hooks Class Initialized
DEBUG - 2020-09-04 10:07:09 --> UTF-8 Support Enabled
INFO - 2020-09-04 10:07:09 --> Utf8 Class Initialized
INFO - 2020-09-04 10:07:09 --> URI Class Initialized
DEBUG - 2020-09-04 10:07:09 --> No URI present. Default controller set.
INFO - 2020-09-04 10:07:09 --> Router Class Initialized
INFO - 2020-09-04 10:07:09 --> Output Class Initialized
INFO - 2020-09-04 10:07:09 --> Security Class Initialized
DEBUG - 2020-09-04 10:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 10:07:09 --> Input Class Initialized
INFO - 2020-09-04 10:07:09 --> Language Class Initialized
INFO - 2020-09-04 10:07:09 --> Language Class Initialized
INFO - 2020-09-04 10:07:09 --> Config Class Initialized
INFO - 2020-09-04 10:07:09 --> Loader Class Initialized
INFO - 2020-09-04 10:07:09 --> Helper loaded: url_helper
INFO - 2020-09-04 10:07:09 --> Helper loaded: form_helper
INFO - 2020-09-04 10:07:09 --> Helper loaded: file_helper
INFO - 2020-09-04 10:07:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 10:07:09 --> Database Driver Class Initialized
DEBUG - 2020-09-04 10:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 10:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 10:07:09 --> Upload Class Initialized
INFO - 2020-09-04 10:07:09 --> Controller Class Initialized
DEBUG - 2020-09-04 10:07:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 10:07:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 10:07:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 10:07:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 10:07:09 --> Final output sent to browser
DEBUG - 2020-09-04 10:07:09 --> Total execution time: 0.0770
INFO - 2020-09-04 10:23:09 --> Config Class Initialized
INFO - 2020-09-04 10:23:09 --> Hooks Class Initialized
DEBUG - 2020-09-04 10:23:09 --> UTF-8 Support Enabled
INFO - 2020-09-04 10:23:09 --> Utf8 Class Initialized
INFO - 2020-09-04 10:23:09 --> URI Class Initialized
DEBUG - 2020-09-04 10:23:09 --> No URI present. Default controller set.
INFO - 2020-09-04 10:23:09 --> Router Class Initialized
INFO - 2020-09-04 10:23:09 --> Output Class Initialized
INFO - 2020-09-04 10:23:09 --> Security Class Initialized
DEBUG - 2020-09-04 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 10:23:09 --> Input Class Initialized
INFO - 2020-09-04 10:23:09 --> Language Class Initialized
INFO - 2020-09-04 10:23:09 --> Language Class Initialized
INFO - 2020-09-04 10:23:09 --> Config Class Initialized
INFO - 2020-09-04 10:23:09 --> Loader Class Initialized
INFO - 2020-09-04 10:23:09 --> Helper loaded: url_helper
INFO - 2020-09-04 10:23:09 --> Helper loaded: form_helper
INFO - 2020-09-04 10:23:09 --> Helper loaded: file_helper
INFO - 2020-09-04 10:23:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 10:23:09 --> Database Driver Class Initialized
DEBUG - 2020-09-04 10:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 10:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 10:23:09 --> Upload Class Initialized
INFO - 2020-09-04 10:23:09 --> Controller Class Initialized
DEBUG - 2020-09-04 10:23:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 10:23:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 10:23:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 10:23:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 10:23:09 --> Final output sent to browser
DEBUG - 2020-09-04 10:23:09 --> Total execution time: 0.0525
INFO - 2020-09-04 10:29:08 --> Config Class Initialized
INFO - 2020-09-04 10:29:08 --> Hooks Class Initialized
DEBUG - 2020-09-04 10:29:08 --> UTF-8 Support Enabled
INFO - 2020-09-04 10:29:08 --> Utf8 Class Initialized
INFO - 2020-09-04 10:29:08 --> URI Class Initialized
INFO - 2020-09-04 10:29:08 --> Router Class Initialized
INFO - 2020-09-04 10:29:08 --> Output Class Initialized
INFO - 2020-09-04 10:29:08 --> Security Class Initialized
DEBUG - 2020-09-04 10:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 10:29:08 --> Input Class Initialized
INFO - 2020-09-04 10:29:08 --> Language Class Initialized
INFO - 2020-09-04 10:29:08 --> Language Class Initialized
INFO - 2020-09-04 10:29:08 --> Config Class Initialized
INFO - 2020-09-04 10:29:08 --> Loader Class Initialized
INFO - 2020-09-04 10:29:08 --> Helper loaded: url_helper
INFO - 2020-09-04 10:29:08 --> Helper loaded: form_helper
INFO - 2020-09-04 10:29:08 --> Helper loaded: file_helper
INFO - 2020-09-04 10:29:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 10:29:08 --> Database Driver Class Initialized
DEBUG - 2020-09-04 10:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 10:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 10:29:08 --> Upload Class Initialized
INFO - 2020-09-04 10:29:08 --> Controller Class Initialized
DEBUG - 2020-09-04 10:29:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 10:29:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 10:29:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 10:29:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 10:29:08 --> Final output sent to browser
DEBUG - 2020-09-04 10:29:08 --> Total execution time: 0.0585
INFO - 2020-09-04 10:29:10 --> Config Class Initialized
INFO - 2020-09-04 10:29:10 --> Hooks Class Initialized
DEBUG - 2020-09-04 10:29:10 --> UTF-8 Support Enabled
INFO - 2020-09-04 10:29:10 --> Utf8 Class Initialized
INFO - 2020-09-04 10:29:10 --> URI Class Initialized
INFO - 2020-09-04 10:29:10 --> Router Class Initialized
INFO - 2020-09-04 10:29:10 --> Output Class Initialized
INFO - 2020-09-04 10:29:10 --> Security Class Initialized
DEBUG - 2020-09-04 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 10:29:10 --> Input Class Initialized
INFO - 2020-09-04 10:29:10 --> Language Class Initialized
INFO - 2020-09-04 10:29:10 --> Language Class Initialized
INFO - 2020-09-04 10:29:10 --> Config Class Initialized
INFO - 2020-09-04 10:29:10 --> Loader Class Initialized
INFO - 2020-09-04 10:29:10 --> Helper loaded: url_helper
INFO - 2020-09-04 10:29:10 --> Helper loaded: form_helper
INFO - 2020-09-04 10:29:10 --> Helper loaded: file_helper
INFO - 2020-09-04 10:29:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 10:29:10 --> Database Driver Class Initialized
DEBUG - 2020-09-04 10:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 10:29:10 --> Upload Class Initialized
INFO - 2020-09-04 10:29:10 --> Controller Class Initialized
ERROR - 2020-09-04 10:29:10 --> 404 Page Not Found: /index
INFO - 2020-09-04 11:21:43 --> Config Class Initialized
INFO - 2020-09-04 11:21:43 --> Hooks Class Initialized
DEBUG - 2020-09-04 11:21:43 --> UTF-8 Support Enabled
INFO - 2020-09-04 11:21:43 --> Utf8 Class Initialized
INFO - 2020-09-04 11:21:43 --> URI Class Initialized
DEBUG - 2020-09-04 11:21:43 --> No URI present. Default controller set.
INFO - 2020-09-04 11:21:43 --> Router Class Initialized
INFO - 2020-09-04 11:21:43 --> Output Class Initialized
INFO - 2020-09-04 11:21:43 --> Security Class Initialized
DEBUG - 2020-09-04 11:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 11:21:43 --> Input Class Initialized
INFO - 2020-09-04 11:21:43 --> Language Class Initialized
INFO - 2020-09-04 11:21:43 --> Language Class Initialized
INFO - 2020-09-04 11:21:43 --> Config Class Initialized
INFO - 2020-09-04 11:21:43 --> Loader Class Initialized
INFO - 2020-09-04 11:21:43 --> Helper loaded: url_helper
INFO - 2020-09-04 11:21:43 --> Helper loaded: form_helper
INFO - 2020-09-04 11:21:43 --> Helper loaded: file_helper
INFO - 2020-09-04 11:21:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 11:21:43 --> Database Driver Class Initialized
DEBUG - 2020-09-04 11:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 11:21:43 --> Upload Class Initialized
INFO - 2020-09-04 11:21:43 --> Controller Class Initialized
DEBUG - 2020-09-04 11:21:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 11:21:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 11:21:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 11:21:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 11:21:43 --> Final output sent to browser
DEBUG - 2020-09-04 11:21:43 --> Total execution time: 0.0862
INFO - 2020-09-04 11:30:59 --> Config Class Initialized
INFO - 2020-09-04 11:30:59 --> Hooks Class Initialized
DEBUG - 2020-09-04 11:30:59 --> UTF-8 Support Enabled
INFO - 2020-09-04 11:30:59 --> Utf8 Class Initialized
INFO - 2020-09-04 11:30:59 --> URI Class Initialized
INFO - 2020-09-04 11:30:59 --> Router Class Initialized
INFO - 2020-09-04 11:30:59 --> Output Class Initialized
INFO - 2020-09-04 11:30:59 --> Security Class Initialized
DEBUG - 2020-09-04 11:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 11:30:59 --> Input Class Initialized
INFO - 2020-09-04 11:30:59 --> Language Class Initialized
INFO - 2020-09-04 11:30:59 --> Language Class Initialized
INFO - 2020-09-04 11:30:59 --> Config Class Initialized
INFO - 2020-09-04 11:30:59 --> Loader Class Initialized
INFO - 2020-09-04 11:30:59 --> Helper loaded: url_helper
INFO - 2020-09-04 11:30:59 --> Helper loaded: form_helper
INFO - 2020-09-04 11:30:59 --> Helper loaded: file_helper
INFO - 2020-09-04 11:30:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 11:30:59 --> Database Driver Class Initialized
DEBUG - 2020-09-04 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 11:30:59 --> Upload Class Initialized
INFO - 2020-09-04 11:30:59 --> Controller Class Initialized
DEBUG - 2020-09-04 11:30:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 11:30:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 11:30:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 11:30:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 11:30:59 --> Final output sent to browser
DEBUG - 2020-09-04 11:30:59 --> Total execution time: 0.0611
INFO - 2020-09-04 11:31:03 --> Config Class Initialized
INFO - 2020-09-04 11:31:03 --> Hooks Class Initialized
DEBUG - 2020-09-04 11:31:03 --> UTF-8 Support Enabled
INFO - 2020-09-04 11:31:03 --> Utf8 Class Initialized
INFO - 2020-09-04 11:31:03 --> URI Class Initialized
INFO - 2020-09-04 11:31:03 --> Router Class Initialized
INFO - 2020-09-04 11:31:03 --> Output Class Initialized
INFO - 2020-09-04 11:31:03 --> Security Class Initialized
DEBUG - 2020-09-04 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 11:31:03 --> Input Class Initialized
INFO - 2020-09-04 11:31:03 --> Language Class Initialized
INFO - 2020-09-04 11:31:03 --> Language Class Initialized
INFO - 2020-09-04 11:31:03 --> Config Class Initialized
INFO - 2020-09-04 11:31:03 --> Loader Class Initialized
INFO - 2020-09-04 11:31:03 --> Helper loaded: url_helper
INFO - 2020-09-04 11:31:03 --> Helper loaded: form_helper
INFO - 2020-09-04 11:31:03 --> Helper loaded: file_helper
INFO - 2020-09-04 11:31:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 11:31:03 --> Database Driver Class Initialized
DEBUG - 2020-09-04 11:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 11:31:03 --> Upload Class Initialized
INFO - 2020-09-04 11:31:03 --> Controller Class Initialized
ERROR - 2020-09-04 11:31:03 --> 404 Page Not Found: /index
INFO - 2020-09-04 11:51:22 --> Config Class Initialized
INFO - 2020-09-04 11:51:22 --> Hooks Class Initialized
DEBUG - 2020-09-04 11:51:22 --> UTF-8 Support Enabled
INFO - 2020-09-04 11:51:22 --> Utf8 Class Initialized
INFO - 2020-09-04 11:51:22 --> URI Class Initialized
DEBUG - 2020-09-04 11:51:22 --> No URI present. Default controller set.
INFO - 2020-09-04 11:51:22 --> Router Class Initialized
INFO - 2020-09-04 11:51:22 --> Output Class Initialized
INFO - 2020-09-04 11:51:22 --> Security Class Initialized
DEBUG - 2020-09-04 11:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 11:51:22 --> Input Class Initialized
INFO - 2020-09-04 11:51:22 --> Language Class Initialized
INFO - 2020-09-04 11:51:22 --> Language Class Initialized
INFO - 2020-09-04 11:51:22 --> Config Class Initialized
INFO - 2020-09-04 11:51:22 --> Loader Class Initialized
INFO - 2020-09-04 11:51:22 --> Helper loaded: url_helper
INFO - 2020-09-04 11:51:22 --> Helper loaded: form_helper
INFO - 2020-09-04 11:51:22 --> Helper loaded: file_helper
INFO - 2020-09-04 11:51:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 11:51:22 --> Database Driver Class Initialized
DEBUG - 2020-09-04 11:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 11:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 11:51:22 --> Upload Class Initialized
INFO - 2020-09-04 11:51:22 --> Controller Class Initialized
DEBUG - 2020-09-04 11:51:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 11:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 11:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 11:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 11:51:22 --> Final output sent to browser
DEBUG - 2020-09-04 11:51:22 --> Total execution time: 0.0509
INFO - 2020-09-04 11:51:29 --> Config Class Initialized
INFO - 2020-09-04 11:51:29 --> Hooks Class Initialized
DEBUG - 2020-09-04 11:51:29 --> UTF-8 Support Enabled
INFO - 2020-09-04 11:51:29 --> Utf8 Class Initialized
INFO - 2020-09-04 11:51:29 --> URI Class Initialized
INFO - 2020-09-04 11:51:29 --> Router Class Initialized
INFO - 2020-09-04 11:51:29 --> Output Class Initialized
INFO - 2020-09-04 11:51:29 --> Security Class Initialized
DEBUG - 2020-09-04 11:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 11:51:29 --> Input Class Initialized
INFO - 2020-09-04 11:51:29 --> Language Class Initialized
INFO - 2020-09-04 11:51:29 --> Language Class Initialized
INFO - 2020-09-04 11:51:29 --> Config Class Initialized
INFO - 2020-09-04 11:51:29 --> Loader Class Initialized
INFO - 2020-09-04 11:51:29 --> Helper loaded: url_helper
INFO - 2020-09-04 11:51:29 --> Helper loaded: form_helper
INFO - 2020-09-04 11:51:29 --> Helper loaded: file_helper
INFO - 2020-09-04 11:51:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 11:51:29 --> Database Driver Class Initialized
DEBUG - 2020-09-04 11:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 11:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 11:51:29 --> Upload Class Initialized
INFO - 2020-09-04 11:51:29 --> Controller Class Initialized
DEBUG - 2020-09-04 11:51:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 11:51:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-04 11:51:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 11:51:29 --> Final output sent to browser
DEBUG - 2020-09-04 11:51:29 --> Total execution time: 0.0520
INFO - 2020-09-04 11:51:30 --> Config Class Initialized
INFO - 2020-09-04 11:51:30 --> Hooks Class Initialized
DEBUG - 2020-09-04 11:51:30 --> UTF-8 Support Enabled
INFO - 2020-09-04 11:51:30 --> Utf8 Class Initialized
INFO - 2020-09-04 11:51:30 --> URI Class Initialized
INFO - 2020-09-04 11:51:30 --> Router Class Initialized
INFO - 2020-09-04 11:51:30 --> Output Class Initialized
INFO - 2020-09-04 11:51:30 --> Security Class Initialized
DEBUG - 2020-09-04 11:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 11:51:30 --> Input Class Initialized
INFO - 2020-09-04 11:51:30 --> Language Class Initialized
INFO - 2020-09-04 11:51:30 --> Language Class Initialized
INFO - 2020-09-04 11:51:30 --> Config Class Initialized
INFO - 2020-09-04 11:51:30 --> Loader Class Initialized
INFO - 2020-09-04 11:51:30 --> Helper loaded: url_helper
INFO - 2020-09-04 11:51:30 --> Helper loaded: form_helper
INFO - 2020-09-04 11:51:30 --> Helper loaded: file_helper
INFO - 2020-09-04 11:51:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 11:51:30 --> Database Driver Class Initialized
DEBUG - 2020-09-04 11:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 11:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 11:51:30 --> Upload Class Initialized
INFO - 2020-09-04 11:51:30 --> Controller Class Initialized
ERROR - 2020-09-04 11:51:30 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:07:08 --> Config Class Initialized
INFO - 2020-09-04 12:07:08 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:07:08 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:07:08 --> Utf8 Class Initialized
INFO - 2020-09-04 12:07:08 --> URI Class Initialized
DEBUG - 2020-09-04 12:07:08 --> No URI present. Default controller set.
INFO - 2020-09-04 12:07:08 --> Router Class Initialized
INFO - 2020-09-04 12:07:08 --> Output Class Initialized
INFO - 2020-09-04 12:07:08 --> Security Class Initialized
DEBUG - 2020-09-04 12:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:07:08 --> Input Class Initialized
INFO - 2020-09-04 12:07:08 --> Language Class Initialized
INFO - 2020-09-04 12:07:08 --> Language Class Initialized
INFO - 2020-09-04 12:07:08 --> Config Class Initialized
INFO - 2020-09-04 12:07:08 --> Loader Class Initialized
INFO - 2020-09-04 12:07:08 --> Helper loaded: url_helper
INFO - 2020-09-04 12:07:08 --> Helper loaded: form_helper
INFO - 2020-09-04 12:07:08 --> Helper loaded: file_helper
INFO - 2020-09-04 12:07:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:07:08 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:07:08 --> Upload Class Initialized
INFO - 2020-09-04 12:07:08 --> Controller Class Initialized
DEBUG - 2020-09-04 12:07:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:07:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:07:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:07:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:07:08 --> Final output sent to browser
DEBUG - 2020-09-04 12:07:08 --> Total execution time: 0.0542
INFO - 2020-09-04 12:07:14 --> Config Class Initialized
INFO - 2020-09-04 12:07:14 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:07:14 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:07:14 --> Utf8 Class Initialized
INFO - 2020-09-04 12:07:14 --> URI Class Initialized
INFO - 2020-09-04 12:07:14 --> Router Class Initialized
INFO - 2020-09-04 12:07:14 --> Output Class Initialized
INFO - 2020-09-04 12:07:14 --> Security Class Initialized
DEBUG - 2020-09-04 12:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:07:14 --> Input Class Initialized
INFO - 2020-09-04 12:07:14 --> Language Class Initialized
INFO - 2020-09-04 12:07:14 --> Language Class Initialized
INFO - 2020-09-04 12:07:14 --> Config Class Initialized
INFO - 2020-09-04 12:07:14 --> Loader Class Initialized
INFO - 2020-09-04 12:07:14 --> Helper loaded: url_helper
INFO - 2020-09-04 12:07:14 --> Helper loaded: form_helper
INFO - 2020-09-04 12:07:14 --> Helper loaded: file_helper
INFO - 2020-09-04 12:07:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:07:14 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:07:14 --> Upload Class Initialized
INFO - 2020-09-04 12:07:14 --> Controller Class Initialized
ERROR - 2020-09-04 12:07:14 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:07:33 --> Config Class Initialized
INFO - 2020-09-04 12:07:33 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:07:33 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:07:33 --> Utf8 Class Initialized
INFO - 2020-09-04 12:07:33 --> URI Class Initialized
DEBUG - 2020-09-04 12:07:33 --> No URI present. Default controller set.
INFO - 2020-09-04 12:07:33 --> Router Class Initialized
INFO - 2020-09-04 12:07:33 --> Output Class Initialized
INFO - 2020-09-04 12:07:33 --> Security Class Initialized
DEBUG - 2020-09-04 12:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:07:33 --> Input Class Initialized
INFO - 2020-09-04 12:07:33 --> Language Class Initialized
INFO - 2020-09-04 12:07:33 --> Language Class Initialized
INFO - 2020-09-04 12:07:33 --> Config Class Initialized
INFO - 2020-09-04 12:07:33 --> Loader Class Initialized
INFO - 2020-09-04 12:07:33 --> Helper loaded: url_helper
INFO - 2020-09-04 12:07:33 --> Helper loaded: form_helper
INFO - 2020-09-04 12:07:33 --> Helper loaded: file_helper
INFO - 2020-09-04 12:07:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:07:33 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:07:33 --> Upload Class Initialized
INFO - 2020-09-04 12:07:33 --> Controller Class Initialized
DEBUG - 2020-09-04 12:07:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:07:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:07:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:07:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:07:33 --> Final output sent to browser
DEBUG - 2020-09-04 12:07:33 --> Total execution time: 0.0489
INFO - 2020-09-04 12:08:01 --> Config Class Initialized
INFO - 2020-09-04 12:08:01 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:08:01 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:08:01 --> Utf8 Class Initialized
INFO - 2020-09-04 12:08:01 --> URI Class Initialized
DEBUG - 2020-09-04 12:08:01 --> No URI present. Default controller set.
INFO - 2020-09-04 12:08:01 --> Router Class Initialized
INFO - 2020-09-04 12:08:01 --> Output Class Initialized
INFO - 2020-09-04 12:08:01 --> Security Class Initialized
DEBUG - 2020-09-04 12:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:08:01 --> Input Class Initialized
INFO - 2020-09-04 12:08:01 --> Language Class Initialized
INFO - 2020-09-04 12:08:01 --> Language Class Initialized
INFO - 2020-09-04 12:08:01 --> Config Class Initialized
INFO - 2020-09-04 12:08:01 --> Loader Class Initialized
INFO - 2020-09-04 12:08:01 --> Helper loaded: url_helper
INFO - 2020-09-04 12:08:01 --> Helper loaded: form_helper
INFO - 2020-09-04 12:08:01 --> Helper loaded: file_helper
INFO - 2020-09-04 12:08:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:08:01 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:08:01 --> Upload Class Initialized
INFO - 2020-09-04 12:08:01 --> Controller Class Initialized
DEBUG - 2020-09-04 12:08:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:08:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:08:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:08:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:08:01 --> Final output sent to browser
DEBUG - 2020-09-04 12:08:01 --> Total execution time: 0.0513
INFO - 2020-09-04 12:08:28 --> Config Class Initialized
INFO - 2020-09-04 12:08:28 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:08:28 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:08:28 --> Utf8 Class Initialized
INFO - 2020-09-04 12:08:28 --> URI Class Initialized
DEBUG - 2020-09-04 12:08:28 --> No URI present. Default controller set.
INFO - 2020-09-04 12:08:28 --> Router Class Initialized
INFO - 2020-09-04 12:08:28 --> Output Class Initialized
INFO - 2020-09-04 12:08:28 --> Security Class Initialized
DEBUG - 2020-09-04 12:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:08:28 --> Input Class Initialized
INFO - 2020-09-04 12:08:28 --> Language Class Initialized
INFO - 2020-09-04 12:08:28 --> Language Class Initialized
INFO - 2020-09-04 12:08:28 --> Config Class Initialized
INFO - 2020-09-04 12:08:28 --> Loader Class Initialized
INFO - 2020-09-04 12:08:28 --> Helper loaded: url_helper
INFO - 2020-09-04 12:08:28 --> Helper loaded: form_helper
INFO - 2020-09-04 12:08:28 --> Helper loaded: file_helper
INFO - 2020-09-04 12:08:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:08:28 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:08:28 --> Upload Class Initialized
INFO - 2020-09-04 12:08:28 --> Controller Class Initialized
DEBUG - 2020-09-04 12:08:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:08:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:08:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:08:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:08:28 --> Final output sent to browser
DEBUG - 2020-09-04 12:08:28 --> Total execution time: 0.0501
INFO - 2020-09-04 12:08:31 --> Config Class Initialized
INFO - 2020-09-04 12:08:31 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:08:31 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:08:31 --> Utf8 Class Initialized
INFO - 2020-09-04 12:08:31 --> URI Class Initialized
INFO - 2020-09-04 12:08:31 --> Router Class Initialized
INFO - 2020-09-04 12:08:31 --> Output Class Initialized
INFO - 2020-09-04 12:08:31 --> Security Class Initialized
DEBUG - 2020-09-04 12:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:08:31 --> Input Class Initialized
INFO - 2020-09-04 12:08:31 --> Language Class Initialized
INFO - 2020-09-04 12:08:31 --> Language Class Initialized
INFO - 2020-09-04 12:08:31 --> Config Class Initialized
INFO - 2020-09-04 12:08:31 --> Loader Class Initialized
INFO - 2020-09-04 12:08:31 --> Helper loaded: url_helper
INFO - 2020-09-04 12:08:31 --> Helper loaded: form_helper
INFO - 2020-09-04 12:08:31 --> Helper loaded: file_helper
INFO - 2020-09-04 12:08:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:08:31 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:08:31 --> Upload Class Initialized
INFO - 2020-09-04 12:08:31 --> Controller Class Initialized
ERROR - 2020-09-04 12:08:31 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:08:34 --> Config Class Initialized
INFO - 2020-09-04 12:08:34 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:08:34 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:08:34 --> Utf8 Class Initialized
INFO - 2020-09-04 12:08:34 --> URI Class Initialized
INFO - 2020-09-04 12:08:34 --> Router Class Initialized
INFO - 2020-09-04 12:08:34 --> Output Class Initialized
INFO - 2020-09-04 12:08:34 --> Security Class Initialized
DEBUG - 2020-09-04 12:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:08:34 --> Input Class Initialized
INFO - 2020-09-04 12:08:34 --> Language Class Initialized
INFO - 2020-09-04 12:08:34 --> Language Class Initialized
INFO - 2020-09-04 12:08:34 --> Config Class Initialized
INFO - 2020-09-04 12:08:34 --> Loader Class Initialized
INFO - 2020-09-04 12:08:34 --> Helper loaded: url_helper
INFO - 2020-09-04 12:08:34 --> Helper loaded: form_helper
INFO - 2020-09-04 12:08:34 --> Helper loaded: file_helper
INFO - 2020-09-04 12:08:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:08:34 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:08:34 --> Upload Class Initialized
INFO - 2020-09-04 12:08:34 --> Controller Class Initialized
ERROR - 2020-09-04 12:08:34 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:10:38 --> Config Class Initialized
INFO - 2020-09-04 12:10:38 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:10:38 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:10:38 --> Utf8 Class Initialized
INFO - 2020-09-04 12:10:38 --> URI Class Initialized
INFO - 2020-09-04 12:10:38 --> Router Class Initialized
INFO - 2020-09-04 12:10:38 --> Output Class Initialized
INFO - 2020-09-04 12:10:38 --> Security Class Initialized
DEBUG - 2020-09-04 12:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:10:38 --> Input Class Initialized
INFO - 2020-09-04 12:10:38 --> Language Class Initialized
INFO - 2020-09-04 12:10:38 --> Language Class Initialized
INFO - 2020-09-04 12:10:38 --> Config Class Initialized
INFO - 2020-09-04 12:10:38 --> Loader Class Initialized
INFO - 2020-09-04 12:10:38 --> Helper loaded: url_helper
INFO - 2020-09-04 12:10:38 --> Helper loaded: form_helper
INFO - 2020-09-04 12:10:38 --> Helper loaded: file_helper
INFO - 2020-09-04 12:10:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:10:38 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:10:38 --> Upload Class Initialized
INFO - 2020-09-04 12:10:38 --> Controller Class Initialized
ERROR - 2020-09-04 12:10:38 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:14:05 --> Config Class Initialized
INFO - 2020-09-04 12:14:05 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:14:05 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:14:05 --> Utf8 Class Initialized
INFO - 2020-09-04 12:14:05 --> URI Class Initialized
INFO - 2020-09-04 12:14:05 --> Router Class Initialized
INFO - 2020-09-04 12:14:05 --> Output Class Initialized
INFO - 2020-09-04 12:14:05 --> Security Class Initialized
DEBUG - 2020-09-04 12:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:14:05 --> Input Class Initialized
INFO - 2020-09-04 12:14:05 --> Language Class Initialized
INFO - 2020-09-04 12:14:05 --> Language Class Initialized
INFO - 2020-09-04 12:14:05 --> Config Class Initialized
INFO - 2020-09-04 12:14:05 --> Loader Class Initialized
INFO - 2020-09-04 12:14:05 --> Helper loaded: url_helper
INFO - 2020-09-04 12:14:05 --> Helper loaded: form_helper
INFO - 2020-09-04 12:14:05 --> Helper loaded: file_helper
INFO - 2020-09-04 12:14:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:14:05 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:14:05 --> Upload Class Initialized
INFO - 2020-09-04 12:14:05 --> Controller Class Initialized
ERROR - 2020-09-04 12:14:05 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:14:06 --> Config Class Initialized
INFO - 2020-09-04 12:14:06 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:14:06 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:14:06 --> Utf8 Class Initialized
INFO - 2020-09-04 12:14:06 --> URI Class Initialized
INFO - 2020-09-04 12:14:06 --> Router Class Initialized
INFO - 2020-09-04 12:14:06 --> Output Class Initialized
INFO - 2020-09-04 12:14:06 --> Security Class Initialized
DEBUG - 2020-09-04 12:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:14:06 --> Input Class Initialized
INFO - 2020-09-04 12:14:06 --> Language Class Initialized
INFO - 2020-09-04 12:14:06 --> Language Class Initialized
INFO - 2020-09-04 12:14:06 --> Config Class Initialized
INFO - 2020-09-04 12:14:06 --> Loader Class Initialized
INFO - 2020-09-04 12:14:06 --> Helper loaded: url_helper
INFO - 2020-09-04 12:14:06 --> Helper loaded: form_helper
INFO - 2020-09-04 12:14:06 --> Helper loaded: file_helper
INFO - 2020-09-04 12:14:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:14:06 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:14:06 --> Upload Class Initialized
INFO - 2020-09-04 12:14:06 --> Controller Class Initialized
ERROR - 2020-09-04 12:14:06 --> 404 Page Not Found: /index
INFO - 2020-09-04 12:32:38 --> Config Class Initialized
INFO - 2020-09-04 12:32:38 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:32:38 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:32:38 --> Utf8 Class Initialized
INFO - 2020-09-04 12:32:38 --> URI Class Initialized
DEBUG - 2020-09-04 12:32:38 --> No URI present. Default controller set.
INFO - 2020-09-04 12:32:38 --> Router Class Initialized
INFO - 2020-09-04 12:32:38 --> Output Class Initialized
INFO - 2020-09-04 12:32:38 --> Security Class Initialized
DEBUG - 2020-09-04 12:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:32:38 --> Input Class Initialized
INFO - 2020-09-04 12:32:38 --> Language Class Initialized
INFO - 2020-09-04 12:32:38 --> Language Class Initialized
INFO - 2020-09-04 12:32:38 --> Config Class Initialized
INFO - 2020-09-04 12:32:38 --> Loader Class Initialized
INFO - 2020-09-04 12:32:38 --> Helper loaded: url_helper
INFO - 2020-09-04 12:32:38 --> Helper loaded: form_helper
INFO - 2020-09-04 12:32:38 --> Helper loaded: file_helper
INFO - 2020-09-04 12:32:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:32:38 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:32:38 --> Upload Class Initialized
INFO - 2020-09-04 12:32:38 --> Controller Class Initialized
DEBUG - 2020-09-04 12:32:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:32:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:32:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:32:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:32:38 --> Final output sent to browser
DEBUG - 2020-09-04 12:32:38 --> Total execution time: 0.0800
INFO - 2020-09-04 12:32:39 --> Config Class Initialized
INFO - 2020-09-04 12:32:39 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:32:39 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:32:39 --> Utf8 Class Initialized
INFO - 2020-09-04 12:32:39 --> URI Class Initialized
DEBUG - 2020-09-04 12:32:39 --> No URI present. Default controller set.
INFO - 2020-09-04 12:32:39 --> Router Class Initialized
INFO - 2020-09-04 12:32:39 --> Output Class Initialized
INFO - 2020-09-04 12:32:39 --> Security Class Initialized
DEBUG - 2020-09-04 12:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:32:39 --> Input Class Initialized
INFO - 2020-09-04 12:32:39 --> Language Class Initialized
INFO - 2020-09-04 12:32:39 --> Language Class Initialized
INFO - 2020-09-04 12:32:39 --> Config Class Initialized
INFO - 2020-09-04 12:32:39 --> Loader Class Initialized
INFO - 2020-09-04 12:32:39 --> Helper loaded: url_helper
INFO - 2020-09-04 12:32:39 --> Helper loaded: form_helper
INFO - 2020-09-04 12:32:39 --> Helper loaded: file_helper
INFO - 2020-09-04 12:32:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:32:39 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:32:39 --> Upload Class Initialized
INFO - 2020-09-04 12:32:39 --> Controller Class Initialized
DEBUG - 2020-09-04 12:32:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:32:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:32:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:32:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:32:39 --> Final output sent to browser
DEBUG - 2020-09-04 12:32:39 --> Total execution time: 0.0531
INFO - 2020-09-04 12:33:39 --> Config Class Initialized
INFO - 2020-09-04 12:33:39 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:33:39 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:33:39 --> Utf8 Class Initialized
INFO - 2020-09-04 12:33:39 --> URI Class Initialized
DEBUG - 2020-09-04 12:33:39 --> No URI present. Default controller set.
INFO - 2020-09-04 12:33:39 --> Router Class Initialized
INFO - 2020-09-04 12:33:39 --> Output Class Initialized
INFO - 2020-09-04 12:33:39 --> Security Class Initialized
DEBUG - 2020-09-04 12:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:33:39 --> Input Class Initialized
INFO - 2020-09-04 12:33:39 --> Language Class Initialized
INFO - 2020-09-04 12:33:39 --> Language Class Initialized
INFO - 2020-09-04 12:33:39 --> Config Class Initialized
INFO - 2020-09-04 12:33:39 --> Loader Class Initialized
INFO - 2020-09-04 12:33:39 --> Helper loaded: url_helper
INFO - 2020-09-04 12:33:39 --> Helper loaded: form_helper
INFO - 2020-09-04 12:33:39 --> Helper loaded: file_helper
INFO - 2020-09-04 12:33:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:33:39 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:33:39 --> Upload Class Initialized
INFO - 2020-09-04 12:33:39 --> Controller Class Initialized
DEBUG - 2020-09-04 12:33:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:33:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:33:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:33:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:33:39 --> Final output sent to browser
DEBUG - 2020-09-04 12:33:39 --> Total execution time: 0.0512
INFO - 2020-09-04 12:47:15 --> Config Class Initialized
INFO - 2020-09-04 12:47:15 --> Hooks Class Initialized
DEBUG - 2020-09-04 12:47:15 --> UTF-8 Support Enabled
INFO - 2020-09-04 12:47:15 --> Utf8 Class Initialized
INFO - 2020-09-04 12:47:15 --> URI Class Initialized
DEBUG - 2020-09-04 12:47:15 --> No URI present. Default controller set.
INFO - 2020-09-04 12:47:15 --> Router Class Initialized
INFO - 2020-09-04 12:47:15 --> Output Class Initialized
INFO - 2020-09-04 12:47:15 --> Security Class Initialized
DEBUG - 2020-09-04 12:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 12:47:15 --> Input Class Initialized
INFO - 2020-09-04 12:47:15 --> Language Class Initialized
INFO - 2020-09-04 12:47:15 --> Language Class Initialized
INFO - 2020-09-04 12:47:15 --> Config Class Initialized
INFO - 2020-09-04 12:47:15 --> Loader Class Initialized
INFO - 2020-09-04 12:47:15 --> Helper loaded: url_helper
INFO - 2020-09-04 12:47:15 --> Helper loaded: form_helper
INFO - 2020-09-04 12:47:15 --> Helper loaded: file_helper
INFO - 2020-09-04 12:47:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 12:47:15 --> Database Driver Class Initialized
DEBUG - 2020-09-04 12:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 12:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 12:47:15 --> Upload Class Initialized
INFO - 2020-09-04 12:47:15 --> Controller Class Initialized
DEBUG - 2020-09-04 12:47:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 12:47:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 12:47:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 12:47:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 12:47:15 --> Final output sent to browser
DEBUG - 2020-09-04 12:47:15 --> Total execution time: 0.0492
INFO - 2020-09-04 13:01:16 --> Config Class Initialized
INFO - 2020-09-04 13:01:16 --> Hooks Class Initialized
DEBUG - 2020-09-04 13:01:16 --> UTF-8 Support Enabled
INFO - 2020-09-04 13:01:16 --> Utf8 Class Initialized
INFO - 2020-09-04 13:01:16 --> URI Class Initialized
DEBUG - 2020-09-04 13:01:16 --> No URI present. Default controller set.
INFO - 2020-09-04 13:01:16 --> Router Class Initialized
INFO - 2020-09-04 13:01:16 --> Output Class Initialized
INFO - 2020-09-04 13:01:16 --> Security Class Initialized
DEBUG - 2020-09-04 13:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 13:01:16 --> Input Class Initialized
INFO - 2020-09-04 13:01:16 --> Language Class Initialized
INFO - 2020-09-04 13:01:16 --> Language Class Initialized
INFO - 2020-09-04 13:01:16 --> Config Class Initialized
INFO - 2020-09-04 13:01:16 --> Loader Class Initialized
INFO - 2020-09-04 13:01:16 --> Helper loaded: url_helper
INFO - 2020-09-04 13:01:16 --> Helper loaded: form_helper
INFO - 2020-09-04 13:01:16 --> Helper loaded: file_helper
INFO - 2020-09-04 13:01:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 13:01:16 --> Database Driver Class Initialized
DEBUG - 2020-09-04 13:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 13:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 13:01:16 --> Upload Class Initialized
INFO - 2020-09-04 13:01:16 --> Controller Class Initialized
DEBUG - 2020-09-04 13:01:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 13:01:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 13:01:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 13:01:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 13:01:16 --> Final output sent to browser
DEBUG - 2020-09-04 13:01:16 --> Total execution time: 0.0527
INFO - 2020-09-04 14:17:17 --> Config Class Initialized
INFO - 2020-09-04 14:17:17 --> Hooks Class Initialized
DEBUG - 2020-09-04 14:17:17 --> UTF-8 Support Enabled
INFO - 2020-09-04 14:17:17 --> Utf8 Class Initialized
INFO - 2020-09-04 14:17:17 --> URI Class Initialized
INFO - 2020-09-04 14:17:17 --> Router Class Initialized
INFO - 2020-09-04 14:17:17 --> Output Class Initialized
INFO - 2020-09-04 14:17:17 --> Security Class Initialized
DEBUG - 2020-09-04 14:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 14:17:17 --> Input Class Initialized
INFO - 2020-09-04 14:17:17 --> Language Class Initialized
INFO - 2020-09-04 14:17:17 --> Language Class Initialized
INFO - 2020-09-04 14:17:17 --> Config Class Initialized
INFO - 2020-09-04 14:17:17 --> Loader Class Initialized
INFO - 2020-09-04 14:17:17 --> Helper loaded: url_helper
INFO - 2020-09-04 14:17:17 --> Helper loaded: form_helper
INFO - 2020-09-04 14:17:17 --> Helper loaded: file_helper
INFO - 2020-09-04 14:17:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 14:17:17 --> Database Driver Class Initialized
DEBUG - 2020-09-04 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 14:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 14:17:17 --> Upload Class Initialized
INFO - 2020-09-04 14:17:17 --> Controller Class Initialized
ERROR - 2020-09-04 14:17:17 --> 404 Page Not Found: /index
INFO - 2020-09-04 14:17:17 --> Config Class Initialized
INFO - 2020-09-04 14:17:17 --> Hooks Class Initialized
DEBUG - 2020-09-04 14:17:17 --> UTF-8 Support Enabled
INFO - 2020-09-04 14:17:17 --> Utf8 Class Initialized
INFO - 2020-09-04 14:17:17 --> URI Class Initialized
INFO - 2020-09-04 14:17:17 --> Router Class Initialized
INFO - 2020-09-04 14:17:17 --> Output Class Initialized
INFO - 2020-09-04 14:17:17 --> Security Class Initialized
DEBUG - 2020-09-04 14:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 14:17:17 --> Input Class Initialized
INFO - 2020-09-04 14:17:17 --> Language Class Initialized
INFO - 2020-09-04 14:17:17 --> Language Class Initialized
INFO - 2020-09-04 14:17:17 --> Config Class Initialized
INFO - 2020-09-04 14:17:17 --> Loader Class Initialized
INFO - 2020-09-04 14:17:17 --> Helper loaded: url_helper
INFO - 2020-09-04 14:17:17 --> Helper loaded: form_helper
INFO - 2020-09-04 14:17:17 --> Helper loaded: file_helper
INFO - 2020-09-04 14:17:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 14:17:17 --> Database Driver Class Initialized
DEBUG - 2020-09-04 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 14:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 14:17:17 --> Upload Class Initialized
INFO - 2020-09-04 14:17:17 --> Controller Class Initialized
DEBUG - 2020-09-04 14:17:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 14:17:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-04 14:17:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 14:17:17 --> Final output sent to browser
DEBUG - 2020-09-04 14:17:17 --> Total execution time: 0.0672
INFO - 2020-09-04 15:08:30 --> Config Class Initialized
INFO - 2020-09-04 15:08:30 --> Hooks Class Initialized
DEBUG - 2020-09-04 15:08:30 --> UTF-8 Support Enabled
INFO - 2020-09-04 15:08:30 --> Utf8 Class Initialized
INFO - 2020-09-04 15:08:30 --> URI Class Initialized
DEBUG - 2020-09-04 15:08:30 --> No URI present. Default controller set.
INFO - 2020-09-04 15:08:30 --> Router Class Initialized
INFO - 2020-09-04 15:08:30 --> Output Class Initialized
INFO - 2020-09-04 15:08:30 --> Security Class Initialized
DEBUG - 2020-09-04 15:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 15:08:30 --> Input Class Initialized
INFO - 2020-09-04 15:08:30 --> Language Class Initialized
INFO - 2020-09-04 15:08:30 --> Language Class Initialized
INFO - 2020-09-04 15:08:30 --> Config Class Initialized
INFO - 2020-09-04 15:08:30 --> Loader Class Initialized
INFO - 2020-09-04 15:08:30 --> Helper loaded: url_helper
INFO - 2020-09-04 15:08:30 --> Helper loaded: form_helper
INFO - 2020-09-04 15:08:30 --> Helper loaded: file_helper
INFO - 2020-09-04 15:08:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 15:08:30 --> Database Driver Class Initialized
DEBUG - 2020-09-04 15:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 15:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 15:08:30 --> Upload Class Initialized
INFO - 2020-09-04 15:08:30 --> Controller Class Initialized
DEBUG - 2020-09-04 15:08:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 15:08:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 15:08:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 15:08:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 15:08:30 --> Final output sent to browser
DEBUG - 2020-09-04 15:08:30 --> Total execution time: 0.0534
INFO - 2020-09-04 15:47:31 --> Config Class Initialized
INFO - 2020-09-04 15:47:31 --> Hooks Class Initialized
DEBUG - 2020-09-04 15:47:31 --> UTF-8 Support Enabled
INFO - 2020-09-04 15:47:31 --> Utf8 Class Initialized
INFO - 2020-09-04 15:47:31 --> URI Class Initialized
DEBUG - 2020-09-04 15:47:31 --> No URI present. Default controller set.
INFO - 2020-09-04 15:47:31 --> Router Class Initialized
INFO - 2020-09-04 15:47:31 --> Output Class Initialized
INFO - 2020-09-04 15:47:31 --> Security Class Initialized
DEBUG - 2020-09-04 15:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 15:47:31 --> Input Class Initialized
INFO - 2020-09-04 15:47:31 --> Language Class Initialized
INFO - 2020-09-04 15:47:31 --> Language Class Initialized
INFO - 2020-09-04 15:47:31 --> Config Class Initialized
INFO - 2020-09-04 15:47:31 --> Loader Class Initialized
INFO - 2020-09-04 15:47:31 --> Helper loaded: url_helper
INFO - 2020-09-04 15:47:31 --> Helper loaded: form_helper
INFO - 2020-09-04 15:47:31 --> Helper loaded: file_helper
INFO - 2020-09-04 15:47:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 15:47:31 --> Database Driver Class Initialized
DEBUG - 2020-09-04 15:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 15:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 15:47:31 --> Upload Class Initialized
INFO - 2020-09-04 15:47:31 --> Controller Class Initialized
DEBUG - 2020-09-04 15:47:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 15:47:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 15:47:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 15:47:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 15:47:31 --> Final output sent to browser
DEBUG - 2020-09-04 15:47:31 --> Total execution time: 0.0557
INFO - 2020-09-04 15:47:33 --> Config Class Initialized
INFO - 2020-09-04 15:47:33 --> Hooks Class Initialized
DEBUG - 2020-09-04 15:47:33 --> UTF-8 Support Enabled
INFO - 2020-09-04 15:47:33 --> Utf8 Class Initialized
INFO - 2020-09-04 15:47:33 --> URI Class Initialized
INFO - 2020-09-04 15:47:33 --> Router Class Initialized
INFO - 2020-09-04 15:47:33 --> Output Class Initialized
INFO - 2020-09-04 15:47:33 --> Security Class Initialized
DEBUG - 2020-09-04 15:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 15:47:33 --> Input Class Initialized
INFO - 2020-09-04 15:47:33 --> Language Class Initialized
INFO - 2020-09-04 15:47:33 --> Language Class Initialized
INFO - 2020-09-04 15:47:33 --> Config Class Initialized
INFO - 2020-09-04 15:47:33 --> Loader Class Initialized
INFO - 2020-09-04 15:47:33 --> Helper loaded: url_helper
INFO - 2020-09-04 15:47:33 --> Helper loaded: form_helper
INFO - 2020-09-04 15:47:33 --> Helper loaded: file_helper
INFO - 2020-09-04 15:47:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 15:47:33 --> Database Driver Class Initialized
DEBUG - 2020-09-04 15:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 15:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 15:47:33 --> Upload Class Initialized
INFO - 2020-09-04 15:47:33 --> Controller Class Initialized
ERROR - 2020-09-04 15:47:33 --> 404 Page Not Found: /index
INFO - 2020-09-04 16:14:31 --> Config Class Initialized
INFO - 2020-09-04 16:14:31 --> Hooks Class Initialized
DEBUG - 2020-09-04 16:14:31 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:14:31 --> Utf8 Class Initialized
INFO - 2020-09-04 16:14:31 --> URI Class Initialized
DEBUG - 2020-09-04 16:14:31 --> No URI present. Default controller set.
INFO - 2020-09-04 16:14:31 --> Router Class Initialized
INFO - 2020-09-04 16:14:31 --> Output Class Initialized
INFO - 2020-09-04 16:14:31 --> Security Class Initialized
DEBUG - 2020-09-04 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:14:31 --> Input Class Initialized
INFO - 2020-09-04 16:14:31 --> Language Class Initialized
INFO - 2020-09-04 16:14:31 --> Language Class Initialized
INFO - 2020-09-04 16:14:31 --> Config Class Initialized
INFO - 2020-09-04 16:14:31 --> Loader Class Initialized
INFO - 2020-09-04 16:14:31 --> Helper loaded: url_helper
INFO - 2020-09-04 16:14:31 --> Helper loaded: form_helper
INFO - 2020-09-04 16:14:31 --> Helper loaded: file_helper
INFO - 2020-09-04 16:14:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:14:31 --> Database Driver Class Initialized
DEBUG - 2020-09-04 16:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:14:31 --> Upload Class Initialized
INFO - 2020-09-04 16:14:31 --> Controller Class Initialized
DEBUG - 2020-09-04 16:14:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 16:14:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 16:14:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 16:14:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 16:14:31 --> Final output sent to browser
DEBUG - 2020-09-04 16:14:31 --> Total execution time: 0.0582
INFO - 2020-09-04 16:14:55 --> Config Class Initialized
INFO - 2020-09-04 16:14:55 --> Hooks Class Initialized
DEBUG - 2020-09-04 16:14:55 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:14:55 --> Utf8 Class Initialized
INFO - 2020-09-04 16:14:55 --> URI Class Initialized
DEBUG - 2020-09-04 16:14:55 --> No URI present. Default controller set.
INFO - 2020-09-04 16:14:55 --> Router Class Initialized
INFO - 2020-09-04 16:14:55 --> Output Class Initialized
INFO - 2020-09-04 16:14:55 --> Security Class Initialized
DEBUG - 2020-09-04 16:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:14:55 --> Input Class Initialized
INFO - 2020-09-04 16:14:55 --> Language Class Initialized
INFO - 2020-09-04 16:14:55 --> Language Class Initialized
INFO - 2020-09-04 16:14:55 --> Config Class Initialized
INFO - 2020-09-04 16:14:55 --> Loader Class Initialized
INFO - 2020-09-04 16:14:55 --> Helper loaded: url_helper
INFO - 2020-09-04 16:14:55 --> Helper loaded: form_helper
INFO - 2020-09-04 16:14:55 --> Helper loaded: file_helper
INFO - 2020-09-04 16:14:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:14:55 --> Database Driver Class Initialized
DEBUG - 2020-09-04 16:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 16:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:14:55 --> Upload Class Initialized
INFO - 2020-09-04 16:14:55 --> Controller Class Initialized
DEBUG - 2020-09-04 16:14:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 16:14:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 16:14:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 16:14:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 16:14:56 --> Final output sent to browser
DEBUG - 2020-09-04 16:14:56 --> Total execution time: 0.0514
INFO - 2020-09-04 16:15:00 --> Config Class Initialized
INFO - 2020-09-04 16:15:00 --> Hooks Class Initialized
DEBUG - 2020-09-04 16:15:00 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:15:00 --> Utf8 Class Initialized
INFO - 2020-09-04 16:15:00 --> URI Class Initialized
INFO - 2020-09-04 16:15:00 --> Router Class Initialized
INFO - 2020-09-04 16:15:00 --> Output Class Initialized
INFO - 2020-09-04 16:15:00 --> Security Class Initialized
DEBUG - 2020-09-04 16:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:15:00 --> Input Class Initialized
INFO - 2020-09-04 16:15:00 --> Language Class Initialized
INFO - 2020-09-04 16:15:00 --> Language Class Initialized
INFO - 2020-09-04 16:15:00 --> Config Class Initialized
INFO - 2020-09-04 16:15:00 --> Loader Class Initialized
INFO - 2020-09-04 16:15:00 --> Helper loaded: url_helper
INFO - 2020-09-04 16:15:00 --> Helper loaded: form_helper
INFO - 2020-09-04 16:15:00 --> Helper loaded: file_helper
INFO - 2020-09-04 16:15:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:15:00 --> Database Driver Class Initialized
DEBUG - 2020-09-04 16:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 16:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:15:00 --> Upload Class Initialized
INFO - 2020-09-04 16:15:00 --> Controller Class Initialized
ERROR - 2020-09-04 16:15:00 --> 404 Page Not Found: /index
INFO - 2020-09-04 16:16:47 --> Config Class Initialized
INFO - 2020-09-04 16:16:47 --> Hooks Class Initialized
INFO - 2020-09-04 16:16:47 --> Config Class Initialized
INFO - 2020-09-04 16:16:47 --> Hooks Class Initialized
DEBUG - 2020-09-04 16:16:47 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:16:47 --> Utf8 Class Initialized
INFO - 2020-09-04 16:16:47 --> URI Class Initialized
DEBUG - 2020-09-04 16:16:47 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:16:47 --> Utf8 Class Initialized
INFO - 2020-09-04 16:16:47 --> URI Class Initialized
DEBUG - 2020-09-04 16:16:47 --> No URI present. Default controller set.
INFO - 2020-09-04 16:16:47 --> Router Class Initialized
DEBUG - 2020-09-04 16:16:47 --> No URI present. Default controller set.
INFO - 2020-09-04 16:16:47 --> Router Class Initialized
INFO - 2020-09-04 16:16:47 --> Output Class Initialized
INFO - 2020-09-04 16:16:47 --> Output Class Initialized
INFO - 2020-09-04 16:16:47 --> Security Class Initialized
INFO - 2020-09-04 16:16:47 --> Security Class Initialized
DEBUG - 2020-09-04 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:16:47 --> Input Class Initialized
INFO - 2020-09-04 16:16:47 --> Language Class Initialized
DEBUG - 2020-09-04 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:16:47 --> Input Class Initialized
INFO - 2020-09-04 16:16:47 --> Language Class Initialized
INFO - 2020-09-04 16:16:47 --> Language Class Initialized
INFO - 2020-09-04 16:16:47 --> Config Class Initialized
INFO - 2020-09-04 16:16:47 --> Language Class Initialized
INFO - 2020-09-04 16:16:47 --> Config Class Initialized
INFO - 2020-09-04 16:16:47 --> Loader Class Initialized
INFO - 2020-09-04 16:16:47 --> Loader Class Initialized
INFO - 2020-09-04 16:16:47 --> Helper loaded: url_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: url_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: form_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: form_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: file_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: file_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:16:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:16:47 --> Database Driver Class Initialized
INFO - 2020-09-04 16:16:47 --> Database Driver Class Initialized
DEBUG - 2020-09-04 16:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-09-04 16:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 16:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:16:47 --> Upload Class Initialized
INFO - 2020-09-04 16:16:47 --> Upload Class Initialized
INFO - 2020-09-04 16:16:47 --> Controller Class Initialized
DEBUG - 2020-09-04 16:16:47 --> Home MX_Controller Initialized
INFO - 2020-09-04 16:16:47 --> Controller Class Initialized
DEBUG - 2020-09-04 16:16:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 16:16:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 16:16:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 16:16:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 16:16:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 16:16:47 --> Final output sent to browser
DEBUG - 2020-09-04 16:16:47 --> Total execution time: 0.0529
DEBUG - 2020-09-04 16:16:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 16:16:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 16:16:47 --> Final output sent to browser
DEBUG - 2020-09-04 16:16:47 --> Total execution time: 0.0549
INFO - 2020-09-04 16:16:49 --> Config Class Initialized
INFO - 2020-09-04 16:16:49 --> Hooks Class Initialized
DEBUG - 2020-09-04 16:16:49 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:16:49 --> Utf8 Class Initialized
INFO - 2020-09-04 16:16:49 --> URI Class Initialized
DEBUG - 2020-09-04 16:16:49 --> No URI present. Default controller set.
INFO - 2020-09-04 16:16:49 --> Router Class Initialized
INFO - 2020-09-04 16:16:49 --> Output Class Initialized
INFO - 2020-09-04 16:16:49 --> Security Class Initialized
DEBUG - 2020-09-04 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:16:49 --> Input Class Initialized
INFO - 2020-09-04 16:16:49 --> Language Class Initialized
INFO - 2020-09-04 16:16:49 --> Language Class Initialized
INFO - 2020-09-04 16:16:49 --> Config Class Initialized
INFO - 2020-09-04 16:16:49 --> Loader Class Initialized
INFO - 2020-09-04 16:16:49 --> Helper loaded: url_helper
INFO - 2020-09-04 16:16:49 --> Helper loaded: form_helper
INFO - 2020-09-04 16:16:49 --> Helper loaded: file_helper
INFO - 2020-09-04 16:16:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:16:49 --> Database Driver Class Initialized
DEBUG - 2020-09-04 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:16:49 --> Upload Class Initialized
INFO - 2020-09-04 16:16:49 --> Controller Class Initialized
DEBUG - 2020-09-04 16:16:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 16:16:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 16:16:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 16:16:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 16:16:49 --> Final output sent to browser
DEBUG - 2020-09-04 16:16:49 --> Total execution time: 0.0533
INFO - 2020-09-04 16:18:04 --> Config Class Initialized
INFO - 2020-09-04 16:18:04 --> Hooks Class Initialized
DEBUG - 2020-09-04 16:18:04 --> UTF-8 Support Enabled
INFO - 2020-09-04 16:18:04 --> Utf8 Class Initialized
INFO - 2020-09-04 16:18:04 --> URI Class Initialized
DEBUG - 2020-09-04 16:18:04 --> No URI present. Default controller set.
INFO - 2020-09-04 16:18:04 --> Router Class Initialized
INFO - 2020-09-04 16:18:04 --> Output Class Initialized
INFO - 2020-09-04 16:18:04 --> Security Class Initialized
DEBUG - 2020-09-04 16:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 16:18:04 --> Input Class Initialized
INFO - 2020-09-04 16:18:04 --> Language Class Initialized
INFO - 2020-09-04 16:18:04 --> Language Class Initialized
INFO - 2020-09-04 16:18:04 --> Config Class Initialized
INFO - 2020-09-04 16:18:04 --> Loader Class Initialized
INFO - 2020-09-04 16:18:04 --> Helper loaded: url_helper
INFO - 2020-09-04 16:18:04 --> Helper loaded: form_helper
INFO - 2020-09-04 16:18:04 --> Helper loaded: file_helper
INFO - 2020-09-04 16:18:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 16:18:04 --> Database Driver Class Initialized
DEBUG - 2020-09-04 16:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 16:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 16:18:04 --> Upload Class Initialized
INFO - 2020-09-04 16:18:04 --> Controller Class Initialized
DEBUG - 2020-09-04 16:18:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 16:18:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 16:18:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 16:18:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 16:18:04 --> Final output sent to browser
DEBUG - 2020-09-04 16:18:04 --> Total execution time: 0.0529
INFO - 2020-09-04 17:01:13 --> Config Class Initialized
INFO - 2020-09-04 17:01:13 --> Hooks Class Initialized
DEBUG - 2020-09-04 17:01:13 --> UTF-8 Support Enabled
INFO - 2020-09-04 17:01:13 --> Utf8 Class Initialized
INFO - 2020-09-04 17:01:13 --> URI Class Initialized
DEBUG - 2020-09-04 17:01:13 --> No URI present. Default controller set.
INFO - 2020-09-04 17:01:13 --> Router Class Initialized
INFO - 2020-09-04 17:01:13 --> Output Class Initialized
INFO - 2020-09-04 17:01:13 --> Security Class Initialized
DEBUG - 2020-09-04 17:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 17:01:13 --> Input Class Initialized
INFO - 2020-09-04 17:01:13 --> Language Class Initialized
INFO - 2020-09-04 17:01:13 --> Language Class Initialized
INFO - 2020-09-04 17:01:13 --> Config Class Initialized
INFO - 2020-09-04 17:01:13 --> Loader Class Initialized
INFO - 2020-09-04 17:01:13 --> Helper loaded: url_helper
INFO - 2020-09-04 17:01:13 --> Helper loaded: form_helper
INFO - 2020-09-04 17:01:13 --> Helper loaded: file_helper
INFO - 2020-09-04 17:01:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 17:01:13 --> Database Driver Class Initialized
DEBUG - 2020-09-04 17:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 17:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 17:01:13 --> Upload Class Initialized
INFO - 2020-09-04 17:01:13 --> Controller Class Initialized
DEBUG - 2020-09-04 17:01:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 17:01:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 17:01:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 17:01:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 17:01:13 --> Final output sent to browser
DEBUG - 2020-09-04 17:01:13 --> Total execution time: 0.0541
INFO - 2020-09-04 17:31:36 --> Config Class Initialized
INFO - 2020-09-04 17:31:36 --> Hooks Class Initialized
DEBUG - 2020-09-04 17:31:36 --> UTF-8 Support Enabled
INFO - 2020-09-04 17:31:36 --> Utf8 Class Initialized
INFO - 2020-09-04 17:31:36 --> URI Class Initialized
INFO - 2020-09-04 17:31:36 --> Router Class Initialized
INFO - 2020-09-04 17:31:36 --> Output Class Initialized
INFO - 2020-09-04 17:31:36 --> Security Class Initialized
DEBUG - 2020-09-04 17:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 17:31:36 --> Input Class Initialized
INFO - 2020-09-04 17:31:36 --> Language Class Initialized
INFO - 2020-09-04 17:31:36 --> Language Class Initialized
INFO - 2020-09-04 17:31:36 --> Config Class Initialized
INFO - 2020-09-04 17:31:36 --> Loader Class Initialized
INFO - 2020-09-04 17:31:36 --> Helper loaded: url_helper
INFO - 2020-09-04 17:31:36 --> Helper loaded: form_helper
INFO - 2020-09-04 17:31:36 --> Helper loaded: file_helper
INFO - 2020-09-04 17:31:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 17:31:36 --> Database Driver Class Initialized
DEBUG - 2020-09-04 17:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 17:31:36 --> Upload Class Initialized
INFO - 2020-09-04 17:31:36 --> Controller Class Initialized
ERROR - 2020-09-04 17:31:36 --> 404 Page Not Found: /index
INFO - 2020-09-04 17:31:36 --> Config Class Initialized
INFO - 2020-09-04 17:31:36 --> Hooks Class Initialized
DEBUG - 2020-09-04 17:31:36 --> UTF-8 Support Enabled
INFO - 2020-09-04 17:31:36 --> Utf8 Class Initialized
INFO - 2020-09-04 17:31:36 --> URI Class Initialized
INFO - 2020-09-04 17:31:36 --> Router Class Initialized
INFO - 2020-09-04 17:31:36 --> Output Class Initialized
INFO - 2020-09-04 17:31:36 --> Security Class Initialized
DEBUG - 2020-09-04 17:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 17:31:36 --> Input Class Initialized
INFO - 2020-09-04 17:31:36 --> Language Class Initialized
INFO - 2020-09-04 17:31:36 --> Language Class Initialized
INFO - 2020-09-04 17:31:36 --> Config Class Initialized
INFO - 2020-09-04 17:31:36 --> Loader Class Initialized
INFO - 2020-09-04 17:31:36 --> Helper loaded: url_helper
INFO - 2020-09-04 17:31:36 --> Helper loaded: form_helper
INFO - 2020-09-04 17:31:36 --> Helper loaded: file_helper
INFO - 2020-09-04 17:31:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 17:31:36 --> Database Driver Class Initialized
DEBUG - 2020-09-04 17:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 17:31:36 --> Upload Class Initialized
INFO - 2020-09-04 17:31:37 --> Controller Class Initialized
ERROR - 2020-09-04 17:31:37 --> 404 Page Not Found: /index
INFO - 2020-09-04 17:38:31 --> Config Class Initialized
INFO - 2020-09-04 17:38:31 --> Hooks Class Initialized
DEBUG - 2020-09-04 17:38:31 --> UTF-8 Support Enabled
INFO - 2020-09-04 17:38:31 --> Utf8 Class Initialized
INFO - 2020-09-04 17:38:31 --> URI Class Initialized
DEBUG - 2020-09-04 17:38:31 --> No URI present. Default controller set.
INFO - 2020-09-04 17:38:31 --> Router Class Initialized
INFO - 2020-09-04 17:38:31 --> Output Class Initialized
INFO - 2020-09-04 17:38:31 --> Security Class Initialized
DEBUG - 2020-09-04 17:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 17:38:31 --> Input Class Initialized
INFO - 2020-09-04 17:38:31 --> Language Class Initialized
INFO - 2020-09-04 17:38:31 --> Language Class Initialized
INFO - 2020-09-04 17:38:31 --> Config Class Initialized
INFO - 2020-09-04 17:38:31 --> Loader Class Initialized
INFO - 2020-09-04 17:38:31 --> Helper loaded: url_helper
INFO - 2020-09-04 17:38:31 --> Helper loaded: form_helper
INFO - 2020-09-04 17:38:31 --> Helper loaded: file_helper
INFO - 2020-09-04 17:38:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 17:38:31 --> Database Driver Class Initialized
DEBUG - 2020-09-04 17:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 17:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 17:38:31 --> Upload Class Initialized
INFO - 2020-09-04 17:38:31 --> Controller Class Initialized
DEBUG - 2020-09-04 17:38:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 17:38:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 17:38:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 17:38:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 17:38:31 --> Final output sent to browser
DEBUG - 2020-09-04 17:38:31 --> Total execution time: 0.0515
INFO - 2020-09-04 19:08:20 --> Config Class Initialized
INFO - 2020-09-04 19:08:20 --> Hooks Class Initialized
DEBUG - 2020-09-04 19:08:20 --> UTF-8 Support Enabled
INFO - 2020-09-04 19:08:20 --> Utf8 Class Initialized
INFO - 2020-09-04 19:08:20 --> URI Class Initialized
DEBUG - 2020-09-04 19:08:20 --> No URI present. Default controller set.
INFO - 2020-09-04 19:08:20 --> Router Class Initialized
INFO - 2020-09-04 19:08:20 --> Output Class Initialized
INFO - 2020-09-04 19:08:20 --> Security Class Initialized
DEBUG - 2020-09-04 19:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 19:08:20 --> Input Class Initialized
INFO - 2020-09-04 19:08:20 --> Language Class Initialized
INFO - 2020-09-04 19:08:20 --> Language Class Initialized
INFO - 2020-09-04 19:08:20 --> Config Class Initialized
INFO - 2020-09-04 19:08:20 --> Loader Class Initialized
INFO - 2020-09-04 19:08:20 --> Helper loaded: url_helper
INFO - 2020-09-04 19:08:20 --> Helper loaded: form_helper
INFO - 2020-09-04 19:08:20 --> Helper loaded: file_helper
INFO - 2020-09-04 19:08:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 19:08:20 --> Database Driver Class Initialized
DEBUG - 2020-09-04 19:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 19:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 19:08:20 --> Upload Class Initialized
INFO - 2020-09-04 19:08:20 --> Controller Class Initialized
DEBUG - 2020-09-04 19:08:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 19:08:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 19:08:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 19:08:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 19:08:20 --> Final output sent to browser
DEBUG - 2020-09-04 19:08:20 --> Total execution time: 0.0555
INFO - 2020-09-04 19:37:25 --> Config Class Initialized
INFO - 2020-09-04 19:37:25 --> Hooks Class Initialized
DEBUG - 2020-09-04 19:37:25 --> UTF-8 Support Enabled
INFO - 2020-09-04 19:37:25 --> Utf8 Class Initialized
INFO - 2020-09-04 19:37:25 --> URI Class Initialized
INFO - 2020-09-04 19:37:25 --> Router Class Initialized
INFO - 2020-09-04 19:37:25 --> Output Class Initialized
INFO - 2020-09-04 19:37:25 --> Security Class Initialized
DEBUG - 2020-09-04 19:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 19:37:25 --> Input Class Initialized
INFO - 2020-09-04 19:37:25 --> Language Class Initialized
INFO - 2020-09-04 19:37:25 --> Language Class Initialized
INFO - 2020-09-04 19:37:25 --> Config Class Initialized
INFO - 2020-09-04 19:37:25 --> Loader Class Initialized
INFO - 2020-09-04 19:37:25 --> Helper loaded: url_helper
INFO - 2020-09-04 19:37:25 --> Helper loaded: form_helper
INFO - 2020-09-04 19:37:25 --> Helper loaded: file_helper
INFO - 2020-09-04 19:37:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 19:37:25 --> Database Driver Class Initialized
DEBUG - 2020-09-04 19:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 19:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 19:37:25 --> Upload Class Initialized
INFO - 2020-09-04 19:37:25 --> Controller Class Initialized
ERROR - 2020-09-04 19:37:25 --> 404 Page Not Found: /index
INFO - 2020-09-04 20:01:40 --> Config Class Initialized
INFO - 2020-09-04 20:01:40 --> Hooks Class Initialized
DEBUG - 2020-09-04 20:01:40 --> UTF-8 Support Enabled
INFO - 2020-09-04 20:01:40 --> Utf8 Class Initialized
INFO - 2020-09-04 20:01:40 --> URI Class Initialized
DEBUG - 2020-09-04 20:01:40 --> No URI present. Default controller set.
INFO - 2020-09-04 20:01:40 --> Router Class Initialized
INFO - 2020-09-04 20:01:40 --> Output Class Initialized
INFO - 2020-09-04 20:01:40 --> Security Class Initialized
DEBUG - 2020-09-04 20:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 20:01:40 --> Input Class Initialized
INFO - 2020-09-04 20:01:40 --> Language Class Initialized
INFO - 2020-09-04 20:01:40 --> Language Class Initialized
INFO - 2020-09-04 20:01:40 --> Config Class Initialized
INFO - 2020-09-04 20:01:40 --> Loader Class Initialized
INFO - 2020-09-04 20:01:40 --> Helper loaded: url_helper
INFO - 2020-09-04 20:01:40 --> Helper loaded: form_helper
INFO - 2020-09-04 20:01:40 --> Helper loaded: file_helper
INFO - 2020-09-04 20:01:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 20:01:40 --> Database Driver Class Initialized
DEBUG - 2020-09-04 20:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 20:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 20:01:40 --> Upload Class Initialized
INFO - 2020-09-04 20:01:40 --> Controller Class Initialized
DEBUG - 2020-09-04 20:01:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 20:01:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 20:01:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 20:01:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 20:01:40 --> Final output sent to browser
DEBUG - 2020-09-04 20:01:40 --> Total execution time: 0.0510
INFO - 2020-09-04 20:34:37 --> Config Class Initialized
INFO - 2020-09-04 20:34:37 --> Hooks Class Initialized
DEBUG - 2020-09-04 20:34:37 --> UTF-8 Support Enabled
INFO - 2020-09-04 20:34:37 --> Utf8 Class Initialized
INFO - 2020-09-04 20:34:37 --> URI Class Initialized
INFO - 2020-09-04 20:34:37 --> Router Class Initialized
INFO - 2020-09-04 20:34:37 --> Output Class Initialized
INFO - 2020-09-04 20:34:37 --> Security Class Initialized
DEBUG - 2020-09-04 20:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 20:34:37 --> Input Class Initialized
INFO - 2020-09-04 20:34:37 --> Language Class Initialized
INFO - 2020-09-04 20:34:37 --> Language Class Initialized
INFO - 2020-09-04 20:34:37 --> Config Class Initialized
INFO - 2020-09-04 20:34:37 --> Loader Class Initialized
INFO - 2020-09-04 20:34:37 --> Helper loaded: url_helper
INFO - 2020-09-04 20:34:37 --> Helper loaded: form_helper
INFO - 2020-09-04 20:34:37 --> Helper loaded: file_helper
INFO - 2020-09-04 20:34:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 20:34:37 --> Database Driver Class Initialized
DEBUG - 2020-09-04 20:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 20:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 20:34:37 --> Upload Class Initialized
INFO - 2020-09-04 20:34:37 --> Controller Class Initialized
ERROR - 2020-09-04 20:34:37 --> 404 Page Not Found: /index
INFO - 2020-09-04 20:34:41 --> Config Class Initialized
INFO - 2020-09-04 20:34:41 --> Hooks Class Initialized
DEBUG - 2020-09-04 20:34:41 --> UTF-8 Support Enabled
INFO - 2020-09-04 20:34:41 --> Utf8 Class Initialized
INFO - 2020-09-04 20:34:41 --> URI Class Initialized
DEBUG - 2020-09-04 20:34:41 --> No URI present. Default controller set.
INFO - 2020-09-04 20:34:41 --> Router Class Initialized
INFO - 2020-09-04 20:34:41 --> Output Class Initialized
INFO - 2020-09-04 20:34:41 --> Security Class Initialized
DEBUG - 2020-09-04 20:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 20:34:41 --> Input Class Initialized
INFO - 2020-09-04 20:34:41 --> Language Class Initialized
INFO - 2020-09-04 20:34:41 --> Language Class Initialized
INFO - 2020-09-04 20:34:41 --> Config Class Initialized
INFO - 2020-09-04 20:34:41 --> Loader Class Initialized
INFO - 2020-09-04 20:34:41 --> Helper loaded: url_helper
INFO - 2020-09-04 20:34:41 --> Helper loaded: form_helper
INFO - 2020-09-04 20:34:41 --> Helper loaded: file_helper
INFO - 2020-09-04 20:34:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 20:34:41 --> Database Driver Class Initialized
DEBUG - 2020-09-04 20:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 20:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 20:34:41 --> Upload Class Initialized
INFO - 2020-09-04 20:34:41 --> Controller Class Initialized
DEBUG - 2020-09-04 20:34:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 20:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 20:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 20:34:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 20:34:41 --> Final output sent to browser
DEBUG - 2020-09-04 20:34:41 --> Total execution time: 0.0514
INFO - 2020-09-04 21:04:50 --> Config Class Initialized
INFO - 2020-09-04 21:04:50 --> Hooks Class Initialized
DEBUG - 2020-09-04 21:04:50 --> UTF-8 Support Enabled
INFO - 2020-09-04 21:04:50 --> Utf8 Class Initialized
INFO - 2020-09-04 21:04:50 --> URI Class Initialized
DEBUG - 2020-09-04 21:04:50 --> No URI present. Default controller set.
INFO - 2020-09-04 21:04:50 --> Router Class Initialized
INFO - 2020-09-04 21:04:50 --> Output Class Initialized
INFO - 2020-09-04 21:04:50 --> Security Class Initialized
DEBUG - 2020-09-04 21:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 21:04:50 --> Input Class Initialized
INFO - 2020-09-04 21:04:50 --> Language Class Initialized
INFO - 2020-09-04 21:04:50 --> Language Class Initialized
INFO - 2020-09-04 21:04:50 --> Config Class Initialized
INFO - 2020-09-04 21:04:50 --> Loader Class Initialized
INFO - 2020-09-04 21:04:50 --> Helper loaded: url_helper
INFO - 2020-09-04 21:04:50 --> Helper loaded: form_helper
INFO - 2020-09-04 21:04:50 --> Helper loaded: file_helper
INFO - 2020-09-04 21:04:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 21:04:50 --> Database Driver Class Initialized
DEBUG - 2020-09-04 21:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 21:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 21:04:50 --> Upload Class Initialized
INFO - 2020-09-04 21:04:50 --> Controller Class Initialized
DEBUG - 2020-09-04 21:04:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 21:04:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 21:04:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 21:04:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 21:04:50 --> Final output sent to browser
DEBUG - 2020-09-04 21:04:50 --> Total execution time: 0.0538
INFO - 2020-09-04 21:04:54 --> Config Class Initialized
INFO - 2020-09-04 21:04:54 --> Hooks Class Initialized
DEBUG - 2020-09-04 21:04:54 --> UTF-8 Support Enabled
INFO - 2020-09-04 21:04:54 --> Utf8 Class Initialized
INFO - 2020-09-04 21:04:54 --> URI Class Initialized
INFO - 2020-09-04 21:04:54 --> Router Class Initialized
INFO - 2020-09-04 21:04:54 --> Output Class Initialized
INFO - 2020-09-04 21:04:54 --> Security Class Initialized
DEBUG - 2020-09-04 21:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 21:04:54 --> Input Class Initialized
INFO - 2020-09-04 21:04:54 --> Language Class Initialized
INFO - 2020-09-04 21:04:54 --> Language Class Initialized
INFO - 2020-09-04 21:04:54 --> Config Class Initialized
INFO - 2020-09-04 21:04:54 --> Loader Class Initialized
INFO - 2020-09-04 21:04:54 --> Helper loaded: url_helper
INFO - 2020-09-04 21:04:54 --> Helper loaded: form_helper
INFO - 2020-09-04 21:04:54 --> Helper loaded: file_helper
INFO - 2020-09-04 21:04:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 21:04:54 --> Database Driver Class Initialized
DEBUG - 2020-09-04 21:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 21:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 21:04:54 --> Upload Class Initialized
INFO - 2020-09-04 21:04:54 --> Controller Class Initialized
ERROR - 2020-09-04 21:04:54 --> 404 Page Not Found: /index
INFO - 2020-09-04 21:32:04 --> Config Class Initialized
INFO - 2020-09-04 21:32:04 --> Hooks Class Initialized
DEBUG - 2020-09-04 21:32:04 --> UTF-8 Support Enabled
INFO - 2020-09-04 21:32:04 --> Utf8 Class Initialized
INFO - 2020-09-04 21:32:04 --> URI Class Initialized
DEBUG - 2020-09-04 21:32:04 --> No URI present. Default controller set.
INFO - 2020-09-04 21:32:04 --> Router Class Initialized
INFO - 2020-09-04 21:32:04 --> Output Class Initialized
INFO - 2020-09-04 21:32:04 --> Security Class Initialized
DEBUG - 2020-09-04 21:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 21:32:04 --> Input Class Initialized
INFO - 2020-09-04 21:32:04 --> Language Class Initialized
INFO - 2020-09-04 21:32:04 --> Language Class Initialized
INFO - 2020-09-04 21:32:04 --> Config Class Initialized
INFO - 2020-09-04 21:32:04 --> Loader Class Initialized
INFO - 2020-09-04 21:32:04 --> Helper loaded: url_helper
INFO - 2020-09-04 21:32:04 --> Helper loaded: form_helper
INFO - 2020-09-04 21:32:04 --> Helper loaded: file_helper
INFO - 2020-09-04 21:32:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 21:32:04 --> Database Driver Class Initialized
DEBUG - 2020-09-04 21:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 21:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 21:32:04 --> Upload Class Initialized
INFO - 2020-09-04 21:32:04 --> Controller Class Initialized
DEBUG - 2020-09-04 21:32:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 21:32:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 21:32:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 21:32:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 21:32:04 --> Final output sent to browser
DEBUG - 2020-09-04 21:32:04 --> Total execution time: 0.0532
INFO - 2020-09-04 22:25:43 --> Config Class Initialized
INFO - 2020-09-04 22:25:43 --> Hooks Class Initialized
DEBUG - 2020-09-04 22:25:43 --> UTF-8 Support Enabled
INFO - 2020-09-04 22:25:43 --> Utf8 Class Initialized
INFO - 2020-09-04 22:25:43 --> URI Class Initialized
INFO - 2020-09-04 22:25:43 --> Router Class Initialized
INFO - 2020-09-04 22:25:43 --> Output Class Initialized
INFO - 2020-09-04 22:25:43 --> Security Class Initialized
DEBUG - 2020-09-04 22:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 22:25:43 --> Input Class Initialized
INFO - 2020-09-04 22:25:43 --> Language Class Initialized
INFO - 2020-09-04 22:25:43 --> Language Class Initialized
INFO - 2020-09-04 22:25:43 --> Config Class Initialized
INFO - 2020-09-04 22:25:43 --> Loader Class Initialized
INFO - 2020-09-04 22:25:43 --> Helper loaded: url_helper
INFO - 2020-09-04 22:25:43 --> Helper loaded: form_helper
INFO - 2020-09-04 22:25:43 --> Helper loaded: file_helper
INFO - 2020-09-04 22:25:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 22:25:43 --> Database Driver Class Initialized
DEBUG - 2020-09-04 22:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 22:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 22:25:43 --> Upload Class Initialized
INFO - 2020-09-04 22:25:43 --> Controller Class Initialized
ERROR - 2020-09-04 22:25:43 --> 404 Page Not Found: /index
INFO - 2020-09-04 22:33:07 --> Config Class Initialized
INFO - 2020-09-04 22:33:07 --> Hooks Class Initialized
DEBUG - 2020-09-04 22:33:07 --> UTF-8 Support Enabled
INFO - 2020-09-04 22:33:07 --> Utf8 Class Initialized
INFO - 2020-09-04 22:33:07 --> URI Class Initialized
INFO - 2020-09-04 22:33:07 --> Router Class Initialized
INFO - 2020-09-04 22:33:07 --> Output Class Initialized
INFO - 2020-09-04 22:33:07 --> Security Class Initialized
DEBUG - 2020-09-04 22:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 22:33:07 --> Input Class Initialized
INFO - 2020-09-04 22:33:07 --> Language Class Initialized
INFO - 2020-09-04 22:33:07 --> Language Class Initialized
INFO - 2020-09-04 22:33:07 --> Config Class Initialized
INFO - 2020-09-04 22:33:07 --> Loader Class Initialized
INFO - 2020-09-04 22:33:07 --> Helper loaded: url_helper
INFO - 2020-09-04 22:33:07 --> Helper loaded: form_helper
INFO - 2020-09-04 22:33:07 --> Helper loaded: file_helper
INFO - 2020-09-04 22:33:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 22:33:07 --> Database Driver Class Initialized
DEBUG - 2020-09-04 22:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 22:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 22:33:07 --> Upload Class Initialized
INFO - 2020-09-04 22:33:07 --> Controller Class Initialized
ERROR - 2020-09-04 22:33:07 --> 404 Page Not Found: /index
INFO - 2020-09-04 23:43:04 --> Config Class Initialized
INFO - 2020-09-04 23:43:04 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:43:04 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:43:04 --> Utf8 Class Initialized
INFO - 2020-09-04 23:43:04 --> URI Class Initialized
DEBUG - 2020-09-04 23:43:04 --> No URI present. Default controller set.
INFO - 2020-09-04 23:43:04 --> Router Class Initialized
INFO - 2020-09-04 23:43:04 --> Output Class Initialized
INFO - 2020-09-04 23:43:04 --> Security Class Initialized
DEBUG - 2020-09-04 23:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:43:04 --> Input Class Initialized
INFO - 2020-09-04 23:43:04 --> Language Class Initialized
INFO - 2020-09-04 23:43:04 --> Language Class Initialized
INFO - 2020-09-04 23:43:04 --> Config Class Initialized
INFO - 2020-09-04 23:43:04 --> Loader Class Initialized
INFO - 2020-09-04 23:43:04 --> Helper loaded: url_helper
INFO - 2020-09-04 23:43:04 --> Helper loaded: form_helper
INFO - 2020-09-04 23:43:04 --> Helper loaded: file_helper
INFO - 2020-09-04 23:43:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:43:04 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:43:04 --> Upload Class Initialized
INFO - 2020-09-04 23:43:04 --> Controller Class Initialized
DEBUG - 2020-09-04 23:43:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 23:43:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 23:43:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 23:43:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 23:43:04 --> Final output sent to browser
DEBUG - 2020-09-04 23:43:04 --> Total execution time: 0.0614
INFO - 2020-09-04 23:43:13 --> Config Class Initialized
INFO - 2020-09-04 23:43:13 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:43:13 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:43:13 --> Utf8 Class Initialized
INFO - 2020-09-04 23:43:13 --> URI Class Initialized
INFO - 2020-09-04 23:43:13 --> Router Class Initialized
INFO - 2020-09-04 23:43:13 --> Output Class Initialized
INFO - 2020-09-04 23:43:13 --> Security Class Initialized
DEBUG - 2020-09-04 23:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:43:13 --> Input Class Initialized
INFO - 2020-09-04 23:43:13 --> Language Class Initialized
INFO - 2020-09-04 23:43:13 --> Language Class Initialized
INFO - 2020-09-04 23:43:13 --> Config Class Initialized
INFO - 2020-09-04 23:43:13 --> Loader Class Initialized
INFO - 2020-09-04 23:43:13 --> Helper loaded: url_helper
INFO - 2020-09-04 23:43:13 --> Helper loaded: form_helper
INFO - 2020-09-04 23:43:13 --> Helper loaded: file_helper
INFO - 2020-09-04 23:43:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:43:13 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:43:13 --> Upload Class Initialized
INFO - 2020-09-04 23:43:13 --> Controller Class Initialized
ERROR - 2020-09-04 23:43:13 --> 404 Page Not Found: /index
INFO - 2020-09-04 23:43:16 --> Config Class Initialized
INFO - 2020-09-04 23:43:16 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:43:16 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:43:16 --> Utf8 Class Initialized
INFO - 2020-09-04 23:43:16 --> URI Class Initialized
DEBUG - 2020-09-04 23:43:16 --> No URI present. Default controller set.
INFO - 2020-09-04 23:43:16 --> Router Class Initialized
INFO - 2020-09-04 23:43:16 --> Output Class Initialized
INFO - 2020-09-04 23:43:16 --> Security Class Initialized
DEBUG - 2020-09-04 23:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:43:16 --> Input Class Initialized
INFO - 2020-09-04 23:43:16 --> Language Class Initialized
INFO - 2020-09-04 23:43:16 --> Language Class Initialized
INFO - 2020-09-04 23:43:16 --> Config Class Initialized
INFO - 2020-09-04 23:43:16 --> Loader Class Initialized
INFO - 2020-09-04 23:43:16 --> Helper loaded: url_helper
INFO - 2020-09-04 23:43:16 --> Helper loaded: form_helper
INFO - 2020-09-04 23:43:16 --> Helper loaded: file_helper
INFO - 2020-09-04 23:43:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:43:16 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:43:16 --> Upload Class Initialized
INFO - 2020-09-04 23:43:16 --> Controller Class Initialized
DEBUG - 2020-09-04 23:43:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 23:43:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-04 23:43:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-04 23:43:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 23:43:16 --> Final output sent to browser
DEBUG - 2020-09-04 23:43:16 --> Total execution time: 0.0835
INFO - 2020-09-04 23:43:22 --> Config Class Initialized
INFO - 2020-09-04 23:43:22 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:43:22 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:43:22 --> Utf8 Class Initialized
INFO - 2020-09-04 23:43:22 --> URI Class Initialized
INFO - 2020-09-04 23:43:22 --> Router Class Initialized
INFO - 2020-09-04 23:43:22 --> Output Class Initialized
INFO - 2020-09-04 23:43:22 --> Security Class Initialized
DEBUG - 2020-09-04 23:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:43:22 --> Input Class Initialized
INFO - 2020-09-04 23:43:22 --> Language Class Initialized
INFO - 2020-09-04 23:43:22 --> Language Class Initialized
INFO - 2020-09-04 23:43:22 --> Config Class Initialized
INFO - 2020-09-04 23:43:22 --> Loader Class Initialized
INFO - 2020-09-04 23:43:22 --> Helper loaded: url_helper
INFO - 2020-09-04 23:43:22 --> Helper loaded: form_helper
INFO - 2020-09-04 23:43:22 --> Helper loaded: file_helper
INFO - 2020-09-04 23:43:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:43:22 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:43:22 --> Upload Class Initialized
INFO - 2020-09-04 23:43:22 --> Controller Class Initialized
ERROR - 2020-09-04 23:43:22 --> 404 Page Not Found: /index
INFO - 2020-09-04 23:44:13 --> Config Class Initialized
INFO - 2020-09-04 23:44:13 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:44:13 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:44:13 --> Utf8 Class Initialized
INFO - 2020-09-04 23:44:13 --> URI Class Initialized
INFO - 2020-09-04 23:44:13 --> Router Class Initialized
INFO - 2020-09-04 23:44:13 --> Output Class Initialized
INFO - 2020-09-04 23:44:13 --> Security Class Initialized
DEBUG - 2020-09-04 23:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:44:13 --> Input Class Initialized
INFO - 2020-09-04 23:44:13 --> Language Class Initialized
INFO - 2020-09-04 23:44:13 --> Language Class Initialized
INFO - 2020-09-04 23:44:13 --> Config Class Initialized
INFO - 2020-09-04 23:44:13 --> Loader Class Initialized
INFO - 2020-09-04 23:44:13 --> Helper loaded: url_helper
INFO - 2020-09-04 23:44:13 --> Helper loaded: form_helper
INFO - 2020-09-04 23:44:13 --> Helper loaded: file_helper
INFO - 2020-09-04 23:44:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:44:13 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:44:13 --> Upload Class Initialized
INFO - 2020-09-04 23:44:13 --> Controller Class Initialized
DEBUG - 2020-09-04 23:44:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 23:44:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-04 23:44:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 23:44:13 --> Final output sent to browser
DEBUG - 2020-09-04 23:44:13 --> Total execution time: 0.0537
INFO - 2020-09-04 23:44:14 --> Config Class Initialized
INFO - 2020-09-04 23:44:14 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:44:14 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:44:14 --> Utf8 Class Initialized
INFO - 2020-09-04 23:44:14 --> URI Class Initialized
INFO - 2020-09-04 23:44:14 --> Router Class Initialized
INFO - 2020-09-04 23:44:14 --> Output Class Initialized
INFO - 2020-09-04 23:44:14 --> Security Class Initialized
DEBUG - 2020-09-04 23:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:44:14 --> Input Class Initialized
INFO - 2020-09-04 23:44:14 --> Language Class Initialized
INFO - 2020-09-04 23:44:14 --> Language Class Initialized
INFO - 2020-09-04 23:44:14 --> Config Class Initialized
INFO - 2020-09-04 23:44:14 --> Loader Class Initialized
INFO - 2020-09-04 23:44:14 --> Helper loaded: url_helper
INFO - 2020-09-04 23:44:14 --> Helper loaded: form_helper
INFO - 2020-09-04 23:44:14 --> Helper loaded: file_helper
INFO - 2020-09-04 23:44:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:44:14 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:44:14 --> Upload Class Initialized
INFO - 2020-09-04 23:44:14 --> Controller Class Initialized
ERROR - 2020-09-04 23:44:14 --> 404 Page Not Found: /index
INFO - 2020-09-04 23:56:23 --> Config Class Initialized
INFO - 2020-09-04 23:56:23 --> Hooks Class Initialized
DEBUG - 2020-09-04 23:56:23 --> UTF-8 Support Enabled
INFO - 2020-09-04 23:56:23 --> Utf8 Class Initialized
INFO - 2020-09-04 23:56:23 --> URI Class Initialized
INFO - 2020-09-04 23:56:23 --> Router Class Initialized
INFO - 2020-09-04 23:56:23 --> Output Class Initialized
INFO - 2020-09-04 23:56:23 --> Security Class Initialized
DEBUG - 2020-09-04 23:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 23:56:23 --> Input Class Initialized
INFO - 2020-09-04 23:56:23 --> Language Class Initialized
INFO - 2020-09-04 23:56:23 --> Language Class Initialized
INFO - 2020-09-04 23:56:23 --> Config Class Initialized
INFO - 2020-09-04 23:56:23 --> Loader Class Initialized
INFO - 2020-09-04 23:56:23 --> Helper loaded: url_helper
INFO - 2020-09-04 23:56:23 --> Helper loaded: form_helper
INFO - 2020-09-04 23:56:23 --> Helper loaded: file_helper
INFO - 2020-09-04 23:56:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-04 23:56:23 --> Database Driver Class Initialized
DEBUG - 2020-09-04 23:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-04 23:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 23:56:23 --> Upload Class Initialized
INFO - 2020-09-04 23:56:24 --> Controller Class Initialized
DEBUG - 2020-09-04 23:56:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-04 23:56:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-04 23:56:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-04 23:56:24 --> Final output sent to browser
DEBUG - 2020-09-04 23:56:24 --> Total execution time: 0.0541
