<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-05 00:16:56 --> Config Class Initialized
INFO - 2020-09-05 00:16:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 00:16:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 00:16:56 --> Utf8 Class Initialized
INFO - 2020-09-05 00:16:56 --> URI Class Initialized
DEBUG - 2020-09-05 00:16:56 --> No URI present. Default controller set.
INFO - 2020-09-05 00:16:56 --> Router Class Initialized
INFO - 2020-09-05 00:16:56 --> Output Class Initialized
INFO - 2020-09-05 00:16:56 --> Security Class Initialized
DEBUG - 2020-09-05 00:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 00:16:56 --> Input Class Initialized
INFO - 2020-09-05 00:16:56 --> Language Class Initialized
INFO - 2020-09-05 00:16:56 --> Language Class Initialized
INFO - 2020-09-05 00:16:56 --> Config Class Initialized
INFO - 2020-09-05 00:16:56 --> Loader Class Initialized
INFO - 2020-09-05 00:16:56 --> Helper loaded: url_helper
INFO - 2020-09-05 00:16:56 --> Helper loaded: form_helper
INFO - 2020-09-05 00:16:56 --> Helper loaded: file_helper
INFO - 2020-09-05 00:16:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 00:16:56 --> Database Driver Class Initialized
DEBUG - 2020-09-05 00:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 00:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 00:16:56 --> Upload Class Initialized
INFO - 2020-09-05 00:16:56 --> Controller Class Initialized
DEBUG - 2020-09-05 00:16:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 00:16:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 00:16:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 00:16:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 00:16:56 --> Final output sent to browser
DEBUG - 2020-09-05 00:16:56 --> Total execution time: 0.0518
INFO - 2020-09-05 00:17:01 --> Config Class Initialized
INFO - 2020-09-05 00:17:01 --> Hooks Class Initialized
DEBUG - 2020-09-05 00:17:01 --> UTF-8 Support Enabled
INFO - 2020-09-05 00:17:01 --> Utf8 Class Initialized
INFO - 2020-09-05 00:17:01 --> URI Class Initialized
INFO - 2020-09-05 00:17:01 --> Router Class Initialized
INFO - 2020-09-05 00:17:01 --> Output Class Initialized
INFO - 2020-09-05 00:17:01 --> Security Class Initialized
DEBUG - 2020-09-05 00:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 00:17:01 --> Input Class Initialized
INFO - 2020-09-05 00:17:01 --> Language Class Initialized
INFO - 2020-09-05 00:17:01 --> Language Class Initialized
INFO - 2020-09-05 00:17:01 --> Config Class Initialized
INFO - 2020-09-05 00:17:01 --> Loader Class Initialized
INFO - 2020-09-05 00:17:01 --> Helper loaded: url_helper
INFO - 2020-09-05 00:17:01 --> Helper loaded: form_helper
INFO - 2020-09-05 00:17:01 --> Helper loaded: file_helper
INFO - 2020-09-05 00:17:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 00:17:01 --> Database Driver Class Initialized
DEBUG - 2020-09-05 00:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 00:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 00:17:01 --> Upload Class Initialized
INFO - 2020-09-05 00:17:01 --> Controller Class Initialized
ERROR - 2020-09-05 00:17:01 --> 404 Page Not Found: /index
INFO - 2020-09-05 01:20:41 --> Config Class Initialized
INFO - 2020-09-05 01:20:41 --> Hooks Class Initialized
DEBUG - 2020-09-05 01:20:41 --> UTF-8 Support Enabled
INFO - 2020-09-05 01:20:41 --> Utf8 Class Initialized
INFO - 2020-09-05 01:20:41 --> URI Class Initialized
INFO - 2020-09-05 01:20:41 --> Router Class Initialized
INFO - 2020-09-05 01:20:42 --> Output Class Initialized
INFO - 2020-09-05 01:20:42 --> Security Class Initialized
DEBUG - 2020-09-05 01:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 01:20:42 --> Input Class Initialized
INFO - 2020-09-05 01:20:42 --> Language Class Initialized
INFO - 2020-09-05 01:20:42 --> Language Class Initialized
INFO - 2020-09-05 01:20:42 --> Config Class Initialized
INFO - 2020-09-05 01:20:42 --> Loader Class Initialized
INFO - 2020-09-05 01:20:42 --> Helper loaded: url_helper
INFO - 2020-09-05 01:20:42 --> Helper loaded: form_helper
INFO - 2020-09-05 01:20:42 --> Helper loaded: file_helper
INFO - 2020-09-05 01:20:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 01:20:42 --> Database Driver Class Initialized
DEBUG - 2020-09-05 01:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 01:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 01:20:42 --> Upload Class Initialized
INFO - 2020-09-05 01:20:42 --> Controller Class Initialized
ERROR - 2020-09-05 01:20:42 --> 404 Page Not Found: /index
INFO - 2020-09-05 02:39:48 --> Config Class Initialized
INFO - 2020-09-05 02:39:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 02:39:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 02:39:48 --> Utf8 Class Initialized
INFO - 2020-09-05 02:39:48 --> URI Class Initialized
DEBUG - 2020-09-05 02:39:48 --> No URI present. Default controller set.
INFO - 2020-09-05 02:39:48 --> Router Class Initialized
INFO - 2020-09-05 02:39:48 --> Output Class Initialized
INFO - 2020-09-05 02:39:48 --> Security Class Initialized
DEBUG - 2020-09-05 02:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 02:39:48 --> Input Class Initialized
INFO - 2020-09-05 02:39:48 --> Language Class Initialized
INFO - 2020-09-05 02:39:48 --> Language Class Initialized
INFO - 2020-09-05 02:39:48 --> Config Class Initialized
INFO - 2020-09-05 02:39:48 --> Loader Class Initialized
INFO - 2020-09-05 02:39:48 --> Helper loaded: url_helper
INFO - 2020-09-05 02:39:48 --> Helper loaded: form_helper
INFO - 2020-09-05 02:39:48 --> Helper loaded: file_helper
INFO - 2020-09-05 02:39:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 02:39:48 --> Database Driver Class Initialized
DEBUG - 2020-09-05 02:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 02:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 02:39:48 --> Upload Class Initialized
INFO - 2020-09-05 02:39:48 --> Controller Class Initialized
DEBUG - 2020-09-05 02:39:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 02:39:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 02:39:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 02:39:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 02:39:48 --> Final output sent to browser
DEBUG - 2020-09-05 02:39:48 --> Total execution time: 0.0522
INFO - 2020-09-05 03:21:54 --> Config Class Initialized
INFO - 2020-09-05 03:21:54 --> Hooks Class Initialized
DEBUG - 2020-09-05 03:21:54 --> UTF-8 Support Enabled
INFO - 2020-09-05 03:21:54 --> Utf8 Class Initialized
INFO - 2020-09-05 03:21:54 --> URI Class Initialized
INFO - 2020-09-05 03:21:54 --> Router Class Initialized
INFO - 2020-09-05 03:21:54 --> Output Class Initialized
INFO - 2020-09-05 03:21:54 --> Security Class Initialized
DEBUG - 2020-09-05 03:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 03:21:54 --> Input Class Initialized
INFO - 2020-09-05 03:21:54 --> Language Class Initialized
INFO - 2020-09-05 03:21:54 --> Language Class Initialized
INFO - 2020-09-05 03:21:54 --> Config Class Initialized
INFO - 2020-09-05 03:21:54 --> Loader Class Initialized
INFO - 2020-09-05 03:21:54 --> Helper loaded: url_helper
INFO - 2020-09-05 03:21:54 --> Helper loaded: form_helper
INFO - 2020-09-05 03:21:54 --> Helper loaded: file_helper
INFO - 2020-09-05 03:21:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 03:21:54 --> Database Driver Class Initialized
DEBUG - 2020-09-05 03:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 03:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 03:21:54 --> Upload Class Initialized
INFO - 2020-09-05 03:21:54 --> Controller Class Initialized
ERROR - 2020-09-05 03:21:54 --> 404 Page Not Found: /index
INFO - 2020-09-05 03:27:06 --> Config Class Initialized
INFO - 2020-09-05 03:27:06 --> Hooks Class Initialized
DEBUG - 2020-09-05 03:27:06 --> UTF-8 Support Enabled
INFO - 2020-09-05 03:27:06 --> Utf8 Class Initialized
INFO - 2020-09-05 03:27:06 --> URI Class Initialized
INFO - 2020-09-05 03:27:06 --> Router Class Initialized
INFO - 2020-09-05 03:27:06 --> Output Class Initialized
INFO - 2020-09-05 03:27:06 --> Security Class Initialized
DEBUG - 2020-09-05 03:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 03:27:06 --> Input Class Initialized
INFO - 2020-09-05 03:27:06 --> Language Class Initialized
INFO - 2020-09-05 03:27:06 --> Language Class Initialized
INFO - 2020-09-05 03:27:06 --> Config Class Initialized
INFO - 2020-09-05 03:27:06 --> Loader Class Initialized
INFO - 2020-09-05 03:27:06 --> Helper loaded: url_helper
INFO - 2020-09-05 03:27:06 --> Helper loaded: form_helper
INFO - 2020-09-05 03:27:06 --> Helper loaded: file_helper
INFO - 2020-09-05 03:27:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 03:27:06 --> Database Driver Class Initialized
DEBUG - 2020-09-05 03:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 03:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 03:27:06 --> Upload Class Initialized
INFO - 2020-09-05 03:27:06 --> Controller Class Initialized
ERROR - 2020-09-05 03:27:06 --> 404 Page Not Found: /index
INFO - 2020-09-05 05:08:48 --> Config Class Initialized
INFO - 2020-09-05 05:08:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 05:08:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 05:08:48 --> Utf8 Class Initialized
INFO - 2020-09-05 05:08:48 --> URI Class Initialized
DEBUG - 2020-09-05 05:08:48 --> No URI present. Default controller set.
INFO - 2020-09-05 05:08:48 --> Router Class Initialized
INFO - 2020-09-05 05:08:48 --> Output Class Initialized
INFO - 2020-09-05 05:08:48 --> Security Class Initialized
DEBUG - 2020-09-05 05:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 05:08:48 --> Input Class Initialized
INFO - 2020-09-05 05:08:48 --> Language Class Initialized
INFO - 2020-09-05 05:08:48 --> Language Class Initialized
INFO - 2020-09-05 05:08:48 --> Config Class Initialized
INFO - 2020-09-05 05:08:48 --> Loader Class Initialized
INFO - 2020-09-05 05:08:48 --> Helper loaded: url_helper
INFO - 2020-09-05 05:08:48 --> Helper loaded: form_helper
INFO - 2020-09-05 05:08:48 --> Helper loaded: file_helper
INFO - 2020-09-05 05:08:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 05:08:48 --> Database Driver Class Initialized
DEBUG - 2020-09-05 05:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 05:08:48 --> Upload Class Initialized
INFO - 2020-09-05 05:08:48 --> Controller Class Initialized
DEBUG - 2020-09-05 05:08:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 05:08:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 05:08:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 05:08:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 05:08:48 --> Final output sent to browser
DEBUG - 2020-09-05 05:08:48 --> Total execution time: 0.0511
INFO - 2020-09-05 05:29:51 --> Config Class Initialized
INFO - 2020-09-05 05:29:51 --> Hooks Class Initialized
DEBUG - 2020-09-05 05:29:51 --> UTF-8 Support Enabled
INFO - 2020-09-05 05:29:51 --> Utf8 Class Initialized
INFO - 2020-09-05 05:29:51 --> URI Class Initialized
INFO - 2020-09-05 05:29:51 --> Router Class Initialized
INFO - 2020-09-05 05:29:51 --> Output Class Initialized
INFO - 2020-09-05 05:29:51 --> Security Class Initialized
DEBUG - 2020-09-05 05:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 05:29:51 --> Input Class Initialized
INFO - 2020-09-05 05:29:51 --> Language Class Initialized
INFO - 2020-09-05 05:29:51 --> Language Class Initialized
INFO - 2020-09-05 05:29:51 --> Config Class Initialized
INFO - 2020-09-05 05:29:51 --> Loader Class Initialized
INFO - 2020-09-05 05:29:51 --> Helper loaded: url_helper
INFO - 2020-09-05 05:29:51 --> Helper loaded: form_helper
INFO - 2020-09-05 05:29:51 --> Helper loaded: file_helper
INFO - 2020-09-05 05:29:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 05:29:51 --> Database Driver Class Initialized
DEBUG - 2020-09-05 05:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 05:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 05:29:51 --> Upload Class Initialized
INFO - 2020-09-05 05:29:51 --> Controller Class Initialized
ERROR - 2020-09-05 05:29:51 --> 404 Page Not Found: /index
INFO - 2020-09-05 05:29:52 --> Config Class Initialized
INFO - 2020-09-05 05:29:52 --> Hooks Class Initialized
DEBUG - 2020-09-05 05:29:52 --> UTF-8 Support Enabled
INFO - 2020-09-05 05:29:52 --> Utf8 Class Initialized
INFO - 2020-09-05 05:29:52 --> URI Class Initialized
INFO - 2020-09-05 05:29:52 --> Router Class Initialized
INFO - 2020-09-05 05:29:52 --> Output Class Initialized
INFO - 2020-09-05 05:29:52 --> Security Class Initialized
DEBUG - 2020-09-05 05:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 05:29:52 --> Input Class Initialized
INFO - 2020-09-05 05:29:52 --> Language Class Initialized
INFO - 2020-09-05 05:29:52 --> Language Class Initialized
INFO - 2020-09-05 05:29:52 --> Config Class Initialized
INFO - 2020-09-05 05:29:52 --> Loader Class Initialized
INFO - 2020-09-05 05:29:52 --> Helper loaded: url_helper
INFO - 2020-09-05 05:29:52 --> Helper loaded: form_helper
INFO - 2020-09-05 05:29:52 --> Helper loaded: file_helper
INFO - 2020-09-05 05:29:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 05:29:52 --> Database Driver Class Initialized
DEBUG - 2020-09-05 05:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 05:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 05:29:52 --> Upload Class Initialized
INFO - 2020-09-05 05:29:52 --> Controller Class Initialized
ERROR - 2020-09-05 05:29:52 --> 404 Page Not Found: /index
INFO - 2020-09-05 05:29:54 --> Config Class Initialized
INFO - 2020-09-05 05:29:54 --> Hooks Class Initialized
DEBUG - 2020-09-05 05:29:54 --> UTF-8 Support Enabled
INFO - 2020-09-05 05:29:54 --> Utf8 Class Initialized
INFO - 2020-09-05 05:29:54 --> URI Class Initialized
DEBUG - 2020-09-05 05:29:54 --> No URI present. Default controller set.
INFO - 2020-09-05 05:29:54 --> Router Class Initialized
INFO - 2020-09-05 05:29:54 --> Output Class Initialized
INFO - 2020-09-05 05:29:54 --> Security Class Initialized
DEBUG - 2020-09-05 05:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 05:29:54 --> Input Class Initialized
INFO - 2020-09-05 05:29:54 --> Language Class Initialized
INFO - 2020-09-05 05:29:54 --> Language Class Initialized
INFO - 2020-09-05 05:29:54 --> Config Class Initialized
INFO - 2020-09-05 05:29:54 --> Loader Class Initialized
INFO - 2020-09-05 05:29:54 --> Helper loaded: url_helper
INFO - 2020-09-05 05:29:54 --> Helper loaded: form_helper
INFO - 2020-09-05 05:29:54 --> Helper loaded: file_helper
INFO - 2020-09-05 05:29:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 05:29:54 --> Database Driver Class Initialized
DEBUG - 2020-09-05 05:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 05:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 05:29:54 --> Upload Class Initialized
INFO - 2020-09-05 05:29:54 --> Controller Class Initialized
DEBUG - 2020-09-05 05:29:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 05:29:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 05:29:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 05:29:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 05:29:54 --> Final output sent to browser
DEBUG - 2020-09-05 05:29:54 --> Total execution time: 0.0493
INFO - 2020-09-05 05:29:56 --> Config Class Initialized
INFO - 2020-09-05 05:29:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 05:29:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 05:29:56 --> Utf8 Class Initialized
INFO - 2020-09-05 05:29:56 --> URI Class Initialized
DEBUG - 2020-09-05 05:29:56 --> No URI present. Default controller set.
INFO - 2020-09-05 05:29:56 --> Router Class Initialized
INFO - 2020-09-05 05:29:56 --> Output Class Initialized
INFO - 2020-09-05 05:29:56 --> Security Class Initialized
DEBUG - 2020-09-05 05:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 05:29:56 --> Input Class Initialized
INFO - 2020-09-05 05:29:56 --> Language Class Initialized
INFO - 2020-09-05 05:29:56 --> Language Class Initialized
INFO - 2020-09-05 05:29:56 --> Config Class Initialized
INFO - 2020-09-05 05:29:56 --> Loader Class Initialized
INFO - 2020-09-05 05:29:56 --> Helper loaded: url_helper
INFO - 2020-09-05 05:29:56 --> Helper loaded: form_helper
INFO - 2020-09-05 05:29:56 --> Helper loaded: file_helper
INFO - 2020-09-05 05:29:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 05:29:56 --> Database Driver Class Initialized
DEBUG - 2020-09-05 05:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 05:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 05:29:56 --> Upload Class Initialized
INFO - 2020-09-05 05:29:56 --> Controller Class Initialized
DEBUG - 2020-09-05 05:29:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 05:29:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 05:29:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 05:29:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 05:29:56 --> Final output sent to browser
DEBUG - 2020-09-05 05:29:56 --> Total execution time: 0.0510
INFO - 2020-09-05 06:10:34 --> Config Class Initialized
INFO - 2020-09-05 06:10:34 --> Hooks Class Initialized
DEBUG - 2020-09-05 06:10:34 --> UTF-8 Support Enabled
INFO - 2020-09-05 06:10:34 --> Utf8 Class Initialized
INFO - 2020-09-05 06:10:34 --> URI Class Initialized
DEBUG - 2020-09-05 06:10:34 --> No URI present. Default controller set.
INFO - 2020-09-05 06:10:34 --> Router Class Initialized
INFO - 2020-09-05 06:10:34 --> Output Class Initialized
INFO - 2020-09-05 06:10:34 --> Security Class Initialized
DEBUG - 2020-09-05 06:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 06:10:34 --> Input Class Initialized
INFO - 2020-09-05 06:10:34 --> Language Class Initialized
INFO - 2020-09-05 06:10:34 --> Language Class Initialized
INFO - 2020-09-05 06:10:34 --> Config Class Initialized
INFO - 2020-09-05 06:10:34 --> Loader Class Initialized
INFO - 2020-09-05 06:10:34 --> Helper loaded: url_helper
INFO - 2020-09-05 06:10:34 --> Helper loaded: form_helper
INFO - 2020-09-05 06:10:34 --> Helper loaded: file_helper
INFO - 2020-09-05 06:10:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 06:10:34 --> Database Driver Class Initialized
DEBUG - 2020-09-05 06:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 06:10:34 --> Upload Class Initialized
INFO - 2020-09-05 06:10:34 --> Controller Class Initialized
DEBUG - 2020-09-05 06:10:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 06:10:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 06:10:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 06:10:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 06:10:34 --> Final output sent to browser
DEBUG - 2020-09-05 06:10:34 --> Total execution time: 0.0530
INFO - 2020-09-05 06:19:08 --> Config Class Initialized
INFO - 2020-09-05 06:19:08 --> Hooks Class Initialized
DEBUG - 2020-09-05 06:19:08 --> UTF-8 Support Enabled
INFO - 2020-09-05 06:19:08 --> Utf8 Class Initialized
INFO - 2020-09-05 06:19:08 --> URI Class Initialized
INFO - 2020-09-05 06:19:08 --> Router Class Initialized
INFO - 2020-09-05 06:19:08 --> Output Class Initialized
INFO - 2020-09-05 06:19:08 --> Security Class Initialized
DEBUG - 2020-09-05 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 06:19:08 --> Input Class Initialized
INFO - 2020-09-05 06:19:08 --> Language Class Initialized
INFO - 2020-09-05 06:19:08 --> Language Class Initialized
INFO - 2020-09-05 06:19:08 --> Config Class Initialized
INFO - 2020-09-05 06:19:08 --> Loader Class Initialized
INFO - 2020-09-05 06:19:08 --> Helper loaded: url_helper
INFO - 2020-09-05 06:19:08 --> Helper loaded: form_helper
INFO - 2020-09-05 06:19:08 --> Helper loaded: file_helper
INFO - 2020-09-05 06:19:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 06:19:08 --> Database Driver Class Initialized
DEBUG - 2020-09-05 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 06:19:08 --> Upload Class Initialized
INFO - 2020-09-05 06:19:08 --> Controller Class Initialized
ERROR - 2020-09-05 06:19:08 --> 404 Page Not Found: /index
INFO - 2020-09-05 06:19:08 --> Config Class Initialized
INFO - 2020-09-05 06:19:08 --> Hooks Class Initialized
DEBUG - 2020-09-05 06:19:08 --> UTF-8 Support Enabled
INFO - 2020-09-05 06:19:08 --> Utf8 Class Initialized
INFO - 2020-09-05 06:19:08 --> URI Class Initialized
INFO - 2020-09-05 06:19:08 --> Router Class Initialized
INFO - 2020-09-05 06:19:08 --> Output Class Initialized
INFO - 2020-09-05 06:19:08 --> Security Class Initialized
DEBUG - 2020-09-05 06:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 06:19:08 --> Input Class Initialized
INFO - 2020-09-05 06:19:08 --> Language Class Initialized
INFO - 2020-09-05 06:19:08 --> Language Class Initialized
INFO - 2020-09-05 06:19:08 --> Config Class Initialized
INFO - 2020-09-05 06:19:08 --> Loader Class Initialized
INFO - 2020-09-05 06:19:08 --> Helper loaded: url_helper
INFO - 2020-09-05 06:19:08 --> Helper loaded: form_helper
INFO - 2020-09-05 06:19:08 --> Helper loaded: file_helper
INFO - 2020-09-05 06:19:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 06:19:08 --> Database Driver Class Initialized
DEBUG - 2020-09-05 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 06:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 06:19:08 --> Upload Class Initialized
INFO - 2020-09-05 06:19:08 --> Controller Class Initialized
DEBUG - 2020-09-05 06:19:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 06:19:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-05 06:19:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 06:19:08 --> Final output sent to browser
DEBUG - 2020-09-05 06:19:08 --> Total execution time: 0.0589
INFO - 2020-09-05 06:21:17 --> Config Class Initialized
INFO - 2020-09-05 06:21:17 --> Hooks Class Initialized
DEBUG - 2020-09-05 06:21:17 --> UTF-8 Support Enabled
INFO - 2020-09-05 06:21:17 --> Utf8 Class Initialized
INFO - 2020-09-05 06:21:17 --> URI Class Initialized
DEBUG - 2020-09-05 06:21:17 --> No URI present. Default controller set.
INFO - 2020-09-05 06:21:17 --> Router Class Initialized
INFO - 2020-09-05 06:21:17 --> Output Class Initialized
INFO - 2020-09-05 06:21:17 --> Security Class Initialized
DEBUG - 2020-09-05 06:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 06:21:17 --> Input Class Initialized
INFO - 2020-09-05 06:21:17 --> Language Class Initialized
INFO - 2020-09-05 06:21:17 --> Language Class Initialized
INFO - 2020-09-05 06:21:17 --> Config Class Initialized
INFO - 2020-09-05 06:21:17 --> Loader Class Initialized
INFO - 2020-09-05 06:21:17 --> Helper loaded: url_helper
INFO - 2020-09-05 06:21:17 --> Helper loaded: form_helper
INFO - 2020-09-05 06:21:17 --> Helper loaded: file_helper
INFO - 2020-09-05 06:21:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 06:21:17 --> Database Driver Class Initialized
DEBUG - 2020-09-05 06:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 06:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 06:21:17 --> Upload Class Initialized
INFO - 2020-09-05 06:21:17 --> Controller Class Initialized
DEBUG - 2020-09-05 06:21:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 06:21:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 06:21:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 06:21:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 06:21:17 --> Final output sent to browser
DEBUG - 2020-09-05 06:21:17 --> Total execution time: 0.0520
INFO - 2020-09-05 06:21:27 --> Config Class Initialized
INFO - 2020-09-05 06:21:27 --> Hooks Class Initialized
DEBUG - 2020-09-05 06:21:27 --> UTF-8 Support Enabled
INFO - 2020-09-05 06:21:27 --> Utf8 Class Initialized
INFO - 2020-09-05 06:21:27 --> URI Class Initialized
DEBUG - 2020-09-05 06:21:27 --> No URI present. Default controller set.
INFO - 2020-09-05 06:21:27 --> Router Class Initialized
INFO - 2020-09-05 06:21:27 --> Output Class Initialized
INFO - 2020-09-05 06:21:27 --> Security Class Initialized
DEBUG - 2020-09-05 06:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 06:21:27 --> Input Class Initialized
INFO - 2020-09-05 06:21:27 --> Language Class Initialized
INFO - 2020-09-05 06:21:27 --> Language Class Initialized
INFO - 2020-09-05 06:21:27 --> Config Class Initialized
INFO - 2020-09-05 06:21:27 --> Loader Class Initialized
INFO - 2020-09-05 06:21:27 --> Helper loaded: url_helper
INFO - 2020-09-05 06:21:27 --> Helper loaded: form_helper
INFO - 2020-09-05 06:21:27 --> Helper loaded: file_helper
INFO - 2020-09-05 06:21:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 06:21:27 --> Database Driver Class Initialized
DEBUG - 2020-09-05 06:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 06:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 06:21:27 --> Upload Class Initialized
INFO - 2020-09-05 06:21:27 --> Controller Class Initialized
DEBUG - 2020-09-05 06:21:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 06:21:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 06:21:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 06:21:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 06:21:27 --> Final output sent to browser
DEBUG - 2020-09-05 06:21:27 --> Total execution time: 0.0488
INFO - 2020-09-05 07:09:11 --> Config Class Initialized
INFO - 2020-09-05 07:09:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 07:09:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 07:09:11 --> Utf8 Class Initialized
INFO - 2020-09-05 07:09:11 --> URI Class Initialized
INFO - 2020-09-05 07:09:11 --> Router Class Initialized
INFO - 2020-09-05 07:09:11 --> Output Class Initialized
INFO - 2020-09-05 07:09:11 --> Security Class Initialized
DEBUG - 2020-09-05 07:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 07:09:11 --> Input Class Initialized
INFO - 2020-09-05 07:09:11 --> Language Class Initialized
INFO - 2020-09-05 07:09:11 --> Language Class Initialized
INFO - 2020-09-05 07:09:11 --> Config Class Initialized
INFO - 2020-09-05 07:09:11 --> Loader Class Initialized
INFO - 2020-09-05 07:09:11 --> Helper loaded: url_helper
INFO - 2020-09-05 07:09:11 --> Helper loaded: form_helper
INFO - 2020-09-05 07:09:11 --> Helper loaded: file_helper
INFO - 2020-09-05 07:09:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 07:09:11 --> Database Driver Class Initialized
DEBUG - 2020-09-05 07:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 07:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 07:09:11 --> Upload Class Initialized
INFO - 2020-09-05 07:09:12 --> Controller Class Initialized
ERROR - 2020-09-05 07:09:12 --> 404 Page Not Found: /index
INFO - 2020-09-05 08:33:28 --> Config Class Initialized
INFO - 2020-09-05 08:33:28 --> Hooks Class Initialized
DEBUG - 2020-09-05 08:33:28 --> UTF-8 Support Enabled
INFO - 2020-09-05 08:33:28 --> Utf8 Class Initialized
INFO - 2020-09-05 08:33:28 --> URI Class Initialized
DEBUG - 2020-09-05 08:33:28 --> No URI present. Default controller set.
INFO - 2020-09-05 08:33:28 --> Router Class Initialized
INFO - 2020-09-05 08:33:28 --> Output Class Initialized
INFO - 2020-09-05 08:33:28 --> Security Class Initialized
DEBUG - 2020-09-05 08:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 08:33:28 --> Input Class Initialized
INFO - 2020-09-05 08:33:28 --> Language Class Initialized
INFO - 2020-09-05 08:33:28 --> Language Class Initialized
INFO - 2020-09-05 08:33:28 --> Config Class Initialized
INFO - 2020-09-05 08:33:28 --> Loader Class Initialized
INFO - 2020-09-05 08:33:28 --> Helper loaded: url_helper
INFO - 2020-09-05 08:33:28 --> Helper loaded: form_helper
INFO - 2020-09-05 08:33:28 --> Helper loaded: file_helper
INFO - 2020-09-05 08:33:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 08:33:28 --> Database Driver Class Initialized
DEBUG - 2020-09-05 08:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 08:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 08:33:28 --> Upload Class Initialized
INFO - 2020-09-05 08:33:28 --> Controller Class Initialized
DEBUG - 2020-09-05 08:33:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 08:33:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 08:33:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 08:33:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 08:33:28 --> Final output sent to browser
DEBUG - 2020-09-05 08:33:28 --> Total execution time: 0.0508
INFO - 2020-09-05 09:29:14 --> Config Class Initialized
INFO - 2020-09-05 09:29:14 --> Hooks Class Initialized
DEBUG - 2020-09-05 09:29:14 --> UTF-8 Support Enabled
INFO - 2020-09-05 09:29:14 --> Utf8 Class Initialized
INFO - 2020-09-05 09:29:14 --> URI Class Initialized
DEBUG - 2020-09-05 09:29:14 --> No URI present. Default controller set.
INFO - 2020-09-05 09:29:14 --> Router Class Initialized
INFO - 2020-09-05 09:29:14 --> Output Class Initialized
INFO - 2020-09-05 09:29:14 --> Security Class Initialized
DEBUG - 2020-09-05 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 09:29:14 --> Input Class Initialized
INFO - 2020-09-05 09:29:14 --> Language Class Initialized
INFO - 2020-09-05 09:29:14 --> Language Class Initialized
INFO - 2020-09-05 09:29:14 --> Config Class Initialized
INFO - 2020-09-05 09:29:14 --> Loader Class Initialized
INFO - 2020-09-05 09:29:14 --> Helper loaded: url_helper
INFO - 2020-09-05 09:29:14 --> Helper loaded: form_helper
INFO - 2020-09-05 09:29:14 --> Helper loaded: file_helper
INFO - 2020-09-05 09:29:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 09:29:14 --> Database Driver Class Initialized
DEBUG - 2020-09-05 09:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 09:29:14 --> Upload Class Initialized
INFO - 2020-09-05 09:29:14 --> Controller Class Initialized
DEBUG - 2020-09-05 09:29:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 09:29:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 09:29:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 09:29:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 09:29:14 --> Final output sent to browser
DEBUG - 2020-09-05 09:29:14 --> Total execution time: 0.1331
INFO - 2020-09-05 09:36:55 --> Config Class Initialized
INFO - 2020-09-05 09:36:55 --> Hooks Class Initialized
DEBUG - 2020-09-05 09:36:55 --> UTF-8 Support Enabled
INFO - 2020-09-05 09:36:55 --> Utf8 Class Initialized
INFO - 2020-09-05 09:36:55 --> URI Class Initialized
INFO - 2020-09-05 09:36:55 --> Router Class Initialized
INFO - 2020-09-05 09:36:55 --> Output Class Initialized
INFO - 2020-09-05 09:36:55 --> Security Class Initialized
DEBUG - 2020-09-05 09:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 09:36:55 --> Input Class Initialized
INFO - 2020-09-05 09:36:55 --> Language Class Initialized
INFO - 2020-09-05 09:36:55 --> Language Class Initialized
INFO - 2020-09-05 09:36:55 --> Config Class Initialized
INFO - 2020-09-05 09:36:55 --> Loader Class Initialized
INFO - 2020-09-05 09:36:55 --> Helper loaded: url_helper
INFO - 2020-09-05 09:36:55 --> Helper loaded: form_helper
INFO - 2020-09-05 09:36:55 --> Helper loaded: file_helper
INFO - 2020-09-05 09:36:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 09:36:55 --> Database Driver Class Initialized
DEBUG - 2020-09-05 09:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 09:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 09:36:55 --> Upload Class Initialized
INFO - 2020-09-05 09:36:55 --> Controller Class Initialized
ERROR - 2020-09-05 09:36:55 --> 404 Page Not Found: /index
INFO - 2020-09-05 09:46:51 --> Config Class Initialized
INFO - 2020-09-05 09:46:51 --> Hooks Class Initialized
DEBUG - 2020-09-05 09:46:51 --> UTF-8 Support Enabled
INFO - 2020-09-05 09:46:51 --> Utf8 Class Initialized
INFO - 2020-09-05 09:46:51 --> URI Class Initialized
INFO - 2020-09-05 09:46:51 --> Router Class Initialized
INFO - 2020-09-05 09:46:51 --> Output Class Initialized
INFO - 2020-09-05 09:46:51 --> Security Class Initialized
DEBUG - 2020-09-05 09:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 09:46:51 --> Input Class Initialized
INFO - 2020-09-05 09:46:51 --> Language Class Initialized
INFO - 2020-09-05 09:46:51 --> Language Class Initialized
INFO - 2020-09-05 09:46:51 --> Config Class Initialized
INFO - 2020-09-05 09:46:51 --> Loader Class Initialized
INFO - 2020-09-05 09:46:51 --> Helper loaded: url_helper
INFO - 2020-09-05 09:46:51 --> Helper loaded: form_helper
INFO - 2020-09-05 09:46:51 --> Helper loaded: file_helper
INFO - 2020-09-05 09:46:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 09:46:51 --> Database Driver Class Initialized
DEBUG - 2020-09-05 09:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 09:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 09:46:51 --> Upload Class Initialized
INFO - 2020-09-05 09:46:51 --> Controller Class Initialized
ERROR - 2020-09-05 09:46:51 --> 404 Page Not Found: /index
INFO - 2020-09-05 09:46:51 --> Config Class Initialized
INFO - 2020-09-05 09:46:51 --> Hooks Class Initialized
DEBUG - 2020-09-05 09:46:51 --> UTF-8 Support Enabled
INFO - 2020-09-05 09:46:51 --> Utf8 Class Initialized
INFO - 2020-09-05 09:46:51 --> URI Class Initialized
INFO - 2020-09-05 09:46:51 --> Router Class Initialized
INFO - 2020-09-05 09:46:51 --> Output Class Initialized
INFO - 2020-09-05 09:46:51 --> Security Class Initialized
DEBUG - 2020-09-05 09:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 09:46:51 --> Input Class Initialized
INFO - 2020-09-05 09:46:51 --> Language Class Initialized
INFO - 2020-09-05 09:46:51 --> Language Class Initialized
INFO - 2020-09-05 09:46:51 --> Config Class Initialized
INFO - 2020-09-05 09:46:51 --> Loader Class Initialized
INFO - 2020-09-05 09:46:51 --> Helper loaded: url_helper
INFO - 2020-09-05 09:46:51 --> Helper loaded: form_helper
INFO - 2020-09-05 09:46:51 --> Helper loaded: file_helper
INFO - 2020-09-05 09:46:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 09:46:51 --> Database Driver Class Initialized
DEBUG - 2020-09-05 09:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 09:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 09:46:51 --> Upload Class Initialized
INFO - 2020-09-05 09:46:51 --> Controller Class Initialized
ERROR - 2020-09-05 09:46:51 --> 404 Page Not Found: /index
INFO - 2020-09-05 09:46:52 --> Config Class Initialized
INFO - 2020-09-05 09:46:52 --> Hooks Class Initialized
DEBUG - 2020-09-05 09:46:52 --> UTF-8 Support Enabled
INFO - 2020-09-05 09:46:52 --> Utf8 Class Initialized
INFO - 2020-09-05 09:46:52 --> URI Class Initialized
INFO - 2020-09-05 09:46:52 --> Router Class Initialized
INFO - 2020-09-05 09:46:52 --> Output Class Initialized
INFO - 2020-09-05 09:46:52 --> Security Class Initialized
DEBUG - 2020-09-05 09:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 09:46:52 --> Input Class Initialized
INFO - 2020-09-05 09:46:52 --> Language Class Initialized
INFO - 2020-09-05 09:46:52 --> Language Class Initialized
INFO - 2020-09-05 09:46:52 --> Config Class Initialized
INFO - 2020-09-05 09:46:52 --> Loader Class Initialized
INFO - 2020-09-05 09:46:52 --> Helper loaded: url_helper
INFO - 2020-09-05 09:46:52 --> Helper loaded: form_helper
INFO - 2020-09-05 09:46:52 --> Helper loaded: file_helper
INFO - 2020-09-05 09:46:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 09:46:52 --> Database Driver Class Initialized
DEBUG - 2020-09-05 09:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 09:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 09:46:52 --> Upload Class Initialized
INFO - 2020-09-05 09:46:52 --> Controller Class Initialized
DEBUG - 2020-09-05 09:46:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 09:46:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 09:46:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 09:46:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 09:46:52 --> Final output sent to browser
DEBUG - 2020-09-05 09:46:52 --> Total execution time: 0.0504
INFO - 2020-09-05 09:56:41 --> Config Class Initialized
INFO - 2020-09-05 09:56:41 --> Hooks Class Initialized
DEBUG - 2020-09-05 09:56:41 --> UTF-8 Support Enabled
INFO - 2020-09-05 09:56:41 --> Utf8 Class Initialized
INFO - 2020-09-05 09:56:41 --> URI Class Initialized
DEBUG - 2020-09-05 09:56:41 --> No URI present. Default controller set.
INFO - 2020-09-05 09:56:41 --> Router Class Initialized
INFO - 2020-09-05 09:56:41 --> Output Class Initialized
INFO - 2020-09-05 09:56:41 --> Security Class Initialized
DEBUG - 2020-09-05 09:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 09:56:41 --> Input Class Initialized
INFO - 2020-09-05 09:56:41 --> Language Class Initialized
INFO - 2020-09-05 09:56:41 --> Language Class Initialized
INFO - 2020-09-05 09:56:41 --> Config Class Initialized
INFO - 2020-09-05 09:56:41 --> Loader Class Initialized
INFO - 2020-09-05 09:56:41 --> Helper loaded: url_helper
INFO - 2020-09-05 09:56:41 --> Helper loaded: form_helper
INFO - 2020-09-05 09:56:41 --> Helper loaded: file_helper
INFO - 2020-09-05 09:56:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 09:56:41 --> Database Driver Class Initialized
DEBUG - 2020-09-05 09:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 09:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 09:56:41 --> Upload Class Initialized
INFO - 2020-09-05 09:56:41 --> Controller Class Initialized
DEBUG - 2020-09-05 09:56:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 09:56:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 09:56:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 09:56:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 09:56:41 --> Final output sent to browser
DEBUG - 2020-09-05 09:56:41 --> Total execution time: 0.0572
INFO - 2020-09-05 10:51:24 --> Config Class Initialized
INFO - 2020-09-05 10:51:24 --> Hooks Class Initialized
DEBUG - 2020-09-05 10:51:24 --> UTF-8 Support Enabled
INFO - 2020-09-05 10:51:24 --> Utf8 Class Initialized
INFO - 2020-09-05 10:51:24 --> URI Class Initialized
DEBUG - 2020-09-05 10:51:24 --> No URI present. Default controller set.
INFO - 2020-09-05 10:51:24 --> Router Class Initialized
INFO - 2020-09-05 10:51:24 --> Output Class Initialized
INFO - 2020-09-05 10:51:24 --> Security Class Initialized
DEBUG - 2020-09-05 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 10:51:24 --> Input Class Initialized
INFO - 2020-09-05 10:51:24 --> Language Class Initialized
INFO - 2020-09-05 10:51:24 --> Language Class Initialized
INFO - 2020-09-05 10:51:24 --> Config Class Initialized
INFO - 2020-09-05 10:51:24 --> Loader Class Initialized
INFO - 2020-09-05 10:51:24 --> Helper loaded: url_helper
INFO - 2020-09-05 10:51:24 --> Helper loaded: form_helper
INFO - 2020-09-05 10:51:24 --> Helper loaded: file_helper
INFO - 2020-09-05 10:51:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 10:51:24 --> Database Driver Class Initialized
DEBUG - 2020-09-05 10:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 10:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 10:51:24 --> Upload Class Initialized
INFO - 2020-09-05 10:51:24 --> Controller Class Initialized
DEBUG - 2020-09-05 10:51:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 10:51:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 10:51:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 10:51:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 10:51:24 --> Final output sent to browser
DEBUG - 2020-09-05 10:51:24 --> Total execution time: 0.0578
INFO - 2020-09-05 10:51:36 --> Config Class Initialized
INFO - 2020-09-05 10:51:36 --> Hooks Class Initialized
DEBUG - 2020-09-05 10:51:36 --> UTF-8 Support Enabled
INFO - 2020-09-05 10:51:36 --> Utf8 Class Initialized
INFO - 2020-09-05 10:51:36 --> URI Class Initialized
INFO - 2020-09-05 10:51:36 --> Router Class Initialized
INFO - 2020-09-05 10:51:36 --> Output Class Initialized
INFO - 2020-09-05 10:51:36 --> Security Class Initialized
DEBUG - 2020-09-05 10:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 10:51:36 --> Input Class Initialized
INFO - 2020-09-05 10:51:36 --> Language Class Initialized
INFO - 2020-09-05 10:51:36 --> Language Class Initialized
INFO - 2020-09-05 10:51:36 --> Config Class Initialized
INFO - 2020-09-05 10:51:36 --> Loader Class Initialized
INFO - 2020-09-05 10:51:36 --> Helper loaded: url_helper
INFO - 2020-09-05 10:51:36 --> Helper loaded: form_helper
INFO - 2020-09-05 10:51:36 --> Helper loaded: file_helper
INFO - 2020-09-05 10:51:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 10:51:36 --> Database Driver Class Initialized
DEBUG - 2020-09-05 10:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 10:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 10:51:36 --> Upload Class Initialized
INFO - 2020-09-05 10:51:36 --> Controller Class Initialized
ERROR - 2020-09-05 10:51:36 --> 404 Page Not Found: /index
INFO - 2020-09-05 11:02:39 --> Config Class Initialized
INFO - 2020-09-05 11:02:39 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:02:39 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:02:39 --> Utf8 Class Initialized
INFO - 2020-09-05 11:02:39 --> URI Class Initialized
DEBUG - 2020-09-05 11:02:39 --> No URI present. Default controller set.
INFO - 2020-09-05 11:02:39 --> Router Class Initialized
INFO - 2020-09-05 11:02:39 --> Output Class Initialized
INFO - 2020-09-05 11:02:39 --> Security Class Initialized
DEBUG - 2020-09-05 11:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:02:39 --> Input Class Initialized
INFO - 2020-09-05 11:02:39 --> Language Class Initialized
INFO - 2020-09-05 11:02:39 --> Language Class Initialized
INFO - 2020-09-05 11:02:39 --> Config Class Initialized
INFO - 2020-09-05 11:02:39 --> Loader Class Initialized
INFO - 2020-09-05 11:02:39 --> Helper loaded: url_helper
INFO - 2020-09-05 11:02:39 --> Helper loaded: form_helper
INFO - 2020-09-05 11:02:39 --> Helper loaded: file_helper
INFO - 2020-09-05 11:02:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:02:39 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:02:39 --> Upload Class Initialized
INFO - 2020-09-05 11:02:39 --> Controller Class Initialized
DEBUG - 2020-09-05 11:02:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 11:02:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 11:02:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 11:02:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 11:02:39 --> Final output sent to browser
DEBUG - 2020-09-05 11:02:39 --> Total execution time: 0.0532
INFO - 2020-09-05 11:02:39 --> Config Class Initialized
INFO - 2020-09-05 11:02:39 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:02:39 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:02:39 --> Utf8 Class Initialized
INFO - 2020-09-05 11:02:39 --> URI Class Initialized
DEBUG - 2020-09-05 11:02:39 --> No URI present. Default controller set.
INFO - 2020-09-05 11:02:39 --> Router Class Initialized
INFO - 2020-09-05 11:02:39 --> Output Class Initialized
INFO - 2020-09-05 11:02:39 --> Security Class Initialized
DEBUG - 2020-09-05 11:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:02:39 --> Input Class Initialized
INFO - 2020-09-05 11:02:39 --> Language Class Initialized
INFO - 2020-09-05 11:02:39 --> Language Class Initialized
INFO - 2020-09-05 11:02:39 --> Config Class Initialized
INFO - 2020-09-05 11:02:39 --> Loader Class Initialized
INFO - 2020-09-05 11:02:39 --> Helper loaded: url_helper
INFO - 2020-09-05 11:02:39 --> Helper loaded: form_helper
INFO - 2020-09-05 11:02:39 --> Helper loaded: file_helper
INFO - 2020-09-05 11:02:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:02:39 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:02:39 --> Upload Class Initialized
INFO - 2020-09-05 11:02:39 --> Controller Class Initialized
DEBUG - 2020-09-05 11:02:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 11:02:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 11:02:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 11:02:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 11:02:39 --> Final output sent to browser
DEBUG - 2020-09-05 11:02:39 --> Total execution time: 0.0544
INFO - 2020-09-05 11:23:00 --> Config Class Initialized
INFO - 2020-09-05 11:23:00 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:23:00 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:23:00 --> Utf8 Class Initialized
INFO - 2020-09-05 11:23:00 --> URI Class Initialized
DEBUG - 2020-09-05 11:23:00 --> No URI present. Default controller set.
INFO - 2020-09-05 11:23:00 --> Router Class Initialized
INFO - 2020-09-05 11:23:00 --> Output Class Initialized
INFO - 2020-09-05 11:23:00 --> Security Class Initialized
DEBUG - 2020-09-05 11:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:23:00 --> Input Class Initialized
INFO - 2020-09-05 11:23:00 --> Language Class Initialized
INFO - 2020-09-05 11:23:00 --> Language Class Initialized
INFO - 2020-09-05 11:23:00 --> Config Class Initialized
INFO - 2020-09-05 11:23:00 --> Loader Class Initialized
INFO - 2020-09-05 11:23:00 --> Helper loaded: url_helper
INFO - 2020-09-05 11:23:00 --> Helper loaded: form_helper
INFO - 2020-09-05 11:23:00 --> Helper loaded: file_helper
INFO - 2020-09-05 11:23:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:23:00 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:23:00 --> Upload Class Initialized
INFO - 2020-09-05 11:23:00 --> Controller Class Initialized
DEBUG - 2020-09-05 11:23:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 11:23:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 11:23:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 11:23:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 11:23:00 --> Final output sent to browser
DEBUG - 2020-09-05 11:23:00 --> Total execution time: 0.0508
INFO - 2020-09-05 11:23:10 --> Config Class Initialized
INFO - 2020-09-05 11:23:10 --> Config Class Initialized
INFO - 2020-09-05 11:23:10 --> Hooks Class Initialized
INFO - 2020-09-05 11:23:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-05 11:23:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:23:10 --> Utf8 Class Initialized
INFO - 2020-09-05 11:23:10 --> Utf8 Class Initialized
INFO - 2020-09-05 11:23:10 --> URI Class Initialized
INFO - 2020-09-05 11:23:10 --> URI Class Initialized
INFO - 2020-09-05 11:23:10 --> Router Class Initialized
INFO - 2020-09-05 11:23:10 --> Router Class Initialized
INFO - 2020-09-05 11:23:10 --> Output Class Initialized
INFO - 2020-09-05 11:23:10 --> Output Class Initialized
INFO - 2020-09-05 11:23:10 --> Security Class Initialized
INFO - 2020-09-05 11:23:10 --> Security Class Initialized
DEBUG - 2020-09-05 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-05 11:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:23:10 --> Input Class Initialized
INFO - 2020-09-05 11:23:10 --> Input Class Initialized
INFO - 2020-09-05 11:23:10 --> Language Class Initialized
INFO - 2020-09-05 11:23:10 --> Language Class Initialized
INFO - 2020-09-05 11:23:10 --> Language Class Initialized
INFO - 2020-09-05 11:23:10 --> Language Class Initialized
INFO - 2020-09-05 11:23:10 --> Config Class Initialized
INFO - 2020-09-05 11:23:10 --> Config Class Initialized
INFO - 2020-09-05 11:23:10 --> Loader Class Initialized
INFO - 2020-09-05 11:23:10 --> Loader Class Initialized
INFO - 2020-09-05 11:23:10 --> Helper loaded: url_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: url_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: form_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: form_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: file_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: file_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:23:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:23:10 --> Database Driver Class Initialized
INFO - 2020-09-05 11:23:10 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-09-05 11:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:23:10 --> Upload Class Initialized
INFO - 2020-09-05 11:23:11 --> Controller Class Initialized
ERROR - 2020-09-05 11:23:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 11:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:23:11 --> Upload Class Initialized
INFO - 2020-09-05 11:23:11 --> Controller Class Initialized
ERROR - 2020-09-05 11:23:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 11:23:18 --> Config Class Initialized
INFO - 2020-09-05 11:23:18 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:23:18 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:23:18 --> Utf8 Class Initialized
INFO - 2020-09-05 11:23:18 --> URI Class Initialized
INFO - 2020-09-05 11:23:18 --> Router Class Initialized
INFO - 2020-09-05 11:23:18 --> Output Class Initialized
INFO - 2020-09-05 11:23:18 --> Security Class Initialized
DEBUG - 2020-09-05 11:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:23:18 --> Input Class Initialized
INFO - 2020-09-05 11:23:18 --> Language Class Initialized
INFO - 2020-09-05 11:23:18 --> Language Class Initialized
INFO - 2020-09-05 11:23:18 --> Config Class Initialized
INFO - 2020-09-05 11:23:18 --> Config Class Initialized
INFO - 2020-09-05 11:23:18 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:23:18 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:23:18 --> Utf8 Class Initialized
INFO - 2020-09-05 11:23:18 --> Loader Class Initialized
INFO - 2020-09-05 11:23:18 --> URI Class Initialized
INFO - 2020-09-05 11:23:18 --> Helper loaded: url_helper
INFO - 2020-09-05 11:23:18 --> Router Class Initialized
INFO - 2020-09-05 11:23:18 --> Helper loaded: form_helper
INFO - 2020-09-05 11:23:18 --> Helper loaded: file_helper
INFO - 2020-09-05 11:23:18 --> Output Class Initialized
INFO - 2020-09-05 11:23:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:23:18 --> Security Class Initialized
DEBUG - 2020-09-05 11:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:23:18 --> Input Class Initialized
INFO - 2020-09-05 11:23:18 --> Language Class Initialized
INFO - 2020-09-05 11:23:18 --> Language Class Initialized
INFO - 2020-09-05 11:23:18 --> Config Class Initialized
INFO - 2020-09-05 11:23:18 --> Loader Class Initialized
INFO - 2020-09-05 11:23:18 --> Database Driver Class Initialized
INFO - 2020-09-05 11:23:18 --> Helper loaded: url_helper
INFO - 2020-09-05 11:23:18 --> Helper loaded: form_helper
INFO - 2020-09-05 11:23:18 --> Helper loaded: file_helper
DEBUG - 2020-09-05 11:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:23:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:23:18 --> Upload Class Initialized
INFO - 2020-09-05 11:23:18 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:23:18 --> Controller Class Initialized
ERROR - 2020-09-05 11:23:18 --> 404 Page Not Found: /index
INFO - 2020-09-05 11:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:23:18 --> Upload Class Initialized
INFO - 2020-09-05 11:23:18 --> Controller Class Initialized
ERROR - 2020-09-05 11:23:18 --> 404 Page Not Found: /index
INFO - 2020-09-05 11:28:25 --> Config Class Initialized
INFO - 2020-09-05 11:28:25 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:28:25 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:28:25 --> Utf8 Class Initialized
INFO - 2020-09-05 11:28:25 --> URI Class Initialized
DEBUG - 2020-09-05 11:28:25 --> No URI present. Default controller set.
INFO - 2020-09-05 11:28:25 --> Router Class Initialized
INFO - 2020-09-05 11:28:25 --> Output Class Initialized
INFO - 2020-09-05 11:28:25 --> Security Class Initialized
DEBUG - 2020-09-05 11:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:28:25 --> Input Class Initialized
INFO - 2020-09-05 11:28:25 --> Language Class Initialized
INFO - 2020-09-05 11:28:25 --> Language Class Initialized
INFO - 2020-09-05 11:28:25 --> Config Class Initialized
INFO - 2020-09-05 11:28:25 --> Loader Class Initialized
INFO - 2020-09-05 11:28:25 --> Helper loaded: url_helper
INFO - 2020-09-05 11:28:25 --> Helper loaded: form_helper
INFO - 2020-09-05 11:28:25 --> Helper loaded: file_helper
INFO - 2020-09-05 11:28:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:28:25 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:28:25 --> Upload Class Initialized
INFO - 2020-09-05 11:28:25 --> Controller Class Initialized
DEBUG - 2020-09-05 11:28:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 11:28:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 11:28:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 11:28:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 11:28:25 --> Final output sent to browser
DEBUG - 2020-09-05 11:28:25 --> Total execution time: 0.0601
INFO - 2020-09-05 11:28:26 --> Config Class Initialized
INFO - 2020-09-05 11:28:26 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:28:26 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:28:26 --> Utf8 Class Initialized
INFO - 2020-09-05 11:28:26 --> URI Class Initialized
INFO - 2020-09-05 11:28:26 --> Router Class Initialized
INFO - 2020-09-05 11:28:26 --> Output Class Initialized
INFO - 2020-09-05 11:28:26 --> Security Class Initialized
DEBUG - 2020-09-05 11:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:28:26 --> Input Class Initialized
INFO - 2020-09-05 11:28:26 --> Language Class Initialized
INFO - 2020-09-05 11:28:26 --> Language Class Initialized
INFO - 2020-09-05 11:28:26 --> Config Class Initialized
INFO - 2020-09-05 11:28:26 --> Loader Class Initialized
INFO - 2020-09-05 11:28:26 --> Helper loaded: url_helper
INFO - 2020-09-05 11:28:26 --> Helper loaded: form_helper
INFO - 2020-09-05 11:28:26 --> Helper loaded: file_helper
INFO - 2020-09-05 11:28:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:28:26 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:28:26 --> Upload Class Initialized
INFO - 2020-09-05 11:28:26 --> Controller Class Initialized
ERROR - 2020-09-05 11:28:26 --> 404 Page Not Found: /index
INFO - 2020-09-05 11:28:27 --> Config Class Initialized
INFO - 2020-09-05 11:28:27 --> Hooks Class Initialized
DEBUG - 2020-09-05 11:28:27 --> UTF-8 Support Enabled
INFO - 2020-09-05 11:28:27 --> Utf8 Class Initialized
INFO - 2020-09-05 11:28:27 --> URI Class Initialized
INFO - 2020-09-05 11:28:27 --> Router Class Initialized
INFO - 2020-09-05 11:28:27 --> Output Class Initialized
INFO - 2020-09-05 11:28:27 --> Security Class Initialized
DEBUG - 2020-09-05 11:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 11:28:27 --> Input Class Initialized
INFO - 2020-09-05 11:28:27 --> Language Class Initialized
INFO - 2020-09-05 11:28:27 --> Language Class Initialized
INFO - 2020-09-05 11:28:27 --> Config Class Initialized
INFO - 2020-09-05 11:28:27 --> Loader Class Initialized
INFO - 2020-09-05 11:28:27 --> Helper loaded: url_helper
INFO - 2020-09-05 11:28:27 --> Helper loaded: form_helper
INFO - 2020-09-05 11:28:27 --> Helper loaded: file_helper
INFO - 2020-09-05 11:28:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 11:28:27 --> Database Driver Class Initialized
DEBUG - 2020-09-05 11:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 11:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 11:28:27 --> Upload Class Initialized
INFO - 2020-09-05 11:28:27 --> Controller Class Initialized
ERROR - 2020-09-05 11:28:27 --> 404 Page Not Found: /index
INFO - 2020-09-05 13:09:58 --> Config Class Initialized
INFO - 2020-09-05 13:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-05 13:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-05 13:09:58 --> Utf8 Class Initialized
INFO - 2020-09-05 13:09:58 --> URI Class Initialized
DEBUG - 2020-09-05 13:09:58 --> No URI present. Default controller set.
INFO - 2020-09-05 13:09:58 --> Router Class Initialized
INFO - 2020-09-05 13:09:58 --> Output Class Initialized
INFO - 2020-09-05 13:09:58 --> Security Class Initialized
DEBUG - 2020-09-05 13:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 13:09:58 --> Input Class Initialized
INFO - 2020-09-05 13:09:58 --> Language Class Initialized
INFO - 2020-09-05 13:09:58 --> Language Class Initialized
INFO - 2020-09-05 13:09:58 --> Config Class Initialized
INFO - 2020-09-05 13:09:58 --> Loader Class Initialized
INFO - 2020-09-05 13:09:58 --> Helper loaded: url_helper
INFO - 2020-09-05 13:09:58 --> Helper loaded: form_helper
INFO - 2020-09-05 13:09:58 --> Helper loaded: file_helper
INFO - 2020-09-05 13:09:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 13:09:58 --> Database Driver Class Initialized
DEBUG - 2020-09-05 13:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 13:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 13:09:58 --> Upload Class Initialized
INFO - 2020-09-05 13:09:58 --> Controller Class Initialized
DEBUG - 2020-09-05 13:09:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 13:09:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 13:09:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 13:09:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 13:09:58 --> Final output sent to browser
DEBUG - 2020-09-05 13:09:58 --> Total execution time: 0.0587
INFO - 2020-09-05 13:46:12 --> Config Class Initialized
INFO - 2020-09-05 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-09-05 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-09-05 13:46:12 --> Utf8 Class Initialized
INFO - 2020-09-05 13:46:12 --> URI Class Initialized
DEBUG - 2020-09-05 13:46:12 --> No URI present. Default controller set.
INFO - 2020-09-05 13:46:12 --> Router Class Initialized
INFO - 2020-09-05 13:46:12 --> Output Class Initialized
INFO - 2020-09-05 13:46:12 --> Security Class Initialized
DEBUG - 2020-09-05 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 13:46:12 --> Input Class Initialized
INFO - 2020-09-05 13:46:12 --> Language Class Initialized
INFO - 2020-09-05 13:46:12 --> Language Class Initialized
INFO - 2020-09-05 13:46:12 --> Config Class Initialized
INFO - 2020-09-05 13:46:12 --> Loader Class Initialized
INFO - 2020-09-05 13:46:12 --> Helper loaded: url_helper
INFO - 2020-09-05 13:46:12 --> Helper loaded: form_helper
INFO - 2020-09-05 13:46:12 --> Helper loaded: file_helper
INFO - 2020-09-05 13:46:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 13:46:12 --> Database Driver Class Initialized
DEBUG - 2020-09-05 13:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 13:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 13:46:12 --> Upload Class Initialized
INFO - 2020-09-05 13:46:13 --> Controller Class Initialized
DEBUG - 2020-09-05 13:46:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 13:46:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 13:46:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 13:46:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 13:46:13 --> Final output sent to browser
DEBUG - 2020-09-05 13:46:13 --> Total execution time: 0.0582
INFO - 2020-09-05 14:00:46 --> Config Class Initialized
INFO - 2020-09-05 14:00:46 --> Hooks Class Initialized
DEBUG - 2020-09-05 14:00:46 --> UTF-8 Support Enabled
INFO - 2020-09-05 14:00:46 --> Utf8 Class Initialized
INFO - 2020-09-05 14:00:46 --> URI Class Initialized
DEBUG - 2020-09-05 14:00:46 --> No URI present. Default controller set.
INFO - 2020-09-05 14:00:46 --> Router Class Initialized
INFO - 2020-09-05 14:00:46 --> Output Class Initialized
INFO - 2020-09-05 14:00:46 --> Security Class Initialized
DEBUG - 2020-09-05 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 14:00:46 --> Input Class Initialized
INFO - 2020-09-05 14:00:46 --> Language Class Initialized
INFO - 2020-09-05 14:00:46 --> Language Class Initialized
INFO - 2020-09-05 14:00:46 --> Config Class Initialized
INFO - 2020-09-05 14:00:46 --> Loader Class Initialized
INFO - 2020-09-05 14:00:46 --> Helper loaded: url_helper
INFO - 2020-09-05 14:00:46 --> Helper loaded: form_helper
INFO - 2020-09-05 14:00:46 --> Helper loaded: file_helper
INFO - 2020-09-05 14:00:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 14:00:46 --> Database Driver Class Initialized
DEBUG - 2020-09-05 14:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 14:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 14:00:46 --> Upload Class Initialized
INFO - 2020-09-05 14:00:47 --> Controller Class Initialized
DEBUG - 2020-09-05 14:00:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 14:00:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 14:00:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 14:00:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 14:00:47 --> Final output sent to browser
DEBUG - 2020-09-05 14:00:47 --> Total execution time: 0.0502
INFO - 2020-09-05 14:00:50 --> Config Class Initialized
INFO - 2020-09-05 14:00:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 14:00:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 14:00:50 --> Utf8 Class Initialized
INFO - 2020-09-05 14:00:50 --> URI Class Initialized
INFO - 2020-09-05 14:00:50 --> Router Class Initialized
INFO - 2020-09-05 14:00:50 --> Output Class Initialized
INFO - 2020-09-05 14:00:50 --> Security Class Initialized
DEBUG - 2020-09-05 14:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 14:00:50 --> Input Class Initialized
INFO - 2020-09-05 14:00:50 --> Language Class Initialized
INFO - 2020-09-05 14:00:50 --> Language Class Initialized
INFO - 2020-09-05 14:00:50 --> Config Class Initialized
INFO - 2020-09-05 14:00:50 --> Loader Class Initialized
INFO - 2020-09-05 14:00:50 --> Helper loaded: url_helper
INFO - 2020-09-05 14:00:50 --> Helper loaded: form_helper
INFO - 2020-09-05 14:00:50 --> Helper loaded: file_helper
INFO - 2020-09-05 14:00:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 14:00:50 --> Database Driver Class Initialized
DEBUG - 2020-09-05 14:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 14:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 14:00:50 --> Upload Class Initialized
INFO - 2020-09-05 14:00:50 --> Controller Class Initialized
ERROR - 2020-09-05 14:00:50 --> 404 Page Not Found: /index
INFO - 2020-09-05 14:00:54 --> Config Class Initialized
INFO - 2020-09-05 14:00:54 --> Hooks Class Initialized
DEBUG - 2020-09-05 14:00:54 --> UTF-8 Support Enabled
INFO - 2020-09-05 14:00:54 --> Utf8 Class Initialized
INFO - 2020-09-05 14:00:54 --> URI Class Initialized
INFO - 2020-09-05 14:00:54 --> Router Class Initialized
INFO - 2020-09-05 14:00:54 --> Output Class Initialized
INFO - 2020-09-05 14:00:54 --> Security Class Initialized
DEBUG - 2020-09-05 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 14:00:54 --> Input Class Initialized
INFO - 2020-09-05 14:00:54 --> Language Class Initialized
INFO - 2020-09-05 14:00:54 --> Language Class Initialized
INFO - 2020-09-05 14:00:54 --> Config Class Initialized
INFO - 2020-09-05 14:00:54 --> Loader Class Initialized
INFO - 2020-09-05 14:00:54 --> Helper loaded: url_helper
INFO - 2020-09-05 14:00:54 --> Helper loaded: form_helper
INFO - 2020-09-05 14:00:54 --> Helper loaded: file_helper
INFO - 2020-09-05 14:00:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 14:00:54 --> Database Driver Class Initialized
DEBUG - 2020-09-05 14:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 14:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 14:00:54 --> Upload Class Initialized
INFO - 2020-09-05 14:00:54 --> Controller Class Initialized
DEBUG - 2020-09-05 14:00:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 14:00:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-05 14:00:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 14:00:54 --> Final output sent to browser
DEBUG - 2020-09-05 14:00:54 --> Total execution time: 0.0532
INFO - 2020-09-05 14:09:10 --> Config Class Initialized
INFO - 2020-09-05 14:09:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 14:09:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 14:09:10 --> Utf8 Class Initialized
INFO - 2020-09-05 14:09:10 --> URI Class Initialized
DEBUG - 2020-09-05 14:09:10 --> No URI present. Default controller set.
INFO - 2020-09-05 14:09:10 --> Router Class Initialized
INFO - 2020-09-05 14:09:10 --> Output Class Initialized
INFO - 2020-09-05 14:09:10 --> Security Class Initialized
DEBUG - 2020-09-05 14:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 14:09:10 --> Input Class Initialized
INFO - 2020-09-05 14:09:10 --> Language Class Initialized
INFO - 2020-09-05 14:09:10 --> Language Class Initialized
INFO - 2020-09-05 14:09:10 --> Config Class Initialized
INFO - 2020-09-05 14:09:10 --> Loader Class Initialized
INFO - 2020-09-05 14:09:10 --> Helper loaded: url_helper
INFO - 2020-09-05 14:09:10 --> Helper loaded: form_helper
INFO - 2020-09-05 14:09:10 --> Helper loaded: file_helper
INFO - 2020-09-05 14:09:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 14:09:10 --> Database Driver Class Initialized
DEBUG - 2020-09-05 14:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 14:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 14:09:10 --> Upload Class Initialized
INFO - 2020-09-05 14:09:10 --> Controller Class Initialized
DEBUG - 2020-09-05 14:09:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 14:09:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 14:09:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 14:09:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 14:09:10 --> Final output sent to browser
DEBUG - 2020-09-05 14:09:10 --> Total execution time: 0.0559
INFO - 2020-09-05 14:09:11 --> Config Class Initialized
INFO - 2020-09-05 14:09:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 14:09:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 14:09:11 --> Utf8 Class Initialized
INFO - 2020-09-05 14:09:11 --> URI Class Initialized
DEBUG - 2020-09-05 14:09:11 --> No URI present. Default controller set.
INFO - 2020-09-05 14:09:11 --> Router Class Initialized
INFO - 2020-09-05 14:09:11 --> Output Class Initialized
INFO - 2020-09-05 14:09:11 --> Security Class Initialized
DEBUG - 2020-09-05 14:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 14:09:11 --> Input Class Initialized
INFO - 2020-09-05 14:09:11 --> Language Class Initialized
INFO - 2020-09-05 14:09:11 --> Language Class Initialized
INFO - 2020-09-05 14:09:11 --> Config Class Initialized
INFO - 2020-09-05 14:09:11 --> Loader Class Initialized
INFO - 2020-09-05 14:09:11 --> Helper loaded: url_helper
INFO - 2020-09-05 14:09:11 --> Helper loaded: form_helper
INFO - 2020-09-05 14:09:11 --> Helper loaded: file_helper
INFO - 2020-09-05 14:09:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 14:09:11 --> Database Driver Class Initialized
DEBUG - 2020-09-05 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 14:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 14:09:11 --> Upload Class Initialized
INFO - 2020-09-05 14:09:11 --> Controller Class Initialized
DEBUG - 2020-09-05 14:09:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 14:09:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 14:09:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 14:09:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 14:09:11 --> Final output sent to browser
DEBUG - 2020-09-05 14:09:11 --> Total execution time: 0.0521
INFO - 2020-09-05 14:37:47 --> Config Class Initialized
INFO - 2020-09-05 14:37:47 --> Hooks Class Initialized
DEBUG - 2020-09-05 14:37:47 --> UTF-8 Support Enabled
INFO - 2020-09-05 14:37:47 --> Utf8 Class Initialized
INFO - 2020-09-05 14:37:47 --> URI Class Initialized
INFO - 2020-09-05 14:37:47 --> Router Class Initialized
INFO - 2020-09-05 14:37:47 --> Output Class Initialized
INFO - 2020-09-05 14:37:47 --> Security Class Initialized
DEBUG - 2020-09-05 14:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 14:37:47 --> Input Class Initialized
INFO - 2020-09-05 14:37:47 --> Language Class Initialized
INFO - 2020-09-05 14:37:47 --> Language Class Initialized
INFO - 2020-09-05 14:37:47 --> Config Class Initialized
INFO - 2020-09-05 14:37:47 --> Loader Class Initialized
INFO - 2020-09-05 14:37:47 --> Helper loaded: url_helper
INFO - 2020-09-05 14:37:47 --> Helper loaded: form_helper
INFO - 2020-09-05 14:37:47 --> Helper loaded: file_helper
INFO - 2020-09-05 14:37:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 14:37:47 --> Database Driver Class Initialized
DEBUG - 2020-09-05 14:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 14:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 14:37:47 --> Upload Class Initialized
INFO - 2020-09-05 14:37:47 --> Controller Class Initialized
DEBUG - 2020-09-05 14:37:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 14:37:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 14:37:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 14:37:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 14:37:47 --> Final output sent to browser
DEBUG - 2020-09-05 14:37:47 --> Total execution time: 0.0497
INFO - 2020-09-05 15:34:00 --> Config Class Initialized
INFO - 2020-09-05 15:34:00 --> Hooks Class Initialized
DEBUG - 2020-09-05 15:34:00 --> UTF-8 Support Enabled
INFO - 2020-09-05 15:34:00 --> Utf8 Class Initialized
INFO - 2020-09-05 15:34:00 --> URI Class Initialized
DEBUG - 2020-09-05 15:34:00 --> No URI present. Default controller set.
INFO - 2020-09-05 15:34:00 --> Router Class Initialized
INFO - 2020-09-05 15:34:00 --> Output Class Initialized
INFO - 2020-09-05 15:34:00 --> Security Class Initialized
DEBUG - 2020-09-05 15:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 15:34:00 --> Input Class Initialized
INFO - 2020-09-05 15:34:00 --> Language Class Initialized
INFO - 2020-09-05 15:34:00 --> Language Class Initialized
INFO - 2020-09-05 15:34:00 --> Config Class Initialized
INFO - 2020-09-05 15:34:00 --> Loader Class Initialized
INFO - 2020-09-05 15:34:00 --> Helper loaded: url_helper
INFO - 2020-09-05 15:34:00 --> Helper loaded: form_helper
INFO - 2020-09-05 15:34:00 --> Helper loaded: file_helper
INFO - 2020-09-05 15:34:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 15:34:00 --> Database Driver Class Initialized
DEBUG - 2020-09-05 15:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 15:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 15:34:00 --> Upload Class Initialized
INFO - 2020-09-05 15:34:00 --> Controller Class Initialized
DEBUG - 2020-09-05 15:34:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 15:34:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 15:34:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 15:34:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 15:34:00 --> Final output sent to browser
DEBUG - 2020-09-05 15:34:00 --> Total execution time: 0.0507
INFO - 2020-09-05 15:34:02 --> Config Class Initialized
INFO - 2020-09-05 15:34:02 --> Hooks Class Initialized
DEBUG - 2020-09-05 15:34:02 --> UTF-8 Support Enabled
INFO - 2020-09-05 15:34:02 --> Utf8 Class Initialized
INFO - 2020-09-05 15:34:02 --> URI Class Initialized
INFO - 2020-09-05 15:34:02 --> Router Class Initialized
INFO - 2020-09-05 15:34:02 --> Output Class Initialized
INFO - 2020-09-05 15:34:02 --> Security Class Initialized
DEBUG - 2020-09-05 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 15:34:02 --> Input Class Initialized
INFO - 2020-09-05 15:34:02 --> Language Class Initialized
INFO - 2020-09-05 15:34:02 --> Language Class Initialized
INFO - 2020-09-05 15:34:02 --> Config Class Initialized
INFO - 2020-09-05 15:34:02 --> Loader Class Initialized
INFO - 2020-09-05 15:34:02 --> Helper loaded: url_helper
INFO - 2020-09-05 15:34:02 --> Helper loaded: form_helper
INFO - 2020-09-05 15:34:02 --> Helper loaded: file_helper
INFO - 2020-09-05 15:34:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 15:34:02 --> Database Driver Class Initialized
DEBUG - 2020-09-05 15:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 15:34:02 --> Upload Class Initialized
INFO - 2020-09-05 15:34:02 --> Controller Class Initialized
ERROR - 2020-09-05 15:34:02 --> 404 Page Not Found: /index
INFO - 2020-09-05 15:59:23 --> Config Class Initialized
INFO - 2020-09-05 15:59:23 --> Hooks Class Initialized
DEBUG - 2020-09-05 15:59:23 --> UTF-8 Support Enabled
INFO - 2020-09-05 15:59:23 --> Utf8 Class Initialized
INFO - 2020-09-05 15:59:23 --> URI Class Initialized
DEBUG - 2020-09-05 15:59:23 --> No URI present. Default controller set.
INFO - 2020-09-05 15:59:23 --> Router Class Initialized
INFO - 2020-09-05 15:59:23 --> Output Class Initialized
INFO - 2020-09-05 15:59:23 --> Security Class Initialized
DEBUG - 2020-09-05 15:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 15:59:23 --> Input Class Initialized
INFO - 2020-09-05 15:59:23 --> Language Class Initialized
INFO - 2020-09-05 15:59:23 --> Language Class Initialized
INFO - 2020-09-05 15:59:23 --> Config Class Initialized
INFO - 2020-09-05 15:59:23 --> Loader Class Initialized
INFO - 2020-09-05 15:59:23 --> Helper loaded: url_helper
INFO - 2020-09-05 15:59:23 --> Helper loaded: form_helper
INFO - 2020-09-05 15:59:23 --> Helper loaded: file_helper
INFO - 2020-09-05 15:59:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 15:59:23 --> Database Driver Class Initialized
DEBUG - 2020-09-05 15:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 15:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 15:59:23 --> Upload Class Initialized
INFO - 2020-09-05 15:59:23 --> Controller Class Initialized
DEBUG - 2020-09-05 15:59:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 15:59:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 15:59:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 15:59:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 15:59:23 --> Final output sent to browser
DEBUG - 2020-09-05 15:59:23 --> Total execution time: 0.0526
INFO - 2020-09-05 16:54:40 --> Config Class Initialized
INFO - 2020-09-05 16:54:40 --> Hooks Class Initialized
DEBUG - 2020-09-05 16:54:40 --> UTF-8 Support Enabled
INFO - 2020-09-05 16:54:40 --> Utf8 Class Initialized
INFO - 2020-09-05 16:54:40 --> URI Class Initialized
DEBUG - 2020-09-05 16:54:40 --> No URI present. Default controller set.
INFO - 2020-09-05 16:54:40 --> Router Class Initialized
INFO - 2020-09-05 16:54:40 --> Output Class Initialized
INFO - 2020-09-05 16:54:40 --> Security Class Initialized
DEBUG - 2020-09-05 16:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 16:54:40 --> Input Class Initialized
INFO - 2020-09-05 16:54:40 --> Language Class Initialized
INFO - 2020-09-05 16:54:40 --> Language Class Initialized
INFO - 2020-09-05 16:54:40 --> Config Class Initialized
INFO - 2020-09-05 16:54:40 --> Loader Class Initialized
INFO - 2020-09-05 16:54:40 --> Helper loaded: url_helper
INFO - 2020-09-05 16:54:40 --> Helper loaded: form_helper
INFO - 2020-09-05 16:54:40 --> Helper loaded: file_helper
INFO - 2020-09-05 16:54:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 16:54:40 --> Database Driver Class Initialized
DEBUG - 2020-09-05 16:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 16:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 16:54:40 --> Upload Class Initialized
INFO - 2020-09-05 16:54:40 --> Controller Class Initialized
DEBUG - 2020-09-05 16:54:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 16:54:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 16:54:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 16:54:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 16:54:40 --> Final output sent to browser
DEBUG - 2020-09-05 16:54:40 --> Total execution time: 0.0524
INFO - 2020-09-05 16:54:42 --> Config Class Initialized
INFO - 2020-09-05 16:54:42 --> Hooks Class Initialized
DEBUG - 2020-09-05 16:54:42 --> UTF-8 Support Enabled
INFO - 2020-09-05 16:54:42 --> Utf8 Class Initialized
INFO - 2020-09-05 16:54:42 --> URI Class Initialized
INFO - 2020-09-05 16:54:42 --> Router Class Initialized
INFO - 2020-09-05 16:54:42 --> Output Class Initialized
INFO - 2020-09-05 16:54:42 --> Security Class Initialized
DEBUG - 2020-09-05 16:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 16:54:42 --> Input Class Initialized
INFO - 2020-09-05 16:54:42 --> Language Class Initialized
INFO - 2020-09-05 16:54:42 --> Language Class Initialized
INFO - 2020-09-05 16:54:42 --> Config Class Initialized
INFO - 2020-09-05 16:54:42 --> Loader Class Initialized
INFO - 2020-09-05 16:54:42 --> Helper loaded: url_helper
INFO - 2020-09-05 16:54:42 --> Helper loaded: form_helper
INFO - 2020-09-05 16:54:42 --> Helper loaded: file_helper
INFO - 2020-09-05 16:54:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 16:54:42 --> Database Driver Class Initialized
DEBUG - 2020-09-05 16:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 16:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 16:54:42 --> Upload Class Initialized
INFO - 2020-09-05 16:54:42 --> Controller Class Initialized
ERROR - 2020-09-05 16:54:42 --> 404 Page Not Found: /index
INFO - 2020-09-05 16:54:46 --> Config Class Initialized
INFO - 2020-09-05 16:54:46 --> Hooks Class Initialized
DEBUG - 2020-09-05 16:54:46 --> UTF-8 Support Enabled
INFO - 2020-09-05 16:54:46 --> Utf8 Class Initialized
INFO - 2020-09-05 16:54:46 --> URI Class Initialized
INFO - 2020-09-05 16:54:46 --> Router Class Initialized
INFO - 2020-09-05 16:54:46 --> Output Class Initialized
INFO - 2020-09-05 16:54:46 --> Security Class Initialized
DEBUG - 2020-09-05 16:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 16:54:46 --> Input Class Initialized
INFO - 2020-09-05 16:54:46 --> Language Class Initialized
INFO - 2020-09-05 16:54:46 --> Language Class Initialized
INFO - 2020-09-05 16:54:46 --> Config Class Initialized
INFO - 2020-09-05 16:54:46 --> Loader Class Initialized
INFO - 2020-09-05 16:54:46 --> Helper loaded: url_helper
INFO - 2020-09-05 16:54:46 --> Helper loaded: form_helper
INFO - 2020-09-05 16:54:46 --> Helper loaded: file_helper
INFO - 2020-09-05 16:54:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 16:54:46 --> Database Driver Class Initialized
DEBUG - 2020-09-05 16:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 16:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 16:54:46 --> Upload Class Initialized
INFO - 2020-09-05 16:54:46 --> Controller Class Initialized
DEBUG - 2020-09-05 16:54:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 16:54:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-05 16:54:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 16:54:46 --> Final output sent to browser
DEBUG - 2020-09-05 16:54:46 --> Total execution time: 0.0556
INFO - 2020-09-05 16:54:58 --> Config Class Initialized
INFO - 2020-09-05 16:54:58 --> Hooks Class Initialized
DEBUG - 2020-09-05 16:54:58 --> UTF-8 Support Enabled
INFO - 2020-09-05 16:54:58 --> Utf8 Class Initialized
INFO - 2020-09-05 16:54:58 --> URI Class Initialized
INFO - 2020-09-05 16:54:58 --> Router Class Initialized
INFO - 2020-09-05 16:54:58 --> Output Class Initialized
INFO - 2020-09-05 16:54:58 --> Security Class Initialized
DEBUG - 2020-09-05 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 16:54:58 --> Input Class Initialized
INFO - 2020-09-05 16:54:58 --> Language Class Initialized
INFO - 2020-09-05 16:54:58 --> Language Class Initialized
INFO - 2020-09-05 16:54:58 --> Config Class Initialized
INFO - 2020-09-05 16:54:58 --> Loader Class Initialized
INFO - 2020-09-05 16:54:58 --> Helper loaded: url_helper
INFO - 2020-09-05 16:54:58 --> Helper loaded: form_helper
INFO - 2020-09-05 16:54:58 --> Helper loaded: file_helper
INFO - 2020-09-05 16:54:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 16:54:58 --> Database Driver Class Initialized
DEBUG - 2020-09-05 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 16:54:58 --> Upload Class Initialized
INFO - 2020-09-05 16:54:58 --> Controller Class Initialized
DEBUG - 2020-09-05 16:54:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 16:54:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 16:54:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 16:54:58 --> Final output sent to browser
DEBUG - 2020-09-05 16:54:58 --> Total execution time: 0.0516
INFO - 2020-09-05 16:57:06 --> Config Class Initialized
INFO - 2020-09-05 16:57:06 --> Hooks Class Initialized
DEBUG - 2020-09-05 16:57:06 --> UTF-8 Support Enabled
INFO - 2020-09-05 16:57:06 --> Utf8 Class Initialized
INFO - 2020-09-05 16:57:06 --> URI Class Initialized
INFO - 2020-09-05 16:57:06 --> Router Class Initialized
INFO - 2020-09-05 16:57:06 --> Output Class Initialized
INFO - 2020-09-05 16:57:06 --> Security Class Initialized
DEBUG - 2020-09-05 16:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 16:57:06 --> Input Class Initialized
INFO - 2020-09-05 16:57:06 --> Language Class Initialized
INFO - 2020-09-05 16:57:06 --> Language Class Initialized
INFO - 2020-09-05 16:57:06 --> Config Class Initialized
INFO - 2020-09-05 16:57:06 --> Loader Class Initialized
INFO - 2020-09-05 16:57:06 --> Helper loaded: url_helper
INFO - 2020-09-05 16:57:06 --> Helper loaded: form_helper
INFO - 2020-09-05 16:57:06 --> Helper loaded: file_helper
INFO - 2020-09-05 16:57:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 16:57:06 --> Database Driver Class Initialized
DEBUG - 2020-09-05 16:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 16:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 16:57:06 --> Upload Class Initialized
INFO - 2020-09-05 16:57:06 --> Controller Class Initialized
DEBUG - 2020-09-05 16:57:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 16:57:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 16:57:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 16:57:06 --> Final output sent to browser
DEBUG - 2020-09-05 16:57:06 --> Total execution time: 0.0499
INFO - 2020-09-05 16:57:21 --> Config Class Initialized
INFO - 2020-09-05 16:57:21 --> Hooks Class Initialized
DEBUG - 2020-09-05 16:57:21 --> UTF-8 Support Enabled
INFO - 2020-09-05 16:57:21 --> Utf8 Class Initialized
INFO - 2020-09-05 16:57:21 --> URI Class Initialized
INFO - 2020-09-05 16:57:21 --> Router Class Initialized
INFO - 2020-09-05 16:57:21 --> Output Class Initialized
INFO - 2020-09-05 16:57:21 --> Security Class Initialized
DEBUG - 2020-09-05 16:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 16:57:21 --> Input Class Initialized
INFO - 2020-09-05 16:57:21 --> Language Class Initialized
INFO - 2020-09-05 16:57:21 --> Language Class Initialized
INFO - 2020-09-05 16:57:21 --> Config Class Initialized
INFO - 2020-09-05 16:57:21 --> Loader Class Initialized
INFO - 2020-09-05 16:57:21 --> Helper loaded: url_helper
INFO - 2020-09-05 16:57:21 --> Helper loaded: form_helper
INFO - 2020-09-05 16:57:21 --> Helper loaded: file_helper
INFO - 2020-09-05 16:57:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 16:57:21 --> Database Driver Class Initialized
DEBUG - 2020-09-05 16:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 16:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 16:57:21 --> Upload Class Initialized
INFO - 2020-09-05 16:57:21 --> Controller Class Initialized
DEBUG - 2020-09-05 16:57:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 16:57:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-05 16:57:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 16:57:21 --> Final output sent to browser
DEBUG - 2020-09-05 16:57:21 --> Total execution time: 0.0505
INFO - 2020-09-05 17:00:35 --> Config Class Initialized
INFO - 2020-09-05 17:00:35 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:00:35 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:00:35 --> Utf8 Class Initialized
INFO - 2020-09-05 17:00:35 --> URI Class Initialized
DEBUG - 2020-09-05 17:00:35 --> No URI present. Default controller set.
INFO - 2020-09-05 17:00:35 --> Router Class Initialized
INFO - 2020-09-05 17:00:35 --> Output Class Initialized
INFO - 2020-09-05 17:00:35 --> Security Class Initialized
DEBUG - 2020-09-05 17:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:00:35 --> Input Class Initialized
INFO - 2020-09-05 17:00:35 --> Language Class Initialized
INFO - 2020-09-05 17:00:35 --> Language Class Initialized
INFO - 2020-09-05 17:00:35 --> Config Class Initialized
INFO - 2020-09-05 17:00:35 --> Loader Class Initialized
INFO - 2020-09-05 17:00:35 --> Helper loaded: url_helper
INFO - 2020-09-05 17:00:35 --> Helper loaded: form_helper
INFO - 2020-09-05 17:00:35 --> Helper loaded: file_helper
INFO - 2020-09-05 17:00:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:00:35 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:00:35 --> Upload Class Initialized
INFO - 2020-09-05 17:00:35 --> Controller Class Initialized
DEBUG - 2020-09-05 17:00:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 17:00:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 17:00:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 17:00:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 17:00:35 --> Final output sent to browser
DEBUG - 2020-09-05 17:00:35 --> Total execution time: 0.0505
INFO - 2020-09-05 17:04:03 --> Config Class Initialized
INFO - 2020-09-05 17:04:03 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:04:03 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:04:03 --> Utf8 Class Initialized
INFO - 2020-09-05 17:04:03 --> URI Class Initialized
INFO - 2020-09-05 17:04:03 --> Router Class Initialized
INFO - 2020-09-05 17:04:03 --> Output Class Initialized
INFO - 2020-09-05 17:04:03 --> Security Class Initialized
DEBUG - 2020-09-05 17:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:04:03 --> Input Class Initialized
INFO - 2020-09-05 17:04:03 --> Language Class Initialized
INFO - 2020-09-05 17:04:03 --> Language Class Initialized
INFO - 2020-09-05 17:04:03 --> Config Class Initialized
INFO - 2020-09-05 17:04:03 --> Loader Class Initialized
INFO - 2020-09-05 17:04:03 --> Helper loaded: url_helper
INFO - 2020-09-05 17:04:03 --> Helper loaded: form_helper
INFO - 2020-09-05 17:04:03 --> Helper loaded: file_helper
INFO - 2020-09-05 17:04:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:04:03 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:04:03 --> Upload Class Initialized
INFO - 2020-09-05 17:04:03 --> Controller Class Initialized
ERROR - 2020-09-05 17:04:03 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:24:53 --> Config Class Initialized
INFO - 2020-09-05 17:24:53 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:24:53 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:24:53 --> Utf8 Class Initialized
INFO - 2020-09-05 17:24:53 --> URI Class Initialized
INFO - 2020-09-05 17:24:53 --> Router Class Initialized
INFO - 2020-09-05 17:24:53 --> Output Class Initialized
INFO - 2020-09-05 17:24:53 --> Security Class Initialized
DEBUG - 2020-09-05 17:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:24:53 --> Input Class Initialized
INFO - 2020-09-05 17:24:53 --> Language Class Initialized
INFO - 2020-09-05 17:24:53 --> Language Class Initialized
INFO - 2020-09-05 17:24:53 --> Config Class Initialized
INFO - 2020-09-05 17:24:53 --> Loader Class Initialized
INFO - 2020-09-05 17:24:53 --> Helper loaded: url_helper
INFO - 2020-09-05 17:24:53 --> Helper loaded: form_helper
INFO - 2020-09-05 17:24:53 --> Helper loaded: file_helper
INFO - 2020-09-05 17:24:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:24:53 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:24:53 --> Upload Class Initialized
INFO - 2020-09-05 17:24:53 --> Controller Class Initialized
ERROR - 2020-09-05 17:24:53 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:24:54 --> Config Class Initialized
INFO - 2020-09-05 17:24:54 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:24:54 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:24:54 --> Utf8 Class Initialized
INFO - 2020-09-05 17:24:54 --> URI Class Initialized
INFO - 2020-09-05 17:24:54 --> Router Class Initialized
INFO - 2020-09-05 17:24:55 --> Output Class Initialized
INFO - 2020-09-05 17:24:55 --> Security Class Initialized
DEBUG - 2020-09-05 17:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:24:55 --> Input Class Initialized
INFO - 2020-09-05 17:24:55 --> Language Class Initialized
INFO - 2020-09-05 17:24:55 --> Language Class Initialized
INFO - 2020-09-05 17:24:55 --> Config Class Initialized
INFO - 2020-09-05 17:24:55 --> Loader Class Initialized
INFO - 2020-09-05 17:24:55 --> Helper loaded: url_helper
INFO - 2020-09-05 17:24:55 --> Helper loaded: form_helper
INFO - 2020-09-05 17:24:55 --> Helper loaded: file_helper
INFO - 2020-09-05 17:24:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:24:55 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:24:55 --> Upload Class Initialized
INFO - 2020-09-05 17:24:55 --> Controller Class Initialized
ERROR - 2020-09-05 17:24:55 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:30:24 --> Config Class Initialized
INFO - 2020-09-05 17:30:24 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:30:24 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:30:24 --> Utf8 Class Initialized
INFO - 2020-09-05 17:30:24 --> URI Class Initialized
INFO - 2020-09-05 17:30:24 --> Router Class Initialized
INFO - 2020-09-05 17:30:24 --> Output Class Initialized
INFO - 2020-09-05 17:30:24 --> Security Class Initialized
DEBUG - 2020-09-05 17:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:30:24 --> Input Class Initialized
INFO - 2020-09-05 17:30:24 --> Language Class Initialized
INFO - 2020-09-05 17:30:24 --> Language Class Initialized
INFO - 2020-09-05 17:30:24 --> Config Class Initialized
INFO - 2020-09-05 17:30:24 --> Loader Class Initialized
INFO - 2020-09-05 17:30:24 --> Helper loaded: url_helper
INFO - 2020-09-05 17:30:24 --> Helper loaded: form_helper
INFO - 2020-09-05 17:30:24 --> Helper loaded: file_helper
INFO - 2020-09-05 17:30:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:30:24 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:30:24 --> Upload Class Initialized
INFO - 2020-09-05 17:30:25 --> Controller Class Initialized
ERROR - 2020-09-05 17:30:25 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:30:25 --> Config Class Initialized
INFO - 2020-09-05 17:30:25 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:30:25 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:30:25 --> Utf8 Class Initialized
INFO - 2020-09-05 17:30:25 --> URI Class Initialized
INFO - 2020-09-05 17:30:25 --> Router Class Initialized
INFO - 2020-09-05 17:30:25 --> Output Class Initialized
INFO - 2020-09-05 17:30:25 --> Security Class Initialized
DEBUG - 2020-09-05 17:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:30:25 --> Input Class Initialized
INFO - 2020-09-05 17:30:25 --> Language Class Initialized
INFO - 2020-09-05 17:30:25 --> Language Class Initialized
INFO - 2020-09-05 17:30:25 --> Config Class Initialized
INFO - 2020-09-05 17:30:25 --> Loader Class Initialized
INFO - 2020-09-05 17:30:25 --> Helper loaded: url_helper
INFO - 2020-09-05 17:30:25 --> Helper loaded: form_helper
INFO - 2020-09-05 17:30:25 --> Helper loaded: file_helper
INFO - 2020-09-05 17:30:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:30:25 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:30:25 --> Upload Class Initialized
INFO - 2020-09-05 17:30:25 --> Controller Class Initialized
ERROR - 2020-09-05 17:30:25 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:33:04 --> Config Class Initialized
INFO - 2020-09-05 17:33:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:33:04 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:33:04 --> Utf8 Class Initialized
INFO - 2020-09-05 17:33:04 --> URI Class Initialized
DEBUG - 2020-09-05 17:33:04 --> No URI present. Default controller set.
INFO - 2020-09-05 17:33:04 --> Router Class Initialized
INFO - 2020-09-05 17:33:04 --> Output Class Initialized
INFO - 2020-09-05 17:33:04 --> Security Class Initialized
DEBUG - 2020-09-05 17:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:33:04 --> Input Class Initialized
INFO - 2020-09-05 17:33:04 --> Language Class Initialized
INFO - 2020-09-05 17:33:04 --> Language Class Initialized
INFO - 2020-09-05 17:33:04 --> Config Class Initialized
INFO - 2020-09-05 17:33:04 --> Loader Class Initialized
INFO - 2020-09-05 17:33:04 --> Helper loaded: url_helper
INFO - 2020-09-05 17:33:04 --> Helper loaded: form_helper
INFO - 2020-09-05 17:33:04 --> Helper loaded: file_helper
INFO - 2020-09-05 17:33:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:33:04 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:33:04 --> Upload Class Initialized
INFO - 2020-09-05 17:33:05 --> Controller Class Initialized
DEBUG - 2020-09-05 17:33:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 17:33:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 17:33:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 17:33:05 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 17:33:05 --> Final output sent to browser
DEBUG - 2020-09-05 17:33:05 --> Total execution time: 0.1107
INFO - 2020-09-05 17:33:11 --> Config Class Initialized
INFO - 2020-09-05 17:33:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:33:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:33:11 --> Utf8 Class Initialized
INFO - 2020-09-05 17:33:11 --> URI Class Initialized
INFO - 2020-09-05 17:33:11 --> Router Class Initialized
INFO - 2020-09-05 17:33:11 --> Output Class Initialized
INFO - 2020-09-05 17:33:11 --> Security Class Initialized
DEBUG - 2020-09-05 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:33:11 --> Input Class Initialized
INFO - 2020-09-05 17:33:11 --> Language Class Initialized
INFO - 2020-09-05 17:33:11 --> Language Class Initialized
INFO - 2020-09-05 17:33:11 --> Config Class Initialized
INFO - 2020-09-05 17:33:11 --> Loader Class Initialized
INFO - 2020-09-05 17:33:11 --> Helper loaded: url_helper
INFO - 2020-09-05 17:33:11 --> Helper loaded: form_helper
INFO - 2020-09-05 17:33:11 --> Helper loaded: file_helper
INFO - 2020-09-05 17:33:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:33:11 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:33:11 --> Upload Class Initialized
INFO - 2020-09-05 17:33:11 --> Controller Class Initialized
ERROR - 2020-09-05 17:33:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:33:59 --> Config Class Initialized
INFO - 2020-09-05 17:33:59 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:33:59 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:33:59 --> Utf8 Class Initialized
INFO - 2020-09-05 17:33:59 --> URI Class Initialized
INFO - 2020-09-05 17:33:59 --> Router Class Initialized
INFO - 2020-09-05 17:33:59 --> Output Class Initialized
INFO - 2020-09-05 17:33:59 --> Security Class Initialized
DEBUG - 2020-09-05 17:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:33:59 --> Input Class Initialized
INFO - 2020-09-05 17:33:59 --> Language Class Initialized
INFO - 2020-09-05 17:33:59 --> Language Class Initialized
INFO - 2020-09-05 17:33:59 --> Config Class Initialized
INFO - 2020-09-05 17:33:59 --> Loader Class Initialized
INFO - 2020-09-05 17:33:59 --> Helper loaded: url_helper
INFO - 2020-09-05 17:33:59 --> Helper loaded: form_helper
INFO - 2020-09-05 17:33:59 --> Helper loaded: file_helper
INFO - 2020-09-05 17:33:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:33:59 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:33:59 --> Upload Class Initialized
INFO - 2020-09-05 17:33:59 --> Controller Class Initialized
ERROR - 2020-09-05 17:33:59 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:34:16 --> Config Class Initialized
INFO - 2020-09-05 17:34:16 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:34:16 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:34:16 --> Utf8 Class Initialized
INFO - 2020-09-05 17:34:16 --> URI Class Initialized
INFO - 2020-09-05 17:34:16 --> Router Class Initialized
INFO - 2020-09-05 17:34:16 --> Output Class Initialized
INFO - 2020-09-05 17:34:16 --> Security Class Initialized
DEBUG - 2020-09-05 17:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:34:16 --> Input Class Initialized
INFO - 2020-09-05 17:34:16 --> Language Class Initialized
INFO - 2020-09-05 17:34:16 --> Language Class Initialized
INFO - 2020-09-05 17:34:16 --> Config Class Initialized
INFO - 2020-09-05 17:34:16 --> Loader Class Initialized
INFO - 2020-09-05 17:34:16 --> Helper loaded: url_helper
INFO - 2020-09-05 17:34:16 --> Helper loaded: form_helper
INFO - 2020-09-05 17:34:16 --> Helper loaded: file_helper
INFO - 2020-09-05 17:34:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:34:16 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:34:16 --> Upload Class Initialized
INFO - 2020-09-05 17:34:16 --> Controller Class Initialized
ERROR - 2020-09-05 17:34:16 --> 404 Page Not Found: /index
INFO - 2020-09-05 17:37:12 --> Config Class Initialized
INFO - 2020-09-05 17:37:12 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:37:12 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:37:12 --> Utf8 Class Initialized
INFO - 2020-09-05 17:37:12 --> URI Class Initialized
DEBUG - 2020-09-05 17:37:12 --> No URI present. Default controller set.
INFO - 2020-09-05 17:37:12 --> Router Class Initialized
INFO - 2020-09-05 17:37:12 --> Output Class Initialized
INFO - 2020-09-05 17:37:12 --> Security Class Initialized
DEBUG - 2020-09-05 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:37:12 --> Input Class Initialized
INFO - 2020-09-05 17:37:12 --> Language Class Initialized
INFO - 2020-09-05 17:37:12 --> Language Class Initialized
INFO - 2020-09-05 17:37:12 --> Config Class Initialized
INFO - 2020-09-05 17:37:12 --> Loader Class Initialized
INFO - 2020-09-05 17:37:12 --> Helper loaded: url_helper
INFO - 2020-09-05 17:37:12 --> Helper loaded: form_helper
INFO - 2020-09-05 17:37:12 --> Helper loaded: file_helper
INFO - 2020-09-05 17:37:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:37:12 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:37:12 --> Upload Class Initialized
INFO - 2020-09-05 17:37:12 --> Controller Class Initialized
DEBUG - 2020-09-05 17:37:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 17:37:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 17:37:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 17:37:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 17:37:12 --> Final output sent to browser
DEBUG - 2020-09-05 17:37:12 --> Total execution time: 0.0520
INFO - 2020-09-05 17:39:11 --> Config Class Initialized
INFO - 2020-09-05 17:39:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:39:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:39:11 --> Utf8 Class Initialized
INFO - 2020-09-05 17:39:11 --> URI Class Initialized
INFO - 2020-09-05 17:39:11 --> Router Class Initialized
INFO - 2020-09-05 17:39:11 --> Output Class Initialized
INFO - 2020-09-05 17:39:11 --> Security Class Initialized
DEBUG - 2020-09-05 17:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:39:11 --> Input Class Initialized
INFO - 2020-09-05 17:39:11 --> Language Class Initialized
INFO - 2020-09-05 17:39:11 --> Language Class Initialized
INFO - 2020-09-05 17:39:11 --> Config Class Initialized
INFO - 2020-09-05 17:39:11 --> Loader Class Initialized
INFO - 2020-09-05 17:39:11 --> Helper loaded: url_helper
INFO - 2020-09-05 17:39:11 --> Helper loaded: form_helper
INFO - 2020-09-05 17:39:11 --> Helper loaded: file_helper
INFO - 2020-09-05 17:39:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:39:11 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:39:11 --> Upload Class Initialized
INFO - 2020-09-05 17:39:11 --> Controller Class Initialized
DEBUG - 2020-09-05 17:39:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 17:39:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-05 17:39:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 17:39:11 --> Final output sent to browser
DEBUG - 2020-09-05 17:39:11 --> Total execution time: 0.0507
INFO - 2020-09-05 17:41:45 --> Config Class Initialized
INFO - 2020-09-05 17:41:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 17:41:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 17:41:45 --> Utf8 Class Initialized
INFO - 2020-09-05 17:41:45 --> URI Class Initialized
DEBUG - 2020-09-05 17:41:45 --> No URI present. Default controller set.
INFO - 2020-09-05 17:41:45 --> Router Class Initialized
INFO - 2020-09-05 17:41:45 --> Output Class Initialized
INFO - 2020-09-05 17:41:45 --> Security Class Initialized
DEBUG - 2020-09-05 17:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 17:41:45 --> Input Class Initialized
INFO - 2020-09-05 17:41:45 --> Language Class Initialized
INFO - 2020-09-05 17:41:45 --> Language Class Initialized
INFO - 2020-09-05 17:41:45 --> Config Class Initialized
INFO - 2020-09-05 17:41:45 --> Loader Class Initialized
INFO - 2020-09-05 17:41:45 --> Helper loaded: url_helper
INFO - 2020-09-05 17:41:45 --> Helper loaded: form_helper
INFO - 2020-09-05 17:41:45 --> Helper loaded: file_helper
INFO - 2020-09-05 17:41:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 17:41:45 --> Database Driver Class Initialized
DEBUG - 2020-09-05 17:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 17:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 17:41:45 --> Upload Class Initialized
INFO - 2020-09-05 17:41:45 --> Controller Class Initialized
DEBUG - 2020-09-05 17:41:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 17:41:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 17:41:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 17:41:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 17:41:45 --> Final output sent to browser
DEBUG - 2020-09-05 17:41:45 --> Total execution time: 0.0497
INFO - 2020-09-05 18:03:01 --> Config Class Initialized
INFO - 2020-09-05 18:03:01 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:03:01 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:03:01 --> Utf8 Class Initialized
INFO - 2020-09-05 18:03:01 --> URI Class Initialized
INFO - 2020-09-05 18:03:01 --> Router Class Initialized
INFO - 2020-09-05 18:03:01 --> Output Class Initialized
INFO - 2020-09-05 18:03:01 --> Security Class Initialized
DEBUG - 2020-09-05 18:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:03:01 --> Input Class Initialized
INFO - 2020-09-05 18:03:01 --> Language Class Initialized
INFO - 2020-09-05 18:03:01 --> Language Class Initialized
INFO - 2020-09-05 18:03:01 --> Config Class Initialized
INFO - 2020-09-05 18:03:01 --> Loader Class Initialized
INFO - 2020-09-05 18:03:01 --> Helper loaded: url_helper
INFO - 2020-09-05 18:03:01 --> Helper loaded: form_helper
INFO - 2020-09-05 18:03:01 --> Helper loaded: file_helper
INFO - 2020-09-05 18:03:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:03:01 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:03:01 --> Upload Class Initialized
INFO - 2020-09-05 18:03:01 --> Controller Class Initialized
DEBUG - 2020-09-05 18:03:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:03:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 18:03:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:03:01 --> Final output sent to browser
DEBUG - 2020-09-05 18:03:01 --> Total execution time: 0.3045
INFO - 2020-09-05 18:03:07 --> Config Class Initialized
INFO - 2020-09-05 18:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:03:07 --> Utf8 Class Initialized
INFO - 2020-09-05 18:03:07 --> URI Class Initialized
INFO - 2020-09-05 18:03:07 --> Router Class Initialized
INFO - 2020-09-05 18:03:07 --> Output Class Initialized
INFO - 2020-09-05 18:03:07 --> Security Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:03:07 --> Input Class Initialized
INFO - 2020-09-05 18:03:07 --> Language Class Initialized
INFO - 2020-09-05 18:03:07 --> Language Class Initialized
INFO - 2020-09-05 18:03:07 --> Config Class Initialized
INFO - 2020-09-05 18:03:07 --> Loader Class Initialized
INFO - 2020-09-05 18:03:07 --> Helper loaded: url_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: form_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: file_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:03:07 --> Upload Class Initialized
INFO - 2020-09-05 18:03:07 --> Controller Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:03:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 18:03:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:03:07 --> Final output sent to browser
DEBUG - 2020-09-05 18:03:07 --> Total execution time: 0.0492
INFO - 2020-09-05 18:03:07 --> Config Class Initialized
INFO - 2020-09-05 18:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:03:07 --> Utf8 Class Initialized
INFO - 2020-09-05 18:03:07 --> URI Class Initialized
INFO - 2020-09-05 18:03:07 --> Router Class Initialized
INFO - 2020-09-05 18:03:07 --> Output Class Initialized
INFO - 2020-09-05 18:03:07 --> Security Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:03:07 --> Input Class Initialized
INFO - 2020-09-05 18:03:07 --> Language Class Initialized
INFO - 2020-09-05 18:03:07 --> Language Class Initialized
INFO - 2020-09-05 18:03:07 --> Config Class Initialized
INFO - 2020-09-05 18:03:07 --> Loader Class Initialized
INFO - 2020-09-05 18:03:07 --> Helper loaded: url_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: form_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: file_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:03:07 --> Upload Class Initialized
INFO - 2020-09-05 18:03:07 --> Controller Class Initialized
ERROR - 2020-09-05 18:03:07 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:03:07 --> Config Class Initialized
INFO - 2020-09-05 18:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:03:07 --> Utf8 Class Initialized
INFO - 2020-09-05 18:03:07 --> URI Class Initialized
INFO - 2020-09-05 18:03:07 --> Router Class Initialized
INFO - 2020-09-05 18:03:07 --> Output Class Initialized
INFO - 2020-09-05 18:03:07 --> Security Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:03:07 --> Input Class Initialized
INFO - 2020-09-05 18:03:07 --> Language Class Initialized
INFO - 2020-09-05 18:03:07 --> Language Class Initialized
INFO - 2020-09-05 18:03:07 --> Config Class Initialized
INFO - 2020-09-05 18:03:07 --> Loader Class Initialized
INFO - 2020-09-05 18:03:07 --> Helper loaded: url_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: form_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: file_helper
INFO - 2020-09-05 18:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:03:07 --> Upload Class Initialized
INFO - 2020-09-05 18:03:07 --> Controller Class Initialized
ERROR - 2020-09-05 18:03:07 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:03:55 --> Config Class Initialized
INFO - 2020-09-05 18:03:55 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:03:55 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:03:55 --> Utf8 Class Initialized
INFO - 2020-09-05 18:03:55 --> URI Class Initialized
INFO - 2020-09-05 18:03:55 --> Router Class Initialized
INFO - 2020-09-05 18:03:55 --> Output Class Initialized
INFO - 2020-09-05 18:03:55 --> Security Class Initialized
DEBUG - 2020-09-05 18:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:03:55 --> Input Class Initialized
INFO - 2020-09-05 18:03:55 --> Language Class Initialized
INFO - 2020-09-05 18:03:55 --> Language Class Initialized
INFO - 2020-09-05 18:03:55 --> Config Class Initialized
INFO - 2020-09-05 18:03:55 --> Loader Class Initialized
INFO - 2020-09-05 18:03:55 --> Helper loaded: url_helper
INFO - 2020-09-05 18:03:55 --> Helper loaded: form_helper
INFO - 2020-09-05 18:03:55 --> Helper loaded: file_helper
INFO - 2020-09-05 18:03:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:03:55 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:03:55 --> Upload Class Initialized
INFO - 2020-09-05 18:03:55 --> Controller Class Initialized
DEBUG - 2020-09-05 18:03:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:03:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-05 18:03:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:03:55 --> Final output sent to browser
DEBUG - 2020-09-05 18:03:55 --> Total execution time: 0.0507
INFO - 2020-09-05 18:03:56 --> Config Class Initialized
INFO - 2020-09-05 18:03:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:03:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:03:56 --> Utf8 Class Initialized
INFO - 2020-09-05 18:03:56 --> URI Class Initialized
INFO - 2020-09-05 18:03:56 --> Router Class Initialized
INFO - 2020-09-05 18:03:56 --> Output Class Initialized
INFO - 2020-09-05 18:03:56 --> Security Class Initialized
DEBUG - 2020-09-05 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:03:56 --> Input Class Initialized
INFO - 2020-09-05 18:03:56 --> Language Class Initialized
INFO - 2020-09-05 18:03:56 --> Language Class Initialized
INFO - 2020-09-05 18:03:56 --> Config Class Initialized
INFO - 2020-09-05 18:03:56 --> Loader Class Initialized
INFO - 2020-09-05 18:03:56 --> Helper loaded: url_helper
INFO - 2020-09-05 18:03:56 --> Helper loaded: form_helper
INFO - 2020-09-05 18:03:56 --> Helper loaded: file_helper
INFO - 2020-09-05 18:03:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:03:56 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:03:56 --> Upload Class Initialized
INFO - 2020-09-05 18:03:56 --> Controller Class Initialized
ERROR - 2020-09-05 18:03:56 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:04:03 --> Config Class Initialized
INFO - 2020-09-05 18:04:03 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:04:03 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:04:03 --> Utf8 Class Initialized
INFO - 2020-09-05 18:04:03 --> URI Class Initialized
INFO - 2020-09-05 18:04:03 --> Router Class Initialized
INFO - 2020-09-05 18:04:03 --> Output Class Initialized
INFO - 2020-09-05 18:04:03 --> Security Class Initialized
DEBUG - 2020-09-05 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:04:03 --> Input Class Initialized
INFO - 2020-09-05 18:04:03 --> Language Class Initialized
INFO - 2020-09-05 18:04:03 --> Language Class Initialized
INFO - 2020-09-05 18:04:03 --> Config Class Initialized
INFO - 2020-09-05 18:04:03 --> Loader Class Initialized
INFO - 2020-09-05 18:04:03 --> Helper loaded: url_helper
INFO - 2020-09-05 18:04:03 --> Helper loaded: form_helper
INFO - 2020-09-05 18:04:03 --> Helper loaded: file_helper
INFO - 2020-09-05 18:04:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:04:03 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:04:03 --> Upload Class Initialized
INFO - 2020-09-05 18:04:03 --> Controller Class Initialized
DEBUG - 2020-09-05 18:04:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:04:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-05 18:04:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:04:03 --> Final output sent to browser
DEBUG - 2020-09-05 18:04:03 --> Total execution time: 0.0511
INFO - 2020-09-05 18:04:04 --> Config Class Initialized
INFO - 2020-09-05 18:04:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:04:04 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:04:04 --> Utf8 Class Initialized
INFO - 2020-09-05 18:04:04 --> URI Class Initialized
INFO - 2020-09-05 18:04:04 --> Router Class Initialized
INFO - 2020-09-05 18:04:04 --> Output Class Initialized
INFO - 2020-09-05 18:04:04 --> Security Class Initialized
DEBUG - 2020-09-05 18:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:04:04 --> Input Class Initialized
INFO - 2020-09-05 18:04:04 --> Language Class Initialized
INFO - 2020-09-05 18:04:04 --> Language Class Initialized
INFO - 2020-09-05 18:04:04 --> Config Class Initialized
INFO - 2020-09-05 18:04:04 --> Loader Class Initialized
INFO - 2020-09-05 18:04:04 --> Helper loaded: url_helper
INFO - 2020-09-05 18:04:04 --> Helper loaded: form_helper
INFO - 2020-09-05 18:04:04 --> Helper loaded: file_helper
INFO - 2020-09-05 18:04:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:04:04 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:04:04 --> Upload Class Initialized
INFO - 2020-09-05 18:04:04 --> Controller Class Initialized
ERROR - 2020-09-05 18:04:04 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:45:04 --> Config Class Initialized
INFO - 2020-09-05 18:45:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:45:04 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:45:04 --> Utf8 Class Initialized
INFO - 2020-09-05 18:45:04 --> URI Class Initialized
DEBUG - 2020-09-05 18:45:04 --> No URI present. Default controller set.
INFO - 2020-09-05 18:45:04 --> Router Class Initialized
INFO - 2020-09-05 18:45:04 --> Output Class Initialized
INFO - 2020-09-05 18:45:04 --> Security Class Initialized
DEBUG - 2020-09-05 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:45:04 --> Input Class Initialized
INFO - 2020-09-05 18:45:04 --> Language Class Initialized
INFO - 2020-09-05 18:45:04 --> Language Class Initialized
INFO - 2020-09-05 18:45:04 --> Config Class Initialized
INFO - 2020-09-05 18:45:04 --> Loader Class Initialized
INFO - 2020-09-05 18:45:04 --> Helper loaded: url_helper
INFO - 2020-09-05 18:45:04 --> Helper loaded: form_helper
INFO - 2020-09-05 18:45:04 --> Helper loaded: file_helper
INFO - 2020-09-05 18:45:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:45:04 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:45:04 --> Upload Class Initialized
INFO - 2020-09-05 18:45:04 --> Controller Class Initialized
DEBUG - 2020-09-05 18:45:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:45:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 18:45:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 18:45:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:45:04 --> Final output sent to browser
DEBUG - 2020-09-05 18:45:04 --> Total execution time: 0.0741
INFO - 2020-09-05 18:45:14 --> Config Class Initialized
INFO - 2020-09-05 18:45:14 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:45:14 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:45:14 --> Utf8 Class Initialized
INFO - 2020-09-05 18:45:14 --> URI Class Initialized
INFO - 2020-09-05 18:45:14 --> Router Class Initialized
INFO - 2020-09-05 18:45:14 --> Output Class Initialized
INFO - 2020-09-05 18:45:14 --> Security Class Initialized
DEBUG - 2020-09-05 18:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:45:14 --> Input Class Initialized
INFO - 2020-09-05 18:45:14 --> Language Class Initialized
INFO - 2020-09-05 18:45:14 --> Language Class Initialized
INFO - 2020-09-05 18:45:14 --> Config Class Initialized
INFO - 2020-09-05 18:45:14 --> Loader Class Initialized
INFO - 2020-09-05 18:45:14 --> Helper loaded: url_helper
INFO - 2020-09-05 18:45:14 --> Helper loaded: form_helper
INFO - 2020-09-05 18:45:14 --> Helper loaded: file_helper
INFO - 2020-09-05 18:45:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:45:14 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:45:14 --> Upload Class Initialized
INFO - 2020-09-05 18:45:14 --> Controller Class Initialized
ERROR - 2020-09-05 18:45:14 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:45:37 --> Config Class Initialized
INFO - 2020-09-05 18:45:37 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:45:37 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:45:37 --> Utf8 Class Initialized
INFO - 2020-09-05 18:45:37 --> URI Class Initialized
INFO - 2020-09-05 18:45:37 --> Router Class Initialized
INFO - 2020-09-05 18:45:37 --> Output Class Initialized
INFO - 2020-09-05 18:45:37 --> Security Class Initialized
DEBUG - 2020-09-05 18:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:45:37 --> Input Class Initialized
INFO - 2020-09-05 18:45:37 --> Language Class Initialized
INFO - 2020-09-05 18:45:37 --> Language Class Initialized
INFO - 2020-09-05 18:45:37 --> Config Class Initialized
INFO - 2020-09-05 18:45:37 --> Loader Class Initialized
INFO - 2020-09-05 18:45:37 --> Helper loaded: url_helper
INFO - 2020-09-05 18:45:37 --> Helper loaded: form_helper
INFO - 2020-09-05 18:45:37 --> Helper loaded: file_helper
INFO - 2020-09-05 18:45:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:45:37 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:45:37 --> Upload Class Initialized
INFO - 2020-09-05 18:45:37 --> Controller Class Initialized
DEBUG - 2020-09-05 18:45:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:45:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 18:45:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:45:37 --> Final output sent to browser
DEBUG - 2020-09-05 18:45:37 --> Total execution time: 0.0555
INFO - 2020-09-05 18:45:38 --> Config Class Initialized
INFO - 2020-09-05 18:45:38 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:45:38 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:45:38 --> Utf8 Class Initialized
INFO - 2020-09-05 18:45:38 --> URI Class Initialized
INFO - 2020-09-05 18:45:38 --> Router Class Initialized
INFO - 2020-09-05 18:45:38 --> Output Class Initialized
INFO - 2020-09-05 18:45:38 --> Security Class Initialized
DEBUG - 2020-09-05 18:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:45:38 --> Input Class Initialized
INFO - 2020-09-05 18:45:38 --> Language Class Initialized
INFO - 2020-09-05 18:45:38 --> Language Class Initialized
INFO - 2020-09-05 18:45:38 --> Config Class Initialized
INFO - 2020-09-05 18:45:38 --> Loader Class Initialized
INFO - 2020-09-05 18:45:38 --> Helper loaded: url_helper
INFO - 2020-09-05 18:45:38 --> Helper loaded: form_helper
INFO - 2020-09-05 18:45:38 --> Helper loaded: file_helper
INFO - 2020-09-05 18:45:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:45:38 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:45:38 --> Upload Class Initialized
INFO - 2020-09-05 18:45:38 --> Controller Class Initialized
ERROR - 2020-09-05 18:45:38 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:47:10 --> Config Class Initialized
INFO - 2020-09-05 18:47:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:47:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:47:10 --> Utf8 Class Initialized
INFO - 2020-09-05 18:47:10 --> URI Class Initialized
INFO - 2020-09-05 18:47:10 --> Router Class Initialized
INFO - 2020-09-05 18:47:10 --> Output Class Initialized
INFO - 2020-09-05 18:47:10 --> Security Class Initialized
DEBUG - 2020-09-05 18:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:47:10 --> Input Class Initialized
INFO - 2020-09-05 18:47:10 --> Language Class Initialized
INFO - 2020-09-05 18:47:10 --> Language Class Initialized
INFO - 2020-09-05 18:47:10 --> Config Class Initialized
INFO - 2020-09-05 18:47:10 --> Loader Class Initialized
INFO - 2020-09-05 18:47:10 --> Helper loaded: url_helper
INFO - 2020-09-05 18:47:10 --> Helper loaded: form_helper
INFO - 2020-09-05 18:47:10 --> Helper loaded: file_helper
INFO - 2020-09-05 18:47:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:47:10 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:47:10 --> Upload Class Initialized
INFO - 2020-09-05 18:47:10 --> Controller Class Initialized
DEBUG - 2020-09-05 18:47:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:47:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 18:47:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:47:10 --> Final output sent to browser
DEBUG - 2020-09-05 18:47:10 --> Total execution time: 0.0512
INFO - 2020-09-05 18:47:14 --> Config Class Initialized
INFO - 2020-09-05 18:47:14 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:47:14 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:47:14 --> Utf8 Class Initialized
INFO - 2020-09-05 18:47:14 --> URI Class Initialized
INFO - 2020-09-05 18:47:14 --> Router Class Initialized
INFO - 2020-09-05 18:47:14 --> Output Class Initialized
INFO - 2020-09-05 18:47:14 --> Security Class Initialized
DEBUG - 2020-09-05 18:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:47:14 --> Input Class Initialized
INFO - 2020-09-05 18:47:14 --> Language Class Initialized
INFO - 2020-09-05 18:47:14 --> Language Class Initialized
INFO - 2020-09-05 18:47:14 --> Config Class Initialized
INFO - 2020-09-05 18:47:14 --> Loader Class Initialized
INFO - 2020-09-05 18:47:14 --> Helper loaded: url_helper
INFO - 2020-09-05 18:47:14 --> Helper loaded: form_helper
INFO - 2020-09-05 18:47:14 --> Helper loaded: file_helper
INFO - 2020-09-05 18:47:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:47:14 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:47:14 --> Upload Class Initialized
INFO - 2020-09-05 18:47:14 --> Controller Class Initialized
ERROR - 2020-09-05 18:47:14 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:48:08 --> Config Class Initialized
INFO - 2020-09-05 18:48:08 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:48:08 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:48:08 --> Utf8 Class Initialized
INFO - 2020-09-05 18:48:08 --> URI Class Initialized
INFO - 2020-09-05 18:48:08 --> Router Class Initialized
INFO - 2020-09-05 18:48:08 --> Output Class Initialized
INFO - 2020-09-05 18:48:08 --> Security Class Initialized
DEBUG - 2020-09-05 18:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:48:08 --> Input Class Initialized
INFO - 2020-09-05 18:48:08 --> Language Class Initialized
INFO - 2020-09-05 18:48:08 --> Language Class Initialized
INFO - 2020-09-05 18:48:08 --> Config Class Initialized
INFO - 2020-09-05 18:48:08 --> Loader Class Initialized
INFO - 2020-09-05 18:48:08 --> Helper loaded: url_helper
INFO - 2020-09-05 18:48:08 --> Helper loaded: form_helper
INFO - 2020-09-05 18:48:08 --> Helper loaded: file_helper
INFO - 2020-09-05 18:48:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:48:08 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:48:08 --> Upload Class Initialized
INFO - 2020-09-05 18:48:08 --> Controller Class Initialized
DEBUG - 2020-09-05 18:48:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:48:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 18:48:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:48:08 --> Final output sent to browser
DEBUG - 2020-09-05 18:48:08 --> Total execution time: 0.0491
INFO - 2020-09-05 18:48:11 --> Config Class Initialized
INFO - 2020-09-05 18:48:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:48:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:48:11 --> Utf8 Class Initialized
INFO - 2020-09-05 18:48:11 --> URI Class Initialized
INFO - 2020-09-05 18:48:11 --> Router Class Initialized
INFO - 2020-09-05 18:48:11 --> Output Class Initialized
INFO - 2020-09-05 18:48:11 --> Security Class Initialized
DEBUG - 2020-09-05 18:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:48:11 --> Input Class Initialized
INFO - 2020-09-05 18:48:11 --> Language Class Initialized
INFO - 2020-09-05 18:48:11 --> Language Class Initialized
INFO - 2020-09-05 18:48:11 --> Config Class Initialized
INFO - 2020-09-05 18:48:11 --> Loader Class Initialized
INFO - 2020-09-05 18:48:11 --> Helper loaded: url_helper
INFO - 2020-09-05 18:48:11 --> Helper loaded: form_helper
INFO - 2020-09-05 18:48:11 --> Helper loaded: file_helper
INFO - 2020-09-05 18:48:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:48:12 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:48:12 --> Upload Class Initialized
INFO - 2020-09-05 18:48:12 --> Controller Class Initialized
ERROR - 2020-09-05 18:48:12 --> 404 Page Not Found: /index
INFO - 2020-09-05 18:49:50 --> Config Class Initialized
INFO - 2020-09-05 18:49:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:50 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:50 --> URI Class Initialized
DEBUG - 2020-09-05 18:49:50 --> No URI present. Default controller set.
INFO - 2020-09-05 18:49:50 --> Router Class Initialized
INFO - 2020-09-05 18:49:50 --> Output Class Initialized
INFO - 2020-09-05 18:49:50 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:50 --> Input Class Initialized
INFO - 2020-09-05 18:49:50 --> Language Class Initialized
INFO - 2020-09-05 18:49:50 --> Language Class Initialized
INFO - 2020-09-05 18:49:50 --> Config Class Initialized
INFO - 2020-09-05 18:49:50 --> Loader Class Initialized
INFO - 2020-09-05 18:49:50 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:50 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:50 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:50 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:50 --> Upload Class Initialized
INFO - 2020-09-05 18:49:50 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 18:49:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 18:49:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:50 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:50 --> Total execution time: 0.0637
INFO - 2020-09-05 18:49:51 --> Config Class Initialized
INFO - 2020-09-05 18:49:51 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:51 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:51 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:51 --> URI Class Initialized
INFO - 2020-09-05 18:49:51 --> Router Class Initialized
INFO - 2020-09-05 18:49:51 --> Output Class Initialized
INFO - 2020-09-05 18:49:51 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:51 --> Input Class Initialized
INFO - 2020-09-05 18:49:51 --> Language Class Initialized
INFO - 2020-09-05 18:49:51 --> Language Class Initialized
INFO - 2020-09-05 18:49:51 --> Config Class Initialized
INFO - 2020-09-05 18:49:51 --> Loader Class Initialized
INFO - 2020-09-05 18:49:51 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:51 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:51 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:51 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:51 --> Upload Class Initialized
INFO - 2020-09-05 18:49:51 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-05 18:49:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:51 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:51 --> Total execution time: 0.0486
INFO - 2020-09-05 18:49:52 --> Config Class Initialized
INFO - 2020-09-05 18:49:52 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:52 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:52 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:52 --> URI Class Initialized
INFO - 2020-09-05 18:49:52 --> Router Class Initialized
INFO - 2020-09-05 18:49:52 --> Output Class Initialized
INFO - 2020-09-05 18:49:52 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:52 --> Input Class Initialized
INFO - 2020-09-05 18:49:52 --> Language Class Initialized
INFO - 2020-09-05 18:49:52 --> Language Class Initialized
INFO - 2020-09-05 18:49:52 --> Config Class Initialized
INFO - 2020-09-05 18:49:52 --> Loader Class Initialized
INFO - 2020-09-05 18:49:52 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:52 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:52 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:52 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:52 --> Upload Class Initialized
INFO - 2020-09-05 18:49:52 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 18:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 18:49:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:52 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:52 --> Total execution time: 0.0492
INFO - 2020-09-05 18:49:53 --> Config Class Initialized
INFO - 2020-09-05 18:49:53 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:53 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:53 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:53 --> URI Class Initialized
INFO - 2020-09-05 18:49:53 --> Router Class Initialized
INFO - 2020-09-05 18:49:53 --> Output Class Initialized
INFO - 2020-09-05 18:49:53 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:53 --> Input Class Initialized
INFO - 2020-09-05 18:49:53 --> Language Class Initialized
INFO - 2020-09-05 18:49:53 --> Language Class Initialized
INFO - 2020-09-05 18:49:53 --> Config Class Initialized
INFO - 2020-09-05 18:49:53 --> Loader Class Initialized
INFO - 2020-09-05 18:49:53 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:53 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:53 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:53 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:53 --> Upload Class Initialized
INFO - 2020-09-05 18:49:53 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-05 18:49:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:53 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:53 --> Total execution time: 0.0510
INFO - 2020-09-05 18:49:54 --> Config Class Initialized
INFO - 2020-09-05 18:49:54 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:54 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:54 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:54 --> URI Class Initialized
INFO - 2020-09-05 18:49:54 --> Router Class Initialized
INFO - 2020-09-05 18:49:54 --> Output Class Initialized
INFO - 2020-09-05 18:49:54 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:54 --> Input Class Initialized
INFO - 2020-09-05 18:49:54 --> Language Class Initialized
INFO - 2020-09-05 18:49:54 --> Language Class Initialized
INFO - 2020-09-05 18:49:54 --> Config Class Initialized
INFO - 2020-09-05 18:49:54 --> Loader Class Initialized
INFO - 2020-09-05 18:49:54 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:54 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:54 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:54 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:54 --> Upload Class Initialized
INFO - 2020-09-05 18:49:54 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 18:49:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 18:49:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:54 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:54 --> Total execution time: 0.0496
INFO - 2020-09-05 18:49:55 --> Config Class Initialized
INFO - 2020-09-05 18:49:55 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:55 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:55 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:55 --> URI Class Initialized
INFO - 2020-09-05 18:49:55 --> Router Class Initialized
INFO - 2020-09-05 18:49:55 --> Output Class Initialized
INFO - 2020-09-05 18:49:55 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:55 --> Input Class Initialized
INFO - 2020-09-05 18:49:55 --> Language Class Initialized
INFO - 2020-09-05 18:49:55 --> Language Class Initialized
INFO - 2020-09-05 18:49:55 --> Config Class Initialized
INFO - 2020-09-05 18:49:55 --> Loader Class Initialized
INFO - 2020-09-05 18:49:55 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:55 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:55 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:55 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:55 --> Upload Class Initialized
INFO - 2020-09-05 18:49:55 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-05 18:49:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:55 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:55 --> Total execution time: 0.0504
INFO - 2020-09-05 18:49:56 --> Config Class Initialized
INFO - 2020-09-05 18:49:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:56 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:56 --> URI Class Initialized
INFO - 2020-09-05 18:49:56 --> Router Class Initialized
INFO - 2020-09-05 18:49:56 --> Output Class Initialized
INFO - 2020-09-05 18:49:56 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:56 --> Input Class Initialized
INFO - 2020-09-05 18:49:56 --> Language Class Initialized
INFO - 2020-09-05 18:49:56 --> Language Class Initialized
INFO - 2020-09-05 18:49:56 --> Config Class Initialized
INFO - 2020-09-05 18:49:56 --> Loader Class Initialized
INFO - 2020-09-05 18:49:56 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:56 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:56 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:56 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:56 --> Upload Class Initialized
INFO - 2020-09-05 18:49:56 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 18:49:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 18:49:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:56 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:56 --> Total execution time: 0.0531
INFO - 2020-09-05 18:49:57 --> Config Class Initialized
INFO - 2020-09-05 18:49:57 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:49:57 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:49:57 --> Utf8 Class Initialized
INFO - 2020-09-05 18:49:57 --> URI Class Initialized
INFO - 2020-09-05 18:49:57 --> Router Class Initialized
INFO - 2020-09-05 18:49:57 --> Output Class Initialized
INFO - 2020-09-05 18:49:57 --> Security Class Initialized
DEBUG - 2020-09-05 18:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:49:57 --> Input Class Initialized
INFO - 2020-09-05 18:49:57 --> Language Class Initialized
INFO - 2020-09-05 18:49:57 --> Language Class Initialized
INFO - 2020-09-05 18:49:57 --> Config Class Initialized
INFO - 2020-09-05 18:49:57 --> Loader Class Initialized
INFO - 2020-09-05 18:49:57 --> Helper loaded: url_helper
INFO - 2020-09-05 18:49:57 --> Helper loaded: form_helper
INFO - 2020-09-05 18:49:57 --> Helper loaded: file_helper
INFO - 2020-09-05 18:49:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:49:57 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:49:57 --> Upload Class Initialized
INFO - 2020-09-05 18:49:57 --> Controller Class Initialized
DEBUG - 2020-09-05 18:49:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:49:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-05 18:49:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:49:57 --> Final output sent to browser
DEBUG - 2020-09-05 18:49:57 --> Total execution time: 0.0541
INFO - 2020-09-05 18:59:23 --> Config Class Initialized
INFO - 2020-09-05 18:59:23 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:59:23 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:59:23 --> Utf8 Class Initialized
INFO - 2020-09-05 18:59:23 --> URI Class Initialized
INFO - 2020-09-05 18:59:23 --> Router Class Initialized
INFO - 2020-09-05 18:59:23 --> Output Class Initialized
INFO - 2020-09-05 18:59:23 --> Security Class Initialized
DEBUG - 2020-09-05 18:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:59:23 --> Input Class Initialized
INFO - 2020-09-05 18:59:23 --> Language Class Initialized
INFO - 2020-09-05 18:59:23 --> Language Class Initialized
INFO - 2020-09-05 18:59:23 --> Config Class Initialized
INFO - 2020-09-05 18:59:23 --> Loader Class Initialized
INFO - 2020-09-05 18:59:23 --> Helper loaded: url_helper
INFO - 2020-09-05 18:59:23 --> Helper loaded: form_helper
INFO - 2020-09-05 18:59:23 --> Helper loaded: file_helper
INFO - 2020-09-05 18:59:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:59:23 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:59:23 --> Upload Class Initialized
INFO - 2020-09-05 18:59:23 --> Controller Class Initialized
DEBUG - 2020-09-05 18:59:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 18:59:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 18:59:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 18:59:23 --> Final output sent to browser
DEBUG - 2020-09-05 18:59:23 --> Total execution time: 0.0644
INFO - 2020-09-05 18:59:31 --> Config Class Initialized
INFO - 2020-09-05 18:59:31 --> Hooks Class Initialized
DEBUG - 2020-09-05 18:59:31 --> UTF-8 Support Enabled
INFO - 2020-09-05 18:59:31 --> Utf8 Class Initialized
INFO - 2020-09-05 18:59:31 --> URI Class Initialized
INFO - 2020-09-05 18:59:31 --> Router Class Initialized
INFO - 2020-09-05 18:59:31 --> Output Class Initialized
INFO - 2020-09-05 18:59:31 --> Security Class Initialized
DEBUG - 2020-09-05 18:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 18:59:31 --> Input Class Initialized
INFO - 2020-09-05 18:59:31 --> Language Class Initialized
INFO - 2020-09-05 18:59:31 --> Language Class Initialized
INFO - 2020-09-05 18:59:31 --> Config Class Initialized
INFO - 2020-09-05 18:59:31 --> Loader Class Initialized
INFO - 2020-09-05 18:59:31 --> Helper loaded: url_helper
INFO - 2020-09-05 18:59:31 --> Helper loaded: form_helper
INFO - 2020-09-05 18:59:31 --> Helper loaded: file_helper
INFO - 2020-09-05 18:59:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 18:59:31 --> Database Driver Class Initialized
DEBUG - 2020-09-05 18:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 18:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 18:59:31 --> Upload Class Initialized
INFO - 2020-09-05 18:59:31 --> Controller Class Initialized
ERROR - 2020-09-05 18:59:31 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:04:07 --> Config Class Initialized
INFO - 2020-09-05 19:04:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:07 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:07 --> URI Class Initialized
INFO - 2020-09-05 19:04:07 --> Router Class Initialized
INFO - 2020-09-05 19:04:07 --> Output Class Initialized
INFO - 2020-09-05 19:04:07 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:07 --> Input Class Initialized
INFO - 2020-09-05 19:04:07 --> Language Class Initialized
INFO - 2020-09-05 19:04:07 --> Language Class Initialized
INFO - 2020-09-05 19:04:07 --> Config Class Initialized
INFO - 2020-09-05 19:04:07 --> Loader Class Initialized
INFO - 2020-09-05 19:04:07 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:07 --> Helper loaded: form_helper
INFO - 2020-09-05 19:04:07 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:04:08 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:04:08 --> Upload Class Initialized
INFO - 2020-09-05 19:04:08 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 19:04:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 19:04:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 19:04:08 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:08 --> Total execution time: 0.0483
INFO - 2020-09-05 19:04:19 --> Config Class Initialized
INFO - 2020-09-05 19:04:19 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:19 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:19 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:19 --> URI Class Initialized
INFO - 2020-09-05 19:04:19 --> Router Class Initialized
INFO - 2020-09-05 19:04:19 --> Output Class Initialized
INFO - 2020-09-05 19:04:19 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:19 --> Input Class Initialized
INFO - 2020-09-05 19:04:19 --> Language Class Initialized
INFO - 2020-09-05 19:04:19 --> Language Class Initialized
INFO - 2020-09-05 19:04:19 --> Config Class Initialized
INFO - 2020-09-05 19:04:19 --> Loader Class Initialized
INFO - 2020-09-05 19:04:19 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:19 --> Helper loaded: form_helper
INFO - 2020-09-05 19:04:19 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:04:19 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:04:19 --> Upload Class Initialized
INFO - 2020-09-05 19:04:19 --> Controller Class Initialized
ERROR - 2020-09-05 19:04:19 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:04:24 --> Config Class Initialized
INFO - 2020-09-05 19:04:24 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:24 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:24 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:24 --> URI Class Initialized
INFO - 2020-09-05 19:04:24 --> Router Class Initialized
INFO - 2020-09-05 19:04:24 --> Output Class Initialized
INFO - 2020-09-05 19:04:24 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:24 --> Input Class Initialized
INFO - 2020-09-05 19:04:24 --> Language Class Initialized
INFO - 2020-09-05 19:04:24 --> Language Class Initialized
INFO - 2020-09-05 19:04:24 --> Config Class Initialized
INFO - 2020-09-05 19:04:24 --> Loader Class Initialized
INFO - 2020-09-05 19:04:24 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:24 --> Helper loaded: form_helper
INFO - 2020-09-05 19:04:24 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:04:24 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:04:24 --> Upload Class Initialized
INFO - 2020-09-05 19:04:24 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 19:04:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 19:04:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 19:04:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 19:04:24 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:24 --> Total execution time: 0.0514
INFO - 2020-09-05 19:04:48 --> Config Class Initialized
INFO - 2020-09-05 19:04:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:48 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:48 --> URI Class Initialized
INFO - 2020-09-05 19:04:48 --> Router Class Initialized
INFO - 2020-09-05 19:04:48 --> Output Class Initialized
INFO - 2020-09-05 19:04:48 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:48 --> Input Class Initialized
INFO - 2020-09-05 19:04:48 --> Language Class Initialized
INFO - 2020-09-05 19:04:48 --> Language Class Initialized
INFO - 2020-09-05 19:04:48 --> Config Class Initialized
INFO - 2020-09-05 19:04:48 --> Loader Class Initialized
INFO - 2020-09-05 19:04:48 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:48 --> Helper loaded: form_helper
INFO - 2020-09-05 19:04:48 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:04:48 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:04:48 --> Upload Class Initialized
INFO - 2020-09-05 19:04:48 --> Controller Class Initialized
DEBUG - 2020-09-05 19:04:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 19:04:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-05 19:04:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 19:04:48 --> Final output sent to browser
DEBUG - 2020-09-05 19:04:48 --> Total execution time: 0.0571
INFO - 2020-09-05 19:04:50 --> Config Class Initialized
INFO - 2020-09-05 19:04:50 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:04:50 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:04:50 --> Utf8 Class Initialized
INFO - 2020-09-05 19:04:50 --> URI Class Initialized
INFO - 2020-09-05 19:04:50 --> Router Class Initialized
INFO - 2020-09-05 19:04:50 --> Output Class Initialized
INFO - 2020-09-05 19:04:50 --> Security Class Initialized
DEBUG - 2020-09-05 19:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:04:50 --> Input Class Initialized
INFO - 2020-09-05 19:04:50 --> Language Class Initialized
INFO - 2020-09-05 19:04:50 --> Language Class Initialized
INFO - 2020-09-05 19:04:50 --> Config Class Initialized
INFO - 2020-09-05 19:04:50 --> Loader Class Initialized
INFO - 2020-09-05 19:04:50 --> Helper loaded: url_helper
INFO - 2020-09-05 19:04:50 --> Helper loaded: form_helper
INFO - 2020-09-05 19:04:50 --> Helper loaded: file_helper
INFO - 2020-09-05 19:04:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:04:50 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:04:50 --> Upload Class Initialized
INFO - 2020-09-05 19:04:50 --> Controller Class Initialized
ERROR - 2020-09-05 19:04:50 --> 404 Page Not Found: /index
INFO - 2020-09-05 19:23:42 --> Config Class Initialized
INFO - 2020-09-05 19:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:23:42 --> Utf8 Class Initialized
INFO - 2020-09-05 19:23:42 --> URI Class Initialized
DEBUG - 2020-09-05 19:23:42 --> No URI present. Default controller set.
INFO - 2020-09-05 19:23:42 --> Router Class Initialized
INFO - 2020-09-05 19:23:42 --> Output Class Initialized
INFO - 2020-09-05 19:23:42 --> Security Class Initialized
DEBUG - 2020-09-05 19:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:23:42 --> Input Class Initialized
INFO - 2020-09-05 19:23:42 --> Language Class Initialized
INFO - 2020-09-05 19:23:42 --> Language Class Initialized
INFO - 2020-09-05 19:23:42 --> Config Class Initialized
INFO - 2020-09-05 19:23:42 --> Loader Class Initialized
INFO - 2020-09-05 19:23:42 --> Helper loaded: url_helper
INFO - 2020-09-05 19:23:42 --> Helper loaded: form_helper
INFO - 2020-09-05 19:23:42 --> Helper loaded: file_helper
INFO - 2020-09-05 19:23:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:23:42 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:23:42 --> Upload Class Initialized
INFO - 2020-09-05 19:23:42 --> Controller Class Initialized
DEBUG - 2020-09-05 19:23:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 19:23:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 19:23:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 19:23:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 19:23:42 --> Final output sent to browser
DEBUG - 2020-09-05 19:23:42 --> Total execution time: 0.0515
INFO - 2020-09-05 19:23:43 --> Config Class Initialized
INFO - 2020-09-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:23:43 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:23:43 --> Utf8 Class Initialized
INFO - 2020-09-05 19:23:43 --> URI Class Initialized
DEBUG - 2020-09-05 19:23:43 --> No URI present. Default controller set.
INFO - 2020-09-05 19:23:43 --> Router Class Initialized
INFO - 2020-09-05 19:23:43 --> Output Class Initialized
INFO - 2020-09-05 19:23:43 --> Security Class Initialized
DEBUG - 2020-09-05 19:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:23:43 --> Input Class Initialized
INFO - 2020-09-05 19:23:43 --> Language Class Initialized
INFO - 2020-09-05 19:23:43 --> Language Class Initialized
INFO - 2020-09-05 19:23:43 --> Config Class Initialized
INFO - 2020-09-05 19:23:43 --> Loader Class Initialized
INFO - 2020-09-05 19:23:43 --> Helper loaded: url_helper
INFO - 2020-09-05 19:23:43 --> Helper loaded: form_helper
INFO - 2020-09-05 19:23:43 --> Helper loaded: file_helper
INFO - 2020-09-05 19:23:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:23:43 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:23:43 --> Upload Class Initialized
INFO - 2020-09-05 19:23:43 --> Controller Class Initialized
DEBUG - 2020-09-05 19:23:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 19:23:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 19:23:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 19:23:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 19:23:43 --> Final output sent to browser
DEBUG - 2020-09-05 19:23:43 --> Total execution time: 0.0497
INFO - 2020-09-05 19:39:13 --> Config Class Initialized
INFO - 2020-09-05 19:39:13 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:39:13 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:39:13 --> Utf8 Class Initialized
INFO - 2020-09-05 19:39:13 --> URI Class Initialized
DEBUG - 2020-09-05 19:39:13 --> No URI present. Default controller set.
INFO - 2020-09-05 19:39:13 --> Router Class Initialized
INFO - 2020-09-05 19:39:13 --> Output Class Initialized
INFO - 2020-09-05 19:39:13 --> Security Class Initialized
DEBUG - 2020-09-05 19:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:39:13 --> Input Class Initialized
INFO - 2020-09-05 19:39:13 --> Language Class Initialized
INFO - 2020-09-05 19:39:13 --> Language Class Initialized
INFO - 2020-09-05 19:39:13 --> Config Class Initialized
INFO - 2020-09-05 19:39:13 --> Loader Class Initialized
INFO - 2020-09-05 19:39:13 --> Helper loaded: url_helper
INFO - 2020-09-05 19:39:13 --> Helper loaded: form_helper
INFO - 2020-09-05 19:39:13 --> Helper loaded: file_helper
INFO - 2020-09-05 19:39:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:39:13 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:39:13 --> Upload Class Initialized
INFO - 2020-09-05 19:39:13 --> Controller Class Initialized
DEBUG - 2020-09-05 19:39:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 19:39:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 19:39:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 19:39:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 19:39:13 --> Final output sent to browser
DEBUG - 2020-09-05 19:39:13 --> Total execution time: 0.0526
INFO - 2020-09-05 19:39:18 --> Config Class Initialized
INFO - 2020-09-05 19:39:18 --> Hooks Class Initialized
DEBUG - 2020-09-05 19:39:18 --> UTF-8 Support Enabled
INFO - 2020-09-05 19:39:18 --> Utf8 Class Initialized
INFO - 2020-09-05 19:39:18 --> URI Class Initialized
INFO - 2020-09-05 19:39:18 --> Router Class Initialized
INFO - 2020-09-05 19:39:18 --> Output Class Initialized
INFO - 2020-09-05 19:39:18 --> Security Class Initialized
DEBUG - 2020-09-05 19:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 19:39:18 --> Input Class Initialized
INFO - 2020-09-05 19:39:18 --> Language Class Initialized
INFO - 2020-09-05 19:39:18 --> Language Class Initialized
INFO - 2020-09-05 19:39:18 --> Config Class Initialized
INFO - 2020-09-05 19:39:18 --> Loader Class Initialized
INFO - 2020-09-05 19:39:18 --> Helper loaded: url_helper
INFO - 2020-09-05 19:39:18 --> Helper loaded: form_helper
INFO - 2020-09-05 19:39:18 --> Helper loaded: file_helper
INFO - 2020-09-05 19:39:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 19:39:18 --> Database Driver Class Initialized
DEBUG - 2020-09-05 19:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 19:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 19:39:18 --> Upload Class Initialized
INFO - 2020-09-05 19:39:18 --> Controller Class Initialized
ERROR - 2020-09-05 19:39:18 --> 404 Page Not Found: /index
INFO - 2020-09-05 20:03:17 --> Config Class Initialized
INFO - 2020-09-05 20:03:17 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:03:17 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:03:17 --> Utf8 Class Initialized
INFO - 2020-09-05 20:03:17 --> URI Class Initialized
DEBUG - 2020-09-05 20:03:17 --> No URI present. Default controller set.
INFO - 2020-09-05 20:03:17 --> Router Class Initialized
INFO - 2020-09-05 20:03:17 --> Output Class Initialized
INFO - 2020-09-05 20:03:17 --> Security Class Initialized
DEBUG - 2020-09-05 20:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:03:17 --> Input Class Initialized
INFO - 2020-09-05 20:03:17 --> Language Class Initialized
INFO - 2020-09-05 20:03:17 --> Language Class Initialized
INFO - 2020-09-05 20:03:17 --> Config Class Initialized
INFO - 2020-09-05 20:03:17 --> Loader Class Initialized
INFO - 2020-09-05 20:03:17 --> Helper loaded: url_helper
INFO - 2020-09-05 20:03:17 --> Helper loaded: form_helper
INFO - 2020-09-05 20:03:17 --> Helper loaded: file_helper
INFO - 2020-09-05 20:03:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:03:17 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:03:17 --> Upload Class Initialized
INFO - 2020-09-05 20:03:17 --> Controller Class Initialized
DEBUG - 2020-09-05 20:03:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 20:03:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 20:03:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 20:03:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 20:03:17 --> Final output sent to browser
DEBUG - 2020-09-05 20:03:17 --> Total execution time: 0.0510
INFO - 2020-09-05 20:03:23 --> Config Class Initialized
INFO - 2020-09-05 20:03:23 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:03:23 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:03:23 --> Utf8 Class Initialized
INFO - 2020-09-05 20:03:23 --> URI Class Initialized
INFO - 2020-09-05 20:03:23 --> Router Class Initialized
INFO - 2020-09-05 20:03:23 --> Output Class Initialized
INFO - 2020-09-05 20:03:23 --> Security Class Initialized
DEBUG - 2020-09-05 20:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:03:23 --> Input Class Initialized
INFO - 2020-09-05 20:03:23 --> Language Class Initialized
INFO - 2020-09-05 20:03:23 --> Language Class Initialized
INFO - 2020-09-05 20:03:23 --> Config Class Initialized
INFO - 2020-09-05 20:03:23 --> Loader Class Initialized
INFO - 2020-09-05 20:03:23 --> Helper loaded: url_helper
INFO - 2020-09-05 20:03:23 --> Helper loaded: form_helper
INFO - 2020-09-05 20:03:23 --> Helper loaded: file_helper
INFO - 2020-09-05 20:03:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:03:23 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:03:23 --> Upload Class Initialized
INFO - 2020-09-05 20:03:23 --> Controller Class Initialized
ERROR - 2020-09-05 20:03:23 --> 404 Page Not Found: /index
INFO - 2020-09-05 20:03:33 --> Config Class Initialized
INFO - 2020-09-05 20:03:33 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:03:33 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:03:33 --> Utf8 Class Initialized
INFO - 2020-09-05 20:03:33 --> URI Class Initialized
DEBUG - 2020-09-05 20:03:33 --> No URI present. Default controller set.
INFO - 2020-09-05 20:03:33 --> Router Class Initialized
INFO - 2020-09-05 20:03:33 --> Output Class Initialized
INFO - 2020-09-05 20:03:33 --> Security Class Initialized
DEBUG - 2020-09-05 20:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:03:33 --> Input Class Initialized
INFO - 2020-09-05 20:03:33 --> Language Class Initialized
INFO - 2020-09-05 20:03:33 --> Language Class Initialized
INFO - 2020-09-05 20:03:33 --> Config Class Initialized
INFO - 2020-09-05 20:03:33 --> Loader Class Initialized
INFO - 2020-09-05 20:03:33 --> Helper loaded: url_helper
INFO - 2020-09-05 20:03:33 --> Helper loaded: form_helper
INFO - 2020-09-05 20:03:33 --> Helper loaded: file_helper
INFO - 2020-09-05 20:03:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:03:33 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:03:33 --> Upload Class Initialized
INFO - 2020-09-05 20:03:33 --> Controller Class Initialized
DEBUG - 2020-09-05 20:03:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 20:03:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 20:03:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 20:03:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 20:03:33 --> Final output sent to browser
DEBUG - 2020-09-05 20:03:33 --> Total execution time: 0.0505
INFO - 2020-09-05 20:03:39 --> Config Class Initialized
INFO - 2020-09-05 20:03:39 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:03:39 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:03:39 --> Utf8 Class Initialized
INFO - 2020-09-05 20:03:39 --> URI Class Initialized
INFO - 2020-09-05 20:03:39 --> Router Class Initialized
INFO - 2020-09-05 20:03:39 --> Output Class Initialized
INFO - 2020-09-05 20:03:39 --> Security Class Initialized
DEBUG - 2020-09-05 20:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:03:39 --> Input Class Initialized
INFO - 2020-09-05 20:03:39 --> Language Class Initialized
INFO - 2020-09-05 20:03:39 --> Language Class Initialized
INFO - 2020-09-05 20:03:39 --> Config Class Initialized
INFO - 2020-09-05 20:03:39 --> Loader Class Initialized
INFO - 2020-09-05 20:03:39 --> Helper loaded: url_helper
INFO - 2020-09-05 20:03:39 --> Helper loaded: form_helper
INFO - 2020-09-05 20:03:39 --> Helper loaded: file_helper
INFO - 2020-09-05 20:03:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:03:39 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:03:39 --> Upload Class Initialized
INFO - 2020-09-05 20:03:40 --> Controller Class Initialized
ERROR - 2020-09-05 20:03:40 --> 404 Page Not Found: /index
INFO - 2020-09-05 20:11:15 --> Config Class Initialized
INFO - 2020-09-05 20:11:15 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:11:15 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:11:15 --> Utf8 Class Initialized
INFO - 2020-09-05 20:11:15 --> URI Class Initialized
INFO - 2020-09-05 20:11:15 --> Router Class Initialized
INFO - 2020-09-05 20:11:15 --> Output Class Initialized
INFO - 2020-09-05 20:11:15 --> Security Class Initialized
DEBUG - 2020-09-05 20:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:11:15 --> Input Class Initialized
INFO - 2020-09-05 20:11:15 --> Language Class Initialized
INFO - 2020-09-05 20:11:15 --> Language Class Initialized
INFO - 2020-09-05 20:11:15 --> Config Class Initialized
INFO - 2020-09-05 20:11:15 --> Loader Class Initialized
INFO - 2020-09-05 20:11:15 --> Helper loaded: url_helper
INFO - 2020-09-05 20:11:15 --> Helper loaded: form_helper
INFO - 2020-09-05 20:11:15 --> Helper loaded: file_helper
INFO - 2020-09-05 20:11:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:11:15 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:11:15 --> Upload Class Initialized
INFO - 2020-09-05 20:11:15 --> Controller Class Initialized
DEBUG - 2020-09-05 20:11:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 20:11:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-05 20:11:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 20:11:15 --> Final output sent to browser
DEBUG - 2020-09-05 20:11:15 --> Total execution time: 0.0528
INFO - 2020-09-05 20:11:21 --> Config Class Initialized
INFO - 2020-09-05 20:11:21 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:11:21 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:11:21 --> Utf8 Class Initialized
INFO - 2020-09-05 20:11:21 --> URI Class Initialized
INFO - 2020-09-05 20:11:21 --> Router Class Initialized
INFO - 2020-09-05 20:11:21 --> Output Class Initialized
INFO - 2020-09-05 20:11:21 --> Security Class Initialized
DEBUG - 2020-09-05 20:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:11:21 --> Input Class Initialized
INFO - 2020-09-05 20:11:21 --> Language Class Initialized
INFO - 2020-09-05 20:11:21 --> Language Class Initialized
INFO - 2020-09-05 20:11:21 --> Config Class Initialized
INFO - 2020-09-05 20:11:21 --> Loader Class Initialized
INFO - 2020-09-05 20:11:21 --> Helper loaded: url_helper
INFO - 2020-09-05 20:11:21 --> Helper loaded: form_helper
INFO - 2020-09-05 20:11:21 --> Helper loaded: file_helper
INFO - 2020-09-05 20:11:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:11:21 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:11:21 --> Upload Class Initialized
INFO - 2020-09-05 20:11:21 --> Controller Class Initialized
ERROR - 2020-09-05 20:11:21 --> 404 Page Not Found: /index
INFO - 2020-09-05 20:13:58 --> Config Class Initialized
INFO - 2020-09-05 20:13:58 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:13:58 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:13:58 --> Utf8 Class Initialized
INFO - 2020-09-05 20:13:58 --> URI Class Initialized
DEBUG - 2020-09-05 20:13:58 --> No URI present. Default controller set.
INFO - 2020-09-05 20:13:58 --> Router Class Initialized
INFO - 2020-09-05 20:13:58 --> Output Class Initialized
INFO - 2020-09-05 20:13:58 --> Security Class Initialized
DEBUG - 2020-09-05 20:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:13:58 --> Input Class Initialized
INFO - 2020-09-05 20:13:58 --> Language Class Initialized
INFO - 2020-09-05 20:13:58 --> Language Class Initialized
INFO - 2020-09-05 20:13:58 --> Config Class Initialized
INFO - 2020-09-05 20:13:58 --> Loader Class Initialized
INFO - 2020-09-05 20:13:58 --> Helper loaded: url_helper
INFO - 2020-09-05 20:13:58 --> Helper loaded: form_helper
INFO - 2020-09-05 20:13:58 --> Helper loaded: file_helper
INFO - 2020-09-05 20:13:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:13:58 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:13:58 --> Upload Class Initialized
INFO - 2020-09-05 20:13:58 --> Controller Class Initialized
DEBUG - 2020-09-05 20:13:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 20:13:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 20:13:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 20:13:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 20:13:58 --> Final output sent to browser
DEBUG - 2020-09-05 20:13:58 --> Total execution time: 0.0512
INFO - 2020-09-05 20:14:00 --> Config Class Initialized
INFO - 2020-09-05 20:14:00 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:14:00 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:14:00 --> Utf8 Class Initialized
INFO - 2020-09-05 20:14:00 --> URI Class Initialized
INFO - 2020-09-05 20:14:00 --> Router Class Initialized
INFO - 2020-09-05 20:14:00 --> Output Class Initialized
INFO - 2020-09-05 20:14:00 --> Security Class Initialized
DEBUG - 2020-09-05 20:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:14:00 --> Input Class Initialized
INFO - 2020-09-05 20:14:00 --> Language Class Initialized
INFO - 2020-09-05 20:14:00 --> Language Class Initialized
INFO - 2020-09-05 20:14:00 --> Config Class Initialized
INFO - 2020-09-05 20:14:00 --> Loader Class Initialized
INFO - 2020-09-05 20:14:00 --> Helper loaded: url_helper
INFO - 2020-09-05 20:14:00 --> Helper loaded: form_helper
INFO - 2020-09-05 20:14:00 --> Helper loaded: file_helper
INFO - 2020-09-05 20:14:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:14:00 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:14:00 --> Upload Class Initialized
INFO - 2020-09-05 20:14:00 --> Controller Class Initialized
ERROR - 2020-09-05 20:14:00 --> 404 Page Not Found: /index
INFO - 2020-09-05 20:43:52 --> Config Class Initialized
INFO - 2020-09-05 20:43:52 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:43:52 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:43:52 --> Utf8 Class Initialized
INFO - 2020-09-05 20:43:52 --> URI Class Initialized
DEBUG - 2020-09-05 20:43:52 --> No URI present. Default controller set.
INFO - 2020-09-05 20:43:52 --> Router Class Initialized
INFO - 2020-09-05 20:43:52 --> Output Class Initialized
INFO - 2020-09-05 20:43:52 --> Security Class Initialized
DEBUG - 2020-09-05 20:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:43:52 --> Input Class Initialized
INFO - 2020-09-05 20:43:52 --> Language Class Initialized
INFO - 2020-09-05 20:43:52 --> Language Class Initialized
INFO - 2020-09-05 20:43:52 --> Config Class Initialized
INFO - 2020-09-05 20:43:52 --> Loader Class Initialized
INFO - 2020-09-05 20:43:52 --> Helper loaded: url_helper
INFO - 2020-09-05 20:43:52 --> Helper loaded: form_helper
INFO - 2020-09-05 20:43:52 --> Helper loaded: file_helper
INFO - 2020-09-05 20:43:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:43:52 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:43:52 --> Upload Class Initialized
INFO - 2020-09-05 20:43:52 --> Controller Class Initialized
DEBUG - 2020-09-05 20:43:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 20:43:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 20:43:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 20:43:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 20:43:52 --> Final output sent to browser
DEBUG - 2020-09-05 20:43:52 --> Total execution time: 0.0542
INFO - 2020-09-05 20:53:16 --> Config Class Initialized
INFO - 2020-09-05 20:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:53:16 --> Utf8 Class Initialized
INFO - 2020-09-05 20:53:16 --> URI Class Initialized
DEBUG - 2020-09-05 20:53:16 --> No URI present. Default controller set.
INFO - 2020-09-05 20:53:16 --> Router Class Initialized
INFO - 2020-09-05 20:53:16 --> Output Class Initialized
INFO - 2020-09-05 20:53:16 --> Security Class Initialized
DEBUG - 2020-09-05 20:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:53:16 --> Input Class Initialized
INFO - 2020-09-05 20:53:16 --> Language Class Initialized
INFO - 2020-09-05 20:53:16 --> Language Class Initialized
INFO - 2020-09-05 20:53:16 --> Config Class Initialized
INFO - 2020-09-05 20:53:16 --> Loader Class Initialized
INFO - 2020-09-05 20:53:16 --> Helper loaded: url_helper
INFO - 2020-09-05 20:53:16 --> Helper loaded: form_helper
INFO - 2020-09-05 20:53:16 --> Helper loaded: file_helper
INFO - 2020-09-05 20:53:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:53:16 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:53:16 --> Upload Class Initialized
INFO - 2020-09-05 20:53:16 --> Controller Class Initialized
DEBUG - 2020-09-05 20:53:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 20:53:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 20:53:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 20:53:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 20:53:16 --> Final output sent to browser
DEBUG - 2020-09-05 20:53:16 --> Total execution time: 0.0498
INFO - 2020-09-05 20:53:27 --> Config Class Initialized
INFO - 2020-09-05 20:53:27 --> Hooks Class Initialized
DEBUG - 2020-09-05 20:53:27 --> UTF-8 Support Enabled
INFO - 2020-09-05 20:53:27 --> Utf8 Class Initialized
INFO - 2020-09-05 20:53:27 --> URI Class Initialized
INFO - 2020-09-05 20:53:27 --> Router Class Initialized
INFO - 2020-09-05 20:53:27 --> Output Class Initialized
INFO - 2020-09-05 20:53:27 --> Security Class Initialized
DEBUG - 2020-09-05 20:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 20:53:27 --> Input Class Initialized
INFO - 2020-09-05 20:53:27 --> Language Class Initialized
INFO - 2020-09-05 20:53:27 --> Language Class Initialized
INFO - 2020-09-05 20:53:27 --> Config Class Initialized
INFO - 2020-09-05 20:53:27 --> Loader Class Initialized
INFO - 2020-09-05 20:53:27 --> Helper loaded: url_helper
INFO - 2020-09-05 20:53:27 --> Helper loaded: form_helper
INFO - 2020-09-05 20:53:27 --> Helper loaded: file_helper
INFO - 2020-09-05 20:53:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 20:53:27 --> Database Driver Class Initialized
DEBUG - 2020-09-05 20:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 20:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 20:53:27 --> Upload Class Initialized
INFO - 2020-09-05 20:53:27 --> Controller Class Initialized
ERROR - 2020-09-05 20:53:27 --> 404 Page Not Found: /index
INFO - 2020-09-05 21:07:22 --> Config Class Initialized
INFO - 2020-09-05 21:07:22 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:07:22 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:07:22 --> Utf8 Class Initialized
INFO - 2020-09-05 21:07:22 --> URI Class Initialized
DEBUG - 2020-09-05 21:07:22 --> No URI present. Default controller set.
INFO - 2020-09-05 21:07:22 --> Router Class Initialized
INFO - 2020-09-05 21:07:22 --> Output Class Initialized
INFO - 2020-09-05 21:07:22 --> Security Class Initialized
DEBUG - 2020-09-05 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:07:22 --> Input Class Initialized
INFO - 2020-09-05 21:07:22 --> Language Class Initialized
INFO - 2020-09-05 21:07:22 --> Language Class Initialized
INFO - 2020-09-05 21:07:22 --> Config Class Initialized
INFO - 2020-09-05 21:07:22 --> Loader Class Initialized
INFO - 2020-09-05 21:07:22 --> Helper loaded: url_helper
INFO - 2020-09-05 21:07:22 --> Helper loaded: form_helper
INFO - 2020-09-05 21:07:22 --> Helper loaded: file_helper
INFO - 2020-09-05 21:07:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:07:22 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:07:22 --> Upload Class Initialized
INFO - 2020-09-05 21:07:22 --> Controller Class Initialized
DEBUG - 2020-09-05 21:07:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:07:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:07:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:07:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:07:22 --> Final output sent to browser
DEBUG - 2020-09-05 21:07:22 --> Total execution time: 0.0525
INFO - 2020-09-05 21:19:42 --> Config Class Initialized
INFO - 2020-09-05 21:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:42 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:42 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:42 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:42 --> Router Class Initialized
INFO - 2020-09-05 21:19:42 --> Output Class Initialized
INFO - 2020-09-05 21:19:42 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:42 --> Input Class Initialized
INFO - 2020-09-05 21:19:42 --> Language Class Initialized
INFO - 2020-09-05 21:19:42 --> Language Class Initialized
INFO - 2020-09-05 21:19:42 --> Config Class Initialized
INFO - 2020-09-05 21:19:42 --> Loader Class Initialized
INFO - 2020-09-05 21:19:42 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:42 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:42 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:42 --> Upload Class Initialized
INFO - 2020-09-05 21:19:42 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:42 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:42 --> Total execution time: 0.0497
INFO - 2020-09-05 21:19:44 --> Config Class Initialized
INFO - 2020-09-05 21:19:44 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:44 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:44 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:44 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:44 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:44 --> Router Class Initialized
INFO - 2020-09-05 21:19:44 --> Output Class Initialized
INFO - 2020-09-05 21:19:44 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:44 --> Input Class Initialized
INFO - 2020-09-05 21:19:44 --> Language Class Initialized
INFO - 2020-09-05 21:19:44 --> Language Class Initialized
INFO - 2020-09-05 21:19:44 --> Config Class Initialized
INFO - 2020-09-05 21:19:44 --> Loader Class Initialized
INFO - 2020-09-05 21:19:44 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:44 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:44 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:44 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:44 --> Upload Class Initialized
INFO - 2020-09-05 21:19:44 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:44 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:44 --> Total execution time: 0.0520
INFO - 2020-09-05 21:19:44 --> Config Class Initialized
INFO - 2020-09-05 21:19:44 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:44 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:44 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:44 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:44 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:44 --> Router Class Initialized
INFO - 2020-09-05 21:19:44 --> Output Class Initialized
INFO - 2020-09-05 21:19:44 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:44 --> Input Class Initialized
INFO - 2020-09-05 21:19:44 --> Language Class Initialized
INFO - 2020-09-05 21:19:44 --> Language Class Initialized
INFO - 2020-09-05 21:19:44 --> Config Class Initialized
INFO - 2020-09-05 21:19:44 --> Loader Class Initialized
INFO - 2020-09-05 21:19:44 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:44 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:44 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:44 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:44 --> Upload Class Initialized
INFO - 2020-09-05 21:19:44 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:44 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:44 --> Total execution time: 0.0526
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:45 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:45 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:45 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:45 --> Router Class Initialized
INFO - 2020-09-05 21:19:45 --> Output Class Initialized
INFO - 2020-09-05 21:19:45 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:45 --> Input Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Loader Class Initialized
INFO - 2020-09-05 21:19:45 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:45 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:45 --> Upload Class Initialized
INFO - 2020-09-05 21:19:45 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:45 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:45 --> Total execution time: 0.0501
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:45 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:45 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:45 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:45 --> Router Class Initialized
INFO - 2020-09-05 21:19:45 --> Output Class Initialized
INFO - 2020-09-05 21:19:45 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:45 --> Input Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Loader Class Initialized
INFO - 2020-09-05 21:19:45 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:45 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:45 --> Database Driver Class Initialized
INFO - 2020-09-05 21:19:45 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:45 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:45 --> Router Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:45 --> Output Class Initialized
INFO - 2020-09-05 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:45 --> Security Class Initialized
INFO - 2020-09-05 21:19:45 --> Upload Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:45 --> Input Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Loader Class Initialized
INFO - 2020-09-05 21:19:45 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:45 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:45 --> Upload Class Initialized
INFO - 2020-09-05 21:19:45 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:45 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:45 --> Total execution time: 0.0523
INFO - 2020-09-05 21:19:45 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:45 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:45 --> Total execution time: 0.0483
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:45 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:45 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:45 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:45 --> Router Class Initialized
INFO - 2020-09-05 21:19:45 --> Output Class Initialized
INFO - 2020-09-05 21:19:45 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:45 --> Input Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Loader Class Initialized
INFO - 2020-09-05 21:19:45 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:45 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:45 --> Upload Class Initialized
INFO - 2020-09-05 21:19:45 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:45 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:45 --> Total execution time: 0.0498
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:19:45 --> Utf8 Class Initialized
INFO - 2020-09-05 21:19:45 --> URI Class Initialized
DEBUG - 2020-09-05 21:19:45 --> No URI present. Default controller set.
INFO - 2020-09-05 21:19:45 --> Router Class Initialized
INFO - 2020-09-05 21:19:45 --> Output Class Initialized
INFO - 2020-09-05 21:19:45 --> Security Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:19:45 --> Input Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Language Class Initialized
INFO - 2020-09-05 21:19:45 --> Config Class Initialized
INFO - 2020-09-05 21:19:45 --> Loader Class Initialized
INFO - 2020-09-05 21:19:45 --> Helper loaded: url_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: form_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: file_helper
INFO - 2020-09-05 21:19:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:19:45 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:19:45 --> Upload Class Initialized
INFO - 2020-09-05 21:19:45 --> Controller Class Initialized
DEBUG - 2020-09-05 21:19:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:19:45 --> Final output sent to browser
DEBUG - 2020-09-05 21:19:45 --> Total execution time: 0.0494
INFO - 2020-09-05 21:29:49 --> Config Class Initialized
INFO - 2020-09-05 21:29:49 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:29:49 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:29:49 --> Utf8 Class Initialized
INFO - 2020-09-05 21:29:49 --> URI Class Initialized
INFO - 2020-09-05 21:29:49 --> Router Class Initialized
INFO - 2020-09-05 21:29:49 --> Output Class Initialized
INFO - 2020-09-05 21:29:49 --> Security Class Initialized
DEBUG - 2020-09-05 21:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:29:49 --> Input Class Initialized
INFO - 2020-09-05 21:29:49 --> Language Class Initialized
INFO - 2020-09-05 21:29:49 --> Language Class Initialized
INFO - 2020-09-05 21:29:49 --> Config Class Initialized
INFO - 2020-09-05 21:29:49 --> Loader Class Initialized
INFO - 2020-09-05 21:29:49 --> Helper loaded: url_helper
INFO - 2020-09-05 21:29:49 --> Helper loaded: form_helper
INFO - 2020-09-05 21:29:49 --> Helper loaded: file_helper
INFO - 2020-09-05 21:29:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:29:49 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:29:49 --> Upload Class Initialized
INFO - 2020-09-05 21:29:49 --> Controller Class Initialized
ERROR - 2020-09-05 21:29:49 --> 404 Page Not Found: /index
INFO - 2020-09-05 21:35:17 --> Config Class Initialized
INFO - 2020-09-05 21:35:17 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:35:17 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:35:17 --> Utf8 Class Initialized
INFO - 2020-09-05 21:35:17 --> URI Class Initialized
DEBUG - 2020-09-05 21:35:17 --> No URI present. Default controller set.
INFO - 2020-09-05 21:35:17 --> Router Class Initialized
INFO - 2020-09-05 21:35:17 --> Output Class Initialized
INFO - 2020-09-05 21:35:17 --> Security Class Initialized
DEBUG - 2020-09-05 21:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:35:17 --> Input Class Initialized
INFO - 2020-09-05 21:35:17 --> Language Class Initialized
INFO - 2020-09-05 21:35:17 --> Language Class Initialized
INFO - 2020-09-05 21:35:17 --> Config Class Initialized
INFO - 2020-09-05 21:35:17 --> Loader Class Initialized
INFO - 2020-09-05 21:35:17 --> Helper loaded: url_helper
INFO - 2020-09-05 21:35:17 --> Helper loaded: form_helper
INFO - 2020-09-05 21:35:17 --> Helper loaded: file_helper
INFO - 2020-09-05 21:35:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:35:17 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:35:17 --> Upload Class Initialized
INFO - 2020-09-05 21:35:17 --> Controller Class Initialized
DEBUG - 2020-09-05 21:35:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:35:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:35:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:35:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:35:17 --> Final output sent to browser
DEBUG - 2020-09-05 21:35:17 --> Total execution time: 0.0519
INFO - 2020-09-05 21:35:27 --> Config Class Initialized
INFO - 2020-09-05 21:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:35:27 --> Utf8 Class Initialized
INFO - 2020-09-05 21:35:27 --> URI Class Initialized
DEBUG - 2020-09-05 21:35:27 --> No URI present. Default controller set.
INFO - 2020-09-05 21:35:27 --> Router Class Initialized
INFO - 2020-09-05 21:35:27 --> Output Class Initialized
INFO - 2020-09-05 21:35:27 --> Security Class Initialized
DEBUG - 2020-09-05 21:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:35:27 --> Input Class Initialized
INFO - 2020-09-05 21:35:27 --> Language Class Initialized
INFO - 2020-09-05 21:35:27 --> Language Class Initialized
INFO - 2020-09-05 21:35:27 --> Config Class Initialized
INFO - 2020-09-05 21:35:27 --> Loader Class Initialized
INFO - 2020-09-05 21:35:27 --> Helper loaded: url_helper
INFO - 2020-09-05 21:35:27 --> Helper loaded: form_helper
INFO - 2020-09-05 21:35:27 --> Helper loaded: file_helper
INFO - 2020-09-05 21:35:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:35:27 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:35:27 --> Upload Class Initialized
INFO - 2020-09-05 21:35:27 --> Controller Class Initialized
DEBUG - 2020-09-05 21:35:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:35:27 --> Final output sent to browser
DEBUG - 2020-09-05 21:35:27 --> Total execution time: 0.0538
INFO - 2020-09-05 21:51:43 --> Config Class Initialized
INFO - 2020-09-05 21:51:43 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:51:43 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:51:43 --> Utf8 Class Initialized
INFO - 2020-09-05 21:51:43 --> URI Class Initialized
INFO - 2020-09-05 21:51:43 --> Router Class Initialized
INFO - 2020-09-05 21:51:43 --> Output Class Initialized
INFO - 2020-09-05 21:51:43 --> Security Class Initialized
DEBUG - 2020-09-05 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:51:43 --> Input Class Initialized
INFO - 2020-09-05 21:51:43 --> Language Class Initialized
INFO - 2020-09-05 21:51:43 --> Language Class Initialized
INFO - 2020-09-05 21:51:43 --> Config Class Initialized
INFO - 2020-09-05 21:51:43 --> Loader Class Initialized
INFO - 2020-09-05 21:51:43 --> Helper loaded: url_helper
INFO - 2020-09-05 21:51:43 --> Helper loaded: form_helper
INFO - 2020-09-05 21:51:43 --> Helper loaded: file_helper
INFO - 2020-09-05 21:51:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:51:43 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:51:43 --> Upload Class Initialized
INFO - 2020-09-05 21:51:43 --> Controller Class Initialized
ERROR - 2020-09-05 21:51:43 --> 404 Page Not Found: /index
INFO - 2020-09-05 21:51:43 --> Config Class Initialized
INFO - 2020-09-05 21:51:43 --> Hooks Class Initialized
DEBUG - 2020-09-05 21:51:43 --> UTF-8 Support Enabled
INFO - 2020-09-05 21:51:43 --> Utf8 Class Initialized
INFO - 2020-09-05 21:51:43 --> URI Class Initialized
DEBUG - 2020-09-05 21:51:43 --> No URI present. Default controller set.
INFO - 2020-09-05 21:51:43 --> Router Class Initialized
INFO - 2020-09-05 21:51:43 --> Output Class Initialized
INFO - 2020-09-05 21:51:43 --> Security Class Initialized
DEBUG - 2020-09-05 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 21:51:43 --> Input Class Initialized
INFO - 2020-09-05 21:51:43 --> Language Class Initialized
INFO - 2020-09-05 21:51:43 --> Language Class Initialized
INFO - 2020-09-05 21:51:43 --> Config Class Initialized
INFO - 2020-09-05 21:51:43 --> Loader Class Initialized
INFO - 2020-09-05 21:51:43 --> Helper loaded: url_helper
INFO - 2020-09-05 21:51:43 --> Helper loaded: form_helper
INFO - 2020-09-05 21:51:43 --> Helper loaded: file_helper
INFO - 2020-09-05 21:51:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 21:51:43 --> Database Driver Class Initialized
DEBUG - 2020-09-05 21:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 21:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 21:51:43 --> Upload Class Initialized
INFO - 2020-09-05 21:51:43 --> Controller Class Initialized
DEBUG - 2020-09-05 21:51:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 21:51:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 21:51:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 21:51:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 21:51:43 --> Final output sent to browser
DEBUG - 2020-09-05 21:51:43 --> Total execution time: 0.0536
INFO - 2020-09-05 22:57:34 --> Config Class Initialized
INFO - 2020-09-05 22:57:34 --> Hooks Class Initialized
DEBUG - 2020-09-05 22:57:34 --> UTF-8 Support Enabled
INFO - 2020-09-05 22:57:34 --> Utf8 Class Initialized
INFO - 2020-09-05 22:57:34 --> URI Class Initialized
INFO - 2020-09-05 22:57:34 --> Router Class Initialized
INFO - 2020-09-05 22:57:34 --> Output Class Initialized
INFO - 2020-09-05 22:57:34 --> Security Class Initialized
DEBUG - 2020-09-05 22:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 22:57:34 --> Input Class Initialized
INFO - 2020-09-05 22:57:34 --> Language Class Initialized
INFO - 2020-09-05 22:57:34 --> Language Class Initialized
INFO - 2020-09-05 22:57:34 --> Config Class Initialized
INFO - 2020-09-05 22:57:34 --> Loader Class Initialized
INFO - 2020-09-05 22:57:34 --> Helper loaded: url_helper
INFO - 2020-09-05 22:57:34 --> Helper loaded: form_helper
INFO - 2020-09-05 22:57:34 --> Helper loaded: file_helper
INFO - 2020-09-05 22:57:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 22:57:34 --> Database Driver Class Initialized
DEBUG - 2020-09-05 22:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 22:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 22:57:34 --> Upload Class Initialized
INFO - 2020-09-05 22:57:34 --> Controller Class Initialized
ERROR - 2020-09-05 22:57:34 --> 404 Page Not Found: /index
INFO - 2020-09-05 22:58:30 --> Config Class Initialized
INFO - 2020-09-05 22:58:30 --> Hooks Class Initialized
DEBUG - 2020-09-05 22:58:31 --> UTF-8 Support Enabled
INFO - 2020-09-05 22:58:31 --> Utf8 Class Initialized
INFO - 2020-09-05 22:58:31 --> URI Class Initialized
INFO - 2020-09-05 22:58:31 --> Router Class Initialized
INFO - 2020-09-05 22:58:31 --> Output Class Initialized
INFO - 2020-09-05 22:58:31 --> Security Class Initialized
DEBUG - 2020-09-05 22:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 22:58:31 --> Input Class Initialized
INFO - 2020-09-05 22:58:31 --> Language Class Initialized
INFO - 2020-09-05 22:58:31 --> Language Class Initialized
INFO - 2020-09-05 22:58:31 --> Config Class Initialized
INFO - 2020-09-05 22:58:31 --> Loader Class Initialized
INFO - 2020-09-05 22:58:31 --> Helper loaded: url_helper
INFO - 2020-09-05 22:58:31 --> Helper loaded: form_helper
INFO - 2020-09-05 22:58:31 --> Helper loaded: file_helper
INFO - 2020-09-05 22:58:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 22:58:31 --> Database Driver Class Initialized
DEBUG - 2020-09-05 22:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 22:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 22:58:31 --> Upload Class Initialized
INFO - 2020-09-05 22:58:31 --> Controller Class Initialized
ERROR - 2020-09-05 22:58:31 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:03:44 --> Config Class Initialized
INFO - 2020-09-05 23:03:44 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:03:44 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:03:44 --> Utf8 Class Initialized
INFO - 2020-09-05 23:03:44 --> URI Class Initialized
INFO - 2020-09-05 23:03:44 --> Router Class Initialized
INFO - 2020-09-05 23:03:44 --> Output Class Initialized
INFO - 2020-09-05 23:03:44 --> Security Class Initialized
DEBUG - 2020-09-05 23:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:03:44 --> Input Class Initialized
INFO - 2020-09-05 23:03:44 --> Language Class Initialized
INFO - 2020-09-05 23:03:44 --> Language Class Initialized
INFO - 2020-09-05 23:03:44 --> Config Class Initialized
INFO - 2020-09-05 23:03:44 --> Loader Class Initialized
INFO - 2020-09-05 23:03:44 --> Helper loaded: url_helper
INFO - 2020-09-05 23:03:44 --> Helper loaded: form_helper
INFO - 2020-09-05 23:03:44 --> Helper loaded: file_helper
INFO - 2020-09-05 23:03:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:03:44 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:03:44 --> Upload Class Initialized
INFO - 2020-09-05 23:03:44 --> Controller Class Initialized
ERROR - 2020-09-05 23:03:44 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:07:23 --> Config Class Initialized
INFO - 2020-09-05 23:07:23 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:07:23 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:07:23 --> Utf8 Class Initialized
INFO - 2020-09-05 23:07:23 --> URI Class Initialized
INFO - 2020-09-05 23:07:23 --> Router Class Initialized
INFO - 2020-09-05 23:07:23 --> Output Class Initialized
INFO - 2020-09-05 23:07:23 --> Security Class Initialized
DEBUG - 2020-09-05 23:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:07:23 --> Input Class Initialized
INFO - 2020-09-05 23:07:23 --> Language Class Initialized
INFO - 2020-09-05 23:07:23 --> Language Class Initialized
INFO - 2020-09-05 23:07:23 --> Config Class Initialized
INFO - 2020-09-05 23:07:23 --> Loader Class Initialized
INFO - 2020-09-05 23:07:23 --> Helper loaded: url_helper
INFO - 2020-09-05 23:07:23 --> Helper loaded: form_helper
INFO - 2020-09-05 23:07:23 --> Helper loaded: file_helper
INFO - 2020-09-05 23:07:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:07:23 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:07:23 --> Upload Class Initialized
INFO - 2020-09-05 23:07:23 --> Controller Class Initialized
DEBUG - 2020-09-05 23:07:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:07:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-05 23:07:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:07:23 --> Final output sent to browser
DEBUG - 2020-09-05 23:07:23 --> Total execution time: 0.0557
INFO - 2020-09-05 23:30:31 --> Config Class Initialized
INFO - 2020-09-05 23:30:31 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:30:31 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:30:31 --> Utf8 Class Initialized
INFO - 2020-09-05 23:30:31 --> URI Class Initialized
INFO - 2020-09-05 23:30:31 --> Router Class Initialized
INFO - 2020-09-05 23:30:31 --> Output Class Initialized
INFO - 2020-09-05 23:30:31 --> Security Class Initialized
DEBUG - 2020-09-05 23:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:30:31 --> Input Class Initialized
INFO - 2020-09-05 23:30:31 --> Language Class Initialized
INFO - 2020-09-05 23:30:31 --> Language Class Initialized
INFO - 2020-09-05 23:30:31 --> Config Class Initialized
INFO - 2020-09-05 23:30:31 --> Loader Class Initialized
INFO - 2020-09-05 23:30:31 --> Helper loaded: url_helper
INFO - 2020-09-05 23:30:31 --> Helper loaded: form_helper
INFO - 2020-09-05 23:30:31 --> Helper loaded: file_helper
INFO - 2020-09-05 23:30:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:30:31 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:30:31 --> Upload Class Initialized
INFO - 2020-09-05 23:30:31 --> Controller Class Initialized
DEBUG - 2020-09-05 23:30:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:30:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 23:30:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 23:30:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:30:31 --> Final output sent to browser
DEBUG - 2020-09-05 23:30:31 --> Total execution time: 0.0523
INFO - 2020-09-05 23:31:29 --> Config Class Initialized
INFO - 2020-09-05 23:31:29 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:31:29 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:31:29 --> Utf8 Class Initialized
INFO - 2020-09-05 23:31:29 --> URI Class Initialized
DEBUG - 2020-09-05 23:31:29 --> No URI present. Default controller set.
INFO - 2020-09-05 23:31:29 --> Router Class Initialized
INFO - 2020-09-05 23:31:29 --> Output Class Initialized
INFO - 2020-09-05 23:31:29 --> Security Class Initialized
DEBUG - 2020-09-05 23:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:31:29 --> Input Class Initialized
INFO - 2020-09-05 23:31:29 --> Language Class Initialized
INFO - 2020-09-05 23:31:29 --> Language Class Initialized
INFO - 2020-09-05 23:31:29 --> Config Class Initialized
INFO - 2020-09-05 23:31:29 --> Loader Class Initialized
INFO - 2020-09-05 23:31:29 --> Helper loaded: url_helper
INFO - 2020-09-05 23:31:29 --> Helper loaded: form_helper
INFO - 2020-09-05 23:31:29 --> Helper loaded: file_helper
INFO - 2020-09-05 23:31:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:31:29 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:31:29 --> Upload Class Initialized
INFO - 2020-09-05 23:31:29 --> Controller Class Initialized
DEBUG - 2020-09-05 23:31:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:31:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 23:31:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 23:31:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:31:29 --> Final output sent to browser
DEBUG - 2020-09-05 23:31:29 --> Total execution time: 0.0495
INFO - 2020-09-05 23:31:34 --> Config Class Initialized
INFO - 2020-09-05 23:31:34 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:31:34 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:31:34 --> Utf8 Class Initialized
INFO - 2020-09-05 23:31:34 --> URI Class Initialized
INFO - 2020-09-05 23:31:34 --> Router Class Initialized
INFO - 2020-09-05 23:31:34 --> Output Class Initialized
INFO - 2020-09-05 23:31:34 --> Security Class Initialized
DEBUG - 2020-09-05 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:31:34 --> Input Class Initialized
INFO - 2020-09-05 23:31:34 --> Language Class Initialized
INFO - 2020-09-05 23:31:34 --> Language Class Initialized
INFO - 2020-09-05 23:31:34 --> Config Class Initialized
INFO - 2020-09-05 23:31:34 --> Loader Class Initialized
INFO - 2020-09-05 23:31:34 --> Helper loaded: url_helper
INFO - 2020-09-05 23:31:34 --> Helper loaded: form_helper
INFO - 2020-09-05 23:31:34 --> Helper loaded: file_helper
INFO - 2020-09-05 23:31:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:31:34 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:31:34 --> Upload Class Initialized
INFO - 2020-09-05 23:31:34 --> Controller Class Initialized
ERROR - 2020-09-05 23:31:34 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:32:48 --> Config Class Initialized
INFO - 2020-09-05 23:32:48 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:32:48 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:32:48 --> Utf8 Class Initialized
INFO - 2020-09-05 23:32:48 --> URI Class Initialized
INFO - 2020-09-05 23:32:48 --> Router Class Initialized
INFO - 2020-09-05 23:32:48 --> Output Class Initialized
INFO - 2020-09-05 23:32:48 --> Security Class Initialized
DEBUG - 2020-09-05 23:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:32:48 --> Input Class Initialized
INFO - 2020-09-05 23:32:48 --> Language Class Initialized
INFO - 2020-09-05 23:32:48 --> Language Class Initialized
INFO - 2020-09-05 23:32:48 --> Config Class Initialized
INFO - 2020-09-05 23:32:48 --> Loader Class Initialized
INFO - 2020-09-05 23:32:48 --> Helper loaded: url_helper
INFO - 2020-09-05 23:32:48 --> Helper loaded: form_helper
INFO - 2020-09-05 23:32:48 --> Helper loaded: file_helper
INFO - 2020-09-05 23:32:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:32:48 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:32:48 --> Upload Class Initialized
INFO - 2020-09-05 23:32:48 --> Controller Class Initialized
ERROR - 2020-09-05 23:32:48 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:04 --> Config Class Initialized
INFO - 2020-09-05 23:34:04 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:04 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:04 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:04 --> URI Class Initialized
DEBUG - 2020-09-05 23:34:04 --> No URI present. Default controller set.
INFO - 2020-09-05 23:34:04 --> Router Class Initialized
INFO - 2020-09-05 23:34:04 --> Output Class Initialized
INFO - 2020-09-05 23:34:04 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:04 --> Input Class Initialized
INFO - 2020-09-05 23:34:04 --> Language Class Initialized
INFO - 2020-09-05 23:34:04 --> Language Class Initialized
INFO - 2020-09-05 23:34:04 --> Config Class Initialized
INFO - 2020-09-05 23:34:04 --> Loader Class Initialized
INFO - 2020-09-05 23:34:04 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:04 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:04 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:04 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:04 --> Upload Class Initialized
INFO - 2020-09-05 23:34:04 --> Controller Class Initialized
DEBUG - 2020-09-05 23:34:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:34:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 23:34:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 23:34:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:34:04 --> Final output sent to browser
DEBUG - 2020-09-05 23:34:04 --> Total execution time: 0.0902
INFO - 2020-09-05 23:34:06 --> Config Class Initialized
INFO - 2020-09-05 23:34:06 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:06 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:06 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:06 --> URI Class Initialized
INFO - 2020-09-05 23:34:06 --> Router Class Initialized
INFO - 2020-09-05 23:34:06 --> Output Class Initialized
INFO - 2020-09-05 23:34:06 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:06 --> Input Class Initialized
INFO - 2020-09-05 23:34:06 --> Language Class Initialized
INFO - 2020-09-05 23:34:06 --> Language Class Initialized
INFO - 2020-09-05 23:34:06 --> Config Class Initialized
INFO - 2020-09-05 23:34:06 --> Loader Class Initialized
INFO - 2020-09-05 23:34:06 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:06 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:06 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:06 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:06 --> Upload Class Initialized
INFO - 2020-09-05 23:34:06 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:06 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:06 --> Config Class Initialized
INFO - 2020-09-05 23:34:06 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:06 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:06 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:06 --> URI Class Initialized
INFO - 2020-09-05 23:34:06 --> Router Class Initialized
INFO - 2020-09-05 23:34:06 --> Output Class Initialized
INFO - 2020-09-05 23:34:06 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:06 --> Input Class Initialized
INFO - 2020-09-05 23:34:06 --> Language Class Initialized
INFO - 2020-09-05 23:34:06 --> Language Class Initialized
INFO - 2020-09-05 23:34:06 --> Config Class Initialized
INFO - 2020-09-05 23:34:06 --> Loader Class Initialized
INFO - 2020-09-05 23:34:06 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:06 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:06 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:06 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:06 --> Upload Class Initialized
INFO - 2020-09-05 23:34:06 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:06 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:07 --> Config Class Initialized
INFO - 2020-09-05 23:34:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:07 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:07 --> URI Class Initialized
DEBUG - 2020-09-05 23:34:07 --> No URI present. Default controller set.
INFO - 2020-09-05 23:34:07 --> Router Class Initialized
INFO - 2020-09-05 23:34:07 --> Output Class Initialized
INFO - 2020-09-05 23:34:07 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:07 --> Input Class Initialized
INFO - 2020-09-05 23:34:07 --> Language Class Initialized
INFO - 2020-09-05 23:34:07 --> Language Class Initialized
INFO - 2020-09-05 23:34:07 --> Config Class Initialized
INFO - 2020-09-05 23:34:07 --> Loader Class Initialized
INFO - 2020-09-05 23:34:07 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:07 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:07 --> Upload Class Initialized
INFO - 2020-09-05 23:34:07 --> Controller Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:34:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 23:34:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 23:34:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:34:07 --> Final output sent to browser
DEBUG - 2020-09-05 23:34:07 --> Total execution time: 0.0509
INFO - 2020-09-05 23:34:07 --> Config Class Initialized
INFO - 2020-09-05 23:34:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:07 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:07 --> URI Class Initialized
INFO - 2020-09-05 23:34:07 --> Router Class Initialized
INFO - 2020-09-05 23:34:07 --> Output Class Initialized
INFO - 2020-09-05 23:34:07 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:07 --> Input Class Initialized
INFO - 2020-09-05 23:34:07 --> Language Class Initialized
INFO - 2020-09-05 23:34:07 --> Language Class Initialized
INFO - 2020-09-05 23:34:07 --> Config Class Initialized
INFO - 2020-09-05 23:34:07 --> Loader Class Initialized
INFO - 2020-09-05 23:34:07 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:07 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:07 --> Upload Class Initialized
INFO - 2020-09-05 23:34:07 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:07 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:07 --> Config Class Initialized
INFO - 2020-09-05 23:34:07 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:07 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:07 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:07 --> URI Class Initialized
INFO - 2020-09-05 23:34:07 --> Router Class Initialized
INFO - 2020-09-05 23:34:07 --> Output Class Initialized
INFO - 2020-09-05 23:34:07 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:07 --> Input Class Initialized
INFO - 2020-09-05 23:34:07 --> Language Class Initialized
INFO - 2020-09-05 23:34:07 --> Language Class Initialized
INFO - 2020-09-05 23:34:07 --> Config Class Initialized
INFO - 2020-09-05 23:34:07 --> Loader Class Initialized
INFO - 2020-09-05 23:34:07 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:07 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:07 --> Upload Class Initialized
INFO - 2020-09-05 23:34:07 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:07 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:08 --> Config Class Initialized
INFO - 2020-09-05 23:34:08 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:08 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:08 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:08 --> URI Class Initialized
INFO - 2020-09-05 23:34:08 --> Router Class Initialized
INFO - 2020-09-05 23:34:08 --> Output Class Initialized
INFO - 2020-09-05 23:34:08 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:08 --> Input Class Initialized
INFO - 2020-09-05 23:34:08 --> Language Class Initialized
INFO - 2020-09-05 23:34:08 --> Language Class Initialized
INFO - 2020-09-05 23:34:08 --> Config Class Initialized
INFO - 2020-09-05 23:34:08 --> Loader Class Initialized
INFO - 2020-09-05 23:34:08 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:08 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:08 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:08 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:08 --> Upload Class Initialized
INFO - 2020-09-05 23:34:08 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:08 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:09 --> Config Class Initialized
INFO - 2020-09-05 23:34:09 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:09 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:09 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:09 --> URI Class Initialized
INFO - 2020-09-05 23:34:09 --> Router Class Initialized
INFO - 2020-09-05 23:34:09 --> Output Class Initialized
INFO - 2020-09-05 23:34:09 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:09 --> Input Class Initialized
INFO - 2020-09-05 23:34:09 --> Language Class Initialized
INFO - 2020-09-05 23:34:09 --> Language Class Initialized
INFO - 2020-09-05 23:34:09 --> Config Class Initialized
INFO - 2020-09-05 23:34:09 --> Loader Class Initialized
INFO - 2020-09-05 23:34:09 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:09 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:09 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:09 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:09 --> Upload Class Initialized
INFO - 2020-09-05 23:34:09 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:09 --> 404 Page Not Found: Website/wp-includes
INFO - 2020-09-05 23:34:09 --> Config Class Initialized
INFO - 2020-09-05 23:34:09 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:09 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:09 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:09 --> URI Class Initialized
INFO - 2020-09-05 23:34:09 --> Router Class Initialized
INFO - 2020-09-05 23:34:10 --> Output Class Initialized
INFO - 2020-09-05 23:34:10 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:10 --> Input Class Initialized
INFO - 2020-09-05 23:34:10 --> Language Class Initialized
INFO - 2020-09-05 23:34:10 --> Language Class Initialized
INFO - 2020-09-05 23:34:10 --> Config Class Initialized
INFO - 2020-09-05 23:34:10 --> Loader Class Initialized
INFO - 2020-09-05 23:34:10 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:10 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:10 --> Upload Class Initialized
INFO - 2020-09-05 23:34:10 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:10 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:10 --> Config Class Initialized
INFO - 2020-09-05 23:34:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:10 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:10 --> URI Class Initialized
INFO - 2020-09-05 23:34:10 --> Router Class Initialized
INFO - 2020-09-05 23:34:10 --> Output Class Initialized
INFO - 2020-09-05 23:34:10 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:10 --> Input Class Initialized
INFO - 2020-09-05 23:34:10 --> Language Class Initialized
INFO - 2020-09-05 23:34:10 --> Language Class Initialized
INFO - 2020-09-05 23:34:10 --> Config Class Initialized
INFO - 2020-09-05 23:34:10 --> Loader Class Initialized
INFO - 2020-09-05 23:34:10 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:10 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:10 --> Upload Class Initialized
INFO - 2020-09-05 23:34:10 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:10 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:10 --> Config Class Initialized
INFO - 2020-09-05 23:34:10 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:10 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:10 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:10 --> URI Class Initialized
INFO - 2020-09-05 23:34:10 --> Router Class Initialized
INFO - 2020-09-05 23:34:10 --> Output Class Initialized
INFO - 2020-09-05 23:34:10 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:10 --> Input Class Initialized
INFO - 2020-09-05 23:34:10 --> Language Class Initialized
INFO - 2020-09-05 23:34:10 --> Language Class Initialized
INFO - 2020-09-05 23:34:10 --> Config Class Initialized
INFO - 2020-09-05 23:34:10 --> Loader Class Initialized
INFO - 2020-09-05 23:34:10 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:10 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:10 --> Upload Class Initialized
INFO - 2020-09-05 23:34:10 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:10 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:11 --> Config Class Initialized
INFO - 2020-09-05 23:34:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:11 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:11 --> URI Class Initialized
INFO - 2020-09-05 23:34:11 --> Router Class Initialized
INFO - 2020-09-05 23:34:11 --> Output Class Initialized
INFO - 2020-09-05 23:34:11 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:11 --> Input Class Initialized
INFO - 2020-09-05 23:34:11 --> Language Class Initialized
INFO - 2020-09-05 23:34:11 --> Language Class Initialized
INFO - 2020-09-05 23:34:11 --> Config Class Initialized
INFO - 2020-09-05 23:34:11 --> Loader Class Initialized
INFO - 2020-09-05 23:34:11 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:11 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:11 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:11 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:11 --> Upload Class Initialized
INFO - 2020-09-05 23:34:11 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:11 --> Config Class Initialized
INFO - 2020-09-05 23:34:11 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:11 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:11 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:11 --> URI Class Initialized
INFO - 2020-09-05 23:34:11 --> Router Class Initialized
INFO - 2020-09-05 23:34:11 --> Output Class Initialized
INFO - 2020-09-05 23:34:11 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:11 --> Input Class Initialized
INFO - 2020-09-05 23:34:11 --> Language Class Initialized
INFO - 2020-09-05 23:34:11 --> Language Class Initialized
INFO - 2020-09-05 23:34:11 --> Config Class Initialized
INFO - 2020-09-05 23:34:11 --> Loader Class Initialized
INFO - 2020-09-05 23:34:11 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:11 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:11 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:11 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:11 --> Upload Class Initialized
INFO - 2020-09-05 23:34:11 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:11 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:12 --> Config Class Initialized
INFO - 2020-09-05 23:34:12 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:12 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:12 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:12 --> URI Class Initialized
INFO - 2020-09-05 23:34:12 --> Router Class Initialized
INFO - 2020-09-05 23:34:12 --> Output Class Initialized
INFO - 2020-09-05 23:34:12 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:12 --> Input Class Initialized
INFO - 2020-09-05 23:34:12 --> Language Class Initialized
INFO - 2020-09-05 23:34:12 --> Language Class Initialized
INFO - 2020-09-05 23:34:12 --> Config Class Initialized
INFO - 2020-09-05 23:34:12 --> Loader Class Initialized
INFO - 2020-09-05 23:34:12 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:12 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:12 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:12 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:12 --> Upload Class Initialized
INFO - 2020-09-05 23:34:12 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:12 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:12 --> Config Class Initialized
INFO - 2020-09-05 23:34:12 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:12 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:12 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:12 --> URI Class Initialized
INFO - 2020-09-05 23:34:12 --> Router Class Initialized
INFO - 2020-09-05 23:34:12 --> Output Class Initialized
INFO - 2020-09-05 23:34:12 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:12 --> Input Class Initialized
INFO - 2020-09-05 23:34:12 --> Language Class Initialized
INFO - 2020-09-05 23:34:12 --> Language Class Initialized
INFO - 2020-09-05 23:34:12 --> Config Class Initialized
INFO - 2020-09-05 23:34:12 --> Loader Class Initialized
INFO - 2020-09-05 23:34:12 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:12 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:12 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:12 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:12 --> Upload Class Initialized
INFO - 2020-09-05 23:34:12 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:12 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:13 --> Config Class Initialized
INFO - 2020-09-05 23:34:13 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:13 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:13 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:13 --> URI Class Initialized
INFO - 2020-09-05 23:34:13 --> Router Class Initialized
INFO - 2020-09-05 23:34:13 --> Output Class Initialized
INFO - 2020-09-05 23:34:13 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:13 --> Input Class Initialized
INFO - 2020-09-05 23:34:13 --> Language Class Initialized
INFO - 2020-09-05 23:34:13 --> Language Class Initialized
INFO - 2020-09-05 23:34:13 --> Config Class Initialized
INFO - 2020-09-05 23:34:13 --> Loader Class Initialized
INFO - 2020-09-05 23:34:13 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:13 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:13 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:13 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:13 --> Upload Class Initialized
INFO - 2020-09-05 23:34:13 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:13 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:14 --> Config Class Initialized
INFO - 2020-09-05 23:34:14 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:14 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:14 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:14 --> URI Class Initialized
INFO - 2020-09-05 23:34:14 --> Router Class Initialized
INFO - 2020-09-05 23:34:14 --> Output Class Initialized
INFO - 2020-09-05 23:34:14 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:14 --> Input Class Initialized
INFO - 2020-09-05 23:34:14 --> Language Class Initialized
INFO - 2020-09-05 23:34:14 --> Language Class Initialized
INFO - 2020-09-05 23:34:14 --> Config Class Initialized
INFO - 2020-09-05 23:34:14 --> Loader Class Initialized
INFO - 2020-09-05 23:34:14 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:14 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:14 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:14 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:14 --> Upload Class Initialized
INFO - 2020-09-05 23:34:14 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:14 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:14 --> Config Class Initialized
INFO - 2020-09-05 23:34:14 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:14 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:14 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:14 --> URI Class Initialized
INFO - 2020-09-05 23:34:14 --> Router Class Initialized
INFO - 2020-09-05 23:34:14 --> Output Class Initialized
INFO - 2020-09-05 23:34:14 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:14 --> Input Class Initialized
INFO - 2020-09-05 23:34:14 --> Language Class Initialized
INFO - 2020-09-05 23:34:14 --> Language Class Initialized
INFO - 2020-09-05 23:34:14 --> Config Class Initialized
INFO - 2020-09-05 23:34:14 --> Loader Class Initialized
INFO - 2020-09-05 23:34:14 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:14 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:14 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:14 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:14 --> Upload Class Initialized
INFO - 2020-09-05 23:34:14 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:14 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:15 --> Config Class Initialized
INFO - 2020-09-05 23:34:15 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:15 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:15 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:15 --> URI Class Initialized
INFO - 2020-09-05 23:34:15 --> Router Class Initialized
INFO - 2020-09-05 23:34:15 --> Output Class Initialized
INFO - 2020-09-05 23:34:15 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:15 --> Input Class Initialized
INFO - 2020-09-05 23:34:15 --> Language Class Initialized
INFO - 2020-09-05 23:34:15 --> Language Class Initialized
INFO - 2020-09-05 23:34:15 --> Config Class Initialized
INFO - 2020-09-05 23:34:15 --> Loader Class Initialized
INFO - 2020-09-05 23:34:15 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:15 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:15 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:15 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:15 --> Upload Class Initialized
INFO - 2020-09-05 23:34:15 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:15 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:34:16 --> Config Class Initialized
INFO - 2020-09-05 23:34:16 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:34:16 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:34:16 --> Utf8 Class Initialized
INFO - 2020-09-05 23:34:16 --> URI Class Initialized
INFO - 2020-09-05 23:34:16 --> Router Class Initialized
INFO - 2020-09-05 23:34:16 --> Output Class Initialized
INFO - 2020-09-05 23:34:16 --> Security Class Initialized
DEBUG - 2020-09-05 23:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:34:16 --> Input Class Initialized
INFO - 2020-09-05 23:34:16 --> Language Class Initialized
INFO - 2020-09-05 23:34:16 --> Language Class Initialized
INFO - 2020-09-05 23:34:16 --> Config Class Initialized
INFO - 2020-09-05 23:34:16 --> Loader Class Initialized
INFO - 2020-09-05 23:34:16 --> Helper loaded: url_helper
INFO - 2020-09-05 23:34:16 --> Helper loaded: form_helper
INFO - 2020-09-05 23:34:16 --> Helper loaded: file_helper
INFO - 2020-09-05 23:34:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:34:16 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:34:16 --> Upload Class Initialized
INFO - 2020-09-05 23:34:16 --> Controller Class Initialized
ERROR - 2020-09-05 23:34:16 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:46:26 --> Config Class Initialized
INFO - 2020-09-05 23:46:26 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:46:26 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:46:26 --> Utf8 Class Initialized
INFO - 2020-09-05 23:46:26 --> URI Class Initialized
INFO - 2020-09-05 23:46:26 --> Router Class Initialized
INFO - 2020-09-05 23:46:26 --> Output Class Initialized
INFO - 2020-09-05 23:46:26 --> Security Class Initialized
DEBUG - 2020-09-05 23:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:46:26 --> Input Class Initialized
INFO - 2020-09-05 23:46:26 --> Language Class Initialized
INFO - 2020-09-05 23:46:26 --> Language Class Initialized
INFO - 2020-09-05 23:46:26 --> Config Class Initialized
INFO - 2020-09-05 23:46:26 --> Loader Class Initialized
INFO - 2020-09-05 23:46:26 --> Helper loaded: url_helper
INFO - 2020-09-05 23:46:26 --> Helper loaded: form_helper
INFO - 2020-09-05 23:46:26 --> Helper loaded: file_helper
INFO - 2020-09-05 23:46:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:46:26 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:46:26 --> Upload Class Initialized
INFO - 2020-09-05 23:46:26 --> Controller Class Initialized
ERROR - 2020-09-05 23:46:26 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:46:30 --> Config Class Initialized
INFO - 2020-09-05 23:46:30 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:46:30 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:46:30 --> Utf8 Class Initialized
INFO - 2020-09-05 23:46:30 --> URI Class Initialized
INFO - 2020-09-05 23:46:30 --> Router Class Initialized
INFO - 2020-09-05 23:46:30 --> Output Class Initialized
INFO - 2020-09-05 23:46:30 --> Security Class Initialized
DEBUG - 2020-09-05 23:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:46:30 --> Input Class Initialized
INFO - 2020-09-05 23:46:30 --> Language Class Initialized
INFO - 2020-09-05 23:46:30 --> Language Class Initialized
INFO - 2020-09-05 23:46:30 --> Config Class Initialized
INFO - 2020-09-05 23:46:30 --> Loader Class Initialized
INFO - 2020-09-05 23:46:30 --> Helper loaded: url_helper
INFO - 2020-09-05 23:46:30 --> Helper loaded: form_helper
INFO - 2020-09-05 23:46:30 --> Helper loaded: file_helper
INFO - 2020-09-05 23:46:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:46:30 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:46:30 --> Upload Class Initialized
INFO - 2020-09-05 23:46:30 --> Controller Class Initialized
DEBUG - 2020-09-05 23:46:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:46:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-05 23:46:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:46:30 --> Final output sent to browser
DEBUG - 2020-09-05 23:46:30 --> Total execution time: 0.0539
INFO - 2020-09-05 23:50:51 --> Config Class Initialized
INFO - 2020-09-05 23:50:51 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:50:51 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:50:51 --> Utf8 Class Initialized
INFO - 2020-09-05 23:50:51 --> URI Class Initialized
INFO - 2020-09-05 23:50:51 --> Router Class Initialized
INFO - 2020-09-05 23:50:51 --> Output Class Initialized
INFO - 2020-09-05 23:50:51 --> Security Class Initialized
DEBUG - 2020-09-05 23:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:50:51 --> Input Class Initialized
INFO - 2020-09-05 23:50:51 --> Language Class Initialized
INFO - 2020-09-05 23:50:51 --> Language Class Initialized
INFO - 2020-09-05 23:50:51 --> Config Class Initialized
INFO - 2020-09-05 23:50:51 --> Loader Class Initialized
INFO - 2020-09-05 23:50:51 --> Helper loaded: url_helper
INFO - 2020-09-05 23:50:51 --> Helper loaded: form_helper
INFO - 2020-09-05 23:50:51 --> Helper loaded: file_helper
INFO - 2020-09-05 23:50:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:50:51 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:50:51 --> Upload Class Initialized
INFO - 2020-09-05 23:50:51 --> Controller Class Initialized
DEBUG - 2020-09-05 23:50:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:50:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-05 23:50:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:50:51 --> Final output sent to browser
DEBUG - 2020-09-05 23:50:51 --> Total execution time: 0.0507
INFO - 2020-09-05 23:50:56 --> Config Class Initialized
INFO - 2020-09-05 23:50:56 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:50:56 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:50:56 --> Utf8 Class Initialized
INFO - 2020-09-05 23:50:56 --> URI Class Initialized
INFO - 2020-09-05 23:50:56 --> Router Class Initialized
INFO - 2020-09-05 23:50:56 --> Output Class Initialized
INFO - 2020-09-05 23:50:56 --> Security Class Initialized
DEBUG - 2020-09-05 23:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:50:56 --> Input Class Initialized
INFO - 2020-09-05 23:50:56 --> Language Class Initialized
INFO - 2020-09-05 23:50:56 --> Language Class Initialized
INFO - 2020-09-05 23:50:56 --> Config Class Initialized
INFO - 2020-09-05 23:50:56 --> Loader Class Initialized
INFO - 2020-09-05 23:50:56 --> Helper loaded: url_helper
INFO - 2020-09-05 23:50:56 --> Helper loaded: form_helper
INFO - 2020-09-05 23:50:56 --> Helper loaded: file_helper
INFO - 2020-09-05 23:50:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:50:56 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:50:56 --> Upload Class Initialized
INFO - 2020-09-05 23:50:56 --> Controller Class Initialized
ERROR - 2020-09-05 23:50:56 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:55:40 --> Config Class Initialized
INFO - 2020-09-05 23:55:40 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:55:40 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:55:40 --> Utf8 Class Initialized
INFO - 2020-09-05 23:55:40 --> URI Class Initialized
DEBUG - 2020-09-05 23:55:40 --> No URI present. Default controller set.
INFO - 2020-09-05 23:55:40 --> Router Class Initialized
INFO - 2020-09-05 23:55:40 --> Output Class Initialized
INFO - 2020-09-05 23:55:40 --> Security Class Initialized
DEBUG - 2020-09-05 23:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:55:40 --> Input Class Initialized
INFO - 2020-09-05 23:55:40 --> Language Class Initialized
INFO - 2020-09-05 23:55:40 --> Language Class Initialized
INFO - 2020-09-05 23:55:40 --> Config Class Initialized
INFO - 2020-09-05 23:55:40 --> Loader Class Initialized
INFO - 2020-09-05 23:55:40 --> Helper loaded: url_helper
INFO - 2020-09-05 23:55:40 --> Helper loaded: form_helper
INFO - 2020-09-05 23:55:40 --> Helper loaded: file_helper
INFO - 2020-09-05 23:55:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:55:40 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:55:40 --> Upload Class Initialized
INFO - 2020-09-05 23:55:41 --> Controller Class Initialized
DEBUG - 2020-09-05 23:55:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:55:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 23:55:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 23:55:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:55:41 --> Final output sent to browser
DEBUG - 2020-09-05 23:55:41 --> Total execution time: 0.0510
INFO - 2020-09-05 23:55:43 --> Config Class Initialized
INFO - 2020-09-05 23:55:43 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:55:43 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:55:43 --> Utf8 Class Initialized
INFO - 2020-09-05 23:55:43 --> URI Class Initialized
INFO - 2020-09-05 23:55:43 --> Router Class Initialized
INFO - 2020-09-05 23:55:43 --> Output Class Initialized
INFO - 2020-09-05 23:55:43 --> Security Class Initialized
DEBUG - 2020-09-05 23:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:55:43 --> Input Class Initialized
INFO - 2020-09-05 23:55:43 --> Language Class Initialized
INFO - 2020-09-05 23:55:43 --> Language Class Initialized
INFO - 2020-09-05 23:55:43 --> Config Class Initialized
INFO - 2020-09-05 23:55:43 --> Loader Class Initialized
INFO - 2020-09-05 23:55:43 --> Helper loaded: url_helper
INFO - 2020-09-05 23:55:43 --> Helper loaded: form_helper
INFO - 2020-09-05 23:55:43 --> Helper loaded: file_helper
INFO - 2020-09-05 23:55:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:55:43 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:55:43 --> Upload Class Initialized
INFO - 2020-09-05 23:55:43 --> Controller Class Initialized
ERROR - 2020-09-05 23:55:43 --> 404 Page Not Found: /index
INFO - 2020-09-05 23:59:44 --> Config Class Initialized
INFO - 2020-09-05 23:59:44 --> Hooks Class Initialized
DEBUG - 2020-09-05 23:59:44 --> UTF-8 Support Enabled
INFO - 2020-09-05 23:59:44 --> Utf8 Class Initialized
INFO - 2020-09-05 23:59:44 --> URI Class Initialized
DEBUG - 2020-09-05 23:59:44 --> No URI present. Default controller set.
INFO - 2020-09-05 23:59:44 --> Router Class Initialized
INFO - 2020-09-05 23:59:44 --> Output Class Initialized
INFO - 2020-09-05 23:59:44 --> Security Class Initialized
DEBUG - 2020-09-05 23:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-05 23:59:44 --> Input Class Initialized
INFO - 2020-09-05 23:59:44 --> Language Class Initialized
INFO - 2020-09-05 23:59:44 --> Language Class Initialized
INFO - 2020-09-05 23:59:44 --> Config Class Initialized
INFO - 2020-09-05 23:59:44 --> Loader Class Initialized
INFO - 2020-09-05 23:59:44 --> Helper loaded: url_helper
INFO - 2020-09-05 23:59:44 --> Helper loaded: form_helper
INFO - 2020-09-05 23:59:44 --> Helper loaded: file_helper
INFO - 2020-09-05 23:59:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-05 23:59:44 --> Database Driver Class Initialized
DEBUG - 2020-09-05 23:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-05 23:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-05 23:59:44 --> Upload Class Initialized
INFO - 2020-09-05 23:59:44 --> Controller Class Initialized
DEBUG - 2020-09-05 23:59:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-05 23:59:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-05 23:59:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-05 23:59:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-05 23:59:44 --> Final output sent to browser
DEBUG - 2020-09-05 23:59:44 --> Total execution time: 0.0506
