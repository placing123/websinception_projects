<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-06 00:21:54 --> Config Class Initialized
INFO - 2020-09-06 00:21:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 00:21:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 00:21:54 --> Utf8 Class Initialized
INFO - 2020-09-06 00:21:54 --> URI Class Initialized
DEBUG - 2020-09-06 00:21:54 --> No URI present. Default controller set.
INFO - 2020-09-06 00:21:54 --> Router Class Initialized
INFO - 2020-09-06 00:21:54 --> Output Class Initialized
INFO - 2020-09-06 00:21:54 --> Security Class Initialized
DEBUG - 2020-09-06 00:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 00:21:54 --> Input Class Initialized
INFO - 2020-09-06 00:21:54 --> Language Class Initialized
INFO - 2020-09-06 00:21:54 --> Language Class Initialized
INFO - 2020-09-06 00:21:54 --> Config Class Initialized
INFO - 2020-09-06 00:21:54 --> Loader Class Initialized
INFO - 2020-09-06 00:21:54 --> Helper loaded: url_helper
INFO - 2020-09-06 00:21:54 --> Helper loaded: form_helper
INFO - 2020-09-06 00:21:54 --> Helper loaded: file_helper
INFO - 2020-09-06 00:21:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 00:21:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 00:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 00:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 00:21:54 --> Upload Class Initialized
INFO - 2020-09-06 00:21:54 --> Controller Class Initialized
DEBUG - 2020-09-06 00:21:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 00:21:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 00:21:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 00:21:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 00:21:54 --> Final output sent to browser
DEBUG - 2020-09-06 00:21:54 --> Total execution time: 0.0516
INFO - 2020-09-06 00:33:44 --> Config Class Initialized
INFO - 2020-09-06 00:33:44 --> Hooks Class Initialized
DEBUG - 2020-09-06 00:33:44 --> UTF-8 Support Enabled
INFO - 2020-09-06 00:33:44 --> Utf8 Class Initialized
INFO - 2020-09-06 00:33:44 --> URI Class Initialized
DEBUG - 2020-09-06 00:33:44 --> No URI present. Default controller set.
INFO - 2020-09-06 00:33:44 --> Router Class Initialized
INFO - 2020-09-06 00:33:44 --> Output Class Initialized
INFO - 2020-09-06 00:33:44 --> Security Class Initialized
DEBUG - 2020-09-06 00:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 00:33:44 --> Input Class Initialized
INFO - 2020-09-06 00:33:44 --> Language Class Initialized
INFO - 2020-09-06 00:33:44 --> Language Class Initialized
INFO - 2020-09-06 00:33:44 --> Config Class Initialized
INFO - 2020-09-06 00:33:44 --> Loader Class Initialized
INFO - 2020-09-06 00:33:44 --> Helper loaded: url_helper
INFO - 2020-09-06 00:33:44 --> Helper loaded: form_helper
INFO - 2020-09-06 00:33:44 --> Helper loaded: file_helper
INFO - 2020-09-06 00:33:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 00:33:44 --> Database Driver Class Initialized
DEBUG - 2020-09-06 00:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 00:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 00:33:44 --> Upload Class Initialized
INFO - 2020-09-06 00:33:44 --> Controller Class Initialized
DEBUG - 2020-09-06 00:33:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 00:33:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 00:33:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 00:33:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 00:33:44 --> Final output sent to browser
DEBUG - 2020-09-06 00:33:44 --> Total execution time: 0.0531
INFO - 2020-09-06 00:33:44 --> Config Class Initialized
INFO - 2020-09-06 00:33:44 --> Hooks Class Initialized
DEBUG - 2020-09-06 00:33:44 --> UTF-8 Support Enabled
INFO - 2020-09-06 00:33:44 --> Utf8 Class Initialized
INFO - 2020-09-06 00:33:44 --> URI Class Initialized
DEBUG - 2020-09-06 00:33:44 --> No URI present. Default controller set.
INFO - 2020-09-06 00:33:44 --> Router Class Initialized
INFO - 2020-09-06 00:33:44 --> Output Class Initialized
INFO - 2020-09-06 00:33:44 --> Security Class Initialized
DEBUG - 2020-09-06 00:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 00:33:44 --> Input Class Initialized
INFO - 2020-09-06 00:33:44 --> Language Class Initialized
INFO - 2020-09-06 00:33:44 --> Language Class Initialized
INFO - 2020-09-06 00:33:44 --> Config Class Initialized
INFO - 2020-09-06 00:33:44 --> Loader Class Initialized
INFO - 2020-09-06 00:33:44 --> Helper loaded: url_helper
INFO - 2020-09-06 00:33:44 --> Helper loaded: form_helper
INFO - 2020-09-06 00:33:44 --> Helper loaded: file_helper
INFO - 2020-09-06 00:33:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 00:33:44 --> Database Driver Class Initialized
DEBUG - 2020-09-06 00:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 00:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 00:33:44 --> Upload Class Initialized
INFO - 2020-09-06 00:33:44 --> Controller Class Initialized
DEBUG - 2020-09-06 00:33:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 00:33:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 00:33:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 00:33:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 00:33:44 --> Final output sent to browser
DEBUG - 2020-09-06 00:33:44 --> Total execution time: 0.0535
INFO - 2020-09-06 01:13:19 --> Config Class Initialized
INFO - 2020-09-06 01:13:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 01:13:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 01:13:19 --> Utf8 Class Initialized
INFO - 2020-09-06 01:13:19 --> URI Class Initialized
INFO - 2020-09-06 01:13:19 --> Router Class Initialized
INFO - 2020-09-06 01:13:19 --> Output Class Initialized
INFO - 2020-09-06 01:13:19 --> Security Class Initialized
DEBUG - 2020-09-06 01:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 01:13:19 --> Input Class Initialized
INFO - 2020-09-06 01:13:19 --> Language Class Initialized
INFO - 2020-09-06 01:13:19 --> Language Class Initialized
INFO - 2020-09-06 01:13:19 --> Config Class Initialized
INFO - 2020-09-06 01:13:19 --> Loader Class Initialized
INFO - 2020-09-06 01:13:19 --> Helper loaded: url_helper
INFO - 2020-09-06 01:13:19 --> Helper loaded: form_helper
INFO - 2020-09-06 01:13:19 --> Helper loaded: file_helper
INFO - 2020-09-06 01:13:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 01:13:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 01:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 01:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 01:13:19 --> Upload Class Initialized
INFO - 2020-09-06 01:13:19 --> Controller Class Initialized
DEBUG - 2020-09-06 01:13:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 01:13:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 01:13:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 01:13:19 --> Final output sent to browser
DEBUG - 2020-09-06 01:13:19 --> Total execution time: 0.0833
INFO - 2020-09-06 01:13:22 --> Config Class Initialized
INFO - 2020-09-06 01:13:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 01:13:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 01:13:22 --> Utf8 Class Initialized
INFO - 2020-09-06 01:13:22 --> URI Class Initialized
INFO - 2020-09-06 01:13:22 --> Router Class Initialized
INFO - 2020-09-06 01:13:22 --> Output Class Initialized
INFO - 2020-09-06 01:13:22 --> Security Class Initialized
DEBUG - 2020-09-06 01:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 01:13:22 --> Input Class Initialized
INFO - 2020-09-06 01:13:22 --> Language Class Initialized
INFO - 2020-09-06 01:13:22 --> Language Class Initialized
INFO - 2020-09-06 01:13:22 --> Config Class Initialized
INFO - 2020-09-06 01:13:22 --> Loader Class Initialized
INFO - 2020-09-06 01:13:22 --> Helper loaded: url_helper
INFO - 2020-09-06 01:13:22 --> Helper loaded: form_helper
INFO - 2020-09-06 01:13:22 --> Helper loaded: file_helper
INFO - 2020-09-06 01:13:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 01:13:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 01:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 01:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 01:13:22 --> Upload Class Initialized
INFO - 2020-09-06 01:13:22 --> Controller Class Initialized
DEBUG - 2020-09-06 01:13:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 01:13:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-06 01:13:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 01:13:22 --> Final output sent to browser
DEBUG - 2020-09-06 01:13:22 --> Total execution time: 0.0515
INFO - 2020-09-06 02:54:39 --> Config Class Initialized
INFO - 2020-09-06 02:54:39 --> Hooks Class Initialized
DEBUG - 2020-09-06 02:54:39 --> UTF-8 Support Enabled
INFO - 2020-09-06 02:54:39 --> Utf8 Class Initialized
INFO - 2020-09-06 02:54:39 --> URI Class Initialized
DEBUG - 2020-09-06 02:54:39 --> No URI present. Default controller set.
INFO - 2020-09-06 02:54:39 --> Router Class Initialized
INFO - 2020-09-06 02:54:39 --> Output Class Initialized
INFO - 2020-09-06 02:54:39 --> Security Class Initialized
DEBUG - 2020-09-06 02:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 02:54:39 --> Input Class Initialized
INFO - 2020-09-06 02:54:39 --> Language Class Initialized
INFO - 2020-09-06 02:54:39 --> Language Class Initialized
INFO - 2020-09-06 02:54:39 --> Config Class Initialized
INFO - 2020-09-06 02:54:39 --> Loader Class Initialized
INFO - 2020-09-06 02:54:39 --> Helper loaded: url_helper
INFO - 2020-09-06 02:54:39 --> Helper loaded: form_helper
INFO - 2020-09-06 02:54:39 --> Helper loaded: file_helper
INFO - 2020-09-06 02:54:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 02:54:39 --> Database Driver Class Initialized
DEBUG - 2020-09-06 02:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 02:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 02:54:39 --> Upload Class Initialized
INFO - 2020-09-06 02:54:39 --> Controller Class Initialized
DEBUG - 2020-09-06 02:54:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 02:54:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 02:54:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 02:54:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 02:54:39 --> Final output sent to browser
DEBUG - 2020-09-06 02:54:39 --> Total execution time: 0.0806
INFO - 2020-09-06 03:16:32 --> Config Class Initialized
INFO - 2020-09-06 03:16:32 --> Hooks Class Initialized
DEBUG - 2020-09-06 03:16:32 --> UTF-8 Support Enabled
INFO - 2020-09-06 03:16:32 --> Utf8 Class Initialized
INFO - 2020-09-06 03:16:32 --> URI Class Initialized
DEBUG - 2020-09-06 03:16:32 --> No URI present. Default controller set.
INFO - 2020-09-06 03:16:32 --> Router Class Initialized
INFO - 2020-09-06 03:16:32 --> Output Class Initialized
INFO - 2020-09-06 03:16:32 --> Security Class Initialized
DEBUG - 2020-09-06 03:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 03:16:32 --> Input Class Initialized
INFO - 2020-09-06 03:16:32 --> Language Class Initialized
INFO - 2020-09-06 03:16:32 --> Language Class Initialized
INFO - 2020-09-06 03:16:32 --> Config Class Initialized
INFO - 2020-09-06 03:16:32 --> Loader Class Initialized
INFO - 2020-09-06 03:16:32 --> Helper loaded: url_helper
INFO - 2020-09-06 03:16:32 --> Helper loaded: form_helper
INFO - 2020-09-06 03:16:32 --> Helper loaded: file_helper
INFO - 2020-09-06 03:16:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 03:16:32 --> Database Driver Class Initialized
DEBUG - 2020-09-06 03:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 03:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 03:16:32 --> Upload Class Initialized
INFO - 2020-09-06 03:16:32 --> Controller Class Initialized
DEBUG - 2020-09-06 03:16:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 03:16:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 03:16:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 03:16:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 03:16:32 --> Final output sent to browser
DEBUG - 2020-09-06 03:16:32 --> Total execution time: 0.0494
INFO - 2020-09-06 05:06:28 --> Config Class Initialized
INFO - 2020-09-06 05:06:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 05:06:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 05:06:28 --> Utf8 Class Initialized
INFO - 2020-09-06 05:06:28 --> URI Class Initialized
INFO - 2020-09-06 05:06:28 --> Router Class Initialized
INFO - 2020-09-06 05:06:28 --> Output Class Initialized
INFO - 2020-09-06 05:06:28 --> Security Class Initialized
DEBUG - 2020-09-06 05:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 05:06:28 --> Input Class Initialized
INFO - 2020-09-06 05:06:28 --> Language Class Initialized
INFO - 2020-09-06 05:06:28 --> Language Class Initialized
INFO - 2020-09-06 05:06:28 --> Config Class Initialized
INFO - 2020-09-06 05:06:28 --> Loader Class Initialized
INFO - 2020-09-06 05:06:28 --> Helper loaded: url_helper
INFO - 2020-09-06 05:06:28 --> Helper loaded: form_helper
INFO - 2020-09-06 05:06:28 --> Helper loaded: file_helper
INFO - 2020-09-06 05:06:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 05:06:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 05:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 05:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 05:06:28 --> Upload Class Initialized
INFO - 2020-09-06 05:06:28 --> Controller Class Initialized
ERROR - 2020-09-06 05:06:28 --> 404 Page Not Found: /index
INFO - 2020-09-06 05:06:29 --> Config Class Initialized
INFO - 2020-09-06 05:06:29 --> Hooks Class Initialized
DEBUG - 2020-09-06 05:06:29 --> UTF-8 Support Enabled
INFO - 2020-09-06 05:06:29 --> Utf8 Class Initialized
INFO - 2020-09-06 05:06:29 --> URI Class Initialized
DEBUG - 2020-09-06 05:06:29 --> No URI present. Default controller set.
INFO - 2020-09-06 05:06:29 --> Router Class Initialized
INFO - 2020-09-06 05:06:29 --> Output Class Initialized
INFO - 2020-09-06 05:06:29 --> Security Class Initialized
DEBUG - 2020-09-06 05:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 05:06:29 --> Input Class Initialized
INFO - 2020-09-06 05:06:29 --> Language Class Initialized
INFO - 2020-09-06 05:06:29 --> Language Class Initialized
INFO - 2020-09-06 05:06:29 --> Config Class Initialized
INFO - 2020-09-06 05:06:29 --> Loader Class Initialized
INFO - 2020-09-06 05:06:29 --> Helper loaded: url_helper
INFO - 2020-09-06 05:06:29 --> Helper loaded: form_helper
INFO - 2020-09-06 05:06:29 --> Helper loaded: file_helper
INFO - 2020-09-06 05:06:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 05:06:29 --> Database Driver Class Initialized
DEBUG - 2020-09-06 05:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 05:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 05:06:29 --> Upload Class Initialized
INFO - 2020-09-06 05:06:29 --> Controller Class Initialized
DEBUG - 2020-09-06 05:06:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 05:06:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 05:06:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 05:06:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 05:06:29 --> Final output sent to browser
DEBUG - 2020-09-06 05:06:29 --> Total execution time: 0.0488
INFO - 2020-09-06 06:03:27 --> Config Class Initialized
INFO - 2020-09-06 06:03:27 --> Hooks Class Initialized
DEBUG - 2020-09-06 06:03:27 --> UTF-8 Support Enabled
INFO - 2020-09-06 06:03:27 --> Utf8 Class Initialized
INFO - 2020-09-06 06:03:27 --> URI Class Initialized
INFO - 2020-09-06 06:03:27 --> Router Class Initialized
INFO - 2020-09-06 06:03:27 --> Output Class Initialized
INFO - 2020-09-06 06:03:27 --> Security Class Initialized
DEBUG - 2020-09-06 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 06:03:27 --> Input Class Initialized
INFO - 2020-09-06 06:03:27 --> Language Class Initialized
INFO - 2020-09-06 06:03:27 --> Language Class Initialized
INFO - 2020-09-06 06:03:27 --> Config Class Initialized
INFO - 2020-09-06 06:03:27 --> Loader Class Initialized
INFO - 2020-09-06 06:03:27 --> Helper loaded: url_helper
INFO - 2020-09-06 06:03:27 --> Helper loaded: form_helper
INFO - 2020-09-06 06:03:27 --> Helper loaded: file_helper
INFO - 2020-09-06 06:03:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 06:03:27 --> Database Driver Class Initialized
DEBUG - 2020-09-06 06:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 06:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 06:03:27 --> Upload Class Initialized
INFO - 2020-09-06 06:03:27 --> Controller Class Initialized
ERROR - 2020-09-06 06:03:27 --> 404 Page Not Found: /index
INFO - 2020-09-06 06:03:28 --> Config Class Initialized
INFO - 2020-09-06 06:03:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 06:03:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 06:03:28 --> Utf8 Class Initialized
INFO - 2020-09-06 06:03:28 --> URI Class Initialized
DEBUG - 2020-09-06 06:03:28 --> No URI present. Default controller set.
INFO - 2020-09-06 06:03:28 --> Router Class Initialized
INFO - 2020-09-06 06:03:28 --> Output Class Initialized
INFO - 2020-09-06 06:03:28 --> Security Class Initialized
DEBUG - 2020-09-06 06:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 06:03:28 --> Input Class Initialized
INFO - 2020-09-06 06:03:28 --> Language Class Initialized
INFO - 2020-09-06 06:03:28 --> Language Class Initialized
INFO - 2020-09-06 06:03:28 --> Config Class Initialized
INFO - 2020-09-06 06:03:28 --> Loader Class Initialized
INFO - 2020-09-06 06:03:28 --> Helper loaded: url_helper
INFO - 2020-09-06 06:03:28 --> Helper loaded: form_helper
INFO - 2020-09-06 06:03:28 --> Helper loaded: file_helper
INFO - 2020-09-06 06:03:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 06:03:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 06:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 06:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 06:03:28 --> Upload Class Initialized
INFO - 2020-09-06 06:03:28 --> Controller Class Initialized
DEBUG - 2020-09-06 06:03:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 06:03:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 06:03:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 06:03:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 06:03:28 --> Final output sent to browser
DEBUG - 2020-09-06 06:03:28 --> Total execution time: 0.0499
INFO - 2020-09-06 07:20:08 --> Config Class Initialized
INFO - 2020-09-06 07:20:08 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:20:08 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:20:08 --> Utf8 Class Initialized
INFO - 2020-09-06 07:20:08 --> URI Class Initialized
DEBUG - 2020-09-06 07:20:08 --> No URI present. Default controller set.
INFO - 2020-09-06 07:20:08 --> Router Class Initialized
INFO - 2020-09-06 07:20:08 --> Output Class Initialized
INFO - 2020-09-06 07:20:08 --> Security Class Initialized
DEBUG - 2020-09-06 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:20:08 --> Input Class Initialized
INFO - 2020-09-06 07:20:08 --> Language Class Initialized
INFO - 2020-09-06 07:20:08 --> Language Class Initialized
INFO - 2020-09-06 07:20:08 --> Config Class Initialized
INFO - 2020-09-06 07:20:08 --> Loader Class Initialized
INFO - 2020-09-06 07:20:08 --> Helper loaded: url_helper
INFO - 2020-09-06 07:20:08 --> Helper loaded: form_helper
INFO - 2020-09-06 07:20:08 --> Helper loaded: file_helper
INFO - 2020-09-06 07:20:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:20:08 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:20:08 --> Upload Class Initialized
INFO - 2020-09-06 07:20:08 --> Controller Class Initialized
DEBUG - 2020-09-06 07:20:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 07:20:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 07:20:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 07:20:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 07:20:08 --> Final output sent to browser
DEBUG - 2020-09-06 07:20:08 --> Total execution time: 0.0876
INFO - 2020-09-06 07:45:41 --> Config Class Initialized
INFO - 2020-09-06 07:45:41 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:45:41 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:45:41 --> Utf8 Class Initialized
INFO - 2020-09-06 07:45:41 --> URI Class Initialized
DEBUG - 2020-09-06 07:45:41 --> No URI present. Default controller set.
INFO - 2020-09-06 07:45:41 --> Router Class Initialized
INFO - 2020-09-06 07:45:41 --> Output Class Initialized
INFO - 2020-09-06 07:45:41 --> Security Class Initialized
DEBUG - 2020-09-06 07:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:45:41 --> Input Class Initialized
INFO - 2020-09-06 07:45:41 --> Language Class Initialized
INFO - 2020-09-06 07:45:41 --> Language Class Initialized
INFO - 2020-09-06 07:45:41 --> Config Class Initialized
INFO - 2020-09-06 07:45:41 --> Loader Class Initialized
INFO - 2020-09-06 07:45:41 --> Helper loaded: url_helper
INFO - 2020-09-06 07:45:41 --> Helper loaded: form_helper
INFO - 2020-09-06 07:45:41 --> Helper loaded: file_helper
INFO - 2020-09-06 07:45:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:45:41 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:45:41 --> Upload Class Initialized
INFO - 2020-09-06 07:45:41 --> Controller Class Initialized
DEBUG - 2020-09-06 07:45:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 07:45:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 07:45:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 07:45:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 07:45:41 --> Final output sent to browser
DEBUG - 2020-09-06 07:45:41 --> Total execution time: 0.0520
INFO - 2020-09-06 07:48:33 --> Config Class Initialized
INFO - 2020-09-06 07:48:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:48:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:48:33 --> Utf8 Class Initialized
INFO - 2020-09-06 07:48:33 --> URI Class Initialized
INFO - 2020-09-06 07:48:33 --> Router Class Initialized
INFO - 2020-09-06 07:48:33 --> Output Class Initialized
INFO - 2020-09-06 07:48:33 --> Security Class Initialized
DEBUG - 2020-09-06 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:48:33 --> Input Class Initialized
INFO - 2020-09-06 07:48:33 --> Language Class Initialized
INFO - 2020-09-06 07:48:33 --> Language Class Initialized
INFO - 2020-09-06 07:48:33 --> Config Class Initialized
INFO - 2020-09-06 07:48:33 --> Loader Class Initialized
INFO - 2020-09-06 07:48:33 --> Helper loaded: url_helper
INFO - 2020-09-06 07:48:33 --> Helper loaded: form_helper
INFO - 2020-09-06 07:48:33 --> Helper loaded: file_helper
INFO - 2020-09-06 07:48:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:48:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:48:33 --> Upload Class Initialized
INFO - 2020-09-06 07:48:33 --> Controller Class Initialized
DEBUG - 2020-09-06 07:48:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 07:48:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-06 07:48:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 07:48:33 --> Final output sent to browser
DEBUG - 2020-09-06 07:48:33 --> Total execution time: 0.0547
INFO - 2020-09-06 07:48:33 --> Config Class Initialized
INFO - 2020-09-06 07:48:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:48:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:48:33 --> Utf8 Class Initialized
INFO - 2020-09-06 07:48:33 --> URI Class Initialized
INFO - 2020-09-06 07:48:33 --> Router Class Initialized
INFO - 2020-09-06 07:48:33 --> Output Class Initialized
INFO - 2020-09-06 07:48:33 --> Security Class Initialized
DEBUG - 2020-09-06 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:48:33 --> Input Class Initialized
INFO - 2020-09-06 07:48:33 --> Language Class Initialized
INFO - 2020-09-06 07:48:33 --> Language Class Initialized
INFO - 2020-09-06 07:48:33 --> Config Class Initialized
INFO - 2020-09-06 07:48:33 --> Loader Class Initialized
INFO - 2020-09-06 07:48:33 --> Helper loaded: url_helper
INFO - 2020-09-06 07:48:33 --> Helper loaded: form_helper
INFO - 2020-09-06 07:48:33 --> Helper loaded: file_helper
INFO - 2020-09-06 07:48:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:48:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:48:33 --> Upload Class Initialized
INFO - 2020-09-06 07:48:33 --> Controller Class Initialized
DEBUG - 2020-09-06 07:48:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 07:48:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-06 07:48:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 07:48:33 --> Final output sent to browser
DEBUG - 2020-09-06 07:48:33 --> Total execution time: 0.0500
INFO - 2020-09-06 07:48:45 --> Config Class Initialized
INFO - 2020-09-06 07:48:45 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:48:45 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:48:45 --> Utf8 Class Initialized
INFO - 2020-09-06 07:48:45 --> URI Class Initialized
INFO - 2020-09-06 07:48:45 --> Router Class Initialized
INFO - 2020-09-06 07:48:45 --> Output Class Initialized
INFO - 2020-09-06 07:48:45 --> Security Class Initialized
DEBUG - 2020-09-06 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:48:45 --> Input Class Initialized
INFO - 2020-09-06 07:48:45 --> Language Class Initialized
INFO - 2020-09-06 07:48:45 --> Language Class Initialized
INFO - 2020-09-06 07:48:45 --> Config Class Initialized
INFO - 2020-09-06 07:48:45 --> Loader Class Initialized
INFO - 2020-09-06 07:48:45 --> Helper loaded: url_helper
INFO - 2020-09-06 07:48:45 --> Helper loaded: form_helper
INFO - 2020-09-06 07:48:45 --> Helper loaded: file_helper
INFO - 2020-09-06 07:48:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:48:45 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:48:45 --> Upload Class Initialized
INFO - 2020-09-06 07:48:45 --> Controller Class Initialized
ERROR - 2020-09-06 07:48:45 --> 404 Page Not Found: /index
INFO - 2020-09-06 07:48:46 --> Config Class Initialized
INFO - 2020-09-06 07:48:46 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:48:46 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:48:46 --> Utf8 Class Initialized
INFO - 2020-09-06 07:48:46 --> URI Class Initialized
INFO - 2020-09-06 07:48:46 --> Router Class Initialized
INFO - 2020-09-06 07:48:46 --> Output Class Initialized
INFO - 2020-09-06 07:48:46 --> Security Class Initialized
DEBUG - 2020-09-06 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:48:46 --> Input Class Initialized
INFO - 2020-09-06 07:48:46 --> Language Class Initialized
INFO - 2020-09-06 07:48:46 --> Language Class Initialized
INFO - 2020-09-06 07:48:46 --> Config Class Initialized
INFO - 2020-09-06 07:48:46 --> Loader Class Initialized
INFO - 2020-09-06 07:48:46 --> Helper loaded: url_helper
INFO - 2020-09-06 07:48:46 --> Helper loaded: form_helper
INFO - 2020-09-06 07:48:46 --> Helper loaded: file_helper
INFO - 2020-09-06 07:48:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:48:46 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:48:46 --> Upload Class Initialized
INFO - 2020-09-06 07:48:46 --> Controller Class Initialized
ERROR - 2020-09-06 07:48:46 --> 404 Page Not Found: /index
INFO - 2020-09-06 07:49:40 --> Config Class Initialized
INFO - 2020-09-06 07:49:40 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:49:40 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:49:40 --> Utf8 Class Initialized
INFO - 2020-09-06 07:49:40 --> URI Class Initialized
INFO - 2020-09-06 07:49:40 --> Router Class Initialized
INFO - 2020-09-06 07:49:40 --> Output Class Initialized
INFO - 2020-09-06 07:49:40 --> Security Class Initialized
DEBUG - 2020-09-06 07:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:49:40 --> Input Class Initialized
INFO - 2020-09-06 07:49:40 --> Language Class Initialized
INFO - 2020-09-06 07:49:40 --> Language Class Initialized
INFO - 2020-09-06 07:49:40 --> Config Class Initialized
INFO - 2020-09-06 07:49:40 --> Loader Class Initialized
INFO - 2020-09-06 07:49:40 --> Helper loaded: url_helper
INFO - 2020-09-06 07:49:40 --> Helper loaded: form_helper
INFO - 2020-09-06 07:49:40 --> Helper loaded: file_helper
INFO - 2020-09-06 07:49:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:49:40 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:49:40 --> Upload Class Initialized
INFO - 2020-09-06 07:49:40 --> Controller Class Initialized
DEBUG - 2020-09-06 07:49:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 07:49:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 07:49:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 07:49:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 07:49:40 --> Final output sent to browser
DEBUG - 2020-09-06 07:49:40 --> Total execution time: 0.0507
INFO - 2020-09-06 07:51:24 --> Config Class Initialized
INFO - 2020-09-06 07:51:24 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:51:24 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:51:24 --> Utf8 Class Initialized
INFO - 2020-09-06 07:51:24 --> URI Class Initialized
INFO - 2020-09-06 07:51:24 --> Router Class Initialized
INFO - 2020-09-06 07:51:24 --> Output Class Initialized
INFO - 2020-09-06 07:51:24 --> Security Class Initialized
DEBUG - 2020-09-06 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:51:24 --> Input Class Initialized
INFO - 2020-09-06 07:51:24 --> Language Class Initialized
INFO - 2020-09-06 07:51:24 --> Language Class Initialized
INFO - 2020-09-06 07:51:24 --> Config Class Initialized
INFO - 2020-09-06 07:51:24 --> Loader Class Initialized
INFO - 2020-09-06 07:51:24 --> Helper loaded: url_helper
INFO - 2020-09-06 07:51:24 --> Helper loaded: form_helper
INFO - 2020-09-06 07:51:24 --> Helper loaded: file_helper
INFO - 2020-09-06 07:51:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:51:24 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:51:24 --> Upload Class Initialized
INFO - 2020-09-06 07:51:24 --> Controller Class Initialized
DEBUG - 2020-09-06 07:51:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 07:51:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 07:51:24 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 07:51:24 --> Final output sent to browser
DEBUG - 2020-09-06 07:51:24 --> Total execution time: 0.0513
INFO - 2020-09-06 07:51:29 --> Config Class Initialized
INFO - 2020-09-06 07:51:29 --> Hooks Class Initialized
DEBUG - 2020-09-06 07:51:29 --> UTF-8 Support Enabled
INFO - 2020-09-06 07:51:29 --> Utf8 Class Initialized
INFO - 2020-09-06 07:51:29 --> URI Class Initialized
INFO - 2020-09-06 07:51:29 --> Router Class Initialized
INFO - 2020-09-06 07:51:29 --> Output Class Initialized
INFO - 2020-09-06 07:51:29 --> Security Class Initialized
DEBUG - 2020-09-06 07:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 07:51:29 --> Input Class Initialized
INFO - 2020-09-06 07:51:29 --> Language Class Initialized
INFO - 2020-09-06 07:51:29 --> Language Class Initialized
INFO - 2020-09-06 07:51:29 --> Config Class Initialized
INFO - 2020-09-06 07:51:29 --> Loader Class Initialized
INFO - 2020-09-06 07:51:29 --> Helper loaded: url_helper
INFO - 2020-09-06 07:51:29 --> Helper loaded: form_helper
INFO - 2020-09-06 07:51:29 --> Helper loaded: file_helper
INFO - 2020-09-06 07:51:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 07:51:29 --> Database Driver Class Initialized
DEBUG - 2020-09-06 07:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 07:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 07:51:29 --> Upload Class Initialized
INFO - 2020-09-06 07:51:29 --> Controller Class Initialized
ERROR - 2020-09-06 07:51:29 --> 404 Page Not Found: /index
INFO - 2020-09-06 08:07:28 --> Config Class Initialized
INFO - 2020-09-06 08:07:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 08:07:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 08:07:28 --> Utf8 Class Initialized
INFO - 2020-09-06 08:07:28 --> URI Class Initialized
INFO - 2020-09-06 08:07:28 --> Router Class Initialized
INFO - 2020-09-06 08:07:28 --> Output Class Initialized
INFO - 2020-09-06 08:07:28 --> Security Class Initialized
DEBUG - 2020-09-06 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 08:07:28 --> Input Class Initialized
INFO - 2020-09-06 08:07:28 --> Language Class Initialized
INFO - 2020-09-06 08:07:28 --> Language Class Initialized
INFO - 2020-09-06 08:07:28 --> Config Class Initialized
INFO - 2020-09-06 08:07:28 --> Loader Class Initialized
INFO - 2020-09-06 08:07:28 --> Helper loaded: url_helper
INFO - 2020-09-06 08:07:28 --> Helper loaded: form_helper
INFO - 2020-09-06 08:07:28 --> Helper loaded: file_helper
INFO - 2020-09-06 08:07:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 08:07:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 08:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 08:07:28 --> Upload Class Initialized
INFO - 2020-09-06 08:07:28 --> Controller Class Initialized
ERROR - 2020-09-06 08:07:28 --> 404 Page Not Found: /index
INFO - 2020-09-06 08:07:29 --> Config Class Initialized
INFO - 2020-09-06 08:07:29 --> Hooks Class Initialized
DEBUG - 2020-09-06 08:07:29 --> UTF-8 Support Enabled
INFO - 2020-09-06 08:07:29 --> Utf8 Class Initialized
INFO - 2020-09-06 08:07:29 --> URI Class Initialized
DEBUG - 2020-09-06 08:07:29 --> No URI present. Default controller set.
INFO - 2020-09-06 08:07:29 --> Router Class Initialized
INFO - 2020-09-06 08:07:29 --> Output Class Initialized
INFO - 2020-09-06 08:07:29 --> Security Class Initialized
DEBUG - 2020-09-06 08:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 08:07:29 --> Input Class Initialized
INFO - 2020-09-06 08:07:29 --> Language Class Initialized
INFO - 2020-09-06 08:07:29 --> Language Class Initialized
INFO - 2020-09-06 08:07:29 --> Config Class Initialized
INFO - 2020-09-06 08:07:29 --> Loader Class Initialized
INFO - 2020-09-06 08:07:29 --> Helper loaded: url_helper
INFO - 2020-09-06 08:07:29 --> Helper loaded: form_helper
INFO - 2020-09-06 08:07:29 --> Helper loaded: file_helper
INFO - 2020-09-06 08:07:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 08:07:29 --> Database Driver Class Initialized
DEBUG - 2020-09-06 08:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 08:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 08:07:29 --> Upload Class Initialized
INFO - 2020-09-06 08:07:29 --> Controller Class Initialized
DEBUG - 2020-09-06 08:07:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 08:07:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 08:07:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 08:07:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 08:07:29 --> Final output sent to browser
DEBUG - 2020-09-06 08:07:29 --> Total execution time: 0.0509
INFO - 2020-09-06 08:39:15 --> Config Class Initialized
INFO - 2020-09-06 08:39:15 --> Hooks Class Initialized
DEBUG - 2020-09-06 08:39:15 --> UTF-8 Support Enabled
INFO - 2020-09-06 08:39:15 --> Utf8 Class Initialized
INFO - 2020-09-06 08:39:15 --> URI Class Initialized
INFO - 2020-09-06 08:39:15 --> Router Class Initialized
INFO - 2020-09-06 08:39:15 --> Output Class Initialized
INFO - 2020-09-06 08:39:15 --> Security Class Initialized
DEBUG - 2020-09-06 08:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 08:39:15 --> Input Class Initialized
INFO - 2020-09-06 08:39:15 --> Language Class Initialized
INFO - 2020-09-06 08:39:15 --> Language Class Initialized
INFO - 2020-09-06 08:39:15 --> Config Class Initialized
INFO - 2020-09-06 08:39:15 --> Loader Class Initialized
INFO - 2020-09-06 08:39:15 --> Helper loaded: url_helper
INFO - 2020-09-06 08:39:15 --> Helper loaded: form_helper
INFO - 2020-09-06 08:39:15 --> Helper loaded: file_helper
INFO - 2020-09-06 08:39:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 08:39:15 --> Database Driver Class Initialized
DEBUG - 2020-09-06 08:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 08:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 08:39:15 --> Upload Class Initialized
INFO - 2020-09-06 08:39:15 --> Controller Class Initialized
ERROR - 2020-09-06 08:39:15 --> 404 Page Not Found: /index
INFO - 2020-09-06 09:01:42 --> Config Class Initialized
INFO - 2020-09-06 09:01:42 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:01:42 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:01:42 --> Utf8 Class Initialized
INFO - 2020-09-06 09:01:42 --> URI Class Initialized
INFO - 2020-09-06 09:01:42 --> Router Class Initialized
INFO - 2020-09-06 09:01:42 --> Output Class Initialized
INFO - 2020-09-06 09:01:42 --> Security Class Initialized
DEBUG - 2020-09-06 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:01:42 --> Input Class Initialized
INFO - 2020-09-06 09:01:42 --> Language Class Initialized
INFO - 2020-09-06 09:01:42 --> Language Class Initialized
INFO - 2020-09-06 09:01:42 --> Config Class Initialized
INFO - 2020-09-06 09:01:42 --> Loader Class Initialized
INFO - 2020-09-06 09:01:42 --> Helper loaded: url_helper
INFO - 2020-09-06 09:01:42 --> Helper loaded: form_helper
INFO - 2020-09-06 09:01:42 --> Helper loaded: file_helper
INFO - 2020-09-06 09:01:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:01:42 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:01:42 --> Upload Class Initialized
INFO - 2020-09-06 09:01:42 --> Controller Class Initialized
ERROR - 2020-09-06 09:01:42 --> 404 Page Not Found: /index
INFO - 2020-09-06 09:02:01 --> Config Class Initialized
INFO - 2020-09-06 09:02:01 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:02:01 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:02:01 --> Utf8 Class Initialized
INFO - 2020-09-06 09:02:01 --> URI Class Initialized
INFO - 2020-09-06 09:02:01 --> Router Class Initialized
INFO - 2020-09-06 09:02:01 --> Output Class Initialized
INFO - 2020-09-06 09:02:01 --> Security Class Initialized
DEBUG - 2020-09-06 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:02:01 --> Input Class Initialized
INFO - 2020-09-06 09:02:01 --> Language Class Initialized
INFO - 2020-09-06 09:02:01 --> Language Class Initialized
INFO - 2020-09-06 09:02:01 --> Config Class Initialized
INFO - 2020-09-06 09:02:01 --> Loader Class Initialized
INFO - 2020-09-06 09:02:01 --> Helper loaded: url_helper
INFO - 2020-09-06 09:02:01 --> Helper loaded: form_helper
INFO - 2020-09-06 09:02:01 --> Helper loaded: file_helper
INFO - 2020-09-06 09:02:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:02:01 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:02:02 --> Upload Class Initialized
INFO - 2020-09-06 09:02:02 --> Controller Class Initialized
ERROR - 2020-09-06 09:02:02 --> 404 Page Not Found: /index
INFO - 2020-09-06 09:02:37 --> Config Class Initialized
INFO - 2020-09-06 09:02:37 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:02:37 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:02:37 --> Utf8 Class Initialized
INFO - 2020-09-06 09:02:37 --> URI Class Initialized
INFO - 2020-09-06 09:02:37 --> Router Class Initialized
INFO - 2020-09-06 09:02:37 --> Output Class Initialized
INFO - 2020-09-06 09:02:37 --> Security Class Initialized
DEBUG - 2020-09-06 09:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:02:37 --> Input Class Initialized
INFO - 2020-09-06 09:02:37 --> Language Class Initialized
INFO - 2020-09-06 09:02:37 --> Language Class Initialized
INFO - 2020-09-06 09:02:37 --> Config Class Initialized
INFO - 2020-09-06 09:02:37 --> Loader Class Initialized
INFO - 2020-09-06 09:02:37 --> Helper loaded: url_helper
INFO - 2020-09-06 09:02:37 --> Helper loaded: form_helper
INFO - 2020-09-06 09:02:37 --> Helper loaded: file_helper
INFO - 2020-09-06 09:02:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:02:37 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:02:37 --> Upload Class Initialized
INFO - 2020-09-06 09:02:37 --> Controller Class Initialized
ERROR - 2020-09-06 09:02:37 --> 404 Page Not Found: /index
INFO - 2020-09-06 09:03:02 --> Config Class Initialized
INFO - 2020-09-06 09:03:02 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:03:02 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:03:02 --> Utf8 Class Initialized
INFO - 2020-09-06 09:03:02 --> URI Class Initialized
INFO - 2020-09-06 09:03:02 --> Router Class Initialized
INFO - 2020-09-06 09:03:02 --> Output Class Initialized
INFO - 2020-09-06 09:03:02 --> Security Class Initialized
DEBUG - 2020-09-06 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:03:02 --> Input Class Initialized
INFO - 2020-09-06 09:03:02 --> Language Class Initialized
INFO - 2020-09-06 09:03:02 --> Language Class Initialized
INFO - 2020-09-06 09:03:02 --> Config Class Initialized
INFO - 2020-09-06 09:03:02 --> Loader Class Initialized
INFO - 2020-09-06 09:03:02 --> Helper loaded: url_helper
INFO - 2020-09-06 09:03:02 --> Helper loaded: form_helper
INFO - 2020-09-06 09:03:02 --> Helper loaded: file_helper
INFO - 2020-09-06 09:03:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:03:02 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:03:02 --> Upload Class Initialized
INFO - 2020-09-06 09:03:02 --> Controller Class Initialized
ERROR - 2020-09-06 09:03:02 --> 404 Page Not Found: /index
INFO - 2020-09-06 09:14:56 --> Config Class Initialized
INFO - 2020-09-06 09:14:56 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:14:56 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:14:56 --> Utf8 Class Initialized
INFO - 2020-09-06 09:14:56 --> URI Class Initialized
DEBUG - 2020-09-06 09:14:56 --> No URI present. Default controller set.
INFO - 2020-09-06 09:14:56 --> Router Class Initialized
INFO - 2020-09-06 09:14:56 --> Output Class Initialized
INFO - 2020-09-06 09:14:56 --> Security Class Initialized
DEBUG - 2020-09-06 09:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:14:56 --> Input Class Initialized
INFO - 2020-09-06 09:14:56 --> Language Class Initialized
INFO - 2020-09-06 09:14:56 --> Language Class Initialized
INFO - 2020-09-06 09:14:56 --> Config Class Initialized
INFO - 2020-09-06 09:14:56 --> Loader Class Initialized
INFO - 2020-09-06 09:14:56 --> Helper loaded: url_helper
INFO - 2020-09-06 09:14:56 --> Helper loaded: form_helper
INFO - 2020-09-06 09:14:56 --> Helper loaded: file_helper
INFO - 2020-09-06 09:14:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:14:56 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:14:56 --> Upload Class Initialized
INFO - 2020-09-06 09:14:56 --> Controller Class Initialized
DEBUG - 2020-09-06 09:14:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 09:14:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 09:14:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 09:14:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 09:14:56 --> Final output sent to browser
DEBUG - 2020-09-06 09:14:56 --> Total execution time: 0.0677
INFO - 2020-09-06 09:30:06 --> Config Class Initialized
INFO - 2020-09-06 09:30:06 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:30:06 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:30:06 --> Utf8 Class Initialized
INFO - 2020-09-06 09:30:06 --> URI Class Initialized
DEBUG - 2020-09-06 09:30:06 --> No URI present. Default controller set.
INFO - 2020-09-06 09:30:06 --> Router Class Initialized
INFO - 2020-09-06 09:30:06 --> Output Class Initialized
INFO - 2020-09-06 09:30:06 --> Security Class Initialized
DEBUG - 2020-09-06 09:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:30:06 --> Input Class Initialized
INFO - 2020-09-06 09:30:06 --> Language Class Initialized
INFO - 2020-09-06 09:30:06 --> Language Class Initialized
INFO - 2020-09-06 09:30:06 --> Config Class Initialized
INFO - 2020-09-06 09:30:06 --> Loader Class Initialized
INFO - 2020-09-06 09:30:06 --> Helper loaded: url_helper
INFO - 2020-09-06 09:30:06 --> Helper loaded: form_helper
INFO - 2020-09-06 09:30:06 --> Helper loaded: file_helper
INFO - 2020-09-06 09:30:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:30:06 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:30:06 --> Upload Class Initialized
INFO - 2020-09-06 09:30:06 --> Controller Class Initialized
DEBUG - 2020-09-06 09:30:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 09:30:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 09:30:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 09:30:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 09:30:06 --> Final output sent to browser
DEBUG - 2020-09-06 09:30:06 --> Total execution time: 0.5783
INFO - 2020-09-06 09:59:03 --> Config Class Initialized
INFO - 2020-09-06 09:59:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 09:59:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 09:59:03 --> Utf8 Class Initialized
INFO - 2020-09-06 09:59:03 --> URI Class Initialized
INFO - 2020-09-06 09:59:03 --> Router Class Initialized
INFO - 2020-09-06 09:59:03 --> Output Class Initialized
INFO - 2020-09-06 09:59:03 --> Security Class Initialized
DEBUG - 2020-09-06 09:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 09:59:03 --> Input Class Initialized
INFO - 2020-09-06 09:59:03 --> Language Class Initialized
INFO - 2020-09-06 09:59:03 --> Language Class Initialized
INFO - 2020-09-06 09:59:03 --> Config Class Initialized
INFO - 2020-09-06 09:59:03 --> Loader Class Initialized
INFO - 2020-09-06 09:59:03 --> Helper loaded: url_helper
INFO - 2020-09-06 09:59:03 --> Helper loaded: form_helper
INFO - 2020-09-06 09:59:03 --> Helper loaded: file_helper
INFO - 2020-09-06 09:59:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 09:59:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 09:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 09:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 09:59:03 --> Upload Class Initialized
INFO - 2020-09-06 09:59:03 --> Controller Class Initialized
ERROR - 2020-09-06 09:59:03 --> 404 Page Not Found: /index
INFO - 2020-09-06 10:18:55 --> Config Class Initialized
INFO - 2020-09-06 10:18:55 --> Hooks Class Initialized
DEBUG - 2020-09-06 10:18:55 --> UTF-8 Support Enabled
INFO - 2020-09-06 10:18:55 --> Utf8 Class Initialized
INFO - 2020-09-06 10:18:55 --> URI Class Initialized
INFO - 2020-09-06 10:18:55 --> Router Class Initialized
INFO - 2020-09-06 10:18:55 --> Output Class Initialized
INFO - 2020-09-06 10:18:55 --> Security Class Initialized
DEBUG - 2020-09-06 10:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 10:18:55 --> Input Class Initialized
INFO - 2020-09-06 10:18:55 --> Language Class Initialized
INFO - 2020-09-06 10:18:55 --> Language Class Initialized
INFO - 2020-09-06 10:18:55 --> Config Class Initialized
INFO - 2020-09-06 10:18:55 --> Loader Class Initialized
INFO - 2020-09-06 10:18:55 --> Helper loaded: url_helper
INFO - 2020-09-06 10:18:55 --> Helper loaded: form_helper
INFO - 2020-09-06 10:18:55 --> Helper loaded: file_helper
INFO - 2020-09-06 10:18:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 10:18:55 --> Database Driver Class Initialized
DEBUG - 2020-09-06 10:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 10:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 10:18:55 --> Upload Class Initialized
INFO - 2020-09-06 10:18:55 --> Controller Class Initialized
ERROR - 2020-09-06 10:18:55 --> 404 Page Not Found: /index
INFO - 2020-09-06 10:18:55 --> Config Class Initialized
INFO - 2020-09-06 10:18:55 --> Hooks Class Initialized
DEBUG - 2020-09-06 10:18:55 --> UTF-8 Support Enabled
INFO - 2020-09-06 10:18:55 --> Utf8 Class Initialized
INFO - 2020-09-06 10:18:55 --> URI Class Initialized
DEBUG - 2020-09-06 10:18:55 --> No URI present. Default controller set.
INFO - 2020-09-06 10:18:55 --> Router Class Initialized
INFO - 2020-09-06 10:18:55 --> Output Class Initialized
INFO - 2020-09-06 10:18:55 --> Security Class Initialized
DEBUG - 2020-09-06 10:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 10:18:55 --> Input Class Initialized
INFO - 2020-09-06 10:18:55 --> Language Class Initialized
INFO - 2020-09-06 10:18:55 --> Language Class Initialized
INFO - 2020-09-06 10:18:55 --> Config Class Initialized
INFO - 2020-09-06 10:18:55 --> Loader Class Initialized
INFO - 2020-09-06 10:18:55 --> Helper loaded: url_helper
INFO - 2020-09-06 10:18:55 --> Helper loaded: form_helper
INFO - 2020-09-06 10:18:55 --> Helper loaded: file_helper
INFO - 2020-09-06 10:18:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 10:18:55 --> Database Driver Class Initialized
DEBUG - 2020-09-06 10:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 10:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 10:18:55 --> Upload Class Initialized
INFO - 2020-09-06 10:18:55 --> Controller Class Initialized
DEBUG - 2020-09-06 10:18:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 10:18:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 10:18:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 10:18:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 10:18:55 --> Final output sent to browser
DEBUG - 2020-09-06 10:18:55 --> Total execution time: 0.0491
INFO - 2020-09-06 10:23:40 --> Config Class Initialized
INFO - 2020-09-06 10:23:40 --> Hooks Class Initialized
DEBUG - 2020-09-06 10:23:40 --> UTF-8 Support Enabled
INFO - 2020-09-06 10:23:40 --> Utf8 Class Initialized
INFO - 2020-09-06 10:23:40 --> URI Class Initialized
DEBUG - 2020-09-06 10:23:40 --> No URI present. Default controller set.
INFO - 2020-09-06 10:23:40 --> Router Class Initialized
INFO - 2020-09-06 10:23:40 --> Output Class Initialized
INFO - 2020-09-06 10:23:40 --> Security Class Initialized
DEBUG - 2020-09-06 10:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 10:23:40 --> Input Class Initialized
INFO - 2020-09-06 10:23:40 --> Language Class Initialized
INFO - 2020-09-06 10:23:40 --> Language Class Initialized
INFO - 2020-09-06 10:23:40 --> Config Class Initialized
INFO - 2020-09-06 10:23:40 --> Loader Class Initialized
INFO - 2020-09-06 10:23:40 --> Helper loaded: url_helper
INFO - 2020-09-06 10:23:40 --> Helper loaded: form_helper
INFO - 2020-09-06 10:23:40 --> Helper loaded: file_helper
INFO - 2020-09-06 10:23:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 10:23:40 --> Database Driver Class Initialized
DEBUG - 2020-09-06 10:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 10:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 10:23:40 --> Upload Class Initialized
INFO - 2020-09-06 10:23:40 --> Controller Class Initialized
DEBUG - 2020-09-06 10:23:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 10:23:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 10:23:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 10:23:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 10:23:40 --> Final output sent to browser
DEBUG - 2020-09-06 10:23:40 --> Total execution time: 0.0531
INFO - 2020-09-06 10:36:53 --> Config Class Initialized
INFO - 2020-09-06 10:36:53 --> Hooks Class Initialized
DEBUG - 2020-09-06 10:36:53 --> UTF-8 Support Enabled
INFO - 2020-09-06 10:36:53 --> Utf8 Class Initialized
INFO - 2020-09-06 10:36:53 --> URI Class Initialized
INFO - 2020-09-06 10:36:53 --> Router Class Initialized
INFO - 2020-09-06 10:36:53 --> Output Class Initialized
INFO - 2020-09-06 10:36:53 --> Security Class Initialized
DEBUG - 2020-09-06 10:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 10:36:53 --> Input Class Initialized
INFO - 2020-09-06 10:36:53 --> Language Class Initialized
INFO - 2020-09-06 10:36:53 --> Language Class Initialized
INFO - 2020-09-06 10:36:53 --> Config Class Initialized
INFO - 2020-09-06 10:36:53 --> Loader Class Initialized
INFO - 2020-09-06 10:36:53 --> Helper loaded: url_helper
INFO - 2020-09-06 10:36:53 --> Helper loaded: form_helper
INFO - 2020-09-06 10:36:53 --> Helper loaded: file_helper
INFO - 2020-09-06 10:36:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 10:36:53 --> Database Driver Class Initialized
DEBUG - 2020-09-06 10:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 10:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 10:36:53 --> Upload Class Initialized
INFO - 2020-09-06 10:36:53 --> Controller Class Initialized
ERROR - 2020-09-06 10:36:53 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:02:28 --> Config Class Initialized
INFO - 2020-09-06 11:02:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:02:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:02:28 --> Utf8 Class Initialized
INFO - 2020-09-06 11:02:28 --> URI Class Initialized
INFO - 2020-09-06 11:02:28 --> Router Class Initialized
INFO - 2020-09-06 11:02:28 --> Output Class Initialized
INFO - 2020-09-06 11:02:28 --> Security Class Initialized
DEBUG - 2020-09-06 11:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:02:28 --> Input Class Initialized
INFO - 2020-09-06 11:02:28 --> Language Class Initialized
INFO - 2020-09-06 11:02:28 --> Language Class Initialized
INFO - 2020-09-06 11:02:28 --> Config Class Initialized
INFO - 2020-09-06 11:02:28 --> Loader Class Initialized
INFO - 2020-09-06 11:02:28 --> Helper loaded: url_helper
INFO - 2020-09-06 11:02:28 --> Helper loaded: form_helper
INFO - 2020-09-06 11:02:28 --> Helper loaded: file_helper
INFO - 2020-09-06 11:02:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:02:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:02:28 --> Upload Class Initialized
INFO - 2020-09-06 11:02:28 --> Controller Class Initialized
DEBUG - 2020-09-06 11:02:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:02:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 11:02:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:02:28 --> Final output sent to browser
DEBUG - 2020-09-06 11:02:28 --> Total execution time: 0.0598
INFO - 2020-09-06 11:02:33 --> Config Class Initialized
INFO - 2020-09-06 11:02:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:02:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:02:33 --> Utf8 Class Initialized
INFO - 2020-09-06 11:02:33 --> URI Class Initialized
INFO - 2020-09-06 11:02:33 --> Router Class Initialized
INFO - 2020-09-06 11:02:33 --> Output Class Initialized
INFO - 2020-09-06 11:02:33 --> Security Class Initialized
DEBUG - 2020-09-06 11:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:02:33 --> Input Class Initialized
INFO - 2020-09-06 11:02:33 --> Language Class Initialized
INFO - 2020-09-06 11:02:33 --> Language Class Initialized
INFO - 2020-09-06 11:02:33 --> Config Class Initialized
INFO - 2020-09-06 11:02:33 --> Loader Class Initialized
INFO - 2020-09-06 11:02:33 --> Helper loaded: url_helper
INFO - 2020-09-06 11:02:33 --> Helper loaded: form_helper
INFO - 2020-09-06 11:02:33 --> Helper loaded: file_helper
INFO - 2020-09-06 11:02:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:02:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:02:33 --> Upload Class Initialized
INFO - 2020-09-06 11:02:33 --> Controller Class Initialized
ERROR - 2020-09-06 11:02:33 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:06:33 --> Config Class Initialized
INFO - 2020-09-06 11:06:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:06:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:06:33 --> Utf8 Class Initialized
INFO - 2020-09-06 11:06:33 --> URI Class Initialized
DEBUG - 2020-09-06 11:06:33 --> No URI present. Default controller set.
INFO - 2020-09-06 11:06:33 --> Router Class Initialized
INFO - 2020-09-06 11:06:33 --> Output Class Initialized
INFO - 2020-09-06 11:06:34 --> Security Class Initialized
DEBUG - 2020-09-06 11:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:06:34 --> Input Class Initialized
INFO - 2020-09-06 11:06:34 --> Language Class Initialized
INFO - 2020-09-06 11:06:34 --> Language Class Initialized
INFO - 2020-09-06 11:06:34 --> Config Class Initialized
INFO - 2020-09-06 11:06:34 --> Loader Class Initialized
INFO - 2020-09-06 11:06:34 --> Helper loaded: url_helper
INFO - 2020-09-06 11:06:34 --> Helper loaded: form_helper
INFO - 2020-09-06 11:06:34 --> Helper loaded: file_helper
INFO - 2020-09-06 11:06:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:06:34 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:06:34 --> Upload Class Initialized
INFO - 2020-09-06 11:06:34 --> Controller Class Initialized
DEBUG - 2020-09-06 11:06:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:06:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:06:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:06:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:06:34 --> Final output sent to browser
DEBUG - 2020-09-06 11:06:34 --> Total execution time: 0.0521
INFO - 2020-09-06 11:06:42 --> Config Class Initialized
INFO - 2020-09-06 11:06:42 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:06:42 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:06:42 --> Utf8 Class Initialized
INFO - 2020-09-06 11:06:42 --> URI Class Initialized
INFO - 2020-09-06 11:06:42 --> Router Class Initialized
INFO - 2020-09-06 11:06:42 --> Output Class Initialized
INFO - 2020-09-06 11:06:42 --> Security Class Initialized
DEBUG - 2020-09-06 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:06:42 --> Input Class Initialized
INFO - 2020-09-06 11:06:42 --> Language Class Initialized
INFO - 2020-09-06 11:06:42 --> Language Class Initialized
INFO - 2020-09-06 11:06:42 --> Config Class Initialized
INFO - 2020-09-06 11:06:42 --> Loader Class Initialized
INFO - 2020-09-06 11:06:42 --> Helper loaded: url_helper
INFO - 2020-09-06 11:06:42 --> Helper loaded: form_helper
INFO - 2020-09-06 11:06:42 --> Helper loaded: file_helper
INFO - 2020-09-06 11:06:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:06:42 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:06:42 --> Upload Class Initialized
INFO - 2020-09-06 11:06:42 --> Controller Class Initialized
ERROR - 2020-09-06 11:06:42 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:15:06 --> Config Class Initialized
INFO - 2020-09-06 11:15:06 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:15:06 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:15:06 --> Utf8 Class Initialized
INFO - 2020-09-06 11:15:06 --> URI Class Initialized
INFO - 2020-09-06 11:15:06 --> Router Class Initialized
INFO - 2020-09-06 11:15:06 --> Output Class Initialized
INFO - 2020-09-06 11:15:06 --> Security Class Initialized
DEBUG - 2020-09-06 11:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:15:06 --> Input Class Initialized
INFO - 2020-09-06 11:15:06 --> Language Class Initialized
INFO - 2020-09-06 11:15:06 --> Language Class Initialized
INFO - 2020-09-06 11:15:06 --> Config Class Initialized
INFO - 2020-09-06 11:15:06 --> Loader Class Initialized
INFO - 2020-09-06 11:15:06 --> Helper loaded: url_helper
INFO - 2020-09-06 11:15:06 --> Helper loaded: form_helper
INFO - 2020-09-06 11:15:06 --> Helper loaded: file_helper
INFO - 2020-09-06 11:15:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:15:06 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:15:06 --> Upload Class Initialized
INFO - 2020-09-06 11:15:06 --> Controller Class Initialized
DEBUG - 2020-09-06 11:15:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:15:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 11:15:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:15:06 --> Final output sent to browser
DEBUG - 2020-09-06 11:15:06 --> Total execution time: 0.0605
INFO - 2020-09-06 11:15:21 --> Config Class Initialized
INFO - 2020-09-06 11:15:21 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:15:21 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:15:21 --> Utf8 Class Initialized
INFO - 2020-09-06 11:15:21 --> URI Class Initialized
INFO - 2020-09-06 11:15:21 --> Router Class Initialized
INFO - 2020-09-06 11:15:21 --> Output Class Initialized
INFO - 2020-09-06 11:15:21 --> Security Class Initialized
DEBUG - 2020-09-06 11:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:15:21 --> Input Class Initialized
INFO - 2020-09-06 11:15:21 --> Language Class Initialized
INFO - 2020-09-06 11:15:21 --> Language Class Initialized
INFO - 2020-09-06 11:15:21 --> Config Class Initialized
INFO - 2020-09-06 11:15:21 --> Loader Class Initialized
INFO - 2020-09-06 11:15:21 --> Helper loaded: url_helper
INFO - 2020-09-06 11:15:21 --> Helper loaded: form_helper
INFO - 2020-09-06 11:15:21 --> Helper loaded: file_helper
INFO - 2020-09-06 11:15:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:15:21 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:15:21 --> Upload Class Initialized
INFO - 2020-09-06 11:15:21 --> Controller Class Initialized
ERROR - 2020-09-06 11:15:21 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:24:19 --> Config Class Initialized
INFO - 2020-09-06 11:24:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:24:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:24:19 --> Utf8 Class Initialized
INFO - 2020-09-06 11:24:19 --> URI Class Initialized
DEBUG - 2020-09-06 11:24:19 --> No URI present. Default controller set.
INFO - 2020-09-06 11:24:19 --> Router Class Initialized
INFO - 2020-09-06 11:24:19 --> Output Class Initialized
INFO - 2020-09-06 11:24:19 --> Security Class Initialized
DEBUG - 2020-09-06 11:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:24:19 --> Input Class Initialized
INFO - 2020-09-06 11:24:19 --> Language Class Initialized
INFO - 2020-09-06 11:24:19 --> Language Class Initialized
INFO - 2020-09-06 11:24:19 --> Config Class Initialized
INFO - 2020-09-06 11:24:19 --> Loader Class Initialized
INFO - 2020-09-06 11:24:19 --> Helper loaded: url_helper
INFO - 2020-09-06 11:24:19 --> Helper loaded: form_helper
INFO - 2020-09-06 11:24:19 --> Helper loaded: file_helper
INFO - 2020-09-06 11:24:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:24:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:24:19 --> Upload Class Initialized
INFO - 2020-09-06 11:24:19 --> Controller Class Initialized
DEBUG - 2020-09-06 11:24:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:24:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:24:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:24:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:24:19 --> Final output sent to browser
DEBUG - 2020-09-06 11:24:19 --> Total execution time: 0.0510
INFO - 2020-09-06 11:24:29 --> Config Class Initialized
INFO - 2020-09-06 11:24:29 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:24:29 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:24:29 --> Utf8 Class Initialized
INFO - 2020-09-06 11:24:29 --> URI Class Initialized
INFO - 2020-09-06 11:24:29 --> Router Class Initialized
INFO - 2020-09-06 11:24:29 --> Output Class Initialized
INFO - 2020-09-06 11:24:29 --> Security Class Initialized
DEBUG - 2020-09-06 11:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:24:29 --> Input Class Initialized
INFO - 2020-09-06 11:24:29 --> Language Class Initialized
INFO - 2020-09-06 11:24:29 --> Language Class Initialized
INFO - 2020-09-06 11:24:29 --> Config Class Initialized
INFO - 2020-09-06 11:24:29 --> Loader Class Initialized
INFO - 2020-09-06 11:24:29 --> Helper loaded: url_helper
INFO - 2020-09-06 11:24:29 --> Helper loaded: form_helper
INFO - 2020-09-06 11:24:29 --> Helper loaded: file_helper
INFO - 2020-09-06 11:24:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:24:29 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:24:29 --> Upload Class Initialized
INFO - 2020-09-06 11:24:29 --> Controller Class Initialized
ERROR - 2020-09-06 11:24:29 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:34:02 --> Config Class Initialized
INFO - 2020-09-06 11:34:02 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:34:02 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:34:02 --> Utf8 Class Initialized
INFO - 2020-09-06 11:34:02 --> URI Class Initialized
DEBUG - 2020-09-06 11:34:02 --> No URI present. Default controller set.
INFO - 2020-09-06 11:34:02 --> Router Class Initialized
INFO - 2020-09-06 11:34:02 --> Output Class Initialized
INFO - 2020-09-06 11:34:02 --> Security Class Initialized
DEBUG - 2020-09-06 11:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:34:02 --> Input Class Initialized
INFO - 2020-09-06 11:34:02 --> Language Class Initialized
INFO - 2020-09-06 11:34:02 --> Language Class Initialized
INFO - 2020-09-06 11:34:02 --> Config Class Initialized
INFO - 2020-09-06 11:34:02 --> Loader Class Initialized
INFO - 2020-09-06 11:34:02 --> Helper loaded: url_helper
INFO - 2020-09-06 11:34:02 --> Helper loaded: form_helper
INFO - 2020-09-06 11:34:02 --> Helper loaded: file_helper
INFO - 2020-09-06 11:34:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:34:02 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:34:02 --> Upload Class Initialized
INFO - 2020-09-06 11:34:02 --> Controller Class Initialized
DEBUG - 2020-09-06 11:34:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:34:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:34:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:34:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:34:02 --> Final output sent to browser
DEBUG - 2020-09-06 11:34:02 --> Total execution time: 0.2088
INFO - 2020-09-06 11:34:47 --> Config Class Initialized
INFO - 2020-09-06 11:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:34:47 --> Utf8 Class Initialized
INFO - 2020-09-06 11:34:47 --> URI Class Initialized
DEBUG - 2020-09-06 11:34:47 --> No URI present. Default controller set.
INFO - 2020-09-06 11:34:47 --> Router Class Initialized
INFO - 2020-09-06 11:34:47 --> Output Class Initialized
INFO - 2020-09-06 11:34:47 --> Security Class Initialized
DEBUG - 2020-09-06 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:34:47 --> Input Class Initialized
INFO - 2020-09-06 11:34:47 --> Language Class Initialized
INFO - 2020-09-06 11:34:47 --> Language Class Initialized
INFO - 2020-09-06 11:34:47 --> Config Class Initialized
INFO - 2020-09-06 11:34:47 --> Loader Class Initialized
INFO - 2020-09-06 11:34:47 --> Helper loaded: url_helper
INFO - 2020-09-06 11:34:47 --> Helper loaded: form_helper
INFO - 2020-09-06 11:34:47 --> Helper loaded: file_helper
INFO - 2020-09-06 11:34:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:34:47 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:34:47 --> Upload Class Initialized
INFO - 2020-09-06 11:34:47 --> Controller Class Initialized
DEBUG - 2020-09-06 11:34:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:34:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:34:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:34:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:34:47 --> Final output sent to browser
DEBUG - 2020-09-06 11:34:47 --> Total execution time: 0.0532
INFO - 2020-09-06 11:34:47 --> Config Class Initialized
INFO - 2020-09-06 11:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:34:47 --> Utf8 Class Initialized
INFO - 2020-09-06 11:34:47 --> URI Class Initialized
DEBUG - 2020-09-06 11:34:47 --> No URI present. Default controller set.
INFO - 2020-09-06 11:34:47 --> Router Class Initialized
INFO - 2020-09-06 11:34:47 --> Output Class Initialized
INFO - 2020-09-06 11:34:47 --> Security Class Initialized
DEBUG - 2020-09-06 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:34:47 --> Input Class Initialized
INFO - 2020-09-06 11:34:47 --> Language Class Initialized
INFO - 2020-09-06 11:34:47 --> Language Class Initialized
INFO - 2020-09-06 11:34:47 --> Config Class Initialized
INFO - 2020-09-06 11:34:47 --> Loader Class Initialized
INFO - 2020-09-06 11:34:47 --> Helper loaded: url_helper
INFO - 2020-09-06 11:34:47 --> Helper loaded: form_helper
INFO - 2020-09-06 11:34:47 --> Helper loaded: file_helper
INFO - 2020-09-06 11:34:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:34:47 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:34:47 --> Upload Class Initialized
INFO - 2020-09-06 11:34:47 --> Controller Class Initialized
DEBUG - 2020-09-06 11:34:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:34:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:34:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:34:47 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:34:47 --> Final output sent to browser
DEBUG - 2020-09-06 11:34:47 --> Total execution time: 0.0526
INFO - 2020-09-06 11:35:22 --> Config Class Initialized
INFO - 2020-09-06 11:35:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:35:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:35:22 --> Utf8 Class Initialized
INFO - 2020-09-06 11:35:22 --> URI Class Initialized
DEBUG - 2020-09-06 11:35:22 --> No URI present. Default controller set.
INFO - 2020-09-06 11:35:22 --> Router Class Initialized
INFO - 2020-09-06 11:35:22 --> Output Class Initialized
INFO - 2020-09-06 11:35:22 --> Security Class Initialized
DEBUG - 2020-09-06 11:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:35:22 --> Input Class Initialized
INFO - 2020-09-06 11:35:22 --> Language Class Initialized
INFO - 2020-09-06 11:35:22 --> Language Class Initialized
INFO - 2020-09-06 11:35:22 --> Config Class Initialized
INFO - 2020-09-06 11:35:22 --> Loader Class Initialized
INFO - 2020-09-06 11:35:22 --> Helper loaded: url_helper
INFO - 2020-09-06 11:35:22 --> Helper loaded: form_helper
INFO - 2020-09-06 11:35:22 --> Helper loaded: file_helper
INFO - 2020-09-06 11:35:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:35:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:35:22 --> Upload Class Initialized
INFO - 2020-09-06 11:35:22 --> Controller Class Initialized
DEBUG - 2020-09-06 11:35:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:35:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:35:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:35:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:35:22 --> Final output sent to browser
DEBUG - 2020-09-06 11:35:22 --> Total execution time: 0.0550
INFO - 2020-09-06 11:35:27 --> Config Class Initialized
INFO - 2020-09-06 11:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:35:27 --> Utf8 Class Initialized
INFO - 2020-09-06 11:35:27 --> URI Class Initialized
INFO - 2020-09-06 11:35:27 --> Router Class Initialized
INFO - 2020-09-06 11:35:27 --> Output Class Initialized
INFO - 2020-09-06 11:35:27 --> Security Class Initialized
DEBUG - 2020-09-06 11:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:35:27 --> Input Class Initialized
INFO - 2020-09-06 11:35:27 --> Language Class Initialized
INFO - 2020-09-06 11:35:27 --> Language Class Initialized
INFO - 2020-09-06 11:35:27 --> Config Class Initialized
INFO - 2020-09-06 11:35:27 --> Loader Class Initialized
INFO - 2020-09-06 11:35:27 --> Helper loaded: url_helper
INFO - 2020-09-06 11:35:27 --> Helper loaded: form_helper
INFO - 2020-09-06 11:35:27 --> Helper loaded: file_helper
INFO - 2020-09-06 11:35:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:35:27 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:35:27 --> Upload Class Initialized
INFO - 2020-09-06 11:35:27 --> Controller Class Initialized
ERROR - 2020-09-06 11:35:27 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:35:27 --> Config Class Initialized
INFO - 2020-09-06 11:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:35:27 --> Utf8 Class Initialized
INFO - 2020-09-06 11:35:27 --> URI Class Initialized
INFO - 2020-09-06 11:35:27 --> Router Class Initialized
INFO - 2020-09-06 11:35:27 --> Output Class Initialized
INFO - 2020-09-06 11:35:27 --> Security Class Initialized
DEBUG - 2020-09-06 11:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:35:27 --> Input Class Initialized
INFO - 2020-09-06 11:35:27 --> Language Class Initialized
INFO - 2020-09-06 11:35:27 --> Language Class Initialized
INFO - 2020-09-06 11:35:27 --> Config Class Initialized
INFO - 2020-09-06 11:35:27 --> Loader Class Initialized
INFO - 2020-09-06 11:35:27 --> Helper loaded: url_helper
INFO - 2020-09-06 11:35:27 --> Helper loaded: form_helper
INFO - 2020-09-06 11:35:27 --> Helper loaded: file_helper
INFO - 2020-09-06 11:35:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:35:27 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:35:27 --> Upload Class Initialized
INFO - 2020-09-06 11:35:27 --> Controller Class Initialized
DEBUG - 2020-09-06 11:35:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 11:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 11:35:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:35:27 --> Final output sent to browser
DEBUG - 2020-09-06 11:35:27 --> Total execution time: 0.0500
INFO - 2020-09-06 11:35:29 --> Config Class Initialized
INFO - 2020-09-06 11:35:29 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:35:29 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:35:29 --> Utf8 Class Initialized
INFO - 2020-09-06 11:35:29 --> URI Class Initialized
INFO - 2020-09-06 11:35:29 --> Router Class Initialized
INFO - 2020-09-06 11:35:29 --> Output Class Initialized
INFO - 2020-09-06 11:35:29 --> Security Class Initialized
DEBUG - 2020-09-06 11:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:35:29 --> Input Class Initialized
INFO - 2020-09-06 11:35:29 --> Language Class Initialized
INFO - 2020-09-06 11:35:29 --> Language Class Initialized
INFO - 2020-09-06 11:35:29 --> Config Class Initialized
INFO - 2020-09-06 11:35:29 --> Loader Class Initialized
INFO - 2020-09-06 11:35:29 --> Helper loaded: url_helper
INFO - 2020-09-06 11:35:29 --> Helper loaded: form_helper
INFO - 2020-09-06 11:35:29 --> Helper loaded: file_helper
INFO - 2020-09-06 11:35:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:35:29 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:35:29 --> Upload Class Initialized
INFO - 2020-09-06 11:35:29 --> Controller Class Initialized
ERROR - 2020-09-06 11:35:29 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:49:27 --> Config Class Initialized
INFO - 2020-09-06 11:49:27 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:49:27 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:49:27 --> Utf8 Class Initialized
INFO - 2020-09-06 11:49:27 --> URI Class Initialized
INFO - 2020-09-06 11:49:27 --> Router Class Initialized
INFO - 2020-09-06 11:49:27 --> Output Class Initialized
INFO - 2020-09-06 11:49:27 --> Security Class Initialized
DEBUG - 2020-09-06 11:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:49:27 --> Input Class Initialized
INFO - 2020-09-06 11:49:27 --> Language Class Initialized
INFO - 2020-09-06 11:49:27 --> Language Class Initialized
INFO - 2020-09-06 11:49:27 --> Config Class Initialized
INFO - 2020-09-06 11:49:27 --> Loader Class Initialized
INFO - 2020-09-06 11:49:27 --> Helper loaded: url_helper
INFO - 2020-09-06 11:49:27 --> Helper loaded: form_helper
INFO - 2020-09-06 11:49:27 --> Helper loaded: file_helper
INFO - 2020-09-06 11:49:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:49:27 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:49:27 --> Upload Class Initialized
INFO - 2020-09-06 11:49:27 --> Controller Class Initialized
ERROR - 2020-09-06 11:49:27 --> 404 Page Not Found: /index
INFO - 2020-09-06 11:50:20 --> Config Class Initialized
INFO - 2020-09-06 11:50:20 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:50:20 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:50:20 --> Utf8 Class Initialized
INFO - 2020-09-06 11:50:20 --> URI Class Initialized
INFO - 2020-09-06 11:50:20 --> Router Class Initialized
INFO - 2020-09-06 11:50:20 --> Output Class Initialized
INFO - 2020-09-06 11:50:20 --> Security Class Initialized
DEBUG - 2020-09-06 11:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:50:20 --> Input Class Initialized
INFO - 2020-09-06 11:50:20 --> Language Class Initialized
INFO - 2020-09-06 11:50:20 --> Language Class Initialized
INFO - 2020-09-06 11:50:20 --> Config Class Initialized
INFO - 2020-09-06 11:50:20 --> Loader Class Initialized
INFO - 2020-09-06 11:50:20 --> Helper loaded: url_helper
INFO - 2020-09-06 11:50:20 --> Helper loaded: form_helper
INFO - 2020-09-06 11:50:20 --> Helper loaded: file_helper
INFO - 2020-09-06 11:50:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:50:20 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:50:20 --> Upload Class Initialized
INFO - 2020-09-06 11:50:20 --> Controller Class Initialized
DEBUG - 2020-09-06 11:50:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 11:50:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-06 11:50:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 11:50:20 --> Final output sent to browser
DEBUG - 2020-09-06 11:50:20 --> Total execution time: 0.0546
INFO - 2020-09-06 11:50:24 --> Config Class Initialized
INFO - 2020-09-06 11:50:24 --> Hooks Class Initialized
DEBUG - 2020-09-06 11:50:24 --> UTF-8 Support Enabled
INFO - 2020-09-06 11:50:24 --> Utf8 Class Initialized
INFO - 2020-09-06 11:50:24 --> URI Class Initialized
INFO - 2020-09-06 11:50:24 --> Router Class Initialized
INFO - 2020-09-06 11:50:24 --> Output Class Initialized
INFO - 2020-09-06 11:50:24 --> Security Class Initialized
DEBUG - 2020-09-06 11:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 11:50:24 --> Input Class Initialized
INFO - 2020-09-06 11:50:24 --> Language Class Initialized
INFO - 2020-09-06 11:50:24 --> Language Class Initialized
INFO - 2020-09-06 11:50:24 --> Config Class Initialized
INFO - 2020-09-06 11:50:24 --> Loader Class Initialized
INFO - 2020-09-06 11:50:24 --> Helper loaded: url_helper
INFO - 2020-09-06 11:50:24 --> Helper loaded: form_helper
INFO - 2020-09-06 11:50:24 --> Helper loaded: file_helper
INFO - 2020-09-06 11:50:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 11:50:24 --> Database Driver Class Initialized
DEBUG - 2020-09-06 11:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 11:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 11:50:24 --> Upload Class Initialized
INFO - 2020-09-06 11:50:24 --> Controller Class Initialized
ERROR - 2020-09-06 11:50:24 --> 404 Page Not Found: /index
INFO - 2020-09-06 12:08:17 --> Config Class Initialized
INFO - 2020-09-06 12:08:17 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:08:17 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:08:17 --> Utf8 Class Initialized
INFO - 2020-09-06 12:08:17 --> URI Class Initialized
INFO - 2020-09-06 12:08:17 --> Router Class Initialized
INFO - 2020-09-06 12:08:17 --> Output Class Initialized
INFO - 2020-09-06 12:08:17 --> Security Class Initialized
DEBUG - 2020-09-06 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:08:17 --> Input Class Initialized
INFO - 2020-09-06 12:08:17 --> Language Class Initialized
INFO - 2020-09-06 12:08:17 --> Language Class Initialized
INFO - 2020-09-06 12:08:17 --> Config Class Initialized
INFO - 2020-09-06 12:08:17 --> Loader Class Initialized
INFO - 2020-09-06 12:08:17 --> Helper loaded: url_helper
INFO - 2020-09-06 12:08:17 --> Helper loaded: form_helper
INFO - 2020-09-06 12:08:17 --> Helper loaded: file_helper
INFO - 2020-09-06 12:08:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:08:17 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:08:17 --> Upload Class Initialized
INFO - 2020-09-06 12:08:17 --> Controller Class Initialized
DEBUG - 2020-09-06 12:08:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:08:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 12:08:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:08:17 --> Final output sent to browser
DEBUG - 2020-09-06 12:08:17 --> Total execution time: 0.0530
INFO - 2020-09-06 12:08:17 --> Config Class Initialized
INFO - 2020-09-06 12:08:17 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:08:17 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:08:17 --> Utf8 Class Initialized
INFO - 2020-09-06 12:08:17 --> URI Class Initialized
INFO - 2020-09-06 12:08:17 --> Router Class Initialized
INFO - 2020-09-06 12:08:17 --> Output Class Initialized
INFO - 2020-09-06 12:08:17 --> Security Class Initialized
DEBUG - 2020-09-06 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:08:17 --> Input Class Initialized
INFO - 2020-09-06 12:08:17 --> Language Class Initialized
INFO - 2020-09-06 12:08:17 --> Language Class Initialized
INFO - 2020-09-06 12:08:17 --> Config Class Initialized
INFO - 2020-09-06 12:08:17 --> Loader Class Initialized
INFO - 2020-09-06 12:08:17 --> Helper loaded: url_helper
INFO - 2020-09-06 12:08:17 --> Helper loaded: form_helper
INFO - 2020-09-06 12:08:17 --> Helper loaded: file_helper
INFO - 2020-09-06 12:08:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:08:17 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:08:17 --> Upload Class Initialized
INFO - 2020-09-06 12:08:17 --> Controller Class Initialized
DEBUG - 2020-09-06 12:08:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:08:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 12:08:17 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:08:17 --> Final output sent to browser
DEBUG - 2020-09-06 12:08:17 --> Total execution time: 0.0544
INFO - 2020-09-06 12:08:22 --> Config Class Initialized
INFO - 2020-09-06 12:08:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:08:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:08:22 --> Utf8 Class Initialized
INFO - 2020-09-06 12:08:22 --> URI Class Initialized
INFO - 2020-09-06 12:08:22 --> Router Class Initialized
INFO - 2020-09-06 12:08:22 --> Output Class Initialized
INFO - 2020-09-06 12:08:22 --> Security Class Initialized
DEBUG - 2020-09-06 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:08:22 --> Input Class Initialized
INFO - 2020-09-06 12:08:22 --> Language Class Initialized
INFO - 2020-09-06 12:08:22 --> Language Class Initialized
INFO - 2020-09-06 12:08:22 --> Config Class Initialized
INFO - 2020-09-06 12:08:22 --> Loader Class Initialized
INFO - 2020-09-06 12:08:22 --> Helper loaded: url_helper
INFO - 2020-09-06 12:08:22 --> Helper loaded: form_helper
INFO - 2020-09-06 12:08:22 --> Helper loaded: file_helper
INFO - 2020-09-06 12:08:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:08:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:08:22 --> Upload Class Initialized
INFO - 2020-09-06 12:08:22 --> Controller Class Initialized
ERROR - 2020-09-06 12:08:22 --> 404 Page Not Found: /index
INFO - 2020-09-06 12:08:22 --> Config Class Initialized
INFO - 2020-09-06 12:08:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:08:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:08:22 --> Utf8 Class Initialized
INFO - 2020-09-06 12:08:22 --> URI Class Initialized
INFO - 2020-09-06 12:08:22 --> Router Class Initialized
INFO - 2020-09-06 12:08:22 --> Output Class Initialized
INFO - 2020-09-06 12:08:22 --> Security Class Initialized
DEBUG - 2020-09-06 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:08:22 --> Input Class Initialized
INFO - 2020-09-06 12:08:22 --> Language Class Initialized
INFO - 2020-09-06 12:08:22 --> Language Class Initialized
INFO - 2020-09-06 12:08:22 --> Config Class Initialized
INFO - 2020-09-06 12:08:22 --> Loader Class Initialized
INFO - 2020-09-06 12:08:22 --> Helper loaded: url_helper
INFO - 2020-09-06 12:08:22 --> Helper loaded: form_helper
INFO - 2020-09-06 12:08:22 --> Helper loaded: file_helper
INFO - 2020-09-06 12:08:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:08:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:08:22 --> Upload Class Initialized
INFO - 2020-09-06 12:08:22 --> Controller Class Initialized
ERROR - 2020-09-06 12:08:22 --> 404 Page Not Found: /index
INFO - 2020-09-06 12:26:15 --> Config Class Initialized
INFO - 2020-09-06 12:26:15 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:26:15 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:26:15 --> Utf8 Class Initialized
INFO - 2020-09-06 12:26:15 --> URI Class Initialized
INFO - 2020-09-06 12:26:15 --> Router Class Initialized
INFO - 2020-09-06 12:26:15 --> Output Class Initialized
INFO - 2020-09-06 12:26:15 --> Security Class Initialized
DEBUG - 2020-09-06 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:26:15 --> Input Class Initialized
INFO - 2020-09-06 12:26:15 --> Language Class Initialized
INFO - 2020-09-06 12:26:15 --> Language Class Initialized
INFO - 2020-09-06 12:26:15 --> Config Class Initialized
INFO - 2020-09-06 12:26:15 --> Loader Class Initialized
INFO - 2020-09-06 12:26:15 --> Helper loaded: url_helper
INFO - 2020-09-06 12:26:15 --> Helper loaded: form_helper
INFO - 2020-09-06 12:26:15 --> Helper loaded: file_helper
INFO - 2020-09-06 12:26:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:26:15 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:26:15 --> Upload Class Initialized
INFO - 2020-09-06 12:26:15 --> Controller Class Initialized
DEBUG - 2020-09-06 12:26:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:26:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-06 12:26:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:26:15 --> Final output sent to browser
DEBUG - 2020-09-06 12:26:15 --> Total execution time: 0.0543
INFO - 2020-09-06 12:26:19 --> Config Class Initialized
INFO - 2020-09-06 12:26:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:26:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:26:19 --> Utf8 Class Initialized
INFO - 2020-09-06 12:26:19 --> URI Class Initialized
INFO - 2020-09-06 12:26:19 --> Router Class Initialized
INFO - 2020-09-06 12:26:19 --> Output Class Initialized
INFO - 2020-09-06 12:26:19 --> Security Class Initialized
DEBUG - 2020-09-06 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:26:19 --> Input Class Initialized
INFO - 2020-09-06 12:26:19 --> Language Class Initialized
INFO - 2020-09-06 12:26:19 --> Language Class Initialized
INFO - 2020-09-06 12:26:19 --> Config Class Initialized
INFO - 2020-09-06 12:26:19 --> Loader Class Initialized
INFO - 2020-09-06 12:26:19 --> Helper loaded: url_helper
INFO - 2020-09-06 12:26:19 --> Helper loaded: form_helper
INFO - 2020-09-06 12:26:19 --> Helper loaded: file_helper
INFO - 2020-09-06 12:26:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:26:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:26:19 --> Upload Class Initialized
INFO - 2020-09-06 12:26:19 --> Controller Class Initialized
DEBUG - 2020-09-06 12:26:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:26:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 12:26:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:26:19 --> Final output sent to browser
DEBUG - 2020-09-06 12:26:19 --> Total execution time: 0.0541
INFO - 2020-09-06 12:26:22 --> Config Class Initialized
INFO - 2020-09-06 12:26:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:26:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:26:22 --> Utf8 Class Initialized
INFO - 2020-09-06 12:26:22 --> URI Class Initialized
INFO - 2020-09-06 12:26:22 --> Router Class Initialized
INFO - 2020-09-06 12:26:22 --> Output Class Initialized
INFO - 2020-09-06 12:26:22 --> Security Class Initialized
DEBUG - 2020-09-06 12:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:26:22 --> Input Class Initialized
INFO - 2020-09-06 12:26:22 --> Language Class Initialized
INFO - 2020-09-06 12:26:22 --> Language Class Initialized
INFO - 2020-09-06 12:26:22 --> Config Class Initialized
INFO - 2020-09-06 12:26:22 --> Loader Class Initialized
INFO - 2020-09-06 12:26:22 --> Helper loaded: url_helper
INFO - 2020-09-06 12:26:22 --> Helper loaded: form_helper
INFO - 2020-09-06 12:26:22 --> Helper loaded: file_helper
INFO - 2020-09-06 12:26:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:26:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:26:22 --> Upload Class Initialized
INFO - 2020-09-06 12:26:22 --> Controller Class Initialized
ERROR - 2020-09-06 12:26:22 --> 404 Page Not Found: /index
INFO - 2020-09-06 12:26:23 --> Config Class Initialized
INFO - 2020-09-06 12:26:23 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:26:23 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:26:23 --> Utf8 Class Initialized
INFO - 2020-09-06 12:26:23 --> URI Class Initialized
INFO - 2020-09-06 12:26:23 --> Router Class Initialized
INFO - 2020-09-06 12:26:23 --> Output Class Initialized
INFO - 2020-09-06 12:26:23 --> Security Class Initialized
DEBUG - 2020-09-06 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:26:23 --> Input Class Initialized
INFO - 2020-09-06 12:26:23 --> Language Class Initialized
INFO - 2020-09-06 12:26:23 --> Language Class Initialized
INFO - 2020-09-06 12:26:23 --> Config Class Initialized
INFO - 2020-09-06 12:26:23 --> Loader Class Initialized
INFO - 2020-09-06 12:26:23 --> Helper loaded: url_helper
INFO - 2020-09-06 12:26:23 --> Helper loaded: form_helper
INFO - 2020-09-06 12:26:23 --> Helper loaded: file_helper
INFO - 2020-09-06 12:26:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:26:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:26:23 --> Upload Class Initialized
INFO - 2020-09-06 12:26:23 --> Controller Class Initialized
ERROR - 2020-09-06 12:26:23 --> 404 Page Not Found: /index
INFO - 2020-09-06 12:45:41 --> Config Class Initialized
INFO - 2020-09-06 12:45:41 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:45:41 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:45:41 --> Utf8 Class Initialized
INFO - 2020-09-06 12:45:41 --> URI Class Initialized
DEBUG - 2020-09-06 12:45:41 --> No URI present. Default controller set.
INFO - 2020-09-06 12:45:41 --> Router Class Initialized
INFO - 2020-09-06 12:45:41 --> Output Class Initialized
INFO - 2020-09-06 12:45:41 --> Security Class Initialized
DEBUG - 2020-09-06 12:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:45:41 --> Input Class Initialized
INFO - 2020-09-06 12:45:41 --> Language Class Initialized
INFO - 2020-09-06 12:45:41 --> Language Class Initialized
INFO - 2020-09-06 12:45:41 --> Config Class Initialized
INFO - 2020-09-06 12:45:41 --> Loader Class Initialized
INFO - 2020-09-06 12:45:41 --> Helper loaded: url_helper
INFO - 2020-09-06 12:45:41 --> Helper loaded: form_helper
INFO - 2020-09-06 12:45:41 --> Helper loaded: file_helper
INFO - 2020-09-06 12:45:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:45:41 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:45:41 --> Upload Class Initialized
INFO - 2020-09-06 12:45:41 --> Controller Class Initialized
DEBUG - 2020-09-06 12:45:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:45:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 12:45:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 12:45:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:45:41 --> Final output sent to browser
DEBUG - 2020-09-06 12:45:41 --> Total execution time: 0.0530
INFO - 2020-09-06 12:45:52 --> Config Class Initialized
INFO - 2020-09-06 12:45:52 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:45:52 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:45:52 --> Utf8 Class Initialized
INFO - 2020-09-06 12:45:52 --> URI Class Initialized
INFO - 2020-09-06 12:45:52 --> Router Class Initialized
INFO - 2020-09-06 12:45:52 --> Output Class Initialized
INFO - 2020-09-06 12:45:52 --> Security Class Initialized
DEBUG - 2020-09-06 12:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:45:52 --> Input Class Initialized
INFO - 2020-09-06 12:45:52 --> Language Class Initialized
INFO - 2020-09-06 12:45:52 --> Language Class Initialized
INFO - 2020-09-06 12:45:52 --> Config Class Initialized
INFO - 2020-09-06 12:45:52 --> Loader Class Initialized
INFO - 2020-09-06 12:45:52 --> Helper loaded: url_helper
INFO - 2020-09-06 12:45:52 --> Helper loaded: form_helper
INFO - 2020-09-06 12:45:52 --> Helper loaded: file_helper
INFO - 2020-09-06 12:45:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:45:53 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:45:53 --> Upload Class Initialized
INFO - 2020-09-06 12:45:53 --> Controller Class Initialized
ERROR - 2020-09-06 12:45:53 --> 404 Page Not Found: /index
INFO - 2020-09-06 12:46:43 --> Config Class Initialized
INFO - 2020-09-06 12:46:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:46:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:46:43 --> Utf8 Class Initialized
INFO - 2020-09-06 12:46:43 --> URI Class Initialized
INFO - 2020-09-06 12:46:43 --> Router Class Initialized
INFO - 2020-09-06 12:46:43 --> Output Class Initialized
INFO - 2020-09-06 12:46:43 --> Security Class Initialized
DEBUG - 2020-09-06 12:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:46:43 --> Input Class Initialized
INFO - 2020-09-06 12:46:43 --> Language Class Initialized
INFO - 2020-09-06 12:46:43 --> Language Class Initialized
INFO - 2020-09-06 12:46:43 --> Config Class Initialized
INFO - 2020-09-06 12:46:43 --> Loader Class Initialized
INFO - 2020-09-06 12:46:43 --> Helper loaded: url_helper
INFO - 2020-09-06 12:46:43 --> Helper loaded: form_helper
INFO - 2020-09-06 12:46:43 --> Helper loaded: file_helper
INFO - 2020-09-06 12:46:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:46:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:46:43 --> Upload Class Initialized
INFO - 2020-09-06 12:46:43 --> Controller Class Initialized
DEBUG - 2020-09-06 12:46:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 12:46:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:46:43 --> Final output sent to browser
DEBUG - 2020-09-06 12:46:43 --> Total execution time: 0.0659
INFO - 2020-09-06 12:47:36 --> Config Class Initialized
INFO - 2020-09-06 12:47:36 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:47:36 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:47:36 --> Utf8 Class Initialized
INFO - 2020-09-06 12:47:36 --> URI Class Initialized
INFO - 2020-09-06 12:47:36 --> Router Class Initialized
INFO - 2020-09-06 12:47:36 --> Output Class Initialized
INFO - 2020-09-06 12:47:36 --> Security Class Initialized
DEBUG - 2020-09-06 12:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:47:36 --> Input Class Initialized
INFO - 2020-09-06 12:47:36 --> Language Class Initialized
INFO - 2020-09-06 12:47:36 --> Language Class Initialized
INFO - 2020-09-06 12:47:36 --> Config Class Initialized
INFO - 2020-09-06 12:47:36 --> Loader Class Initialized
INFO - 2020-09-06 12:47:36 --> Helper loaded: url_helper
INFO - 2020-09-06 12:47:36 --> Helper loaded: form_helper
INFO - 2020-09-06 12:47:36 --> Helper loaded: file_helper
INFO - 2020-09-06 12:47:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:47:36 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:47:36 --> Upload Class Initialized
INFO - 2020-09-06 12:47:36 --> Controller Class Initialized
DEBUG - 2020-09-06 12:47:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:47:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-06 12:47:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:47:36 --> Final output sent to browser
DEBUG - 2020-09-06 12:47:36 --> Total execution time: 0.0563
INFO - 2020-09-06 12:49:07 --> Config Class Initialized
INFO - 2020-09-06 12:49:07 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:49:07 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:49:07 --> Utf8 Class Initialized
INFO - 2020-09-06 12:49:07 --> URI Class Initialized
INFO - 2020-09-06 12:49:07 --> Router Class Initialized
INFO - 2020-09-06 12:49:07 --> Output Class Initialized
INFO - 2020-09-06 12:49:07 --> Security Class Initialized
DEBUG - 2020-09-06 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:49:07 --> Input Class Initialized
INFO - 2020-09-06 12:49:07 --> Language Class Initialized
INFO - 2020-09-06 12:49:07 --> Language Class Initialized
INFO - 2020-09-06 12:49:07 --> Config Class Initialized
INFO - 2020-09-06 12:49:07 --> Loader Class Initialized
INFO - 2020-09-06 12:49:07 --> Helper loaded: url_helper
INFO - 2020-09-06 12:49:07 --> Helper loaded: form_helper
INFO - 2020-09-06 12:49:07 --> Helper loaded: file_helper
INFO - 2020-09-06 12:49:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:49:07 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:49:07 --> Upload Class Initialized
INFO - 2020-09-06 12:49:07 --> Controller Class Initialized
DEBUG - 2020-09-06 12:49:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:49:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 12:49:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:49:07 --> Final output sent to browser
DEBUG - 2020-09-06 12:49:07 --> Total execution time: 0.0543
INFO - 2020-09-06 12:49:08 --> Config Class Initialized
INFO - 2020-09-06 12:49:08 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:49:08 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:49:08 --> Utf8 Class Initialized
INFO - 2020-09-06 12:49:08 --> URI Class Initialized
DEBUG - 2020-09-06 12:49:08 --> No URI present. Default controller set.
INFO - 2020-09-06 12:49:08 --> Router Class Initialized
INFO - 2020-09-06 12:49:08 --> Output Class Initialized
INFO - 2020-09-06 12:49:08 --> Security Class Initialized
DEBUG - 2020-09-06 12:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:49:08 --> Input Class Initialized
INFO - 2020-09-06 12:49:08 --> Language Class Initialized
INFO - 2020-09-06 12:49:08 --> Language Class Initialized
INFO - 2020-09-06 12:49:08 --> Config Class Initialized
INFO - 2020-09-06 12:49:08 --> Loader Class Initialized
INFO - 2020-09-06 12:49:08 --> Helper loaded: url_helper
INFO - 2020-09-06 12:49:08 --> Helper loaded: form_helper
INFO - 2020-09-06 12:49:08 --> Helper loaded: file_helper
INFO - 2020-09-06 12:49:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:49:08 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:49:08 --> Upload Class Initialized
INFO - 2020-09-06 12:49:09 --> Controller Class Initialized
DEBUG - 2020-09-06 12:49:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:49:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 12:49:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 12:49:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:49:09 --> Final output sent to browser
DEBUG - 2020-09-06 12:49:09 --> Total execution time: 0.0593
INFO - 2020-09-06 12:57:15 --> Config Class Initialized
INFO - 2020-09-06 12:57:15 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:57:15 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:57:15 --> Utf8 Class Initialized
INFO - 2020-09-06 12:57:15 --> URI Class Initialized
DEBUG - 2020-09-06 12:57:15 --> No URI present. Default controller set.
INFO - 2020-09-06 12:57:15 --> Router Class Initialized
INFO - 2020-09-06 12:57:15 --> Output Class Initialized
INFO - 2020-09-06 12:57:15 --> Security Class Initialized
DEBUG - 2020-09-06 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:57:15 --> Input Class Initialized
INFO - 2020-09-06 12:57:15 --> Language Class Initialized
INFO - 2020-09-06 12:57:15 --> Language Class Initialized
INFO - 2020-09-06 12:57:15 --> Config Class Initialized
INFO - 2020-09-06 12:57:15 --> Loader Class Initialized
INFO - 2020-09-06 12:57:15 --> Helper loaded: url_helper
INFO - 2020-09-06 12:57:15 --> Helper loaded: form_helper
INFO - 2020-09-06 12:57:15 --> Helper loaded: file_helper
INFO - 2020-09-06 12:57:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:57:15 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:57:15 --> Upload Class Initialized
INFO - 2020-09-06 12:57:15 --> Controller Class Initialized
DEBUG - 2020-09-06 12:57:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 12:57:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 12:57:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 12:57:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 12:57:15 --> Final output sent to browser
DEBUG - 2020-09-06 12:57:15 --> Total execution time: 0.0568
INFO - 2020-09-06 12:57:32 --> Config Class Initialized
INFO - 2020-09-06 12:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-06 12:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-06 12:57:32 --> Utf8 Class Initialized
INFO - 2020-09-06 12:57:32 --> URI Class Initialized
INFO - 2020-09-06 12:57:32 --> Router Class Initialized
INFO - 2020-09-06 12:57:32 --> Output Class Initialized
INFO - 2020-09-06 12:57:32 --> Security Class Initialized
DEBUG - 2020-09-06 12:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 12:57:32 --> Input Class Initialized
INFO - 2020-09-06 12:57:32 --> Language Class Initialized
INFO - 2020-09-06 12:57:32 --> Language Class Initialized
INFO - 2020-09-06 12:57:32 --> Config Class Initialized
INFO - 2020-09-06 12:57:32 --> Loader Class Initialized
INFO - 2020-09-06 12:57:32 --> Helper loaded: url_helper
INFO - 2020-09-06 12:57:32 --> Helper loaded: form_helper
INFO - 2020-09-06 12:57:32 --> Helper loaded: file_helper
INFO - 2020-09-06 12:57:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 12:57:32 --> Database Driver Class Initialized
DEBUG - 2020-09-06 12:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 12:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 12:57:32 --> Upload Class Initialized
INFO - 2020-09-06 12:57:32 --> Controller Class Initialized
ERROR - 2020-09-06 12:57:32 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:02:19 --> Config Class Initialized
INFO - 2020-09-06 13:02:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:02:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:02:19 --> Utf8 Class Initialized
INFO - 2020-09-06 13:02:19 --> URI Class Initialized
INFO - 2020-09-06 13:02:19 --> Router Class Initialized
INFO - 2020-09-06 13:02:19 --> Output Class Initialized
INFO - 2020-09-06 13:02:19 --> Security Class Initialized
DEBUG - 2020-09-06 13:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:02:19 --> Input Class Initialized
INFO - 2020-09-06 13:02:19 --> Language Class Initialized
INFO - 2020-09-06 13:02:19 --> Language Class Initialized
INFO - 2020-09-06 13:02:19 --> Config Class Initialized
INFO - 2020-09-06 13:02:19 --> Loader Class Initialized
INFO - 2020-09-06 13:02:19 --> Helper loaded: url_helper
INFO - 2020-09-06 13:02:19 --> Helper loaded: form_helper
INFO - 2020-09-06 13:02:19 --> Helper loaded: file_helper
INFO - 2020-09-06 13:02:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:02:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:02:19 --> Upload Class Initialized
INFO - 2020-09-06 13:02:19 --> Controller Class Initialized
DEBUG - 2020-09-06 13:02:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:02:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 13:02:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:02:19 --> Final output sent to browser
DEBUG - 2020-09-06 13:02:19 --> Total execution time: 0.0568
INFO - 2020-09-06 13:02:28 --> Config Class Initialized
INFO - 2020-09-06 13:02:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:02:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:02:28 --> Utf8 Class Initialized
INFO - 2020-09-06 13:02:28 --> URI Class Initialized
INFO - 2020-09-06 13:02:28 --> Router Class Initialized
INFO - 2020-09-06 13:02:28 --> Output Class Initialized
INFO - 2020-09-06 13:02:28 --> Security Class Initialized
DEBUG - 2020-09-06 13:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:02:28 --> Input Class Initialized
INFO - 2020-09-06 13:02:28 --> Language Class Initialized
INFO - 2020-09-06 13:02:28 --> Language Class Initialized
INFO - 2020-09-06 13:02:28 --> Config Class Initialized
INFO - 2020-09-06 13:02:28 --> Loader Class Initialized
INFO - 2020-09-06 13:02:28 --> Helper loaded: url_helper
INFO - 2020-09-06 13:02:28 --> Helper loaded: form_helper
INFO - 2020-09-06 13:02:28 --> Helper loaded: file_helper
INFO - 2020-09-06 13:02:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:02:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:02:28 --> Upload Class Initialized
INFO - 2020-09-06 13:02:28 --> Controller Class Initialized
ERROR - 2020-09-06 13:02:28 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:05:25 --> Config Class Initialized
INFO - 2020-09-06 13:05:25 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:05:25 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:05:25 --> Utf8 Class Initialized
INFO - 2020-09-06 13:05:25 --> URI Class Initialized
DEBUG - 2020-09-06 13:05:25 --> No URI present. Default controller set.
INFO - 2020-09-06 13:05:25 --> Router Class Initialized
INFO - 2020-09-06 13:05:25 --> Output Class Initialized
INFO - 2020-09-06 13:05:25 --> Security Class Initialized
DEBUG - 2020-09-06 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:05:25 --> Input Class Initialized
INFO - 2020-09-06 13:05:25 --> Language Class Initialized
INFO - 2020-09-06 13:05:25 --> Language Class Initialized
INFO - 2020-09-06 13:05:25 --> Config Class Initialized
INFO - 2020-09-06 13:05:25 --> Loader Class Initialized
INFO - 2020-09-06 13:05:25 --> Helper loaded: url_helper
INFO - 2020-09-06 13:05:25 --> Helper loaded: form_helper
INFO - 2020-09-06 13:05:25 --> Helper loaded: file_helper
INFO - 2020-09-06 13:05:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:05:25 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:05:25 --> Upload Class Initialized
INFO - 2020-09-06 13:05:25 --> Controller Class Initialized
DEBUG - 2020-09-06 13:05:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:05:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 13:05:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 13:05:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:05:25 --> Final output sent to browser
DEBUG - 2020-09-06 13:05:25 --> Total execution time: 0.0490
INFO - 2020-09-06 13:05:26 --> Config Class Initialized
INFO - 2020-09-06 13:05:26 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:05:26 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:05:26 --> Utf8 Class Initialized
INFO - 2020-09-06 13:05:26 --> URI Class Initialized
DEBUG - 2020-09-06 13:05:26 --> No URI present. Default controller set.
INFO - 2020-09-06 13:05:26 --> Router Class Initialized
INFO - 2020-09-06 13:05:26 --> Output Class Initialized
INFO - 2020-09-06 13:05:26 --> Security Class Initialized
DEBUG - 2020-09-06 13:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:05:26 --> Input Class Initialized
INFO - 2020-09-06 13:05:26 --> Language Class Initialized
INFO - 2020-09-06 13:05:26 --> Language Class Initialized
INFO - 2020-09-06 13:05:26 --> Config Class Initialized
INFO - 2020-09-06 13:05:26 --> Loader Class Initialized
INFO - 2020-09-06 13:05:26 --> Helper loaded: url_helper
INFO - 2020-09-06 13:05:26 --> Helper loaded: form_helper
INFO - 2020-09-06 13:05:26 --> Helper loaded: file_helper
INFO - 2020-09-06 13:05:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:05:26 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:05:26 --> Upload Class Initialized
INFO - 2020-09-06 13:05:26 --> Controller Class Initialized
DEBUG - 2020-09-06 13:05:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:05:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 13:05:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 13:05:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:05:26 --> Final output sent to browser
DEBUG - 2020-09-06 13:05:26 --> Total execution time: 0.0505
INFO - 2020-09-06 13:06:36 --> Config Class Initialized
INFO - 2020-09-06 13:06:36 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:06:36 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:06:36 --> Utf8 Class Initialized
INFO - 2020-09-06 13:06:36 --> URI Class Initialized
INFO - 2020-09-06 13:06:36 --> Router Class Initialized
INFO - 2020-09-06 13:06:36 --> Output Class Initialized
INFO - 2020-09-06 13:06:36 --> Security Class Initialized
DEBUG - 2020-09-06 13:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:06:36 --> Input Class Initialized
INFO - 2020-09-06 13:06:36 --> Language Class Initialized
INFO - 2020-09-06 13:06:36 --> Language Class Initialized
INFO - 2020-09-06 13:06:36 --> Config Class Initialized
INFO - 2020-09-06 13:06:36 --> Loader Class Initialized
INFO - 2020-09-06 13:06:36 --> Helper loaded: url_helper
INFO - 2020-09-06 13:06:36 --> Helper loaded: form_helper
INFO - 2020-09-06 13:06:36 --> Helper loaded: file_helper
INFO - 2020-09-06 13:06:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:06:36 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:06:36 --> Upload Class Initialized
INFO - 2020-09-06 13:06:36 --> Controller Class Initialized
DEBUG - 2020-09-06 13:06:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:06:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-06 13:06:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:06:36 --> Final output sent to browser
DEBUG - 2020-09-06 13:06:36 --> Total execution time: 0.0511
INFO - 2020-09-06 13:07:11 --> Config Class Initialized
INFO - 2020-09-06 13:07:11 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:07:11 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:07:11 --> Utf8 Class Initialized
INFO - 2020-09-06 13:07:11 --> URI Class Initialized
INFO - 2020-09-06 13:07:11 --> Router Class Initialized
INFO - 2020-09-06 13:07:11 --> Output Class Initialized
INFO - 2020-09-06 13:07:11 --> Security Class Initialized
DEBUG - 2020-09-06 13:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:07:11 --> Input Class Initialized
INFO - 2020-09-06 13:07:11 --> Language Class Initialized
INFO - 2020-09-06 13:07:11 --> Language Class Initialized
INFO - 2020-09-06 13:07:11 --> Config Class Initialized
INFO - 2020-09-06 13:07:11 --> Loader Class Initialized
INFO - 2020-09-06 13:07:11 --> Helper loaded: url_helper
INFO - 2020-09-06 13:07:11 --> Helper loaded: form_helper
INFO - 2020-09-06 13:07:11 --> Helper loaded: file_helper
INFO - 2020-09-06 13:07:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:07:11 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:07:12 --> Upload Class Initialized
INFO - 2020-09-06 13:07:12 --> Controller Class Initialized
DEBUG - 2020-09-06 13:07:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:07:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-06 13:07:12 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:07:12 --> Final output sent to browser
DEBUG - 2020-09-06 13:07:12 --> Total execution time: 0.0564
INFO - 2020-09-06 13:07:31 --> Config Class Initialized
INFO - 2020-09-06 13:07:31 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:07:31 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:07:31 --> Utf8 Class Initialized
INFO - 2020-09-06 13:07:31 --> URI Class Initialized
DEBUG - 2020-09-06 13:07:31 --> No URI present. Default controller set.
INFO - 2020-09-06 13:07:31 --> Router Class Initialized
INFO - 2020-09-06 13:07:31 --> Output Class Initialized
INFO - 2020-09-06 13:07:31 --> Security Class Initialized
DEBUG - 2020-09-06 13:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:07:31 --> Input Class Initialized
INFO - 2020-09-06 13:07:31 --> Language Class Initialized
INFO - 2020-09-06 13:07:31 --> Language Class Initialized
INFO - 2020-09-06 13:07:31 --> Config Class Initialized
INFO - 2020-09-06 13:07:31 --> Loader Class Initialized
INFO - 2020-09-06 13:07:31 --> Helper loaded: url_helper
INFO - 2020-09-06 13:07:31 --> Helper loaded: form_helper
INFO - 2020-09-06 13:07:31 --> Helper loaded: file_helper
INFO - 2020-09-06 13:07:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:07:31 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:07:31 --> Upload Class Initialized
INFO - 2020-09-06 13:07:31 --> Controller Class Initialized
DEBUG - 2020-09-06 13:07:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:07:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 13:07:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 13:07:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:07:31 --> Final output sent to browser
DEBUG - 2020-09-06 13:07:31 --> Total execution time: 0.0564
INFO - 2020-09-06 13:07:43 --> Config Class Initialized
INFO - 2020-09-06 13:07:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:07:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:07:43 --> Utf8 Class Initialized
INFO - 2020-09-06 13:07:43 --> URI Class Initialized
INFO - 2020-09-06 13:07:43 --> Router Class Initialized
INFO - 2020-09-06 13:07:43 --> Output Class Initialized
INFO - 2020-09-06 13:07:43 --> Security Class Initialized
DEBUG - 2020-09-06 13:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:07:43 --> Input Class Initialized
INFO - 2020-09-06 13:07:43 --> Language Class Initialized
INFO - 2020-09-06 13:07:43 --> Language Class Initialized
INFO - 2020-09-06 13:07:43 --> Config Class Initialized
INFO - 2020-09-06 13:07:43 --> Loader Class Initialized
INFO - 2020-09-06 13:07:43 --> Helper loaded: url_helper
INFO - 2020-09-06 13:07:43 --> Helper loaded: form_helper
INFO - 2020-09-06 13:07:43 --> Helper loaded: file_helper
INFO - 2020-09-06 13:07:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:07:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:07:43 --> Upload Class Initialized
INFO - 2020-09-06 13:07:43 --> Controller Class Initialized
ERROR - 2020-09-06 13:07:43 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:09:11 --> Config Class Initialized
INFO - 2020-09-06 13:09:11 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:09:11 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:09:11 --> Utf8 Class Initialized
INFO - 2020-09-06 13:09:11 --> URI Class Initialized
INFO - 2020-09-06 13:09:11 --> Router Class Initialized
INFO - 2020-09-06 13:09:11 --> Output Class Initialized
INFO - 2020-09-06 13:09:11 --> Security Class Initialized
DEBUG - 2020-09-06 13:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:09:11 --> Input Class Initialized
INFO - 2020-09-06 13:09:11 --> Language Class Initialized
INFO - 2020-09-06 13:09:11 --> Language Class Initialized
INFO - 2020-09-06 13:09:11 --> Config Class Initialized
INFO - 2020-09-06 13:09:11 --> Loader Class Initialized
INFO - 2020-09-06 13:09:11 --> Helper loaded: url_helper
INFO - 2020-09-06 13:09:11 --> Helper loaded: form_helper
INFO - 2020-09-06 13:09:11 --> Helper loaded: file_helper
INFO - 2020-09-06 13:09:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:09:11 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:09:11 --> Upload Class Initialized
INFO - 2020-09-06 13:09:11 --> Controller Class Initialized
DEBUG - 2020-09-06 13:09:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:09:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 13:09:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:09:11 --> Final output sent to browser
DEBUG - 2020-09-06 13:09:11 --> Total execution time: 0.0528
INFO - 2020-09-06 13:09:12 --> Config Class Initialized
INFO - 2020-09-06 13:09:12 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:09:12 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:09:12 --> Utf8 Class Initialized
INFO - 2020-09-06 13:09:12 --> URI Class Initialized
INFO - 2020-09-06 13:09:12 --> Router Class Initialized
INFO - 2020-09-06 13:09:12 --> Output Class Initialized
INFO - 2020-09-06 13:09:12 --> Security Class Initialized
DEBUG - 2020-09-06 13:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:09:12 --> Input Class Initialized
INFO - 2020-09-06 13:09:12 --> Language Class Initialized
INFO - 2020-09-06 13:09:12 --> Language Class Initialized
INFO - 2020-09-06 13:09:12 --> Config Class Initialized
INFO - 2020-09-06 13:09:12 --> Loader Class Initialized
INFO - 2020-09-06 13:09:12 --> Helper loaded: url_helper
INFO - 2020-09-06 13:09:12 --> Helper loaded: form_helper
INFO - 2020-09-06 13:09:12 --> Helper loaded: file_helper
INFO - 2020-09-06 13:09:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:09:12 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:09:12 --> Upload Class Initialized
INFO - 2020-09-06 13:09:13 --> Controller Class Initialized
ERROR - 2020-09-06 13:09:13 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:13:21 --> Config Class Initialized
INFO - 2020-09-06 13:13:21 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:13:21 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:13:21 --> Utf8 Class Initialized
INFO - 2020-09-06 13:13:21 --> URI Class Initialized
INFO - 2020-09-06 13:13:21 --> Router Class Initialized
INFO - 2020-09-06 13:13:21 --> Output Class Initialized
INFO - 2020-09-06 13:13:21 --> Security Class Initialized
DEBUG - 2020-09-06 13:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:13:21 --> Input Class Initialized
INFO - 2020-09-06 13:13:21 --> Language Class Initialized
INFO - 2020-09-06 13:13:21 --> Language Class Initialized
INFO - 2020-09-06 13:13:21 --> Config Class Initialized
INFO - 2020-09-06 13:13:21 --> Loader Class Initialized
INFO - 2020-09-06 13:13:21 --> Helper loaded: url_helper
INFO - 2020-09-06 13:13:21 --> Helper loaded: form_helper
INFO - 2020-09-06 13:13:21 --> Helper loaded: file_helper
INFO - 2020-09-06 13:13:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:13:21 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:13:21 --> Upload Class Initialized
INFO - 2020-09-06 13:13:21 --> Controller Class Initialized
DEBUG - 2020-09-06 13:13:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:13:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 13:13:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:13:21 --> Final output sent to browser
DEBUG - 2020-09-06 13:13:21 --> Total execution time: 0.0523
INFO - 2020-09-06 13:13:22 --> Config Class Initialized
INFO - 2020-09-06 13:13:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:13:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:13:22 --> Utf8 Class Initialized
INFO - 2020-09-06 13:13:22 --> URI Class Initialized
INFO - 2020-09-06 13:13:22 --> Router Class Initialized
INFO - 2020-09-06 13:13:22 --> Output Class Initialized
INFO - 2020-09-06 13:13:22 --> Security Class Initialized
DEBUG - 2020-09-06 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:13:22 --> Input Class Initialized
INFO - 2020-09-06 13:13:22 --> Language Class Initialized
INFO - 2020-09-06 13:13:22 --> Language Class Initialized
INFO - 2020-09-06 13:13:22 --> Config Class Initialized
INFO - 2020-09-06 13:13:22 --> Loader Class Initialized
INFO - 2020-09-06 13:13:22 --> Helper loaded: url_helper
INFO - 2020-09-06 13:13:22 --> Helper loaded: form_helper
INFO - 2020-09-06 13:13:22 --> Helper loaded: file_helper
INFO - 2020-09-06 13:13:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:13:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:13:22 --> Upload Class Initialized
INFO - 2020-09-06 13:13:22 --> Controller Class Initialized
ERROR - 2020-09-06 13:13:22 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:13:22 --> Config Class Initialized
INFO - 2020-09-06 13:13:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:13:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:13:22 --> Utf8 Class Initialized
INFO - 2020-09-06 13:13:22 --> URI Class Initialized
INFO - 2020-09-06 13:13:22 --> Router Class Initialized
INFO - 2020-09-06 13:13:22 --> Output Class Initialized
INFO - 2020-09-06 13:13:22 --> Security Class Initialized
DEBUG - 2020-09-06 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:13:22 --> Input Class Initialized
INFO - 2020-09-06 13:13:22 --> Language Class Initialized
INFO - 2020-09-06 13:13:22 --> Language Class Initialized
INFO - 2020-09-06 13:13:22 --> Config Class Initialized
INFO - 2020-09-06 13:13:22 --> Loader Class Initialized
INFO - 2020-09-06 13:13:22 --> Helper loaded: url_helper
INFO - 2020-09-06 13:13:22 --> Helper loaded: form_helper
INFO - 2020-09-06 13:13:22 --> Helper loaded: file_helper
INFO - 2020-09-06 13:13:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:13:22 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:13:22 --> Upload Class Initialized
INFO - 2020-09-06 13:13:22 --> Controller Class Initialized
DEBUG - 2020-09-06 13:13:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:13:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-06 13:13:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:13:22 --> Final output sent to browser
DEBUG - 2020-09-06 13:13:22 --> Total execution time: 0.0529
INFO - 2020-09-06 13:13:22 --> Config Class Initialized
INFO - 2020-09-06 13:13:22 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:13:22 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:13:22 --> Utf8 Class Initialized
INFO - 2020-09-06 13:13:22 --> URI Class Initialized
INFO - 2020-09-06 13:13:22 --> Router Class Initialized
INFO - 2020-09-06 13:13:23 --> Output Class Initialized
INFO - 2020-09-06 13:13:23 --> Security Class Initialized
DEBUG - 2020-09-06 13:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:13:23 --> Input Class Initialized
INFO - 2020-09-06 13:13:23 --> Language Class Initialized
INFO - 2020-09-06 13:13:23 --> Language Class Initialized
INFO - 2020-09-06 13:13:23 --> Config Class Initialized
INFO - 2020-09-06 13:13:23 --> Loader Class Initialized
INFO - 2020-09-06 13:13:23 --> Helper loaded: url_helper
INFO - 2020-09-06 13:13:23 --> Helper loaded: form_helper
INFO - 2020-09-06 13:13:23 --> Helper loaded: file_helper
INFO - 2020-09-06 13:13:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:13:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:13:23 --> Upload Class Initialized
INFO - 2020-09-06 13:13:23 --> Controller Class Initialized
ERROR - 2020-09-06 13:13:23 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:13:43 --> Config Class Initialized
INFO - 2020-09-06 13:13:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:13:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:13:43 --> Utf8 Class Initialized
INFO - 2020-09-06 13:13:43 --> URI Class Initialized
INFO - 2020-09-06 13:13:43 --> Router Class Initialized
INFO - 2020-09-06 13:13:43 --> Output Class Initialized
INFO - 2020-09-06 13:13:43 --> Security Class Initialized
DEBUG - 2020-09-06 13:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:13:43 --> Input Class Initialized
INFO - 2020-09-06 13:13:43 --> Language Class Initialized
INFO - 2020-09-06 13:13:43 --> Language Class Initialized
INFO - 2020-09-06 13:13:43 --> Config Class Initialized
INFO - 2020-09-06 13:13:43 --> Loader Class Initialized
INFO - 2020-09-06 13:13:43 --> Helper loaded: url_helper
INFO - 2020-09-06 13:13:43 --> Helper loaded: form_helper
INFO - 2020-09-06 13:13:43 --> Helper loaded: file_helper
INFO - 2020-09-06 13:13:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:13:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:13:43 --> Upload Class Initialized
INFO - 2020-09-06 13:13:43 --> Controller Class Initialized
DEBUG - 2020-09-06 13:13:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:13:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 13:13:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:13:43 --> Final output sent to browser
DEBUG - 2020-09-06 13:13:43 --> Total execution time: 0.0504
INFO - 2020-09-06 13:13:54 --> Config Class Initialized
INFO - 2020-09-06 13:13:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:13:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:13:54 --> Utf8 Class Initialized
INFO - 2020-09-06 13:13:54 --> URI Class Initialized
INFO - 2020-09-06 13:13:54 --> Router Class Initialized
INFO - 2020-09-06 13:13:54 --> Output Class Initialized
INFO - 2020-09-06 13:13:54 --> Security Class Initialized
DEBUG - 2020-09-06 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:13:54 --> Input Class Initialized
INFO - 2020-09-06 13:13:54 --> Language Class Initialized
INFO - 2020-09-06 13:13:54 --> Language Class Initialized
INFO - 2020-09-06 13:13:54 --> Config Class Initialized
INFO - 2020-09-06 13:13:54 --> Loader Class Initialized
INFO - 2020-09-06 13:13:54 --> Helper loaded: url_helper
INFO - 2020-09-06 13:13:54 --> Helper loaded: form_helper
INFO - 2020-09-06 13:13:54 --> Helper loaded: file_helper
INFO - 2020-09-06 13:13:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:13:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:13:54 --> Upload Class Initialized
INFO - 2020-09-06 13:13:54 --> Controller Class Initialized
ERROR - 2020-09-06 13:13:54 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:14:57 --> Config Class Initialized
INFO - 2020-09-06 13:14:57 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:14:57 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:14:57 --> Utf8 Class Initialized
INFO - 2020-09-06 13:14:57 --> URI Class Initialized
INFO - 2020-09-06 13:14:57 --> Router Class Initialized
INFO - 2020-09-06 13:14:57 --> Output Class Initialized
INFO - 2020-09-06 13:14:57 --> Security Class Initialized
DEBUG - 2020-09-06 13:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:14:57 --> Input Class Initialized
INFO - 2020-09-06 13:14:57 --> Language Class Initialized
INFO - 2020-09-06 13:14:57 --> Language Class Initialized
INFO - 2020-09-06 13:14:57 --> Config Class Initialized
INFO - 2020-09-06 13:14:57 --> Loader Class Initialized
INFO - 2020-09-06 13:14:57 --> Helper loaded: url_helper
INFO - 2020-09-06 13:14:57 --> Helper loaded: form_helper
INFO - 2020-09-06 13:14:57 --> Helper loaded: file_helper
INFO - 2020-09-06 13:14:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:14:57 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:14:57 --> Upload Class Initialized
INFO - 2020-09-06 13:14:57 --> Controller Class Initialized
DEBUG - 2020-09-06 13:14:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:14:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-06 13:14:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:14:57 --> Final output sent to browser
DEBUG - 2020-09-06 13:14:57 --> Total execution time: 0.0555
INFO - 2020-09-06 13:14:57 --> Config Class Initialized
INFO - 2020-09-06 13:14:57 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:14:57 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:14:57 --> Utf8 Class Initialized
INFO - 2020-09-06 13:14:57 --> URI Class Initialized
INFO - 2020-09-06 13:14:57 --> Router Class Initialized
INFO - 2020-09-06 13:14:57 --> Output Class Initialized
INFO - 2020-09-06 13:14:57 --> Security Class Initialized
DEBUG - 2020-09-06 13:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:14:57 --> Input Class Initialized
INFO - 2020-09-06 13:14:57 --> Language Class Initialized
INFO - 2020-09-06 13:14:57 --> Language Class Initialized
INFO - 2020-09-06 13:14:57 --> Config Class Initialized
INFO - 2020-09-06 13:14:57 --> Loader Class Initialized
INFO - 2020-09-06 13:14:57 --> Helper loaded: url_helper
INFO - 2020-09-06 13:14:57 --> Helper loaded: form_helper
INFO - 2020-09-06 13:14:57 --> Helper loaded: file_helper
INFO - 2020-09-06 13:14:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:14:57 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:14:57 --> Upload Class Initialized
INFO - 2020-09-06 13:14:57 --> Controller Class Initialized
ERROR - 2020-09-06 13:14:57 --> 404 Page Not Found: /index
INFO - 2020-09-06 13:22:49 --> Config Class Initialized
INFO - 2020-09-06 13:22:49 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:22:49 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:22:49 --> Utf8 Class Initialized
INFO - 2020-09-06 13:22:49 --> URI Class Initialized
INFO - 2020-09-06 13:22:49 --> Router Class Initialized
INFO - 2020-09-06 13:22:49 --> Output Class Initialized
INFO - 2020-09-06 13:22:49 --> Security Class Initialized
DEBUG - 2020-09-06 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:22:49 --> Input Class Initialized
INFO - 2020-09-06 13:22:49 --> Language Class Initialized
INFO - 2020-09-06 13:22:49 --> Language Class Initialized
INFO - 2020-09-06 13:22:49 --> Config Class Initialized
INFO - 2020-09-06 13:22:49 --> Loader Class Initialized
INFO - 2020-09-06 13:22:49 --> Helper loaded: url_helper
INFO - 2020-09-06 13:22:49 --> Helper loaded: form_helper
INFO - 2020-09-06 13:22:49 --> Helper loaded: file_helper
INFO - 2020-09-06 13:22:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:22:49 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:22:49 --> Upload Class Initialized
INFO - 2020-09-06 13:22:49 --> Controller Class Initialized
DEBUG - 2020-09-06 13:22:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 13:22:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 13:22:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 13:22:49 --> Final output sent to browser
DEBUG - 2020-09-06 13:22:49 --> Total execution time: 0.0520
INFO - 2020-09-06 13:22:59 --> Config Class Initialized
INFO - 2020-09-06 13:22:59 --> Hooks Class Initialized
DEBUG - 2020-09-06 13:22:59 --> UTF-8 Support Enabled
INFO - 2020-09-06 13:22:59 --> Utf8 Class Initialized
INFO - 2020-09-06 13:22:59 --> URI Class Initialized
INFO - 2020-09-06 13:22:59 --> Router Class Initialized
INFO - 2020-09-06 13:22:59 --> Output Class Initialized
INFO - 2020-09-06 13:22:59 --> Security Class Initialized
DEBUG - 2020-09-06 13:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 13:22:59 --> Input Class Initialized
INFO - 2020-09-06 13:22:59 --> Language Class Initialized
INFO - 2020-09-06 13:22:59 --> Language Class Initialized
INFO - 2020-09-06 13:22:59 --> Config Class Initialized
INFO - 2020-09-06 13:22:59 --> Loader Class Initialized
INFO - 2020-09-06 13:22:59 --> Helper loaded: url_helper
INFO - 2020-09-06 13:22:59 --> Helper loaded: form_helper
INFO - 2020-09-06 13:22:59 --> Helper loaded: file_helper
INFO - 2020-09-06 13:22:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 13:22:59 --> Database Driver Class Initialized
DEBUG - 2020-09-06 13:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 13:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 13:22:59 --> Upload Class Initialized
INFO - 2020-09-06 13:22:59 --> Controller Class Initialized
ERROR - 2020-09-06 13:22:59 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:16:35 --> Config Class Initialized
INFO - 2020-09-06 14:16:35 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:16:35 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:16:35 --> Utf8 Class Initialized
INFO - 2020-09-06 14:16:35 --> URI Class Initialized
INFO - 2020-09-06 14:16:35 --> Router Class Initialized
INFO - 2020-09-06 14:16:35 --> Output Class Initialized
INFO - 2020-09-06 14:16:35 --> Security Class Initialized
DEBUG - 2020-09-06 14:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:16:35 --> Input Class Initialized
INFO - 2020-09-06 14:16:35 --> Language Class Initialized
INFO - 2020-09-06 14:16:35 --> Language Class Initialized
INFO - 2020-09-06 14:16:35 --> Config Class Initialized
INFO - 2020-09-06 14:16:35 --> Loader Class Initialized
INFO - 2020-09-06 14:16:35 --> Helper loaded: url_helper
INFO - 2020-09-06 14:16:35 --> Helper loaded: form_helper
INFO - 2020-09-06 14:16:35 --> Helper loaded: file_helper
INFO - 2020-09-06 14:16:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:16:35 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:16:35 --> Upload Class Initialized
INFO - 2020-09-06 14:16:35 --> Controller Class Initialized
DEBUG - 2020-09-06 14:16:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:16:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 14:16:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:16:35 --> Final output sent to browser
DEBUG - 2020-09-06 14:16:35 --> Total execution time: 0.1107
INFO - 2020-09-06 14:16:37 --> Config Class Initialized
INFO - 2020-09-06 14:16:37 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:16:37 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:16:37 --> Utf8 Class Initialized
INFO - 2020-09-06 14:16:37 --> URI Class Initialized
INFO - 2020-09-06 14:16:37 --> Router Class Initialized
INFO - 2020-09-06 14:16:37 --> Output Class Initialized
INFO - 2020-09-06 14:16:37 --> Security Class Initialized
DEBUG - 2020-09-06 14:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:16:37 --> Input Class Initialized
INFO - 2020-09-06 14:16:37 --> Language Class Initialized
INFO - 2020-09-06 14:16:37 --> Language Class Initialized
INFO - 2020-09-06 14:16:37 --> Config Class Initialized
INFO - 2020-09-06 14:16:37 --> Loader Class Initialized
INFO - 2020-09-06 14:16:37 --> Helper loaded: url_helper
INFO - 2020-09-06 14:16:37 --> Helper loaded: form_helper
INFO - 2020-09-06 14:16:37 --> Helper loaded: file_helper
INFO - 2020-09-06 14:16:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:16:37 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:16:37 --> Upload Class Initialized
INFO - 2020-09-06 14:16:37 --> Controller Class Initialized
ERROR - 2020-09-06 14:16:37 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:19:41 --> Config Class Initialized
INFO - 2020-09-06 14:19:41 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:19:41 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:19:41 --> Utf8 Class Initialized
INFO - 2020-09-06 14:19:41 --> URI Class Initialized
INFO - 2020-09-06 14:19:41 --> Router Class Initialized
INFO - 2020-09-06 14:19:41 --> Output Class Initialized
INFO - 2020-09-06 14:19:41 --> Security Class Initialized
DEBUG - 2020-09-06 14:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:19:41 --> Input Class Initialized
INFO - 2020-09-06 14:19:41 --> Language Class Initialized
INFO - 2020-09-06 14:19:41 --> Language Class Initialized
INFO - 2020-09-06 14:19:41 --> Config Class Initialized
INFO - 2020-09-06 14:19:41 --> Loader Class Initialized
INFO - 2020-09-06 14:19:41 --> Helper loaded: url_helper
INFO - 2020-09-06 14:19:41 --> Helper loaded: form_helper
INFO - 2020-09-06 14:19:41 --> Helper loaded: file_helper
INFO - 2020-09-06 14:19:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:19:41 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:19:41 --> Upload Class Initialized
INFO - 2020-09-06 14:19:41 --> Controller Class Initialized
ERROR - 2020-09-06 14:19:41 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:19:42 --> Config Class Initialized
INFO - 2020-09-06 14:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:19:42 --> Utf8 Class Initialized
INFO - 2020-09-06 14:19:42 --> URI Class Initialized
DEBUG - 2020-09-06 14:19:42 --> No URI present. Default controller set.
INFO - 2020-09-06 14:19:42 --> Router Class Initialized
INFO - 2020-09-06 14:19:42 --> Output Class Initialized
INFO - 2020-09-06 14:19:42 --> Security Class Initialized
DEBUG - 2020-09-06 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:19:42 --> Input Class Initialized
INFO - 2020-09-06 14:19:42 --> Language Class Initialized
INFO - 2020-09-06 14:19:42 --> Language Class Initialized
INFO - 2020-09-06 14:19:42 --> Config Class Initialized
INFO - 2020-09-06 14:19:42 --> Loader Class Initialized
INFO - 2020-09-06 14:19:42 --> Helper loaded: url_helper
INFO - 2020-09-06 14:19:42 --> Helper loaded: form_helper
INFO - 2020-09-06 14:19:42 --> Helper loaded: file_helper
INFO - 2020-09-06 14:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:19:42 --> Upload Class Initialized
INFO - 2020-09-06 14:19:42 --> Controller Class Initialized
DEBUG - 2020-09-06 14:19:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:19:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 14:19:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 14:19:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:19:42 --> Final output sent to browser
DEBUG - 2020-09-06 14:19:42 --> Total execution time: 0.0535
INFO - 2020-09-06 14:44:43 --> Config Class Initialized
INFO - 2020-09-06 14:44:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:44:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:44:43 --> Utf8 Class Initialized
INFO - 2020-09-06 14:44:43 --> URI Class Initialized
INFO - 2020-09-06 14:44:43 --> Router Class Initialized
INFO - 2020-09-06 14:44:43 --> Output Class Initialized
INFO - 2020-09-06 14:44:43 --> Security Class Initialized
DEBUG - 2020-09-06 14:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:44:43 --> Input Class Initialized
INFO - 2020-09-06 14:44:43 --> Language Class Initialized
INFO - 2020-09-06 14:44:43 --> Language Class Initialized
INFO - 2020-09-06 14:44:43 --> Config Class Initialized
INFO - 2020-09-06 14:44:43 --> Loader Class Initialized
INFO - 2020-09-06 14:44:43 --> Helper loaded: url_helper
INFO - 2020-09-06 14:44:43 --> Helper loaded: form_helper
INFO - 2020-09-06 14:44:43 --> Helper loaded: file_helper
INFO - 2020-09-06 14:44:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:44:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:44:43 --> Upload Class Initialized
INFO - 2020-09-06 14:44:43 --> Controller Class Initialized
DEBUG - 2020-09-06 14:44:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:44:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 14:44:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:44:43 --> Final output sent to browser
DEBUG - 2020-09-06 14:44:43 --> Total execution time: 0.0816
INFO - 2020-09-06 14:44:54 --> Config Class Initialized
INFO - 2020-09-06 14:44:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:44:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:44:54 --> Utf8 Class Initialized
INFO - 2020-09-06 14:44:54 --> URI Class Initialized
INFO - 2020-09-06 14:44:54 --> Router Class Initialized
INFO - 2020-09-06 14:44:54 --> Output Class Initialized
INFO - 2020-09-06 14:44:54 --> Security Class Initialized
DEBUG - 2020-09-06 14:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:44:54 --> Input Class Initialized
INFO - 2020-09-06 14:44:54 --> Language Class Initialized
INFO - 2020-09-06 14:44:54 --> Language Class Initialized
INFO - 2020-09-06 14:44:54 --> Config Class Initialized
INFO - 2020-09-06 14:44:54 --> Loader Class Initialized
INFO - 2020-09-06 14:44:54 --> Helper loaded: url_helper
INFO - 2020-09-06 14:44:54 --> Helper loaded: form_helper
INFO - 2020-09-06 14:44:54 --> Helper loaded: file_helper
INFO - 2020-09-06 14:44:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:44:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:44:54 --> Upload Class Initialized
INFO - 2020-09-06 14:44:54 --> Controller Class Initialized
ERROR - 2020-09-06 14:44:54 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:45:38 --> Config Class Initialized
INFO - 2020-09-06 14:45:38 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:45:38 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:45:38 --> Utf8 Class Initialized
INFO - 2020-09-06 14:45:38 --> URI Class Initialized
INFO - 2020-09-06 14:45:38 --> Router Class Initialized
INFO - 2020-09-06 14:45:38 --> Output Class Initialized
INFO - 2020-09-06 14:45:38 --> Security Class Initialized
DEBUG - 2020-09-06 14:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:45:38 --> Input Class Initialized
INFO - 2020-09-06 14:45:38 --> Language Class Initialized
INFO - 2020-09-06 14:45:38 --> Language Class Initialized
INFO - 2020-09-06 14:45:38 --> Config Class Initialized
INFO - 2020-09-06 14:45:38 --> Loader Class Initialized
INFO - 2020-09-06 14:45:38 --> Helper loaded: url_helper
INFO - 2020-09-06 14:45:38 --> Helper loaded: form_helper
INFO - 2020-09-06 14:45:38 --> Helper loaded: file_helper
INFO - 2020-09-06 14:45:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:45:38 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:45:38 --> Upload Class Initialized
INFO - 2020-09-06 14:45:38 --> Controller Class Initialized
DEBUG - 2020-09-06 14:45:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:45:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 14:45:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:45:38 --> Final output sent to browser
DEBUG - 2020-09-06 14:45:38 --> Total execution time: 0.0506
INFO - 2020-09-06 14:45:49 --> Config Class Initialized
INFO - 2020-09-06 14:45:49 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:45:49 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:45:49 --> Utf8 Class Initialized
INFO - 2020-09-06 14:45:49 --> URI Class Initialized
INFO - 2020-09-06 14:45:49 --> Router Class Initialized
INFO - 2020-09-06 14:45:49 --> Output Class Initialized
INFO - 2020-09-06 14:45:49 --> Security Class Initialized
DEBUG - 2020-09-06 14:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:45:49 --> Input Class Initialized
INFO - 2020-09-06 14:45:49 --> Language Class Initialized
INFO - 2020-09-06 14:45:49 --> Language Class Initialized
INFO - 2020-09-06 14:45:49 --> Config Class Initialized
INFO - 2020-09-06 14:45:49 --> Loader Class Initialized
INFO - 2020-09-06 14:45:49 --> Helper loaded: url_helper
INFO - 2020-09-06 14:45:49 --> Helper loaded: form_helper
INFO - 2020-09-06 14:45:49 --> Helper loaded: file_helper
INFO - 2020-09-06 14:45:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:45:49 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:45:49 --> Upload Class Initialized
INFO - 2020-09-06 14:45:49 --> Controller Class Initialized
ERROR - 2020-09-06 14:45:49 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:46:03 --> Config Class Initialized
INFO - 2020-09-06 14:46:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:46:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:46:03 --> Utf8 Class Initialized
INFO - 2020-09-06 14:46:03 --> URI Class Initialized
INFO - 2020-09-06 14:46:03 --> Router Class Initialized
INFO - 2020-09-06 14:46:03 --> Output Class Initialized
INFO - 2020-09-06 14:46:03 --> Security Class Initialized
DEBUG - 2020-09-06 14:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:46:03 --> Input Class Initialized
INFO - 2020-09-06 14:46:03 --> Language Class Initialized
INFO - 2020-09-06 14:46:03 --> Language Class Initialized
INFO - 2020-09-06 14:46:03 --> Config Class Initialized
INFO - 2020-09-06 14:46:03 --> Loader Class Initialized
INFO - 2020-09-06 14:46:03 --> Helper loaded: url_helper
INFO - 2020-09-06 14:46:03 --> Helper loaded: form_helper
INFO - 2020-09-06 14:46:03 --> Helper loaded: file_helper
INFO - 2020-09-06 14:46:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:46:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:46:03 --> Upload Class Initialized
INFO - 2020-09-06 14:46:03 --> Controller Class Initialized
DEBUG - 2020-09-06 14:46:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:46:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 14:46:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:46:03 --> Final output sent to browser
DEBUG - 2020-09-06 14:46:03 --> Total execution time: 0.0537
INFO - 2020-09-06 14:46:05 --> Config Class Initialized
INFO - 2020-09-06 14:46:05 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:46:05 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:46:05 --> Utf8 Class Initialized
INFO - 2020-09-06 14:46:05 --> URI Class Initialized
INFO - 2020-09-06 14:46:05 --> Router Class Initialized
INFO - 2020-09-06 14:46:05 --> Output Class Initialized
INFO - 2020-09-06 14:46:05 --> Security Class Initialized
DEBUG - 2020-09-06 14:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:46:05 --> Input Class Initialized
INFO - 2020-09-06 14:46:05 --> Language Class Initialized
INFO - 2020-09-06 14:46:05 --> Language Class Initialized
INFO - 2020-09-06 14:46:05 --> Config Class Initialized
INFO - 2020-09-06 14:46:05 --> Loader Class Initialized
INFO - 2020-09-06 14:46:05 --> Helper loaded: url_helper
INFO - 2020-09-06 14:46:05 --> Helper loaded: form_helper
INFO - 2020-09-06 14:46:05 --> Helper loaded: file_helper
INFO - 2020-09-06 14:46:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:46:05 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:46:05 --> Upload Class Initialized
INFO - 2020-09-06 14:46:05 --> Controller Class Initialized
ERROR - 2020-09-06 14:46:05 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:46:40 --> Config Class Initialized
INFO - 2020-09-06 14:46:40 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:46:40 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:46:40 --> Utf8 Class Initialized
INFO - 2020-09-06 14:46:40 --> URI Class Initialized
INFO - 2020-09-06 14:46:40 --> Router Class Initialized
INFO - 2020-09-06 14:46:40 --> Output Class Initialized
INFO - 2020-09-06 14:46:40 --> Security Class Initialized
DEBUG - 2020-09-06 14:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:46:40 --> Input Class Initialized
INFO - 2020-09-06 14:46:40 --> Language Class Initialized
INFO - 2020-09-06 14:46:40 --> Language Class Initialized
INFO - 2020-09-06 14:46:40 --> Config Class Initialized
INFO - 2020-09-06 14:46:40 --> Loader Class Initialized
INFO - 2020-09-06 14:46:40 --> Helper loaded: url_helper
INFO - 2020-09-06 14:46:40 --> Helper loaded: form_helper
INFO - 2020-09-06 14:46:40 --> Helper loaded: file_helper
INFO - 2020-09-06 14:46:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:46:40 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:46:40 --> Upload Class Initialized
INFO - 2020-09-06 14:46:40 --> Controller Class Initialized
DEBUG - 2020-09-06 14:46:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:46:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 14:46:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:46:40 --> Final output sent to browser
DEBUG - 2020-09-06 14:46:40 --> Total execution time: 0.0552
INFO - 2020-09-06 14:46:42 --> Config Class Initialized
INFO - 2020-09-06 14:46:42 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:46:42 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:46:42 --> Utf8 Class Initialized
INFO - 2020-09-06 14:46:42 --> URI Class Initialized
INFO - 2020-09-06 14:46:42 --> Router Class Initialized
INFO - 2020-09-06 14:46:42 --> Output Class Initialized
INFO - 2020-09-06 14:46:42 --> Security Class Initialized
DEBUG - 2020-09-06 14:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:46:42 --> Input Class Initialized
INFO - 2020-09-06 14:46:42 --> Language Class Initialized
INFO - 2020-09-06 14:46:42 --> Language Class Initialized
INFO - 2020-09-06 14:46:42 --> Config Class Initialized
INFO - 2020-09-06 14:46:42 --> Loader Class Initialized
INFO - 2020-09-06 14:46:42 --> Helper loaded: url_helper
INFO - 2020-09-06 14:46:42 --> Helper loaded: form_helper
INFO - 2020-09-06 14:46:42 --> Helper loaded: file_helper
INFO - 2020-09-06 14:46:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:46:42 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:46:42 --> Upload Class Initialized
INFO - 2020-09-06 14:46:42 --> Controller Class Initialized
ERROR - 2020-09-06 14:46:42 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:46:53 --> Config Class Initialized
INFO - 2020-09-06 14:46:53 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:46:53 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:46:53 --> Utf8 Class Initialized
INFO - 2020-09-06 14:46:53 --> URI Class Initialized
INFO - 2020-09-06 14:46:53 --> Router Class Initialized
INFO - 2020-09-06 14:46:53 --> Output Class Initialized
INFO - 2020-09-06 14:46:53 --> Security Class Initialized
DEBUG - 2020-09-06 14:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:46:53 --> Input Class Initialized
INFO - 2020-09-06 14:46:53 --> Language Class Initialized
INFO - 2020-09-06 14:46:53 --> Language Class Initialized
INFO - 2020-09-06 14:46:53 --> Config Class Initialized
INFO - 2020-09-06 14:46:53 --> Loader Class Initialized
INFO - 2020-09-06 14:46:53 --> Helper loaded: url_helper
INFO - 2020-09-06 14:46:53 --> Helper loaded: form_helper
INFO - 2020-09-06 14:46:53 --> Helper loaded: file_helper
INFO - 2020-09-06 14:46:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:46:53 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:46:53 --> Upload Class Initialized
INFO - 2020-09-06 14:46:53 --> Controller Class Initialized
DEBUG - 2020-09-06 14:46:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:46:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-06 14:46:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:46:53 --> Final output sent to browser
DEBUG - 2020-09-06 14:46:53 --> Total execution time: 0.0518
INFO - 2020-09-06 14:46:58 --> Config Class Initialized
INFO - 2020-09-06 14:46:58 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:46:58 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:46:58 --> Utf8 Class Initialized
INFO - 2020-09-06 14:46:58 --> URI Class Initialized
INFO - 2020-09-06 14:46:58 --> Router Class Initialized
INFO - 2020-09-06 14:46:58 --> Output Class Initialized
INFO - 2020-09-06 14:46:58 --> Security Class Initialized
DEBUG - 2020-09-06 14:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:46:58 --> Input Class Initialized
INFO - 2020-09-06 14:46:58 --> Language Class Initialized
INFO - 2020-09-06 14:46:58 --> Language Class Initialized
INFO - 2020-09-06 14:46:58 --> Config Class Initialized
INFO - 2020-09-06 14:46:58 --> Loader Class Initialized
INFO - 2020-09-06 14:46:58 --> Helper loaded: url_helper
INFO - 2020-09-06 14:46:58 --> Helper loaded: form_helper
INFO - 2020-09-06 14:46:58 --> Helper loaded: file_helper
INFO - 2020-09-06 14:46:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:46:58 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:46:58 --> Upload Class Initialized
INFO - 2020-09-06 14:46:58 --> Controller Class Initialized
ERROR - 2020-09-06 14:46:58 --> 404 Page Not Found: /index
INFO - 2020-09-06 14:47:08 --> Config Class Initialized
INFO - 2020-09-06 14:47:08 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:47:08 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:47:08 --> Utf8 Class Initialized
INFO - 2020-09-06 14:47:08 --> URI Class Initialized
INFO - 2020-09-06 14:47:08 --> Router Class Initialized
INFO - 2020-09-06 14:47:08 --> Output Class Initialized
INFO - 2020-09-06 14:47:08 --> Security Class Initialized
DEBUG - 2020-09-06 14:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:47:08 --> Input Class Initialized
INFO - 2020-09-06 14:47:08 --> Language Class Initialized
INFO - 2020-09-06 14:47:08 --> Language Class Initialized
INFO - 2020-09-06 14:47:08 --> Config Class Initialized
INFO - 2020-09-06 14:47:08 --> Loader Class Initialized
INFO - 2020-09-06 14:47:08 --> Helper loaded: url_helper
INFO - 2020-09-06 14:47:08 --> Helper loaded: form_helper
INFO - 2020-09-06 14:47:08 --> Helper loaded: file_helper
INFO - 2020-09-06 14:47:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:47:08 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:47:08 --> Upload Class Initialized
INFO - 2020-09-06 14:47:08 --> Controller Class Initialized
DEBUG - 2020-09-06 14:47:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 14:47:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 14:47:08 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 14:47:08 --> Final output sent to browser
DEBUG - 2020-09-06 14:47:08 --> Total execution time: 0.0498
INFO - 2020-09-06 14:47:09 --> Config Class Initialized
INFO - 2020-09-06 14:47:09 --> Hooks Class Initialized
DEBUG - 2020-09-06 14:47:09 --> UTF-8 Support Enabled
INFO - 2020-09-06 14:47:09 --> Utf8 Class Initialized
INFO - 2020-09-06 14:47:09 --> URI Class Initialized
INFO - 2020-09-06 14:47:09 --> Router Class Initialized
INFO - 2020-09-06 14:47:09 --> Output Class Initialized
INFO - 2020-09-06 14:47:09 --> Security Class Initialized
DEBUG - 2020-09-06 14:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 14:47:09 --> Input Class Initialized
INFO - 2020-09-06 14:47:09 --> Language Class Initialized
INFO - 2020-09-06 14:47:09 --> Language Class Initialized
INFO - 2020-09-06 14:47:09 --> Config Class Initialized
INFO - 2020-09-06 14:47:09 --> Loader Class Initialized
INFO - 2020-09-06 14:47:09 --> Helper loaded: url_helper
INFO - 2020-09-06 14:47:09 --> Helper loaded: form_helper
INFO - 2020-09-06 14:47:09 --> Helper loaded: file_helper
INFO - 2020-09-06 14:47:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 14:47:09 --> Database Driver Class Initialized
DEBUG - 2020-09-06 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 14:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 14:47:09 --> Upload Class Initialized
INFO - 2020-09-06 14:47:09 --> Controller Class Initialized
ERROR - 2020-09-06 14:47:09 --> 404 Page Not Found: /index
INFO - 2020-09-06 15:54:59 --> Config Class Initialized
INFO - 2020-09-06 15:54:59 --> Hooks Class Initialized
DEBUG - 2020-09-06 15:54:59 --> UTF-8 Support Enabled
INFO - 2020-09-06 15:54:59 --> Utf8 Class Initialized
INFO - 2020-09-06 15:54:59 --> URI Class Initialized
INFO - 2020-09-06 15:54:59 --> Router Class Initialized
INFO - 2020-09-06 15:54:59 --> Output Class Initialized
INFO - 2020-09-06 15:54:59 --> Security Class Initialized
DEBUG - 2020-09-06 15:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 15:54:59 --> Input Class Initialized
INFO - 2020-09-06 15:54:59 --> Language Class Initialized
INFO - 2020-09-06 15:54:59 --> Language Class Initialized
INFO - 2020-09-06 15:54:59 --> Config Class Initialized
INFO - 2020-09-06 15:54:59 --> Loader Class Initialized
INFO - 2020-09-06 15:54:59 --> Helper loaded: url_helper
INFO - 2020-09-06 15:54:59 --> Helper loaded: form_helper
INFO - 2020-09-06 15:54:59 --> Helper loaded: file_helper
INFO - 2020-09-06 15:54:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 15:54:59 --> Database Driver Class Initialized
DEBUG - 2020-09-06 15:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 15:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 15:54:59 --> Upload Class Initialized
INFO - 2020-09-06 15:54:59 --> Controller Class Initialized
DEBUG - 2020-09-06 15:54:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 15:54:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 15:54:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 15:54:59 --> Final output sent to browser
DEBUG - 2020-09-06 15:54:59 --> Total execution time: 0.1453
INFO - 2020-09-06 15:55:03 --> Config Class Initialized
INFO - 2020-09-06 15:55:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 15:55:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 15:55:03 --> Utf8 Class Initialized
INFO - 2020-09-06 15:55:03 --> URI Class Initialized
INFO - 2020-09-06 15:55:03 --> Router Class Initialized
INFO - 2020-09-06 15:55:03 --> Output Class Initialized
INFO - 2020-09-06 15:55:03 --> Security Class Initialized
DEBUG - 2020-09-06 15:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 15:55:03 --> Input Class Initialized
INFO - 2020-09-06 15:55:03 --> Language Class Initialized
INFO - 2020-09-06 15:55:03 --> Language Class Initialized
INFO - 2020-09-06 15:55:03 --> Config Class Initialized
INFO - 2020-09-06 15:55:03 --> Loader Class Initialized
INFO - 2020-09-06 15:55:03 --> Helper loaded: url_helper
INFO - 2020-09-06 15:55:03 --> Helper loaded: form_helper
INFO - 2020-09-06 15:55:03 --> Helper loaded: file_helper
INFO - 2020-09-06 15:55:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 15:55:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 15:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 15:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 15:55:03 --> Upload Class Initialized
INFO - 2020-09-06 15:55:03 --> Controller Class Initialized
ERROR - 2020-09-06 15:55:03 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:26:37 --> Config Class Initialized
INFO - 2020-09-06 16:26:37 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:26:37 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:26:37 --> Utf8 Class Initialized
INFO - 2020-09-06 16:26:37 --> URI Class Initialized
INFO - 2020-09-06 16:26:37 --> Router Class Initialized
INFO - 2020-09-06 16:26:37 --> Output Class Initialized
INFO - 2020-09-06 16:26:37 --> Security Class Initialized
DEBUG - 2020-09-06 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:26:37 --> Input Class Initialized
INFO - 2020-09-06 16:26:37 --> Language Class Initialized
INFO - 2020-09-06 16:26:37 --> Language Class Initialized
INFO - 2020-09-06 16:26:37 --> Config Class Initialized
INFO - 2020-09-06 16:26:37 --> Loader Class Initialized
INFO - 2020-09-06 16:26:37 --> Helper loaded: url_helper
INFO - 2020-09-06 16:26:37 --> Helper loaded: form_helper
INFO - 2020-09-06 16:26:37 --> Helper loaded: file_helper
INFO - 2020-09-06 16:26:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:26:37 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:26:37 --> Upload Class Initialized
INFO - 2020-09-06 16:26:37 --> Controller Class Initialized
DEBUG - 2020-09-06 16:26:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:26:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-06 16:26:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:26:37 --> Final output sent to browser
DEBUG - 2020-09-06 16:26:37 --> Total execution time: 0.0525
INFO - 2020-09-06 16:26:42 --> Config Class Initialized
INFO - 2020-09-06 16:26:42 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:26:42 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:26:42 --> Utf8 Class Initialized
INFO - 2020-09-06 16:26:42 --> URI Class Initialized
INFO - 2020-09-06 16:26:42 --> Router Class Initialized
INFO - 2020-09-06 16:26:42 --> Output Class Initialized
INFO - 2020-09-06 16:26:42 --> Security Class Initialized
DEBUG - 2020-09-06 16:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:26:42 --> Input Class Initialized
INFO - 2020-09-06 16:26:42 --> Language Class Initialized
INFO - 2020-09-06 16:26:42 --> Language Class Initialized
INFO - 2020-09-06 16:26:42 --> Config Class Initialized
INFO - 2020-09-06 16:26:42 --> Loader Class Initialized
INFO - 2020-09-06 16:26:42 --> Helper loaded: url_helper
INFO - 2020-09-06 16:26:42 --> Helper loaded: form_helper
INFO - 2020-09-06 16:26:42 --> Helper loaded: file_helper
INFO - 2020-09-06 16:26:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:26:42 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:26:42 --> Upload Class Initialized
INFO - 2020-09-06 16:26:42 --> Controller Class Initialized
ERROR - 2020-09-06 16:26:42 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:26:52 --> Config Class Initialized
INFO - 2020-09-06 16:26:52 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:26:52 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:26:52 --> Utf8 Class Initialized
INFO - 2020-09-06 16:26:52 --> URI Class Initialized
INFO - 2020-09-06 16:26:52 --> Router Class Initialized
INFO - 2020-09-06 16:26:52 --> Output Class Initialized
INFO - 2020-09-06 16:26:52 --> Security Class Initialized
DEBUG - 2020-09-06 16:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:26:52 --> Input Class Initialized
INFO - 2020-09-06 16:26:52 --> Language Class Initialized
INFO - 2020-09-06 16:26:52 --> Language Class Initialized
INFO - 2020-09-06 16:26:52 --> Config Class Initialized
INFO - 2020-09-06 16:26:52 --> Loader Class Initialized
INFO - 2020-09-06 16:26:52 --> Helper loaded: url_helper
INFO - 2020-09-06 16:26:52 --> Helper loaded: form_helper
INFO - 2020-09-06 16:26:52 --> Helper loaded: file_helper
INFO - 2020-09-06 16:26:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:26:52 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:26:52 --> Upload Class Initialized
INFO - 2020-09-06 16:26:52 --> Controller Class Initialized
DEBUG - 2020-09-06 16:26:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:26:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 16:26:52 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:26:52 --> Final output sent to browser
DEBUG - 2020-09-06 16:26:52 --> Total execution time: 0.0548
INFO - 2020-09-06 16:26:53 --> Config Class Initialized
INFO - 2020-09-06 16:26:53 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:26:53 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:26:53 --> Utf8 Class Initialized
INFO - 2020-09-06 16:26:53 --> URI Class Initialized
INFO - 2020-09-06 16:26:53 --> Router Class Initialized
INFO - 2020-09-06 16:26:53 --> Output Class Initialized
INFO - 2020-09-06 16:26:53 --> Security Class Initialized
DEBUG - 2020-09-06 16:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:26:53 --> Input Class Initialized
INFO - 2020-09-06 16:26:53 --> Language Class Initialized
INFO - 2020-09-06 16:26:53 --> Language Class Initialized
INFO - 2020-09-06 16:26:53 --> Config Class Initialized
INFO - 2020-09-06 16:26:53 --> Loader Class Initialized
INFO - 2020-09-06 16:26:53 --> Helper loaded: url_helper
INFO - 2020-09-06 16:26:53 --> Helper loaded: form_helper
INFO - 2020-09-06 16:26:53 --> Helper loaded: file_helper
INFO - 2020-09-06 16:26:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:26:53 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:26:53 --> Upload Class Initialized
INFO - 2020-09-06 16:26:53 --> Controller Class Initialized
ERROR - 2020-09-06 16:26:53 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:45:43 --> Config Class Initialized
INFO - 2020-09-06 16:45:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:45:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:45:43 --> Utf8 Class Initialized
INFO - 2020-09-06 16:45:43 --> URI Class Initialized
INFO - 2020-09-06 16:45:43 --> Router Class Initialized
INFO - 2020-09-06 16:45:43 --> Output Class Initialized
INFO - 2020-09-06 16:45:43 --> Security Class Initialized
DEBUG - 2020-09-06 16:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:45:43 --> Input Class Initialized
INFO - 2020-09-06 16:45:43 --> Language Class Initialized
INFO - 2020-09-06 16:45:43 --> Language Class Initialized
INFO - 2020-09-06 16:45:43 --> Config Class Initialized
INFO - 2020-09-06 16:45:43 --> Loader Class Initialized
INFO - 2020-09-06 16:45:43 --> Helper loaded: url_helper
INFO - 2020-09-06 16:45:43 --> Helper loaded: form_helper
INFO - 2020-09-06 16:45:43 --> Helper loaded: file_helper
INFO - 2020-09-06 16:45:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:45:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:45:43 --> Upload Class Initialized
INFO - 2020-09-06 16:45:43 --> Controller Class Initialized
DEBUG - 2020-09-06 16:45:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:45:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 16:45:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:45:43 --> Final output sent to browser
DEBUG - 2020-09-06 16:45:43 --> Total execution time: 0.0541
INFO - 2020-09-06 16:45:47 --> Config Class Initialized
INFO - 2020-09-06 16:45:47 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:45:47 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:45:47 --> Utf8 Class Initialized
INFO - 2020-09-06 16:45:47 --> URI Class Initialized
INFO - 2020-09-06 16:45:47 --> Router Class Initialized
INFO - 2020-09-06 16:45:47 --> Output Class Initialized
INFO - 2020-09-06 16:45:47 --> Security Class Initialized
DEBUG - 2020-09-06 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:45:47 --> Input Class Initialized
INFO - 2020-09-06 16:45:47 --> Language Class Initialized
INFO - 2020-09-06 16:45:47 --> Language Class Initialized
INFO - 2020-09-06 16:45:47 --> Config Class Initialized
INFO - 2020-09-06 16:45:47 --> Loader Class Initialized
INFO - 2020-09-06 16:45:47 --> Helper loaded: url_helper
INFO - 2020-09-06 16:45:47 --> Helper loaded: form_helper
INFO - 2020-09-06 16:45:47 --> Helper loaded: file_helper
INFO - 2020-09-06 16:45:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:45:47 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:45:47 --> Upload Class Initialized
INFO - 2020-09-06 16:45:47 --> Controller Class Initialized
ERROR - 2020-09-06 16:45:47 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:53:40 --> Config Class Initialized
INFO - 2020-09-06 16:53:40 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:53:40 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:53:40 --> Utf8 Class Initialized
INFO - 2020-09-06 16:53:40 --> URI Class Initialized
DEBUG - 2020-09-06 16:53:40 --> No URI present. Default controller set.
INFO - 2020-09-06 16:53:40 --> Router Class Initialized
INFO - 2020-09-06 16:53:40 --> Output Class Initialized
INFO - 2020-09-06 16:53:40 --> Security Class Initialized
DEBUG - 2020-09-06 16:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:53:40 --> Input Class Initialized
INFO - 2020-09-06 16:53:40 --> Language Class Initialized
INFO - 2020-09-06 16:53:40 --> Language Class Initialized
INFO - 2020-09-06 16:53:40 --> Config Class Initialized
INFO - 2020-09-06 16:53:40 --> Loader Class Initialized
INFO - 2020-09-06 16:53:40 --> Helper loaded: url_helper
INFO - 2020-09-06 16:53:40 --> Helper loaded: form_helper
INFO - 2020-09-06 16:53:40 --> Helper loaded: file_helper
INFO - 2020-09-06 16:53:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:53:40 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:53:40 --> Upload Class Initialized
INFO - 2020-09-06 16:53:40 --> Controller Class Initialized
DEBUG - 2020-09-06 16:53:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:53:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 16:53:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 16:53:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:53:40 --> Final output sent to browser
DEBUG - 2020-09-06 16:53:40 --> Total execution time: 0.0558
INFO - 2020-09-06 16:53:49 --> Config Class Initialized
INFO - 2020-09-06 16:53:49 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:53:49 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:53:49 --> Utf8 Class Initialized
INFO - 2020-09-06 16:53:49 --> URI Class Initialized
INFO - 2020-09-06 16:53:49 --> Router Class Initialized
INFO - 2020-09-06 16:53:49 --> Output Class Initialized
INFO - 2020-09-06 16:53:49 --> Security Class Initialized
DEBUG - 2020-09-06 16:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:53:49 --> Input Class Initialized
INFO - 2020-09-06 16:53:49 --> Language Class Initialized
INFO - 2020-09-06 16:53:49 --> Language Class Initialized
INFO - 2020-09-06 16:53:49 --> Config Class Initialized
INFO - 2020-09-06 16:53:49 --> Loader Class Initialized
INFO - 2020-09-06 16:53:49 --> Helper loaded: url_helper
INFO - 2020-09-06 16:53:49 --> Helper loaded: form_helper
INFO - 2020-09-06 16:53:49 --> Helper loaded: file_helper
INFO - 2020-09-06 16:53:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:53:49 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:53:49 --> Upload Class Initialized
INFO - 2020-09-06 16:53:49 --> Controller Class Initialized
ERROR - 2020-09-06 16:53:49 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:54:55 --> Config Class Initialized
INFO - 2020-09-06 16:54:55 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:54:55 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:54:55 --> Utf8 Class Initialized
INFO - 2020-09-06 16:54:55 --> URI Class Initialized
DEBUG - 2020-09-06 16:54:55 --> No URI present. Default controller set.
INFO - 2020-09-06 16:54:55 --> Router Class Initialized
INFO - 2020-09-06 16:54:55 --> Output Class Initialized
INFO - 2020-09-06 16:54:55 --> Security Class Initialized
DEBUG - 2020-09-06 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:54:55 --> Input Class Initialized
INFO - 2020-09-06 16:54:55 --> Language Class Initialized
INFO - 2020-09-06 16:54:55 --> Language Class Initialized
INFO - 2020-09-06 16:54:55 --> Config Class Initialized
INFO - 2020-09-06 16:54:55 --> Loader Class Initialized
INFO - 2020-09-06 16:54:55 --> Helper loaded: url_helper
INFO - 2020-09-06 16:54:55 --> Helper loaded: form_helper
INFO - 2020-09-06 16:54:55 --> Helper loaded: file_helper
INFO - 2020-09-06 16:54:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:54:55 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:54:55 --> Upload Class Initialized
INFO - 2020-09-06 16:54:55 --> Controller Class Initialized
DEBUG - 2020-09-06 16:54:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:54:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 16:54:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 16:54:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:54:55 --> Final output sent to browser
DEBUG - 2020-09-06 16:54:55 --> Total execution time: 0.0577
INFO - 2020-09-06 16:54:56 --> Config Class Initialized
INFO - 2020-09-06 16:54:56 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:54:56 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:54:56 --> Utf8 Class Initialized
INFO - 2020-09-06 16:54:56 --> URI Class Initialized
INFO - 2020-09-06 16:54:56 --> Router Class Initialized
INFO - 2020-09-06 16:54:56 --> Output Class Initialized
INFO - 2020-09-06 16:54:56 --> Security Class Initialized
DEBUG - 2020-09-06 16:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:54:56 --> Input Class Initialized
INFO - 2020-09-06 16:54:56 --> Language Class Initialized
INFO - 2020-09-06 16:54:56 --> Language Class Initialized
INFO - 2020-09-06 16:54:56 --> Config Class Initialized
INFO - 2020-09-06 16:54:56 --> Loader Class Initialized
INFO - 2020-09-06 16:54:56 --> Helper loaded: url_helper
INFO - 2020-09-06 16:54:56 --> Helper loaded: form_helper
INFO - 2020-09-06 16:54:56 --> Helper loaded: file_helper
INFO - 2020-09-06 16:54:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:54:56 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:54:56 --> Upload Class Initialized
INFO - 2020-09-06 16:54:56 --> Controller Class Initialized
ERROR - 2020-09-06 16:54:56 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:55:27 --> Config Class Initialized
INFO - 2020-09-06 16:55:27 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:55:27 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:55:27 --> Utf8 Class Initialized
INFO - 2020-09-06 16:55:27 --> URI Class Initialized
DEBUG - 2020-09-06 16:55:27 --> No URI present. Default controller set.
INFO - 2020-09-06 16:55:27 --> Router Class Initialized
INFO - 2020-09-06 16:55:27 --> Output Class Initialized
INFO - 2020-09-06 16:55:27 --> Security Class Initialized
DEBUG - 2020-09-06 16:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:55:27 --> Input Class Initialized
INFO - 2020-09-06 16:55:27 --> Language Class Initialized
INFO - 2020-09-06 16:55:27 --> Language Class Initialized
INFO - 2020-09-06 16:55:27 --> Config Class Initialized
INFO - 2020-09-06 16:55:27 --> Loader Class Initialized
INFO - 2020-09-06 16:55:27 --> Helper loaded: url_helper
INFO - 2020-09-06 16:55:27 --> Helper loaded: form_helper
INFO - 2020-09-06 16:55:27 --> Helper loaded: file_helper
INFO - 2020-09-06 16:55:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:55:27 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:55:27 --> Upload Class Initialized
INFO - 2020-09-06 16:55:27 --> Controller Class Initialized
DEBUG - 2020-09-06 16:55:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:55:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 16:55:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 16:55:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:55:27 --> Final output sent to browser
DEBUG - 2020-09-06 16:55:27 --> Total execution time: 0.0501
INFO - 2020-09-06 16:56:04 --> Config Class Initialized
INFO - 2020-09-06 16:56:04 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:56:04 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:56:04 --> Utf8 Class Initialized
INFO - 2020-09-06 16:56:04 --> URI Class Initialized
DEBUG - 2020-09-06 16:56:04 --> No URI present. Default controller set.
INFO - 2020-09-06 16:56:04 --> Router Class Initialized
INFO - 2020-09-06 16:56:04 --> Output Class Initialized
INFO - 2020-09-06 16:56:04 --> Security Class Initialized
DEBUG - 2020-09-06 16:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:56:04 --> Input Class Initialized
INFO - 2020-09-06 16:56:04 --> Language Class Initialized
INFO - 2020-09-06 16:56:04 --> Language Class Initialized
INFO - 2020-09-06 16:56:04 --> Config Class Initialized
INFO - 2020-09-06 16:56:04 --> Loader Class Initialized
INFO - 2020-09-06 16:56:04 --> Helper loaded: url_helper
INFO - 2020-09-06 16:56:04 --> Helper loaded: form_helper
INFO - 2020-09-06 16:56:04 --> Helper loaded: file_helper
INFO - 2020-09-06 16:56:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:56:04 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:56:04 --> Upload Class Initialized
INFO - 2020-09-06 16:56:04 --> Controller Class Initialized
DEBUG - 2020-09-06 16:56:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:56:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 16:56:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 16:56:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:56:04 --> Final output sent to browser
DEBUG - 2020-09-06 16:56:04 --> Total execution time: 0.0545
INFO - 2020-09-06 16:56:12 --> Config Class Initialized
INFO - 2020-09-06 16:56:12 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:56:12 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:56:12 --> Utf8 Class Initialized
INFO - 2020-09-06 16:56:12 --> URI Class Initialized
INFO - 2020-09-06 16:56:12 --> Router Class Initialized
INFO - 2020-09-06 16:56:12 --> Output Class Initialized
INFO - 2020-09-06 16:56:12 --> Security Class Initialized
DEBUG - 2020-09-06 16:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:56:12 --> Input Class Initialized
INFO - 2020-09-06 16:56:12 --> Language Class Initialized
INFO - 2020-09-06 16:56:12 --> Language Class Initialized
INFO - 2020-09-06 16:56:12 --> Config Class Initialized
INFO - 2020-09-06 16:56:12 --> Loader Class Initialized
INFO - 2020-09-06 16:56:12 --> Helper loaded: url_helper
INFO - 2020-09-06 16:56:12 --> Helper loaded: form_helper
INFO - 2020-09-06 16:56:12 --> Helper loaded: file_helper
INFO - 2020-09-06 16:56:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:56:12 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:56:12 --> Upload Class Initialized
INFO - 2020-09-06 16:56:12 --> Controller Class Initialized
ERROR - 2020-09-06 16:56:12 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:58:07 --> Config Class Initialized
INFO - 2020-09-06 16:58:07 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:58:07 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:58:07 --> Utf8 Class Initialized
INFO - 2020-09-06 16:58:07 --> URI Class Initialized
DEBUG - 2020-09-06 16:58:07 --> No URI present. Default controller set.
INFO - 2020-09-06 16:58:07 --> Router Class Initialized
INFO - 2020-09-06 16:58:07 --> Output Class Initialized
INFO - 2020-09-06 16:58:07 --> Security Class Initialized
DEBUG - 2020-09-06 16:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:58:07 --> Input Class Initialized
INFO - 2020-09-06 16:58:07 --> Language Class Initialized
INFO - 2020-09-06 16:58:07 --> Language Class Initialized
INFO - 2020-09-06 16:58:07 --> Config Class Initialized
INFO - 2020-09-06 16:58:07 --> Loader Class Initialized
INFO - 2020-09-06 16:58:07 --> Helper loaded: url_helper
INFO - 2020-09-06 16:58:07 --> Helper loaded: form_helper
INFO - 2020-09-06 16:58:07 --> Helper loaded: file_helper
INFO - 2020-09-06 16:58:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:58:07 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:58:07 --> Upload Class Initialized
INFO - 2020-09-06 16:58:07 --> Controller Class Initialized
DEBUG - 2020-09-06 16:58:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:58:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 16:58:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 16:58:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:58:07 --> Final output sent to browser
DEBUG - 2020-09-06 16:58:07 --> Total execution time: 0.0497
INFO - 2020-09-06 16:58:14 --> Config Class Initialized
INFO - 2020-09-06 16:58:14 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:58:14 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:58:14 --> Utf8 Class Initialized
INFO - 2020-09-06 16:58:14 --> URI Class Initialized
INFO - 2020-09-06 16:58:14 --> Router Class Initialized
INFO - 2020-09-06 16:58:14 --> Output Class Initialized
INFO - 2020-09-06 16:58:14 --> Security Class Initialized
DEBUG - 2020-09-06 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:58:14 --> Input Class Initialized
INFO - 2020-09-06 16:58:14 --> Language Class Initialized
INFO - 2020-09-06 16:58:14 --> Language Class Initialized
INFO - 2020-09-06 16:58:14 --> Config Class Initialized
INFO - 2020-09-06 16:58:14 --> Loader Class Initialized
INFO - 2020-09-06 16:58:14 --> Helper loaded: url_helper
INFO - 2020-09-06 16:58:14 --> Helper loaded: form_helper
INFO - 2020-09-06 16:58:14 --> Helper loaded: file_helper
INFO - 2020-09-06 16:58:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:58:14 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:58:14 --> Upload Class Initialized
INFO - 2020-09-06 16:58:14 --> Controller Class Initialized
ERROR - 2020-09-06 16:58:14 --> 404 Page Not Found: /index
INFO - 2020-09-06 16:59:03 --> Config Class Initialized
INFO - 2020-09-06 16:59:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:59:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:59:03 --> Utf8 Class Initialized
INFO - 2020-09-06 16:59:03 --> URI Class Initialized
DEBUG - 2020-09-06 16:59:03 --> No URI present. Default controller set.
INFO - 2020-09-06 16:59:03 --> Router Class Initialized
INFO - 2020-09-06 16:59:03 --> Output Class Initialized
INFO - 2020-09-06 16:59:03 --> Security Class Initialized
DEBUG - 2020-09-06 16:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:59:03 --> Input Class Initialized
INFO - 2020-09-06 16:59:03 --> Language Class Initialized
INFO - 2020-09-06 16:59:03 --> Language Class Initialized
INFO - 2020-09-06 16:59:03 --> Config Class Initialized
INFO - 2020-09-06 16:59:03 --> Loader Class Initialized
INFO - 2020-09-06 16:59:03 --> Helper loaded: url_helper
INFO - 2020-09-06 16:59:03 --> Helper loaded: form_helper
INFO - 2020-09-06 16:59:03 --> Helper loaded: file_helper
INFO - 2020-09-06 16:59:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:59:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:59:03 --> Upload Class Initialized
INFO - 2020-09-06 16:59:03 --> Controller Class Initialized
DEBUG - 2020-09-06 16:59:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 16:59:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 16:59:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 16:59:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 16:59:03 --> Final output sent to browser
DEBUG - 2020-09-06 16:59:03 --> Total execution time: 0.0541
INFO - 2020-09-06 16:59:20 --> Config Class Initialized
INFO - 2020-09-06 16:59:20 --> Hooks Class Initialized
DEBUG - 2020-09-06 16:59:20 --> UTF-8 Support Enabled
INFO - 2020-09-06 16:59:20 --> Utf8 Class Initialized
INFO - 2020-09-06 16:59:20 --> URI Class Initialized
INFO - 2020-09-06 16:59:20 --> Router Class Initialized
INFO - 2020-09-06 16:59:20 --> Output Class Initialized
INFO - 2020-09-06 16:59:20 --> Security Class Initialized
DEBUG - 2020-09-06 16:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 16:59:20 --> Input Class Initialized
INFO - 2020-09-06 16:59:20 --> Language Class Initialized
INFO - 2020-09-06 16:59:20 --> Language Class Initialized
INFO - 2020-09-06 16:59:20 --> Config Class Initialized
INFO - 2020-09-06 16:59:20 --> Loader Class Initialized
INFO - 2020-09-06 16:59:20 --> Helper loaded: url_helper
INFO - 2020-09-06 16:59:20 --> Helper loaded: form_helper
INFO - 2020-09-06 16:59:20 --> Helper loaded: file_helper
INFO - 2020-09-06 16:59:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 16:59:20 --> Database Driver Class Initialized
DEBUG - 2020-09-06 16:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 16:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 16:59:20 --> Upload Class Initialized
INFO - 2020-09-06 16:59:20 --> Controller Class Initialized
ERROR - 2020-09-06 16:59:20 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:05:54 --> Config Class Initialized
INFO - 2020-09-06 17:05:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:05:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:05:54 --> Utf8 Class Initialized
INFO - 2020-09-06 17:05:54 --> URI Class Initialized
DEBUG - 2020-09-06 17:05:54 --> No URI present. Default controller set.
INFO - 2020-09-06 17:05:54 --> Router Class Initialized
INFO - 2020-09-06 17:05:54 --> Output Class Initialized
INFO - 2020-09-06 17:05:54 --> Security Class Initialized
DEBUG - 2020-09-06 17:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:05:54 --> Input Class Initialized
INFO - 2020-09-06 17:05:54 --> Language Class Initialized
INFO - 2020-09-06 17:05:54 --> Language Class Initialized
INFO - 2020-09-06 17:05:54 --> Config Class Initialized
INFO - 2020-09-06 17:05:54 --> Loader Class Initialized
INFO - 2020-09-06 17:05:54 --> Helper loaded: url_helper
INFO - 2020-09-06 17:05:54 --> Helper loaded: form_helper
INFO - 2020-09-06 17:05:54 --> Helper loaded: file_helper
INFO - 2020-09-06 17:05:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:05:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:05:54 --> Upload Class Initialized
INFO - 2020-09-06 17:05:54 --> Controller Class Initialized
DEBUG - 2020-09-06 17:05:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:05:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:05:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:05:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:05:54 --> Final output sent to browser
DEBUG - 2020-09-06 17:05:54 --> Total execution time: 0.0588
INFO - 2020-09-06 17:06:03 --> Config Class Initialized
INFO - 2020-09-06 17:06:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:06:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:06:03 --> Utf8 Class Initialized
INFO - 2020-09-06 17:06:03 --> URI Class Initialized
INFO - 2020-09-06 17:06:03 --> Router Class Initialized
INFO - 2020-09-06 17:06:03 --> Output Class Initialized
INFO - 2020-09-06 17:06:03 --> Security Class Initialized
DEBUG - 2020-09-06 17:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:06:03 --> Input Class Initialized
INFO - 2020-09-06 17:06:03 --> Language Class Initialized
INFO - 2020-09-06 17:06:03 --> Language Class Initialized
INFO - 2020-09-06 17:06:03 --> Config Class Initialized
INFO - 2020-09-06 17:06:03 --> Loader Class Initialized
INFO - 2020-09-06 17:06:03 --> Helper loaded: url_helper
INFO - 2020-09-06 17:06:03 --> Helper loaded: form_helper
INFO - 2020-09-06 17:06:03 --> Helper loaded: file_helper
INFO - 2020-09-06 17:06:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:06:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:06:03 --> Upload Class Initialized
INFO - 2020-09-06 17:06:03 --> Controller Class Initialized
ERROR - 2020-09-06 17:06:03 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:09:39 --> Config Class Initialized
INFO - 2020-09-06 17:09:39 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:09:39 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:09:39 --> Utf8 Class Initialized
INFO - 2020-09-06 17:09:39 --> URI Class Initialized
DEBUG - 2020-09-06 17:09:39 --> No URI present. Default controller set.
INFO - 2020-09-06 17:09:39 --> Router Class Initialized
INFO - 2020-09-06 17:09:39 --> Output Class Initialized
INFO - 2020-09-06 17:09:39 --> Security Class Initialized
DEBUG - 2020-09-06 17:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:09:39 --> Input Class Initialized
INFO - 2020-09-06 17:09:39 --> Language Class Initialized
INFO - 2020-09-06 17:09:39 --> Language Class Initialized
INFO - 2020-09-06 17:09:39 --> Config Class Initialized
INFO - 2020-09-06 17:09:39 --> Loader Class Initialized
INFO - 2020-09-06 17:09:39 --> Helper loaded: url_helper
INFO - 2020-09-06 17:09:39 --> Helper loaded: form_helper
INFO - 2020-09-06 17:09:39 --> Helper loaded: file_helper
INFO - 2020-09-06 17:09:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:09:39 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:09:39 --> Upload Class Initialized
INFO - 2020-09-06 17:09:39 --> Controller Class Initialized
DEBUG - 2020-09-06 17:09:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:09:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:09:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:09:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:09:39 --> Final output sent to browser
DEBUG - 2020-09-06 17:09:39 --> Total execution time: 0.0500
INFO - 2020-09-06 17:10:39 --> Config Class Initialized
INFO - 2020-09-06 17:10:39 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:10:39 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:10:39 --> Utf8 Class Initialized
INFO - 2020-09-06 17:10:39 --> URI Class Initialized
DEBUG - 2020-09-06 17:10:39 --> No URI present. Default controller set.
INFO - 2020-09-06 17:10:39 --> Router Class Initialized
INFO - 2020-09-06 17:10:39 --> Output Class Initialized
INFO - 2020-09-06 17:10:39 --> Security Class Initialized
DEBUG - 2020-09-06 17:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:10:39 --> Input Class Initialized
INFO - 2020-09-06 17:10:39 --> Language Class Initialized
INFO - 2020-09-06 17:10:39 --> Language Class Initialized
INFO - 2020-09-06 17:10:39 --> Config Class Initialized
INFO - 2020-09-06 17:10:39 --> Loader Class Initialized
INFO - 2020-09-06 17:10:39 --> Helper loaded: url_helper
INFO - 2020-09-06 17:10:39 --> Helper loaded: form_helper
INFO - 2020-09-06 17:10:39 --> Helper loaded: file_helper
INFO - 2020-09-06 17:10:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:10:39 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:10:39 --> Upload Class Initialized
INFO - 2020-09-06 17:10:39 --> Controller Class Initialized
DEBUG - 2020-09-06 17:10:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:10:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:10:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:10:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:10:39 --> Final output sent to browser
DEBUG - 2020-09-06 17:10:39 --> Total execution time: 0.0515
INFO - 2020-09-06 17:10:44 --> Config Class Initialized
INFO - 2020-09-06 17:10:44 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:10:44 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:10:44 --> Utf8 Class Initialized
INFO - 2020-09-06 17:10:44 --> URI Class Initialized
INFO - 2020-09-06 17:10:44 --> Router Class Initialized
INFO - 2020-09-06 17:10:44 --> Output Class Initialized
INFO - 2020-09-06 17:10:44 --> Security Class Initialized
DEBUG - 2020-09-06 17:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:10:44 --> Input Class Initialized
INFO - 2020-09-06 17:10:44 --> Language Class Initialized
INFO - 2020-09-06 17:10:44 --> Language Class Initialized
INFO - 2020-09-06 17:10:44 --> Config Class Initialized
INFO - 2020-09-06 17:10:44 --> Loader Class Initialized
INFO - 2020-09-06 17:10:44 --> Helper loaded: url_helper
INFO - 2020-09-06 17:10:44 --> Helper loaded: form_helper
INFO - 2020-09-06 17:10:44 --> Helper loaded: file_helper
INFO - 2020-09-06 17:10:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:10:44 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:10:44 --> Upload Class Initialized
INFO - 2020-09-06 17:10:44 --> Config Class Initialized
INFO - 2020-09-06 17:10:44 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:10:44 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:10:44 --> Utf8 Class Initialized
INFO - 2020-09-06 17:10:44 --> URI Class Initialized
DEBUG - 2020-09-06 17:10:44 --> No URI present. Default controller set.
INFO - 2020-09-06 17:10:44 --> Router Class Initialized
INFO - 2020-09-06 17:10:44 --> Output Class Initialized
INFO - 2020-09-06 17:10:44 --> Security Class Initialized
DEBUG - 2020-09-06 17:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:10:44 --> Input Class Initialized
INFO - 2020-09-06 17:10:44 --> Language Class Initialized
INFO - 2020-09-06 17:10:44 --> Language Class Initialized
INFO - 2020-09-06 17:10:44 --> Config Class Initialized
INFO - 2020-09-06 17:10:44 --> Controller Class Initialized
ERROR - 2020-09-06 17:10:44 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:10:44 --> Loader Class Initialized
INFO - 2020-09-06 17:10:44 --> Helper loaded: url_helper
INFO - 2020-09-06 17:10:44 --> Helper loaded: form_helper
INFO - 2020-09-06 17:10:44 --> Helper loaded: file_helper
INFO - 2020-09-06 17:10:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:10:44 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:10:44 --> Upload Class Initialized
INFO - 2020-09-06 17:10:44 --> Controller Class Initialized
DEBUG - 2020-09-06 17:10:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:10:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:10:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:10:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:10:44 --> Final output sent to browser
DEBUG - 2020-09-06 17:10:44 --> Total execution time: 0.0501
INFO - 2020-09-06 17:10:50 --> Config Class Initialized
INFO - 2020-09-06 17:10:50 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:10:50 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:10:50 --> Utf8 Class Initialized
INFO - 2020-09-06 17:10:50 --> URI Class Initialized
DEBUG - 2020-09-06 17:10:50 --> No URI present. Default controller set.
INFO - 2020-09-06 17:10:50 --> Router Class Initialized
INFO - 2020-09-06 17:10:50 --> Output Class Initialized
INFO - 2020-09-06 17:10:50 --> Security Class Initialized
DEBUG - 2020-09-06 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:10:50 --> Input Class Initialized
INFO - 2020-09-06 17:10:50 --> Language Class Initialized
INFO - 2020-09-06 17:10:50 --> Language Class Initialized
INFO - 2020-09-06 17:10:50 --> Config Class Initialized
INFO - 2020-09-06 17:10:50 --> Loader Class Initialized
INFO - 2020-09-06 17:10:50 --> Helper loaded: url_helper
INFO - 2020-09-06 17:10:50 --> Helper loaded: form_helper
INFO - 2020-09-06 17:10:50 --> Helper loaded: file_helper
INFO - 2020-09-06 17:10:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:10:50 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:10:50 --> Upload Class Initialized
INFO - 2020-09-06 17:10:50 --> Controller Class Initialized
DEBUG - 2020-09-06 17:10:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:10:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:10:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:10:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:10:50 --> Final output sent to browser
DEBUG - 2020-09-06 17:10:50 --> Total execution time: 0.0772
INFO - 2020-09-06 17:10:54 --> Config Class Initialized
INFO - 2020-09-06 17:10:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:10:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:10:54 --> Utf8 Class Initialized
INFO - 2020-09-06 17:10:54 --> URI Class Initialized
INFO - 2020-09-06 17:10:54 --> Router Class Initialized
INFO - 2020-09-06 17:10:54 --> Output Class Initialized
INFO - 2020-09-06 17:10:54 --> Security Class Initialized
DEBUG - 2020-09-06 17:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:10:54 --> Input Class Initialized
INFO - 2020-09-06 17:10:54 --> Language Class Initialized
INFO - 2020-09-06 17:10:54 --> Language Class Initialized
INFO - 2020-09-06 17:10:54 --> Config Class Initialized
INFO - 2020-09-06 17:10:54 --> Loader Class Initialized
INFO - 2020-09-06 17:10:54 --> Helper loaded: url_helper
INFO - 2020-09-06 17:10:54 --> Helper loaded: form_helper
INFO - 2020-09-06 17:10:54 --> Helper loaded: file_helper
INFO - 2020-09-06 17:10:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:10:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:10:54 --> Upload Class Initialized
INFO - 2020-09-06 17:10:54 --> Controller Class Initialized
ERROR - 2020-09-06 17:10:54 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:16:21 --> Config Class Initialized
INFO - 2020-09-06 17:16:21 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:16:21 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:16:21 --> Utf8 Class Initialized
INFO - 2020-09-06 17:16:21 --> URI Class Initialized
DEBUG - 2020-09-06 17:16:21 --> No URI present. Default controller set.
INFO - 2020-09-06 17:16:21 --> Router Class Initialized
INFO - 2020-09-06 17:16:21 --> Output Class Initialized
INFO - 2020-09-06 17:16:21 --> Security Class Initialized
DEBUG - 2020-09-06 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:16:21 --> Input Class Initialized
INFO - 2020-09-06 17:16:21 --> Language Class Initialized
INFO - 2020-09-06 17:16:21 --> Language Class Initialized
INFO - 2020-09-06 17:16:21 --> Config Class Initialized
INFO - 2020-09-06 17:16:21 --> Loader Class Initialized
INFO - 2020-09-06 17:16:21 --> Helper loaded: url_helper
INFO - 2020-09-06 17:16:21 --> Helper loaded: form_helper
INFO - 2020-09-06 17:16:21 --> Helper loaded: file_helper
INFO - 2020-09-06 17:16:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:16:21 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:16:21 --> Upload Class Initialized
INFO - 2020-09-06 17:16:21 --> Controller Class Initialized
DEBUG - 2020-09-06 17:16:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:16:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:16:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:16:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:16:21 --> Final output sent to browser
DEBUG - 2020-09-06 17:16:21 --> Total execution time: 0.0518
INFO - 2020-09-06 17:16:23 --> Config Class Initialized
INFO - 2020-09-06 17:16:23 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:16:23 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:16:23 --> Utf8 Class Initialized
INFO - 2020-09-06 17:16:23 --> URI Class Initialized
INFO - 2020-09-06 17:16:23 --> Router Class Initialized
INFO - 2020-09-06 17:16:23 --> Output Class Initialized
INFO - 2020-09-06 17:16:23 --> Security Class Initialized
DEBUG - 2020-09-06 17:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:16:23 --> Input Class Initialized
INFO - 2020-09-06 17:16:23 --> Language Class Initialized
INFO - 2020-09-06 17:16:23 --> Language Class Initialized
INFO - 2020-09-06 17:16:23 --> Config Class Initialized
INFO - 2020-09-06 17:16:23 --> Loader Class Initialized
INFO - 2020-09-06 17:16:23 --> Helper loaded: url_helper
INFO - 2020-09-06 17:16:23 --> Helper loaded: form_helper
INFO - 2020-09-06 17:16:23 --> Helper loaded: file_helper
INFO - 2020-09-06 17:16:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:16:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:16:23 --> Upload Class Initialized
INFO - 2020-09-06 17:16:23 --> Controller Class Initialized
ERROR - 2020-09-06 17:16:23 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:22:46 --> Config Class Initialized
INFO - 2020-09-06 17:22:46 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:22:46 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:22:46 --> Utf8 Class Initialized
INFO - 2020-09-06 17:22:46 --> URI Class Initialized
INFO - 2020-09-06 17:22:46 --> Router Class Initialized
INFO - 2020-09-06 17:22:46 --> Output Class Initialized
INFO - 2020-09-06 17:22:46 --> Security Class Initialized
DEBUG - 2020-09-06 17:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:22:46 --> Input Class Initialized
INFO - 2020-09-06 17:22:46 --> Language Class Initialized
INFO - 2020-09-06 17:22:46 --> Language Class Initialized
INFO - 2020-09-06 17:22:46 --> Config Class Initialized
INFO - 2020-09-06 17:22:46 --> Loader Class Initialized
INFO - 2020-09-06 17:22:46 --> Helper loaded: url_helper
INFO - 2020-09-06 17:22:46 --> Helper loaded: form_helper
INFO - 2020-09-06 17:22:46 --> Helper loaded: file_helper
INFO - 2020-09-06 17:22:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:22:46 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:22:46 --> Upload Class Initialized
INFO - 2020-09-06 17:22:46 --> Controller Class Initialized
ERROR - 2020-09-06 17:22:46 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:22:46 --> Config Class Initialized
INFO - 2020-09-06 17:22:46 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:22:46 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:22:46 --> Utf8 Class Initialized
INFO - 2020-09-06 17:22:46 --> URI Class Initialized
DEBUG - 2020-09-06 17:22:46 --> No URI present. Default controller set.
INFO - 2020-09-06 17:22:46 --> Router Class Initialized
INFO - 2020-09-06 17:22:46 --> Output Class Initialized
INFO - 2020-09-06 17:22:46 --> Security Class Initialized
DEBUG - 2020-09-06 17:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:22:46 --> Input Class Initialized
INFO - 2020-09-06 17:22:46 --> Language Class Initialized
INFO - 2020-09-06 17:22:46 --> Language Class Initialized
INFO - 2020-09-06 17:22:46 --> Config Class Initialized
INFO - 2020-09-06 17:22:46 --> Loader Class Initialized
INFO - 2020-09-06 17:22:46 --> Helper loaded: url_helper
INFO - 2020-09-06 17:22:46 --> Helper loaded: form_helper
INFO - 2020-09-06 17:22:46 --> Helper loaded: file_helper
INFO - 2020-09-06 17:22:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:22:46 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:22:46 --> Upload Class Initialized
INFO - 2020-09-06 17:22:46 --> Controller Class Initialized
DEBUG - 2020-09-06 17:22:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:22:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:22:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:22:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:22:46 --> Final output sent to browser
DEBUG - 2020-09-06 17:22:46 --> Total execution time: 0.0531
INFO - 2020-09-06 17:31:51 --> Config Class Initialized
INFO - 2020-09-06 17:31:51 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:31:51 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:31:51 --> Utf8 Class Initialized
INFO - 2020-09-06 17:31:51 --> URI Class Initialized
DEBUG - 2020-09-06 17:31:51 --> No URI present. Default controller set.
INFO - 2020-09-06 17:31:51 --> Router Class Initialized
INFO - 2020-09-06 17:31:51 --> Output Class Initialized
INFO - 2020-09-06 17:31:51 --> Security Class Initialized
DEBUG - 2020-09-06 17:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:31:51 --> Input Class Initialized
INFO - 2020-09-06 17:31:51 --> Language Class Initialized
INFO - 2020-09-06 17:31:51 --> Language Class Initialized
INFO - 2020-09-06 17:31:51 --> Config Class Initialized
INFO - 2020-09-06 17:31:51 --> Loader Class Initialized
INFO - 2020-09-06 17:31:51 --> Helper loaded: url_helper
INFO - 2020-09-06 17:31:51 --> Helper loaded: form_helper
INFO - 2020-09-06 17:31:51 --> Helper loaded: file_helper
INFO - 2020-09-06 17:31:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:31:51 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:31:51 --> Upload Class Initialized
INFO - 2020-09-06 17:31:51 --> Controller Class Initialized
DEBUG - 2020-09-06 17:31:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:31:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:31:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:31:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:31:51 --> Final output sent to browser
DEBUG - 2020-09-06 17:31:51 --> Total execution time: 0.0502
INFO - 2020-09-06 17:33:08 --> Config Class Initialized
INFO - 2020-09-06 17:33:08 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:33:08 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:33:08 --> Utf8 Class Initialized
INFO - 2020-09-06 17:33:08 --> URI Class Initialized
INFO - 2020-09-06 17:33:08 --> Router Class Initialized
INFO - 2020-09-06 17:33:08 --> Output Class Initialized
INFO - 2020-09-06 17:33:08 --> Security Class Initialized
DEBUG - 2020-09-06 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:33:08 --> Input Class Initialized
INFO - 2020-09-06 17:33:08 --> Language Class Initialized
INFO - 2020-09-06 17:33:08 --> Language Class Initialized
INFO - 2020-09-06 17:33:08 --> Config Class Initialized
INFO - 2020-09-06 17:33:08 --> Loader Class Initialized
INFO - 2020-09-06 17:33:08 --> Helper loaded: url_helper
INFO - 2020-09-06 17:33:08 --> Helper loaded: form_helper
INFO - 2020-09-06 17:33:08 --> Helper loaded: file_helper
INFO - 2020-09-06 17:33:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:33:08 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:33:08 --> Upload Class Initialized
INFO - 2020-09-06 17:33:08 --> Controller Class Initialized
ERROR - 2020-09-06 17:33:08 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:33:27 --> Config Class Initialized
INFO - 2020-09-06 17:33:27 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:33:27 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:33:27 --> Utf8 Class Initialized
INFO - 2020-09-06 17:33:27 --> URI Class Initialized
DEBUG - 2020-09-06 17:33:27 --> No URI present. Default controller set.
INFO - 2020-09-06 17:33:27 --> Router Class Initialized
INFO - 2020-09-06 17:33:27 --> Output Class Initialized
INFO - 2020-09-06 17:33:27 --> Security Class Initialized
DEBUG - 2020-09-06 17:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:33:27 --> Input Class Initialized
INFO - 2020-09-06 17:33:27 --> Language Class Initialized
INFO - 2020-09-06 17:33:27 --> Language Class Initialized
INFO - 2020-09-06 17:33:27 --> Config Class Initialized
INFO - 2020-09-06 17:33:27 --> Loader Class Initialized
INFO - 2020-09-06 17:33:27 --> Helper loaded: url_helper
INFO - 2020-09-06 17:33:27 --> Helper loaded: form_helper
INFO - 2020-09-06 17:33:27 --> Helper loaded: file_helper
INFO - 2020-09-06 17:33:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:33:27 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:33:27 --> Upload Class Initialized
INFO - 2020-09-06 17:33:27 --> Controller Class Initialized
DEBUG - 2020-09-06 17:33:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:33:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:33:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:33:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:33:27 --> Final output sent to browser
DEBUG - 2020-09-06 17:33:27 --> Total execution time: 0.0486
INFO - 2020-09-06 17:33:45 --> Config Class Initialized
INFO - 2020-09-06 17:33:45 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:33:45 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:33:45 --> Utf8 Class Initialized
INFO - 2020-09-06 17:33:45 --> URI Class Initialized
INFO - 2020-09-06 17:33:45 --> Router Class Initialized
INFO - 2020-09-06 17:33:45 --> Output Class Initialized
INFO - 2020-09-06 17:33:45 --> Security Class Initialized
DEBUG - 2020-09-06 17:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:33:45 --> Input Class Initialized
INFO - 2020-09-06 17:33:45 --> Language Class Initialized
INFO - 2020-09-06 17:33:45 --> Language Class Initialized
INFO - 2020-09-06 17:33:45 --> Config Class Initialized
INFO - 2020-09-06 17:33:45 --> Loader Class Initialized
INFO - 2020-09-06 17:33:45 --> Helper loaded: url_helper
INFO - 2020-09-06 17:33:45 --> Helper loaded: form_helper
INFO - 2020-09-06 17:33:45 --> Helper loaded: file_helper
INFO - 2020-09-06 17:33:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:33:45 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:33:45 --> Upload Class Initialized
INFO - 2020-09-06 17:33:45 --> Controller Class Initialized
ERROR - 2020-09-06 17:33:45 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:36:50 --> Config Class Initialized
INFO - 2020-09-06 17:36:50 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:36:50 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:36:50 --> Utf8 Class Initialized
INFO - 2020-09-06 17:36:50 --> URI Class Initialized
DEBUG - 2020-09-06 17:36:50 --> No URI present. Default controller set.
INFO - 2020-09-06 17:36:50 --> Router Class Initialized
INFO - 2020-09-06 17:36:50 --> Output Class Initialized
INFO - 2020-09-06 17:36:50 --> Security Class Initialized
DEBUG - 2020-09-06 17:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:36:50 --> Input Class Initialized
INFO - 2020-09-06 17:36:50 --> Language Class Initialized
INFO - 2020-09-06 17:36:50 --> Language Class Initialized
INFO - 2020-09-06 17:36:50 --> Config Class Initialized
INFO - 2020-09-06 17:36:50 --> Loader Class Initialized
INFO - 2020-09-06 17:36:50 --> Helper loaded: url_helper
INFO - 2020-09-06 17:36:50 --> Helper loaded: form_helper
INFO - 2020-09-06 17:36:50 --> Helper loaded: file_helper
INFO - 2020-09-06 17:36:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:36:50 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:36:50 --> Upload Class Initialized
INFO - 2020-09-06 17:36:50 --> Controller Class Initialized
DEBUG - 2020-09-06 17:36:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:36:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:36:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:36:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:36:50 --> Final output sent to browser
DEBUG - 2020-09-06 17:36:50 --> Total execution time: 0.0504
INFO - 2020-09-06 17:36:55 --> Config Class Initialized
INFO - 2020-09-06 17:36:55 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:36:55 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:36:55 --> Utf8 Class Initialized
INFO - 2020-09-06 17:36:55 --> URI Class Initialized
INFO - 2020-09-06 17:36:55 --> Router Class Initialized
INFO - 2020-09-06 17:36:55 --> Output Class Initialized
INFO - 2020-09-06 17:36:55 --> Security Class Initialized
DEBUG - 2020-09-06 17:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:36:55 --> Input Class Initialized
INFO - 2020-09-06 17:36:55 --> Language Class Initialized
INFO - 2020-09-06 17:36:55 --> Language Class Initialized
INFO - 2020-09-06 17:36:55 --> Config Class Initialized
INFO - 2020-09-06 17:36:55 --> Loader Class Initialized
INFO - 2020-09-06 17:36:55 --> Helper loaded: url_helper
INFO - 2020-09-06 17:36:55 --> Helper loaded: form_helper
INFO - 2020-09-06 17:36:55 --> Helper loaded: file_helper
INFO - 2020-09-06 17:36:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:36:55 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:36:55 --> Upload Class Initialized
INFO - 2020-09-06 17:36:55 --> Controller Class Initialized
ERROR - 2020-09-06 17:36:55 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:45:18 --> Config Class Initialized
INFO - 2020-09-06 17:45:18 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:18 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:18 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:18 --> URI Class Initialized
DEBUG - 2020-09-06 17:45:18 --> No URI present. Default controller set.
INFO - 2020-09-06 17:45:18 --> Router Class Initialized
INFO - 2020-09-06 17:45:18 --> Output Class Initialized
INFO - 2020-09-06 17:45:18 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:18 --> Input Class Initialized
INFO - 2020-09-06 17:45:18 --> Language Class Initialized
INFO - 2020-09-06 17:45:18 --> Language Class Initialized
INFO - 2020-09-06 17:45:18 --> Config Class Initialized
INFO - 2020-09-06 17:45:18 --> Loader Class Initialized
INFO - 2020-09-06 17:45:18 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:18 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:18 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:18 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:18 --> Upload Class Initialized
INFO - 2020-09-06 17:45:18 --> Controller Class Initialized
DEBUG - 2020-09-06 17:45:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:45:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:45:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:45:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:45:18 --> Final output sent to browser
DEBUG - 2020-09-06 17:45:18 --> Total execution time: 0.0509
INFO - 2020-09-06 17:45:24 --> Config Class Initialized
INFO - 2020-09-06 17:45:24 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:24 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:24 --> URI Class Initialized
INFO - 2020-09-06 17:45:24 --> Router Class Initialized
INFO - 2020-09-06 17:45:24 --> Output Class Initialized
INFO - 2020-09-06 17:45:24 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:24 --> Input Class Initialized
INFO - 2020-09-06 17:45:24 --> Language Class Initialized
INFO - 2020-09-06 17:45:24 --> Language Class Initialized
INFO - 2020-09-06 17:45:24 --> Config Class Initialized
INFO - 2020-09-06 17:45:24 --> Loader Class Initialized
INFO - 2020-09-06 17:45:24 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:24 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:24 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:24 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:24 --> Upload Class Initialized
INFO - 2020-09-06 17:45:24 --> Controller Class Initialized
ERROR - 2020-09-06 17:45:24 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:45:26 --> Config Class Initialized
INFO - 2020-09-06 17:45:26 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:26 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:26 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:26 --> URI Class Initialized
DEBUG - 2020-09-06 17:45:26 --> No URI present. Default controller set.
INFO - 2020-09-06 17:45:26 --> Router Class Initialized
INFO - 2020-09-06 17:45:26 --> Output Class Initialized
INFO - 2020-09-06 17:45:26 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:26 --> Input Class Initialized
INFO - 2020-09-06 17:45:26 --> Language Class Initialized
INFO - 2020-09-06 17:45:26 --> Language Class Initialized
INFO - 2020-09-06 17:45:26 --> Config Class Initialized
INFO - 2020-09-06 17:45:26 --> Loader Class Initialized
INFO - 2020-09-06 17:45:26 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:26 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:26 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:26 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:26 --> Upload Class Initialized
INFO - 2020-09-06 17:45:26 --> Controller Class Initialized
DEBUG - 2020-09-06 17:45:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:45:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:45:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:45:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:45:26 --> Final output sent to browser
DEBUG - 2020-09-06 17:45:26 --> Total execution time: 0.0529
INFO - 2020-09-06 17:45:30 --> Config Class Initialized
INFO - 2020-09-06 17:45:30 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:30 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:30 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:30 --> URI Class Initialized
DEBUG - 2020-09-06 17:45:30 --> No URI present. Default controller set.
INFO - 2020-09-06 17:45:30 --> Router Class Initialized
INFO - 2020-09-06 17:45:30 --> Output Class Initialized
INFO - 2020-09-06 17:45:30 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:30 --> Input Class Initialized
INFO - 2020-09-06 17:45:30 --> Language Class Initialized
INFO - 2020-09-06 17:45:30 --> Language Class Initialized
INFO - 2020-09-06 17:45:30 --> Config Class Initialized
INFO - 2020-09-06 17:45:30 --> Loader Class Initialized
INFO - 2020-09-06 17:45:30 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:30 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:30 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:30 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:30 --> Upload Class Initialized
INFO - 2020-09-06 17:45:30 --> Config Class Initialized
INFO - 2020-09-06 17:45:30 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:30 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:30 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:30 --> URI Class Initialized
INFO - 2020-09-06 17:45:30 --> Controller Class Initialized
DEBUG - 2020-09-06 17:45:30 --> No URI present. Default controller set.
INFO - 2020-09-06 17:45:30 --> Router Class Initialized
DEBUG - 2020-09-06 17:45:30 --> Home MX_Controller Initialized
INFO - 2020-09-06 17:45:30 --> Output Class Initialized
INFO - 2020-09-06 17:45:30 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:30 --> Input Class Initialized
DEBUG - 2020-09-06 17:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:45:30 --> Final output sent to browser
DEBUG - 2020-09-06 17:45:30 --> Total execution time: 0.0496
INFO - 2020-09-06 17:45:30 --> Language Class Initialized
INFO - 2020-09-06 17:45:30 --> Language Class Initialized
INFO - 2020-09-06 17:45:30 --> Config Class Initialized
INFO - 2020-09-06 17:45:30 --> Loader Class Initialized
INFO - 2020-09-06 17:45:30 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:30 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:30 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:30 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:30 --> Upload Class Initialized
INFO - 2020-09-06 17:45:30 --> Controller Class Initialized
DEBUG - 2020-09-06 17:45:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:45:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:45:30 --> Final output sent to browser
DEBUG - 2020-09-06 17:45:30 --> Total execution time: 0.0492
INFO - 2020-09-06 17:45:33 --> Config Class Initialized
INFO - 2020-09-06 17:45:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:33 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:33 --> URI Class Initialized
DEBUG - 2020-09-06 17:45:33 --> No URI present. Default controller set.
INFO - 2020-09-06 17:45:33 --> Router Class Initialized
INFO - 2020-09-06 17:45:33 --> Output Class Initialized
INFO - 2020-09-06 17:45:33 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:33 --> Input Class Initialized
INFO - 2020-09-06 17:45:33 --> Language Class Initialized
INFO - 2020-09-06 17:45:33 --> Language Class Initialized
INFO - 2020-09-06 17:45:33 --> Config Class Initialized
INFO - 2020-09-06 17:45:33 --> Loader Class Initialized
INFO - 2020-09-06 17:45:33 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:33 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:33 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:33 --> Upload Class Initialized
INFO - 2020-09-06 17:45:33 --> Controller Class Initialized
DEBUG - 2020-09-06 17:45:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:45:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:45:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:45:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:45:33 --> Final output sent to browser
DEBUG - 2020-09-06 17:45:33 --> Total execution time: 0.0513
INFO - 2020-09-06 17:45:34 --> Config Class Initialized
INFO - 2020-09-06 17:45:34 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:34 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:34 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:34 --> URI Class Initialized
INFO - 2020-09-06 17:45:34 --> Router Class Initialized
INFO - 2020-09-06 17:45:34 --> Output Class Initialized
INFO - 2020-09-06 17:45:34 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:34 --> Input Class Initialized
INFO - 2020-09-06 17:45:34 --> Language Class Initialized
INFO - 2020-09-06 17:45:34 --> Language Class Initialized
INFO - 2020-09-06 17:45:34 --> Config Class Initialized
INFO - 2020-09-06 17:45:34 --> Loader Class Initialized
INFO - 2020-09-06 17:45:34 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:34 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:34 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:34 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:34 --> Upload Class Initialized
INFO - 2020-09-06 17:45:34 --> Controller Class Initialized
ERROR - 2020-09-06 17:45:34 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:45:34 --> Config Class Initialized
INFO - 2020-09-06 17:45:34 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:34 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:34 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:34 --> URI Class Initialized
DEBUG - 2020-09-06 17:45:34 --> No URI present. Default controller set.
INFO - 2020-09-06 17:45:34 --> Router Class Initialized
INFO - 2020-09-06 17:45:34 --> Output Class Initialized
INFO - 2020-09-06 17:45:34 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:34 --> Input Class Initialized
INFO - 2020-09-06 17:45:34 --> Language Class Initialized
INFO - 2020-09-06 17:45:34 --> Language Class Initialized
INFO - 2020-09-06 17:45:34 --> Config Class Initialized
INFO - 2020-09-06 17:45:34 --> Loader Class Initialized
INFO - 2020-09-06 17:45:34 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:34 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:34 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:34 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:34 --> Upload Class Initialized
INFO - 2020-09-06 17:45:34 --> Controller Class Initialized
DEBUG - 2020-09-06 17:45:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:45:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:45:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:45:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:45:34 --> Final output sent to browser
DEBUG - 2020-09-06 17:45:34 --> Total execution time: 0.0491
INFO - 2020-09-06 17:45:40 --> Config Class Initialized
INFO - 2020-09-06 17:45:40 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:40 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:40 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:40 --> URI Class Initialized
INFO - 2020-09-06 17:45:40 --> Router Class Initialized
INFO - 2020-09-06 17:45:40 --> Output Class Initialized
INFO - 2020-09-06 17:45:40 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:40 --> Input Class Initialized
INFO - 2020-09-06 17:45:40 --> Language Class Initialized
INFO - 2020-09-06 17:45:40 --> Language Class Initialized
INFO - 2020-09-06 17:45:40 --> Config Class Initialized
INFO - 2020-09-06 17:45:40 --> Loader Class Initialized
INFO - 2020-09-06 17:45:40 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:40 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:40 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:40 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:40 --> Upload Class Initialized
INFO - 2020-09-06 17:45:40 --> Controller Class Initialized
ERROR - 2020-09-06 17:45:40 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:45:48 --> Config Class Initialized
INFO - 2020-09-06 17:45:48 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:45:48 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:45:48 --> Utf8 Class Initialized
INFO - 2020-09-06 17:45:48 --> URI Class Initialized
INFO - 2020-09-06 17:45:48 --> Router Class Initialized
INFO - 2020-09-06 17:45:48 --> Output Class Initialized
INFO - 2020-09-06 17:45:48 --> Security Class Initialized
DEBUG - 2020-09-06 17:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:45:48 --> Input Class Initialized
INFO - 2020-09-06 17:45:48 --> Language Class Initialized
INFO - 2020-09-06 17:45:48 --> Language Class Initialized
INFO - 2020-09-06 17:45:48 --> Config Class Initialized
INFO - 2020-09-06 17:45:48 --> Loader Class Initialized
INFO - 2020-09-06 17:45:48 --> Helper loaded: url_helper
INFO - 2020-09-06 17:45:48 --> Helper loaded: form_helper
INFO - 2020-09-06 17:45:48 --> Helper loaded: file_helper
INFO - 2020-09-06 17:45:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:45:48 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:45:48 --> Upload Class Initialized
INFO - 2020-09-06 17:45:48 --> Controller Class Initialized
ERROR - 2020-09-06 17:45:48 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:47:33 --> Config Class Initialized
INFO - 2020-09-06 17:47:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:47:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:47:33 --> Utf8 Class Initialized
INFO - 2020-09-06 17:47:33 --> URI Class Initialized
DEBUG - 2020-09-06 17:47:33 --> No URI present. Default controller set.
INFO - 2020-09-06 17:47:33 --> Router Class Initialized
INFO - 2020-09-06 17:47:33 --> Output Class Initialized
INFO - 2020-09-06 17:47:33 --> Security Class Initialized
DEBUG - 2020-09-06 17:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:47:33 --> Input Class Initialized
INFO - 2020-09-06 17:47:33 --> Language Class Initialized
INFO - 2020-09-06 17:47:33 --> Language Class Initialized
INFO - 2020-09-06 17:47:33 --> Config Class Initialized
INFO - 2020-09-06 17:47:33 --> Loader Class Initialized
INFO - 2020-09-06 17:47:33 --> Helper loaded: url_helper
INFO - 2020-09-06 17:47:33 --> Helper loaded: form_helper
INFO - 2020-09-06 17:47:33 --> Helper loaded: file_helper
INFO - 2020-09-06 17:47:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:47:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:47:33 --> Upload Class Initialized
INFO - 2020-09-06 17:47:33 --> Controller Class Initialized
DEBUG - 2020-09-06 17:47:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:47:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:47:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:47:33 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:47:33 --> Final output sent to browser
DEBUG - 2020-09-06 17:47:33 --> Total execution time: 0.0527
INFO - 2020-09-06 17:48:44 --> Config Class Initialized
INFO - 2020-09-06 17:48:44 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:48:44 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:48:44 --> Utf8 Class Initialized
INFO - 2020-09-06 17:48:44 --> URI Class Initialized
DEBUG - 2020-09-06 17:48:44 --> No URI present. Default controller set.
INFO - 2020-09-06 17:48:44 --> Router Class Initialized
INFO - 2020-09-06 17:48:44 --> Output Class Initialized
INFO - 2020-09-06 17:48:44 --> Security Class Initialized
DEBUG - 2020-09-06 17:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:48:44 --> Input Class Initialized
INFO - 2020-09-06 17:48:44 --> Language Class Initialized
INFO - 2020-09-06 17:48:44 --> Language Class Initialized
INFO - 2020-09-06 17:48:44 --> Config Class Initialized
INFO - 2020-09-06 17:48:44 --> Loader Class Initialized
INFO - 2020-09-06 17:48:44 --> Helper loaded: url_helper
INFO - 2020-09-06 17:48:44 --> Helper loaded: form_helper
INFO - 2020-09-06 17:48:44 --> Helper loaded: file_helper
INFO - 2020-09-06 17:48:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:48:44 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:48:44 --> Upload Class Initialized
INFO - 2020-09-06 17:48:44 --> Controller Class Initialized
DEBUG - 2020-09-06 17:48:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:48:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:48:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:48:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:48:44 --> Final output sent to browser
DEBUG - 2020-09-06 17:48:44 --> Total execution time: 0.0525
INFO - 2020-09-06 17:48:51 --> Config Class Initialized
INFO - 2020-09-06 17:48:51 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:48:51 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:48:51 --> Utf8 Class Initialized
INFO - 2020-09-06 17:48:51 --> URI Class Initialized
INFO - 2020-09-06 17:48:51 --> Router Class Initialized
INFO - 2020-09-06 17:48:51 --> Output Class Initialized
INFO - 2020-09-06 17:48:51 --> Security Class Initialized
DEBUG - 2020-09-06 17:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:48:51 --> Input Class Initialized
INFO - 2020-09-06 17:48:51 --> Language Class Initialized
INFO - 2020-09-06 17:48:51 --> Language Class Initialized
INFO - 2020-09-06 17:48:51 --> Config Class Initialized
INFO - 2020-09-06 17:48:51 --> Loader Class Initialized
INFO - 2020-09-06 17:48:51 --> Helper loaded: url_helper
INFO - 2020-09-06 17:48:51 --> Helper loaded: form_helper
INFO - 2020-09-06 17:48:51 --> Helper loaded: file_helper
INFO - 2020-09-06 17:48:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:48:51 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:48:51 --> Upload Class Initialized
INFO - 2020-09-06 17:48:51 --> Controller Class Initialized
ERROR - 2020-09-06 17:48:51 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:48:53 --> Config Class Initialized
INFO - 2020-09-06 17:48:53 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:48:53 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:48:53 --> Utf8 Class Initialized
INFO - 2020-09-06 17:48:53 --> URI Class Initialized
DEBUG - 2020-09-06 17:48:53 --> No URI present. Default controller set.
INFO - 2020-09-06 17:48:53 --> Router Class Initialized
INFO - 2020-09-06 17:48:53 --> Output Class Initialized
INFO - 2020-09-06 17:48:53 --> Security Class Initialized
DEBUG - 2020-09-06 17:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:48:53 --> Input Class Initialized
INFO - 2020-09-06 17:48:53 --> Language Class Initialized
INFO - 2020-09-06 17:48:53 --> Language Class Initialized
INFO - 2020-09-06 17:48:53 --> Config Class Initialized
INFO - 2020-09-06 17:48:53 --> Loader Class Initialized
INFO - 2020-09-06 17:48:53 --> Helper loaded: url_helper
INFO - 2020-09-06 17:48:53 --> Helper loaded: form_helper
INFO - 2020-09-06 17:48:53 --> Helper loaded: file_helper
INFO - 2020-09-06 17:48:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:48:53 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:48:53 --> Upload Class Initialized
INFO - 2020-09-06 17:48:53 --> Controller Class Initialized
DEBUG - 2020-09-06 17:48:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:48:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:48:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:48:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:48:53 --> Final output sent to browser
DEBUG - 2020-09-06 17:48:53 --> Total execution time: 0.0489
INFO - 2020-09-06 17:48:57 --> Config Class Initialized
INFO - 2020-09-06 17:48:57 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:48:57 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:48:57 --> Utf8 Class Initialized
INFO - 2020-09-06 17:48:57 --> URI Class Initialized
INFO - 2020-09-06 17:48:57 --> Router Class Initialized
INFO - 2020-09-06 17:48:57 --> Output Class Initialized
INFO - 2020-09-06 17:48:57 --> Security Class Initialized
DEBUG - 2020-09-06 17:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:48:57 --> Input Class Initialized
INFO - 2020-09-06 17:48:57 --> Language Class Initialized
INFO - 2020-09-06 17:48:57 --> Language Class Initialized
INFO - 2020-09-06 17:48:57 --> Config Class Initialized
INFO - 2020-09-06 17:48:57 --> Loader Class Initialized
INFO - 2020-09-06 17:48:57 --> Helper loaded: url_helper
INFO - 2020-09-06 17:48:57 --> Helper loaded: form_helper
INFO - 2020-09-06 17:48:57 --> Helper loaded: file_helper
INFO - 2020-09-06 17:48:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:48:57 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:48:57 --> Upload Class Initialized
INFO - 2020-09-06 17:48:57 --> Controller Class Initialized
ERROR - 2020-09-06 17:48:57 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:49:26 --> Config Class Initialized
INFO - 2020-09-06 17:49:26 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:49:26 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:49:26 --> Utf8 Class Initialized
INFO - 2020-09-06 17:49:26 --> URI Class Initialized
DEBUG - 2020-09-06 17:49:26 --> No URI present. Default controller set.
INFO - 2020-09-06 17:49:26 --> Router Class Initialized
INFO - 2020-09-06 17:49:26 --> Output Class Initialized
INFO - 2020-09-06 17:49:26 --> Security Class Initialized
DEBUG - 2020-09-06 17:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:49:26 --> Input Class Initialized
INFO - 2020-09-06 17:49:26 --> Language Class Initialized
INFO - 2020-09-06 17:49:26 --> Language Class Initialized
INFO - 2020-09-06 17:49:26 --> Config Class Initialized
INFO - 2020-09-06 17:49:26 --> Loader Class Initialized
INFO - 2020-09-06 17:49:26 --> Helper loaded: url_helper
INFO - 2020-09-06 17:49:26 --> Helper loaded: form_helper
INFO - 2020-09-06 17:49:26 --> Helper loaded: file_helper
INFO - 2020-09-06 17:49:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:49:26 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:49:26 --> Upload Class Initialized
INFO - 2020-09-06 17:49:26 --> Controller Class Initialized
DEBUG - 2020-09-06 17:49:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:49:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:49:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:49:26 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:49:26 --> Final output sent to browser
DEBUG - 2020-09-06 17:49:26 --> Total execution time: 0.0530
INFO - 2020-09-06 17:49:34 --> Config Class Initialized
INFO - 2020-09-06 17:49:34 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:49:34 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:49:34 --> Utf8 Class Initialized
INFO - 2020-09-06 17:49:34 --> URI Class Initialized
INFO - 2020-09-06 17:49:34 --> Router Class Initialized
INFO - 2020-09-06 17:49:34 --> Output Class Initialized
INFO - 2020-09-06 17:49:34 --> Security Class Initialized
DEBUG - 2020-09-06 17:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:49:34 --> Input Class Initialized
INFO - 2020-09-06 17:49:34 --> Language Class Initialized
INFO - 2020-09-06 17:49:34 --> Language Class Initialized
INFO - 2020-09-06 17:49:34 --> Config Class Initialized
INFO - 2020-09-06 17:49:34 --> Loader Class Initialized
INFO - 2020-09-06 17:49:34 --> Helper loaded: url_helper
INFO - 2020-09-06 17:49:34 --> Helper loaded: form_helper
INFO - 2020-09-06 17:49:34 --> Helper loaded: file_helper
INFO - 2020-09-06 17:49:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:49:34 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:49:34 --> Upload Class Initialized
INFO - 2020-09-06 17:49:34 --> Controller Class Initialized
ERROR - 2020-09-06 17:49:34 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:50:03 --> Config Class Initialized
INFO - 2020-09-06 17:50:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:50:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:50:03 --> Utf8 Class Initialized
INFO - 2020-09-06 17:50:03 --> URI Class Initialized
DEBUG - 2020-09-06 17:50:03 --> No URI present. Default controller set.
INFO - 2020-09-06 17:50:03 --> Router Class Initialized
INFO - 2020-09-06 17:50:03 --> Output Class Initialized
INFO - 2020-09-06 17:50:03 --> Security Class Initialized
DEBUG - 2020-09-06 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:50:03 --> Input Class Initialized
INFO - 2020-09-06 17:50:03 --> Language Class Initialized
INFO - 2020-09-06 17:50:03 --> Language Class Initialized
INFO - 2020-09-06 17:50:03 --> Config Class Initialized
INFO - 2020-09-06 17:50:03 --> Loader Class Initialized
INFO - 2020-09-06 17:50:03 --> Helper loaded: url_helper
INFO - 2020-09-06 17:50:03 --> Helper loaded: form_helper
INFO - 2020-09-06 17:50:03 --> Helper loaded: file_helper
INFO - 2020-09-06 17:50:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:50:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:50:03 --> Upload Class Initialized
INFO - 2020-09-06 17:50:03 --> Controller Class Initialized
DEBUG - 2020-09-06 17:50:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:50:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:50:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:50:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:50:03 --> Final output sent to browser
DEBUG - 2020-09-06 17:50:03 --> Total execution time: 0.2921
INFO - 2020-09-06 17:50:10 --> Config Class Initialized
INFO - 2020-09-06 17:50:10 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:50:10 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:50:10 --> Utf8 Class Initialized
INFO - 2020-09-06 17:50:10 --> URI Class Initialized
INFO - 2020-09-06 17:50:10 --> Router Class Initialized
INFO - 2020-09-06 17:50:10 --> Output Class Initialized
INFO - 2020-09-06 17:50:10 --> Security Class Initialized
DEBUG - 2020-09-06 17:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:50:10 --> Input Class Initialized
INFO - 2020-09-06 17:50:10 --> Language Class Initialized
INFO - 2020-09-06 17:50:10 --> Language Class Initialized
INFO - 2020-09-06 17:50:10 --> Config Class Initialized
INFO - 2020-09-06 17:50:10 --> Loader Class Initialized
INFO - 2020-09-06 17:50:10 --> Helper loaded: url_helper
INFO - 2020-09-06 17:50:10 --> Helper loaded: form_helper
INFO - 2020-09-06 17:50:10 --> Helper loaded: file_helper
INFO - 2020-09-06 17:50:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:50:10 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:50:10 --> Upload Class Initialized
INFO - 2020-09-06 17:50:10 --> Controller Class Initialized
ERROR - 2020-09-06 17:50:10 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:50:41 --> Config Class Initialized
INFO - 2020-09-06 17:50:41 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:50:41 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:50:41 --> Utf8 Class Initialized
INFO - 2020-09-06 17:50:41 --> URI Class Initialized
DEBUG - 2020-09-06 17:50:41 --> No URI present. Default controller set.
INFO - 2020-09-06 17:50:41 --> Router Class Initialized
INFO - 2020-09-06 17:50:41 --> Output Class Initialized
INFO - 2020-09-06 17:50:41 --> Security Class Initialized
DEBUG - 2020-09-06 17:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:50:41 --> Input Class Initialized
INFO - 2020-09-06 17:50:41 --> Language Class Initialized
INFO - 2020-09-06 17:50:41 --> Language Class Initialized
INFO - 2020-09-06 17:50:41 --> Config Class Initialized
INFO - 2020-09-06 17:50:41 --> Loader Class Initialized
INFO - 2020-09-06 17:50:41 --> Helper loaded: url_helper
INFO - 2020-09-06 17:50:41 --> Helper loaded: form_helper
INFO - 2020-09-06 17:50:41 --> Helper loaded: file_helper
INFO - 2020-09-06 17:50:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:50:41 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:50:41 --> Upload Class Initialized
INFO - 2020-09-06 17:50:41 --> Controller Class Initialized
DEBUG - 2020-09-06 17:50:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:50:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:50:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:50:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:50:41 --> Final output sent to browser
DEBUG - 2020-09-06 17:50:41 --> Total execution time: 0.0575
INFO - 2020-09-06 17:55:03 --> Config Class Initialized
INFO - 2020-09-06 17:55:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:55:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:55:03 --> Utf8 Class Initialized
INFO - 2020-09-06 17:55:03 --> URI Class Initialized
DEBUG - 2020-09-06 17:55:03 --> No URI present. Default controller set.
INFO - 2020-09-06 17:55:03 --> Router Class Initialized
INFO - 2020-09-06 17:55:03 --> Output Class Initialized
INFO - 2020-09-06 17:55:03 --> Security Class Initialized
DEBUG - 2020-09-06 17:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:55:03 --> Input Class Initialized
INFO - 2020-09-06 17:55:03 --> Language Class Initialized
INFO - 2020-09-06 17:55:03 --> Language Class Initialized
INFO - 2020-09-06 17:55:03 --> Config Class Initialized
INFO - 2020-09-06 17:55:03 --> Loader Class Initialized
INFO - 2020-09-06 17:55:03 --> Helper loaded: url_helper
INFO - 2020-09-06 17:55:03 --> Helper loaded: form_helper
INFO - 2020-09-06 17:55:03 --> Helper loaded: file_helper
INFO - 2020-09-06 17:55:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:55:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:55:03 --> Upload Class Initialized
INFO - 2020-09-06 17:55:03 --> Controller Class Initialized
DEBUG - 2020-09-06 17:55:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:55:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:55:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:55:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:55:03 --> Final output sent to browser
DEBUG - 2020-09-06 17:55:03 --> Total execution time: 0.2043
INFO - 2020-09-06 17:56:25 --> Config Class Initialized
INFO - 2020-09-06 17:56:25 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:56:25 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:56:25 --> Utf8 Class Initialized
INFO - 2020-09-06 17:56:25 --> URI Class Initialized
DEBUG - 2020-09-06 17:56:25 --> No URI present. Default controller set.
INFO - 2020-09-06 17:56:25 --> Router Class Initialized
INFO - 2020-09-06 17:56:25 --> Output Class Initialized
INFO - 2020-09-06 17:56:25 --> Security Class Initialized
DEBUG - 2020-09-06 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:56:25 --> Input Class Initialized
INFO - 2020-09-06 17:56:25 --> Language Class Initialized
INFO - 2020-09-06 17:56:25 --> Language Class Initialized
INFO - 2020-09-06 17:56:25 --> Config Class Initialized
INFO - 2020-09-06 17:56:25 --> Loader Class Initialized
INFO - 2020-09-06 17:56:25 --> Helper loaded: url_helper
INFO - 2020-09-06 17:56:25 --> Helper loaded: form_helper
INFO - 2020-09-06 17:56:25 --> Helper loaded: file_helper
INFO - 2020-09-06 17:56:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:56:25 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:56:25 --> Upload Class Initialized
INFO - 2020-09-06 17:56:25 --> Controller Class Initialized
DEBUG - 2020-09-06 17:56:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:56:25 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:56:25 --> Final output sent to browser
DEBUG - 2020-09-06 17:56:25 --> Total execution time: 0.0509
INFO - 2020-09-06 17:56:35 --> Config Class Initialized
INFO - 2020-09-06 17:56:35 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:56:35 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:56:35 --> Utf8 Class Initialized
INFO - 2020-09-06 17:56:35 --> URI Class Initialized
INFO - 2020-09-06 17:56:35 --> Router Class Initialized
INFO - 2020-09-06 17:56:35 --> Output Class Initialized
INFO - 2020-09-06 17:56:35 --> Security Class Initialized
DEBUG - 2020-09-06 17:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:56:35 --> Input Class Initialized
INFO - 2020-09-06 17:56:35 --> Language Class Initialized
INFO - 2020-09-06 17:56:35 --> Language Class Initialized
INFO - 2020-09-06 17:56:35 --> Config Class Initialized
INFO - 2020-09-06 17:56:35 --> Loader Class Initialized
INFO - 2020-09-06 17:56:35 --> Helper loaded: url_helper
INFO - 2020-09-06 17:56:35 --> Helper loaded: form_helper
INFO - 2020-09-06 17:56:35 --> Helper loaded: file_helper
INFO - 2020-09-06 17:56:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:56:35 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:56:35 --> Upload Class Initialized
INFO - 2020-09-06 17:56:35 --> Controller Class Initialized
ERROR - 2020-09-06 17:56:35 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:56:35 --> Config Class Initialized
INFO - 2020-09-06 17:56:35 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:56:35 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:56:35 --> Utf8 Class Initialized
INFO - 2020-09-06 17:56:35 --> URI Class Initialized
DEBUG - 2020-09-06 17:56:35 --> No URI present. Default controller set.
INFO - 2020-09-06 17:56:35 --> Router Class Initialized
INFO - 2020-09-06 17:56:35 --> Output Class Initialized
INFO - 2020-09-06 17:56:35 --> Security Class Initialized
DEBUG - 2020-09-06 17:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:56:35 --> Input Class Initialized
INFO - 2020-09-06 17:56:35 --> Language Class Initialized
INFO - 2020-09-06 17:56:35 --> Language Class Initialized
INFO - 2020-09-06 17:56:35 --> Config Class Initialized
INFO - 2020-09-06 17:56:35 --> Loader Class Initialized
INFO - 2020-09-06 17:56:35 --> Helper loaded: url_helper
INFO - 2020-09-06 17:56:35 --> Helper loaded: form_helper
INFO - 2020-09-06 17:56:35 --> Helper loaded: file_helper
INFO - 2020-09-06 17:56:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:56:35 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:56:35 --> Upload Class Initialized
INFO - 2020-09-06 17:56:35 --> Controller Class Initialized
DEBUG - 2020-09-06 17:56:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:56:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:56:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:56:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:56:35 --> Final output sent to browser
DEBUG - 2020-09-06 17:56:35 --> Total execution time: 0.0658
INFO - 2020-09-06 17:56:41 --> Config Class Initialized
INFO - 2020-09-06 17:56:41 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:56:41 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:56:41 --> Utf8 Class Initialized
INFO - 2020-09-06 17:56:41 --> URI Class Initialized
INFO - 2020-09-06 17:56:41 --> Router Class Initialized
INFO - 2020-09-06 17:56:41 --> Output Class Initialized
INFO - 2020-09-06 17:56:41 --> Security Class Initialized
DEBUG - 2020-09-06 17:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:56:41 --> Input Class Initialized
INFO - 2020-09-06 17:56:41 --> Language Class Initialized
INFO - 2020-09-06 17:56:41 --> Language Class Initialized
INFO - 2020-09-06 17:56:41 --> Config Class Initialized
INFO - 2020-09-06 17:56:41 --> Loader Class Initialized
INFO - 2020-09-06 17:56:41 --> Helper loaded: url_helper
INFO - 2020-09-06 17:56:41 --> Helper loaded: form_helper
INFO - 2020-09-06 17:56:41 --> Helper loaded: file_helper
INFO - 2020-09-06 17:56:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:56:41 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:56:41 --> Upload Class Initialized
INFO - 2020-09-06 17:56:41 --> Controller Class Initialized
ERROR - 2020-09-06 17:56:41 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:56:47 --> Config Class Initialized
INFO - 2020-09-06 17:56:47 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:56:47 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:56:47 --> Utf8 Class Initialized
INFO - 2020-09-06 17:56:47 --> URI Class Initialized
DEBUG - 2020-09-06 17:56:47 --> No URI present. Default controller set.
INFO - 2020-09-06 17:56:47 --> Router Class Initialized
INFO - 2020-09-06 17:56:47 --> Output Class Initialized
INFO - 2020-09-06 17:56:47 --> Security Class Initialized
DEBUG - 2020-09-06 17:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:56:47 --> Input Class Initialized
INFO - 2020-09-06 17:56:47 --> Language Class Initialized
INFO - 2020-09-06 17:56:47 --> Language Class Initialized
INFO - 2020-09-06 17:56:47 --> Config Class Initialized
INFO - 2020-09-06 17:56:47 --> Loader Class Initialized
INFO - 2020-09-06 17:56:47 --> Helper loaded: url_helper
INFO - 2020-09-06 17:56:47 --> Helper loaded: form_helper
INFO - 2020-09-06 17:56:47 --> Helper loaded: file_helper
INFO - 2020-09-06 17:56:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:56:47 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:56:47 --> Upload Class Initialized
INFO - 2020-09-06 17:56:48 --> Controller Class Initialized
DEBUG - 2020-09-06 17:56:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:56:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:56:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:56:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:56:48 --> Final output sent to browser
DEBUG - 2020-09-06 17:56:48 --> Total execution time: 0.0500
INFO - 2020-09-06 17:57:00 --> Config Class Initialized
INFO - 2020-09-06 17:57:00 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:57:00 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:57:00 --> Utf8 Class Initialized
INFO - 2020-09-06 17:57:00 --> URI Class Initialized
DEBUG - 2020-09-06 17:57:00 --> No URI present. Default controller set.
INFO - 2020-09-06 17:57:00 --> Router Class Initialized
INFO - 2020-09-06 17:57:00 --> Output Class Initialized
INFO - 2020-09-06 17:57:00 --> Security Class Initialized
DEBUG - 2020-09-06 17:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:57:00 --> Input Class Initialized
INFO - 2020-09-06 17:57:00 --> Language Class Initialized
INFO - 2020-09-06 17:57:00 --> Language Class Initialized
INFO - 2020-09-06 17:57:00 --> Config Class Initialized
INFO - 2020-09-06 17:57:00 --> Loader Class Initialized
INFO - 2020-09-06 17:57:00 --> Helper loaded: url_helper
INFO - 2020-09-06 17:57:00 --> Helper loaded: form_helper
INFO - 2020-09-06 17:57:00 --> Helper loaded: file_helper
INFO - 2020-09-06 17:57:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:57:00 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:57:00 --> Upload Class Initialized
INFO - 2020-09-06 17:57:00 --> Controller Class Initialized
DEBUG - 2020-09-06 17:57:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:57:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:57:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:57:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:57:00 --> Final output sent to browser
DEBUG - 2020-09-06 17:57:00 --> Total execution time: 0.0489
INFO - 2020-09-06 17:57:02 --> Config Class Initialized
INFO - 2020-09-06 17:57:02 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:57:02 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:57:02 --> Utf8 Class Initialized
INFO - 2020-09-06 17:57:02 --> URI Class Initialized
INFO - 2020-09-06 17:57:02 --> Router Class Initialized
INFO - 2020-09-06 17:57:02 --> Output Class Initialized
INFO - 2020-09-06 17:57:02 --> Security Class Initialized
DEBUG - 2020-09-06 17:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:57:02 --> Input Class Initialized
INFO - 2020-09-06 17:57:02 --> Language Class Initialized
INFO - 2020-09-06 17:57:02 --> Language Class Initialized
INFO - 2020-09-06 17:57:02 --> Config Class Initialized
INFO - 2020-09-06 17:57:02 --> Loader Class Initialized
INFO - 2020-09-06 17:57:02 --> Helper loaded: url_helper
INFO - 2020-09-06 17:57:02 --> Helper loaded: form_helper
INFO - 2020-09-06 17:57:02 --> Helper loaded: file_helper
INFO - 2020-09-06 17:57:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:57:02 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:57:02 --> Upload Class Initialized
INFO - 2020-09-06 17:57:02 --> Controller Class Initialized
ERROR - 2020-09-06 17:57:02 --> 404 Page Not Found: /index
INFO - 2020-09-06 17:57:46 --> Config Class Initialized
INFO - 2020-09-06 17:57:46 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:57:46 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:57:46 --> Utf8 Class Initialized
INFO - 2020-09-06 17:57:46 --> URI Class Initialized
DEBUG - 2020-09-06 17:57:46 --> No URI present. Default controller set.
INFO - 2020-09-06 17:57:46 --> Router Class Initialized
INFO - 2020-09-06 17:57:46 --> Output Class Initialized
INFO - 2020-09-06 17:57:46 --> Security Class Initialized
DEBUG - 2020-09-06 17:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:57:46 --> Input Class Initialized
INFO - 2020-09-06 17:57:46 --> Language Class Initialized
INFO - 2020-09-06 17:57:46 --> Language Class Initialized
INFO - 2020-09-06 17:57:46 --> Config Class Initialized
INFO - 2020-09-06 17:57:46 --> Loader Class Initialized
INFO - 2020-09-06 17:57:46 --> Helper loaded: url_helper
INFO - 2020-09-06 17:57:46 --> Helper loaded: form_helper
INFO - 2020-09-06 17:57:46 --> Helper loaded: file_helper
INFO - 2020-09-06 17:57:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:57:46 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:57:46 --> Upload Class Initialized
INFO - 2020-09-06 17:57:46 --> Controller Class Initialized
DEBUG - 2020-09-06 17:57:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 17:57:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 17:57:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 17:57:46 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 17:57:46 --> Final output sent to browser
DEBUG - 2020-09-06 17:57:46 --> Total execution time: 0.0620
INFO - 2020-09-06 17:57:54 --> Config Class Initialized
INFO - 2020-09-06 17:57:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 17:57:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 17:57:54 --> Utf8 Class Initialized
INFO - 2020-09-06 17:57:54 --> URI Class Initialized
INFO - 2020-09-06 17:57:54 --> Router Class Initialized
INFO - 2020-09-06 17:57:54 --> Output Class Initialized
INFO - 2020-09-06 17:57:54 --> Security Class Initialized
DEBUG - 2020-09-06 17:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 17:57:54 --> Input Class Initialized
INFO - 2020-09-06 17:57:54 --> Language Class Initialized
INFO - 2020-09-06 17:57:54 --> Language Class Initialized
INFO - 2020-09-06 17:57:54 --> Config Class Initialized
INFO - 2020-09-06 17:57:54 --> Loader Class Initialized
INFO - 2020-09-06 17:57:54 --> Helper loaded: url_helper
INFO - 2020-09-06 17:57:54 --> Helper loaded: form_helper
INFO - 2020-09-06 17:57:54 --> Helper loaded: file_helper
INFO - 2020-09-06 17:57:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 17:57:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 17:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 17:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 17:57:54 --> Upload Class Initialized
INFO - 2020-09-06 17:57:54 --> Controller Class Initialized
ERROR - 2020-09-06 17:57:54 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:02:55 --> Config Class Initialized
INFO - 2020-09-06 18:02:55 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:02:55 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:02:55 --> Utf8 Class Initialized
INFO - 2020-09-06 18:02:55 --> URI Class Initialized
DEBUG - 2020-09-06 18:02:55 --> No URI present. Default controller set.
INFO - 2020-09-06 18:02:55 --> Router Class Initialized
INFO - 2020-09-06 18:02:55 --> Output Class Initialized
INFO - 2020-09-06 18:02:55 --> Security Class Initialized
DEBUG - 2020-09-06 18:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:02:55 --> Input Class Initialized
INFO - 2020-09-06 18:02:55 --> Language Class Initialized
INFO - 2020-09-06 18:02:55 --> Language Class Initialized
INFO - 2020-09-06 18:02:55 --> Config Class Initialized
INFO - 2020-09-06 18:02:55 --> Loader Class Initialized
INFO - 2020-09-06 18:02:55 --> Helper loaded: url_helper
INFO - 2020-09-06 18:02:55 --> Helper loaded: form_helper
INFO - 2020-09-06 18:02:55 --> Helper loaded: file_helper
INFO - 2020-09-06 18:02:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:02:55 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:02:55 --> Upload Class Initialized
INFO - 2020-09-06 18:02:55 --> Controller Class Initialized
DEBUG - 2020-09-06 18:02:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:02:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:02:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:02:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:02:55 --> Final output sent to browser
DEBUG - 2020-09-06 18:02:55 --> Total execution time: 0.0512
INFO - 2020-09-06 18:03:07 --> Config Class Initialized
INFO - 2020-09-06 18:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:03:07 --> Utf8 Class Initialized
INFO - 2020-09-06 18:03:07 --> URI Class Initialized
DEBUG - 2020-09-06 18:03:07 --> No URI present. Default controller set.
INFO - 2020-09-06 18:03:07 --> Router Class Initialized
INFO - 2020-09-06 18:03:07 --> Output Class Initialized
INFO - 2020-09-06 18:03:07 --> Security Class Initialized
DEBUG - 2020-09-06 18:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:03:07 --> Input Class Initialized
INFO - 2020-09-06 18:03:07 --> Language Class Initialized
INFO - 2020-09-06 18:03:07 --> Language Class Initialized
INFO - 2020-09-06 18:03:07 --> Config Class Initialized
INFO - 2020-09-06 18:03:07 --> Loader Class Initialized
INFO - 2020-09-06 18:03:07 --> Helper loaded: url_helper
INFO - 2020-09-06 18:03:07 --> Helper loaded: form_helper
INFO - 2020-09-06 18:03:07 --> Helper loaded: file_helper
INFO - 2020-09-06 18:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:03:07 --> Upload Class Initialized
INFO - 2020-09-06 18:03:07 --> Controller Class Initialized
DEBUG - 2020-09-06 18:03:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:03:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:03:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:03:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:03:07 --> Final output sent to browser
DEBUG - 2020-09-06 18:03:07 --> Total execution time: 0.0501
INFO - 2020-09-06 18:03:14 --> Config Class Initialized
INFO - 2020-09-06 18:03:14 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:03:14 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:03:14 --> Utf8 Class Initialized
INFO - 2020-09-06 18:03:14 --> URI Class Initialized
INFO - 2020-09-06 18:03:14 --> Router Class Initialized
INFO - 2020-09-06 18:03:14 --> Output Class Initialized
INFO - 2020-09-06 18:03:14 --> Security Class Initialized
DEBUG - 2020-09-06 18:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:03:14 --> Input Class Initialized
INFO - 2020-09-06 18:03:14 --> Language Class Initialized
INFO - 2020-09-06 18:03:14 --> Language Class Initialized
INFO - 2020-09-06 18:03:14 --> Config Class Initialized
INFO - 2020-09-06 18:03:14 --> Loader Class Initialized
INFO - 2020-09-06 18:03:14 --> Helper loaded: url_helper
INFO - 2020-09-06 18:03:14 --> Helper loaded: form_helper
INFO - 2020-09-06 18:03:14 --> Helper loaded: file_helper
INFO - 2020-09-06 18:03:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:03:14 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:03:14 --> Upload Class Initialized
INFO - 2020-09-06 18:03:14 --> Controller Class Initialized
ERROR - 2020-09-06 18:03:14 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:04:43 --> Config Class Initialized
INFO - 2020-09-06 18:04:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:04:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:04:43 --> Utf8 Class Initialized
INFO - 2020-09-06 18:04:43 --> URI Class Initialized
DEBUG - 2020-09-06 18:04:43 --> No URI present. Default controller set.
INFO - 2020-09-06 18:04:43 --> Router Class Initialized
INFO - 2020-09-06 18:04:43 --> Output Class Initialized
INFO - 2020-09-06 18:04:43 --> Security Class Initialized
DEBUG - 2020-09-06 18:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:04:43 --> Input Class Initialized
INFO - 2020-09-06 18:04:43 --> Language Class Initialized
INFO - 2020-09-06 18:04:43 --> Language Class Initialized
INFO - 2020-09-06 18:04:43 --> Config Class Initialized
INFO - 2020-09-06 18:04:43 --> Loader Class Initialized
INFO - 2020-09-06 18:04:43 --> Helper loaded: url_helper
INFO - 2020-09-06 18:04:43 --> Helper loaded: form_helper
INFO - 2020-09-06 18:04:43 --> Helper loaded: file_helper
INFO - 2020-09-06 18:04:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:04:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:04:43 --> Upload Class Initialized
INFO - 2020-09-06 18:04:43 --> Controller Class Initialized
DEBUG - 2020-09-06 18:04:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:04:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:04:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:04:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:04:43 --> Final output sent to browser
DEBUG - 2020-09-06 18:04:43 --> Total execution time: 0.0484
INFO - 2020-09-06 18:06:10 --> Config Class Initialized
INFO - 2020-09-06 18:06:10 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:06:10 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:06:10 --> Utf8 Class Initialized
INFO - 2020-09-06 18:06:10 --> URI Class Initialized
DEBUG - 2020-09-06 18:06:10 --> No URI present. Default controller set.
INFO - 2020-09-06 18:06:10 --> Router Class Initialized
INFO - 2020-09-06 18:06:10 --> Output Class Initialized
INFO - 2020-09-06 18:06:10 --> Security Class Initialized
DEBUG - 2020-09-06 18:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:06:10 --> Input Class Initialized
INFO - 2020-09-06 18:06:10 --> Language Class Initialized
INFO - 2020-09-06 18:06:10 --> Language Class Initialized
INFO - 2020-09-06 18:06:10 --> Config Class Initialized
INFO - 2020-09-06 18:06:10 --> Loader Class Initialized
INFO - 2020-09-06 18:06:10 --> Helper loaded: url_helper
INFO - 2020-09-06 18:06:10 --> Helper loaded: form_helper
INFO - 2020-09-06 18:06:10 --> Helper loaded: file_helper
INFO - 2020-09-06 18:06:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:06:10 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:06:10 --> Upload Class Initialized
INFO - 2020-09-06 18:06:10 --> Controller Class Initialized
DEBUG - 2020-09-06 18:06:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:06:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:06:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:06:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:06:10 --> Final output sent to browser
DEBUG - 2020-09-06 18:06:10 --> Total execution time: 0.0516
INFO - 2020-09-06 18:07:01 --> Config Class Initialized
INFO - 2020-09-06 18:07:01 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:07:01 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:07:01 --> Utf8 Class Initialized
INFO - 2020-09-06 18:07:01 --> URI Class Initialized
DEBUG - 2020-09-06 18:07:01 --> No URI present. Default controller set.
INFO - 2020-09-06 18:07:01 --> Router Class Initialized
INFO - 2020-09-06 18:07:01 --> Output Class Initialized
INFO - 2020-09-06 18:07:01 --> Security Class Initialized
DEBUG - 2020-09-06 18:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:07:01 --> Input Class Initialized
INFO - 2020-09-06 18:07:01 --> Language Class Initialized
INFO - 2020-09-06 18:07:01 --> Language Class Initialized
INFO - 2020-09-06 18:07:01 --> Config Class Initialized
INFO - 2020-09-06 18:07:01 --> Loader Class Initialized
INFO - 2020-09-06 18:07:01 --> Helper loaded: url_helper
INFO - 2020-09-06 18:07:01 --> Helper loaded: form_helper
INFO - 2020-09-06 18:07:01 --> Helper loaded: file_helper
INFO - 2020-09-06 18:07:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:07:01 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:07:01 --> Upload Class Initialized
INFO - 2020-09-06 18:07:01 --> Controller Class Initialized
DEBUG - 2020-09-06 18:07:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:07:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:07:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:07:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:07:01 --> Final output sent to browser
DEBUG - 2020-09-06 18:07:01 --> Total execution time: 0.0589
INFO - 2020-09-06 18:08:30 --> Config Class Initialized
INFO - 2020-09-06 18:08:30 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:08:30 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:08:30 --> Utf8 Class Initialized
INFO - 2020-09-06 18:08:30 --> URI Class Initialized
DEBUG - 2020-09-06 18:08:30 --> No URI present. Default controller set.
INFO - 2020-09-06 18:08:30 --> Router Class Initialized
INFO - 2020-09-06 18:08:30 --> Output Class Initialized
INFO - 2020-09-06 18:08:30 --> Security Class Initialized
DEBUG - 2020-09-06 18:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:08:30 --> Input Class Initialized
INFO - 2020-09-06 18:08:30 --> Language Class Initialized
INFO - 2020-09-06 18:08:30 --> Language Class Initialized
INFO - 2020-09-06 18:08:30 --> Config Class Initialized
INFO - 2020-09-06 18:08:30 --> Loader Class Initialized
INFO - 2020-09-06 18:08:30 --> Helper loaded: url_helper
INFO - 2020-09-06 18:08:30 --> Helper loaded: form_helper
INFO - 2020-09-06 18:08:30 --> Helper loaded: file_helper
INFO - 2020-09-06 18:08:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:08:30 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:08:30 --> Upload Class Initialized
INFO - 2020-09-06 18:08:30 --> Controller Class Initialized
DEBUG - 2020-09-06 18:08:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:08:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:08:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:08:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:08:30 --> Final output sent to browser
DEBUG - 2020-09-06 18:08:30 --> Total execution time: 0.0497
INFO - 2020-09-06 18:08:37 --> Config Class Initialized
INFO - 2020-09-06 18:08:37 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:08:37 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:08:37 --> Utf8 Class Initialized
INFO - 2020-09-06 18:08:37 --> URI Class Initialized
INFO - 2020-09-06 18:08:37 --> Router Class Initialized
INFO - 2020-09-06 18:08:37 --> Output Class Initialized
INFO - 2020-09-06 18:08:37 --> Security Class Initialized
DEBUG - 2020-09-06 18:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:08:37 --> Input Class Initialized
INFO - 2020-09-06 18:08:37 --> Language Class Initialized
INFO - 2020-09-06 18:08:37 --> Language Class Initialized
INFO - 2020-09-06 18:08:37 --> Config Class Initialized
INFO - 2020-09-06 18:08:37 --> Loader Class Initialized
INFO - 2020-09-06 18:08:37 --> Helper loaded: url_helper
INFO - 2020-09-06 18:08:37 --> Helper loaded: form_helper
INFO - 2020-09-06 18:08:37 --> Helper loaded: file_helper
INFO - 2020-09-06 18:08:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:08:37 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:08:37 --> Upload Class Initialized
INFO - 2020-09-06 18:08:37 --> Controller Class Initialized
ERROR - 2020-09-06 18:08:37 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:10:38 --> Config Class Initialized
INFO - 2020-09-06 18:10:38 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:10:38 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:10:38 --> Utf8 Class Initialized
INFO - 2020-09-06 18:10:38 --> URI Class Initialized
DEBUG - 2020-09-06 18:10:38 --> No URI present. Default controller set.
INFO - 2020-09-06 18:10:38 --> Router Class Initialized
INFO - 2020-09-06 18:10:38 --> Output Class Initialized
INFO - 2020-09-06 18:10:38 --> Security Class Initialized
DEBUG - 2020-09-06 18:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:10:38 --> Input Class Initialized
INFO - 2020-09-06 18:10:38 --> Language Class Initialized
INFO - 2020-09-06 18:10:38 --> Language Class Initialized
INFO - 2020-09-06 18:10:38 --> Config Class Initialized
INFO - 2020-09-06 18:10:38 --> Loader Class Initialized
INFO - 2020-09-06 18:10:38 --> Helper loaded: url_helper
INFO - 2020-09-06 18:10:38 --> Helper loaded: form_helper
INFO - 2020-09-06 18:10:38 --> Helper loaded: file_helper
INFO - 2020-09-06 18:10:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:10:38 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:10:38 --> Upload Class Initialized
INFO - 2020-09-06 18:10:38 --> Controller Class Initialized
DEBUG - 2020-09-06 18:10:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:10:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:10:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:10:38 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:10:38 --> Final output sent to browser
DEBUG - 2020-09-06 18:10:38 --> Total execution time: 0.0541
INFO - 2020-09-06 18:10:43 --> Config Class Initialized
INFO - 2020-09-06 18:10:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:10:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:10:43 --> Utf8 Class Initialized
INFO - 2020-09-06 18:10:43 --> URI Class Initialized
INFO - 2020-09-06 18:10:43 --> Router Class Initialized
INFO - 2020-09-06 18:10:43 --> Output Class Initialized
INFO - 2020-09-06 18:10:43 --> Security Class Initialized
DEBUG - 2020-09-06 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:10:43 --> Input Class Initialized
INFO - 2020-09-06 18:10:43 --> Language Class Initialized
INFO - 2020-09-06 18:10:43 --> Language Class Initialized
INFO - 2020-09-06 18:10:43 --> Config Class Initialized
INFO - 2020-09-06 18:10:43 --> Loader Class Initialized
INFO - 2020-09-06 18:10:43 --> Helper loaded: url_helper
INFO - 2020-09-06 18:10:43 --> Helper loaded: form_helper
INFO - 2020-09-06 18:10:43 --> Helper loaded: file_helper
INFO - 2020-09-06 18:10:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:10:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:10:43 --> Upload Class Initialized
INFO - 2020-09-06 18:10:43 --> Controller Class Initialized
ERROR - 2020-09-06 18:10:43 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:15:09 --> Config Class Initialized
INFO - 2020-09-06 18:15:09 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:15:09 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:15:09 --> Utf8 Class Initialized
INFO - 2020-09-06 18:15:09 --> URI Class Initialized
DEBUG - 2020-09-06 18:15:09 --> No URI present. Default controller set.
INFO - 2020-09-06 18:15:09 --> Router Class Initialized
INFO - 2020-09-06 18:15:09 --> Output Class Initialized
INFO - 2020-09-06 18:15:09 --> Security Class Initialized
DEBUG - 2020-09-06 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:15:09 --> Input Class Initialized
INFO - 2020-09-06 18:15:09 --> Language Class Initialized
INFO - 2020-09-06 18:15:09 --> Language Class Initialized
INFO - 2020-09-06 18:15:09 --> Config Class Initialized
INFO - 2020-09-06 18:15:09 --> Loader Class Initialized
INFO - 2020-09-06 18:15:09 --> Helper loaded: url_helper
INFO - 2020-09-06 18:15:09 --> Helper loaded: form_helper
INFO - 2020-09-06 18:15:09 --> Helper loaded: file_helper
INFO - 2020-09-06 18:15:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:15:09 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:15:09 --> Upload Class Initialized
INFO - 2020-09-06 18:15:09 --> Controller Class Initialized
DEBUG - 2020-09-06 18:15:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:15:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:15:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:15:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:15:09 --> Final output sent to browser
DEBUG - 2020-09-06 18:15:09 --> Total execution time: 0.0495
INFO - 2020-09-06 18:15:14 --> Config Class Initialized
INFO - 2020-09-06 18:15:14 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:15:14 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:15:14 --> Utf8 Class Initialized
INFO - 2020-09-06 18:15:14 --> URI Class Initialized
INFO - 2020-09-06 18:15:14 --> Router Class Initialized
INFO - 2020-09-06 18:15:14 --> Output Class Initialized
INFO - 2020-09-06 18:15:14 --> Security Class Initialized
DEBUG - 2020-09-06 18:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:15:14 --> Input Class Initialized
INFO - 2020-09-06 18:15:14 --> Language Class Initialized
INFO - 2020-09-06 18:15:14 --> Language Class Initialized
INFO - 2020-09-06 18:15:14 --> Config Class Initialized
INFO - 2020-09-06 18:15:14 --> Loader Class Initialized
INFO - 2020-09-06 18:15:14 --> Helper loaded: url_helper
INFO - 2020-09-06 18:15:14 --> Helper loaded: form_helper
INFO - 2020-09-06 18:15:14 --> Helper loaded: file_helper
INFO - 2020-09-06 18:15:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:15:14 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:15:14 --> Upload Class Initialized
INFO - 2020-09-06 18:15:14 --> Controller Class Initialized
ERROR - 2020-09-06 18:15:14 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:19:26 --> Config Class Initialized
INFO - 2020-09-06 18:19:26 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:19:26 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:19:26 --> Utf8 Class Initialized
INFO - 2020-09-06 18:19:26 --> URI Class Initialized
DEBUG - 2020-09-06 18:19:26 --> No URI present. Default controller set.
INFO - 2020-09-06 18:19:26 --> Router Class Initialized
INFO - 2020-09-06 18:19:26 --> Output Class Initialized
INFO - 2020-09-06 18:19:26 --> Security Class Initialized
DEBUG - 2020-09-06 18:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:19:26 --> Input Class Initialized
INFO - 2020-09-06 18:19:26 --> Language Class Initialized
INFO - 2020-09-06 18:19:26 --> Language Class Initialized
INFO - 2020-09-06 18:19:26 --> Config Class Initialized
INFO - 2020-09-06 18:19:26 --> Loader Class Initialized
INFO - 2020-09-06 18:19:26 --> Helper loaded: url_helper
INFO - 2020-09-06 18:19:26 --> Helper loaded: form_helper
INFO - 2020-09-06 18:19:26 --> Helper loaded: file_helper
INFO - 2020-09-06 18:19:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:19:26 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:19:26 --> Upload Class Initialized
INFO - 2020-09-06 18:19:27 --> Controller Class Initialized
DEBUG - 2020-09-06 18:19:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:19:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:19:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:19:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:19:27 --> Final output sent to browser
DEBUG - 2020-09-06 18:19:27 --> Total execution time: 0.0500
INFO - 2020-09-06 18:19:33 --> Config Class Initialized
INFO - 2020-09-06 18:19:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:19:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:19:33 --> Utf8 Class Initialized
INFO - 2020-09-06 18:19:33 --> URI Class Initialized
INFO - 2020-09-06 18:19:33 --> Router Class Initialized
INFO - 2020-09-06 18:19:33 --> Output Class Initialized
INFO - 2020-09-06 18:19:33 --> Security Class Initialized
DEBUG - 2020-09-06 18:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:19:33 --> Input Class Initialized
INFO - 2020-09-06 18:19:33 --> Language Class Initialized
INFO - 2020-09-06 18:19:33 --> Language Class Initialized
INFO - 2020-09-06 18:19:33 --> Config Class Initialized
INFO - 2020-09-06 18:19:33 --> Loader Class Initialized
INFO - 2020-09-06 18:19:33 --> Helper loaded: url_helper
INFO - 2020-09-06 18:19:33 --> Helper loaded: form_helper
INFO - 2020-09-06 18:19:33 --> Helper loaded: file_helper
INFO - 2020-09-06 18:19:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:19:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:19:33 --> Upload Class Initialized
INFO - 2020-09-06 18:19:33 --> Controller Class Initialized
ERROR - 2020-09-06 18:19:33 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:21:44 --> Config Class Initialized
INFO - 2020-09-06 18:21:44 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:21:44 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:21:44 --> Utf8 Class Initialized
INFO - 2020-09-06 18:21:44 --> URI Class Initialized
DEBUG - 2020-09-06 18:21:44 --> No URI present. Default controller set.
INFO - 2020-09-06 18:21:44 --> Router Class Initialized
INFO - 2020-09-06 18:21:44 --> Output Class Initialized
INFO - 2020-09-06 18:21:44 --> Security Class Initialized
DEBUG - 2020-09-06 18:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:21:44 --> Input Class Initialized
INFO - 2020-09-06 18:21:44 --> Language Class Initialized
INFO - 2020-09-06 18:21:44 --> Language Class Initialized
INFO - 2020-09-06 18:21:44 --> Config Class Initialized
INFO - 2020-09-06 18:21:44 --> Loader Class Initialized
INFO - 2020-09-06 18:21:44 --> Helper loaded: url_helper
INFO - 2020-09-06 18:21:44 --> Helper loaded: form_helper
INFO - 2020-09-06 18:21:44 --> Helper loaded: file_helper
INFO - 2020-09-06 18:21:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:21:44 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:21:44 --> Upload Class Initialized
INFO - 2020-09-06 18:21:44 --> Controller Class Initialized
DEBUG - 2020-09-06 18:21:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:21:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:21:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:21:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:21:44 --> Final output sent to browser
DEBUG - 2020-09-06 18:21:44 --> Total execution time: 0.0492
INFO - 2020-09-06 18:24:02 --> Config Class Initialized
INFO - 2020-09-06 18:24:02 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:24:02 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:24:02 --> Utf8 Class Initialized
INFO - 2020-09-06 18:24:02 --> URI Class Initialized
DEBUG - 2020-09-06 18:24:02 --> No URI present. Default controller set.
INFO - 2020-09-06 18:24:02 --> Router Class Initialized
INFO - 2020-09-06 18:24:02 --> Output Class Initialized
INFO - 2020-09-06 18:24:02 --> Security Class Initialized
DEBUG - 2020-09-06 18:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:24:02 --> Input Class Initialized
INFO - 2020-09-06 18:24:02 --> Language Class Initialized
INFO - 2020-09-06 18:24:02 --> Language Class Initialized
INFO - 2020-09-06 18:24:02 --> Config Class Initialized
INFO - 2020-09-06 18:24:02 --> Loader Class Initialized
INFO - 2020-09-06 18:24:02 --> Helper loaded: url_helper
INFO - 2020-09-06 18:24:02 --> Helper loaded: form_helper
INFO - 2020-09-06 18:24:02 --> Helper loaded: file_helper
INFO - 2020-09-06 18:24:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:24:02 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:24:02 --> Upload Class Initialized
INFO - 2020-09-06 18:24:02 --> Controller Class Initialized
DEBUG - 2020-09-06 18:24:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:24:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:24:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:24:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:24:02 --> Final output sent to browser
DEBUG - 2020-09-06 18:24:02 --> Total execution time: 0.1633
INFO - 2020-09-06 18:24:07 --> Config Class Initialized
INFO - 2020-09-06 18:24:07 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:24:07 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:24:07 --> Utf8 Class Initialized
INFO - 2020-09-06 18:24:07 --> URI Class Initialized
INFO - 2020-09-06 18:24:07 --> Router Class Initialized
INFO - 2020-09-06 18:24:07 --> Output Class Initialized
INFO - 2020-09-06 18:24:07 --> Security Class Initialized
DEBUG - 2020-09-06 18:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:24:07 --> Input Class Initialized
INFO - 2020-09-06 18:24:07 --> Language Class Initialized
INFO - 2020-09-06 18:24:07 --> Language Class Initialized
INFO - 2020-09-06 18:24:07 --> Config Class Initialized
INFO - 2020-09-06 18:24:07 --> Loader Class Initialized
INFO - 2020-09-06 18:24:07 --> Helper loaded: url_helper
INFO - 2020-09-06 18:24:07 --> Helper loaded: form_helper
INFO - 2020-09-06 18:24:07 --> Helper loaded: file_helper
INFO - 2020-09-06 18:24:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:24:07 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:24:07 --> Upload Class Initialized
INFO - 2020-09-06 18:24:07 --> Controller Class Initialized
ERROR - 2020-09-06 18:24:07 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:44:56 --> Config Class Initialized
INFO - 2020-09-06 18:44:56 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:44:56 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:44:56 --> Utf8 Class Initialized
INFO - 2020-09-06 18:44:56 --> URI Class Initialized
INFO - 2020-09-06 18:44:56 --> Router Class Initialized
INFO - 2020-09-06 18:44:56 --> Output Class Initialized
INFO - 2020-09-06 18:44:56 --> Security Class Initialized
DEBUG - 2020-09-06 18:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:44:56 --> Input Class Initialized
INFO - 2020-09-06 18:44:56 --> Language Class Initialized
INFO - 2020-09-06 18:44:56 --> Language Class Initialized
INFO - 2020-09-06 18:44:56 --> Config Class Initialized
INFO - 2020-09-06 18:44:56 --> Loader Class Initialized
INFO - 2020-09-06 18:44:56 --> Helper loaded: url_helper
INFO - 2020-09-06 18:44:56 --> Helper loaded: form_helper
INFO - 2020-09-06 18:44:56 --> Helper loaded: file_helper
INFO - 2020-09-06 18:44:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:44:56 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:44:56 --> Upload Class Initialized
INFO - 2020-09-06 18:44:56 --> Controller Class Initialized
DEBUG - 2020-09-06 18:44:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-06 18:44:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:44:56 --> Final output sent to browser
DEBUG - 2020-09-06 18:44:56 --> Total execution time: 0.0532
INFO - 2020-09-06 18:45:12 --> Config Class Initialized
INFO - 2020-09-06 18:45:12 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:45:12 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:45:12 --> Utf8 Class Initialized
INFO - 2020-09-06 18:45:12 --> URI Class Initialized
INFO - 2020-09-06 18:45:12 --> Router Class Initialized
INFO - 2020-09-06 18:45:12 --> Output Class Initialized
INFO - 2020-09-06 18:45:12 --> Security Class Initialized
DEBUG - 2020-09-06 18:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:45:12 --> Input Class Initialized
INFO - 2020-09-06 18:45:12 --> Language Class Initialized
INFO - 2020-09-06 18:45:12 --> Language Class Initialized
INFO - 2020-09-06 18:45:12 --> Config Class Initialized
INFO - 2020-09-06 18:45:12 --> Loader Class Initialized
INFO - 2020-09-06 18:45:12 --> Helper loaded: url_helper
INFO - 2020-09-06 18:45:12 --> Helper loaded: form_helper
INFO - 2020-09-06 18:45:12 --> Helper loaded: file_helper
INFO - 2020-09-06 18:45:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:45:12 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:45:12 --> Upload Class Initialized
INFO - 2020-09-06 18:45:12 --> Controller Class Initialized
ERROR - 2020-09-06 18:45:12 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:45:21 --> Config Class Initialized
INFO - 2020-09-06 18:45:21 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:45:21 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:45:21 --> Utf8 Class Initialized
INFO - 2020-09-06 18:45:21 --> URI Class Initialized
INFO - 2020-09-06 18:45:21 --> Router Class Initialized
INFO - 2020-09-06 18:45:21 --> Output Class Initialized
INFO - 2020-09-06 18:45:21 --> Security Class Initialized
DEBUG - 2020-09-06 18:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:45:21 --> Input Class Initialized
INFO - 2020-09-06 18:45:21 --> Language Class Initialized
INFO - 2020-09-06 18:45:21 --> Language Class Initialized
INFO - 2020-09-06 18:45:21 --> Config Class Initialized
INFO - 2020-09-06 18:45:21 --> Loader Class Initialized
INFO - 2020-09-06 18:45:21 --> Helper loaded: url_helper
INFO - 2020-09-06 18:45:21 --> Helper loaded: form_helper
INFO - 2020-09-06 18:45:21 --> Helper loaded: file_helper
INFO - 2020-09-06 18:45:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:45:21 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:45:21 --> Upload Class Initialized
INFO - 2020-09-06 18:45:21 --> Controller Class Initialized
DEBUG - 2020-09-06 18:45:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:45:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-06 18:45:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:45:21 --> Final output sent to browser
DEBUG - 2020-09-06 18:45:21 --> Total execution time: 0.0504
INFO - 2020-09-06 18:45:23 --> Config Class Initialized
INFO - 2020-09-06 18:45:23 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:45:23 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:45:23 --> Utf8 Class Initialized
INFO - 2020-09-06 18:45:23 --> URI Class Initialized
INFO - 2020-09-06 18:45:23 --> Router Class Initialized
INFO - 2020-09-06 18:45:23 --> Output Class Initialized
INFO - 2020-09-06 18:45:23 --> Security Class Initialized
DEBUG - 2020-09-06 18:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:45:23 --> Input Class Initialized
INFO - 2020-09-06 18:45:23 --> Language Class Initialized
INFO - 2020-09-06 18:45:23 --> Language Class Initialized
INFO - 2020-09-06 18:45:23 --> Config Class Initialized
INFO - 2020-09-06 18:45:23 --> Loader Class Initialized
INFO - 2020-09-06 18:45:23 --> Helper loaded: url_helper
INFO - 2020-09-06 18:45:23 --> Helper loaded: form_helper
INFO - 2020-09-06 18:45:23 --> Helper loaded: file_helper
INFO - 2020-09-06 18:45:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:45:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:45:23 --> Upload Class Initialized
INFO - 2020-09-06 18:45:23 --> Controller Class Initialized
ERROR - 2020-09-06 18:45:23 --> 404 Page Not Found: /index
INFO - 2020-09-06 18:58:55 --> Config Class Initialized
INFO - 2020-09-06 18:58:55 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:58:55 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:58:55 --> Utf8 Class Initialized
INFO - 2020-09-06 18:58:55 --> URI Class Initialized
DEBUG - 2020-09-06 18:58:55 --> No URI present. Default controller set.
INFO - 2020-09-06 18:58:55 --> Router Class Initialized
INFO - 2020-09-06 18:58:55 --> Output Class Initialized
INFO - 2020-09-06 18:58:55 --> Security Class Initialized
DEBUG - 2020-09-06 18:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:58:55 --> Input Class Initialized
INFO - 2020-09-06 18:58:55 --> Language Class Initialized
INFO - 2020-09-06 18:58:55 --> Language Class Initialized
INFO - 2020-09-06 18:58:55 --> Config Class Initialized
INFO - 2020-09-06 18:58:55 --> Loader Class Initialized
INFO - 2020-09-06 18:58:55 --> Helper loaded: url_helper
INFO - 2020-09-06 18:58:55 --> Helper loaded: form_helper
INFO - 2020-09-06 18:58:55 --> Helper loaded: file_helper
INFO - 2020-09-06 18:58:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:58:55 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:58:55 --> Upload Class Initialized
INFO - 2020-09-06 18:58:55 --> Controller Class Initialized
DEBUG - 2020-09-06 18:58:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 18:58:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 18:58:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 18:58:55 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 18:58:55 --> Final output sent to browser
DEBUG - 2020-09-06 18:58:55 --> Total execution time: 0.0497
INFO - 2020-09-06 18:58:58 --> Config Class Initialized
INFO - 2020-09-06 18:58:58 --> Hooks Class Initialized
DEBUG - 2020-09-06 18:58:58 --> UTF-8 Support Enabled
INFO - 2020-09-06 18:58:58 --> Utf8 Class Initialized
INFO - 2020-09-06 18:58:58 --> URI Class Initialized
INFO - 2020-09-06 18:58:58 --> Router Class Initialized
INFO - 2020-09-06 18:58:58 --> Output Class Initialized
INFO - 2020-09-06 18:58:58 --> Security Class Initialized
DEBUG - 2020-09-06 18:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 18:58:58 --> Input Class Initialized
INFO - 2020-09-06 18:58:58 --> Language Class Initialized
INFO - 2020-09-06 18:58:58 --> Language Class Initialized
INFO - 2020-09-06 18:58:58 --> Config Class Initialized
INFO - 2020-09-06 18:58:58 --> Loader Class Initialized
INFO - 2020-09-06 18:58:58 --> Helper loaded: url_helper
INFO - 2020-09-06 18:58:58 --> Helper loaded: form_helper
INFO - 2020-09-06 18:58:58 --> Helper loaded: file_helper
INFO - 2020-09-06 18:58:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 18:58:58 --> Database Driver Class Initialized
DEBUG - 2020-09-06 18:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 18:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 18:58:58 --> Upload Class Initialized
INFO - 2020-09-06 18:58:58 --> Controller Class Initialized
ERROR - 2020-09-06 18:58:58 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:00:28 --> Config Class Initialized
INFO - 2020-09-06 19:00:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:00:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:00:28 --> Utf8 Class Initialized
INFO - 2020-09-06 19:00:28 --> URI Class Initialized
DEBUG - 2020-09-06 19:00:28 --> No URI present. Default controller set.
INFO - 2020-09-06 19:00:28 --> Router Class Initialized
INFO - 2020-09-06 19:00:28 --> Output Class Initialized
INFO - 2020-09-06 19:00:28 --> Security Class Initialized
DEBUG - 2020-09-06 19:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:00:28 --> Input Class Initialized
INFO - 2020-09-06 19:00:28 --> Language Class Initialized
INFO - 2020-09-06 19:00:28 --> Language Class Initialized
INFO - 2020-09-06 19:00:28 --> Config Class Initialized
INFO - 2020-09-06 19:00:28 --> Loader Class Initialized
INFO - 2020-09-06 19:00:28 --> Helper loaded: url_helper
INFO - 2020-09-06 19:00:28 --> Helper loaded: form_helper
INFO - 2020-09-06 19:00:28 --> Helper loaded: file_helper
INFO - 2020-09-06 19:00:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:00:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:00:28 --> Upload Class Initialized
INFO - 2020-09-06 19:00:28 --> Controller Class Initialized
DEBUG - 2020-09-06 19:00:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:00:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 19:00:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 19:00:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:00:28 --> Final output sent to browser
DEBUG - 2020-09-06 19:00:28 --> Total execution time: 0.0494
INFO - 2020-09-06 19:00:35 --> Config Class Initialized
INFO - 2020-09-06 19:00:35 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:00:35 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:00:35 --> Utf8 Class Initialized
INFO - 2020-09-06 19:00:35 --> URI Class Initialized
INFO - 2020-09-06 19:00:35 --> Router Class Initialized
INFO - 2020-09-06 19:00:35 --> Output Class Initialized
INFO - 2020-09-06 19:00:35 --> Security Class Initialized
DEBUG - 2020-09-06 19:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:00:35 --> Input Class Initialized
INFO - 2020-09-06 19:00:35 --> Language Class Initialized
INFO - 2020-09-06 19:00:35 --> Language Class Initialized
INFO - 2020-09-06 19:00:35 --> Config Class Initialized
INFO - 2020-09-06 19:00:35 --> Loader Class Initialized
INFO - 2020-09-06 19:00:35 --> Helper loaded: url_helper
INFO - 2020-09-06 19:00:35 --> Helper loaded: form_helper
INFO - 2020-09-06 19:00:35 --> Helper loaded: file_helper
INFO - 2020-09-06 19:00:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:00:35 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:00:35 --> Upload Class Initialized
INFO - 2020-09-06 19:00:35 --> Controller Class Initialized
ERROR - 2020-09-06 19:00:35 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:03:18 --> Config Class Initialized
INFO - 2020-09-06 19:03:18 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:03:18 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:03:18 --> Utf8 Class Initialized
INFO - 2020-09-06 19:03:18 --> URI Class Initialized
INFO - 2020-09-06 19:03:18 --> Router Class Initialized
INFO - 2020-09-06 19:03:18 --> Output Class Initialized
INFO - 2020-09-06 19:03:18 --> Security Class Initialized
DEBUG - 2020-09-06 19:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:03:18 --> Input Class Initialized
INFO - 2020-09-06 19:03:18 --> Language Class Initialized
INFO - 2020-09-06 19:03:18 --> Language Class Initialized
INFO - 2020-09-06 19:03:18 --> Config Class Initialized
INFO - 2020-09-06 19:03:18 --> Loader Class Initialized
INFO - 2020-09-06 19:03:18 --> Helper loaded: url_helper
INFO - 2020-09-06 19:03:18 --> Helper loaded: form_helper
INFO - 2020-09-06 19:03:18 --> Helper loaded: file_helper
INFO - 2020-09-06 19:03:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:03:18 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:03:18 --> Upload Class Initialized
INFO - 2020-09-06 19:03:18 --> Controller Class Initialized
DEBUG - 2020-09-06 19:03:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:03:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:03:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:03:18 --> Final output sent to browser
DEBUG - 2020-09-06 19:03:18 --> Total execution time: 0.0689
INFO - 2020-09-06 19:03:23 --> Config Class Initialized
INFO - 2020-09-06 19:03:23 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:03:23 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:03:23 --> Utf8 Class Initialized
INFO - 2020-09-06 19:03:23 --> URI Class Initialized
INFO - 2020-09-06 19:03:23 --> Router Class Initialized
INFO - 2020-09-06 19:03:23 --> Output Class Initialized
INFO - 2020-09-06 19:03:23 --> Security Class Initialized
DEBUG - 2020-09-06 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:03:23 --> Input Class Initialized
INFO - 2020-09-06 19:03:23 --> Language Class Initialized
INFO - 2020-09-06 19:03:23 --> Language Class Initialized
INFO - 2020-09-06 19:03:23 --> Config Class Initialized
INFO - 2020-09-06 19:03:23 --> Loader Class Initialized
INFO - 2020-09-06 19:03:23 --> Helper loaded: url_helper
INFO - 2020-09-06 19:03:23 --> Helper loaded: form_helper
INFO - 2020-09-06 19:03:23 --> Helper loaded: file_helper
INFO - 2020-09-06 19:03:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:03:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:03:23 --> Upload Class Initialized
INFO - 2020-09-06 19:03:23 --> Controller Class Initialized
ERROR - 2020-09-06 19:03:23 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:04:50 --> Config Class Initialized
INFO - 2020-09-06 19:04:50 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:04:50 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:04:50 --> Utf8 Class Initialized
INFO - 2020-09-06 19:04:50 --> URI Class Initialized
INFO - 2020-09-06 19:04:50 --> Router Class Initialized
INFO - 2020-09-06 19:04:50 --> Output Class Initialized
INFO - 2020-09-06 19:04:50 --> Security Class Initialized
DEBUG - 2020-09-06 19:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:04:50 --> Input Class Initialized
INFO - 2020-09-06 19:04:50 --> Language Class Initialized
INFO - 2020-09-06 19:04:50 --> Language Class Initialized
INFO - 2020-09-06 19:04:50 --> Config Class Initialized
INFO - 2020-09-06 19:04:50 --> Loader Class Initialized
INFO - 2020-09-06 19:04:50 --> Helper loaded: url_helper
INFO - 2020-09-06 19:04:50 --> Helper loaded: form_helper
INFO - 2020-09-06 19:04:50 --> Helper loaded: file_helper
INFO - 2020-09-06 19:04:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:04:50 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:04:50 --> Upload Class Initialized
INFO - 2020-09-06 19:04:50 --> Controller Class Initialized
DEBUG - 2020-09-06 19:04:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:04:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:04:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:04:50 --> Final output sent to browser
DEBUG - 2020-09-06 19:04:50 --> Total execution time: 0.0522
INFO - 2020-09-06 19:04:52 --> Config Class Initialized
INFO - 2020-09-06 19:04:52 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:04:52 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:04:52 --> Utf8 Class Initialized
INFO - 2020-09-06 19:04:52 --> URI Class Initialized
INFO - 2020-09-06 19:04:52 --> Router Class Initialized
INFO - 2020-09-06 19:04:52 --> Output Class Initialized
INFO - 2020-09-06 19:04:52 --> Security Class Initialized
DEBUG - 2020-09-06 19:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:04:52 --> Input Class Initialized
INFO - 2020-09-06 19:04:52 --> Language Class Initialized
INFO - 2020-09-06 19:04:52 --> Language Class Initialized
INFO - 2020-09-06 19:04:52 --> Config Class Initialized
INFO - 2020-09-06 19:04:52 --> Loader Class Initialized
INFO - 2020-09-06 19:04:52 --> Helper loaded: url_helper
INFO - 2020-09-06 19:04:52 --> Helper loaded: form_helper
INFO - 2020-09-06 19:04:52 --> Helper loaded: file_helper
INFO - 2020-09-06 19:04:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:04:52 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:04:52 --> Upload Class Initialized
INFO - 2020-09-06 19:04:52 --> Controller Class Initialized
ERROR - 2020-09-06 19:04:52 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:05:29 --> Config Class Initialized
INFO - 2020-09-06 19:05:29 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:05:29 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:05:29 --> Utf8 Class Initialized
INFO - 2020-09-06 19:05:29 --> URI Class Initialized
INFO - 2020-09-06 19:05:29 --> Router Class Initialized
INFO - 2020-09-06 19:05:29 --> Output Class Initialized
INFO - 2020-09-06 19:05:29 --> Security Class Initialized
DEBUG - 2020-09-06 19:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:05:29 --> Input Class Initialized
INFO - 2020-09-06 19:05:29 --> Language Class Initialized
INFO - 2020-09-06 19:05:29 --> Language Class Initialized
INFO - 2020-09-06 19:05:29 --> Config Class Initialized
INFO - 2020-09-06 19:05:29 --> Loader Class Initialized
INFO - 2020-09-06 19:05:29 --> Helper loaded: url_helper
INFO - 2020-09-06 19:05:29 --> Helper loaded: form_helper
INFO - 2020-09-06 19:05:29 --> Helper loaded: file_helper
INFO - 2020-09-06 19:05:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:05:29 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:05:29 --> Upload Class Initialized
INFO - 2020-09-06 19:05:29 --> Controller Class Initialized
DEBUG - 2020-09-06 19:05:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:05:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:05:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:05:29 --> Final output sent to browser
DEBUG - 2020-09-06 19:05:29 --> Total execution time: 0.0490
INFO - 2020-09-06 19:05:30 --> Config Class Initialized
INFO - 2020-09-06 19:05:30 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:05:30 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:05:30 --> Utf8 Class Initialized
INFO - 2020-09-06 19:05:30 --> URI Class Initialized
INFO - 2020-09-06 19:05:30 --> Router Class Initialized
INFO - 2020-09-06 19:05:30 --> Output Class Initialized
INFO - 2020-09-06 19:05:30 --> Security Class Initialized
DEBUG - 2020-09-06 19:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:05:30 --> Input Class Initialized
INFO - 2020-09-06 19:05:30 --> Language Class Initialized
INFO - 2020-09-06 19:05:30 --> Language Class Initialized
INFO - 2020-09-06 19:05:30 --> Config Class Initialized
INFO - 2020-09-06 19:05:30 --> Loader Class Initialized
INFO - 2020-09-06 19:05:30 --> Helper loaded: url_helper
INFO - 2020-09-06 19:05:30 --> Helper loaded: form_helper
INFO - 2020-09-06 19:05:30 --> Helper loaded: file_helper
INFO - 2020-09-06 19:05:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:05:30 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:05:30 --> Upload Class Initialized
INFO - 2020-09-06 19:05:30 --> Controller Class Initialized
ERROR - 2020-09-06 19:05:30 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:23:03 --> Config Class Initialized
INFO - 2020-09-06 19:23:03 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:23:03 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:23:03 --> Utf8 Class Initialized
INFO - 2020-09-06 19:23:03 --> URI Class Initialized
DEBUG - 2020-09-06 19:23:03 --> No URI present. Default controller set.
INFO - 2020-09-06 19:23:03 --> Router Class Initialized
INFO - 2020-09-06 19:23:03 --> Output Class Initialized
INFO - 2020-09-06 19:23:03 --> Security Class Initialized
DEBUG - 2020-09-06 19:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:23:03 --> Input Class Initialized
INFO - 2020-09-06 19:23:03 --> Language Class Initialized
INFO - 2020-09-06 19:23:03 --> Language Class Initialized
INFO - 2020-09-06 19:23:03 --> Config Class Initialized
INFO - 2020-09-06 19:23:03 --> Loader Class Initialized
INFO - 2020-09-06 19:23:03 --> Helper loaded: url_helper
INFO - 2020-09-06 19:23:03 --> Helper loaded: form_helper
INFO - 2020-09-06 19:23:03 --> Helper loaded: file_helper
INFO - 2020-09-06 19:23:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:23:03 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:23:03 --> Upload Class Initialized
INFO - 2020-09-06 19:23:03 --> Controller Class Initialized
DEBUG - 2020-09-06 19:23:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:23:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 19:23:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 19:23:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:23:03 --> Final output sent to browser
DEBUG - 2020-09-06 19:23:03 --> Total execution time: 0.0850
INFO - 2020-09-06 19:23:09 --> Config Class Initialized
INFO - 2020-09-06 19:23:09 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:23:09 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:23:09 --> Utf8 Class Initialized
INFO - 2020-09-06 19:23:09 --> URI Class Initialized
INFO - 2020-09-06 19:23:09 --> Router Class Initialized
INFO - 2020-09-06 19:23:09 --> Output Class Initialized
INFO - 2020-09-06 19:23:09 --> Security Class Initialized
DEBUG - 2020-09-06 19:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:23:09 --> Input Class Initialized
INFO - 2020-09-06 19:23:09 --> Language Class Initialized
INFO - 2020-09-06 19:23:09 --> Language Class Initialized
INFO - 2020-09-06 19:23:09 --> Config Class Initialized
INFO - 2020-09-06 19:23:09 --> Loader Class Initialized
INFO - 2020-09-06 19:23:09 --> Helper loaded: url_helper
INFO - 2020-09-06 19:23:09 --> Helper loaded: form_helper
INFO - 2020-09-06 19:23:09 --> Helper loaded: file_helper
INFO - 2020-09-06 19:23:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:23:09 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:23:09 --> Upload Class Initialized
INFO - 2020-09-06 19:23:09 --> Controller Class Initialized
ERROR - 2020-09-06 19:23:09 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:47:23 --> Config Class Initialized
INFO - 2020-09-06 19:47:23 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:47:23 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:47:23 --> Utf8 Class Initialized
INFO - 2020-09-06 19:47:23 --> URI Class Initialized
INFO - 2020-09-06 19:47:23 --> Router Class Initialized
INFO - 2020-09-06 19:47:23 --> Output Class Initialized
INFO - 2020-09-06 19:47:23 --> Security Class Initialized
DEBUG - 2020-09-06 19:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:47:23 --> Input Class Initialized
INFO - 2020-09-06 19:47:23 --> Language Class Initialized
INFO - 2020-09-06 19:47:23 --> Language Class Initialized
INFO - 2020-09-06 19:47:23 --> Config Class Initialized
INFO - 2020-09-06 19:47:23 --> Loader Class Initialized
INFO - 2020-09-06 19:47:23 --> Helper loaded: url_helper
INFO - 2020-09-06 19:47:23 --> Helper loaded: form_helper
INFO - 2020-09-06 19:47:23 --> Helper loaded: file_helper
INFO - 2020-09-06 19:47:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:47:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:47:23 --> Upload Class Initialized
INFO - 2020-09-06 19:47:23 --> Controller Class Initialized
DEBUG - 2020-09-06 19:47:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:47:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:47:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:47:23 --> Final output sent to browser
DEBUG - 2020-09-06 19:47:23 --> Total execution time: 0.0499
INFO - 2020-09-06 19:47:24 --> Config Class Initialized
INFO - 2020-09-06 19:47:24 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:47:24 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:47:24 --> Utf8 Class Initialized
INFO - 2020-09-06 19:47:24 --> URI Class Initialized
INFO - 2020-09-06 19:47:24 --> Router Class Initialized
INFO - 2020-09-06 19:47:24 --> Output Class Initialized
INFO - 2020-09-06 19:47:24 --> Security Class Initialized
DEBUG - 2020-09-06 19:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:47:24 --> Input Class Initialized
INFO - 2020-09-06 19:47:24 --> Language Class Initialized
INFO - 2020-09-06 19:47:24 --> Language Class Initialized
INFO - 2020-09-06 19:47:24 --> Config Class Initialized
INFO - 2020-09-06 19:47:24 --> Loader Class Initialized
INFO - 2020-09-06 19:47:24 --> Helper loaded: url_helper
INFO - 2020-09-06 19:47:24 --> Helper loaded: form_helper
INFO - 2020-09-06 19:47:24 --> Helper loaded: file_helper
INFO - 2020-09-06 19:47:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:47:24 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:47:24 --> Upload Class Initialized
INFO - 2020-09-06 19:47:24 --> Controller Class Initialized
ERROR - 2020-09-06 19:47:24 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:47:28 --> Config Class Initialized
INFO - 2020-09-06 19:47:28 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:47:28 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:47:28 --> Utf8 Class Initialized
INFO - 2020-09-06 19:47:28 --> URI Class Initialized
INFO - 2020-09-06 19:47:28 --> Router Class Initialized
INFO - 2020-09-06 19:47:28 --> Output Class Initialized
INFO - 2020-09-06 19:47:28 --> Security Class Initialized
DEBUG - 2020-09-06 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:47:28 --> Input Class Initialized
INFO - 2020-09-06 19:47:28 --> Language Class Initialized
INFO - 2020-09-06 19:47:28 --> Language Class Initialized
INFO - 2020-09-06 19:47:28 --> Config Class Initialized
INFO - 2020-09-06 19:47:28 --> Loader Class Initialized
INFO - 2020-09-06 19:47:28 --> Helper loaded: url_helper
INFO - 2020-09-06 19:47:28 --> Helper loaded: form_helper
INFO - 2020-09-06 19:47:28 --> Helper loaded: file_helper
INFO - 2020-09-06 19:47:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:47:28 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:47:28 --> Upload Class Initialized
INFO - 2020-09-06 19:47:28 --> Controller Class Initialized
DEBUG - 2020-09-06 19:47:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:47:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 19:47:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 19:47:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:47:28 --> Final output sent to browser
DEBUG - 2020-09-06 19:47:28 --> Total execution time: 0.0497
INFO - 2020-09-06 19:49:15 --> Config Class Initialized
INFO - 2020-09-06 19:49:15 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:49:15 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:49:15 --> Utf8 Class Initialized
INFO - 2020-09-06 19:49:15 --> URI Class Initialized
INFO - 2020-09-06 19:49:15 --> Router Class Initialized
INFO - 2020-09-06 19:49:15 --> Output Class Initialized
INFO - 2020-09-06 19:49:15 --> Security Class Initialized
DEBUG - 2020-09-06 19:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:49:15 --> Input Class Initialized
INFO - 2020-09-06 19:49:15 --> Language Class Initialized
INFO - 2020-09-06 19:49:15 --> Language Class Initialized
INFO - 2020-09-06 19:49:15 --> Config Class Initialized
INFO - 2020-09-06 19:49:15 --> Loader Class Initialized
INFO - 2020-09-06 19:49:15 --> Helper loaded: url_helper
INFO - 2020-09-06 19:49:15 --> Helper loaded: form_helper
INFO - 2020-09-06 19:49:15 --> Helper loaded: file_helper
INFO - 2020-09-06 19:49:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:49:15 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:49:15 --> Upload Class Initialized
INFO - 2020-09-06 19:49:15 --> Controller Class Initialized
DEBUG - 2020-09-06 19:49:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:49:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:49:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:49:15 --> Final output sent to browser
DEBUG - 2020-09-06 19:49:15 --> Total execution time: 0.0600
INFO - 2020-09-06 19:49:16 --> Config Class Initialized
INFO - 2020-09-06 19:49:16 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:49:16 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:49:16 --> Utf8 Class Initialized
INFO - 2020-09-06 19:49:16 --> URI Class Initialized
INFO - 2020-09-06 19:49:16 --> Router Class Initialized
INFO - 2020-09-06 19:49:16 --> Output Class Initialized
INFO - 2020-09-06 19:49:16 --> Security Class Initialized
DEBUG - 2020-09-06 19:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:49:16 --> Input Class Initialized
INFO - 2020-09-06 19:49:16 --> Language Class Initialized
INFO - 2020-09-06 19:49:16 --> Language Class Initialized
INFO - 2020-09-06 19:49:16 --> Config Class Initialized
INFO - 2020-09-06 19:49:16 --> Loader Class Initialized
INFO - 2020-09-06 19:49:16 --> Helper loaded: url_helper
INFO - 2020-09-06 19:49:16 --> Helper loaded: form_helper
INFO - 2020-09-06 19:49:16 --> Helper loaded: file_helper
INFO - 2020-09-06 19:49:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:49:16 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:49:16 --> Upload Class Initialized
INFO - 2020-09-06 19:49:16 --> Controller Class Initialized
ERROR - 2020-09-06 19:49:16 --> 404 Page Not Found: /index
INFO - 2020-09-06 19:49:18 --> Config Class Initialized
INFO - 2020-09-06 19:49:18 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:49:18 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:49:18 --> Utf8 Class Initialized
INFO - 2020-09-06 19:49:18 --> URI Class Initialized
INFO - 2020-09-06 19:49:18 --> Router Class Initialized
INFO - 2020-09-06 19:49:18 --> Output Class Initialized
INFO - 2020-09-06 19:49:18 --> Security Class Initialized
DEBUG - 2020-09-06 19:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:49:18 --> Input Class Initialized
INFO - 2020-09-06 19:49:18 --> Language Class Initialized
INFO - 2020-09-06 19:49:18 --> Language Class Initialized
INFO - 2020-09-06 19:49:18 --> Config Class Initialized
INFO - 2020-09-06 19:49:18 --> Loader Class Initialized
INFO - 2020-09-06 19:49:18 --> Helper loaded: url_helper
INFO - 2020-09-06 19:49:18 --> Helper loaded: form_helper
INFO - 2020-09-06 19:49:18 --> Helper loaded: file_helper
INFO - 2020-09-06 19:49:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:49:18 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:49:18 --> Upload Class Initialized
INFO - 2020-09-06 19:49:18 --> Controller Class Initialized
DEBUG - 2020-09-06 19:49:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:49:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:49:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:49:18 --> Final output sent to browser
DEBUG - 2020-09-06 19:49:18 --> Total execution time: 0.0514
INFO - 2020-09-06 19:49:19 --> Config Class Initialized
INFO - 2020-09-06 19:49:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:49:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:49:19 --> Utf8 Class Initialized
INFO - 2020-09-06 19:49:19 --> URI Class Initialized
INFO - 2020-09-06 19:49:19 --> Router Class Initialized
INFO - 2020-09-06 19:49:19 --> Output Class Initialized
INFO - 2020-09-06 19:49:19 --> Security Class Initialized
DEBUG - 2020-09-06 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:49:19 --> Input Class Initialized
INFO - 2020-09-06 19:49:19 --> Language Class Initialized
INFO - 2020-09-06 19:49:19 --> Language Class Initialized
INFO - 2020-09-06 19:49:19 --> Config Class Initialized
INFO - 2020-09-06 19:49:19 --> Loader Class Initialized
INFO - 2020-09-06 19:49:19 --> Helper loaded: url_helper
INFO - 2020-09-06 19:49:19 --> Helper loaded: form_helper
INFO - 2020-09-06 19:49:19 --> Helper loaded: file_helper
INFO - 2020-09-06 19:49:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:49:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:49:19 --> Upload Class Initialized
INFO - 2020-09-06 19:49:19 --> Controller Class Initialized
DEBUG - 2020-09-06 19:49:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:49:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:49:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:49:19 --> Final output sent to browser
DEBUG - 2020-09-06 19:49:19 --> Total execution time: 0.0509
INFO - 2020-09-06 19:49:19 --> Config Class Initialized
INFO - 2020-09-06 19:49:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:49:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:49:19 --> Utf8 Class Initialized
INFO - 2020-09-06 19:49:19 --> URI Class Initialized
INFO - 2020-09-06 19:49:19 --> Router Class Initialized
INFO - 2020-09-06 19:49:19 --> Output Class Initialized
INFO - 2020-09-06 19:49:19 --> Security Class Initialized
DEBUG - 2020-09-06 19:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:49:19 --> Input Class Initialized
INFO - 2020-09-06 19:49:19 --> Language Class Initialized
INFO - 2020-09-06 19:49:19 --> Language Class Initialized
INFO - 2020-09-06 19:49:19 --> Config Class Initialized
INFO - 2020-09-06 19:49:19 --> Loader Class Initialized
INFO - 2020-09-06 19:49:19 --> Helper loaded: url_helper
INFO - 2020-09-06 19:49:19 --> Helper loaded: form_helper
INFO - 2020-09-06 19:49:19 --> Helper loaded: file_helper
INFO - 2020-09-06 19:49:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:49:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:49:19 --> Upload Class Initialized
INFO - 2020-09-06 19:49:19 --> Controller Class Initialized
DEBUG - 2020-09-06 19:49:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:49:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-06 19:49:19 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:49:19 --> Final output sent to browser
DEBUG - 2020-09-06 19:49:19 --> Total execution time: 0.0529
INFO - 2020-09-06 19:49:20 --> Config Class Initialized
INFO - 2020-09-06 19:49:20 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:49:20 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:49:20 --> Utf8 Class Initialized
INFO - 2020-09-06 19:49:20 --> URI Class Initialized
INFO - 2020-09-06 19:49:20 --> Router Class Initialized
INFO - 2020-09-06 19:49:20 --> Output Class Initialized
INFO - 2020-09-06 19:49:20 --> Security Class Initialized
DEBUG - 2020-09-06 19:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:49:20 --> Input Class Initialized
INFO - 2020-09-06 19:49:20 --> Language Class Initialized
INFO - 2020-09-06 19:49:20 --> Language Class Initialized
INFO - 2020-09-06 19:49:20 --> Config Class Initialized
INFO - 2020-09-06 19:49:20 --> Loader Class Initialized
INFO - 2020-09-06 19:49:20 --> Helper loaded: url_helper
INFO - 2020-09-06 19:49:20 --> Helper loaded: form_helper
INFO - 2020-09-06 19:49:20 --> Helper loaded: file_helper
INFO - 2020-09-06 19:49:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:49:20 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:49:20 --> Upload Class Initialized
INFO - 2020-09-06 19:49:20 --> Controller Class Initialized
DEBUG - 2020-09-06 19:49:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 19:49:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 19:49:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 19:49:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 19:49:20 --> Final output sent to browser
DEBUG - 2020-09-06 19:49:20 --> Total execution time: 0.0513
INFO - 2020-09-06 19:59:33 --> Config Class Initialized
INFO - 2020-09-06 19:59:33 --> Hooks Class Initialized
DEBUG - 2020-09-06 19:59:33 --> UTF-8 Support Enabled
INFO - 2020-09-06 19:59:33 --> Utf8 Class Initialized
INFO - 2020-09-06 19:59:33 --> URI Class Initialized
INFO - 2020-09-06 19:59:33 --> Router Class Initialized
INFO - 2020-09-06 19:59:33 --> Output Class Initialized
INFO - 2020-09-06 19:59:33 --> Security Class Initialized
DEBUG - 2020-09-06 19:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 19:59:33 --> Input Class Initialized
INFO - 2020-09-06 19:59:33 --> Language Class Initialized
INFO - 2020-09-06 19:59:33 --> Language Class Initialized
INFO - 2020-09-06 19:59:33 --> Config Class Initialized
INFO - 2020-09-06 19:59:33 --> Loader Class Initialized
INFO - 2020-09-06 19:59:33 --> Helper loaded: url_helper
INFO - 2020-09-06 19:59:33 --> Helper loaded: form_helper
INFO - 2020-09-06 19:59:33 --> Helper loaded: file_helper
INFO - 2020-09-06 19:59:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 19:59:33 --> Database Driver Class Initialized
DEBUG - 2020-09-06 19:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 19:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 19:59:33 --> Upload Class Initialized
INFO - 2020-09-06 19:59:33 --> Controller Class Initialized
ERROR - 2020-09-06 19:59:33 --> 404 Page Not Found: /index
INFO - 2020-09-06 20:02:02 --> Config Class Initialized
INFO - 2020-09-06 20:02:02 --> Hooks Class Initialized
DEBUG - 2020-09-06 20:02:02 --> UTF-8 Support Enabled
INFO - 2020-09-06 20:02:02 --> Utf8 Class Initialized
INFO - 2020-09-06 20:02:02 --> URI Class Initialized
INFO - 2020-09-06 20:02:02 --> Router Class Initialized
INFO - 2020-09-06 20:02:02 --> Output Class Initialized
INFO - 2020-09-06 20:02:02 --> Security Class Initialized
DEBUG - 2020-09-06 20:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 20:02:02 --> Input Class Initialized
INFO - 2020-09-06 20:02:02 --> Language Class Initialized
INFO - 2020-09-06 20:02:02 --> Language Class Initialized
INFO - 2020-09-06 20:02:02 --> Config Class Initialized
INFO - 2020-09-06 20:02:02 --> Loader Class Initialized
INFO - 2020-09-06 20:02:02 --> Helper loaded: url_helper
INFO - 2020-09-06 20:02:02 --> Helper loaded: form_helper
INFO - 2020-09-06 20:02:02 --> Helper loaded: file_helper
INFO - 2020-09-06 20:02:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 20:02:02 --> Database Driver Class Initialized
DEBUG - 2020-09-06 20:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 20:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 20:02:02 --> Upload Class Initialized
INFO - 2020-09-06 20:02:02 --> Controller Class Initialized
ERROR - 2020-09-06 20:02:02 --> 404 Page Not Found: /index
INFO - 2020-09-06 20:40:54 --> Config Class Initialized
INFO - 2020-09-06 20:40:54 --> Hooks Class Initialized
DEBUG - 2020-09-06 20:40:54 --> UTF-8 Support Enabled
INFO - 2020-09-06 20:40:54 --> Utf8 Class Initialized
INFO - 2020-09-06 20:40:54 --> URI Class Initialized
DEBUG - 2020-09-06 20:40:54 --> No URI present. Default controller set.
INFO - 2020-09-06 20:40:54 --> Router Class Initialized
INFO - 2020-09-06 20:40:54 --> Output Class Initialized
INFO - 2020-09-06 20:40:54 --> Security Class Initialized
DEBUG - 2020-09-06 20:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 20:40:54 --> Input Class Initialized
INFO - 2020-09-06 20:40:54 --> Language Class Initialized
INFO - 2020-09-06 20:40:54 --> Language Class Initialized
INFO - 2020-09-06 20:40:54 --> Config Class Initialized
INFO - 2020-09-06 20:40:54 --> Loader Class Initialized
INFO - 2020-09-06 20:40:54 --> Helper loaded: url_helper
INFO - 2020-09-06 20:40:54 --> Helper loaded: form_helper
INFO - 2020-09-06 20:40:54 --> Helper loaded: file_helper
INFO - 2020-09-06 20:40:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 20:40:54 --> Database Driver Class Initialized
DEBUG - 2020-09-06 20:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 20:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 20:40:54 --> Upload Class Initialized
INFO - 2020-09-06 20:40:54 --> Controller Class Initialized
DEBUG - 2020-09-06 20:40:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 20:40:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 20:40:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 20:40:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 20:40:54 --> Final output sent to browser
DEBUG - 2020-09-06 20:40:54 --> Total execution time: 0.0515
INFO - 2020-09-06 22:00:10 --> Config Class Initialized
INFO - 2020-09-06 22:00:10 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:00:10 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:00:10 --> Utf8 Class Initialized
INFO - 2020-09-06 22:00:10 --> URI Class Initialized
DEBUG - 2020-09-06 22:00:10 --> No URI present. Default controller set.
INFO - 2020-09-06 22:00:10 --> Router Class Initialized
INFO - 2020-09-06 22:00:10 --> Output Class Initialized
INFO - 2020-09-06 22:00:10 --> Security Class Initialized
DEBUG - 2020-09-06 22:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:00:10 --> Input Class Initialized
INFO - 2020-09-06 22:00:10 --> Language Class Initialized
INFO - 2020-09-06 22:00:10 --> Language Class Initialized
INFO - 2020-09-06 22:00:10 --> Config Class Initialized
INFO - 2020-09-06 22:00:10 --> Loader Class Initialized
INFO - 2020-09-06 22:00:10 --> Helper loaded: url_helper
INFO - 2020-09-06 22:00:10 --> Helper loaded: form_helper
INFO - 2020-09-06 22:00:10 --> Helper loaded: file_helper
INFO - 2020-09-06 22:00:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:00:10 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:00:10 --> Upload Class Initialized
INFO - 2020-09-06 22:00:11 --> Controller Class Initialized
DEBUG - 2020-09-06 22:00:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 22:00:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 22:00:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 22:00:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 22:00:11 --> Final output sent to browser
DEBUG - 2020-09-06 22:00:11 --> Total execution time: 0.0537
INFO - 2020-09-06 22:00:19 --> Config Class Initialized
INFO - 2020-09-06 22:00:19 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:00:19 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:00:19 --> Utf8 Class Initialized
INFO - 2020-09-06 22:00:19 --> URI Class Initialized
INFO - 2020-09-06 22:00:19 --> Router Class Initialized
INFO - 2020-09-06 22:00:19 --> Output Class Initialized
INFO - 2020-09-06 22:00:19 --> Security Class Initialized
DEBUG - 2020-09-06 22:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:00:19 --> Input Class Initialized
INFO - 2020-09-06 22:00:19 --> Language Class Initialized
INFO - 2020-09-06 22:00:19 --> Language Class Initialized
INFO - 2020-09-06 22:00:19 --> Config Class Initialized
INFO - 2020-09-06 22:00:19 --> Loader Class Initialized
INFO - 2020-09-06 22:00:19 --> Helper loaded: url_helper
INFO - 2020-09-06 22:00:19 --> Helper loaded: form_helper
INFO - 2020-09-06 22:00:19 --> Helper loaded: file_helper
INFO - 2020-09-06 22:00:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:00:19 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:00:19 --> Upload Class Initialized
INFO - 2020-09-06 22:00:19 --> Controller Class Initialized
ERROR - 2020-09-06 22:00:19 --> 404 Page Not Found: /index
INFO - 2020-09-06 22:22:23 --> Config Class Initialized
INFO - 2020-09-06 22:22:23 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:22:23 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:22:23 --> Utf8 Class Initialized
INFO - 2020-09-06 22:22:23 --> URI Class Initialized
DEBUG - 2020-09-06 22:22:23 --> No URI present. Default controller set.
INFO - 2020-09-06 22:22:23 --> Router Class Initialized
INFO - 2020-09-06 22:22:23 --> Output Class Initialized
INFO - 2020-09-06 22:22:23 --> Security Class Initialized
DEBUG - 2020-09-06 22:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:22:23 --> Input Class Initialized
INFO - 2020-09-06 22:22:23 --> Language Class Initialized
INFO - 2020-09-06 22:22:23 --> Language Class Initialized
INFO - 2020-09-06 22:22:23 --> Config Class Initialized
INFO - 2020-09-06 22:22:23 --> Loader Class Initialized
INFO - 2020-09-06 22:22:23 --> Helper loaded: url_helper
INFO - 2020-09-06 22:22:23 --> Helper loaded: form_helper
INFO - 2020-09-06 22:22:23 --> Helper loaded: file_helper
INFO - 2020-09-06 22:22:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:22:23 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:22:23 --> Upload Class Initialized
INFO - 2020-09-06 22:22:23 --> Controller Class Initialized
DEBUG - 2020-09-06 22:22:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 22:22:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 22:22:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 22:22:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 22:22:23 --> Final output sent to browser
DEBUG - 2020-09-06 22:22:23 --> Total execution time: 0.0543
INFO - 2020-09-06 22:22:43 --> Config Class Initialized
INFO - 2020-09-06 22:22:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:22:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:22:43 --> Utf8 Class Initialized
INFO - 2020-09-06 22:22:43 --> URI Class Initialized
INFO - 2020-09-06 22:22:43 --> Router Class Initialized
INFO - 2020-09-06 22:22:43 --> Output Class Initialized
INFO - 2020-09-06 22:22:43 --> Security Class Initialized
DEBUG - 2020-09-06 22:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:22:43 --> Input Class Initialized
INFO - 2020-09-06 22:22:43 --> Language Class Initialized
INFO - 2020-09-06 22:22:43 --> Language Class Initialized
INFO - 2020-09-06 22:22:43 --> Config Class Initialized
INFO - 2020-09-06 22:22:43 --> Loader Class Initialized
INFO - 2020-09-06 22:22:43 --> Helper loaded: url_helper
INFO - 2020-09-06 22:22:43 --> Helper loaded: form_helper
INFO - 2020-09-06 22:22:43 --> Helper loaded: file_helper
INFO - 2020-09-06 22:22:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:22:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:22:43 --> Upload Class Initialized
INFO - 2020-09-06 22:22:43 --> Controller Class Initialized
ERROR - 2020-09-06 22:22:43 --> 404 Page Not Found: /index
INFO - 2020-09-06 22:50:06 --> Config Class Initialized
INFO - 2020-09-06 22:50:06 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:50:06 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:50:06 --> Utf8 Class Initialized
INFO - 2020-09-06 22:50:06 --> URI Class Initialized
INFO - 2020-09-06 22:50:06 --> Router Class Initialized
INFO - 2020-09-06 22:50:06 --> Output Class Initialized
INFO - 2020-09-06 22:50:06 --> Security Class Initialized
DEBUG - 2020-09-06 22:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:50:06 --> Input Class Initialized
INFO - 2020-09-06 22:50:06 --> Language Class Initialized
INFO - 2020-09-06 22:50:06 --> Language Class Initialized
INFO - 2020-09-06 22:50:06 --> Config Class Initialized
INFO - 2020-09-06 22:50:06 --> Loader Class Initialized
INFO - 2020-09-06 22:50:06 --> Helper loaded: url_helper
INFO - 2020-09-06 22:50:06 --> Helper loaded: form_helper
INFO - 2020-09-06 22:50:06 --> Helper loaded: file_helper
INFO - 2020-09-06 22:50:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:50:06 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:50:06 --> Upload Class Initialized
INFO - 2020-09-06 22:50:06 --> Controller Class Initialized
ERROR - 2020-09-06 22:50:06 --> 404 Page Not Found: /index
INFO - 2020-09-06 22:51:43 --> Config Class Initialized
INFO - 2020-09-06 22:51:43 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:51:43 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:51:43 --> Utf8 Class Initialized
INFO - 2020-09-06 22:51:43 --> URI Class Initialized
INFO - 2020-09-06 22:51:43 --> Router Class Initialized
INFO - 2020-09-06 22:51:43 --> Output Class Initialized
INFO - 2020-09-06 22:51:43 --> Security Class Initialized
DEBUG - 2020-09-06 22:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:51:43 --> Input Class Initialized
INFO - 2020-09-06 22:51:43 --> Language Class Initialized
INFO - 2020-09-06 22:51:43 --> Language Class Initialized
INFO - 2020-09-06 22:51:43 --> Config Class Initialized
INFO - 2020-09-06 22:51:43 --> Loader Class Initialized
INFO - 2020-09-06 22:51:43 --> Helper loaded: url_helper
INFO - 2020-09-06 22:51:43 --> Helper loaded: form_helper
INFO - 2020-09-06 22:51:43 --> Helper loaded: file_helper
INFO - 2020-09-06 22:51:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:51:43 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:51:43 --> Upload Class Initialized
INFO - 2020-09-06 22:51:43 --> Controller Class Initialized
ERROR - 2020-09-06 22:51:43 --> 404 Page Not Found: /index
INFO - 2020-09-06 22:59:53 --> Config Class Initialized
INFO - 2020-09-06 22:59:53 --> Hooks Class Initialized
DEBUG - 2020-09-06 22:59:53 --> UTF-8 Support Enabled
INFO - 2020-09-06 22:59:53 --> Utf8 Class Initialized
INFO - 2020-09-06 22:59:53 --> URI Class Initialized
INFO - 2020-09-06 22:59:53 --> Router Class Initialized
INFO - 2020-09-06 22:59:53 --> Output Class Initialized
INFO - 2020-09-06 22:59:53 --> Security Class Initialized
DEBUG - 2020-09-06 22:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 22:59:53 --> Input Class Initialized
INFO - 2020-09-06 22:59:53 --> Language Class Initialized
INFO - 2020-09-06 22:59:53 --> Language Class Initialized
INFO - 2020-09-06 22:59:53 --> Config Class Initialized
INFO - 2020-09-06 22:59:53 --> Loader Class Initialized
INFO - 2020-09-06 22:59:53 --> Helper loaded: url_helper
INFO - 2020-09-06 22:59:53 --> Helper loaded: form_helper
INFO - 2020-09-06 22:59:53 --> Helper loaded: file_helper
INFO - 2020-09-06 22:59:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 22:59:53 --> Database Driver Class Initialized
DEBUG - 2020-09-06 22:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 22:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 22:59:53 --> Upload Class Initialized
INFO - 2020-09-06 22:59:53 --> Controller Class Initialized
ERROR - 2020-09-06 22:59:53 --> 404 Page Not Found: /index
INFO - 2020-09-06 23:06:50 --> Config Class Initialized
INFO - 2020-09-06 23:06:50 --> Hooks Class Initialized
DEBUG - 2020-09-06 23:06:50 --> UTF-8 Support Enabled
INFO - 2020-09-06 23:06:50 --> Utf8 Class Initialized
INFO - 2020-09-06 23:06:50 --> URI Class Initialized
INFO - 2020-09-06 23:06:50 --> Router Class Initialized
INFO - 2020-09-06 23:06:50 --> Output Class Initialized
INFO - 2020-09-06 23:06:50 --> Security Class Initialized
DEBUG - 2020-09-06 23:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 23:06:50 --> Input Class Initialized
INFO - 2020-09-06 23:06:50 --> Language Class Initialized
INFO - 2020-09-06 23:06:50 --> Language Class Initialized
INFO - 2020-09-06 23:06:50 --> Config Class Initialized
INFO - 2020-09-06 23:06:50 --> Loader Class Initialized
INFO - 2020-09-06 23:06:50 --> Helper loaded: url_helper
INFO - 2020-09-06 23:06:50 --> Helper loaded: form_helper
INFO - 2020-09-06 23:06:50 --> Helper loaded: file_helper
INFO - 2020-09-06 23:06:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 23:06:50 --> Database Driver Class Initialized
DEBUG - 2020-09-06 23:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 23:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 23:06:50 --> Upload Class Initialized
INFO - 2020-09-06 23:06:50 --> Controller Class Initialized
ERROR - 2020-09-06 23:06:50 --> 404 Page Not Found: /index
INFO - 2020-09-06 23:39:48 --> Config Class Initialized
INFO - 2020-09-06 23:39:48 --> Hooks Class Initialized
DEBUG - 2020-09-06 23:39:48 --> UTF-8 Support Enabled
INFO - 2020-09-06 23:39:48 --> Utf8 Class Initialized
INFO - 2020-09-06 23:39:48 --> URI Class Initialized
DEBUG - 2020-09-06 23:39:48 --> No URI present. Default controller set.
INFO - 2020-09-06 23:39:48 --> Router Class Initialized
INFO - 2020-09-06 23:39:48 --> Output Class Initialized
INFO - 2020-09-06 23:39:48 --> Security Class Initialized
DEBUG - 2020-09-06 23:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-06 23:39:48 --> Input Class Initialized
INFO - 2020-09-06 23:39:48 --> Language Class Initialized
INFO - 2020-09-06 23:39:48 --> Language Class Initialized
INFO - 2020-09-06 23:39:48 --> Config Class Initialized
INFO - 2020-09-06 23:39:48 --> Loader Class Initialized
INFO - 2020-09-06 23:39:48 --> Helper loaded: url_helper
INFO - 2020-09-06 23:39:48 --> Helper loaded: form_helper
INFO - 2020-09-06 23:39:48 --> Helper loaded: file_helper
INFO - 2020-09-06 23:39:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-06 23:39:48 --> Database Driver Class Initialized
DEBUG - 2020-09-06 23:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-06 23:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-06 23:39:48 --> Upload Class Initialized
INFO - 2020-09-06 23:39:48 --> Controller Class Initialized
DEBUG - 2020-09-06 23:39:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-06 23:39:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-06 23:39:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-06 23:39:48 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-06 23:39:48 --> Final output sent to browser
DEBUG - 2020-09-06 23:39:48 --> Total execution time: 0.0636
