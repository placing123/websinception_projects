<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-08 00:01:58 --> Config Class Initialized
INFO - 2020-09-08 00:01:58 --> Hooks Class Initialized
DEBUG - 2020-09-08 00:01:59 --> UTF-8 Support Enabled
INFO - 2020-09-08 00:01:59 --> Utf8 Class Initialized
INFO - 2020-09-08 00:01:59 --> URI Class Initialized
DEBUG - 2020-09-08 00:01:59 --> No URI present. Default controller set.
INFO - 2020-09-08 00:01:59 --> Router Class Initialized
INFO - 2020-09-08 00:01:59 --> Output Class Initialized
INFO - 2020-09-08 00:01:59 --> Security Class Initialized
DEBUG - 2020-09-08 00:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 00:01:59 --> Input Class Initialized
INFO - 2020-09-08 00:01:59 --> Language Class Initialized
INFO - 2020-09-08 00:01:59 --> Language Class Initialized
INFO - 2020-09-08 00:01:59 --> Config Class Initialized
INFO - 2020-09-08 00:01:59 --> Loader Class Initialized
INFO - 2020-09-08 00:01:59 --> Helper loaded: url_helper
INFO - 2020-09-08 00:01:59 --> Helper loaded: form_helper
INFO - 2020-09-08 00:01:59 --> Helper loaded: file_helper
INFO - 2020-09-08 00:01:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 00:01:59 --> Database Driver Class Initialized
DEBUG - 2020-09-08 00:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 00:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 00:01:59 --> Upload Class Initialized
INFO - 2020-09-08 00:01:59 --> Controller Class Initialized
DEBUG - 2020-09-08 00:01:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 00:01:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 00:01:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 00:01:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 00:01:59 --> Final output sent to browser
DEBUG - 2020-09-08 00:01:59 --> Total execution time: 0.6899
INFO - 2020-09-08 00:02:00 --> Config Class Initialized
INFO - 2020-09-08 00:02:00 --> Hooks Class Initialized
DEBUG - 2020-09-08 00:02:00 --> UTF-8 Support Enabled
INFO - 2020-09-08 00:02:00 --> Utf8 Class Initialized
INFO - 2020-09-08 00:02:00 --> URI Class Initialized
DEBUG - 2020-09-08 00:02:00 --> No URI present. Default controller set.
INFO - 2020-09-08 00:02:00 --> Router Class Initialized
INFO - 2020-09-08 00:02:00 --> Output Class Initialized
INFO - 2020-09-08 00:02:00 --> Security Class Initialized
DEBUG - 2020-09-08 00:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 00:02:00 --> Input Class Initialized
INFO - 2020-09-08 00:02:00 --> Language Class Initialized
INFO - 2020-09-08 00:02:00 --> Language Class Initialized
INFO - 2020-09-08 00:02:00 --> Config Class Initialized
INFO - 2020-09-08 00:02:00 --> Loader Class Initialized
INFO - 2020-09-08 00:02:00 --> Helper loaded: url_helper
INFO - 2020-09-08 00:02:00 --> Helper loaded: form_helper
INFO - 2020-09-08 00:02:00 --> Helper loaded: file_helper
INFO - 2020-09-08 00:02:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 00:02:00 --> Database Driver Class Initialized
DEBUG - 2020-09-08 00:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 00:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 00:02:00 --> Upload Class Initialized
INFO - 2020-09-08 00:02:00 --> Controller Class Initialized
DEBUG - 2020-09-08 00:02:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 00:02:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 00:02:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 00:02:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 00:02:00 --> Final output sent to browser
DEBUG - 2020-09-08 00:02:00 --> Total execution time: 0.0382
INFO - 2020-09-08 00:16:59 --> Config Class Initialized
INFO - 2020-09-08 00:16:59 --> Hooks Class Initialized
DEBUG - 2020-09-08 00:16:59 --> UTF-8 Support Enabled
INFO - 2020-09-08 00:16:59 --> Utf8 Class Initialized
INFO - 2020-09-08 00:16:59 --> URI Class Initialized
INFO - 2020-09-08 00:16:59 --> Router Class Initialized
INFO - 2020-09-08 00:16:59 --> Output Class Initialized
INFO - 2020-09-08 00:16:59 --> Security Class Initialized
DEBUG - 2020-09-08 00:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 00:16:59 --> Input Class Initialized
INFO - 2020-09-08 00:16:59 --> Language Class Initialized
INFO - 2020-09-08 00:16:59 --> Language Class Initialized
INFO - 2020-09-08 00:16:59 --> Config Class Initialized
INFO - 2020-09-08 00:16:59 --> Loader Class Initialized
INFO - 2020-09-08 00:16:59 --> Helper loaded: url_helper
INFO - 2020-09-08 00:16:59 --> Helper loaded: form_helper
INFO - 2020-09-08 00:16:59 --> Helper loaded: file_helper
INFO - 2020-09-08 00:16:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 00:16:59 --> Database Driver Class Initialized
DEBUG - 2020-09-08 00:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 00:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 00:16:59 --> Upload Class Initialized
INFO - 2020-09-08 00:16:59 --> Controller Class Initialized
ERROR - 2020-09-08 00:16:59 --> 404 Page Not Found: /index
INFO - 2020-09-08 00:23:07 --> Config Class Initialized
INFO - 2020-09-08 00:23:07 --> Hooks Class Initialized
DEBUG - 2020-09-08 00:23:07 --> UTF-8 Support Enabled
INFO - 2020-09-08 00:23:07 --> Utf8 Class Initialized
INFO - 2020-09-08 00:23:07 --> URI Class Initialized
INFO - 2020-09-08 00:23:07 --> Router Class Initialized
INFO - 2020-09-08 00:23:07 --> Output Class Initialized
INFO - 2020-09-08 00:23:07 --> Security Class Initialized
DEBUG - 2020-09-08 00:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 00:23:07 --> Input Class Initialized
INFO - 2020-09-08 00:23:07 --> Language Class Initialized
INFO - 2020-09-08 00:23:07 --> Language Class Initialized
INFO - 2020-09-08 00:23:07 --> Config Class Initialized
INFO - 2020-09-08 00:23:07 --> Loader Class Initialized
INFO - 2020-09-08 00:23:07 --> Helper loaded: url_helper
INFO - 2020-09-08 00:23:07 --> Helper loaded: form_helper
INFO - 2020-09-08 00:23:07 --> Helper loaded: file_helper
INFO - 2020-09-08 00:23:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 00:23:07 --> Database Driver Class Initialized
DEBUG - 2020-09-08 00:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 00:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 00:23:07 --> Upload Class Initialized
INFO - 2020-09-08 00:23:07 --> Controller Class Initialized
ERROR - 2020-09-08 00:23:07 --> 404 Page Not Found: /index
INFO - 2020-09-08 03:07:25 --> Config Class Initialized
INFO - 2020-09-08 03:07:25 --> Hooks Class Initialized
DEBUG - 2020-09-08 03:07:26 --> UTF-8 Support Enabled
INFO - 2020-09-08 03:07:26 --> Utf8 Class Initialized
INFO - 2020-09-08 03:07:26 --> URI Class Initialized
DEBUG - 2020-09-08 03:07:26 --> No URI present. Default controller set.
INFO - 2020-09-08 03:07:26 --> Router Class Initialized
INFO - 2020-09-08 03:07:26 --> Output Class Initialized
INFO - 2020-09-08 03:07:26 --> Security Class Initialized
DEBUG - 2020-09-08 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 03:07:26 --> Input Class Initialized
INFO - 2020-09-08 03:07:26 --> Language Class Initialized
INFO - 2020-09-08 03:07:26 --> Language Class Initialized
INFO - 2020-09-08 03:07:26 --> Config Class Initialized
INFO - 2020-09-08 03:07:26 --> Loader Class Initialized
INFO - 2020-09-08 03:07:26 --> Helper loaded: url_helper
INFO - 2020-09-08 03:07:26 --> Helper loaded: form_helper
INFO - 2020-09-08 03:07:26 --> Helper loaded: file_helper
INFO - 2020-09-08 03:07:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 03:07:26 --> Database Driver Class Initialized
DEBUG - 2020-09-08 03:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 03:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 03:07:26 --> Upload Class Initialized
INFO - 2020-09-08 03:07:27 --> Controller Class Initialized
DEBUG - 2020-09-08 03:07:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 03:07:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 03:07:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 03:07:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 03:07:27 --> Final output sent to browser
DEBUG - 2020-09-08 03:07:27 --> Total execution time: 1.2000
INFO - 2020-09-08 04:09:41 --> Config Class Initialized
INFO - 2020-09-08 04:09:41 --> Hooks Class Initialized
DEBUG - 2020-09-08 04:09:41 --> UTF-8 Support Enabled
INFO - 2020-09-08 04:09:41 --> Utf8 Class Initialized
INFO - 2020-09-08 04:09:41 --> URI Class Initialized
DEBUG - 2020-09-08 04:09:41 --> No URI present. Default controller set.
INFO - 2020-09-08 04:09:41 --> Router Class Initialized
INFO - 2020-09-08 04:09:41 --> Output Class Initialized
INFO - 2020-09-08 04:09:41 --> Security Class Initialized
DEBUG - 2020-09-08 04:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 04:09:41 --> Input Class Initialized
INFO - 2020-09-08 04:09:41 --> Language Class Initialized
INFO - 2020-09-08 04:09:41 --> Language Class Initialized
INFO - 2020-09-08 04:09:41 --> Config Class Initialized
INFO - 2020-09-08 04:09:41 --> Loader Class Initialized
INFO - 2020-09-08 04:09:41 --> Helper loaded: url_helper
INFO - 2020-09-08 04:09:41 --> Helper loaded: form_helper
INFO - 2020-09-08 04:09:41 --> Helper loaded: file_helper
INFO - 2020-09-08 04:09:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 04:09:41 --> Database Driver Class Initialized
DEBUG - 2020-09-08 04:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 04:09:42 --> Upload Class Initialized
INFO - 2020-09-08 04:09:42 --> Controller Class Initialized
DEBUG - 2020-09-08 04:09:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 04:09:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 04:09:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 04:09:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 04:09:42 --> Final output sent to browser
DEBUG - 2020-09-08 04:09:42 --> Total execution time: 1.0504
INFO - 2020-09-08 05:27:00 --> Config Class Initialized
INFO - 2020-09-08 05:27:00 --> Hooks Class Initialized
DEBUG - 2020-09-08 05:27:01 --> UTF-8 Support Enabled
INFO - 2020-09-08 05:27:01 --> Utf8 Class Initialized
INFO - 2020-09-08 05:27:01 --> URI Class Initialized
DEBUG - 2020-09-08 05:27:01 --> No URI present. Default controller set.
INFO - 2020-09-08 05:27:01 --> Router Class Initialized
INFO - 2020-09-08 05:27:01 --> Output Class Initialized
INFO - 2020-09-08 05:27:01 --> Security Class Initialized
DEBUG - 2020-09-08 05:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 05:27:01 --> Input Class Initialized
INFO - 2020-09-08 05:27:01 --> Language Class Initialized
INFO - 2020-09-08 05:27:01 --> Language Class Initialized
INFO - 2020-09-08 05:27:01 --> Config Class Initialized
INFO - 2020-09-08 05:27:01 --> Loader Class Initialized
INFO - 2020-09-08 05:27:01 --> Helper loaded: url_helper
INFO - 2020-09-08 05:27:01 --> Helper loaded: form_helper
INFO - 2020-09-08 05:27:01 --> Helper loaded: file_helper
INFO - 2020-09-08 05:27:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 05:27:01 --> Database Driver Class Initialized
DEBUG - 2020-09-08 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 05:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 05:27:01 --> Upload Class Initialized
INFO - 2020-09-08 05:27:01 --> Controller Class Initialized
DEBUG - 2020-09-08 05:27:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 05:27:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 05:27:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 05:27:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 05:27:01 --> Final output sent to browser
DEBUG - 2020-09-08 05:27:01 --> Total execution time: 0.7745
INFO - 2020-09-08 05:27:02 --> Config Class Initialized
INFO - 2020-09-08 05:27:02 --> Hooks Class Initialized
DEBUG - 2020-09-08 05:27:02 --> UTF-8 Support Enabled
INFO - 2020-09-08 05:27:02 --> Utf8 Class Initialized
INFO - 2020-09-08 05:27:02 --> URI Class Initialized
DEBUG - 2020-09-08 05:27:02 --> No URI present. Default controller set.
INFO - 2020-09-08 05:27:02 --> Router Class Initialized
INFO - 2020-09-08 05:27:02 --> Output Class Initialized
INFO - 2020-09-08 05:27:02 --> Security Class Initialized
DEBUG - 2020-09-08 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 05:27:02 --> Input Class Initialized
INFO - 2020-09-08 05:27:02 --> Language Class Initialized
INFO - 2020-09-08 05:27:02 --> Language Class Initialized
INFO - 2020-09-08 05:27:02 --> Config Class Initialized
INFO - 2020-09-08 05:27:02 --> Loader Class Initialized
INFO - 2020-09-08 05:27:02 --> Helper loaded: url_helper
INFO - 2020-09-08 05:27:02 --> Helper loaded: form_helper
INFO - 2020-09-08 05:27:02 --> Helper loaded: file_helper
INFO - 2020-09-08 05:27:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 05:27:02 --> Database Driver Class Initialized
DEBUG - 2020-09-08 05:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 05:27:02 --> Upload Class Initialized
INFO - 2020-09-08 05:27:02 --> Controller Class Initialized
DEBUG - 2020-09-08 05:27:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 05:27:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 05:27:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 05:27:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 05:27:02 --> Final output sent to browser
DEBUG - 2020-09-08 05:27:02 --> Total execution time: 0.2879
INFO - 2020-09-08 05:40:03 --> Config Class Initialized
INFO - 2020-09-08 05:40:03 --> Hooks Class Initialized
DEBUG - 2020-09-08 05:40:03 --> UTF-8 Support Enabled
INFO - 2020-09-08 05:40:03 --> Utf8 Class Initialized
INFO - 2020-09-08 05:40:03 --> URI Class Initialized
DEBUG - 2020-09-08 05:40:03 --> No URI present. Default controller set.
INFO - 2020-09-08 05:40:03 --> Router Class Initialized
INFO - 2020-09-08 05:40:03 --> Output Class Initialized
INFO - 2020-09-08 05:40:03 --> Security Class Initialized
DEBUG - 2020-09-08 05:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 05:40:03 --> Input Class Initialized
INFO - 2020-09-08 05:40:03 --> Language Class Initialized
INFO - 2020-09-08 05:40:03 --> Language Class Initialized
INFO - 2020-09-08 05:40:03 --> Config Class Initialized
INFO - 2020-09-08 05:40:03 --> Loader Class Initialized
INFO - 2020-09-08 05:40:03 --> Helper loaded: url_helper
INFO - 2020-09-08 05:40:03 --> Helper loaded: form_helper
INFO - 2020-09-08 05:40:03 --> Helper loaded: file_helper
INFO - 2020-09-08 05:40:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 05:40:03 --> Database Driver Class Initialized
DEBUG - 2020-09-08 05:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 05:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 05:40:03 --> Upload Class Initialized
INFO - 2020-09-08 05:40:03 --> Controller Class Initialized
DEBUG - 2020-09-08 05:40:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 05:40:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 05:40:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 05:40:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 05:40:03 --> Final output sent to browser
DEBUG - 2020-09-08 05:40:03 --> Total execution time: 0.3192
INFO - 2020-09-08 06:21:44 --> Config Class Initialized
INFO - 2020-09-08 06:21:44 --> Hooks Class Initialized
DEBUG - 2020-09-08 06:21:44 --> UTF-8 Support Enabled
INFO - 2020-09-08 06:21:44 --> Utf8 Class Initialized
INFO - 2020-09-08 06:21:44 --> URI Class Initialized
INFO - 2020-09-08 06:21:44 --> Router Class Initialized
INFO - 2020-09-08 06:21:44 --> Output Class Initialized
INFO - 2020-09-08 06:21:44 --> Security Class Initialized
DEBUG - 2020-09-08 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 06:21:44 --> Input Class Initialized
INFO - 2020-09-08 06:21:44 --> Language Class Initialized
INFO - 2020-09-08 06:21:44 --> Language Class Initialized
INFO - 2020-09-08 06:21:44 --> Config Class Initialized
INFO - 2020-09-08 06:21:44 --> Loader Class Initialized
INFO - 2020-09-08 06:21:44 --> Helper loaded: url_helper
INFO - 2020-09-08 06:21:44 --> Helper loaded: form_helper
INFO - 2020-09-08 06:21:44 --> Helper loaded: file_helper
INFO - 2020-09-08 06:21:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 06:21:45 --> Database Driver Class Initialized
DEBUG - 2020-09-08 06:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 06:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 06:21:45 --> Upload Class Initialized
INFO - 2020-09-08 06:21:45 --> Controller Class Initialized
ERROR - 2020-09-08 06:21:45 --> 404 Page Not Found: /index
INFO - 2020-09-08 07:34:24 --> Config Class Initialized
INFO - 2020-09-08 07:34:25 --> Hooks Class Initialized
DEBUG - 2020-09-08 07:34:27 --> UTF-8 Support Enabled
INFO - 2020-09-08 07:34:27 --> Utf8 Class Initialized
INFO - 2020-09-08 07:34:27 --> URI Class Initialized
DEBUG - 2020-09-08 07:34:27 --> No URI present. Default controller set.
INFO - 2020-09-08 07:34:27 --> Router Class Initialized
INFO - 2020-09-08 07:34:27 --> Output Class Initialized
INFO - 2020-09-08 07:34:27 --> Security Class Initialized
DEBUG - 2020-09-08 07:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 07:34:27 --> Input Class Initialized
INFO - 2020-09-08 07:34:27 --> Language Class Initialized
INFO - 2020-09-08 07:34:27 --> Language Class Initialized
INFO - 2020-09-08 07:34:27 --> Config Class Initialized
INFO - 2020-09-08 07:34:27 --> Loader Class Initialized
INFO - 2020-09-08 07:34:27 --> Helper loaded: url_helper
INFO - 2020-09-08 07:34:28 --> Helper loaded: form_helper
INFO - 2020-09-08 07:34:28 --> Helper loaded: file_helper
INFO - 2020-09-08 07:34:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 07:34:28 --> Database Driver Class Initialized
DEBUG - 2020-09-08 07:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 07:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 07:34:29 --> Upload Class Initialized
INFO - 2020-09-08 07:34:30 --> Controller Class Initialized
DEBUG - 2020-09-08 07:34:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 07:34:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 07:34:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 07:34:30 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 07:34:30 --> Final output sent to browser
DEBUG - 2020-09-08 07:34:30 --> Total execution time: 6.4788
INFO - 2020-09-08 08:10:12 --> Config Class Initialized
INFO - 2020-09-08 08:10:12 --> Hooks Class Initialized
DEBUG - 2020-09-08 08:10:12 --> UTF-8 Support Enabled
INFO - 2020-09-08 08:10:12 --> Utf8 Class Initialized
INFO - 2020-09-08 08:10:12 --> URI Class Initialized
DEBUG - 2020-09-08 08:10:13 --> No URI present. Default controller set.
INFO - 2020-09-08 08:10:13 --> Router Class Initialized
INFO - 2020-09-08 08:10:13 --> Output Class Initialized
INFO - 2020-09-08 08:10:13 --> Security Class Initialized
DEBUG - 2020-09-08 08:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 08:10:13 --> Input Class Initialized
INFO - 2020-09-08 08:10:13 --> Language Class Initialized
INFO - 2020-09-08 08:10:13 --> Language Class Initialized
INFO - 2020-09-08 08:10:13 --> Config Class Initialized
INFO - 2020-09-08 08:10:13 --> Loader Class Initialized
INFO - 2020-09-08 08:10:13 --> Helper loaded: url_helper
INFO - 2020-09-08 08:10:14 --> Helper loaded: form_helper
INFO - 2020-09-08 08:10:14 --> Helper loaded: file_helper
INFO - 2020-09-08 08:10:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 08:10:14 --> Database Driver Class Initialized
DEBUG - 2020-09-08 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 08:10:14 --> Upload Class Initialized
INFO - 2020-09-08 08:10:16 --> Controller Class Initialized
DEBUG - 2020-09-08 08:10:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 08:10:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 08:10:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 08:10:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 08:10:18 --> Final output sent to browser
DEBUG - 2020-09-08 08:10:18 --> Total execution time: 6.2945
INFO - 2020-09-08 08:49:26 --> Config Class Initialized
INFO - 2020-09-08 08:49:26 --> Hooks Class Initialized
DEBUG - 2020-09-08 08:49:26 --> UTF-8 Support Enabled
INFO - 2020-09-08 08:49:26 --> Utf8 Class Initialized
INFO - 2020-09-08 08:49:26 --> URI Class Initialized
DEBUG - 2020-09-08 08:49:26 --> No URI present. Default controller set.
INFO - 2020-09-08 08:49:26 --> Router Class Initialized
INFO - 2020-09-08 08:49:26 --> Output Class Initialized
INFO - 2020-09-08 08:49:27 --> Security Class Initialized
DEBUG - 2020-09-08 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 08:49:27 --> Input Class Initialized
INFO - 2020-09-08 08:49:27 --> Language Class Initialized
INFO - 2020-09-08 08:49:27 --> Language Class Initialized
INFO - 2020-09-08 08:49:27 --> Config Class Initialized
INFO - 2020-09-08 08:49:27 --> Loader Class Initialized
INFO - 2020-09-08 08:49:27 --> Helper loaded: url_helper
INFO - 2020-09-08 08:49:27 --> Helper loaded: form_helper
INFO - 2020-09-08 08:49:27 --> Helper loaded: file_helper
INFO - 2020-09-08 08:49:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 08:49:27 --> Database Driver Class Initialized
DEBUG - 2020-09-08 08:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 08:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 08:49:27 --> Upload Class Initialized
INFO - 2020-09-08 08:49:27 --> Controller Class Initialized
DEBUG - 2020-09-08 08:49:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 08:49:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 08:49:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 08:49:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 08:49:27 --> Final output sent to browser
DEBUG - 2020-09-08 08:49:27 --> Total execution time: 1.4661
INFO - 2020-09-08 08:57:01 --> Config Class Initialized
INFO - 2020-09-08 08:57:01 --> Hooks Class Initialized
DEBUG - 2020-09-08 08:57:01 --> UTF-8 Support Enabled
INFO - 2020-09-08 08:57:01 --> Utf8 Class Initialized
INFO - 2020-09-08 08:57:01 --> URI Class Initialized
DEBUG - 2020-09-08 08:57:01 --> No URI present. Default controller set.
INFO - 2020-09-08 08:57:01 --> Router Class Initialized
INFO - 2020-09-08 08:57:01 --> Output Class Initialized
INFO - 2020-09-08 08:57:01 --> Security Class Initialized
DEBUG - 2020-09-08 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 08:57:01 --> Input Class Initialized
INFO - 2020-09-08 08:57:01 --> Language Class Initialized
INFO - 2020-09-08 08:57:01 --> Language Class Initialized
INFO - 2020-09-08 08:57:01 --> Config Class Initialized
INFO - 2020-09-08 08:57:01 --> Loader Class Initialized
INFO - 2020-09-08 08:57:01 --> Helper loaded: url_helper
INFO - 2020-09-08 08:57:01 --> Helper loaded: form_helper
INFO - 2020-09-08 08:57:01 --> Helper loaded: file_helper
INFO - 2020-09-08 08:57:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 08:57:01 --> Database Driver Class Initialized
DEBUG - 2020-09-08 08:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 08:57:01 --> Upload Class Initialized
INFO - 2020-09-08 08:57:01 --> Controller Class Initialized
DEBUG - 2020-09-08 08:57:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 08:57:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 08:57:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 08:57:01 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 08:57:01 --> Final output sent to browser
DEBUG - 2020-09-08 08:57:01 --> Total execution time: 0.0598
INFO - 2020-09-08 09:10:41 --> Config Class Initialized
INFO - 2020-09-08 09:10:41 --> Hooks Class Initialized
DEBUG - 2020-09-08 09:10:41 --> UTF-8 Support Enabled
INFO - 2020-09-08 09:10:41 --> Utf8 Class Initialized
INFO - 2020-09-08 09:10:41 --> URI Class Initialized
INFO - 2020-09-08 09:10:41 --> Router Class Initialized
INFO - 2020-09-08 09:10:41 --> Output Class Initialized
INFO - 2020-09-08 09:10:41 --> Security Class Initialized
DEBUG - 2020-09-08 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 09:10:41 --> Input Class Initialized
INFO - 2020-09-08 09:10:41 --> Language Class Initialized
INFO - 2020-09-08 09:10:41 --> Language Class Initialized
INFO - 2020-09-08 09:10:41 --> Config Class Initialized
INFO - 2020-09-08 09:10:41 --> Loader Class Initialized
INFO - 2020-09-08 09:10:41 --> Helper loaded: url_helper
INFO - 2020-09-08 09:10:41 --> Helper loaded: form_helper
INFO - 2020-09-08 09:10:41 --> Helper loaded: file_helper
INFO - 2020-09-08 09:10:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 09:10:41 --> Database Driver Class Initialized
DEBUG - 2020-09-08 09:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 09:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 09:10:41 --> Upload Class Initialized
INFO - 2020-09-08 09:10:41 --> Controller Class Initialized
ERROR - 2020-09-08 09:10:41 --> 404 Page Not Found: /index
INFO - 2020-09-08 09:10:42 --> Config Class Initialized
INFO - 2020-09-08 09:10:42 --> Hooks Class Initialized
DEBUG - 2020-09-08 09:10:42 --> UTF-8 Support Enabled
INFO - 2020-09-08 09:10:42 --> Utf8 Class Initialized
INFO - 2020-09-08 09:10:42 --> URI Class Initialized
DEBUG - 2020-09-08 09:10:42 --> No URI present. Default controller set.
INFO - 2020-09-08 09:10:42 --> Router Class Initialized
INFO - 2020-09-08 09:10:42 --> Output Class Initialized
INFO - 2020-09-08 09:10:42 --> Security Class Initialized
DEBUG - 2020-09-08 09:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 09:10:42 --> Input Class Initialized
INFO - 2020-09-08 09:10:42 --> Language Class Initialized
INFO - 2020-09-08 09:10:42 --> Language Class Initialized
INFO - 2020-09-08 09:10:42 --> Config Class Initialized
INFO - 2020-09-08 09:10:42 --> Loader Class Initialized
INFO - 2020-09-08 09:10:42 --> Helper loaded: url_helper
INFO - 2020-09-08 09:10:42 --> Helper loaded: form_helper
INFO - 2020-09-08 09:10:42 --> Helper loaded: file_helper
INFO - 2020-09-08 09:10:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 09:10:42 --> Database Driver Class Initialized
DEBUG - 2020-09-08 09:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 09:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 09:10:42 --> Upload Class Initialized
INFO - 2020-09-08 09:10:42 --> Controller Class Initialized
DEBUG - 2020-09-08 09:10:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 09:10:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 09:10:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 09:10:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 09:10:42 --> Final output sent to browser
DEBUG - 2020-09-08 09:10:42 --> Total execution time: 0.0407
INFO - 2020-09-08 09:17:49 --> Config Class Initialized
INFO - 2020-09-08 09:17:49 --> Hooks Class Initialized
DEBUG - 2020-09-08 09:17:49 --> UTF-8 Support Enabled
INFO - 2020-09-08 09:17:49 --> Utf8 Class Initialized
INFO - 2020-09-08 09:17:49 --> URI Class Initialized
DEBUG - 2020-09-08 09:17:49 --> No URI present. Default controller set.
INFO - 2020-09-08 09:17:49 --> Router Class Initialized
INFO - 2020-09-08 09:17:49 --> Output Class Initialized
INFO - 2020-09-08 09:17:49 --> Security Class Initialized
DEBUG - 2020-09-08 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 09:17:49 --> Input Class Initialized
INFO - 2020-09-08 09:17:49 --> Language Class Initialized
INFO - 2020-09-08 09:17:49 --> Language Class Initialized
INFO - 2020-09-08 09:17:49 --> Config Class Initialized
INFO - 2020-09-08 09:17:49 --> Loader Class Initialized
INFO - 2020-09-08 09:17:49 --> Helper loaded: url_helper
INFO - 2020-09-08 09:17:49 --> Helper loaded: form_helper
INFO - 2020-09-08 09:17:49 --> Helper loaded: file_helper
INFO - 2020-09-08 09:17:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 09:17:49 --> Database Driver Class Initialized
DEBUG - 2020-09-08 09:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 09:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 09:17:49 --> Upload Class Initialized
INFO - 2020-09-08 09:17:49 --> Controller Class Initialized
DEBUG - 2020-09-08 09:17:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 09:17:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 09:17:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 09:17:49 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 09:17:49 --> Final output sent to browser
DEBUG - 2020-09-08 09:17:49 --> Total execution time: 0.0548
INFO - 2020-09-08 09:20:40 --> Config Class Initialized
INFO - 2020-09-08 09:20:40 --> Hooks Class Initialized
DEBUG - 2020-09-08 09:20:40 --> UTF-8 Support Enabled
INFO - 2020-09-08 09:20:40 --> Utf8 Class Initialized
INFO - 2020-09-08 09:20:40 --> URI Class Initialized
DEBUG - 2020-09-08 09:20:40 --> No URI present. Default controller set.
INFO - 2020-09-08 09:20:40 --> Router Class Initialized
INFO - 2020-09-08 09:20:40 --> Output Class Initialized
INFO - 2020-09-08 09:20:40 --> Security Class Initialized
DEBUG - 2020-09-08 09:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 09:20:40 --> Input Class Initialized
INFO - 2020-09-08 09:20:40 --> Language Class Initialized
INFO - 2020-09-08 09:20:40 --> Language Class Initialized
INFO - 2020-09-08 09:20:40 --> Config Class Initialized
INFO - 2020-09-08 09:20:40 --> Loader Class Initialized
INFO - 2020-09-08 09:20:40 --> Helper loaded: url_helper
INFO - 2020-09-08 09:20:40 --> Helper loaded: form_helper
INFO - 2020-09-08 09:20:40 --> Helper loaded: file_helper
INFO - 2020-09-08 09:20:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 09:20:40 --> Database Driver Class Initialized
DEBUG - 2020-09-08 09:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 09:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 09:20:40 --> Upload Class Initialized
INFO - 2020-09-08 09:20:40 --> Controller Class Initialized
DEBUG - 2020-09-08 09:20:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 09:20:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 09:20:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 09:20:40 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 09:20:40 --> Final output sent to browser
DEBUG - 2020-09-08 09:20:40 --> Total execution time: 0.0513
INFO - 2020-09-08 11:43:44 --> Config Class Initialized
INFO - 2020-09-08 11:43:44 --> Hooks Class Initialized
DEBUG - 2020-09-08 11:43:44 --> UTF-8 Support Enabled
INFO - 2020-09-08 11:43:44 --> Utf8 Class Initialized
INFO - 2020-09-08 11:43:44 --> URI Class Initialized
INFO - 2020-09-08 11:43:44 --> Router Class Initialized
INFO - 2020-09-08 11:43:44 --> Output Class Initialized
INFO - 2020-09-08 11:43:44 --> Security Class Initialized
DEBUG - 2020-09-08 11:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 11:43:44 --> Input Class Initialized
INFO - 2020-09-08 11:43:44 --> Language Class Initialized
INFO - 2020-09-08 11:43:44 --> Language Class Initialized
INFO - 2020-09-08 11:43:44 --> Config Class Initialized
INFO - 2020-09-08 11:43:44 --> Loader Class Initialized
INFO - 2020-09-08 11:43:44 --> Helper loaded: url_helper
INFO - 2020-09-08 11:43:44 --> Helper loaded: form_helper
INFO - 2020-09-08 11:43:44 --> Helper loaded: file_helper
INFO - 2020-09-08 11:43:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 11:43:44 --> Database Driver Class Initialized
DEBUG - 2020-09-08 11:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 11:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 11:43:44 --> Upload Class Initialized
INFO - 2020-09-08 11:43:44 --> Controller Class Initialized
DEBUG - 2020-09-08 11:43:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 11:43:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-08 11:43:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 11:43:44 --> Final output sent to browser
DEBUG - 2020-09-08 11:43:44 --> Total execution time: 0.5640
INFO - 2020-09-08 11:43:47 --> Config Class Initialized
INFO - 2020-09-08 11:43:47 --> Hooks Class Initialized
DEBUG - 2020-09-08 11:43:47 --> UTF-8 Support Enabled
INFO - 2020-09-08 11:43:47 --> Utf8 Class Initialized
INFO - 2020-09-08 11:43:47 --> URI Class Initialized
INFO - 2020-09-08 11:43:47 --> Router Class Initialized
INFO - 2020-09-08 11:43:47 --> Output Class Initialized
INFO - 2020-09-08 11:43:47 --> Security Class Initialized
DEBUG - 2020-09-08 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 11:43:47 --> Input Class Initialized
INFO - 2020-09-08 11:43:47 --> Language Class Initialized
INFO - 2020-09-08 11:43:47 --> Language Class Initialized
INFO - 2020-09-08 11:43:47 --> Config Class Initialized
INFO - 2020-09-08 11:43:47 --> Loader Class Initialized
INFO - 2020-09-08 11:43:47 --> Helper loaded: url_helper
INFO - 2020-09-08 11:43:47 --> Helper loaded: form_helper
INFO - 2020-09-08 11:43:47 --> Helper loaded: file_helper
INFO - 2020-09-08 11:43:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 11:43:47 --> Database Driver Class Initialized
DEBUG - 2020-09-08 11:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 11:43:47 --> Upload Class Initialized
INFO - 2020-09-08 11:43:47 --> Controller Class Initialized
ERROR - 2020-09-08 11:43:47 --> 404 Page Not Found: /index
INFO - 2020-09-08 12:26:54 --> Config Class Initialized
INFO - 2020-09-08 12:26:54 --> Hooks Class Initialized
DEBUG - 2020-09-08 12:26:54 --> UTF-8 Support Enabled
INFO - 2020-09-08 12:26:54 --> Utf8 Class Initialized
INFO - 2020-09-08 12:26:54 --> URI Class Initialized
DEBUG - 2020-09-08 12:26:54 --> No URI present. Default controller set.
INFO - 2020-09-08 12:26:54 --> Router Class Initialized
INFO - 2020-09-08 12:26:54 --> Output Class Initialized
INFO - 2020-09-08 12:26:54 --> Security Class Initialized
DEBUG - 2020-09-08 12:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 12:26:54 --> Input Class Initialized
INFO - 2020-09-08 12:26:54 --> Language Class Initialized
INFO - 2020-09-08 12:26:54 --> Language Class Initialized
INFO - 2020-09-08 12:26:54 --> Config Class Initialized
INFO - 2020-09-08 12:26:54 --> Loader Class Initialized
INFO - 2020-09-08 12:26:54 --> Helper loaded: url_helper
INFO - 2020-09-08 12:26:54 --> Helper loaded: form_helper
INFO - 2020-09-08 12:26:54 --> Helper loaded: file_helper
INFO - 2020-09-08 12:26:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 12:26:54 --> Database Driver Class Initialized
DEBUG - 2020-09-08 12:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 12:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 12:26:54 --> Upload Class Initialized
INFO - 2020-09-08 12:26:54 --> Controller Class Initialized
DEBUG - 2020-09-08 12:26:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 12:26:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 12:26:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 12:26:54 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 12:26:54 --> Final output sent to browser
DEBUG - 2020-09-08 12:26:54 --> Total execution time: 0.7839
INFO - 2020-09-08 12:26:56 --> Config Class Initialized
INFO - 2020-09-08 12:26:56 --> Hooks Class Initialized
DEBUG - 2020-09-08 12:26:56 --> UTF-8 Support Enabled
INFO - 2020-09-08 12:26:56 --> Utf8 Class Initialized
INFO - 2020-09-08 12:26:56 --> URI Class Initialized
INFO - 2020-09-08 12:26:56 --> Router Class Initialized
INFO - 2020-09-08 12:26:56 --> Output Class Initialized
INFO - 2020-09-08 12:26:56 --> Security Class Initialized
DEBUG - 2020-09-08 12:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 12:26:56 --> Input Class Initialized
INFO - 2020-09-08 12:26:56 --> Language Class Initialized
INFO - 2020-09-08 12:26:56 --> Language Class Initialized
INFO - 2020-09-08 12:26:56 --> Config Class Initialized
INFO - 2020-09-08 12:26:56 --> Loader Class Initialized
INFO - 2020-09-08 12:26:56 --> Helper loaded: url_helper
INFO - 2020-09-08 12:26:56 --> Helper loaded: form_helper
INFO - 2020-09-08 12:26:56 --> Helper loaded: file_helper
INFO - 2020-09-08 12:26:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 12:26:56 --> Database Driver Class Initialized
DEBUG - 2020-09-08 12:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 12:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 12:26:56 --> Upload Class Initialized
INFO - 2020-09-08 12:26:56 --> Controller Class Initialized
ERROR - 2020-09-08 12:26:56 --> 404 Page Not Found: /index
INFO - 2020-09-08 12:41:15 --> Config Class Initialized
INFO - 2020-09-08 12:41:15 --> Hooks Class Initialized
DEBUG - 2020-09-08 12:41:15 --> UTF-8 Support Enabled
INFO - 2020-09-08 12:41:15 --> Utf8 Class Initialized
INFO - 2020-09-08 12:41:15 --> URI Class Initialized
DEBUG - 2020-09-08 12:41:15 --> No URI present. Default controller set.
INFO - 2020-09-08 12:41:15 --> Router Class Initialized
INFO - 2020-09-08 12:41:15 --> Output Class Initialized
INFO - 2020-09-08 12:41:15 --> Security Class Initialized
DEBUG - 2020-09-08 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 12:41:15 --> Input Class Initialized
INFO - 2020-09-08 12:41:15 --> Language Class Initialized
INFO - 2020-09-08 12:41:15 --> Language Class Initialized
INFO - 2020-09-08 12:41:15 --> Config Class Initialized
INFO - 2020-09-08 12:41:15 --> Loader Class Initialized
INFO - 2020-09-08 12:41:15 --> Helper loaded: url_helper
INFO - 2020-09-08 12:41:15 --> Helper loaded: form_helper
INFO - 2020-09-08 12:41:15 --> Helper loaded: file_helper
INFO - 2020-09-08 12:41:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 12:41:15 --> Database Driver Class Initialized
DEBUG - 2020-09-08 12:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 12:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 12:41:15 --> Upload Class Initialized
INFO - 2020-09-08 12:41:15 --> Controller Class Initialized
DEBUG - 2020-09-08 12:41:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 12:41:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 12:41:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 12:41:15 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 12:41:15 --> Final output sent to browser
DEBUG - 2020-09-08 12:41:15 --> Total execution time: 0.0467
INFO - 2020-09-08 12:41:16 --> Config Class Initialized
INFO - 2020-09-08 12:41:16 --> Hooks Class Initialized
DEBUG - 2020-09-08 12:41:16 --> UTF-8 Support Enabled
INFO - 2020-09-08 12:41:16 --> Utf8 Class Initialized
INFO - 2020-09-08 12:41:16 --> URI Class Initialized
DEBUG - 2020-09-08 12:41:16 --> No URI present. Default controller set.
INFO - 2020-09-08 12:41:16 --> Router Class Initialized
INFO - 2020-09-08 12:41:16 --> Output Class Initialized
INFO - 2020-09-08 12:41:16 --> Security Class Initialized
DEBUG - 2020-09-08 12:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 12:41:16 --> Input Class Initialized
INFO - 2020-09-08 12:41:16 --> Language Class Initialized
INFO - 2020-09-08 12:41:16 --> Language Class Initialized
INFO - 2020-09-08 12:41:16 --> Config Class Initialized
INFO - 2020-09-08 12:41:16 --> Loader Class Initialized
INFO - 2020-09-08 12:41:16 --> Helper loaded: url_helper
INFO - 2020-09-08 12:41:16 --> Helper loaded: form_helper
INFO - 2020-09-08 12:41:16 --> Helper loaded: file_helper
INFO - 2020-09-08 12:41:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 12:41:16 --> Database Driver Class Initialized
DEBUG - 2020-09-08 12:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 12:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 12:41:16 --> Upload Class Initialized
INFO - 2020-09-08 12:41:16 --> Controller Class Initialized
DEBUG - 2020-09-08 12:41:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 12:41:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 12:41:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 12:41:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 12:41:16 --> Final output sent to browser
DEBUG - 2020-09-08 12:41:16 --> Total execution time: 0.0378
INFO - 2020-09-08 13:04:59 --> Config Class Initialized
INFO - 2020-09-08 13:04:59 --> Hooks Class Initialized
DEBUG - 2020-09-08 13:04:59 --> UTF-8 Support Enabled
INFO - 2020-09-08 13:04:59 --> Utf8 Class Initialized
INFO - 2020-09-08 13:04:59 --> URI Class Initialized
INFO - 2020-09-08 13:04:59 --> Router Class Initialized
INFO - 2020-09-08 13:04:59 --> Output Class Initialized
INFO - 2020-09-08 13:04:59 --> Security Class Initialized
DEBUG - 2020-09-08 13:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 13:04:59 --> Input Class Initialized
INFO - 2020-09-08 13:04:59 --> Language Class Initialized
INFO - 2020-09-08 13:04:59 --> Language Class Initialized
INFO - 2020-09-08 13:04:59 --> Config Class Initialized
INFO - 2020-09-08 13:04:59 --> Loader Class Initialized
INFO - 2020-09-08 13:04:59 --> Helper loaded: url_helper
INFO - 2020-09-08 13:04:59 --> Helper loaded: form_helper
INFO - 2020-09-08 13:04:59 --> Helper loaded: file_helper
INFO - 2020-09-08 13:04:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 13:04:59 --> Database Driver Class Initialized
DEBUG - 2020-09-08 13:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 13:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 13:04:59 --> Upload Class Initialized
INFO - 2020-09-08 13:05:00 --> Controller Class Initialized
ERROR - 2020-09-08 13:05:00 --> 404 Page Not Found: /index
INFO - 2020-09-08 15:22:50 --> Config Class Initialized
INFO - 2020-09-08 15:22:50 --> Hooks Class Initialized
DEBUG - 2020-09-08 15:22:50 --> UTF-8 Support Enabled
INFO - 2020-09-08 15:22:50 --> Utf8 Class Initialized
INFO - 2020-09-08 15:22:50 --> URI Class Initialized
INFO - 2020-09-08 15:22:51 --> Router Class Initialized
INFO - 2020-09-08 15:22:51 --> Output Class Initialized
INFO - 2020-09-08 15:22:51 --> Security Class Initialized
DEBUG - 2020-09-08 15:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 15:22:51 --> Input Class Initialized
INFO - 2020-09-08 15:22:51 --> Language Class Initialized
INFO - 2020-09-08 15:22:51 --> Language Class Initialized
INFO - 2020-09-08 15:22:51 --> Config Class Initialized
INFO - 2020-09-08 15:22:51 --> Loader Class Initialized
INFO - 2020-09-08 15:22:51 --> Helper loaded: url_helper
INFO - 2020-09-08 15:22:51 --> Helper loaded: form_helper
INFO - 2020-09-08 15:22:51 --> Helper loaded: file_helper
INFO - 2020-09-08 15:22:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 15:22:51 --> Database Driver Class Initialized
DEBUG - 2020-09-08 15:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 15:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 15:22:51 --> Upload Class Initialized
INFO - 2020-09-08 15:22:51 --> Controller Class Initialized
ERROR - 2020-09-08 15:22:51 --> 404 Page Not Found: /index
INFO - 2020-09-08 15:26:12 --> Config Class Initialized
INFO - 2020-09-08 15:26:12 --> Hooks Class Initialized
DEBUG - 2020-09-08 15:26:12 --> UTF-8 Support Enabled
INFO - 2020-09-08 15:26:12 --> Utf8 Class Initialized
INFO - 2020-09-08 15:26:12 --> URI Class Initialized
INFO - 2020-09-08 15:26:12 --> Router Class Initialized
INFO - 2020-09-08 15:26:12 --> Output Class Initialized
INFO - 2020-09-08 15:26:12 --> Security Class Initialized
DEBUG - 2020-09-08 15:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 15:26:12 --> Input Class Initialized
INFO - 2020-09-08 15:26:12 --> Language Class Initialized
INFO - 2020-09-08 15:26:12 --> Language Class Initialized
INFO - 2020-09-08 15:26:12 --> Config Class Initialized
INFO - 2020-09-08 15:26:12 --> Loader Class Initialized
INFO - 2020-09-08 15:26:12 --> Helper loaded: url_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: form_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: file_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 15:26:12 --> Database Driver Class Initialized
DEBUG - 2020-09-08 15:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 15:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 15:26:12 --> Upload Class Initialized
INFO - 2020-09-08 15:26:12 --> Controller Class Initialized
ERROR - 2020-09-08 15:26:12 --> 404 Page Not Found: /index
INFO - 2020-09-08 15:26:12 --> Config Class Initialized
INFO - 2020-09-08 15:26:12 --> Hooks Class Initialized
DEBUG - 2020-09-08 15:26:12 --> UTF-8 Support Enabled
INFO - 2020-09-08 15:26:12 --> Utf8 Class Initialized
INFO - 2020-09-08 15:26:12 --> URI Class Initialized
INFO - 2020-09-08 15:26:12 --> Router Class Initialized
INFO - 2020-09-08 15:26:12 --> Output Class Initialized
INFO - 2020-09-08 15:26:12 --> Security Class Initialized
DEBUG - 2020-09-08 15:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 15:26:12 --> Input Class Initialized
INFO - 2020-09-08 15:26:12 --> Language Class Initialized
INFO - 2020-09-08 15:26:12 --> Language Class Initialized
INFO - 2020-09-08 15:26:12 --> Config Class Initialized
INFO - 2020-09-08 15:26:12 --> Loader Class Initialized
INFO - 2020-09-08 15:26:12 --> Helper loaded: url_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: form_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: file_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 15:26:12 --> Database Driver Class Initialized
DEBUG - 2020-09-08 15:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 15:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 15:26:12 --> Upload Class Initialized
INFO - 2020-09-08 15:26:12 --> Controller Class Initialized
ERROR - 2020-09-08 15:26:12 --> 404 Page Not Found: /index
INFO - 2020-09-08 15:26:12 --> Config Class Initialized
INFO - 2020-09-08 15:26:12 --> Hooks Class Initialized
DEBUG - 2020-09-08 15:26:12 --> UTF-8 Support Enabled
INFO - 2020-09-08 15:26:12 --> Utf8 Class Initialized
INFO - 2020-09-08 15:26:12 --> URI Class Initialized
INFO - 2020-09-08 15:26:12 --> Router Class Initialized
INFO - 2020-09-08 15:26:12 --> Output Class Initialized
INFO - 2020-09-08 15:26:12 --> Security Class Initialized
DEBUG - 2020-09-08 15:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 15:26:12 --> Input Class Initialized
INFO - 2020-09-08 15:26:12 --> Language Class Initialized
INFO - 2020-09-08 15:26:12 --> Language Class Initialized
INFO - 2020-09-08 15:26:12 --> Config Class Initialized
INFO - 2020-09-08 15:26:12 --> Loader Class Initialized
INFO - 2020-09-08 15:26:12 --> Helper loaded: url_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: form_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: file_helper
INFO - 2020-09-08 15:26:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 15:26:12 --> Database Driver Class Initialized
DEBUG - 2020-09-08 15:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 15:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 15:26:12 --> Upload Class Initialized
INFO - 2020-09-08 15:26:12 --> Controller Class Initialized
ERROR - 2020-09-08 15:26:12 --> 404 Page Not Found: /index
INFO - 2020-09-08 15:26:13 --> Config Class Initialized
INFO - 2020-09-08 15:26:13 --> Hooks Class Initialized
DEBUG - 2020-09-08 15:26:13 --> UTF-8 Support Enabled
INFO - 2020-09-08 15:26:13 --> Utf8 Class Initialized
INFO - 2020-09-08 15:26:13 --> URI Class Initialized
DEBUG - 2020-09-08 15:26:13 --> No URI present. Default controller set.
INFO - 2020-09-08 15:26:13 --> Router Class Initialized
INFO - 2020-09-08 15:26:13 --> Output Class Initialized
INFO - 2020-09-08 15:26:13 --> Security Class Initialized
DEBUG - 2020-09-08 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 15:26:13 --> Input Class Initialized
INFO - 2020-09-08 15:26:13 --> Language Class Initialized
INFO - 2020-09-08 15:26:13 --> Language Class Initialized
INFO - 2020-09-08 15:26:13 --> Config Class Initialized
INFO - 2020-09-08 15:26:13 --> Loader Class Initialized
INFO - 2020-09-08 15:26:13 --> Helper loaded: url_helper
INFO - 2020-09-08 15:26:13 --> Helper loaded: form_helper
INFO - 2020-09-08 15:26:13 --> Helper loaded: file_helper
INFO - 2020-09-08 15:26:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 15:26:13 --> Database Driver Class Initialized
DEBUG - 2020-09-08 15:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 15:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 15:26:13 --> Upload Class Initialized
INFO - 2020-09-08 15:26:13 --> Controller Class Initialized
DEBUG - 2020-09-08 15:26:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 15:26:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 15:26:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 15:26:13 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 15:26:13 --> Final output sent to browser
DEBUG - 2020-09-08 15:26:13 --> Total execution time: 0.1357
INFO - 2020-09-08 15:32:34 --> Config Class Initialized
INFO - 2020-09-08 15:32:34 --> Hooks Class Initialized
DEBUG - 2020-09-08 15:32:34 --> UTF-8 Support Enabled
INFO - 2020-09-08 15:32:34 --> Utf8 Class Initialized
INFO - 2020-09-08 15:32:34 --> URI Class Initialized
INFO - 2020-09-08 15:32:34 --> Router Class Initialized
INFO - 2020-09-08 15:32:34 --> Output Class Initialized
INFO - 2020-09-08 15:32:34 --> Security Class Initialized
DEBUG - 2020-09-08 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 15:32:34 --> Input Class Initialized
INFO - 2020-09-08 15:32:34 --> Language Class Initialized
INFO - 2020-09-08 15:32:34 --> Language Class Initialized
INFO - 2020-09-08 15:32:34 --> Config Class Initialized
INFO - 2020-09-08 15:32:34 --> Loader Class Initialized
INFO - 2020-09-08 15:32:34 --> Helper loaded: url_helper
INFO - 2020-09-08 15:32:34 --> Helper loaded: form_helper
INFO - 2020-09-08 15:32:34 --> Helper loaded: file_helper
INFO - 2020-09-08 15:32:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 15:32:34 --> Database Driver Class Initialized
DEBUG - 2020-09-08 15:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 15:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 15:32:34 --> Upload Class Initialized
INFO - 2020-09-08 15:32:34 --> Controller Class Initialized
ERROR - 2020-09-08 15:32:34 --> 404 Page Not Found: /index
INFO - 2020-09-08 16:49:20 --> Config Class Initialized
INFO - 2020-09-08 16:49:20 --> Hooks Class Initialized
DEBUG - 2020-09-08 16:49:20 --> UTF-8 Support Enabled
INFO - 2020-09-08 16:49:20 --> Utf8 Class Initialized
INFO - 2020-09-08 16:49:20 --> URI Class Initialized
DEBUG - 2020-09-08 16:49:20 --> No URI present. Default controller set.
INFO - 2020-09-08 16:49:20 --> Router Class Initialized
INFO - 2020-09-08 16:49:20 --> Output Class Initialized
INFO - 2020-09-08 16:49:20 --> Security Class Initialized
DEBUG - 2020-09-08 16:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 16:49:20 --> Input Class Initialized
INFO - 2020-09-08 16:49:20 --> Language Class Initialized
INFO - 2020-09-08 16:49:20 --> Language Class Initialized
INFO - 2020-09-08 16:49:20 --> Config Class Initialized
INFO - 2020-09-08 16:49:20 --> Loader Class Initialized
INFO - 2020-09-08 16:49:20 --> Helper loaded: url_helper
INFO - 2020-09-08 16:49:20 --> Helper loaded: form_helper
INFO - 2020-09-08 16:49:20 --> Helper loaded: file_helper
INFO - 2020-09-08 16:49:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 16:49:20 --> Database Driver Class Initialized
DEBUG - 2020-09-08 16:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 16:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 16:49:20 --> Upload Class Initialized
INFO - 2020-09-08 16:49:20 --> Controller Class Initialized
DEBUG - 2020-09-08 16:49:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 16:49:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 16:49:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 16:49:20 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 16:49:20 --> Final output sent to browser
DEBUG - 2020-09-08 16:49:20 --> Total execution time: 0.4206
INFO - 2020-09-08 16:49:22 --> Config Class Initialized
INFO - 2020-09-08 16:49:22 --> Hooks Class Initialized
DEBUG - 2020-09-08 16:49:22 --> UTF-8 Support Enabled
INFO - 2020-09-08 16:49:22 --> Utf8 Class Initialized
INFO - 2020-09-08 16:49:22 --> URI Class Initialized
INFO - 2020-09-08 16:49:22 --> Router Class Initialized
INFO - 2020-09-08 16:49:22 --> Output Class Initialized
INFO - 2020-09-08 16:49:22 --> Security Class Initialized
DEBUG - 2020-09-08 16:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 16:49:22 --> Input Class Initialized
INFO - 2020-09-08 16:49:22 --> Language Class Initialized
INFO - 2020-09-08 16:49:22 --> Language Class Initialized
INFO - 2020-09-08 16:49:22 --> Config Class Initialized
INFO - 2020-09-08 16:49:22 --> Loader Class Initialized
INFO - 2020-09-08 16:49:22 --> Helper loaded: url_helper
INFO - 2020-09-08 16:49:22 --> Helper loaded: form_helper
INFO - 2020-09-08 16:49:22 --> Helper loaded: file_helper
INFO - 2020-09-08 16:49:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 16:49:22 --> Database Driver Class Initialized
DEBUG - 2020-09-08 16:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 16:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 16:49:22 --> Upload Class Initialized
INFO - 2020-09-08 16:49:22 --> Controller Class Initialized
ERROR - 2020-09-08 16:49:22 --> 404 Page Not Found: /index
INFO - 2020-09-08 18:46:04 --> Config Class Initialized
INFO - 2020-09-08 18:46:04 --> Hooks Class Initialized
DEBUG - 2020-09-08 18:46:04 --> UTF-8 Support Enabled
INFO - 2020-09-08 18:46:04 --> Utf8 Class Initialized
INFO - 2020-09-08 18:46:04 --> URI Class Initialized
INFO - 2020-09-08 18:46:04 --> Router Class Initialized
INFO - 2020-09-08 18:46:04 --> Output Class Initialized
INFO - 2020-09-08 18:46:04 --> Security Class Initialized
DEBUG - 2020-09-08 18:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 18:46:04 --> Input Class Initialized
INFO - 2020-09-08 18:46:04 --> Language Class Initialized
INFO - 2020-09-08 18:46:04 --> Language Class Initialized
INFO - 2020-09-08 18:46:04 --> Config Class Initialized
INFO - 2020-09-08 18:46:04 --> Loader Class Initialized
INFO - 2020-09-08 18:46:04 --> Helper loaded: url_helper
INFO - 2020-09-08 18:46:04 --> Helper loaded: form_helper
INFO - 2020-09-08 18:46:04 --> Helper loaded: file_helper
INFO - 2020-09-08 18:46:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 18:46:04 --> Database Driver Class Initialized
DEBUG - 2020-09-08 18:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 18:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 18:46:04 --> Upload Class Initialized
INFO - 2020-09-08 18:46:05 --> Controller Class Initialized
ERROR - 2020-09-08 18:46:05 --> 404 Page Not Found: /index
INFO - 2020-09-08 18:46:07 --> Config Class Initialized
INFO - 2020-09-08 18:46:07 --> Hooks Class Initialized
DEBUG - 2020-09-08 18:46:07 --> UTF-8 Support Enabled
INFO - 2020-09-08 18:46:07 --> Utf8 Class Initialized
INFO - 2020-09-08 18:46:07 --> URI Class Initialized
INFO - 2020-09-08 18:46:07 --> Router Class Initialized
INFO - 2020-09-08 18:46:07 --> Output Class Initialized
INFO - 2020-09-08 18:46:07 --> Security Class Initialized
DEBUG - 2020-09-08 18:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 18:46:07 --> Input Class Initialized
INFO - 2020-09-08 18:46:07 --> Language Class Initialized
INFO - 2020-09-08 18:46:07 --> Language Class Initialized
INFO - 2020-09-08 18:46:07 --> Config Class Initialized
INFO - 2020-09-08 18:46:07 --> Loader Class Initialized
INFO - 2020-09-08 18:46:07 --> Helper loaded: url_helper
INFO - 2020-09-08 18:46:07 --> Helper loaded: form_helper
INFO - 2020-09-08 18:46:07 --> Helper loaded: file_helper
INFO - 2020-09-08 18:46:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 18:46:07 --> Database Driver Class Initialized
DEBUG - 2020-09-08 18:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 18:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 18:46:07 --> Upload Class Initialized
INFO - 2020-09-08 18:46:07 --> Controller Class Initialized
DEBUG - 2020-09-08 18:46:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 18:46:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-08 18:46:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 18:46:07 --> Final output sent to browser
DEBUG - 2020-09-08 18:46:07 --> Total execution time: 0.1071
INFO - 2020-09-08 19:42:07 --> Config Class Initialized
INFO - 2020-09-08 19:42:07 --> Hooks Class Initialized
DEBUG - 2020-09-08 19:42:07 --> UTF-8 Support Enabled
INFO - 2020-09-08 19:42:07 --> Utf8 Class Initialized
INFO - 2020-09-08 19:42:07 --> URI Class Initialized
DEBUG - 2020-09-08 19:42:07 --> No URI present. Default controller set.
INFO - 2020-09-08 19:42:07 --> Router Class Initialized
INFO - 2020-09-08 19:42:07 --> Output Class Initialized
INFO - 2020-09-08 19:42:07 --> Security Class Initialized
DEBUG - 2020-09-08 19:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 19:42:07 --> Input Class Initialized
INFO - 2020-09-08 19:42:07 --> Language Class Initialized
INFO - 2020-09-08 19:42:07 --> Language Class Initialized
INFO - 2020-09-08 19:42:07 --> Config Class Initialized
INFO - 2020-09-08 19:42:07 --> Loader Class Initialized
INFO - 2020-09-08 19:42:07 --> Helper loaded: url_helper
INFO - 2020-09-08 19:42:07 --> Helper loaded: form_helper
INFO - 2020-09-08 19:42:07 --> Helper loaded: file_helper
INFO - 2020-09-08 19:42:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 19:42:07 --> Database Driver Class Initialized
DEBUG - 2020-09-08 19:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 19:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 19:42:07 --> Upload Class Initialized
INFO - 2020-09-08 19:42:07 --> Controller Class Initialized
DEBUG - 2020-09-08 19:42:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 19:42:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 19:42:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 19:42:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 19:42:07 --> Final output sent to browser
DEBUG - 2020-09-08 19:42:07 --> Total execution time: 0.0767
INFO - 2020-09-08 19:42:12 --> Config Class Initialized
INFO - 2020-09-08 19:42:12 --> Hooks Class Initialized
DEBUG - 2020-09-08 19:42:12 --> UTF-8 Support Enabled
INFO - 2020-09-08 19:42:12 --> Utf8 Class Initialized
INFO - 2020-09-08 19:42:12 --> URI Class Initialized
INFO - 2020-09-08 19:42:12 --> Router Class Initialized
INFO - 2020-09-08 19:42:12 --> Output Class Initialized
INFO - 2020-09-08 19:42:12 --> Security Class Initialized
DEBUG - 2020-09-08 19:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 19:42:12 --> Input Class Initialized
INFO - 2020-09-08 19:42:12 --> Language Class Initialized
INFO - 2020-09-08 19:42:12 --> Language Class Initialized
INFO - 2020-09-08 19:42:12 --> Config Class Initialized
INFO - 2020-09-08 19:42:12 --> Loader Class Initialized
INFO - 2020-09-08 19:42:12 --> Helper loaded: url_helper
INFO - 2020-09-08 19:42:12 --> Helper loaded: form_helper
INFO - 2020-09-08 19:42:12 --> Helper loaded: file_helper
INFO - 2020-09-08 19:42:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 19:42:12 --> Database Driver Class Initialized
DEBUG - 2020-09-08 19:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 19:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 19:42:12 --> Upload Class Initialized
INFO - 2020-09-08 19:42:12 --> Controller Class Initialized
ERROR - 2020-09-08 19:42:12 --> 404 Page Not Found: /index
INFO - 2020-09-08 19:50:43 --> Config Class Initialized
INFO - 2020-09-08 19:50:44 --> Hooks Class Initialized
DEBUG - 2020-09-08 19:50:44 --> UTF-8 Support Enabled
INFO - 2020-09-08 19:50:44 --> Utf8 Class Initialized
INFO - 2020-09-08 19:50:44 --> URI Class Initialized
DEBUG - 2020-09-08 19:50:44 --> No URI present. Default controller set.
INFO - 2020-09-08 19:50:44 --> Router Class Initialized
INFO - 2020-09-08 19:50:44 --> Output Class Initialized
INFO - 2020-09-08 19:50:44 --> Security Class Initialized
DEBUG - 2020-09-08 19:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 19:50:44 --> Input Class Initialized
INFO - 2020-09-08 19:50:44 --> Language Class Initialized
INFO - 2020-09-08 19:50:44 --> Language Class Initialized
INFO - 2020-09-08 19:50:44 --> Config Class Initialized
INFO - 2020-09-08 19:50:44 --> Loader Class Initialized
INFO - 2020-09-08 19:50:44 --> Helper loaded: url_helper
INFO - 2020-09-08 19:50:44 --> Helper loaded: form_helper
INFO - 2020-09-08 19:50:44 --> Helper loaded: file_helper
INFO - 2020-09-08 19:50:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 19:50:44 --> Database Driver Class Initialized
DEBUG - 2020-09-08 19:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 19:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 19:50:45 --> Upload Class Initialized
INFO - 2020-09-08 19:50:45 --> Controller Class Initialized
DEBUG - 2020-09-08 19:50:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 19:50:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 19:50:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 19:50:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 19:50:45 --> Final output sent to browser
DEBUG - 2020-09-08 19:50:45 --> Total execution time: 1.8750
INFO - 2020-09-08 19:50:47 --> Config Class Initialized
INFO - 2020-09-08 19:50:47 --> Hooks Class Initialized
DEBUG - 2020-09-08 19:50:47 --> UTF-8 Support Enabled
INFO - 2020-09-08 19:50:47 --> Utf8 Class Initialized
INFO - 2020-09-08 19:50:47 --> URI Class Initialized
INFO - 2020-09-08 19:50:47 --> Router Class Initialized
INFO - 2020-09-08 19:50:47 --> Output Class Initialized
INFO - 2020-09-08 19:50:47 --> Security Class Initialized
DEBUG - 2020-09-08 19:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 19:50:47 --> Input Class Initialized
INFO - 2020-09-08 19:50:47 --> Language Class Initialized
INFO - 2020-09-08 19:50:47 --> Language Class Initialized
INFO - 2020-09-08 19:50:47 --> Config Class Initialized
INFO - 2020-09-08 19:50:47 --> Loader Class Initialized
INFO - 2020-09-08 19:50:47 --> Helper loaded: url_helper
INFO - 2020-09-08 19:50:47 --> Helper loaded: form_helper
INFO - 2020-09-08 19:50:47 --> Helper loaded: file_helper
INFO - 2020-09-08 19:50:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 19:50:47 --> Database Driver Class Initialized
DEBUG - 2020-09-08 19:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 19:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 19:50:47 --> Upload Class Initialized
INFO - 2020-09-08 19:50:47 --> Controller Class Initialized
ERROR - 2020-09-08 19:50:47 --> 404 Page Not Found: /index
INFO - 2020-09-08 20:28:41 --> Config Class Initialized
INFO - 2020-09-08 20:28:41 --> Hooks Class Initialized
DEBUG - 2020-09-08 20:28:41 --> UTF-8 Support Enabled
INFO - 2020-09-08 20:28:41 --> Utf8 Class Initialized
INFO - 2020-09-08 20:28:41 --> URI Class Initialized
DEBUG - 2020-09-08 20:28:41 --> No URI present. Default controller set.
INFO - 2020-09-08 20:28:41 --> Router Class Initialized
INFO - 2020-09-08 20:28:41 --> Output Class Initialized
INFO - 2020-09-08 20:28:41 --> Security Class Initialized
DEBUG - 2020-09-08 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 20:28:41 --> Input Class Initialized
INFO - 2020-09-08 20:28:41 --> Language Class Initialized
INFO - 2020-09-08 20:28:41 --> Language Class Initialized
INFO - 2020-09-08 20:28:41 --> Config Class Initialized
INFO - 2020-09-08 20:28:41 --> Loader Class Initialized
INFO - 2020-09-08 20:28:41 --> Helper loaded: url_helper
INFO - 2020-09-08 20:28:41 --> Helper loaded: form_helper
INFO - 2020-09-08 20:28:41 --> Helper loaded: file_helper
INFO - 2020-09-08 20:28:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 20:28:41 --> Database Driver Class Initialized
DEBUG - 2020-09-08 20:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 20:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 20:28:41 --> Upload Class Initialized
INFO - 2020-09-08 20:28:41 --> Controller Class Initialized
DEBUG - 2020-09-08 20:28:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 20:28:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 20:28:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 20:28:41 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 20:28:41 --> Final output sent to browser
DEBUG - 2020-09-08 20:28:41 --> Total execution time: 0.0448
INFO - 2020-09-08 21:35:05 --> Config Class Initialized
INFO - 2020-09-08 21:35:05 --> Hooks Class Initialized
DEBUG - 2020-09-08 21:35:05 --> UTF-8 Support Enabled
INFO - 2020-09-08 21:35:05 --> Utf8 Class Initialized
INFO - 2020-09-08 21:35:05 --> URI Class Initialized
INFO - 2020-09-08 21:35:06 --> Router Class Initialized
INFO - 2020-09-08 21:35:06 --> Output Class Initialized
INFO - 2020-09-08 21:35:06 --> Security Class Initialized
DEBUG - 2020-09-08 21:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 21:35:06 --> Input Class Initialized
INFO - 2020-09-08 21:35:06 --> Language Class Initialized
INFO - 2020-09-08 21:35:06 --> Language Class Initialized
INFO - 2020-09-08 21:35:06 --> Config Class Initialized
INFO - 2020-09-08 21:35:06 --> Loader Class Initialized
INFO - 2020-09-08 21:35:06 --> Helper loaded: url_helper
INFO - 2020-09-08 21:35:06 --> Helper loaded: form_helper
INFO - 2020-09-08 21:35:06 --> Helper loaded: file_helper
INFO - 2020-09-08 21:35:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 21:35:06 --> Database Driver Class Initialized
DEBUG - 2020-09-08 21:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 21:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 21:35:06 --> Upload Class Initialized
INFO - 2020-09-08 21:35:06 --> Controller Class Initialized
ERROR - 2020-09-08 21:35:06 --> 404 Page Not Found: /index
INFO - 2020-09-08 21:35:07 --> Config Class Initialized
INFO - 2020-09-08 21:35:07 --> Hooks Class Initialized
DEBUG - 2020-09-08 21:35:07 --> UTF-8 Support Enabled
INFO - 2020-09-08 21:35:07 --> Utf8 Class Initialized
INFO - 2020-09-08 21:35:07 --> URI Class Initialized
INFO - 2020-09-08 21:35:07 --> Router Class Initialized
INFO - 2020-09-08 21:35:07 --> Output Class Initialized
INFO - 2020-09-08 21:35:07 --> Security Class Initialized
DEBUG - 2020-09-08 21:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 21:35:07 --> Input Class Initialized
INFO - 2020-09-08 21:35:07 --> Language Class Initialized
INFO - 2020-09-08 21:35:07 --> Language Class Initialized
INFO - 2020-09-08 21:35:07 --> Config Class Initialized
INFO - 2020-09-08 21:35:07 --> Loader Class Initialized
INFO - 2020-09-08 21:35:07 --> Helper loaded: url_helper
INFO - 2020-09-08 21:35:07 --> Helper loaded: form_helper
INFO - 2020-09-08 21:35:07 --> Helper loaded: file_helper
INFO - 2020-09-08 21:35:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 21:35:07 --> Database Driver Class Initialized
DEBUG - 2020-09-08 21:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 21:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 21:35:07 --> Upload Class Initialized
INFO - 2020-09-08 21:35:08 --> Controller Class Initialized
ERROR - 2020-09-08 21:35:08 --> 404 Page Not Found: /index
INFO - 2020-09-08 22:19:04 --> Config Class Initialized
INFO - 2020-09-08 22:19:04 --> Hooks Class Initialized
DEBUG - 2020-09-08 22:19:04 --> UTF-8 Support Enabled
INFO - 2020-09-08 22:19:04 --> Utf8 Class Initialized
INFO - 2020-09-08 22:19:04 --> URI Class Initialized
INFO - 2020-09-08 22:19:04 --> Router Class Initialized
INFO - 2020-09-08 22:19:04 --> Output Class Initialized
INFO - 2020-09-08 22:19:04 --> Security Class Initialized
DEBUG - 2020-09-08 22:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 22:19:04 --> Input Class Initialized
INFO - 2020-09-08 22:19:04 --> Language Class Initialized
INFO - 2020-09-08 22:19:04 --> Language Class Initialized
INFO - 2020-09-08 22:19:04 --> Config Class Initialized
INFO - 2020-09-08 22:19:04 --> Loader Class Initialized
INFO - 2020-09-08 22:19:04 --> Helper loaded: url_helper
INFO - 2020-09-08 22:19:04 --> Helper loaded: form_helper
INFO - 2020-09-08 22:19:04 --> Helper loaded: file_helper
INFO - 2020-09-08 22:19:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 22:19:04 --> Database Driver Class Initialized
DEBUG - 2020-09-08 22:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 22:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 22:19:04 --> Upload Class Initialized
INFO - 2020-09-08 22:19:04 --> Controller Class Initialized
ERROR - 2020-09-08 22:19:04 --> 404 Page Not Found: /index
INFO - 2020-09-08 22:19:07 --> Config Class Initialized
INFO - 2020-09-08 22:19:07 --> Hooks Class Initialized
DEBUG - 2020-09-08 22:19:07 --> UTF-8 Support Enabled
INFO - 2020-09-08 22:19:07 --> Utf8 Class Initialized
INFO - 2020-09-08 22:19:07 --> URI Class Initialized
INFO - 2020-09-08 22:19:07 --> Router Class Initialized
INFO - 2020-09-08 22:19:07 --> Output Class Initialized
INFO - 2020-09-08 22:19:07 --> Security Class Initialized
DEBUG - 2020-09-08 22:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 22:19:07 --> Input Class Initialized
INFO - 2020-09-08 22:19:07 --> Language Class Initialized
INFO - 2020-09-08 22:19:07 --> Language Class Initialized
INFO - 2020-09-08 22:19:07 --> Config Class Initialized
INFO - 2020-09-08 22:19:07 --> Loader Class Initialized
INFO - 2020-09-08 22:19:07 --> Helper loaded: url_helper
INFO - 2020-09-08 22:19:07 --> Helper loaded: form_helper
INFO - 2020-09-08 22:19:07 --> Helper loaded: file_helper
INFO - 2020-09-08 22:19:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 22:19:07 --> Database Driver Class Initialized
DEBUG - 2020-09-08 22:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 22:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 22:19:07 --> Upload Class Initialized
INFO - 2020-09-08 22:19:07 --> Controller Class Initialized
DEBUG - 2020-09-08 22:19:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 22:19:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-08 22:19:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 22:19:07 --> Final output sent to browser
DEBUG - 2020-09-08 22:19:07 --> Total execution time: 0.0831
INFO - 2020-09-08 22:52:06 --> Config Class Initialized
INFO - 2020-09-08 22:52:06 --> Hooks Class Initialized
DEBUG - 2020-09-08 22:52:06 --> UTF-8 Support Enabled
INFO - 2020-09-08 22:52:06 --> Utf8 Class Initialized
INFO - 2020-09-08 22:52:06 --> URI Class Initialized
DEBUG - 2020-09-08 22:52:06 --> No URI present. Default controller set.
INFO - 2020-09-08 22:52:06 --> Router Class Initialized
INFO - 2020-09-08 22:52:06 --> Output Class Initialized
INFO - 2020-09-08 22:52:06 --> Security Class Initialized
DEBUG - 2020-09-08 22:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 22:52:06 --> Input Class Initialized
INFO - 2020-09-08 22:52:06 --> Language Class Initialized
INFO - 2020-09-08 22:52:06 --> Language Class Initialized
INFO - 2020-09-08 22:52:06 --> Config Class Initialized
INFO - 2020-09-08 22:52:06 --> Loader Class Initialized
INFO - 2020-09-08 22:52:06 --> Helper loaded: url_helper
INFO - 2020-09-08 22:52:06 --> Helper loaded: form_helper
INFO - 2020-09-08 22:52:06 --> Helper loaded: file_helper
INFO - 2020-09-08 22:52:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 22:52:06 --> Database Driver Class Initialized
DEBUG - 2020-09-08 22:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 22:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 22:52:06 --> Upload Class Initialized
INFO - 2020-09-08 22:52:06 --> Controller Class Initialized
DEBUG - 2020-09-08 22:52:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 22:52:06 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 22:52:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 22:52:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 22:52:07 --> Final output sent to browser
DEBUG - 2020-09-08 22:52:07 --> Total execution time: 0.6251
INFO - 2020-09-08 22:52:07 --> Config Class Initialized
INFO - 2020-09-08 22:52:07 --> Hooks Class Initialized
DEBUG - 2020-09-08 22:52:07 --> UTF-8 Support Enabled
INFO - 2020-09-08 22:52:07 --> Utf8 Class Initialized
INFO - 2020-09-08 22:52:07 --> URI Class Initialized
DEBUG - 2020-09-08 22:52:07 --> No URI present. Default controller set.
INFO - 2020-09-08 22:52:07 --> Router Class Initialized
INFO - 2020-09-08 22:52:07 --> Output Class Initialized
INFO - 2020-09-08 22:52:07 --> Security Class Initialized
DEBUG - 2020-09-08 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 22:52:07 --> Input Class Initialized
INFO - 2020-09-08 22:52:07 --> Language Class Initialized
INFO - 2020-09-08 22:52:07 --> Language Class Initialized
INFO - 2020-09-08 22:52:07 --> Config Class Initialized
INFO - 2020-09-08 22:52:07 --> Loader Class Initialized
INFO - 2020-09-08 22:52:07 --> Helper loaded: url_helper
INFO - 2020-09-08 22:52:07 --> Helper loaded: form_helper
INFO - 2020-09-08 22:52:07 --> Helper loaded: file_helper
INFO - 2020-09-08 22:52:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 22:52:07 --> Database Driver Class Initialized
DEBUG - 2020-09-08 22:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 22:52:07 --> Upload Class Initialized
INFO - 2020-09-08 22:52:07 --> Controller Class Initialized
DEBUG - 2020-09-08 22:52:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-08 22:52:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-08 22:52:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-08 22:52:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-08 22:52:07 --> Final output sent to browser
DEBUG - 2020-09-08 22:52:07 --> Total execution time: 0.0444
INFO - 2020-09-08 23:55:26 --> Config Class Initialized
INFO - 2020-09-08 23:55:26 --> Hooks Class Initialized
DEBUG - 2020-09-08 23:55:26 --> UTF-8 Support Enabled
INFO - 2020-09-08 23:55:26 --> Utf8 Class Initialized
INFO - 2020-09-08 23:55:26 --> URI Class Initialized
INFO - 2020-09-08 23:55:26 --> Router Class Initialized
INFO - 2020-09-08 23:55:26 --> Output Class Initialized
INFO - 2020-09-08 23:55:26 --> Security Class Initialized
DEBUG - 2020-09-08 23:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-08 23:55:26 --> Input Class Initialized
INFO - 2020-09-08 23:55:26 --> Language Class Initialized
INFO - 2020-09-08 23:55:26 --> Language Class Initialized
INFO - 2020-09-08 23:55:26 --> Config Class Initialized
INFO - 2020-09-08 23:55:26 --> Loader Class Initialized
INFO - 2020-09-08 23:55:26 --> Helper loaded: url_helper
INFO - 2020-09-08 23:55:26 --> Helper loaded: form_helper
INFO - 2020-09-08 23:55:26 --> Helper loaded: file_helper
INFO - 2020-09-08 23:55:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-08 23:55:26 --> Database Driver Class Initialized
DEBUG - 2020-09-08 23:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-08 23:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-08 23:55:27 --> Upload Class Initialized
INFO - 2020-09-08 23:55:27 --> Controller Class Initialized
ERROR - 2020-09-08 23:55:27 --> 404 Page Not Found: /index
