<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-09 00:15:16 --> Config Class Initialized
INFO - 2020-09-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 00:15:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 00:15:16 --> Utf8 Class Initialized
INFO - 2020-09-09 00:15:16 --> URI Class Initialized
DEBUG - 2020-09-09 00:15:16 --> No URI present. Default controller set.
INFO - 2020-09-09 00:15:16 --> Router Class Initialized
INFO - 2020-09-09 00:15:16 --> Output Class Initialized
INFO - 2020-09-09 00:15:16 --> Security Class Initialized
DEBUG - 2020-09-09 00:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 00:15:16 --> Input Class Initialized
INFO - 2020-09-09 00:15:16 --> Language Class Initialized
INFO - 2020-09-09 00:15:16 --> Language Class Initialized
INFO - 2020-09-09 00:15:16 --> Config Class Initialized
INFO - 2020-09-09 00:15:16 --> Loader Class Initialized
INFO - 2020-09-09 00:15:16 --> Helper loaded: url_helper
INFO - 2020-09-09 00:15:16 --> Helper loaded: form_helper
INFO - 2020-09-09 00:15:16 --> Helper loaded: file_helper
INFO - 2020-09-09 00:15:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 00:15:16 --> Database Driver Class Initialized
DEBUG - 2020-09-09 00:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 00:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 00:15:16 --> Upload Class Initialized
INFO - 2020-09-09 00:15:16 --> Controller Class Initialized
DEBUG - 2020-09-09 00:15:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 00:15:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 00:15:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 00:15:16 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 00:15:16 --> Final output sent to browser
DEBUG - 2020-09-09 00:15:16 --> Total execution time: 0.2081
INFO - 2020-09-09 00:15:22 --> Config Class Initialized
INFO - 2020-09-09 00:15:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 00:15:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 00:15:22 --> Utf8 Class Initialized
INFO - 2020-09-09 00:15:22 --> URI Class Initialized
INFO - 2020-09-09 00:15:22 --> Router Class Initialized
INFO - 2020-09-09 00:15:22 --> Output Class Initialized
INFO - 2020-09-09 00:15:22 --> Security Class Initialized
DEBUG - 2020-09-09 00:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 00:15:22 --> Input Class Initialized
INFO - 2020-09-09 00:15:22 --> Language Class Initialized
INFO - 2020-09-09 00:15:22 --> Language Class Initialized
INFO - 2020-09-09 00:15:22 --> Config Class Initialized
INFO - 2020-09-09 00:15:22 --> Loader Class Initialized
INFO - 2020-09-09 00:15:22 --> Helper loaded: url_helper
INFO - 2020-09-09 00:15:22 --> Helper loaded: form_helper
INFO - 2020-09-09 00:15:22 --> Helper loaded: file_helper
INFO - 2020-09-09 00:15:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 00:15:22 --> Database Driver Class Initialized
DEBUG - 2020-09-09 00:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 00:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 00:15:22 --> Upload Class Initialized
INFO - 2020-09-09 00:15:22 --> Controller Class Initialized
ERROR - 2020-09-09 00:15:22 --> 404 Page Not Found: /index
INFO - 2020-09-09 01:15:09 --> Config Class Initialized
INFO - 2020-09-09 01:15:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 01:15:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 01:15:09 --> Utf8 Class Initialized
INFO - 2020-09-09 01:15:09 --> URI Class Initialized
DEBUG - 2020-09-09 01:15:09 --> No URI present. Default controller set.
INFO - 2020-09-09 01:15:09 --> Router Class Initialized
INFO - 2020-09-09 01:15:09 --> Output Class Initialized
INFO - 2020-09-09 01:15:09 --> Security Class Initialized
DEBUG - 2020-09-09 01:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 01:15:09 --> Input Class Initialized
INFO - 2020-09-09 01:15:09 --> Language Class Initialized
INFO - 2020-09-09 01:15:09 --> Language Class Initialized
INFO - 2020-09-09 01:15:09 --> Config Class Initialized
INFO - 2020-09-09 01:15:09 --> Loader Class Initialized
INFO - 2020-09-09 01:15:10 --> Helper loaded: url_helper
INFO - 2020-09-09 01:15:10 --> Helper loaded: form_helper
INFO - 2020-09-09 01:15:10 --> Helper loaded: file_helper
INFO - 2020-09-09 01:15:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 01:15:10 --> Database Driver Class Initialized
DEBUG - 2020-09-09 01:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 01:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 01:15:10 --> Upload Class Initialized
INFO - 2020-09-09 01:15:10 --> Controller Class Initialized
DEBUG - 2020-09-09 01:15:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 01:15:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 01:15:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 01:15:10 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 01:15:10 --> Final output sent to browser
DEBUG - 2020-09-09 01:15:10 --> Total execution time: 0.8757
INFO - 2020-09-09 01:15:12 --> Config Class Initialized
INFO - 2020-09-09 01:15:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 01:15:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 01:15:12 --> Utf8 Class Initialized
INFO - 2020-09-09 01:15:12 --> URI Class Initialized
INFO - 2020-09-09 01:15:12 --> Router Class Initialized
INFO - 2020-09-09 01:15:12 --> Output Class Initialized
INFO - 2020-09-09 01:15:12 --> Security Class Initialized
DEBUG - 2020-09-09 01:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 01:15:12 --> Input Class Initialized
INFO - 2020-09-09 01:15:12 --> Language Class Initialized
INFO - 2020-09-09 01:15:12 --> Language Class Initialized
INFO - 2020-09-09 01:15:12 --> Config Class Initialized
INFO - 2020-09-09 01:15:12 --> Loader Class Initialized
INFO - 2020-09-09 01:15:12 --> Helper loaded: url_helper
INFO - 2020-09-09 01:15:12 --> Helper loaded: form_helper
INFO - 2020-09-09 01:15:12 --> Helper loaded: file_helper
INFO - 2020-09-09 01:15:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 01:15:12 --> Database Driver Class Initialized
DEBUG - 2020-09-09 01:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 01:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 01:15:12 --> Upload Class Initialized
INFO - 2020-09-09 01:15:12 --> Controller Class Initialized
ERROR - 2020-09-09 01:15:12 --> 404 Page Not Found: /index
INFO - 2020-09-09 01:18:09 --> Config Class Initialized
INFO - 2020-09-09 01:18:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 01:18:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 01:18:09 --> Utf8 Class Initialized
INFO - 2020-09-09 01:18:09 --> URI Class Initialized
DEBUG - 2020-09-09 01:18:09 --> No URI present. Default controller set.
INFO - 2020-09-09 01:18:09 --> Router Class Initialized
INFO - 2020-09-09 01:18:09 --> Output Class Initialized
INFO - 2020-09-09 01:18:09 --> Security Class Initialized
DEBUG - 2020-09-09 01:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 01:18:09 --> Input Class Initialized
INFO - 2020-09-09 01:18:09 --> Language Class Initialized
INFO - 2020-09-09 01:18:09 --> Language Class Initialized
INFO - 2020-09-09 01:18:09 --> Config Class Initialized
INFO - 2020-09-09 01:18:09 --> Loader Class Initialized
INFO - 2020-09-09 01:18:09 --> Helper loaded: url_helper
INFO - 2020-09-09 01:18:09 --> Helper loaded: form_helper
INFO - 2020-09-09 01:18:09 --> Helper loaded: file_helper
INFO - 2020-09-09 01:18:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 01:18:09 --> Database Driver Class Initialized
DEBUG - 2020-09-09 01:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 01:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 01:18:09 --> Upload Class Initialized
INFO - 2020-09-09 01:18:09 --> Controller Class Initialized
DEBUG - 2020-09-09 01:18:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 01:18:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 01:18:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 01:18:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 01:18:09 --> Final output sent to browser
DEBUG - 2020-09-09 01:18:09 --> Total execution time: 0.0498
INFO - 2020-09-09 01:19:57 --> Config Class Initialized
INFO - 2020-09-09 01:19:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 01:19:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 01:19:57 --> Utf8 Class Initialized
INFO - 2020-09-09 01:19:57 --> URI Class Initialized
DEBUG - 2020-09-09 01:19:57 --> No URI present. Default controller set.
INFO - 2020-09-09 01:19:57 --> Router Class Initialized
INFO - 2020-09-09 01:19:57 --> Output Class Initialized
INFO - 2020-09-09 01:19:57 --> Security Class Initialized
DEBUG - 2020-09-09 01:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 01:19:57 --> Input Class Initialized
INFO - 2020-09-09 01:19:57 --> Language Class Initialized
INFO - 2020-09-09 01:19:57 --> Language Class Initialized
INFO - 2020-09-09 01:19:57 --> Config Class Initialized
INFO - 2020-09-09 01:19:57 --> Loader Class Initialized
INFO - 2020-09-09 01:19:57 --> Helper loaded: url_helper
INFO - 2020-09-09 01:19:57 --> Helper loaded: form_helper
INFO - 2020-09-09 01:19:57 --> Helper loaded: file_helper
INFO - 2020-09-09 01:19:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 01:19:57 --> Database Driver Class Initialized
DEBUG - 2020-09-09 01:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 01:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 01:19:57 --> Upload Class Initialized
INFO - 2020-09-09 01:19:57 --> Controller Class Initialized
DEBUG - 2020-09-09 01:19:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 01:19:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 01:19:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 01:19:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 01:19:57 --> Final output sent to browser
DEBUG - 2020-09-09 01:19:57 --> Total execution time: 0.0465
INFO - 2020-09-09 01:20:04 --> Config Class Initialized
INFO - 2020-09-09 01:20:04 --> Hooks Class Initialized
DEBUG - 2020-09-09 01:20:04 --> UTF-8 Support Enabled
INFO - 2020-09-09 01:20:04 --> Utf8 Class Initialized
INFO - 2020-09-09 01:20:04 --> URI Class Initialized
DEBUG - 2020-09-09 01:20:04 --> No URI present. Default controller set.
INFO - 2020-09-09 01:20:04 --> Router Class Initialized
INFO - 2020-09-09 01:20:04 --> Output Class Initialized
INFO - 2020-09-09 01:20:04 --> Security Class Initialized
DEBUG - 2020-09-09 01:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 01:20:04 --> Input Class Initialized
INFO - 2020-09-09 01:20:04 --> Language Class Initialized
INFO - 2020-09-09 01:20:04 --> Language Class Initialized
INFO - 2020-09-09 01:20:04 --> Config Class Initialized
INFO - 2020-09-09 01:20:04 --> Loader Class Initialized
INFO - 2020-09-09 01:20:04 --> Helper loaded: url_helper
INFO - 2020-09-09 01:20:04 --> Helper loaded: form_helper
INFO - 2020-09-09 01:20:04 --> Helper loaded: file_helper
INFO - 2020-09-09 01:20:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 01:20:04 --> Database Driver Class Initialized
DEBUG - 2020-09-09 01:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 01:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 01:20:04 --> Upload Class Initialized
INFO - 2020-09-09 01:20:04 --> Controller Class Initialized
DEBUG - 2020-09-09 01:20:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 01:20:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 01:20:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 01:20:04 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 01:20:04 --> Final output sent to browser
DEBUG - 2020-09-09 01:20:04 --> Total execution time: 0.2034
INFO - 2020-09-09 02:28:58 --> Config Class Initialized
INFO - 2020-09-09 02:28:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 02:28:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 02:28:58 --> Utf8 Class Initialized
INFO - 2020-09-09 02:28:58 --> URI Class Initialized
DEBUG - 2020-09-09 02:28:58 --> No URI present. Default controller set.
INFO - 2020-09-09 02:28:58 --> Router Class Initialized
INFO - 2020-09-09 02:28:58 --> Output Class Initialized
INFO - 2020-09-09 02:28:58 --> Security Class Initialized
DEBUG - 2020-09-09 02:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 02:28:58 --> Input Class Initialized
INFO - 2020-09-09 02:28:58 --> Language Class Initialized
INFO - 2020-09-09 02:28:58 --> Language Class Initialized
INFO - 2020-09-09 02:28:58 --> Config Class Initialized
INFO - 2020-09-09 02:28:58 --> Loader Class Initialized
INFO - 2020-09-09 02:28:59 --> Helper loaded: url_helper
INFO - 2020-09-09 02:28:59 --> Helper loaded: form_helper
INFO - 2020-09-09 02:28:59 --> Helper loaded: file_helper
INFO - 2020-09-09 02:28:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 02:28:59 --> Database Driver Class Initialized
DEBUG - 2020-09-09 02:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 02:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 02:28:59 --> Upload Class Initialized
INFO - 2020-09-09 02:28:59 --> Controller Class Initialized
DEBUG - 2020-09-09 02:28:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 02:28:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 02:28:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 02:28:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 02:28:59 --> Final output sent to browser
DEBUG - 2020-09-09 02:28:59 --> Total execution time: 1.2731
INFO - 2020-09-09 04:42:17 --> Config Class Initialized
INFO - 2020-09-09 04:42:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 04:42:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 04:42:17 --> Utf8 Class Initialized
INFO - 2020-09-09 04:42:17 --> URI Class Initialized
DEBUG - 2020-09-09 04:42:18 --> No URI present. Default controller set.
INFO - 2020-09-09 04:42:18 --> Router Class Initialized
INFO - 2020-09-09 04:42:18 --> Output Class Initialized
INFO - 2020-09-09 04:42:18 --> Security Class Initialized
DEBUG - 2020-09-09 04:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 04:42:18 --> Input Class Initialized
INFO - 2020-09-09 04:42:18 --> Language Class Initialized
INFO - 2020-09-09 04:42:18 --> Language Class Initialized
INFO - 2020-09-09 04:42:18 --> Config Class Initialized
INFO - 2020-09-09 04:42:18 --> Loader Class Initialized
INFO - 2020-09-09 04:42:18 --> Helper loaded: url_helper
INFO - 2020-09-09 04:42:18 --> Helper loaded: form_helper
INFO - 2020-09-09 04:42:18 --> Helper loaded: file_helper
INFO - 2020-09-09 04:42:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 04:42:18 --> Database Driver Class Initialized
DEBUG - 2020-09-09 04:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 04:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 04:42:18 --> Upload Class Initialized
INFO - 2020-09-09 04:42:18 --> Controller Class Initialized
DEBUG - 2020-09-09 04:42:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 04:42:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 04:42:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 04:42:18 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 04:42:18 --> Final output sent to browser
DEBUG - 2020-09-09 04:42:18 --> Total execution time: 1.5141
INFO - 2020-09-09 04:42:50 --> Config Class Initialized
INFO - 2020-09-09 04:42:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 04:42:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 04:42:50 --> Utf8 Class Initialized
INFO - 2020-09-09 04:42:50 --> URI Class Initialized
DEBUG - 2020-09-09 04:42:50 --> No URI present. Default controller set.
INFO - 2020-09-09 04:42:50 --> Router Class Initialized
INFO - 2020-09-09 04:42:50 --> Output Class Initialized
INFO - 2020-09-09 04:42:50 --> Security Class Initialized
DEBUG - 2020-09-09 04:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 04:42:50 --> Input Class Initialized
INFO - 2020-09-09 04:42:50 --> Language Class Initialized
INFO - 2020-09-09 04:42:50 --> Language Class Initialized
INFO - 2020-09-09 04:42:50 --> Config Class Initialized
INFO - 2020-09-09 04:42:50 --> Loader Class Initialized
INFO - 2020-09-09 04:42:50 --> Helper loaded: url_helper
INFO - 2020-09-09 04:42:50 --> Helper loaded: form_helper
INFO - 2020-09-09 04:42:50 --> Helper loaded: file_helper
INFO - 2020-09-09 04:42:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 04:42:50 --> Database Driver Class Initialized
DEBUG - 2020-09-09 04:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 04:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 04:42:50 --> Upload Class Initialized
INFO - 2020-09-09 04:42:50 --> Controller Class Initialized
DEBUG - 2020-09-09 04:42:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 04:42:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 04:42:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 04:42:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 04:42:50 --> Final output sent to browser
DEBUG - 2020-09-09 04:42:50 --> Total execution time: 0.0501
INFO - 2020-09-09 04:43:08 --> Config Class Initialized
INFO - 2020-09-09 04:43:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 04:43:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 04:43:08 --> Utf8 Class Initialized
INFO - 2020-09-09 04:43:08 --> URI Class Initialized
INFO - 2020-09-09 04:43:08 --> Router Class Initialized
INFO - 2020-09-09 04:43:08 --> Output Class Initialized
INFO - 2020-09-09 04:43:08 --> Security Class Initialized
DEBUG - 2020-09-09 04:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 04:43:08 --> Input Class Initialized
INFO - 2020-09-09 04:43:08 --> Language Class Initialized
INFO - 2020-09-09 04:43:08 --> Language Class Initialized
INFO - 2020-09-09 04:43:08 --> Config Class Initialized
INFO - 2020-09-09 04:43:08 --> Loader Class Initialized
INFO - 2020-09-09 04:43:08 --> Helper loaded: url_helper
INFO - 2020-09-09 04:43:08 --> Helper loaded: form_helper
INFO - 2020-09-09 04:43:08 --> Helper loaded: file_helper
INFO - 2020-09-09 04:43:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 04:43:08 --> Database Driver Class Initialized
DEBUG - 2020-09-09 04:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 04:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 04:43:08 --> Upload Class Initialized
INFO - 2020-09-09 04:43:08 --> Controller Class Initialized
ERROR - 2020-09-09 04:43:08 --> 404 Page Not Found: /index
INFO - 2020-09-09 04:51:10 --> Config Class Initialized
INFO - 2020-09-09 04:51:10 --> Config Class Initialized
INFO - 2020-09-09 04:51:10 --> Hooks Class Initialized
INFO - 2020-09-09 04:51:10 --> Hooks Class Initialized
DEBUG - 2020-09-09 04:51:10 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 04:51:10 --> UTF-8 Support Enabled
INFO - 2020-09-09 04:51:10 --> Utf8 Class Initialized
INFO - 2020-09-09 04:51:10 --> Utf8 Class Initialized
INFO - 2020-09-09 04:51:10 --> URI Class Initialized
INFO - 2020-09-09 04:51:10 --> URI Class Initialized
INFO - 2020-09-09 04:51:10 --> Router Class Initialized
INFO - 2020-09-09 04:51:10 --> Router Class Initialized
INFO - 2020-09-09 04:51:10 --> Output Class Initialized
INFO - 2020-09-09 04:51:10 --> Output Class Initialized
INFO - 2020-09-09 04:51:10 --> Security Class Initialized
INFO - 2020-09-09 04:51:10 --> Security Class Initialized
DEBUG - 2020-09-09 04:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-09 04:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 04:51:10 --> Input Class Initialized
INFO - 2020-09-09 04:51:10 --> Input Class Initialized
INFO - 2020-09-09 04:51:10 --> Language Class Initialized
INFO - 2020-09-09 04:51:10 --> Language Class Initialized
INFO - 2020-09-09 04:51:10 --> Language Class Initialized
INFO - 2020-09-09 04:51:10 --> Language Class Initialized
INFO - 2020-09-09 04:51:10 --> Config Class Initialized
INFO - 2020-09-09 04:51:10 --> Config Class Initialized
INFO - 2020-09-09 04:51:10 --> Loader Class Initialized
INFO - 2020-09-09 04:51:10 --> Loader Class Initialized
INFO - 2020-09-09 04:51:10 --> Helper loaded: url_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: url_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: form_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: form_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: file_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: file_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 04:51:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 04:51:10 --> Database Driver Class Initialized
INFO - 2020-09-09 04:51:10 --> Database Driver Class Initialized
DEBUG - 2020-09-09 04:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-09-09 04:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 04:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 04:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 04:51:10 --> Upload Class Initialized
INFO - 2020-09-09 04:51:10 --> Upload Class Initialized
INFO - 2020-09-09 04:51:10 --> Controller Class Initialized
INFO - 2020-09-09 04:51:10 --> Controller Class Initialized
ERROR - 2020-09-09 04:51:10 --> 404 Page Not Found: /index
ERROR - 2020-09-09 04:51:10 --> 404 Page Not Found: /index
INFO - 2020-09-09 05:40:50 --> Config Class Initialized
INFO - 2020-09-09 05:40:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 05:40:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 05:40:50 --> Utf8 Class Initialized
INFO - 2020-09-09 05:40:50 --> URI Class Initialized
DEBUG - 2020-09-09 05:40:50 --> No URI present. Default controller set.
INFO - 2020-09-09 05:40:50 --> Router Class Initialized
INFO - 2020-09-09 05:40:50 --> Output Class Initialized
INFO - 2020-09-09 05:40:50 --> Security Class Initialized
DEBUG - 2020-09-09 05:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 05:40:50 --> Input Class Initialized
INFO - 2020-09-09 05:40:50 --> Language Class Initialized
INFO - 2020-09-09 05:40:50 --> Language Class Initialized
INFO - 2020-09-09 05:40:50 --> Config Class Initialized
INFO - 2020-09-09 05:40:50 --> Loader Class Initialized
INFO - 2020-09-09 05:40:50 --> Helper loaded: url_helper
INFO - 2020-09-09 05:40:50 --> Helper loaded: form_helper
INFO - 2020-09-09 05:40:50 --> Helper loaded: file_helper
INFO - 2020-09-09 05:40:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 05:40:50 --> Database Driver Class Initialized
DEBUG - 2020-09-09 05:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 05:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 05:40:50 --> Upload Class Initialized
INFO - 2020-09-09 05:40:50 --> Controller Class Initialized
DEBUG - 2020-09-09 05:40:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 05:40:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 05:40:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 05:40:50 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 05:40:50 --> Final output sent to browser
DEBUG - 2020-09-09 05:40:50 --> Total execution time: 0.9006
INFO - 2020-09-09 05:43:44 --> Config Class Initialized
INFO - 2020-09-09 05:43:44 --> Hooks Class Initialized
DEBUG - 2020-09-09 05:43:44 --> UTF-8 Support Enabled
INFO - 2020-09-09 05:43:44 --> Utf8 Class Initialized
INFO - 2020-09-09 05:43:44 --> URI Class Initialized
DEBUG - 2020-09-09 05:43:44 --> No URI present. Default controller set.
INFO - 2020-09-09 05:43:44 --> Router Class Initialized
INFO - 2020-09-09 05:43:44 --> Output Class Initialized
INFO - 2020-09-09 05:43:44 --> Security Class Initialized
DEBUG - 2020-09-09 05:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 05:43:44 --> Input Class Initialized
INFO - 2020-09-09 05:43:44 --> Language Class Initialized
INFO - 2020-09-09 05:43:44 --> Language Class Initialized
INFO - 2020-09-09 05:43:44 --> Config Class Initialized
INFO - 2020-09-09 05:43:44 --> Loader Class Initialized
INFO - 2020-09-09 05:43:44 --> Helper loaded: url_helper
INFO - 2020-09-09 05:43:44 --> Helper loaded: form_helper
INFO - 2020-09-09 05:43:44 --> Helper loaded: file_helper
INFO - 2020-09-09 05:43:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 05:43:44 --> Database Driver Class Initialized
DEBUG - 2020-09-09 05:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 05:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 05:43:44 --> Upload Class Initialized
INFO - 2020-09-09 05:43:44 --> Controller Class Initialized
DEBUG - 2020-09-09 05:43:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 05:43:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 05:43:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 05:43:44 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 05:43:44 --> Final output sent to browser
DEBUG - 2020-09-09 05:43:44 --> Total execution time: 0.0454
INFO - 2020-09-09 06:47:20 --> Config Class Initialized
INFO - 2020-09-09 06:47:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:47:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:47:20 --> Utf8 Class Initialized
INFO - 2020-09-09 06:47:20 --> URI Class Initialized
DEBUG - 2020-09-09 06:47:20 --> No URI present. Default controller set.
INFO - 2020-09-09 06:47:20 --> Router Class Initialized
INFO - 2020-09-09 06:47:21 --> Output Class Initialized
INFO - 2020-09-09 06:47:21 --> Security Class Initialized
DEBUG - 2020-09-09 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:47:21 --> Input Class Initialized
INFO - 2020-09-09 06:47:21 --> Language Class Initialized
INFO - 2020-09-09 06:47:21 --> Language Class Initialized
INFO - 2020-09-09 06:47:21 --> Config Class Initialized
INFO - 2020-09-09 06:47:21 --> Loader Class Initialized
INFO - 2020-09-09 06:47:21 --> Helper loaded: url_helper
INFO - 2020-09-09 06:47:21 --> Helper loaded: form_helper
INFO - 2020-09-09 06:47:21 --> Helper loaded: file_helper
INFO - 2020-09-09 06:47:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 06:47:21 --> Database Driver Class Initialized
DEBUG - 2020-09-09 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:47:21 --> Upload Class Initialized
INFO - 2020-09-09 06:47:21 --> Controller Class Initialized
DEBUG - 2020-09-09 06:47:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 06:47:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 06:47:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 06:47:21 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 06:47:21 --> Final output sent to browser
DEBUG - 2020-09-09 06:47:21 --> Total execution time: 0.7637
INFO - 2020-09-09 06:54:03 --> Config Class Initialized
INFO - 2020-09-09 06:54:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:54:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:54:03 --> Utf8 Class Initialized
INFO - 2020-09-09 06:54:03 --> URI Class Initialized
DEBUG - 2020-09-09 06:54:03 --> No URI present. Default controller set.
INFO - 2020-09-09 06:54:03 --> Router Class Initialized
INFO - 2020-09-09 06:54:03 --> Output Class Initialized
INFO - 2020-09-09 06:54:03 --> Security Class Initialized
DEBUG - 2020-09-09 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:54:03 --> Input Class Initialized
INFO - 2020-09-09 06:54:03 --> Language Class Initialized
INFO - 2020-09-09 06:54:03 --> Language Class Initialized
INFO - 2020-09-09 06:54:03 --> Config Class Initialized
INFO - 2020-09-09 06:54:03 --> Loader Class Initialized
INFO - 2020-09-09 06:54:03 --> Helper loaded: url_helper
INFO - 2020-09-09 06:54:03 --> Helper loaded: form_helper
INFO - 2020-09-09 06:54:03 --> Helper loaded: file_helper
INFO - 2020-09-09 06:54:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 06:54:03 --> Database Driver Class Initialized
DEBUG - 2020-09-09 06:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 06:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:54:03 --> Upload Class Initialized
INFO - 2020-09-09 06:54:03 --> Controller Class Initialized
DEBUG - 2020-09-09 06:54:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 06:54:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 06:54:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 06:54:03 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 06:54:03 --> Final output sent to browser
DEBUG - 2020-09-09 06:54:03 --> Total execution time: 0.2486
INFO - 2020-09-09 07:21:39 --> Config Class Initialized
INFO - 2020-09-09 07:21:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 07:21:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 07:21:39 --> Utf8 Class Initialized
INFO - 2020-09-09 07:21:39 --> URI Class Initialized
DEBUG - 2020-09-09 07:21:39 --> No URI present. Default controller set.
INFO - 2020-09-09 07:21:39 --> Router Class Initialized
INFO - 2020-09-09 07:21:39 --> Output Class Initialized
INFO - 2020-09-09 07:21:39 --> Security Class Initialized
DEBUG - 2020-09-09 07:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 07:21:39 --> Input Class Initialized
INFO - 2020-09-09 07:21:39 --> Language Class Initialized
INFO - 2020-09-09 07:21:39 --> Language Class Initialized
INFO - 2020-09-09 07:21:39 --> Config Class Initialized
INFO - 2020-09-09 07:21:39 --> Loader Class Initialized
INFO - 2020-09-09 07:21:39 --> Helper loaded: url_helper
INFO - 2020-09-09 07:21:39 --> Helper loaded: form_helper
INFO - 2020-09-09 07:21:39 --> Helper loaded: file_helper
INFO - 2020-09-09 07:21:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 07:21:39 --> Database Driver Class Initialized
DEBUG - 2020-09-09 07:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 07:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 07:21:39 --> Upload Class Initialized
INFO - 2020-09-09 07:21:39 --> Controller Class Initialized
DEBUG - 2020-09-09 07:21:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 07:21:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 07:21:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 07:21:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 07:21:39 --> Final output sent to browser
DEBUG - 2020-09-09 07:21:39 --> Total execution time: 0.0493
INFO - 2020-09-09 07:30:55 --> Config Class Initialized
INFO - 2020-09-09 07:30:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 07:30:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 07:30:55 --> Utf8 Class Initialized
INFO - 2020-09-09 07:30:55 --> URI Class Initialized
INFO - 2020-09-09 07:30:55 --> Router Class Initialized
INFO - 2020-09-09 07:30:55 --> Output Class Initialized
INFO - 2020-09-09 07:30:55 --> Security Class Initialized
DEBUG - 2020-09-09 07:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 07:30:55 --> Input Class Initialized
INFO - 2020-09-09 07:30:55 --> Language Class Initialized
INFO - 2020-09-09 07:30:55 --> Language Class Initialized
INFO - 2020-09-09 07:30:55 --> Config Class Initialized
INFO - 2020-09-09 07:30:55 --> Loader Class Initialized
INFO - 2020-09-09 07:30:55 --> Helper loaded: url_helper
INFO - 2020-09-09 07:30:55 --> Helper loaded: form_helper
INFO - 2020-09-09 07:30:55 --> Helper loaded: file_helper
INFO - 2020-09-09 07:30:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 07:30:55 --> Database Driver Class Initialized
DEBUG - 2020-09-09 07:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 07:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 07:30:55 --> Upload Class Initialized
INFO - 2020-09-09 07:30:55 --> Controller Class Initialized
ERROR - 2020-09-09 07:30:55 --> 404 Page Not Found: /index
INFO - 2020-09-09 07:30:57 --> Config Class Initialized
INFO - 2020-09-09 07:30:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 07:30:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 07:30:57 --> Utf8 Class Initialized
INFO - 2020-09-09 07:30:57 --> URI Class Initialized
INFO - 2020-09-09 07:30:57 --> Router Class Initialized
INFO - 2020-09-09 07:30:57 --> Output Class Initialized
INFO - 2020-09-09 07:30:57 --> Security Class Initialized
DEBUG - 2020-09-09 07:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 07:30:57 --> Input Class Initialized
INFO - 2020-09-09 07:30:57 --> Language Class Initialized
INFO - 2020-09-09 07:30:57 --> Language Class Initialized
INFO - 2020-09-09 07:30:57 --> Config Class Initialized
INFO - 2020-09-09 07:30:57 --> Loader Class Initialized
INFO - 2020-09-09 07:30:57 --> Helper loaded: url_helper
INFO - 2020-09-09 07:30:57 --> Helper loaded: form_helper
INFO - 2020-09-09 07:30:57 --> Helper loaded: file_helper
INFO - 2020-09-09 07:30:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 07:30:57 --> Database Driver Class Initialized
DEBUG - 2020-09-09 07:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 07:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 07:30:57 --> Upload Class Initialized
INFO - 2020-09-09 07:30:57 --> Controller Class Initialized
DEBUG - 2020-09-09 07:30:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 07:30:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-09 07:30:57 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 07:30:57 --> Final output sent to browser
DEBUG - 2020-09-09 07:30:57 --> Total execution time: 0.0958
INFO - 2020-09-09 07:55:07 --> Config Class Initialized
INFO - 2020-09-09 07:55:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 07:55:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 07:55:07 --> Utf8 Class Initialized
INFO - 2020-09-09 07:55:07 --> URI Class Initialized
INFO - 2020-09-09 07:55:08 --> Router Class Initialized
INFO - 2020-09-09 07:55:08 --> Output Class Initialized
INFO - 2020-09-09 07:55:08 --> Security Class Initialized
DEBUG - 2020-09-09 07:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 07:55:08 --> Input Class Initialized
INFO - 2020-09-09 07:55:08 --> Language Class Initialized
INFO - 2020-09-09 07:55:08 --> Language Class Initialized
INFO - 2020-09-09 07:55:08 --> Config Class Initialized
INFO - 2020-09-09 07:55:08 --> Loader Class Initialized
INFO - 2020-09-09 07:55:08 --> Helper loaded: url_helper
INFO - 2020-09-09 07:55:08 --> Helper loaded: form_helper
INFO - 2020-09-09 07:55:08 --> Helper loaded: file_helper
INFO - 2020-09-09 07:55:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 07:55:08 --> Database Driver Class Initialized
DEBUG - 2020-09-09 07:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 07:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 07:55:08 --> Upload Class Initialized
INFO - 2020-09-09 07:55:08 --> Controller Class Initialized
ERROR - 2020-09-09 07:55:08 --> 404 Page Not Found: /index
INFO - 2020-09-09 08:19:11 --> Config Class Initialized
INFO - 2020-09-09 08:19:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:19:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:19:11 --> Utf8 Class Initialized
INFO - 2020-09-09 08:19:11 --> URI Class Initialized
DEBUG - 2020-09-09 08:19:11 --> No URI present. Default controller set.
INFO - 2020-09-09 08:19:11 --> Router Class Initialized
INFO - 2020-09-09 08:19:11 --> Output Class Initialized
INFO - 2020-09-09 08:19:11 --> Security Class Initialized
DEBUG - 2020-09-09 08:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:19:11 --> Input Class Initialized
INFO - 2020-09-09 08:19:11 --> Language Class Initialized
INFO - 2020-09-09 08:19:11 --> Language Class Initialized
INFO - 2020-09-09 08:19:11 --> Config Class Initialized
INFO - 2020-09-09 08:19:11 --> Loader Class Initialized
INFO - 2020-09-09 08:19:11 --> Helper loaded: url_helper
INFO - 2020-09-09 08:19:11 --> Helper loaded: form_helper
INFO - 2020-09-09 08:19:11 --> Helper loaded: file_helper
INFO - 2020-09-09 08:19:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 08:19:11 --> Database Driver Class Initialized
DEBUG - 2020-09-09 08:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 08:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 08:19:11 --> Upload Class Initialized
INFO - 2020-09-09 08:19:11 --> Controller Class Initialized
DEBUG - 2020-09-09 08:19:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 08:19:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 08:19:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 08:19:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 08:19:11 --> Final output sent to browser
DEBUG - 2020-09-09 08:19:11 --> Total execution time: 0.1846
INFO - 2020-09-09 08:30:31 --> Config Class Initialized
INFO - 2020-09-09 08:30:31 --> Hooks Class Initialized
DEBUG - 2020-09-09 08:30:31 --> UTF-8 Support Enabled
INFO - 2020-09-09 08:30:31 --> Utf8 Class Initialized
INFO - 2020-09-09 08:30:31 --> URI Class Initialized
DEBUG - 2020-09-09 08:30:31 --> No URI present. Default controller set.
INFO - 2020-09-09 08:30:31 --> Router Class Initialized
INFO - 2020-09-09 08:30:31 --> Output Class Initialized
INFO - 2020-09-09 08:30:31 --> Security Class Initialized
DEBUG - 2020-09-09 08:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 08:30:31 --> Input Class Initialized
INFO - 2020-09-09 08:30:31 --> Language Class Initialized
INFO - 2020-09-09 08:30:31 --> Language Class Initialized
INFO - 2020-09-09 08:30:31 --> Config Class Initialized
INFO - 2020-09-09 08:30:31 --> Loader Class Initialized
INFO - 2020-09-09 08:30:31 --> Helper loaded: url_helper
INFO - 2020-09-09 08:30:31 --> Helper loaded: form_helper
INFO - 2020-09-09 08:30:31 --> Helper loaded: file_helper
INFO - 2020-09-09 08:30:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 08:30:31 --> Database Driver Class Initialized
DEBUG - 2020-09-09 08:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 08:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 08:30:31 --> Upload Class Initialized
INFO - 2020-09-09 08:30:31 --> Controller Class Initialized
DEBUG - 2020-09-09 08:30:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 08:30:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 08:30:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 08:30:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 08:30:31 --> Final output sent to browser
DEBUG - 2020-09-09 08:30:31 --> Total execution time: 0.0535
INFO - 2020-09-09 09:19:42 --> Config Class Initialized
INFO - 2020-09-09 09:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:19:42 --> Utf8 Class Initialized
INFO - 2020-09-09 09:19:42 --> URI Class Initialized
DEBUG - 2020-09-09 09:19:42 --> No URI present. Default controller set.
INFO - 2020-09-09 09:19:42 --> Router Class Initialized
INFO - 2020-09-09 09:19:42 --> Output Class Initialized
INFO - 2020-09-09 09:19:42 --> Security Class Initialized
DEBUG - 2020-09-09 09:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:19:42 --> Input Class Initialized
INFO - 2020-09-09 09:19:42 --> Language Class Initialized
INFO - 2020-09-09 09:19:42 --> Language Class Initialized
INFO - 2020-09-09 09:19:42 --> Config Class Initialized
INFO - 2020-09-09 09:19:42 --> Loader Class Initialized
INFO - 2020-09-09 09:19:42 --> Helper loaded: url_helper
INFO - 2020-09-09 09:19:42 --> Helper loaded: form_helper
INFO - 2020-09-09 09:19:42 --> Helper loaded: file_helper
INFO - 2020-09-09 09:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 09:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-09 09:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 09:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:19:42 --> Upload Class Initialized
INFO - 2020-09-09 09:19:43 --> Controller Class Initialized
DEBUG - 2020-09-09 09:19:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 09:19:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 09:19:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 09:19:43 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 09:19:43 --> Final output sent to browser
DEBUG - 2020-09-09 09:19:43 --> Total execution time: 0.8987
INFO - 2020-09-09 09:24:34 --> Config Class Initialized
INFO - 2020-09-09 09:24:34 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:24:34 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:24:34 --> Utf8 Class Initialized
INFO - 2020-09-09 09:24:34 --> URI Class Initialized
DEBUG - 2020-09-09 09:24:34 --> No URI present. Default controller set.
INFO - 2020-09-09 09:24:34 --> Router Class Initialized
INFO - 2020-09-09 09:24:34 --> Output Class Initialized
INFO - 2020-09-09 09:24:34 --> Security Class Initialized
DEBUG - 2020-09-09 09:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:24:34 --> Input Class Initialized
INFO - 2020-09-09 09:24:34 --> Language Class Initialized
INFO - 2020-09-09 09:24:34 --> Language Class Initialized
INFO - 2020-09-09 09:24:34 --> Config Class Initialized
INFO - 2020-09-09 09:24:34 --> Loader Class Initialized
INFO - 2020-09-09 09:24:34 --> Helper loaded: url_helper
INFO - 2020-09-09 09:24:34 --> Helper loaded: form_helper
INFO - 2020-09-09 09:24:34 --> Helper loaded: file_helper
INFO - 2020-09-09 09:24:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 09:24:34 --> Database Driver Class Initialized
DEBUG - 2020-09-09 09:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 09:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:24:34 --> Upload Class Initialized
INFO - 2020-09-09 09:24:34 --> Controller Class Initialized
DEBUG - 2020-09-09 09:24:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 09:24:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 09:24:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 09:24:34 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 09:24:34 --> Final output sent to browser
DEBUG - 2020-09-09 09:24:34 --> Total execution time: 0.0410
INFO - 2020-09-09 09:24:35 --> Config Class Initialized
INFO - 2020-09-09 09:24:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:24:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:24:35 --> Utf8 Class Initialized
INFO - 2020-09-09 09:24:35 --> URI Class Initialized
DEBUG - 2020-09-09 09:24:35 --> No URI present. Default controller set.
INFO - 2020-09-09 09:24:35 --> Router Class Initialized
INFO - 2020-09-09 09:24:35 --> Output Class Initialized
INFO - 2020-09-09 09:24:35 --> Security Class Initialized
DEBUG - 2020-09-09 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:24:35 --> Input Class Initialized
INFO - 2020-09-09 09:24:35 --> Language Class Initialized
INFO - 2020-09-09 09:24:35 --> Language Class Initialized
INFO - 2020-09-09 09:24:35 --> Config Class Initialized
INFO - 2020-09-09 09:24:35 --> Loader Class Initialized
INFO - 2020-09-09 09:24:35 --> Helper loaded: url_helper
INFO - 2020-09-09 09:24:35 --> Helper loaded: form_helper
INFO - 2020-09-09 09:24:35 --> Helper loaded: file_helper
INFO - 2020-09-09 09:24:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 09:24:35 --> Database Driver Class Initialized
DEBUG - 2020-09-09 09:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 09:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:24:35 --> Upload Class Initialized
INFO - 2020-09-09 09:24:35 --> Controller Class Initialized
DEBUG - 2020-09-09 09:24:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 09:24:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 09:24:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 09:24:35 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 09:24:35 --> Final output sent to browser
DEBUG - 2020-09-09 09:24:35 --> Total execution time: 0.0557
INFO - 2020-09-09 09:25:30 --> Config Class Initialized
INFO - 2020-09-09 09:25:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:25:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:25:30 --> Utf8 Class Initialized
INFO - 2020-09-09 09:25:30 --> URI Class Initialized
INFO - 2020-09-09 09:25:30 --> Router Class Initialized
INFO - 2020-09-09 09:25:30 --> Output Class Initialized
INFO - 2020-09-09 09:25:30 --> Security Class Initialized
DEBUG - 2020-09-09 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:25:30 --> Input Class Initialized
INFO - 2020-09-09 09:25:30 --> Language Class Initialized
INFO - 2020-09-09 09:25:30 --> Language Class Initialized
INFO - 2020-09-09 09:25:30 --> Config Class Initialized
INFO - 2020-09-09 09:25:30 --> Loader Class Initialized
INFO - 2020-09-09 09:25:30 --> Helper loaded: url_helper
INFO - 2020-09-09 09:25:30 --> Helper loaded: form_helper
INFO - 2020-09-09 09:25:30 --> Helper loaded: file_helper
INFO - 2020-09-09 09:25:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 09:25:30 --> Database Driver Class Initialized
DEBUG - 2020-09-09 09:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 09:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:25:30 --> Upload Class Initialized
INFO - 2020-09-09 09:25:30 --> Controller Class Initialized
ERROR - 2020-09-09 09:25:30 --> 404 Page Not Found: /index
INFO - 2020-09-09 09:25:32 --> Config Class Initialized
INFO - 2020-09-09 09:25:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:25:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:25:32 --> Utf8 Class Initialized
INFO - 2020-09-09 09:25:32 --> URI Class Initialized
DEBUG - 2020-09-09 09:25:32 --> No URI present. Default controller set.
INFO - 2020-09-09 09:25:32 --> Router Class Initialized
INFO - 2020-09-09 09:25:32 --> Output Class Initialized
INFO - 2020-09-09 09:25:32 --> Security Class Initialized
DEBUG - 2020-09-09 09:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:25:32 --> Input Class Initialized
INFO - 2020-09-09 09:25:32 --> Language Class Initialized
INFO - 2020-09-09 09:25:32 --> Language Class Initialized
INFO - 2020-09-09 09:25:32 --> Config Class Initialized
INFO - 2020-09-09 09:25:32 --> Loader Class Initialized
INFO - 2020-09-09 09:25:32 --> Helper loaded: url_helper
INFO - 2020-09-09 09:25:32 --> Helper loaded: form_helper
INFO - 2020-09-09 09:25:32 --> Helper loaded: file_helper
INFO - 2020-09-09 09:25:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 09:25:32 --> Database Driver Class Initialized
DEBUG - 2020-09-09 09:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 09:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:25:32 --> Upload Class Initialized
INFO - 2020-09-09 09:25:32 --> Controller Class Initialized
DEBUG - 2020-09-09 09:25:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 09:25:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 09:25:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 09:25:32 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 09:25:32 --> Final output sent to browser
DEBUG - 2020-09-09 09:25:32 --> Total execution time: 0.0448
INFO - 2020-09-09 10:30:00 --> Config Class Initialized
INFO - 2020-09-09 10:30:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:30:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:30:01 --> Utf8 Class Initialized
INFO - 2020-09-09 10:30:01 --> URI Class Initialized
DEBUG - 2020-09-09 10:30:01 --> No URI present. Default controller set.
INFO - 2020-09-09 10:30:01 --> Router Class Initialized
INFO - 2020-09-09 10:30:01 --> Output Class Initialized
INFO - 2020-09-09 10:30:01 --> Security Class Initialized
DEBUG - 2020-09-09 10:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:30:01 --> Input Class Initialized
INFO - 2020-09-09 10:30:01 --> Language Class Initialized
INFO - 2020-09-09 10:30:01 --> Language Class Initialized
INFO - 2020-09-09 10:30:01 --> Config Class Initialized
INFO - 2020-09-09 10:30:01 --> Loader Class Initialized
INFO - 2020-09-09 10:30:01 --> Helper loaded: url_helper
INFO - 2020-09-09 10:30:01 --> Helper loaded: form_helper
INFO - 2020-09-09 10:30:01 --> Helper loaded: file_helper
INFO - 2020-09-09 10:30:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:30:01 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:30:01 --> Upload Class Initialized
INFO - 2020-09-09 10:30:02 --> Controller Class Initialized
DEBUG - 2020-09-09 10:30:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:30:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 10:30:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 10:30:02 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:30:02 --> Final output sent to browser
DEBUG - 2020-09-09 10:30:02 --> Total execution time: 1.5081
INFO - 2020-09-09 10:30:06 --> Config Class Initialized
INFO - 2020-09-09 10:30:06 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:30:06 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:30:06 --> Utf8 Class Initialized
INFO - 2020-09-09 10:30:06 --> URI Class Initialized
INFO - 2020-09-09 10:30:06 --> Router Class Initialized
INFO - 2020-09-09 10:30:06 --> Output Class Initialized
INFO - 2020-09-09 10:30:06 --> Security Class Initialized
DEBUG - 2020-09-09 10:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:30:06 --> Input Class Initialized
INFO - 2020-09-09 10:30:06 --> Language Class Initialized
INFO - 2020-09-09 10:30:06 --> Language Class Initialized
INFO - 2020-09-09 10:30:06 --> Config Class Initialized
INFO - 2020-09-09 10:30:06 --> Loader Class Initialized
INFO - 2020-09-09 10:30:06 --> Helper loaded: url_helper
INFO - 2020-09-09 10:30:06 --> Helper loaded: form_helper
INFO - 2020-09-09 10:30:06 --> Helper loaded: file_helper
INFO - 2020-09-09 10:30:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:30:06 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:30:06 --> Upload Class Initialized
INFO - 2020-09-09 10:30:06 --> Controller Class Initialized
ERROR - 2020-09-09 10:30:06 --> 404 Page Not Found: /index
INFO - 2020-09-09 10:30:07 --> Config Class Initialized
INFO - 2020-09-09 10:30:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:30:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:30:07 --> Utf8 Class Initialized
INFO - 2020-09-09 10:30:07 --> URI Class Initialized
DEBUG - 2020-09-09 10:30:07 --> No URI present. Default controller set.
INFO - 2020-09-09 10:30:07 --> Router Class Initialized
INFO - 2020-09-09 10:30:07 --> Output Class Initialized
INFO - 2020-09-09 10:30:07 --> Security Class Initialized
DEBUG - 2020-09-09 10:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:30:07 --> Input Class Initialized
INFO - 2020-09-09 10:30:07 --> Language Class Initialized
INFO - 2020-09-09 10:30:07 --> Language Class Initialized
INFO - 2020-09-09 10:30:07 --> Config Class Initialized
INFO - 2020-09-09 10:30:07 --> Loader Class Initialized
INFO - 2020-09-09 10:30:07 --> Helper loaded: url_helper
INFO - 2020-09-09 10:30:07 --> Helper loaded: form_helper
INFO - 2020-09-09 10:30:07 --> Helper loaded: file_helper
INFO - 2020-09-09 10:30:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:30:07 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:30:07 --> Upload Class Initialized
INFO - 2020-09-09 10:30:07 --> Controller Class Initialized
DEBUG - 2020-09-09 10:30:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:30:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 10:30:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 10:30:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:30:07 --> Final output sent to browser
DEBUG - 2020-09-09 10:30:07 --> Total execution time: 0.1261
INFO - 2020-09-09 10:31:37 --> Config Class Initialized
INFO - 2020-09-09 10:31:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:31:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:31:37 --> Utf8 Class Initialized
INFO - 2020-09-09 10:31:37 --> URI Class Initialized
INFO - 2020-09-09 10:31:37 --> Router Class Initialized
INFO - 2020-09-09 10:31:37 --> Output Class Initialized
INFO - 2020-09-09 10:31:37 --> Security Class Initialized
DEBUG - 2020-09-09 10:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:31:37 --> Input Class Initialized
INFO - 2020-09-09 10:31:37 --> Language Class Initialized
INFO - 2020-09-09 10:31:37 --> Language Class Initialized
INFO - 2020-09-09 10:31:37 --> Config Class Initialized
INFO - 2020-09-09 10:31:37 --> Loader Class Initialized
INFO - 2020-09-09 10:31:37 --> Helper loaded: url_helper
INFO - 2020-09-09 10:31:37 --> Helper loaded: form_helper
INFO - 2020-09-09 10:31:37 --> Helper loaded: file_helper
INFO - 2020-09-09 10:31:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:31:37 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:31:37 --> Upload Class Initialized
INFO - 2020-09-09 10:31:37 --> Controller Class Initialized
DEBUG - 2020-09-09 10:31:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:31:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-09 10:31:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:31:37 --> Final output sent to browser
DEBUG - 2020-09-09 10:31:37 --> Total execution time: 0.0552
INFO - 2020-09-09 10:35:56 --> Config Class Initialized
INFO - 2020-09-09 10:35:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:35:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:35:56 --> Utf8 Class Initialized
INFO - 2020-09-09 10:35:56 --> URI Class Initialized
INFO - 2020-09-09 10:35:56 --> Router Class Initialized
INFO - 2020-09-09 10:35:56 --> Output Class Initialized
INFO - 2020-09-09 10:35:56 --> Security Class Initialized
DEBUG - 2020-09-09 10:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:35:56 --> Input Class Initialized
INFO - 2020-09-09 10:35:56 --> Language Class Initialized
INFO - 2020-09-09 10:35:56 --> Language Class Initialized
INFO - 2020-09-09 10:35:56 --> Config Class Initialized
INFO - 2020-09-09 10:35:56 --> Loader Class Initialized
INFO - 2020-09-09 10:35:56 --> Helper loaded: url_helper
INFO - 2020-09-09 10:35:56 --> Helper loaded: form_helper
INFO - 2020-09-09 10:35:56 --> Helper loaded: file_helper
INFO - 2020-09-09 10:35:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:35:56 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:35:56 --> Upload Class Initialized
INFO - 2020-09-09 10:35:56 --> Controller Class Initialized
DEBUG - 2020-09-09 10:35:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:35:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-09 10:35:56 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:35:56 --> Final output sent to browser
DEBUG - 2020-09-09 10:35:56 --> Total execution time: 0.1122
INFO - 2020-09-09 10:42:41 --> Config Class Initialized
INFO - 2020-09-09 10:42:41 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:42:41 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:42:41 --> Utf8 Class Initialized
INFO - 2020-09-09 10:42:41 --> URI Class Initialized
INFO - 2020-09-09 10:42:41 --> Router Class Initialized
INFO - 2020-09-09 10:42:41 --> Output Class Initialized
INFO - 2020-09-09 10:42:41 --> Security Class Initialized
DEBUG - 2020-09-09 10:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:42:41 --> Input Class Initialized
INFO - 2020-09-09 10:42:41 --> Language Class Initialized
INFO - 2020-09-09 10:42:41 --> Language Class Initialized
INFO - 2020-09-09 10:42:41 --> Config Class Initialized
INFO - 2020-09-09 10:42:41 --> Loader Class Initialized
INFO - 2020-09-09 10:42:41 --> Helper loaded: url_helper
INFO - 2020-09-09 10:42:41 --> Helper loaded: form_helper
INFO - 2020-09-09 10:42:41 --> Helper loaded: file_helper
INFO - 2020-09-09 10:42:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:42:41 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:42:41 --> Upload Class Initialized
INFO - 2020-09-09 10:42:41 --> Controller Class Initialized
ERROR - 2020-09-09 10:42:41 --> 404 Page Not Found: /index
INFO - 2020-09-09 10:45:30 --> Config Class Initialized
INFO - 2020-09-09 10:45:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:45:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:45:30 --> Utf8 Class Initialized
INFO - 2020-09-09 10:45:30 --> URI Class Initialized
INFO - 2020-09-09 10:45:31 --> Router Class Initialized
INFO - 2020-09-09 10:45:31 --> Output Class Initialized
INFO - 2020-09-09 10:45:31 --> Security Class Initialized
DEBUG - 2020-09-09 10:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:45:31 --> Input Class Initialized
INFO - 2020-09-09 10:45:31 --> Language Class Initialized
INFO - 2020-09-09 10:45:31 --> Language Class Initialized
INFO - 2020-09-09 10:45:31 --> Config Class Initialized
INFO - 2020-09-09 10:45:31 --> Loader Class Initialized
INFO - 2020-09-09 10:45:31 --> Helper loaded: url_helper
INFO - 2020-09-09 10:45:31 --> Helper loaded: form_helper
INFO - 2020-09-09 10:45:31 --> Helper loaded: file_helper
INFO - 2020-09-09 10:45:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:45:31 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:45:31 --> Upload Class Initialized
INFO - 2020-09-09 10:45:31 --> Controller Class Initialized
DEBUG - 2020-09-09 10:45:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:45:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-09 10:45:31 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:45:31 --> Final output sent to browser
DEBUG - 2020-09-09 10:45:31 --> Total execution time: 1.3661
INFO - 2020-09-09 10:51:09 --> Config Class Initialized
INFO - 2020-09-09 10:51:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:51:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:51:09 --> Utf8 Class Initialized
INFO - 2020-09-09 10:51:09 --> URI Class Initialized
INFO - 2020-09-09 10:51:09 --> Router Class Initialized
INFO - 2020-09-09 10:51:09 --> Output Class Initialized
INFO - 2020-09-09 10:51:09 --> Security Class Initialized
DEBUG - 2020-09-09 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:51:09 --> Input Class Initialized
INFO - 2020-09-09 10:51:09 --> Language Class Initialized
INFO - 2020-09-09 10:51:09 --> Language Class Initialized
INFO - 2020-09-09 10:51:09 --> Config Class Initialized
INFO - 2020-09-09 10:51:09 --> Loader Class Initialized
INFO - 2020-09-09 10:51:09 --> Helper loaded: url_helper
INFO - 2020-09-09 10:51:09 --> Helper loaded: form_helper
INFO - 2020-09-09 10:51:09 --> Helper loaded: file_helper
INFO - 2020-09-09 10:51:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:51:09 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:51:09 --> Upload Class Initialized
INFO - 2020-09-09 10:51:09 --> Controller Class Initialized
DEBUG - 2020-09-09 10:51:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:51:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-09 10:51:09 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:51:09 --> Final output sent to browser
DEBUG - 2020-09-09 10:51:09 --> Total execution time: 0.0617
INFO - 2020-09-09 10:58:07 --> Config Class Initialized
INFO - 2020-09-09 10:58:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:58:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:58:07 --> Utf8 Class Initialized
INFO - 2020-09-09 10:58:07 --> URI Class Initialized
INFO - 2020-09-09 10:58:07 --> Router Class Initialized
INFO - 2020-09-09 10:58:07 --> Output Class Initialized
INFO - 2020-09-09 10:58:07 --> Security Class Initialized
DEBUG - 2020-09-09 10:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:58:07 --> Input Class Initialized
INFO - 2020-09-09 10:58:07 --> Language Class Initialized
INFO - 2020-09-09 10:58:07 --> Language Class Initialized
INFO - 2020-09-09 10:58:07 --> Config Class Initialized
INFO - 2020-09-09 10:58:07 --> Loader Class Initialized
INFO - 2020-09-09 10:58:07 --> Helper loaded: url_helper
INFO - 2020-09-09 10:58:07 --> Helper loaded: form_helper
INFO - 2020-09-09 10:58:07 --> Helper loaded: file_helper
INFO - 2020-09-09 10:58:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 10:58:07 --> Database Driver Class Initialized
DEBUG - 2020-09-09 10:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 10:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:58:07 --> Upload Class Initialized
INFO - 2020-09-09 10:58:07 --> Controller Class Initialized
DEBUG - 2020-09-09 10:58:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 10:58:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-09 10:58:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 10:58:07 --> Final output sent to browser
DEBUG - 2020-09-09 10:58:07 --> Total execution time: 0.0833
INFO - 2020-09-09 11:01:11 --> Config Class Initialized
INFO - 2020-09-09 11:01:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:01:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:01:11 --> Utf8 Class Initialized
INFO - 2020-09-09 11:01:11 --> URI Class Initialized
INFO - 2020-09-09 11:01:11 --> Router Class Initialized
INFO - 2020-09-09 11:01:11 --> Output Class Initialized
INFO - 2020-09-09 11:01:11 --> Security Class Initialized
DEBUG - 2020-09-09 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:01:11 --> Input Class Initialized
INFO - 2020-09-09 11:01:11 --> Language Class Initialized
INFO - 2020-09-09 11:01:11 --> Language Class Initialized
INFO - 2020-09-09 11:01:11 --> Config Class Initialized
INFO - 2020-09-09 11:01:11 --> Loader Class Initialized
INFO - 2020-09-09 11:01:11 --> Helper loaded: url_helper
INFO - 2020-09-09 11:01:11 --> Helper loaded: form_helper
INFO - 2020-09-09 11:01:11 --> Helper loaded: file_helper
INFO - 2020-09-09 11:01:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 11:01:11 --> Database Driver Class Initialized
DEBUG - 2020-09-09 11:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 11:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:01:11 --> Upload Class Initialized
INFO - 2020-09-09 11:01:11 --> Controller Class Initialized
DEBUG - 2020-09-09 11:01:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 11:01:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 11:01:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 11:01:11 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 11:01:11 --> Final output sent to browser
DEBUG - 2020-09-09 11:01:11 --> Total execution time: 0.0701
INFO - 2020-09-09 11:03:36 --> Config Class Initialized
INFO - 2020-09-09 11:03:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:03:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:03:36 --> Utf8 Class Initialized
INFO - 2020-09-09 11:03:36 --> URI Class Initialized
INFO - 2020-09-09 11:03:36 --> Router Class Initialized
INFO - 2020-09-09 11:03:36 --> Output Class Initialized
INFO - 2020-09-09 11:03:36 --> Security Class Initialized
DEBUG - 2020-09-09 11:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:03:36 --> Input Class Initialized
INFO - 2020-09-09 11:03:36 --> Language Class Initialized
INFO - 2020-09-09 11:03:36 --> Language Class Initialized
INFO - 2020-09-09 11:03:36 --> Config Class Initialized
INFO - 2020-09-09 11:03:36 --> Loader Class Initialized
INFO - 2020-09-09 11:03:36 --> Helper loaded: url_helper
INFO - 2020-09-09 11:03:36 --> Helper loaded: form_helper
INFO - 2020-09-09 11:03:36 --> Helper loaded: file_helper
INFO - 2020-09-09 11:03:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 11:03:36 --> Database Driver Class Initialized
DEBUG - 2020-09-09 11:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 11:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:03:36 --> Upload Class Initialized
INFO - 2020-09-09 11:03:36 --> Controller Class Initialized
DEBUG - 2020-09-09 11:03:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 11:03:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-09 11:03:36 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 11:03:36 --> Final output sent to browser
DEBUG - 2020-09-09 11:03:36 --> Total execution time: 0.0725
INFO - 2020-09-09 11:06:42 --> Config Class Initialized
INFO - 2020-09-09 11:06:42 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:06:42 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:06:42 --> Utf8 Class Initialized
INFO - 2020-09-09 11:06:42 --> URI Class Initialized
INFO - 2020-09-09 11:06:42 --> Router Class Initialized
INFO - 2020-09-09 11:06:42 --> Output Class Initialized
INFO - 2020-09-09 11:06:42 --> Security Class Initialized
DEBUG - 2020-09-09 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:06:42 --> Input Class Initialized
INFO - 2020-09-09 11:06:42 --> Language Class Initialized
INFO - 2020-09-09 11:06:42 --> Language Class Initialized
INFO - 2020-09-09 11:06:42 --> Config Class Initialized
INFO - 2020-09-09 11:06:42 --> Loader Class Initialized
INFO - 2020-09-09 11:06:42 --> Helper loaded: url_helper
INFO - 2020-09-09 11:06:42 --> Helper loaded: form_helper
INFO - 2020-09-09 11:06:42 --> Helper loaded: file_helper
INFO - 2020-09-09 11:06:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 11:06:42 --> Database Driver Class Initialized
DEBUG - 2020-09-09 11:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 11:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:06:42 --> Upload Class Initialized
INFO - 2020-09-09 11:06:42 --> Controller Class Initialized
DEBUG - 2020-09-09 11:06:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 11:06:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-09 11:06:42 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 11:06:42 --> Final output sent to browser
DEBUG - 2020-09-09 11:06:42 --> Total execution time: 0.1612
INFO - 2020-09-09 11:36:55 --> Config Class Initialized
INFO - 2020-09-09 11:36:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:36:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:36:55 --> Utf8 Class Initialized
INFO - 2020-09-09 11:36:55 --> URI Class Initialized
INFO - 2020-09-09 11:36:55 --> Router Class Initialized
INFO - 2020-09-09 11:36:55 --> Output Class Initialized
INFO - 2020-09-09 11:36:55 --> Security Class Initialized
DEBUG - 2020-09-09 11:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:36:55 --> Input Class Initialized
INFO - 2020-09-09 11:36:55 --> Language Class Initialized
INFO - 2020-09-09 11:36:55 --> Language Class Initialized
INFO - 2020-09-09 11:36:55 --> Config Class Initialized
INFO - 2020-09-09 11:36:55 --> Loader Class Initialized
INFO - 2020-09-09 11:36:55 --> Helper loaded: url_helper
INFO - 2020-09-09 11:36:55 --> Helper loaded: form_helper
INFO - 2020-09-09 11:36:55 --> Helper loaded: file_helper
INFO - 2020-09-09 11:36:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 11:36:55 --> Database Driver Class Initialized
DEBUG - 2020-09-09 11:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 11:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:36:55 --> Upload Class Initialized
INFO - 2020-09-09 11:36:55 --> Controller Class Initialized
ERROR - 2020-09-09 11:36:55 --> 404 Page Not Found: /index
INFO - 2020-09-09 11:49:07 --> Config Class Initialized
INFO - 2020-09-09 11:49:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:49:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:49:07 --> Utf8 Class Initialized
INFO - 2020-09-09 11:49:07 --> URI Class Initialized
DEBUG - 2020-09-09 11:49:07 --> No URI present. Default controller set.
INFO - 2020-09-09 11:49:07 --> Router Class Initialized
INFO - 2020-09-09 11:49:07 --> Output Class Initialized
INFO - 2020-09-09 11:49:07 --> Security Class Initialized
DEBUG - 2020-09-09 11:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:49:07 --> Input Class Initialized
INFO - 2020-09-09 11:49:07 --> Language Class Initialized
INFO - 2020-09-09 11:49:07 --> Language Class Initialized
INFO - 2020-09-09 11:49:07 --> Config Class Initialized
INFO - 2020-09-09 11:49:07 --> Loader Class Initialized
INFO - 2020-09-09 11:49:07 --> Helper loaded: url_helper
INFO - 2020-09-09 11:49:07 --> Helper loaded: form_helper
INFO - 2020-09-09 11:49:07 --> Helper loaded: file_helper
INFO - 2020-09-09 11:49:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 11:49:07 --> Database Driver Class Initialized
DEBUG - 2020-09-09 11:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 11:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:49:07 --> Upload Class Initialized
INFO - 2020-09-09 11:49:07 --> Controller Class Initialized
DEBUG - 2020-09-09 11:49:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 11:49:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 11:49:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 11:49:07 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 11:49:07 --> Final output sent to browser
DEBUG - 2020-09-09 11:49:07 --> Total execution time: 0.3917
INFO - 2020-09-09 11:51:22 --> Config Class Initialized
INFO - 2020-09-09 11:51:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:51:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:51:22 --> Utf8 Class Initialized
INFO - 2020-09-09 11:51:22 --> URI Class Initialized
DEBUG - 2020-09-09 11:51:22 --> No URI present. Default controller set.
INFO - 2020-09-09 11:51:22 --> Router Class Initialized
INFO - 2020-09-09 11:51:22 --> Output Class Initialized
INFO - 2020-09-09 11:51:22 --> Security Class Initialized
DEBUG - 2020-09-09 11:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:51:22 --> Input Class Initialized
INFO - 2020-09-09 11:51:22 --> Language Class Initialized
INFO - 2020-09-09 11:51:22 --> Language Class Initialized
INFO - 2020-09-09 11:51:22 --> Config Class Initialized
INFO - 2020-09-09 11:51:22 --> Loader Class Initialized
INFO - 2020-09-09 11:51:22 --> Helper loaded: url_helper
INFO - 2020-09-09 11:51:22 --> Helper loaded: form_helper
INFO - 2020-09-09 11:51:22 --> Helper loaded: file_helper
INFO - 2020-09-09 11:51:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 11:51:22 --> Database Driver Class Initialized
DEBUG - 2020-09-09 11:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 11:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:51:22 --> Upload Class Initialized
INFO - 2020-09-09 11:51:22 --> Controller Class Initialized
DEBUG - 2020-09-09 11:51:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 11:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 11:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 11:51:22 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 11:51:22 --> Final output sent to browser
DEBUG - 2020-09-09 11:51:22 --> Total execution time: 0.0707
INFO - 2020-09-09 12:38:37 --> Config Class Initialized
INFO - 2020-09-09 12:38:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:38:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:38:37 --> Utf8 Class Initialized
INFO - 2020-09-09 12:38:37 --> URI Class Initialized
INFO - 2020-09-09 12:38:37 --> Router Class Initialized
INFO - 2020-09-09 12:38:37 --> Output Class Initialized
INFO - 2020-09-09 12:38:37 --> Security Class Initialized
DEBUG - 2020-09-09 12:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:38:37 --> Input Class Initialized
INFO - 2020-09-09 12:38:37 --> Language Class Initialized
INFO - 2020-09-09 12:38:37 --> Language Class Initialized
INFO - 2020-09-09 12:38:37 --> Config Class Initialized
INFO - 2020-09-09 12:38:37 --> Loader Class Initialized
INFO - 2020-09-09 12:38:37 --> Helper loaded: url_helper
INFO - 2020-09-09 12:38:37 --> Helper loaded: form_helper
INFO - 2020-09-09 12:38:37 --> Helper loaded: file_helper
INFO - 2020-09-09 12:38:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 12:38:37 --> Database Driver Class Initialized
DEBUG - 2020-09-09 12:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 12:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 12:38:37 --> Upload Class Initialized
INFO - 2020-09-09 12:38:37 --> Controller Class Initialized
ERROR - 2020-09-09 12:38:37 --> 404 Page Not Found: /index
INFO - 2020-09-09 12:58:26 --> Config Class Initialized
INFO - 2020-09-09 12:58:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:58:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:58:26 --> Utf8 Class Initialized
INFO - 2020-09-09 12:58:26 --> URI Class Initialized
DEBUG - 2020-09-09 12:58:26 --> No URI present. Default controller set.
INFO - 2020-09-09 12:58:26 --> Router Class Initialized
INFO - 2020-09-09 12:58:26 --> Output Class Initialized
INFO - 2020-09-09 12:58:26 --> Security Class Initialized
DEBUG - 2020-09-09 12:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:58:26 --> Input Class Initialized
INFO - 2020-09-09 12:58:26 --> Language Class Initialized
INFO - 2020-09-09 12:58:26 --> Language Class Initialized
INFO - 2020-09-09 12:58:26 --> Config Class Initialized
INFO - 2020-09-09 12:58:26 --> Loader Class Initialized
INFO - 2020-09-09 12:58:26 --> Helper loaded: url_helper
INFO - 2020-09-09 12:58:26 --> Helper loaded: form_helper
INFO - 2020-09-09 12:58:26 --> Helper loaded: file_helper
INFO - 2020-09-09 12:58:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 12:58:26 --> Database Driver Class Initialized
DEBUG - 2020-09-09 12:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 12:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 12:58:26 --> Upload Class Initialized
INFO - 2020-09-09 12:58:27 --> Controller Class Initialized
DEBUG - 2020-09-09 12:58:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 12:58:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 12:58:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 12:58:27 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 12:58:27 --> Final output sent to browser
DEBUG - 2020-09-09 12:58:27 --> Total execution time: 0.4351
INFO - 2020-09-09 12:58:28 --> Config Class Initialized
INFO - 2020-09-09 12:58:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:58:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:58:28 --> Utf8 Class Initialized
INFO - 2020-09-09 12:58:28 --> URI Class Initialized
DEBUG - 2020-09-09 12:58:28 --> No URI present. Default controller set.
INFO - 2020-09-09 12:58:28 --> Router Class Initialized
INFO - 2020-09-09 12:58:28 --> Output Class Initialized
INFO - 2020-09-09 12:58:28 --> Security Class Initialized
DEBUG - 2020-09-09 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:58:28 --> Input Class Initialized
INFO - 2020-09-09 12:58:28 --> Language Class Initialized
INFO - 2020-09-09 12:58:28 --> Language Class Initialized
INFO - 2020-09-09 12:58:28 --> Config Class Initialized
INFO - 2020-09-09 12:58:28 --> Loader Class Initialized
INFO - 2020-09-09 12:58:28 --> Helper loaded: url_helper
INFO - 2020-09-09 12:58:28 --> Helper loaded: form_helper
INFO - 2020-09-09 12:58:28 --> Helper loaded: file_helper
INFO - 2020-09-09 12:58:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 12:58:28 --> Database Driver Class Initialized
DEBUG - 2020-09-09 12:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 12:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 12:58:28 --> Upload Class Initialized
INFO - 2020-09-09 12:58:28 --> Controller Class Initialized
DEBUG - 2020-09-09 12:58:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 12:58:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 12:58:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 12:58:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 12:58:28 --> Final output sent to browser
DEBUG - 2020-09-09 12:58:28 --> Total execution time: 0.0581
INFO - 2020-09-09 12:58:30 --> Config Class Initialized
INFO - 2020-09-09 12:58:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 12:58:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 12:58:30 --> Utf8 Class Initialized
INFO - 2020-09-09 12:58:30 --> URI Class Initialized
INFO - 2020-09-09 12:58:30 --> Router Class Initialized
INFO - 2020-09-09 12:58:30 --> Output Class Initialized
INFO - 2020-09-09 12:58:30 --> Security Class Initialized
DEBUG - 2020-09-09 12:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 12:58:30 --> Input Class Initialized
INFO - 2020-09-09 12:58:30 --> Language Class Initialized
INFO - 2020-09-09 12:58:30 --> Language Class Initialized
INFO - 2020-09-09 12:58:30 --> Config Class Initialized
INFO - 2020-09-09 12:58:30 --> Loader Class Initialized
INFO - 2020-09-09 12:58:30 --> Helper loaded: url_helper
INFO - 2020-09-09 12:58:30 --> Helper loaded: form_helper
INFO - 2020-09-09 12:58:30 --> Helper loaded: file_helper
INFO - 2020-09-09 12:58:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 12:58:30 --> Database Driver Class Initialized
DEBUG - 2020-09-09 12:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 12:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 12:58:30 --> Upload Class Initialized
INFO - 2020-09-09 12:58:30 --> Controller Class Initialized
ERROR - 2020-09-09 12:58:30 --> 404 Page Not Found: /index
INFO - 2020-09-09 14:19:43 --> Config Class Initialized
INFO - 2020-09-09 14:19:43 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:19:43 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:19:43 --> Utf8 Class Initialized
INFO - 2020-09-09 14:19:43 --> URI Class Initialized
INFO - 2020-09-09 14:19:43 --> Router Class Initialized
INFO - 2020-09-09 14:19:43 --> Output Class Initialized
INFO - 2020-09-09 14:19:43 --> Security Class Initialized
DEBUG - 2020-09-09 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:19:43 --> Input Class Initialized
INFO - 2020-09-09 14:19:43 --> Language Class Initialized
INFO - 2020-09-09 14:19:43 --> Language Class Initialized
INFO - 2020-09-09 14:19:43 --> Config Class Initialized
INFO - 2020-09-09 14:19:43 --> Loader Class Initialized
INFO - 2020-09-09 14:19:43 --> Helper loaded: url_helper
INFO - 2020-09-09 14:19:43 --> Helper loaded: form_helper
INFO - 2020-09-09 14:19:43 --> Helper loaded: file_helper
INFO - 2020-09-09 14:19:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 14:19:43 --> Database Driver Class Initialized
DEBUG - 2020-09-09 14:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 14:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:19:43 --> Upload Class Initialized
INFO - 2020-09-09 14:19:43 --> Controller Class Initialized
ERROR - 2020-09-09 14:19:43 --> 404 Page Not Found: /index
INFO - 2020-09-09 14:19:45 --> Config Class Initialized
INFO - 2020-09-09 14:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:19:45 --> Utf8 Class Initialized
INFO - 2020-09-09 14:19:45 --> URI Class Initialized
DEBUG - 2020-09-09 14:19:45 --> No URI present. Default controller set.
INFO - 2020-09-09 14:19:45 --> Router Class Initialized
INFO - 2020-09-09 14:19:45 --> Output Class Initialized
INFO - 2020-09-09 14:19:45 --> Security Class Initialized
DEBUG - 2020-09-09 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:19:45 --> Input Class Initialized
INFO - 2020-09-09 14:19:45 --> Language Class Initialized
INFO - 2020-09-09 14:19:45 --> Language Class Initialized
INFO - 2020-09-09 14:19:45 --> Config Class Initialized
INFO - 2020-09-09 14:19:45 --> Loader Class Initialized
INFO - 2020-09-09 14:19:45 --> Helper loaded: url_helper
INFO - 2020-09-09 14:19:45 --> Helper loaded: form_helper
INFO - 2020-09-09 14:19:45 --> Helper loaded: file_helper
INFO - 2020-09-09 14:19:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 14:19:45 --> Database Driver Class Initialized
DEBUG - 2020-09-09 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:19:45 --> Upload Class Initialized
INFO - 2020-09-09 14:19:45 --> Controller Class Initialized
DEBUG - 2020-09-09 14:19:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 14:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 14:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 14:19:45 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 14:19:45 --> Final output sent to browser
DEBUG - 2020-09-09 14:19:45 --> Total execution time: 0.0642
INFO - 2020-09-09 14:54:26 --> Config Class Initialized
INFO - 2020-09-09 14:54:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:54:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:54:27 --> Utf8 Class Initialized
INFO - 2020-09-09 14:54:27 --> URI Class Initialized
INFO - 2020-09-09 14:54:27 --> Router Class Initialized
INFO - 2020-09-09 14:54:27 --> Output Class Initialized
INFO - 2020-09-09 14:54:27 --> Security Class Initialized
DEBUG - 2020-09-09 14:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:54:27 --> Input Class Initialized
INFO - 2020-09-09 14:54:27 --> Language Class Initialized
INFO - 2020-09-09 14:54:27 --> Language Class Initialized
INFO - 2020-09-09 14:54:27 --> Config Class Initialized
INFO - 2020-09-09 14:54:27 --> Loader Class Initialized
INFO - 2020-09-09 14:54:27 --> Helper loaded: url_helper
INFO - 2020-09-09 14:54:27 --> Helper loaded: form_helper
INFO - 2020-09-09 14:54:27 --> Helper loaded: file_helper
INFO - 2020-09-09 14:54:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 14:54:27 --> Database Driver Class Initialized
DEBUG - 2020-09-09 14:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 14:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:54:27 --> Upload Class Initialized
INFO - 2020-09-09 14:54:27 --> Controller Class Initialized
ERROR - 2020-09-09 14:54:27 --> 404 Page Not Found: /index
INFO - 2020-09-09 15:11:59 --> Config Class Initialized
INFO - 2020-09-09 15:11:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:11:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:11:59 --> Utf8 Class Initialized
INFO - 2020-09-09 15:11:59 --> URI Class Initialized
INFO - 2020-09-09 15:11:59 --> Router Class Initialized
INFO - 2020-09-09 15:11:59 --> Output Class Initialized
INFO - 2020-09-09 15:11:59 --> Security Class Initialized
DEBUG - 2020-09-09 15:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:11:59 --> Input Class Initialized
INFO - 2020-09-09 15:11:59 --> Language Class Initialized
INFO - 2020-09-09 15:11:59 --> Language Class Initialized
INFO - 2020-09-09 15:11:59 --> Config Class Initialized
INFO - 2020-09-09 15:11:59 --> Loader Class Initialized
INFO - 2020-09-09 15:11:59 --> Helper loaded: url_helper
INFO - 2020-09-09 15:11:59 --> Helper loaded: form_helper
INFO - 2020-09-09 15:11:59 --> Helper loaded: file_helper
INFO - 2020-09-09 15:11:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 15:11:59 --> Database Driver Class Initialized
DEBUG - 2020-09-09 15:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 15:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:11:59 --> Upload Class Initialized
INFO - 2020-09-09 15:11:59 --> Controller Class Initialized
ERROR - 2020-09-09 15:11:59 --> 404 Page Not Found: /index
INFO - 2020-09-09 15:11:59 --> Config Class Initialized
INFO - 2020-09-09 15:11:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:11:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:11:59 --> Utf8 Class Initialized
INFO - 2020-09-09 15:11:59 --> URI Class Initialized
DEBUG - 2020-09-09 15:12:00 --> No URI present. Default controller set.
INFO - 2020-09-09 15:12:00 --> Router Class Initialized
INFO - 2020-09-09 15:12:00 --> Output Class Initialized
INFO - 2020-09-09 15:12:00 --> Security Class Initialized
DEBUG - 2020-09-09 15:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:12:00 --> Input Class Initialized
INFO - 2020-09-09 15:12:00 --> Language Class Initialized
INFO - 2020-09-09 15:12:00 --> Language Class Initialized
INFO - 2020-09-09 15:12:00 --> Config Class Initialized
INFO - 2020-09-09 15:12:00 --> Loader Class Initialized
INFO - 2020-09-09 15:12:00 --> Helper loaded: url_helper
INFO - 2020-09-09 15:12:00 --> Helper loaded: form_helper
INFO - 2020-09-09 15:12:00 --> Helper loaded: file_helper
INFO - 2020-09-09 15:12:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 15:12:00 --> Database Driver Class Initialized
DEBUG - 2020-09-09 15:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 15:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:12:00 --> Upload Class Initialized
INFO - 2020-09-09 15:12:00 --> Controller Class Initialized
DEBUG - 2020-09-09 15:12:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 15:12:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 15:12:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 15:12:00 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 15:12:00 --> Final output sent to browser
DEBUG - 2020-09-09 15:12:00 --> Total execution time: 0.2469
INFO - 2020-09-09 15:29:23 --> Config Class Initialized
INFO - 2020-09-09 15:29:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:29:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:29:23 --> Utf8 Class Initialized
INFO - 2020-09-09 15:29:23 --> URI Class Initialized
DEBUG - 2020-09-09 15:29:23 --> No URI present. Default controller set.
INFO - 2020-09-09 15:29:23 --> Router Class Initialized
INFO - 2020-09-09 15:29:23 --> Output Class Initialized
INFO - 2020-09-09 15:29:23 --> Security Class Initialized
DEBUG - 2020-09-09 15:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:29:23 --> Input Class Initialized
INFO - 2020-09-09 15:29:23 --> Language Class Initialized
INFO - 2020-09-09 15:29:23 --> Language Class Initialized
INFO - 2020-09-09 15:29:23 --> Config Class Initialized
INFO - 2020-09-09 15:29:23 --> Loader Class Initialized
INFO - 2020-09-09 15:29:23 --> Helper loaded: url_helper
INFO - 2020-09-09 15:29:23 --> Helper loaded: form_helper
INFO - 2020-09-09 15:29:23 --> Helper loaded: file_helper
INFO - 2020-09-09 15:29:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 15:29:23 --> Database Driver Class Initialized
DEBUG - 2020-09-09 15:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 15:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:29:23 --> Upload Class Initialized
INFO - 2020-09-09 15:29:23 --> Controller Class Initialized
DEBUG - 2020-09-09 15:29:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 15:29:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 15:29:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 15:29:23 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 15:29:23 --> Final output sent to browser
DEBUG - 2020-09-09 15:29:23 --> Total execution time: 0.0535
INFO - 2020-09-09 16:49:13 --> Config Class Initialized
INFO - 2020-09-09 16:49:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:49:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:49:13 --> Utf8 Class Initialized
INFO - 2020-09-09 16:49:13 --> URI Class Initialized
DEBUG - 2020-09-09 16:49:13 --> No URI present. Default controller set.
INFO - 2020-09-09 16:49:13 --> Router Class Initialized
INFO - 2020-09-09 16:49:13 --> Output Class Initialized
INFO - 2020-09-09 16:49:13 --> Security Class Initialized
DEBUG - 2020-09-09 16:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:49:13 --> Input Class Initialized
INFO - 2020-09-09 16:49:13 --> Language Class Initialized
INFO - 2020-09-09 16:49:13 --> Language Class Initialized
INFO - 2020-09-09 16:49:13 --> Config Class Initialized
INFO - 2020-09-09 16:49:13 --> Loader Class Initialized
INFO - 2020-09-09 16:49:13 --> Helper loaded: url_helper
INFO - 2020-09-09 16:49:13 --> Helper loaded: form_helper
INFO - 2020-09-09 16:49:13 --> Helper loaded: file_helper
INFO - 2020-09-09 16:49:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 16:49:13 --> Database Driver Class Initialized
DEBUG - 2020-09-09 16:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:49:13 --> Upload Class Initialized
INFO - 2020-09-09 16:49:14 --> Controller Class Initialized
DEBUG - 2020-09-09 16:49:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 16:49:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 16:49:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 16:49:14 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 16:49:14 --> Final output sent to browser
DEBUG - 2020-09-09 16:49:14 --> Total execution time: 0.6410
INFO - 2020-09-09 18:10:57 --> Config Class Initialized
INFO - 2020-09-09 18:10:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:10:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:10:57 --> Utf8 Class Initialized
INFO - 2020-09-09 18:10:57 --> URI Class Initialized
INFO - 2020-09-09 18:10:57 --> Router Class Initialized
INFO - 2020-09-09 18:10:57 --> Output Class Initialized
INFO - 2020-09-09 18:10:57 --> Security Class Initialized
DEBUG - 2020-09-09 18:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:10:57 --> Input Class Initialized
INFO - 2020-09-09 18:10:57 --> Language Class Initialized
INFO - 2020-09-09 18:10:57 --> Language Class Initialized
INFO - 2020-09-09 18:10:57 --> Config Class Initialized
INFO - 2020-09-09 18:10:57 --> Loader Class Initialized
INFO - 2020-09-09 18:10:57 --> Helper loaded: url_helper
INFO - 2020-09-09 18:10:57 --> Helper loaded: form_helper
INFO - 2020-09-09 18:10:57 --> Helper loaded: file_helper
INFO - 2020-09-09 18:10:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 18:10:57 --> Database Driver Class Initialized
DEBUG - 2020-09-09 18:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 18:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:10:57 --> Upload Class Initialized
INFO - 2020-09-09 18:10:57 --> Controller Class Initialized
ERROR - 2020-09-09 18:10:57 --> 404 Page Not Found: /index
INFO - 2020-09-09 18:35:57 --> Config Class Initialized
INFO - 2020-09-09 18:35:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:35:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:35:57 --> Utf8 Class Initialized
INFO - 2020-09-09 18:35:57 --> URI Class Initialized
DEBUG - 2020-09-09 18:35:57 --> No URI present. Default controller set.
INFO - 2020-09-09 18:35:57 --> Router Class Initialized
INFO - 2020-09-09 18:35:57 --> Output Class Initialized
INFO - 2020-09-09 18:35:57 --> Security Class Initialized
DEBUG - 2020-09-09 18:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:35:57 --> Input Class Initialized
INFO - 2020-09-09 18:35:57 --> Language Class Initialized
INFO - 2020-09-09 18:35:57 --> Language Class Initialized
INFO - 2020-09-09 18:35:57 --> Config Class Initialized
INFO - 2020-09-09 18:35:57 --> Loader Class Initialized
INFO - 2020-09-09 18:35:57 --> Helper loaded: url_helper
INFO - 2020-09-09 18:35:57 --> Helper loaded: form_helper
INFO - 2020-09-09 18:35:57 --> Helper loaded: file_helper
INFO - 2020-09-09 18:35:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 18:35:57 --> Database Driver Class Initialized
DEBUG - 2020-09-09 18:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 18:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:35:57 --> Upload Class Initialized
INFO - 2020-09-09 18:35:57 --> Controller Class Initialized
DEBUG - 2020-09-09 18:35:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 18:35:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 18:35:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 18:35:58 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 18:35:58 --> Final output sent to browser
DEBUG - 2020-09-09 18:35:58 --> Total execution time: 0.7990
INFO - 2020-09-09 21:20:51 --> Config Class Initialized
INFO - 2020-09-09 21:20:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 21:20:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 21:20:51 --> Utf8 Class Initialized
INFO - 2020-09-09 21:20:51 --> URI Class Initialized
DEBUG - 2020-09-09 21:20:51 --> No URI present. Default controller set.
INFO - 2020-09-09 21:20:51 --> Router Class Initialized
INFO - 2020-09-09 21:20:51 --> Output Class Initialized
INFO - 2020-09-09 21:20:51 --> Security Class Initialized
DEBUG - 2020-09-09 21:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 21:20:51 --> Input Class Initialized
INFO - 2020-09-09 21:20:51 --> Language Class Initialized
INFO - 2020-09-09 21:20:51 --> Language Class Initialized
INFO - 2020-09-09 21:20:51 --> Config Class Initialized
INFO - 2020-09-09 21:20:51 --> Loader Class Initialized
INFO - 2020-09-09 21:20:51 --> Helper loaded: url_helper
INFO - 2020-09-09 21:20:51 --> Helper loaded: form_helper
INFO - 2020-09-09 21:20:51 --> Helper loaded: file_helper
INFO - 2020-09-09 21:20:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 21:20:51 --> Database Driver Class Initialized
DEBUG - 2020-09-09 21:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 21:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 21:20:51 --> Upload Class Initialized
INFO - 2020-09-09 21:20:51 --> Controller Class Initialized
DEBUG - 2020-09-09 21:20:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 21:20:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 21:20:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 21:20:51 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 21:20:51 --> Final output sent to browser
DEBUG - 2020-09-09 21:20:51 --> Total execution time: 0.5541
INFO - 2020-09-09 21:20:53 --> Config Class Initialized
INFO - 2020-09-09 21:20:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 21:20:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 21:20:53 --> Utf8 Class Initialized
INFO - 2020-09-09 21:20:53 --> URI Class Initialized
DEBUG - 2020-09-09 21:20:53 --> No URI present. Default controller set.
INFO - 2020-09-09 21:20:53 --> Router Class Initialized
INFO - 2020-09-09 21:20:53 --> Output Class Initialized
INFO - 2020-09-09 21:20:53 --> Security Class Initialized
DEBUG - 2020-09-09 21:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 21:20:53 --> Input Class Initialized
INFO - 2020-09-09 21:20:53 --> Language Class Initialized
INFO - 2020-09-09 21:20:53 --> Language Class Initialized
INFO - 2020-09-09 21:20:53 --> Config Class Initialized
INFO - 2020-09-09 21:20:53 --> Loader Class Initialized
INFO - 2020-09-09 21:20:53 --> Helper loaded: url_helper
INFO - 2020-09-09 21:20:53 --> Helper loaded: form_helper
INFO - 2020-09-09 21:20:53 --> Helper loaded: file_helper
INFO - 2020-09-09 21:20:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 21:20:53 --> Database Driver Class Initialized
DEBUG - 2020-09-09 21:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 21:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 21:20:53 --> Upload Class Initialized
INFO - 2020-09-09 21:20:53 --> Controller Class Initialized
DEBUG - 2020-09-09 21:20:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 21:20:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 21:20:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 21:20:53 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 21:20:53 --> Final output sent to browser
DEBUG - 2020-09-09 21:20:53 --> Total execution time: 0.0404
INFO - 2020-09-09 21:21:11 --> Config Class Initialized
INFO - 2020-09-09 21:21:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 21:21:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 21:21:11 --> Utf8 Class Initialized
INFO - 2020-09-09 21:21:11 --> URI Class Initialized
INFO - 2020-09-09 21:21:11 --> Router Class Initialized
INFO - 2020-09-09 21:21:11 --> Output Class Initialized
INFO - 2020-09-09 21:21:11 --> Security Class Initialized
DEBUG - 2020-09-09 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 21:21:11 --> Input Class Initialized
INFO - 2020-09-09 21:21:11 --> Language Class Initialized
INFO - 2020-09-09 21:21:11 --> Language Class Initialized
INFO - 2020-09-09 21:21:11 --> Config Class Initialized
INFO - 2020-09-09 21:21:11 --> Loader Class Initialized
INFO - 2020-09-09 21:21:11 --> Helper loaded: url_helper
INFO - 2020-09-09 21:21:11 --> Helper loaded: form_helper
INFO - 2020-09-09 21:21:11 --> Helper loaded: file_helper
INFO - 2020-09-09 21:21:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 21:21:11 --> Database Driver Class Initialized
DEBUG - 2020-09-09 21:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 21:21:11 --> Upload Class Initialized
INFO - 2020-09-09 21:21:11 --> Controller Class Initialized
ERROR - 2020-09-09 21:21:11 --> 404 Page Not Found: /index
INFO - 2020-09-09 21:26:28 --> Config Class Initialized
INFO - 2020-09-09 21:26:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 21:26:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 21:26:28 --> Utf8 Class Initialized
INFO - 2020-09-09 21:26:28 --> URI Class Initialized
DEBUG - 2020-09-09 21:26:28 --> No URI present. Default controller set.
INFO - 2020-09-09 21:26:28 --> Router Class Initialized
INFO - 2020-09-09 21:26:28 --> Output Class Initialized
INFO - 2020-09-09 21:26:28 --> Security Class Initialized
DEBUG - 2020-09-09 21:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 21:26:28 --> Input Class Initialized
INFO - 2020-09-09 21:26:28 --> Language Class Initialized
INFO - 2020-09-09 21:26:28 --> Language Class Initialized
INFO - 2020-09-09 21:26:28 --> Config Class Initialized
INFO - 2020-09-09 21:26:28 --> Loader Class Initialized
INFO - 2020-09-09 21:26:28 --> Helper loaded: url_helper
INFO - 2020-09-09 21:26:28 --> Helper loaded: form_helper
INFO - 2020-09-09 21:26:28 --> Helper loaded: file_helper
INFO - 2020-09-09 21:26:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 21:26:28 --> Database Driver Class Initialized
DEBUG - 2020-09-09 21:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 21:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 21:26:28 --> Upload Class Initialized
INFO - 2020-09-09 21:26:28 --> Controller Class Initialized
DEBUG - 2020-09-09 21:26:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 21:26:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 21:26:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 21:26:28 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 21:26:28 --> Final output sent to browser
DEBUG - 2020-09-09 21:26:28 --> Total execution time: 0.0462
INFO - 2020-09-09 21:26:29 --> Config Class Initialized
INFO - 2020-09-09 21:26:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 21:26:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 21:26:29 --> Utf8 Class Initialized
INFO - 2020-09-09 21:26:29 --> URI Class Initialized
DEBUG - 2020-09-09 21:26:29 --> No URI present. Default controller set.
INFO - 2020-09-09 21:26:29 --> Router Class Initialized
INFO - 2020-09-09 21:26:29 --> Output Class Initialized
INFO - 2020-09-09 21:26:29 --> Security Class Initialized
DEBUG - 2020-09-09 21:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 21:26:29 --> Input Class Initialized
INFO - 2020-09-09 21:26:29 --> Language Class Initialized
INFO - 2020-09-09 21:26:29 --> Language Class Initialized
INFO - 2020-09-09 21:26:29 --> Config Class Initialized
INFO - 2020-09-09 21:26:29 --> Loader Class Initialized
INFO - 2020-09-09 21:26:29 --> Helper loaded: url_helper
INFO - 2020-09-09 21:26:29 --> Helper loaded: form_helper
INFO - 2020-09-09 21:26:29 --> Helper loaded: file_helper
INFO - 2020-09-09 21:26:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 21:26:29 --> Database Driver Class Initialized
DEBUG - 2020-09-09 21:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 21:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 21:26:29 --> Upload Class Initialized
INFO - 2020-09-09 21:26:29 --> Controller Class Initialized
DEBUG - 2020-09-09 21:26:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 21:26:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 21:26:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 21:26:29 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 21:26:29 --> Final output sent to browser
DEBUG - 2020-09-09 21:26:29 --> Total execution time: 0.0419
INFO - 2020-09-09 21:38:39 --> Config Class Initialized
INFO - 2020-09-09 21:38:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 21:38:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 21:38:39 --> Utf8 Class Initialized
INFO - 2020-09-09 21:38:39 --> URI Class Initialized
DEBUG - 2020-09-09 21:38:39 --> No URI present. Default controller set.
INFO - 2020-09-09 21:38:39 --> Router Class Initialized
INFO - 2020-09-09 21:38:39 --> Output Class Initialized
INFO - 2020-09-09 21:38:39 --> Security Class Initialized
DEBUG - 2020-09-09 21:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 21:38:39 --> Input Class Initialized
INFO - 2020-09-09 21:38:39 --> Language Class Initialized
INFO - 2020-09-09 21:38:39 --> Language Class Initialized
INFO - 2020-09-09 21:38:39 --> Config Class Initialized
INFO - 2020-09-09 21:38:39 --> Loader Class Initialized
INFO - 2020-09-09 21:38:39 --> Helper loaded: url_helper
INFO - 2020-09-09 21:38:39 --> Helper loaded: form_helper
INFO - 2020-09-09 21:38:39 --> Helper loaded: file_helper
INFO - 2020-09-09 21:38:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 21:38:39 --> Database Driver Class Initialized
DEBUG - 2020-09-09 21:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 21:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 21:38:39 --> Upload Class Initialized
INFO - 2020-09-09 21:38:39 --> Controller Class Initialized
DEBUG - 2020-09-09 21:38:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 21:38:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 21:38:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 21:38:39 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 21:38:39 --> Final output sent to browser
DEBUG - 2020-09-09 21:38:39 --> Total execution time: 0.0466
INFO - 2020-09-09 22:12:36 --> Config Class Initialized
INFO - 2020-09-09 22:12:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 22:12:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 22:12:37 --> Utf8 Class Initialized
INFO - 2020-09-09 22:12:37 --> URI Class Initialized
DEBUG - 2020-09-09 22:12:37 --> No URI present. Default controller set.
INFO - 2020-09-09 22:12:37 --> Router Class Initialized
INFO - 2020-09-09 22:12:37 --> Output Class Initialized
INFO - 2020-09-09 22:12:37 --> Security Class Initialized
DEBUG - 2020-09-09 22:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 22:12:37 --> Input Class Initialized
INFO - 2020-09-09 22:12:37 --> Language Class Initialized
INFO - 2020-09-09 22:12:37 --> Language Class Initialized
INFO - 2020-09-09 22:12:37 --> Config Class Initialized
INFO - 2020-09-09 22:12:37 --> Loader Class Initialized
INFO - 2020-09-09 22:12:37 --> Helper loaded: url_helper
INFO - 2020-09-09 22:12:37 --> Helper loaded: form_helper
INFO - 2020-09-09 22:12:37 --> Helper loaded: file_helper
INFO - 2020-09-09 22:12:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 22:12:37 --> Database Driver Class Initialized
DEBUG - 2020-09-09 22:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 22:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 22:12:37 --> Upload Class Initialized
INFO - 2020-09-09 22:12:37 --> Controller Class Initialized
DEBUG - 2020-09-09 22:12:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 22:12:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-09 22:12:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-09 22:12:37 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 22:12:37 --> Final output sent to browser
DEBUG - 2020-09-09 22:12:37 --> Total execution time: 0.4226
INFO - 2020-09-09 22:12:59 --> Config Class Initialized
INFO - 2020-09-09 22:12:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 22:12:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 22:12:59 --> Utf8 Class Initialized
INFO - 2020-09-09 22:12:59 --> URI Class Initialized
INFO - 2020-09-09 22:12:59 --> Router Class Initialized
INFO - 2020-09-09 22:12:59 --> Output Class Initialized
INFO - 2020-09-09 22:12:59 --> Security Class Initialized
DEBUG - 2020-09-09 22:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 22:12:59 --> Input Class Initialized
INFO - 2020-09-09 22:12:59 --> Language Class Initialized
INFO - 2020-09-09 22:12:59 --> Language Class Initialized
INFO - 2020-09-09 22:12:59 --> Config Class Initialized
INFO - 2020-09-09 22:12:59 --> Loader Class Initialized
INFO - 2020-09-09 22:12:59 --> Helper loaded: url_helper
INFO - 2020-09-09 22:12:59 --> Helper loaded: form_helper
INFO - 2020-09-09 22:12:59 --> Helper loaded: file_helper
INFO - 2020-09-09 22:12:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 22:12:59 --> Database Driver Class Initialized
DEBUG - 2020-09-09 22:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 22:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 22:12:59 --> Upload Class Initialized
INFO - 2020-09-09 22:12:59 --> Controller Class Initialized
DEBUG - 2020-09-09 22:12:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-09 22:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-09 22:12:59 --> File loaded: /home/myfield11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-09 22:12:59 --> Final output sent to browser
DEBUG - 2020-09-09 22:12:59 --> Total execution time: 0.1722
INFO - 2020-09-09 22:13:00 --> Config Class Initialized
INFO - 2020-09-09 22:13:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 22:13:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 22:13:00 --> Utf8 Class Initialized
INFO - 2020-09-09 22:13:00 --> URI Class Initialized
INFO - 2020-09-09 22:13:00 --> Router Class Initialized
INFO - 2020-09-09 22:13:00 --> Output Class Initialized
INFO - 2020-09-09 22:13:00 --> Security Class Initialized
DEBUG - 2020-09-09 22:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 22:13:00 --> Input Class Initialized
INFO - 2020-09-09 22:13:00 --> Language Class Initialized
INFO - 2020-09-09 22:13:00 --> Language Class Initialized
INFO - 2020-09-09 22:13:00 --> Config Class Initialized
INFO - 2020-09-09 22:13:00 --> Loader Class Initialized
INFO - 2020-09-09 22:13:00 --> Helper loaded: url_helper
INFO - 2020-09-09 22:13:00 --> Helper loaded: form_helper
INFO - 2020-09-09 22:13:00 --> Helper loaded: file_helper
INFO - 2020-09-09 22:13:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-09 22:13:00 --> Database Driver Class Initialized
DEBUG - 2020-09-09 22:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-09 22:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 22:13:00 --> Upload Class Initialized
INFO - 2020-09-09 22:13:00 --> Controller Class Initialized
ERROR - 2020-09-09 22:13:00 --> 404 Page Not Found: /index
