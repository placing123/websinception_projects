<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-10 00:20:28 --> Config Class Initialized
INFO - 2020-09-10 00:20:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:20:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:20:28 --> Utf8 Class Initialized
INFO - 2020-09-10 00:20:28 --> URI Class Initialized
DEBUG - 2020-09-10 00:20:28 --> No URI present. Default controller set.
INFO - 2020-09-10 00:20:28 --> Router Class Initialized
INFO - 2020-09-10 00:20:28 --> Output Class Initialized
INFO - 2020-09-10 00:20:28 --> Security Class Initialized
DEBUG - 2020-09-10 00:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:20:28 --> Input Class Initialized
INFO - 2020-09-10 00:20:28 --> Language Class Initialized
INFO - 2020-09-10 00:20:28 --> Language Class Initialized
INFO - 2020-09-10 00:20:28 --> Config Class Initialized
INFO - 2020-09-10 00:20:28 --> Loader Class Initialized
INFO - 2020-09-10 00:20:28 --> Helper loaded: url_helper
INFO - 2020-09-10 00:20:28 --> Helper loaded: form_helper
INFO - 2020-09-10 00:20:28 --> Helper loaded: file_helper
INFO - 2020-09-10 00:20:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:20:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:20:28 --> Upload Class Initialized
INFO - 2020-09-10 00:20:28 --> Controller Class Initialized
DEBUG - 2020-09-10 00:20:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 00:20:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 00:20:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 00:20:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 00:20:28 --> Final output sent to browser
DEBUG - 2020-09-10 00:20:28 --> Total execution time: 0.0566
INFO - 2020-09-10 00:20:37 --> Config Class Initialized
INFO - 2020-09-10 00:20:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:20:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:20:37 --> Utf8 Class Initialized
INFO - 2020-09-10 00:20:37 --> URI Class Initialized
INFO - 2020-09-10 00:20:37 --> Router Class Initialized
INFO - 2020-09-10 00:20:37 --> Output Class Initialized
INFO - 2020-09-10 00:20:37 --> Security Class Initialized
DEBUG - 2020-09-10 00:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:20:37 --> Input Class Initialized
INFO - 2020-09-10 00:20:37 --> Language Class Initialized
INFO - 2020-09-10 00:20:37 --> Language Class Initialized
INFO - 2020-09-10 00:20:37 --> Config Class Initialized
INFO - 2020-09-10 00:20:37 --> Loader Class Initialized
INFO - 2020-09-10 00:20:37 --> Helper loaded: url_helper
INFO - 2020-09-10 00:20:37 --> Helper loaded: form_helper
INFO - 2020-09-10 00:20:37 --> Helper loaded: file_helper
INFO - 2020-09-10 00:20:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:20:37 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:20:37 --> Upload Class Initialized
INFO - 2020-09-10 00:20:37 --> Controller Class Initialized
ERROR - 2020-09-10 00:20:37 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:20:37 --> Config Class Initialized
INFO - 2020-09-10 00:20:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:20:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:20:37 --> Utf8 Class Initialized
INFO - 2020-09-10 00:20:37 --> URI Class Initialized
INFO - 2020-09-10 00:20:37 --> Router Class Initialized
INFO - 2020-09-10 00:20:37 --> Output Class Initialized
INFO - 2020-09-10 00:20:37 --> Security Class Initialized
DEBUG - 2020-09-10 00:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:20:37 --> Input Class Initialized
INFO - 2020-09-10 00:20:37 --> Language Class Initialized
INFO - 2020-09-10 00:20:37 --> Language Class Initialized
INFO - 2020-09-10 00:20:37 --> Config Class Initialized
INFO - 2020-09-10 00:20:37 --> Loader Class Initialized
INFO - 2020-09-10 00:20:37 --> Helper loaded: url_helper
INFO - 2020-09-10 00:20:37 --> Helper loaded: form_helper
INFO - 2020-09-10 00:20:37 --> Helper loaded: file_helper
INFO - 2020-09-10 00:20:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:20:37 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:20:37 --> Upload Class Initialized
INFO - 2020-09-10 00:20:37 --> Controller Class Initialized
ERROR - 2020-09-10 00:20:37 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:20:38 --> Config Class Initialized
INFO - 2020-09-10 00:20:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:20:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:20:38 --> Utf8 Class Initialized
INFO - 2020-09-10 00:20:38 --> URI Class Initialized
INFO - 2020-09-10 00:20:38 --> Router Class Initialized
INFO - 2020-09-10 00:20:38 --> Output Class Initialized
INFO - 2020-09-10 00:20:38 --> Security Class Initialized
DEBUG - 2020-09-10 00:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:20:38 --> Input Class Initialized
INFO - 2020-09-10 00:20:38 --> Language Class Initialized
INFO - 2020-09-10 00:20:38 --> Language Class Initialized
INFO - 2020-09-10 00:20:38 --> Config Class Initialized
INFO - 2020-09-10 00:20:38 --> Loader Class Initialized
INFO - 2020-09-10 00:20:38 --> Helper loaded: url_helper
INFO - 2020-09-10 00:20:38 --> Helper loaded: form_helper
INFO - 2020-09-10 00:20:38 --> Helper loaded: file_helper
INFO - 2020-09-10 00:20:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:20:38 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:20:38 --> Upload Class Initialized
INFO - 2020-09-10 00:20:38 --> Controller Class Initialized
ERROR - 2020-09-10 00:20:38 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:20:39 --> Config Class Initialized
INFO - 2020-09-10 00:20:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:20:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:20:39 --> Utf8 Class Initialized
INFO - 2020-09-10 00:20:39 --> URI Class Initialized
INFO - 2020-09-10 00:20:39 --> Router Class Initialized
INFO - 2020-09-10 00:20:39 --> Output Class Initialized
INFO - 2020-09-10 00:20:39 --> Security Class Initialized
DEBUG - 2020-09-10 00:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:20:39 --> Input Class Initialized
INFO - 2020-09-10 00:20:39 --> Language Class Initialized
INFO - 2020-09-10 00:20:39 --> Language Class Initialized
INFO - 2020-09-10 00:20:39 --> Config Class Initialized
INFO - 2020-09-10 00:20:39 --> Loader Class Initialized
INFO - 2020-09-10 00:20:39 --> Helper loaded: url_helper
INFO - 2020-09-10 00:20:39 --> Helper loaded: form_helper
INFO - 2020-09-10 00:20:39 --> Helper loaded: file_helper
INFO - 2020-09-10 00:20:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:20:39 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:20:39 --> Upload Class Initialized
INFO - 2020-09-10 00:20:39 --> Controller Class Initialized
ERROR - 2020-09-10 00:20:39 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:20:41 --> Config Class Initialized
INFO - 2020-09-10 00:20:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:20:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:20:41 --> Utf8 Class Initialized
INFO - 2020-09-10 00:20:41 --> URI Class Initialized
INFO - 2020-09-10 00:20:41 --> Router Class Initialized
INFO - 2020-09-10 00:20:41 --> Output Class Initialized
INFO - 2020-09-10 00:20:41 --> Security Class Initialized
DEBUG - 2020-09-10 00:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:20:41 --> Input Class Initialized
INFO - 2020-09-10 00:20:41 --> Language Class Initialized
INFO - 2020-09-10 00:20:41 --> Language Class Initialized
INFO - 2020-09-10 00:20:41 --> Config Class Initialized
INFO - 2020-09-10 00:20:41 --> Loader Class Initialized
INFO - 2020-09-10 00:20:41 --> Helper loaded: url_helper
INFO - 2020-09-10 00:20:41 --> Helper loaded: form_helper
INFO - 2020-09-10 00:20:41 --> Helper loaded: file_helper
INFO - 2020-09-10 00:20:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:20:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:20:41 --> Upload Class Initialized
INFO - 2020-09-10 00:20:41 --> Controller Class Initialized
ERROR - 2020-09-10 00:20:41 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:21:08 --> Config Class Initialized
INFO - 2020-09-10 00:21:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:21:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:21:08 --> Utf8 Class Initialized
INFO - 2020-09-10 00:21:08 --> URI Class Initialized
INFO - 2020-09-10 00:21:08 --> Router Class Initialized
INFO - 2020-09-10 00:21:08 --> Output Class Initialized
INFO - 2020-09-10 00:21:08 --> Security Class Initialized
DEBUG - 2020-09-10 00:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:21:08 --> Input Class Initialized
INFO - 2020-09-10 00:21:08 --> Language Class Initialized
INFO - 2020-09-10 00:21:08 --> Language Class Initialized
INFO - 2020-09-10 00:21:08 --> Config Class Initialized
INFO - 2020-09-10 00:21:08 --> Loader Class Initialized
INFO - 2020-09-10 00:21:08 --> Helper loaded: url_helper
INFO - 2020-09-10 00:21:08 --> Helper loaded: form_helper
INFO - 2020-09-10 00:21:08 --> Helper loaded: file_helper
INFO - 2020-09-10 00:21:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:21:08 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:21:08 --> Upload Class Initialized
INFO - 2020-09-10 00:21:08 --> Controller Class Initialized
ERROR - 2020-09-10 00:21:08 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:21:17 --> Config Class Initialized
INFO - 2020-09-10 00:21:17 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:21:17 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:21:17 --> Utf8 Class Initialized
INFO - 2020-09-10 00:21:17 --> URI Class Initialized
DEBUG - 2020-09-10 00:21:17 --> No URI present. Default controller set.
INFO - 2020-09-10 00:21:17 --> Router Class Initialized
INFO - 2020-09-10 00:21:17 --> Output Class Initialized
INFO - 2020-09-10 00:21:17 --> Security Class Initialized
DEBUG - 2020-09-10 00:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:21:17 --> Input Class Initialized
INFO - 2020-09-10 00:21:17 --> Language Class Initialized
INFO - 2020-09-10 00:21:17 --> Language Class Initialized
INFO - 2020-09-10 00:21:17 --> Config Class Initialized
INFO - 2020-09-10 00:21:17 --> Loader Class Initialized
INFO - 2020-09-10 00:21:17 --> Helper loaded: url_helper
INFO - 2020-09-10 00:21:17 --> Helper loaded: form_helper
INFO - 2020-09-10 00:21:17 --> Helper loaded: file_helper
INFO - 2020-09-10 00:21:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:21:17 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:21:17 --> Upload Class Initialized
INFO - 2020-09-10 00:21:17 --> Controller Class Initialized
DEBUG - 2020-09-10 00:21:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 00:21:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 00:21:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 00:21:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 00:21:17 --> Final output sent to browser
DEBUG - 2020-09-10 00:21:17 --> Total execution time: 0.0482
INFO - 2020-09-10 00:21:25 --> Config Class Initialized
INFO - 2020-09-10 00:21:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:21:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:21:25 --> Utf8 Class Initialized
INFO - 2020-09-10 00:21:25 --> URI Class Initialized
INFO - 2020-09-10 00:21:25 --> Router Class Initialized
INFO - 2020-09-10 00:21:25 --> Output Class Initialized
INFO - 2020-09-10 00:21:25 --> Security Class Initialized
DEBUG - 2020-09-10 00:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:21:25 --> Input Class Initialized
INFO - 2020-09-10 00:21:25 --> Language Class Initialized
INFO - 2020-09-10 00:21:25 --> Language Class Initialized
INFO - 2020-09-10 00:21:25 --> Config Class Initialized
INFO - 2020-09-10 00:21:25 --> Loader Class Initialized
INFO - 2020-09-10 00:21:25 --> Helper loaded: url_helper
INFO - 2020-09-10 00:21:25 --> Helper loaded: form_helper
INFO - 2020-09-10 00:21:25 --> Helper loaded: file_helper
INFO - 2020-09-10 00:21:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:21:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:21:25 --> Upload Class Initialized
INFO - 2020-09-10 00:21:25 --> Controller Class Initialized
ERROR - 2020-09-10 00:21:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:21:25 --> Config Class Initialized
INFO - 2020-09-10 00:21:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:21:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:21:25 --> Utf8 Class Initialized
INFO - 2020-09-10 00:21:25 --> URI Class Initialized
INFO - 2020-09-10 00:21:25 --> Router Class Initialized
INFO - 2020-09-10 00:21:25 --> Output Class Initialized
INFO - 2020-09-10 00:21:25 --> Security Class Initialized
DEBUG - 2020-09-10 00:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:21:25 --> Input Class Initialized
INFO - 2020-09-10 00:21:25 --> Language Class Initialized
INFO - 2020-09-10 00:21:25 --> Language Class Initialized
INFO - 2020-09-10 00:21:25 --> Config Class Initialized
INFO - 2020-09-10 00:21:25 --> Loader Class Initialized
INFO - 2020-09-10 00:21:25 --> Helper loaded: url_helper
INFO - 2020-09-10 00:21:25 --> Helper loaded: form_helper
INFO - 2020-09-10 00:21:25 --> Helper loaded: file_helper
INFO - 2020-09-10 00:21:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:21:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:21:25 --> Upload Class Initialized
INFO - 2020-09-10 00:21:25 --> Controller Class Initialized
ERROR - 2020-09-10 00:21:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:21:26 --> Config Class Initialized
INFO - 2020-09-10 00:21:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:21:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:21:26 --> Utf8 Class Initialized
INFO - 2020-09-10 00:21:26 --> URI Class Initialized
INFO - 2020-09-10 00:21:26 --> Router Class Initialized
INFO - 2020-09-10 00:21:26 --> Output Class Initialized
INFO - 2020-09-10 00:21:26 --> Security Class Initialized
DEBUG - 2020-09-10 00:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:21:26 --> Input Class Initialized
INFO - 2020-09-10 00:21:26 --> Language Class Initialized
INFO - 2020-09-10 00:21:26 --> Language Class Initialized
INFO - 2020-09-10 00:21:26 --> Config Class Initialized
INFO - 2020-09-10 00:21:26 --> Loader Class Initialized
INFO - 2020-09-10 00:21:26 --> Helper loaded: url_helper
INFO - 2020-09-10 00:21:26 --> Helper loaded: form_helper
INFO - 2020-09-10 00:21:26 --> Helper loaded: file_helper
INFO - 2020-09-10 00:21:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:21:26 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:21:26 --> Upload Class Initialized
INFO - 2020-09-10 00:21:26 --> Controller Class Initialized
ERROR - 2020-09-10 00:21:26 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:21:27 --> Config Class Initialized
INFO - 2020-09-10 00:21:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:21:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:21:27 --> Utf8 Class Initialized
INFO - 2020-09-10 00:21:27 --> URI Class Initialized
INFO - 2020-09-10 00:21:27 --> Router Class Initialized
INFO - 2020-09-10 00:21:27 --> Output Class Initialized
INFO - 2020-09-10 00:21:27 --> Security Class Initialized
DEBUG - 2020-09-10 00:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:21:27 --> Input Class Initialized
INFO - 2020-09-10 00:21:27 --> Language Class Initialized
INFO - 2020-09-10 00:21:27 --> Language Class Initialized
INFO - 2020-09-10 00:21:27 --> Config Class Initialized
INFO - 2020-09-10 00:21:27 --> Loader Class Initialized
INFO - 2020-09-10 00:21:27 --> Helper loaded: url_helper
INFO - 2020-09-10 00:21:27 --> Helper loaded: form_helper
INFO - 2020-09-10 00:21:27 --> Helper loaded: file_helper
INFO - 2020-09-10 00:21:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:21:27 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:21:27 --> Upload Class Initialized
INFO - 2020-09-10 00:21:27 --> Controller Class Initialized
ERROR - 2020-09-10 00:21:27 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:22:10 --> Config Class Initialized
INFO - 2020-09-10 00:22:10 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:22:10 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:22:10 --> Utf8 Class Initialized
INFO - 2020-09-10 00:22:10 --> URI Class Initialized
INFO - 2020-09-10 00:22:10 --> Router Class Initialized
INFO - 2020-09-10 00:22:10 --> Output Class Initialized
INFO - 2020-09-10 00:22:10 --> Security Class Initialized
DEBUG - 2020-09-10 00:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:22:10 --> Input Class Initialized
INFO - 2020-09-10 00:22:10 --> Language Class Initialized
INFO - 2020-09-10 00:22:10 --> Language Class Initialized
INFO - 2020-09-10 00:22:10 --> Config Class Initialized
INFO - 2020-09-10 00:22:10 --> Loader Class Initialized
INFO - 2020-09-10 00:22:10 --> Helper loaded: url_helper
INFO - 2020-09-10 00:22:10 --> Helper loaded: form_helper
INFO - 2020-09-10 00:22:10 --> Helper loaded: file_helper
INFO - 2020-09-10 00:22:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:22:10 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:22:10 --> Upload Class Initialized
INFO - 2020-09-10 00:22:10 --> Controller Class Initialized
ERROR - 2020-09-10 00:22:10 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:22:23 --> Config Class Initialized
INFO - 2020-09-10 00:22:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:22:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:22:23 --> Utf8 Class Initialized
INFO - 2020-09-10 00:22:23 --> URI Class Initialized
INFO - 2020-09-10 00:22:23 --> Router Class Initialized
INFO - 2020-09-10 00:22:23 --> Output Class Initialized
INFO - 2020-09-10 00:22:23 --> Security Class Initialized
DEBUG - 2020-09-10 00:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:22:23 --> Input Class Initialized
INFO - 2020-09-10 00:22:23 --> Language Class Initialized
INFO - 2020-09-10 00:22:23 --> Language Class Initialized
INFO - 2020-09-10 00:22:23 --> Config Class Initialized
INFO - 2020-09-10 00:22:23 --> Loader Class Initialized
INFO - 2020-09-10 00:22:23 --> Helper loaded: url_helper
INFO - 2020-09-10 00:22:23 --> Helper loaded: form_helper
INFO - 2020-09-10 00:22:23 --> Helper loaded: file_helper
INFO - 2020-09-10 00:22:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:22:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:22:23 --> Upload Class Initialized
INFO - 2020-09-10 00:22:23 --> Controller Class Initialized
ERROR - 2020-09-10 00:22:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:23:05 --> Config Class Initialized
INFO - 2020-09-10 00:23:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:23:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:23:05 --> Utf8 Class Initialized
INFO - 2020-09-10 00:23:05 --> URI Class Initialized
DEBUG - 2020-09-10 00:23:05 --> No URI present. Default controller set.
INFO - 2020-09-10 00:23:05 --> Router Class Initialized
INFO - 2020-09-10 00:23:05 --> Output Class Initialized
INFO - 2020-09-10 00:23:05 --> Security Class Initialized
DEBUG - 2020-09-10 00:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:23:05 --> Input Class Initialized
INFO - 2020-09-10 00:23:05 --> Language Class Initialized
INFO - 2020-09-10 00:23:05 --> Language Class Initialized
INFO - 2020-09-10 00:23:05 --> Config Class Initialized
INFO - 2020-09-10 00:23:05 --> Loader Class Initialized
INFO - 2020-09-10 00:23:05 --> Helper loaded: url_helper
INFO - 2020-09-10 00:23:05 --> Helper loaded: form_helper
INFO - 2020-09-10 00:23:05 --> Helper loaded: file_helper
INFO - 2020-09-10 00:23:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:23:05 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:23:05 --> Upload Class Initialized
INFO - 2020-09-10 00:23:05 --> Controller Class Initialized
DEBUG - 2020-09-10 00:23:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 00:23:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 00:23:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 00:23:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 00:23:05 --> Final output sent to browser
DEBUG - 2020-09-10 00:23:05 --> Total execution time: 0.0399
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:23:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:23:14 --> Utf8 Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:23:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:23:14 --> Utf8 Class Initialized
INFO - 2020-09-10 00:23:14 --> URI Class Initialized
INFO - 2020-09-10 00:23:14 --> Router Class Initialized
INFO - 2020-09-10 00:23:14 --> Output Class Initialized
INFO - 2020-09-10 00:23:14 --> Security Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:23:14 --> Input Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> URI Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Loader Class Initialized
INFO - 2020-09-10 00:23:14 --> Helper loaded: url_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: form_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: file_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:23:14 --> Router Class Initialized
INFO - 2020-09-10 00:23:14 --> Output Class Initialized
INFO - 2020-09-10 00:23:14 --> Database Driver Class Initialized
INFO - 2020-09-10 00:23:14 --> Security Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:23:14 --> Input Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Upload Class Initialized
INFO - 2020-09-10 00:23:14 --> Loader Class Initialized
INFO - 2020-09-10 00:23:14 --> Helper loaded: url_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: form_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: file_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:23:14 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:23:14 --> Controller Class Initialized
ERROR - 2020-09-10 00:23:14 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:23:14 --> Upload Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:23:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:23:14 --> Utf8 Class Initialized
INFO - 2020-09-10 00:23:14 --> URI Class Initialized
INFO - 2020-09-10 00:23:14 --> Controller Class Initialized
ERROR - 2020-09-10 00:23:14 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:23:14 --> Router Class Initialized
INFO - 2020-09-10 00:23:14 --> Output Class Initialized
INFO - 2020-09-10 00:23:14 --> Security Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:23:14 --> Input Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Loader Class Initialized
INFO - 2020-09-10 00:23:14 --> Helper loaded: url_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: form_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: file_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:23:14 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:23:14 --> Upload Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:23:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:23:14 --> Utf8 Class Initialized
INFO - 2020-09-10 00:23:14 --> URI Class Initialized
INFO - 2020-09-10 00:23:14 --> Router Class Initialized
INFO - 2020-09-10 00:23:14 --> Output Class Initialized
INFO - 2020-09-10 00:23:14 --> Security Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:23:14 --> Input Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> Language Class Initialized
INFO - 2020-09-10 00:23:14 --> Config Class Initialized
INFO - 2020-09-10 00:23:14 --> Loader Class Initialized
INFO - 2020-09-10 00:23:14 --> Helper loaded: url_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: form_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: file_helper
INFO - 2020-09-10 00:23:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:23:14 --> Controller Class Initialized
ERROR - 2020-09-10 00:23:14 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:23:14 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:23:14 --> Upload Class Initialized
INFO - 2020-09-10 00:23:14 --> Controller Class Initialized
ERROR - 2020-09-10 00:23:14 --> 404 Page Not Found: /index
INFO - 2020-09-10 00:39:51 --> Config Class Initialized
INFO - 2020-09-10 00:39:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 00:39:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 00:39:51 --> Utf8 Class Initialized
INFO - 2020-09-10 00:39:51 --> URI Class Initialized
DEBUG - 2020-09-10 00:39:51 --> No URI present. Default controller set.
INFO - 2020-09-10 00:39:51 --> Router Class Initialized
INFO - 2020-09-10 00:39:51 --> Output Class Initialized
INFO - 2020-09-10 00:39:51 --> Security Class Initialized
DEBUG - 2020-09-10 00:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 00:39:51 --> Input Class Initialized
INFO - 2020-09-10 00:39:51 --> Language Class Initialized
INFO - 2020-09-10 00:39:51 --> Language Class Initialized
INFO - 2020-09-10 00:39:51 --> Config Class Initialized
INFO - 2020-09-10 00:39:51 --> Loader Class Initialized
INFO - 2020-09-10 00:39:51 --> Helper loaded: url_helper
INFO - 2020-09-10 00:39:51 --> Helper loaded: form_helper
INFO - 2020-09-10 00:39:51 --> Helper loaded: file_helper
INFO - 2020-09-10 00:39:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 00:39:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 00:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 00:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 00:39:51 --> Upload Class Initialized
INFO - 2020-09-10 00:39:51 --> Controller Class Initialized
DEBUG - 2020-09-10 00:39:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 00:39:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 00:39:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 00:39:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 00:39:51 --> Final output sent to browser
DEBUG - 2020-09-10 00:39:51 --> Total execution time: 0.0524
INFO - 2020-09-10 01:25:45 --> Config Class Initialized
INFO - 2020-09-10 01:25:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 01:25:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 01:25:45 --> Utf8 Class Initialized
INFO - 2020-09-10 01:25:45 --> URI Class Initialized
DEBUG - 2020-09-10 01:25:45 --> No URI present. Default controller set.
INFO - 2020-09-10 01:25:45 --> Router Class Initialized
INFO - 2020-09-10 01:25:45 --> Output Class Initialized
INFO - 2020-09-10 01:25:45 --> Security Class Initialized
DEBUG - 2020-09-10 01:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 01:25:45 --> Input Class Initialized
INFO - 2020-09-10 01:25:45 --> Language Class Initialized
INFO - 2020-09-10 01:25:45 --> Language Class Initialized
INFO - 2020-09-10 01:25:45 --> Config Class Initialized
INFO - 2020-09-10 01:25:45 --> Loader Class Initialized
INFO - 2020-09-10 01:25:45 --> Helper loaded: url_helper
INFO - 2020-09-10 01:25:45 --> Helper loaded: form_helper
INFO - 2020-09-10 01:25:45 --> Helper loaded: file_helper
INFO - 2020-09-10 01:25:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 01:25:45 --> Database Driver Class Initialized
DEBUG - 2020-09-10 01:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 01:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 01:25:45 --> Upload Class Initialized
INFO - 2020-09-10 01:25:45 --> Controller Class Initialized
DEBUG - 2020-09-10 01:25:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 01:25:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 01:25:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 01:25:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 01:25:45 --> Final output sent to browser
DEBUG - 2020-09-10 01:25:45 --> Total execution time: 0.0566
INFO - 2020-09-10 02:29:41 --> Config Class Initialized
INFO - 2020-09-10 02:29:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:29:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:29:41 --> Utf8 Class Initialized
INFO - 2020-09-10 02:29:41 --> URI Class Initialized
INFO - 2020-09-10 02:29:41 --> Router Class Initialized
INFO - 2020-09-10 02:29:41 --> Output Class Initialized
INFO - 2020-09-10 02:29:41 --> Security Class Initialized
DEBUG - 2020-09-10 02:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:29:41 --> Input Class Initialized
INFO - 2020-09-10 02:29:41 --> Language Class Initialized
INFO - 2020-09-10 02:29:41 --> Language Class Initialized
INFO - 2020-09-10 02:29:41 --> Config Class Initialized
INFO - 2020-09-10 02:29:41 --> Loader Class Initialized
INFO - 2020-09-10 02:29:41 --> Helper loaded: url_helper
INFO - 2020-09-10 02:29:41 --> Helper loaded: form_helper
INFO - 2020-09-10 02:29:41 --> Helper loaded: file_helper
INFO - 2020-09-10 02:29:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:29:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:29:41 --> Upload Class Initialized
INFO - 2020-09-10 02:29:41 --> Controller Class Initialized
ERROR - 2020-09-10 02:29:41 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:29:42 --> Config Class Initialized
INFO - 2020-09-10 02:29:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:29:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:29:42 --> Utf8 Class Initialized
INFO - 2020-09-10 02:29:42 --> URI Class Initialized
DEBUG - 2020-09-10 02:29:42 --> No URI present. Default controller set.
INFO - 2020-09-10 02:29:42 --> Router Class Initialized
INFO - 2020-09-10 02:29:42 --> Output Class Initialized
INFO - 2020-09-10 02:29:42 --> Security Class Initialized
DEBUG - 2020-09-10 02:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:29:42 --> Input Class Initialized
INFO - 2020-09-10 02:29:42 --> Language Class Initialized
INFO - 2020-09-10 02:29:42 --> Language Class Initialized
INFO - 2020-09-10 02:29:42 --> Config Class Initialized
INFO - 2020-09-10 02:29:42 --> Loader Class Initialized
INFO - 2020-09-10 02:29:42 --> Helper loaded: url_helper
INFO - 2020-09-10 02:29:42 --> Helper loaded: form_helper
INFO - 2020-09-10 02:29:42 --> Helper loaded: file_helper
INFO - 2020-09-10 02:29:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:29:42 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:29:42 --> Upload Class Initialized
INFO - 2020-09-10 02:29:42 --> Controller Class Initialized
DEBUG - 2020-09-10 02:29:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:29:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 02:29:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 02:29:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:29:42 --> Final output sent to browser
DEBUG - 2020-09-10 02:29:42 --> Total execution time: 0.0489
INFO - 2020-09-10 02:29:42 --> Config Class Initialized
INFO - 2020-09-10 02:29:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:29:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:29:42 --> Utf8 Class Initialized
INFO - 2020-09-10 02:29:42 --> URI Class Initialized
INFO - 2020-09-10 02:29:42 --> Router Class Initialized
INFO - 2020-09-10 02:29:42 --> Output Class Initialized
INFO - 2020-09-10 02:29:42 --> Security Class Initialized
DEBUG - 2020-09-10 02:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:29:42 --> Input Class Initialized
INFO - 2020-09-10 02:29:42 --> Language Class Initialized
INFO - 2020-09-10 02:29:42 --> Language Class Initialized
INFO - 2020-09-10 02:29:42 --> Config Class Initialized
INFO - 2020-09-10 02:29:42 --> Loader Class Initialized
INFO - 2020-09-10 02:29:42 --> Helper loaded: url_helper
INFO - 2020-09-10 02:29:42 --> Helper loaded: form_helper
INFO - 2020-09-10 02:29:42 --> Helper loaded: file_helper
INFO - 2020-09-10 02:29:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:29:42 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:29:42 --> Upload Class Initialized
INFO - 2020-09-10 02:29:42 --> Controller Class Initialized
ERROR - 2020-09-10 02:29:42 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:29:43 --> Config Class Initialized
INFO - 2020-09-10 02:29:43 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:29:43 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:29:43 --> Utf8 Class Initialized
INFO - 2020-09-10 02:29:43 --> URI Class Initialized
INFO - 2020-09-10 02:29:43 --> Router Class Initialized
INFO - 2020-09-10 02:29:43 --> Output Class Initialized
INFO - 2020-09-10 02:29:43 --> Security Class Initialized
DEBUG - 2020-09-10 02:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:29:43 --> Input Class Initialized
INFO - 2020-09-10 02:29:43 --> Language Class Initialized
INFO - 2020-09-10 02:29:43 --> Language Class Initialized
INFO - 2020-09-10 02:29:43 --> Config Class Initialized
INFO - 2020-09-10 02:29:43 --> Loader Class Initialized
INFO - 2020-09-10 02:29:43 --> Helper loaded: url_helper
INFO - 2020-09-10 02:29:43 --> Helper loaded: form_helper
INFO - 2020-09-10 02:29:43 --> Helper loaded: file_helper
INFO - 2020-09-10 02:29:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:29:43 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:29:43 --> Upload Class Initialized
INFO - 2020-09-10 02:29:43 --> Controller Class Initialized
DEBUG - 2020-09-10 02:29:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:29:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-10 02:29:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:29:43 --> Final output sent to browser
DEBUG - 2020-09-10 02:29:43 --> Total execution time: 0.0718
INFO - 2020-09-10 02:29:44 --> Config Class Initialized
INFO - 2020-09-10 02:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:29:44 --> Utf8 Class Initialized
INFO - 2020-09-10 02:29:44 --> URI Class Initialized
INFO - 2020-09-10 02:29:44 --> Router Class Initialized
INFO - 2020-09-10 02:29:44 --> Output Class Initialized
INFO - 2020-09-10 02:29:44 --> Security Class Initialized
DEBUG - 2020-09-10 02:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:29:44 --> Input Class Initialized
INFO - 2020-09-10 02:29:44 --> Language Class Initialized
INFO - 2020-09-10 02:29:44 --> Language Class Initialized
INFO - 2020-09-10 02:29:44 --> Config Class Initialized
INFO - 2020-09-10 02:29:44 --> Loader Class Initialized
INFO - 2020-09-10 02:29:44 --> Helper loaded: url_helper
INFO - 2020-09-10 02:29:44 --> Helper loaded: form_helper
INFO - 2020-09-10 02:29:44 --> Helper loaded: file_helper
INFO - 2020-09-10 02:29:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:29:44 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:29:44 --> Upload Class Initialized
INFO - 2020-09-10 02:29:44 --> Controller Class Initialized
DEBUG - 2020-09-10 02:29:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:29:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-10 02:29:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:29:44 --> Final output sent to browser
DEBUG - 2020-09-10 02:29:44 --> Total execution time: 0.0516
INFO - 2020-09-10 02:37:31 --> Config Class Initialized
INFO - 2020-09-10 02:37:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:37:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:37:31 --> Utf8 Class Initialized
INFO - 2020-09-10 02:37:31 --> URI Class Initialized
INFO - 2020-09-10 02:37:31 --> Router Class Initialized
INFO - 2020-09-10 02:37:31 --> Output Class Initialized
INFO - 2020-09-10 02:37:31 --> Security Class Initialized
DEBUG - 2020-09-10 02:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:37:31 --> Input Class Initialized
INFO - 2020-09-10 02:37:31 --> Language Class Initialized
INFO - 2020-09-10 02:37:31 --> Language Class Initialized
INFO - 2020-09-10 02:37:31 --> Config Class Initialized
INFO - 2020-09-10 02:37:31 --> Loader Class Initialized
INFO - 2020-09-10 02:37:31 --> Helper loaded: url_helper
INFO - 2020-09-10 02:37:31 --> Helper loaded: form_helper
INFO - 2020-09-10 02:37:31 --> Helper loaded: file_helper
INFO - 2020-09-10 02:37:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:37:31 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:37:31 --> Upload Class Initialized
INFO - 2020-09-10 02:37:31 --> Controller Class Initialized
ERROR - 2020-09-10 02:37:31 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:37:31 --> Config Class Initialized
INFO - 2020-09-10 02:37:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:37:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:37:31 --> Utf8 Class Initialized
INFO - 2020-09-10 02:37:31 --> URI Class Initialized
INFO - 2020-09-10 02:37:31 --> Router Class Initialized
INFO - 2020-09-10 02:37:31 --> Output Class Initialized
INFO - 2020-09-10 02:37:31 --> Security Class Initialized
DEBUG - 2020-09-10 02:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:37:31 --> Input Class Initialized
INFO - 2020-09-10 02:37:31 --> Language Class Initialized
INFO - 2020-09-10 02:37:31 --> Language Class Initialized
INFO - 2020-09-10 02:37:31 --> Config Class Initialized
INFO - 2020-09-10 02:37:31 --> Loader Class Initialized
INFO - 2020-09-10 02:37:31 --> Helper loaded: url_helper
INFO - 2020-09-10 02:37:31 --> Helper loaded: form_helper
INFO - 2020-09-10 02:37:31 --> Helper loaded: file_helper
INFO - 2020-09-10 02:37:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:37:31 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:37:31 --> Upload Class Initialized
INFO - 2020-09-10 02:37:31 --> Controller Class Initialized
ERROR - 2020-09-10 02:37:31 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:52:29 --> Config Class Initialized
INFO - 2020-09-10 02:52:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:52:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:52:29 --> Utf8 Class Initialized
INFO - 2020-09-10 02:52:29 --> URI Class Initialized
INFO - 2020-09-10 02:52:29 --> Router Class Initialized
INFO - 2020-09-10 02:52:29 --> Output Class Initialized
INFO - 2020-09-10 02:52:29 --> Security Class Initialized
DEBUG - 2020-09-10 02:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:52:29 --> Input Class Initialized
INFO - 2020-09-10 02:52:29 --> Language Class Initialized
INFO - 2020-09-10 02:52:29 --> Language Class Initialized
INFO - 2020-09-10 02:52:29 --> Config Class Initialized
INFO - 2020-09-10 02:52:29 --> Loader Class Initialized
INFO - 2020-09-10 02:52:29 --> Helper loaded: url_helper
INFO - 2020-09-10 02:52:29 --> Helper loaded: form_helper
INFO - 2020-09-10 02:52:29 --> Helper loaded: file_helper
INFO - 2020-09-10 02:52:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:52:29 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:52:29 --> Upload Class Initialized
INFO - 2020-09-10 02:52:29 --> Controller Class Initialized
ERROR - 2020-09-10 02:52:29 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:58:00 --> Config Class Initialized
INFO - 2020-09-10 02:58:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:00 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:00 --> URI Class Initialized
INFO - 2020-09-10 02:58:00 --> Router Class Initialized
INFO - 2020-09-10 02:58:00 --> Output Class Initialized
INFO - 2020-09-10 02:58:00 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:00 --> Input Class Initialized
INFO - 2020-09-10 02:58:00 --> Language Class Initialized
INFO - 2020-09-10 02:58:00 --> Language Class Initialized
INFO - 2020-09-10 02:58:00 --> Config Class Initialized
INFO - 2020-09-10 02:58:00 --> Loader Class Initialized
INFO - 2020-09-10 02:58:00 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:00 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:00 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:00 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:00 --> Upload Class Initialized
INFO - 2020-09-10 02:58:00 --> Controller Class Initialized
ERROR - 2020-09-10 02:58:00 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:58:04 --> Config Class Initialized
INFO - 2020-09-10 02:58:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:04 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:04 --> URI Class Initialized
INFO - 2020-09-10 02:58:04 --> Router Class Initialized
INFO - 2020-09-10 02:58:04 --> Output Class Initialized
INFO - 2020-09-10 02:58:04 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:04 --> Input Class Initialized
INFO - 2020-09-10 02:58:04 --> Language Class Initialized
INFO - 2020-09-10 02:58:04 --> Language Class Initialized
INFO - 2020-09-10 02:58:04 --> Config Class Initialized
INFO - 2020-09-10 02:58:04 --> Loader Class Initialized
INFO - 2020-09-10 02:58:04 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:04 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:04 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:04 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:04 --> Upload Class Initialized
INFO - 2020-09-10 02:58:04 --> Controller Class Initialized
ERROR - 2020-09-10 02:58:04 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:58:08 --> Config Class Initialized
INFO - 2020-09-10 02:58:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:08 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:08 --> URI Class Initialized
INFO - 2020-09-10 02:58:08 --> Router Class Initialized
INFO - 2020-09-10 02:58:08 --> Output Class Initialized
INFO - 2020-09-10 02:58:08 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:08 --> Input Class Initialized
INFO - 2020-09-10 02:58:08 --> Language Class Initialized
INFO - 2020-09-10 02:58:08 --> Language Class Initialized
INFO - 2020-09-10 02:58:08 --> Config Class Initialized
INFO - 2020-09-10 02:58:08 --> Loader Class Initialized
INFO - 2020-09-10 02:58:08 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:08 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:08 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:08 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:08 --> Upload Class Initialized
INFO - 2020-09-10 02:58:08 --> Controller Class Initialized
ERROR - 2020-09-10 02:58:08 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:58:22 --> Config Class Initialized
INFO - 2020-09-10 02:58:22 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:22 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:22 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:22 --> URI Class Initialized
INFO - 2020-09-10 02:58:22 --> Router Class Initialized
INFO - 2020-09-10 02:58:22 --> Output Class Initialized
INFO - 2020-09-10 02:58:22 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:22 --> Input Class Initialized
INFO - 2020-09-10 02:58:22 --> Language Class Initialized
INFO - 2020-09-10 02:58:22 --> Language Class Initialized
INFO - 2020-09-10 02:58:22 --> Config Class Initialized
INFO - 2020-09-10 02:58:22 --> Loader Class Initialized
INFO - 2020-09-10 02:58:22 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:22 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:22 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:22 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:22 --> Upload Class Initialized
INFO - 2020-09-10 02:58:22 --> Controller Class Initialized
ERROR - 2020-09-10 02:58:22 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:58:25 --> Config Class Initialized
INFO - 2020-09-10 02:58:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:25 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:25 --> URI Class Initialized
DEBUG - 2020-09-10 02:58:25 --> No URI present. Default controller set.
INFO - 2020-09-10 02:58:25 --> Router Class Initialized
INFO - 2020-09-10 02:58:25 --> Output Class Initialized
INFO - 2020-09-10 02:58:25 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:25 --> Input Class Initialized
INFO - 2020-09-10 02:58:25 --> Language Class Initialized
INFO - 2020-09-10 02:58:25 --> Language Class Initialized
INFO - 2020-09-10 02:58:25 --> Config Class Initialized
INFO - 2020-09-10 02:58:25 --> Loader Class Initialized
INFO - 2020-09-10 02:58:25 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:25 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:25 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:25 --> Upload Class Initialized
INFO - 2020-09-10 02:58:25 --> Controller Class Initialized
DEBUG - 2020-09-10 02:58:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:58:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 02:58:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 02:58:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:58:25 --> Final output sent to browser
DEBUG - 2020-09-10 02:58:25 --> Total execution time: 0.0606
INFO - 2020-09-10 02:58:30 --> Config Class Initialized
INFO - 2020-09-10 02:58:30 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:30 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:30 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:30 --> URI Class Initialized
DEBUG - 2020-09-10 02:58:30 --> No URI present. Default controller set.
INFO - 2020-09-10 02:58:30 --> Router Class Initialized
INFO - 2020-09-10 02:58:30 --> Output Class Initialized
INFO - 2020-09-10 02:58:30 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:30 --> Input Class Initialized
INFO - 2020-09-10 02:58:30 --> Language Class Initialized
INFO - 2020-09-10 02:58:30 --> Language Class Initialized
INFO - 2020-09-10 02:58:30 --> Config Class Initialized
INFO - 2020-09-10 02:58:30 --> Loader Class Initialized
INFO - 2020-09-10 02:58:30 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:30 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:30 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:30 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:30 --> Upload Class Initialized
INFO - 2020-09-10 02:58:30 --> Controller Class Initialized
DEBUG - 2020-09-10 02:58:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:58:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 02:58:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 02:58:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:58:30 --> Final output sent to browser
DEBUG - 2020-09-10 02:58:30 --> Total execution time: 0.0479
INFO - 2020-09-10 02:58:57 --> Config Class Initialized
INFO - 2020-09-10 02:58:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:58:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:58:57 --> Utf8 Class Initialized
INFO - 2020-09-10 02:58:57 --> URI Class Initialized
INFO - 2020-09-10 02:58:57 --> Router Class Initialized
INFO - 2020-09-10 02:58:57 --> Output Class Initialized
INFO - 2020-09-10 02:58:57 --> Security Class Initialized
DEBUG - 2020-09-10 02:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:58:57 --> Input Class Initialized
INFO - 2020-09-10 02:58:57 --> Language Class Initialized
INFO - 2020-09-10 02:58:57 --> Language Class Initialized
INFO - 2020-09-10 02:58:57 --> Config Class Initialized
INFO - 2020-09-10 02:58:57 --> Loader Class Initialized
INFO - 2020-09-10 02:58:57 --> Helper loaded: url_helper
INFO - 2020-09-10 02:58:57 --> Helper loaded: form_helper
INFO - 2020-09-10 02:58:57 --> Helper loaded: file_helper
INFO - 2020-09-10 02:58:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:58:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:58:57 --> Upload Class Initialized
INFO - 2020-09-10 02:58:57 --> Controller Class Initialized
ERROR - 2020-09-10 02:58:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:59:20 --> Config Class Initialized
INFO - 2020-09-10 02:59:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:20 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:20 --> URI Class Initialized
INFO - 2020-09-10 02:59:20 --> Router Class Initialized
INFO - 2020-09-10 02:59:20 --> Output Class Initialized
INFO - 2020-09-10 02:59:20 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:20 --> Input Class Initialized
INFO - 2020-09-10 02:59:20 --> Language Class Initialized
INFO - 2020-09-10 02:59:20 --> Language Class Initialized
INFO - 2020-09-10 02:59:20 --> Config Class Initialized
INFO - 2020-09-10 02:59:20 --> Loader Class Initialized
INFO - 2020-09-10 02:59:20 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:20 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:20 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:20 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:20 --> Upload Class Initialized
INFO - 2020-09-10 02:59:20 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-10 02:59:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:20 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:20 --> Total execution time: 0.0601
INFO - 2020-09-10 02:59:24 --> Config Class Initialized
INFO - 2020-09-10 02:59:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:24 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:24 --> URI Class Initialized
INFO - 2020-09-10 02:59:24 --> Router Class Initialized
INFO - 2020-09-10 02:59:24 --> Output Class Initialized
INFO - 2020-09-10 02:59:24 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:24 --> Input Class Initialized
INFO - 2020-09-10 02:59:24 --> Language Class Initialized
INFO - 2020-09-10 02:59:24 --> Language Class Initialized
INFO - 2020-09-10 02:59:24 --> Config Class Initialized
INFO - 2020-09-10 02:59:24 --> Loader Class Initialized
INFO - 2020-09-10 02:59:24 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:24 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:24 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:24 --> Upload Class Initialized
INFO - 2020-09-10 02:59:24 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-10 02:59:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:24 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:24 --> Total execution time: 0.0611
INFO - 2020-09-10 02:59:27 --> Config Class Initialized
INFO - 2020-09-10 02:59:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:27 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:27 --> URI Class Initialized
INFO - 2020-09-10 02:59:27 --> Router Class Initialized
INFO - 2020-09-10 02:59:27 --> Output Class Initialized
INFO - 2020-09-10 02:59:27 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:27 --> Input Class Initialized
INFO - 2020-09-10 02:59:27 --> Language Class Initialized
INFO - 2020-09-10 02:59:27 --> Language Class Initialized
INFO - 2020-09-10 02:59:27 --> Config Class Initialized
INFO - 2020-09-10 02:59:27 --> Loader Class Initialized
INFO - 2020-09-10 02:59:27 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:27 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:27 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:27 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:27 --> Upload Class Initialized
INFO - 2020-09-10 02:59:27 --> Controller Class Initialized
ERROR - 2020-09-10 02:59:27 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:59:29 --> Config Class Initialized
INFO - 2020-09-10 02:59:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:29 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:29 --> URI Class Initialized
INFO - 2020-09-10 02:59:29 --> Router Class Initialized
INFO - 2020-09-10 02:59:29 --> Output Class Initialized
INFO - 2020-09-10 02:59:29 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:29 --> Input Class Initialized
INFO - 2020-09-10 02:59:29 --> Language Class Initialized
INFO - 2020-09-10 02:59:29 --> Language Class Initialized
INFO - 2020-09-10 02:59:29 --> Config Class Initialized
INFO - 2020-09-10 02:59:29 --> Loader Class Initialized
INFO - 2020-09-10 02:59:29 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:29 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:29 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:29 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:29 --> Upload Class Initialized
INFO - 2020-09-10 02:59:29 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-10 02:59:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:29 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:29 --> Total execution time: 0.0536
INFO - 2020-09-10 02:59:32 --> Config Class Initialized
INFO - 2020-09-10 02:59:32 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:32 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:32 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:32 --> URI Class Initialized
INFO - 2020-09-10 02:59:32 --> Router Class Initialized
INFO - 2020-09-10 02:59:32 --> Output Class Initialized
INFO - 2020-09-10 02:59:32 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:32 --> Input Class Initialized
INFO - 2020-09-10 02:59:32 --> Language Class Initialized
INFO - 2020-09-10 02:59:32 --> Language Class Initialized
INFO - 2020-09-10 02:59:32 --> Config Class Initialized
INFO - 2020-09-10 02:59:32 --> Loader Class Initialized
INFO - 2020-09-10 02:59:32 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:32 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:32 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:32 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:32 --> Upload Class Initialized
INFO - 2020-09-10 02:59:32 --> Controller Class Initialized
ERROR - 2020-09-10 02:59:32 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:59:35 --> Config Class Initialized
INFO - 2020-09-10 02:59:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:35 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:35 --> URI Class Initialized
INFO - 2020-09-10 02:59:35 --> Router Class Initialized
INFO - 2020-09-10 02:59:35 --> Output Class Initialized
INFO - 2020-09-10 02:59:35 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:35 --> Input Class Initialized
INFO - 2020-09-10 02:59:35 --> Language Class Initialized
INFO - 2020-09-10 02:59:35 --> Language Class Initialized
INFO - 2020-09-10 02:59:35 --> Config Class Initialized
INFO - 2020-09-10 02:59:35 --> Loader Class Initialized
INFO - 2020-09-10 02:59:35 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:35 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:35 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:35 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:35 --> Upload Class Initialized
INFO - 2020-09-10 02:59:35 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 02:59:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 02:59:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:35 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:35 --> Total execution time: 0.0594
INFO - 2020-09-10 02:59:38 --> Config Class Initialized
INFO - 2020-09-10 02:59:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:38 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:38 --> URI Class Initialized
INFO - 2020-09-10 02:59:38 --> Router Class Initialized
INFO - 2020-09-10 02:59:38 --> Output Class Initialized
INFO - 2020-09-10 02:59:38 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:38 --> Input Class Initialized
INFO - 2020-09-10 02:59:38 --> Language Class Initialized
INFO - 2020-09-10 02:59:38 --> Language Class Initialized
INFO - 2020-09-10 02:59:38 --> Config Class Initialized
INFO - 2020-09-10 02:59:38 --> Loader Class Initialized
INFO - 2020-09-10 02:59:38 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:38 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:38 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:38 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:38 --> Upload Class Initialized
INFO - 2020-09-10 02:59:38 --> Controller Class Initialized
ERROR - 2020-09-10 02:59:38 --> 404 Page Not Found: /index
INFO - 2020-09-10 02:59:41 --> Config Class Initialized
INFO - 2020-09-10 02:59:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:41 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:41 --> URI Class Initialized
INFO - 2020-09-10 02:59:41 --> Router Class Initialized
INFO - 2020-09-10 02:59:41 --> Output Class Initialized
INFO - 2020-09-10 02:59:41 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:41 --> Input Class Initialized
INFO - 2020-09-10 02:59:41 --> Language Class Initialized
INFO - 2020-09-10 02:59:41 --> Language Class Initialized
INFO - 2020-09-10 02:59:41 --> Config Class Initialized
INFO - 2020-09-10 02:59:41 --> Loader Class Initialized
INFO - 2020-09-10 02:59:41 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:41 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:41 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:41 --> Upload Class Initialized
INFO - 2020-09-10 02:59:41 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-10 02:59:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:41 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:41 --> Total execution time: 0.0578
INFO - 2020-09-10 02:59:45 --> Config Class Initialized
INFO - 2020-09-10 02:59:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:45 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:45 --> URI Class Initialized
INFO - 2020-09-10 02:59:45 --> Router Class Initialized
INFO - 2020-09-10 02:59:45 --> Output Class Initialized
INFO - 2020-09-10 02:59:45 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:45 --> Input Class Initialized
INFO - 2020-09-10 02:59:45 --> Language Class Initialized
INFO - 2020-09-10 02:59:45 --> Language Class Initialized
INFO - 2020-09-10 02:59:45 --> Config Class Initialized
INFO - 2020-09-10 02:59:45 --> Loader Class Initialized
INFO - 2020-09-10 02:59:45 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:45 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:45 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:45 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:45 --> Upload Class Initialized
INFO - 2020-09-10 02:59:46 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-10 02:59:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:46 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:46 --> Total execution time: 0.0601
INFO - 2020-09-10 02:59:50 --> Config Class Initialized
INFO - 2020-09-10 02:59:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:50 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:50 --> URI Class Initialized
INFO - 2020-09-10 02:59:50 --> Router Class Initialized
INFO - 2020-09-10 02:59:50 --> Output Class Initialized
INFO - 2020-09-10 02:59:50 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:50 --> Input Class Initialized
INFO - 2020-09-10 02:59:51 --> Language Class Initialized
INFO - 2020-09-10 02:59:51 --> Language Class Initialized
INFO - 2020-09-10 02:59:51 --> Config Class Initialized
INFO - 2020-09-10 02:59:51 --> Loader Class Initialized
INFO - 2020-09-10 02:59:51 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:51 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:51 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:51 --> Upload Class Initialized
INFO - 2020-09-10 02:59:51 --> Controller Class Initialized
DEBUG - 2020-09-10 02:59:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 02:59:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-10 02:59:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 02:59:51 --> Final output sent to browser
DEBUG - 2020-09-10 02:59:51 --> Total execution time: 0.0491
INFO - 2020-09-10 02:59:52 --> Config Class Initialized
INFO - 2020-09-10 02:59:52 --> Hooks Class Initialized
DEBUG - 2020-09-10 02:59:52 --> UTF-8 Support Enabled
INFO - 2020-09-10 02:59:52 --> Utf8 Class Initialized
INFO - 2020-09-10 02:59:52 --> URI Class Initialized
INFO - 2020-09-10 02:59:52 --> Router Class Initialized
INFO - 2020-09-10 02:59:52 --> Output Class Initialized
INFO - 2020-09-10 02:59:52 --> Security Class Initialized
DEBUG - 2020-09-10 02:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 02:59:52 --> Input Class Initialized
INFO - 2020-09-10 02:59:52 --> Language Class Initialized
INFO - 2020-09-10 02:59:52 --> Language Class Initialized
INFO - 2020-09-10 02:59:52 --> Config Class Initialized
INFO - 2020-09-10 02:59:52 --> Loader Class Initialized
INFO - 2020-09-10 02:59:52 --> Helper loaded: url_helper
INFO - 2020-09-10 02:59:52 --> Helper loaded: form_helper
INFO - 2020-09-10 02:59:52 --> Helper loaded: file_helper
INFO - 2020-09-10 02:59:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 02:59:52 --> Database Driver Class Initialized
DEBUG - 2020-09-10 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 02:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 02:59:52 --> Upload Class Initialized
INFO - 2020-09-10 02:59:52 --> Controller Class Initialized
ERROR - 2020-09-10 02:59:52 --> 404 Page Not Found: /index
INFO - 2020-09-10 03:00:08 --> Config Class Initialized
INFO - 2020-09-10 03:00:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:00:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:00:08 --> Utf8 Class Initialized
INFO - 2020-09-10 03:00:08 --> URI Class Initialized
INFO - 2020-09-10 03:00:08 --> Router Class Initialized
INFO - 2020-09-10 03:00:08 --> Output Class Initialized
INFO - 2020-09-10 03:00:08 --> Security Class Initialized
DEBUG - 2020-09-10 03:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:00:08 --> Input Class Initialized
INFO - 2020-09-10 03:00:08 --> Language Class Initialized
INFO - 2020-09-10 03:00:08 --> Language Class Initialized
INFO - 2020-09-10 03:00:08 --> Config Class Initialized
INFO - 2020-09-10 03:00:08 --> Loader Class Initialized
INFO - 2020-09-10 03:00:08 --> Helper loaded: url_helper
INFO - 2020-09-10 03:00:08 --> Helper loaded: form_helper
INFO - 2020-09-10 03:00:08 --> Helper loaded: file_helper
INFO - 2020-09-10 03:00:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:00:08 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:00:08 --> Upload Class Initialized
INFO - 2020-09-10 03:00:08 --> Controller Class Initialized
DEBUG - 2020-09-10 03:00:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:00:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-10 03:00:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:00:08 --> Final output sent to browser
DEBUG - 2020-09-10 03:00:08 --> Total execution time: 0.0535
INFO - 2020-09-10 03:00:09 --> Config Class Initialized
INFO - 2020-09-10 03:00:09 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:00:09 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:00:09 --> Utf8 Class Initialized
INFO - 2020-09-10 03:00:09 --> URI Class Initialized
INFO - 2020-09-10 03:00:09 --> Router Class Initialized
INFO - 2020-09-10 03:00:09 --> Output Class Initialized
INFO - 2020-09-10 03:00:09 --> Security Class Initialized
DEBUG - 2020-09-10 03:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:00:09 --> Input Class Initialized
INFO - 2020-09-10 03:00:09 --> Language Class Initialized
INFO - 2020-09-10 03:00:09 --> Language Class Initialized
INFO - 2020-09-10 03:00:09 --> Config Class Initialized
INFO - 2020-09-10 03:00:09 --> Loader Class Initialized
INFO - 2020-09-10 03:00:09 --> Helper loaded: url_helper
INFO - 2020-09-10 03:00:09 --> Helper loaded: form_helper
INFO - 2020-09-10 03:00:09 --> Helper loaded: file_helper
INFO - 2020-09-10 03:00:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:00:09 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:00:09 --> Upload Class Initialized
INFO - 2020-09-10 03:00:09 --> Controller Class Initialized
DEBUG - 2020-09-10 03:00:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:00:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-10 03:00:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:00:09 --> Final output sent to browser
DEBUG - 2020-09-10 03:00:09 --> Total execution time: 0.0509
INFO - 2020-09-10 03:00:24 --> Config Class Initialized
INFO - 2020-09-10 03:00:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:00:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:00:24 --> Utf8 Class Initialized
INFO - 2020-09-10 03:00:24 --> URI Class Initialized
INFO - 2020-09-10 03:00:24 --> Router Class Initialized
INFO - 2020-09-10 03:00:24 --> Output Class Initialized
INFO - 2020-09-10 03:00:24 --> Security Class Initialized
DEBUG - 2020-09-10 03:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:00:24 --> Input Class Initialized
INFO - 2020-09-10 03:00:24 --> Language Class Initialized
INFO - 2020-09-10 03:00:24 --> Language Class Initialized
INFO - 2020-09-10 03:00:24 --> Config Class Initialized
INFO - 2020-09-10 03:00:24 --> Loader Class Initialized
INFO - 2020-09-10 03:00:24 --> Helper loaded: url_helper
INFO - 2020-09-10 03:00:24 --> Helper loaded: form_helper
INFO - 2020-09-10 03:00:24 --> Helper loaded: file_helper
INFO - 2020-09-10 03:00:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:00:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:00:24 --> Upload Class Initialized
INFO - 2020-09-10 03:00:24 --> Controller Class Initialized
DEBUG - 2020-09-10 03:00:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:00:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-10 03:00:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:00:24 --> Final output sent to browser
DEBUG - 2020-09-10 03:00:24 --> Total execution time: 0.0502
INFO - 2020-09-10 03:00:26 --> Config Class Initialized
INFO - 2020-09-10 03:00:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:00:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:00:26 --> Utf8 Class Initialized
INFO - 2020-09-10 03:00:26 --> URI Class Initialized
INFO - 2020-09-10 03:00:26 --> Router Class Initialized
INFO - 2020-09-10 03:00:26 --> Output Class Initialized
INFO - 2020-09-10 03:00:26 --> Security Class Initialized
DEBUG - 2020-09-10 03:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:00:26 --> Input Class Initialized
INFO - 2020-09-10 03:00:26 --> Language Class Initialized
INFO - 2020-09-10 03:00:26 --> Language Class Initialized
INFO - 2020-09-10 03:00:26 --> Config Class Initialized
INFO - 2020-09-10 03:00:26 --> Loader Class Initialized
INFO - 2020-09-10 03:00:26 --> Helper loaded: url_helper
INFO - 2020-09-10 03:00:26 --> Helper loaded: form_helper
INFO - 2020-09-10 03:00:26 --> Helper loaded: file_helper
INFO - 2020-09-10 03:00:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:00:26 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:00:26 --> Upload Class Initialized
INFO - 2020-09-10 03:00:26 --> Controller Class Initialized
DEBUG - 2020-09-10 03:00:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:00:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-10 03:00:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:00:26 --> Final output sent to browser
DEBUG - 2020-09-10 03:00:26 --> Total execution time: 0.0515
INFO - 2020-09-10 03:01:21 --> Config Class Initialized
INFO - 2020-09-10 03:01:21 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:01:21 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:01:21 --> Utf8 Class Initialized
INFO - 2020-09-10 03:01:21 --> URI Class Initialized
DEBUG - 2020-09-10 03:01:21 --> No URI present. Default controller set.
INFO - 2020-09-10 03:01:21 --> Router Class Initialized
INFO - 2020-09-10 03:01:21 --> Output Class Initialized
INFO - 2020-09-10 03:01:21 --> Security Class Initialized
DEBUG - 2020-09-10 03:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:01:21 --> Input Class Initialized
INFO - 2020-09-10 03:01:21 --> Language Class Initialized
INFO - 2020-09-10 03:01:21 --> Language Class Initialized
INFO - 2020-09-10 03:01:21 --> Config Class Initialized
INFO - 2020-09-10 03:01:21 --> Loader Class Initialized
INFO - 2020-09-10 03:01:21 --> Helper loaded: url_helper
INFO - 2020-09-10 03:01:21 --> Helper loaded: form_helper
INFO - 2020-09-10 03:01:21 --> Helper loaded: file_helper
INFO - 2020-09-10 03:01:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:01:21 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:01:21 --> Upload Class Initialized
INFO - 2020-09-10 03:01:21 --> Controller Class Initialized
DEBUG - 2020-09-10 03:01:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:01:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 03:01:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 03:01:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:01:21 --> Final output sent to browser
DEBUG - 2020-09-10 03:01:21 --> Total execution time: 0.0560
INFO - 2020-09-10 03:04:36 --> Config Class Initialized
INFO - 2020-09-10 03:04:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:04:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:04:36 --> Utf8 Class Initialized
INFO - 2020-09-10 03:04:36 --> URI Class Initialized
INFO - 2020-09-10 03:04:36 --> Router Class Initialized
INFO - 2020-09-10 03:04:36 --> Output Class Initialized
INFO - 2020-09-10 03:04:36 --> Security Class Initialized
DEBUG - 2020-09-10 03:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:04:36 --> Input Class Initialized
INFO - 2020-09-10 03:04:36 --> Language Class Initialized
INFO - 2020-09-10 03:04:36 --> Language Class Initialized
INFO - 2020-09-10 03:04:36 --> Config Class Initialized
INFO - 2020-09-10 03:04:36 --> Loader Class Initialized
INFO - 2020-09-10 03:04:36 --> Helper loaded: url_helper
INFO - 2020-09-10 03:04:36 --> Helper loaded: form_helper
INFO - 2020-09-10 03:04:36 --> Helper loaded: file_helper
INFO - 2020-09-10 03:04:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:04:36 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:04:36 --> Upload Class Initialized
INFO - 2020-09-10 03:04:36 --> Controller Class Initialized
DEBUG - 2020-09-10 03:04:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:04:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-10 03:04:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:04:36 --> Final output sent to browser
DEBUG - 2020-09-10 03:04:36 --> Total execution time: 0.0473
INFO - 2020-09-10 03:05:23 --> Config Class Initialized
INFO - 2020-09-10 03:05:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:23 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:23 --> URI Class Initialized
INFO - 2020-09-10 03:05:23 --> Router Class Initialized
INFO - 2020-09-10 03:05:23 --> Output Class Initialized
INFO - 2020-09-10 03:05:23 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:23 --> Input Class Initialized
INFO - 2020-09-10 03:05:23 --> Language Class Initialized
INFO - 2020-09-10 03:05:23 --> Language Class Initialized
INFO - 2020-09-10 03:05:23 --> Config Class Initialized
INFO - 2020-09-10 03:05:23 --> Loader Class Initialized
INFO - 2020-09-10 03:05:23 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:23 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:23 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:23 --> Upload Class Initialized
INFO - 2020-09-10 03:05:23 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-10 03:05:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:23 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:23 --> Total execution time: 0.0587
INFO - 2020-09-10 03:05:25 --> Config Class Initialized
INFO - 2020-09-10 03:05:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:25 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:25 --> URI Class Initialized
INFO - 2020-09-10 03:05:25 --> Router Class Initialized
INFO - 2020-09-10 03:05:25 --> Output Class Initialized
INFO - 2020-09-10 03:05:25 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:25 --> Input Class Initialized
INFO - 2020-09-10 03:05:25 --> Language Class Initialized
INFO - 2020-09-10 03:05:25 --> Language Class Initialized
INFO - 2020-09-10 03:05:25 --> Config Class Initialized
INFO - 2020-09-10 03:05:25 --> Loader Class Initialized
INFO - 2020-09-10 03:05:25 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:25 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:25 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:25 --> Upload Class Initialized
INFO - 2020-09-10 03:05:25 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-10 03:05:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:25 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:25 --> Total execution time: 0.0564
INFO - 2020-09-10 03:05:26 --> Config Class Initialized
INFO - 2020-09-10 03:05:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:26 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:26 --> URI Class Initialized
INFO - 2020-09-10 03:05:26 --> Router Class Initialized
INFO - 2020-09-10 03:05:26 --> Output Class Initialized
INFO - 2020-09-10 03:05:26 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:26 --> Input Class Initialized
INFO - 2020-09-10 03:05:26 --> Language Class Initialized
INFO - 2020-09-10 03:05:26 --> Language Class Initialized
INFO - 2020-09-10 03:05:26 --> Config Class Initialized
INFO - 2020-09-10 03:05:26 --> Loader Class Initialized
INFO - 2020-09-10 03:05:26 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:26 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:26 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:26 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:26 --> Upload Class Initialized
INFO - 2020-09-10 03:05:26 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-10 03:05:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:26 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:26 --> Total execution time: 0.0518
INFO - 2020-09-10 03:05:28 --> Config Class Initialized
INFO - 2020-09-10 03:05:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:28 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:28 --> URI Class Initialized
INFO - 2020-09-10 03:05:28 --> Router Class Initialized
INFO - 2020-09-10 03:05:28 --> Output Class Initialized
INFO - 2020-09-10 03:05:28 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:28 --> Input Class Initialized
INFO - 2020-09-10 03:05:28 --> Language Class Initialized
INFO - 2020-09-10 03:05:28 --> Language Class Initialized
INFO - 2020-09-10 03:05:28 --> Config Class Initialized
INFO - 2020-09-10 03:05:28 --> Loader Class Initialized
INFO - 2020-09-10 03:05:28 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:28 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:28 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:28 --> Upload Class Initialized
INFO - 2020-09-10 03:05:28 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-10 03:05:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:28 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:28 --> Total execution time: 0.0517
INFO - 2020-09-10 03:05:30 --> Config Class Initialized
INFO - 2020-09-10 03:05:30 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:30 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:30 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:30 --> URI Class Initialized
INFO - 2020-09-10 03:05:30 --> Router Class Initialized
INFO - 2020-09-10 03:05:30 --> Output Class Initialized
INFO - 2020-09-10 03:05:30 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:30 --> Input Class Initialized
INFO - 2020-09-10 03:05:30 --> Language Class Initialized
INFO - 2020-09-10 03:05:30 --> Language Class Initialized
INFO - 2020-09-10 03:05:30 --> Config Class Initialized
INFO - 2020-09-10 03:05:30 --> Loader Class Initialized
INFO - 2020-09-10 03:05:30 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:30 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:30 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:30 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:30 --> Upload Class Initialized
INFO - 2020-09-10 03:05:30 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-10 03:05:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:30 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:30 --> Total execution time: 0.0631
INFO - 2020-09-10 03:05:31 --> Config Class Initialized
INFO - 2020-09-10 03:05:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:31 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:31 --> URI Class Initialized
INFO - 2020-09-10 03:05:31 --> Router Class Initialized
INFO - 2020-09-10 03:05:31 --> Output Class Initialized
INFO - 2020-09-10 03:05:31 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:31 --> Input Class Initialized
INFO - 2020-09-10 03:05:31 --> Language Class Initialized
INFO - 2020-09-10 03:05:31 --> Language Class Initialized
INFO - 2020-09-10 03:05:31 --> Config Class Initialized
INFO - 2020-09-10 03:05:31 --> Loader Class Initialized
INFO - 2020-09-10 03:05:31 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:31 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:31 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:31 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:31 --> Upload Class Initialized
INFO - 2020-09-10 03:05:31 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 03:05:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 03:05:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:31 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:31 --> Total execution time: 0.0577
INFO - 2020-09-10 03:05:32 --> Config Class Initialized
INFO - 2020-09-10 03:05:32 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:32 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:32 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:32 --> URI Class Initialized
INFO - 2020-09-10 03:05:32 --> Router Class Initialized
INFO - 2020-09-10 03:05:32 --> Output Class Initialized
INFO - 2020-09-10 03:05:32 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:32 --> Input Class Initialized
INFO - 2020-09-10 03:05:32 --> Language Class Initialized
INFO - 2020-09-10 03:05:32 --> Language Class Initialized
INFO - 2020-09-10 03:05:32 --> Config Class Initialized
INFO - 2020-09-10 03:05:32 --> Loader Class Initialized
INFO - 2020-09-10 03:05:32 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:32 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:32 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:32 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:32 --> Upload Class Initialized
INFO - 2020-09-10 03:05:32 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-10 03:05:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:32 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:32 --> Total execution time: 0.0457
INFO - 2020-09-10 03:05:33 --> Config Class Initialized
INFO - 2020-09-10 03:05:33 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:33 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:33 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:33 --> URI Class Initialized
INFO - 2020-09-10 03:05:33 --> Router Class Initialized
INFO - 2020-09-10 03:05:33 --> Output Class Initialized
INFO - 2020-09-10 03:05:33 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:33 --> Input Class Initialized
INFO - 2020-09-10 03:05:33 --> Language Class Initialized
INFO - 2020-09-10 03:05:33 --> Language Class Initialized
INFO - 2020-09-10 03:05:33 --> Config Class Initialized
INFO - 2020-09-10 03:05:33 --> Loader Class Initialized
INFO - 2020-09-10 03:05:33 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:33 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:33 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:33 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:33 --> Upload Class Initialized
INFO - 2020-09-10 03:05:34 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-10 03:05:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:34 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:34 --> Total execution time: 0.0454
INFO - 2020-09-10 03:05:35 --> Config Class Initialized
INFO - 2020-09-10 03:05:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:35 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:35 --> URI Class Initialized
INFO - 2020-09-10 03:05:35 --> Router Class Initialized
INFO - 2020-09-10 03:05:35 --> Output Class Initialized
INFO - 2020-09-10 03:05:35 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:35 --> Input Class Initialized
INFO - 2020-09-10 03:05:35 --> Language Class Initialized
INFO - 2020-09-10 03:05:35 --> Language Class Initialized
INFO - 2020-09-10 03:05:35 --> Config Class Initialized
INFO - 2020-09-10 03:05:35 --> Loader Class Initialized
INFO - 2020-09-10 03:05:35 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:35 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:35 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:35 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:35 --> Upload Class Initialized
INFO - 2020-09-10 03:05:35 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 03:05:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 03:05:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:35 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:35 --> Total execution time: 0.0605
INFO - 2020-09-10 03:05:36 --> Config Class Initialized
INFO - 2020-09-10 03:05:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:36 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:36 --> URI Class Initialized
INFO - 2020-09-10 03:05:36 --> Router Class Initialized
INFO - 2020-09-10 03:05:36 --> Output Class Initialized
INFO - 2020-09-10 03:05:36 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:36 --> Input Class Initialized
INFO - 2020-09-10 03:05:36 --> Language Class Initialized
INFO - 2020-09-10 03:05:36 --> Language Class Initialized
INFO - 2020-09-10 03:05:36 --> Config Class Initialized
INFO - 2020-09-10 03:05:36 --> Loader Class Initialized
INFO - 2020-09-10 03:05:36 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:36 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:36 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:36 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:36 --> Upload Class Initialized
INFO - 2020-09-10 03:05:36 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-10 03:05:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:36 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:36 --> Total execution time: 0.0703
INFO - 2020-09-10 03:05:37 --> Config Class Initialized
INFO - 2020-09-10 03:05:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:37 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:37 --> URI Class Initialized
INFO - 2020-09-10 03:05:37 --> Router Class Initialized
INFO - 2020-09-10 03:05:37 --> Output Class Initialized
INFO - 2020-09-10 03:05:37 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:37 --> Input Class Initialized
INFO - 2020-09-10 03:05:37 --> Language Class Initialized
INFO - 2020-09-10 03:05:37 --> Language Class Initialized
INFO - 2020-09-10 03:05:37 --> Config Class Initialized
INFO - 2020-09-10 03:05:37 --> Loader Class Initialized
INFO - 2020-09-10 03:05:37 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:37 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:37 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:37 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:37 --> Upload Class Initialized
INFO - 2020-09-10 03:05:38 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-10 03:05:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:38 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:38 --> Total execution time: 0.0421
INFO - 2020-09-10 03:05:39 --> Config Class Initialized
INFO - 2020-09-10 03:05:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:39 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:39 --> URI Class Initialized
INFO - 2020-09-10 03:05:39 --> Router Class Initialized
INFO - 2020-09-10 03:05:39 --> Output Class Initialized
INFO - 2020-09-10 03:05:39 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:39 --> Input Class Initialized
INFO - 2020-09-10 03:05:39 --> Language Class Initialized
INFO - 2020-09-10 03:05:39 --> Language Class Initialized
INFO - 2020-09-10 03:05:39 --> Config Class Initialized
INFO - 2020-09-10 03:05:39 --> Loader Class Initialized
INFO - 2020-09-10 03:05:39 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:39 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:39 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:39 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:39 --> Upload Class Initialized
INFO - 2020-09-10 03:05:39 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-10 03:05:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:39 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:39 --> Total execution time: 0.0437
INFO - 2020-09-10 03:05:40 --> Config Class Initialized
INFO - 2020-09-10 03:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:40 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:40 --> URI Class Initialized
INFO - 2020-09-10 03:05:40 --> Router Class Initialized
INFO - 2020-09-10 03:05:40 --> Output Class Initialized
INFO - 2020-09-10 03:05:40 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:40 --> Input Class Initialized
INFO - 2020-09-10 03:05:40 --> Language Class Initialized
INFO - 2020-09-10 03:05:40 --> Language Class Initialized
INFO - 2020-09-10 03:05:40 --> Config Class Initialized
INFO - 2020-09-10 03:05:40 --> Loader Class Initialized
INFO - 2020-09-10 03:05:40 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:40 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:40 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:40 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:40 --> Upload Class Initialized
INFO - 2020-09-10 03:05:40 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-10 03:05:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:40 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:40 --> Total execution time: 0.0369
INFO - 2020-09-10 03:05:41 --> Config Class Initialized
INFO - 2020-09-10 03:05:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:05:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:05:41 --> Utf8 Class Initialized
INFO - 2020-09-10 03:05:41 --> URI Class Initialized
INFO - 2020-09-10 03:05:41 --> Router Class Initialized
INFO - 2020-09-10 03:05:41 --> Output Class Initialized
INFO - 2020-09-10 03:05:41 --> Security Class Initialized
DEBUG - 2020-09-10 03:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:05:41 --> Input Class Initialized
INFO - 2020-09-10 03:05:41 --> Language Class Initialized
INFO - 2020-09-10 03:05:41 --> Language Class Initialized
INFO - 2020-09-10 03:05:41 --> Config Class Initialized
INFO - 2020-09-10 03:05:41 --> Loader Class Initialized
INFO - 2020-09-10 03:05:41 --> Helper loaded: url_helper
INFO - 2020-09-10 03:05:41 --> Helper loaded: form_helper
INFO - 2020-09-10 03:05:41 --> Helper loaded: file_helper
INFO - 2020-09-10 03:05:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:05:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:05:41 --> Upload Class Initialized
INFO - 2020-09-10 03:05:41 --> Controller Class Initialized
DEBUG - 2020-09-10 03:05:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 03:05:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-10 03:05:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 03:05:41 --> Final output sent to browser
DEBUG - 2020-09-10 03:05:41 --> Total execution time: 0.0502
INFO - 2020-09-10 03:51:56 --> Config Class Initialized
INFO - 2020-09-10 03:51:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 03:51:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 03:51:56 --> Utf8 Class Initialized
INFO - 2020-09-10 03:51:56 --> URI Class Initialized
INFO - 2020-09-10 03:51:56 --> Router Class Initialized
INFO - 2020-09-10 03:51:56 --> Output Class Initialized
INFO - 2020-09-10 03:51:56 --> Security Class Initialized
DEBUG - 2020-09-10 03:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 03:51:56 --> Input Class Initialized
INFO - 2020-09-10 03:51:56 --> Language Class Initialized
INFO - 2020-09-10 03:51:56 --> Language Class Initialized
INFO - 2020-09-10 03:51:56 --> Config Class Initialized
INFO - 2020-09-10 03:51:56 --> Loader Class Initialized
INFO - 2020-09-10 03:51:56 --> Helper loaded: url_helper
INFO - 2020-09-10 03:51:56 --> Helper loaded: form_helper
INFO - 2020-09-10 03:51:56 --> Helper loaded: file_helper
INFO - 2020-09-10 03:51:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 03:51:56 --> Database Driver Class Initialized
DEBUG - 2020-09-10 03:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 03:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 03:51:56 --> Upload Class Initialized
INFO - 2020-09-10 03:51:56 --> Controller Class Initialized
ERROR - 2020-09-10 03:51:56 --> 404 Page Not Found: /index
INFO - 2020-09-10 05:42:00 --> Config Class Initialized
INFO - 2020-09-10 05:42:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 05:42:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 05:42:00 --> Utf8 Class Initialized
INFO - 2020-09-10 05:42:00 --> URI Class Initialized
INFO - 2020-09-10 05:42:00 --> Router Class Initialized
INFO - 2020-09-10 05:42:00 --> Output Class Initialized
INFO - 2020-09-10 05:42:00 --> Security Class Initialized
DEBUG - 2020-09-10 05:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 05:42:00 --> Input Class Initialized
INFO - 2020-09-10 05:42:00 --> Language Class Initialized
INFO - 2020-09-10 05:42:00 --> Language Class Initialized
INFO - 2020-09-10 05:42:00 --> Config Class Initialized
INFO - 2020-09-10 05:42:00 --> Loader Class Initialized
INFO - 2020-09-10 05:42:00 --> Helper loaded: url_helper
INFO - 2020-09-10 05:42:00 --> Helper loaded: form_helper
INFO - 2020-09-10 05:42:00 --> Helper loaded: file_helper
INFO - 2020-09-10 05:42:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 05:42:00 --> Database Driver Class Initialized
DEBUG - 2020-09-10 05:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 05:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 05:42:00 --> Upload Class Initialized
INFO - 2020-09-10 05:42:00 --> Controller Class Initialized
ERROR - 2020-09-10 05:42:00 --> 404 Page Not Found: /index
INFO - 2020-09-10 06:04:40 --> Config Class Initialized
INFO - 2020-09-10 06:04:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 06:04:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 06:04:40 --> Utf8 Class Initialized
INFO - 2020-09-10 06:04:40 --> URI Class Initialized
DEBUG - 2020-09-10 06:04:40 --> No URI present. Default controller set.
INFO - 2020-09-10 06:04:40 --> Router Class Initialized
INFO - 2020-09-10 06:04:40 --> Output Class Initialized
INFO - 2020-09-10 06:04:40 --> Security Class Initialized
DEBUG - 2020-09-10 06:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 06:04:40 --> Input Class Initialized
INFO - 2020-09-10 06:04:40 --> Language Class Initialized
INFO - 2020-09-10 06:04:40 --> Language Class Initialized
INFO - 2020-09-10 06:04:40 --> Config Class Initialized
INFO - 2020-09-10 06:04:40 --> Loader Class Initialized
INFO - 2020-09-10 06:04:40 --> Helper loaded: url_helper
INFO - 2020-09-10 06:04:40 --> Helper loaded: form_helper
INFO - 2020-09-10 06:04:40 --> Helper loaded: file_helper
INFO - 2020-09-10 06:04:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 06:04:40 --> Database Driver Class Initialized
DEBUG - 2020-09-10 06:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 06:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 06:04:40 --> Upload Class Initialized
INFO - 2020-09-10 06:04:40 --> Controller Class Initialized
DEBUG - 2020-09-10 06:04:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 06:04:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 06:04:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 06:04:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 06:04:40 --> Final output sent to browser
DEBUG - 2020-09-10 06:04:40 --> Total execution time: 0.0514
INFO - 2020-09-10 07:25:39 --> Config Class Initialized
INFO - 2020-09-10 07:25:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 07:25:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 07:25:39 --> Utf8 Class Initialized
INFO - 2020-09-10 07:25:39 --> URI Class Initialized
DEBUG - 2020-09-10 07:25:39 --> No URI present. Default controller set.
INFO - 2020-09-10 07:25:39 --> Router Class Initialized
INFO - 2020-09-10 07:25:39 --> Output Class Initialized
INFO - 2020-09-10 07:25:39 --> Security Class Initialized
DEBUG - 2020-09-10 07:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 07:25:39 --> Input Class Initialized
INFO - 2020-09-10 07:25:39 --> Language Class Initialized
INFO - 2020-09-10 07:25:39 --> Language Class Initialized
INFO - 2020-09-10 07:25:39 --> Config Class Initialized
INFO - 2020-09-10 07:25:39 --> Loader Class Initialized
INFO - 2020-09-10 07:25:39 --> Helper loaded: url_helper
INFO - 2020-09-10 07:25:39 --> Helper loaded: form_helper
INFO - 2020-09-10 07:25:39 --> Helper loaded: file_helper
INFO - 2020-09-10 07:25:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 07:25:39 --> Database Driver Class Initialized
DEBUG - 2020-09-10 07:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 07:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 07:25:39 --> Upload Class Initialized
INFO - 2020-09-10 07:25:39 --> Controller Class Initialized
DEBUG - 2020-09-10 07:25:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 07:25:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 07:25:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 07:25:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 07:25:39 --> Final output sent to browser
DEBUG - 2020-09-10 07:25:39 --> Total execution time: 0.0499
INFO - 2020-09-10 07:30:10 --> Config Class Initialized
INFO - 2020-09-10 07:30:10 --> Hooks Class Initialized
DEBUG - 2020-09-10 07:30:10 --> UTF-8 Support Enabled
INFO - 2020-09-10 07:30:10 --> Utf8 Class Initialized
INFO - 2020-09-10 07:30:10 --> URI Class Initialized
DEBUG - 2020-09-10 07:30:10 --> No URI present. Default controller set.
INFO - 2020-09-10 07:30:10 --> Router Class Initialized
INFO - 2020-09-10 07:30:10 --> Output Class Initialized
INFO - 2020-09-10 07:30:10 --> Security Class Initialized
DEBUG - 2020-09-10 07:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 07:30:10 --> Input Class Initialized
INFO - 2020-09-10 07:30:10 --> Language Class Initialized
INFO - 2020-09-10 07:30:10 --> Language Class Initialized
INFO - 2020-09-10 07:30:10 --> Config Class Initialized
INFO - 2020-09-10 07:30:10 --> Loader Class Initialized
INFO - 2020-09-10 07:30:10 --> Helper loaded: url_helper
INFO - 2020-09-10 07:30:10 --> Helper loaded: form_helper
INFO - 2020-09-10 07:30:10 --> Helper loaded: file_helper
INFO - 2020-09-10 07:30:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 07:30:10 --> Database Driver Class Initialized
DEBUG - 2020-09-10 07:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 07:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 07:30:10 --> Upload Class Initialized
INFO - 2020-09-10 07:30:10 --> Controller Class Initialized
DEBUG - 2020-09-10 07:30:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 07:30:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 07:30:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 07:30:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 07:30:10 --> Final output sent to browser
DEBUG - 2020-09-10 07:30:10 --> Total execution time: 0.0480
INFO - 2020-09-10 09:55:08 --> Config Class Initialized
INFO - 2020-09-10 09:55:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 09:55:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:55:08 --> Utf8 Class Initialized
INFO - 2020-09-10 09:55:08 --> URI Class Initialized
INFO - 2020-09-10 09:55:08 --> Router Class Initialized
INFO - 2020-09-10 09:55:08 --> Output Class Initialized
INFO - 2020-09-10 09:55:08 --> Security Class Initialized
DEBUG - 2020-09-10 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:55:08 --> Input Class Initialized
INFO - 2020-09-10 09:55:08 --> Language Class Initialized
INFO - 2020-09-10 09:55:08 --> Language Class Initialized
INFO - 2020-09-10 09:55:08 --> Config Class Initialized
INFO - 2020-09-10 09:55:08 --> Loader Class Initialized
INFO - 2020-09-10 09:55:08 --> Helper loaded: url_helper
INFO - 2020-09-10 09:55:08 --> Helper loaded: form_helper
INFO - 2020-09-10 09:55:08 --> Helper loaded: file_helper
INFO - 2020-09-10 09:55:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 09:55:08 --> Database Driver Class Initialized
DEBUG - 2020-09-10 09:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:55:08 --> Upload Class Initialized
INFO - 2020-09-10 09:55:08 --> Controller Class Initialized
ERROR - 2020-09-10 09:55:08 --> 404 Page Not Found: /index
INFO - 2020-09-10 10:34:37 --> Config Class Initialized
INFO - 2020-09-10 10:34:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:34:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:34:37 --> Utf8 Class Initialized
INFO - 2020-09-10 10:34:37 --> URI Class Initialized
DEBUG - 2020-09-10 10:34:37 --> No URI present. Default controller set.
INFO - 2020-09-10 10:34:37 --> Router Class Initialized
INFO - 2020-09-10 10:34:37 --> Output Class Initialized
INFO - 2020-09-10 10:34:37 --> Security Class Initialized
DEBUG - 2020-09-10 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:34:37 --> Input Class Initialized
INFO - 2020-09-10 10:34:37 --> Language Class Initialized
INFO - 2020-09-10 10:34:37 --> Language Class Initialized
INFO - 2020-09-10 10:34:37 --> Config Class Initialized
INFO - 2020-09-10 10:34:37 --> Loader Class Initialized
INFO - 2020-09-10 10:34:37 --> Helper loaded: url_helper
INFO - 2020-09-10 10:34:37 --> Helper loaded: form_helper
INFO - 2020-09-10 10:34:37 --> Helper loaded: file_helper
INFO - 2020-09-10 10:34:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 10:34:37 --> Database Driver Class Initialized
DEBUG - 2020-09-10 10:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:34:37 --> Upload Class Initialized
INFO - 2020-09-10 10:34:37 --> Controller Class Initialized
DEBUG - 2020-09-10 10:34:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 10:34:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 10:34:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 10:34:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 10:34:37 --> Final output sent to browser
DEBUG - 2020-09-10 10:34:37 --> Total execution time: 0.0476
INFO - 2020-09-10 10:34:42 --> Config Class Initialized
INFO - 2020-09-10 10:34:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:34:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:34:42 --> Utf8 Class Initialized
INFO - 2020-09-10 10:34:42 --> URI Class Initialized
INFO - 2020-09-10 10:34:42 --> Router Class Initialized
INFO - 2020-09-10 10:34:42 --> Output Class Initialized
INFO - 2020-09-10 10:34:42 --> Security Class Initialized
DEBUG - 2020-09-10 10:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:34:42 --> Input Class Initialized
INFO - 2020-09-10 10:34:42 --> Language Class Initialized
INFO - 2020-09-10 10:34:42 --> Language Class Initialized
INFO - 2020-09-10 10:34:42 --> Config Class Initialized
INFO - 2020-09-10 10:34:42 --> Loader Class Initialized
INFO - 2020-09-10 10:34:42 --> Helper loaded: url_helper
INFO - 2020-09-10 10:34:42 --> Helper loaded: form_helper
INFO - 2020-09-10 10:34:42 --> Helper loaded: file_helper
INFO - 2020-09-10 10:34:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 10:34:42 --> Database Driver Class Initialized
DEBUG - 2020-09-10 10:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 10:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:34:42 --> Upload Class Initialized
INFO - 2020-09-10 10:34:42 --> Controller Class Initialized
ERROR - 2020-09-10 10:34:42 --> 404 Page Not Found: /index
INFO - 2020-09-10 10:34:44 --> Config Class Initialized
INFO - 2020-09-10 10:34:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:34:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:34:44 --> Utf8 Class Initialized
INFO - 2020-09-10 10:34:44 --> URI Class Initialized
INFO - 2020-09-10 10:34:44 --> Router Class Initialized
INFO - 2020-09-10 10:34:44 --> Output Class Initialized
INFO - 2020-09-10 10:34:44 --> Security Class Initialized
DEBUG - 2020-09-10 10:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:34:44 --> Input Class Initialized
INFO - 2020-09-10 10:34:44 --> Language Class Initialized
INFO - 2020-09-10 10:34:44 --> Language Class Initialized
INFO - 2020-09-10 10:34:44 --> Config Class Initialized
INFO - 2020-09-10 10:34:44 --> Loader Class Initialized
INFO - 2020-09-10 10:34:44 --> Helper loaded: url_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: form_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: file_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 10:34:44 --> Database Driver Class Initialized
DEBUG - 2020-09-10 10:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 10:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:34:44 --> Upload Class Initialized
INFO - 2020-09-10 10:34:44 --> Controller Class Initialized
ERROR - 2020-09-10 10:34:44 --> 404 Page Not Found: /index
INFO - 2020-09-10 10:34:44 --> Config Class Initialized
INFO - 2020-09-10 10:34:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:34:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:34:44 --> Utf8 Class Initialized
INFO - 2020-09-10 10:34:44 --> URI Class Initialized
INFO - 2020-09-10 10:34:44 --> Router Class Initialized
INFO - 2020-09-10 10:34:44 --> Output Class Initialized
INFO - 2020-09-10 10:34:44 --> Security Class Initialized
DEBUG - 2020-09-10 10:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:34:44 --> Input Class Initialized
INFO - 2020-09-10 10:34:44 --> Language Class Initialized
INFO - 2020-09-10 10:34:44 --> Language Class Initialized
INFO - 2020-09-10 10:34:44 --> Config Class Initialized
INFO - 2020-09-10 10:34:44 --> Loader Class Initialized
INFO - 2020-09-10 10:34:44 --> Helper loaded: url_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: form_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: file_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 10:34:44 --> Database Driver Class Initialized
DEBUG - 2020-09-10 10:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 10:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:34:44 --> Upload Class Initialized
INFO - 2020-09-10 10:34:44 --> Config Class Initialized
INFO - 2020-09-10 10:34:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:34:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:34:44 --> Utf8 Class Initialized
INFO - 2020-09-10 10:34:44 --> URI Class Initialized
INFO - 2020-09-10 10:34:44 --> Controller Class Initialized
ERROR - 2020-09-10 10:34:44 --> 404 Page Not Found: /index
INFO - 2020-09-10 10:34:44 --> Router Class Initialized
INFO - 2020-09-10 10:34:44 --> Output Class Initialized
INFO - 2020-09-10 10:34:44 --> Security Class Initialized
DEBUG - 2020-09-10 10:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:34:44 --> Input Class Initialized
INFO - 2020-09-10 10:34:44 --> Language Class Initialized
INFO - 2020-09-10 10:34:44 --> Language Class Initialized
INFO - 2020-09-10 10:34:44 --> Config Class Initialized
INFO - 2020-09-10 10:34:44 --> Loader Class Initialized
INFO - 2020-09-10 10:34:44 --> Helper loaded: url_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: form_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: file_helper
INFO - 2020-09-10 10:34:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 10:34:44 --> Database Driver Class Initialized
DEBUG - 2020-09-10 10:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 10:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:34:44 --> Upload Class Initialized
INFO - 2020-09-10 10:34:44 --> Controller Class Initialized
ERROR - 2020-09-10 10:34:44 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:05:46 --> Config Class Initialized
INFO - 2020-09-10 11:05:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:05:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:05:46 --> Utf8 Class Initialized
INFO - 2020-09-10 11:05:46 --> URI Class Initialized
DEBUG - 2020-09-10 11:05:46 --> No URI present. Default controller set.
INFO - 2020-09-10 11:05:46 --> Router Class Initialized
INFO - 2020-09-10 11:05:46 --> Output Class Initialized
INFO - 2020-09-10 11:05:46 --> Security Class Initialized
DEBUG - 2020-09-10 11:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:05:46 --> Input Class Initialized
INFO - 2020-09-10 11:05:46 --> Language Class Initialized
INFO - 2020-09-10 11:05:46 --> Language Class Initialized
INFO - 2020-09-10 11:05:46 --> Config Class Initialized
INFO - 2020-09-10 11:05:46 --> Loader Class Initialized
INFO - 2020-09-10 11:05:46 --> Helper loaded: url_helper
INFO - 2020-09-10 11:05:46 --> Helper loaded: form_helper
INFO - 2020-09-10 11:05:46 --> Helper loaded: file_helper
INFO - 2020-09-10 11:05:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:05:46 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:05:46 --> Upload Class Initialized
INFO - 2020-09-10 11:05:46 --> Controller Class Initialized
DEBUG - 2020-09-10 11:05:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 11:05:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 11:05:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 11:05:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 11:05:46 --> Final output sent to browser
DEBUG - 2020-09-10 11:05:46 --> Total execution time: 0.0461
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:05:47 --> Utf8 Class Initialized
INFO - 2020-09-10 11:05:47 --> URI Class Initialized
INFO - 2020-09-10 11:05:47 --> Router Class Initialized
INFO - 2020-09-10 11:05:47 --> Output Class Initialized
INFO - 2020-09-10 11:05:47 --> Security Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:05:47 --> Input Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Loader Class Initialized
INFO - 2020-09-10 11:05:47 --> Helper loaded: url_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: form_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: file_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Hooks Class Initialized
INFO - 2020-09-10 11:05:47 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:05:47 --> Utf8 Class Initialized
INFO - 2020-09-10 11:05:47 --> URI Class Initialized
INFO - 2020-09-10 11:05:47 --> Router Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:05:47 --> Output Class Initialized
INFO - 2020-09-10 11:05:47 --> Security Class Initialized
INFO - 2020-09-10 11:05:47 --> Upload Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:05:47 --> Input Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Loader Class Initialized
INFO - 2020-09-10 11:05:47 --> Helper loaded: url_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: form_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: file_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:05:47 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:05:47 --> Controller Class Initialized
ERROR - 2020-09-10 11:05:47 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:05:47 --> Upload Class Initialized
INFO - 2020-09-10 11:05:47 --> Controller Class Initialized
ERROR - 2020-09-10 11:05:47 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:05:47 --> Utf8 Class Initialized
INFO - 2020-09-10 11:05:47 --> URI Class Initialized
INFO - 2020-09-10 11:05:47 --> Router Class Initialized
INFO - 2020-09-10 11:05:47 --> Output Class Initialized
INFO - 2020-09-10 11:05:47 --> Security Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:05:47 --> Input Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Loader Class Initialized
INFO - 2020-09-10 11:05:47 --> Helper loaded: url_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: form_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: file_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:05:47 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:05:47 --> Upload Class Initialized
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:05:47 --> Utf8 Class Initialized
INFO - 2020-09-10 11:05:47 --> URI Class Initialized
INFO - 2020-09-10 11:05:47 --> Router Class Initialized
INFO - 2020-09-10 11:05:47 --> Output Class Initialized
INFO - 2020-09-10 11:05:47 --> Security Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:05:47 --> Input Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Language Class Initialized
INFO - 2020-09-10 11:05:47 --> Config Class Initialized
INFO - 2020-09-10 11:05:47 --> Loader Class Initialized
INFO - 2020-09-10 11:05:47 --> Controller Class Initialized
INFO - 2020-09-10 11:05:47 --> Helper loaded: url_helper
ERROR - 2020-09-10 11:05:47 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:05:47 --> Helper loaded: form_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: file_helper
INFO - 2020-09-10 11:05:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:05:47 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:05:47 --> Upload Class Initialized
INFO - 2020-09-10 11:05:47 --> Controller Class Initialized
ERROR - 2020-09-10 11:05:47 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:05:50 --> Config Class Initialized
INFO - 2020-09-10 11:05:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:05:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:05:50 --> Utf8 Class Initialized
INFO - 2020-09-10 11:05:50 --> URI Class Initialized
INFO - 2020-09-10 11:05:50 --> Router Class Initialized
INFO - 2020-09-10 11:05:50 --> Output Class Initialized
INFO - 2020-09-10 11:05:50 --> Security Class Initialized
DEBUG - 2020-09-10 11:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:05:50 --> Input Class Initialized
INFO - 2020-09-10 11:05:50 --> Language Class Initialized
INFO - 2020-09-10 11:05:50 --> Language Class Initialized
INFO - 2020-09-10 11:05:50 --> Config Class Initialized
INFO - 2020-09-10 11:05:50 --> Loader Class Initialized
INFO - 2020-09-10 11:05:50 --> Helper loaded: url_helper
INFO - 2020-09-10 11:05:50 --> Helper loaded: form_helper
INFO - 2020-09-10 11:05:50 --> Helper loaded: file_helper
INFO - 2020-09-10 11:05:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:05:50 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:05:50 --> Upload Class Initialized
INFO - 2020-09-10 11:05:50 --> Controller Class Initialized
ERROR - 2020-09-10 11:05:50 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:12:31 --> Config Class Initialized
INFO - 2020-09-10 11:12:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:12:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:12:31 --> Utf8 Class Initialized
INFO - 2020-09-10 11:12:31 --> URI Class Initialized
DEBUG - 2020-09-10 11:12:31 --> No URI present. Default controller set.
INFO - 2020-09-10 11:12:31 --> Router Class Initialized
INFO - 2020-09-10 11:12:31 --> Output Class Initialized
INFO - 2020-09-10 11:12:31 --> Security Class Initialized
DEBUG - 2020-09-10 11:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:12:31 --> Input Class Initialized
INFO - 2020-09-10 11:12:31 --> Language Class Initialized
INFO - 2020-09-10 11:12:31 --> Language Class Initialized
INFO - 2020-09-10 11:12:31 --> Config Class Initialized
INFO - 2020-09-10 11:12:31 --> Loader Class Initialized
INFO - 2020-09-10 11:12:31 --> Helper loaded: url_helper
INFO - 2020-09-10 11:12:31 --> Helper loaded: form_helper
INFO - 2020-09-10 11:12:31 --> Helper loaded: file_helper
INFO - 2020-09-10 11:12:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:12:31 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:12:31 --> Upload Class Initialized
INFO - 2020-09-10 11:12:31 --> Controller Class Initialized
DEBUG - 2020-09-10 11:12:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 11:12:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 11:12:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 11:12:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 11:12:31 --> Final output sent to browser
DEBUG - 2020-09-10 11:12:31 --> Total execution time: 0.0766
INFO - 2020-09-10 11:41:40 --> Config Class Initialized
INFO - 2020-09-10 11:41:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:41:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:41:40 --> Utf8 Class Initialized
INFO - 2020-09-10 11:41:40 --> URI Class Initialized
INFO - 2020-09-10 11:41:40 --> Router Class Initialized
INFO - 2020-09-10 11:41:40 --> Output Class Initialized
INFO - 2020-09-10 11:41:40 --> Security Class Initialized
DEBUG - 2020-09-10 11:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:41:40 --> Input Class Initialized
INFO - 2020-09-10 11:41:40 --> Language Class Initialized
INFO - 2020-09-10 11:41:40 --> Language Class Initialized
INFO - 2020-09-10 11:41:40 --> Config Class Initialized
INFO - 2020-09-10 11:41:40 --> Loader Class Initialized
INFO - 2020-09-10 11:41:40 --> Helper loaded: url_helper
INFO - 2020-09-10 11:41:40 --> Helper loaded: form_helper
INFO - 2020-09-10 11:41:40 --> Helper loaded: file_helper
INFO - 2020-09-10 11:41:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:41:40 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:41:40 --> Upload Class Initialized
INFO - 2020-09-10 11:41:40 --> Controller Class Initialized
ERROR - 2020-09-10 11:41:40 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:41:44 --> Config Class Initialized
INFO - 2020-09-10 11:41:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:41:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:41:44 --> Utf8 Class Initialized
INFO - 2020-09-10 11:41:44 --> URI Class Initialized
INFO - 2020-09-10 11:41:44 --> Router Class Initialized
INFO - 2020-09-10 11:41:44 --> Output Class Initialized
INFO - 2020-09-10 11:41:44 --> Security Class Initialized
DEBUG - 2020-09-10 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:41:44 --> Input Class Initialized
INFO - 2020-09-10 11:41:44 --> Language Class Initialized
INFO - 2020-09-10 11:41:44 --> Language Class Initialized
INFO - 2020-09-10 11:41:44 --> Config Class Initialized
INFO - 2020-09-10 11:41:44 --> Loader Class Initialized
INFO - 2020-09-10 11:41:44 --> Helper loaded: url_helper
INFO - 2020-09-10 11:41:44 --> Helper loaded: form_helper
INFO - 2020-09-10 11:41:44 --> Helper loaded: file_helper
INFO - 2020-09-10 11:41:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:41:44 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:41:44 --> Upload Class Initialized
INFO - 2020-09-10 11:41:44 --> Controller Class Initialized
ERROR - 2020-09-10 11:41:44 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:41:48 --> Config Class Initialized
INFO - 2020-09-10 11:41:48 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:41:48 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:41:48 --> Utf8 Class Initialized
INFO - 2020-09-10 11:41:48 --> URI Class Initialized
DEBUG - 2020-09-10 11:41:48 --> No URI present. Default controller set.
INFO - 2020-09-10 11:41:48 --> Router Class Initialized
INFO - 2020-09-10 11:41:48 --> Output Class Initialized
INFO - 2020-09-10 11:41:48 --> Security Class Initialized
DEBUG - 2020-09-10 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:41:48 --> Input Class Initialized
INFO - 2020-09-10 11:41:48 --> Language Class Initialized
INFO - 2020-09-10 11:41:48 --> Language Class Initialized
INFO - 2020-09-10 11:41:48 --> Config Class Initialized
INFO - 2020-09-10 11:41:48 --> Loader Class Initialized
INFO - 2020-09-10 11:41:48 --> Helper loaded: url_helper
INFO - 2020-09-10 11:41:48 --> Helper loaded: form_helper
INFO - 2020-09-10 11:41:48 --> Helper loaded: file_helper
INFO - 2020-09-10 11:41:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:41:48 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:41:48 --> Upload Class Initialized
INFO - 2020-09-10 11:41:48 --> Controller Class Initialized
DEBUG - 2020-09-10 11:41:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 11:41:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 11:41:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 11:41:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 11:41:48 --> Final output sent to browser
DEBUG - 2020-09-10 11:41:48 --> Total execution time: 0.0531
INFO - 2020-09-10 11:48:56 --> Config Class Initialized
INFO - 2020-09-10 11:48:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:48:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:48:56 --> Utf8 Class Initialized
INFO - 2020-09-10 11:48:56 --> URI Class Initialized
INFO - 2020-09-10 11:48:56 --> Router Class Initialized
INFO - 2020-09-10 11:48:56 --> Output Class Initialized
INFO - 2020-09-10 11:48:56 --> Security Class Initialized
DEBUG - 2020-09-10 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:48:56 --> Input Class Initialized
INFO - 2020-09-10 11:48:56 --> Language Class Initialized
INFO - 2020-09-10 11:48:56 --> Language Class Initialized
INFO - 2020-09-10 11:48:56 --> Config Class Initialized
INFO - 2020-09-10 11:48:56 --> Loader Class Initialized
INFO - 2020-09-10 11:48:56 --> Helper loaded: url_helper
INFO - 2020-09-10 11:48:56 --> Helper loaded: form_helper
INFO - 2020-09-10 11:48:56 --> Helper loaded: file_helper
INFO - 2020-09-10 11:48:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:48:56 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:48:56 --> Upload Class Initialized
INFO - 2020-09-10 11:48:56 --> Controller Class Initialized
ERROR - 2020-09-10 11:48:56 --> 404 Page Not Found: /index
INFO - 2020-09-10 11:59:56 --> Config Class Initialized
INFO - 2020-09-10 11:59:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 11:59:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 11:59:56 --> Utf8 Class Initialized
INFO - 2020-09-10 11:59:56 --> URI Class Initialized
DEBUG - 2020-09-10 11:59:56 --> No URI present. Default controller set.
INFO - 2020-09-10 11:59:56 --> Router Class Initialized
INFO - 2020-09-10 11:59:56 --> Output Class Initialized
INFO - 2020-09-10 11:59:56 --> Security Class Initialized
DEBUG - 2020-09-10 11:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 11:59:56 --> Input Class Initialized
INFO - 2020-09-10 11:59:56 --> Language Class Initialized
INFO - 2020-09-10 11:59:56 --> Language Class Initialized
INFO - 2020-09-10 11:59:56 --> Config Class Initialized
INFO - 2020-09-10 11:59:56 --> Loader Class Initialized
INFO - 2020-09-10 11:59:56 --> Helper loaded: url_helper
INFO - 2020-09-10 11:59:56 --> Helper loaded: form_helper
INFO - 2020-09-10 11:59:56 --> Helper loaded: file_helper
INFO - 2020-09-10 11:59:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 11:59:56 --> Database Driver Class Initialized
DEBUG - 2020-09-10 11:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 11:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 11:59:56 --> Upload Class Initialized
INFO - 2020-09-10 11:59:57 --> Controller Class Initialized
DEBUG - 2020-09-10 11:59:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 11:59:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 11:59:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 11:59:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 11:59:57 --> Final output sent to browser
DEBUG - 2020-09-10 11:59:57 --> Total execution time: 0.0550
INFO - 2020-09-10 13:03:18 --> Config Class Initialized
INFO - 2020-09-10 13:03:18 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:03:18 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:03:18 --> Utf8 Class Initialized
INFO - 2020-09-10 13:03:18 --> URI Class Initialized
DEBUG - 2020-09-10 13:03:18 --> No URI present. Default controller set.
INFO - 2020-09-10 13:03:18 --> Router Class Initialized
INFO - 2020-09-10 13:03:18 --> Output Class Initialized
INFO - 2020-09-10 13:03:18 --> Security Class Initialized
DEBUG - 2020-09-10 13:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:03:18 --> Input Class Initialized
INFO - 2020-09-10 13:03:18 --> Language Class Initialized
INFO - 2020-09-10 13:03:18 --> Language Class Initialized
INFO - 2020-09-10 13:03:18 --> Config Class Initialized
INFO - 2020-09-10 13:03:18 --> Loader Class Initialized
INFO - 2020-09-10 13:03:18 --> Helper loaded: url_helper
INFO - 2020-09-10 13:03:18 --> Helper loaded: form_helper
INFO - 2020-09-10 13:03:18 --> Helper loaded: file_helper
INFO - 2020-09-10 13:03:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 13:03:18 --> Database Driver Class Initialized
DEBUG - 2020-09-10 13:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 13:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 13:03:18 --> Upload Class Initialized
INFO - 2020-09-10 13:03:19 --> Controller Class Initialized
DEBUG - 2020-09-10 13:03:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 13:03:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 13:03:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 13:03:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 13:03:19 --> Final output sent to browser
DEBUG - 2020-09-10 13:03:19 --> Total execution time: 0.0479
INFO - 2020-09-10 13:24:48 --> Config Class Initialized
INFO - 2020-09-10 13:24:48 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:24:48 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:24:48 --> Utf8 Class Initialized
INFO - 2020-09-10 13:24:48 --> URI Class Initialized
DEBUG - 2020-09-10 13:24:48 --> No URI present. Default controller set.
INFO - 2020-09-10 13:24:48 --> Router Class Initialized
INFO - 2020-09-10 13:24:48 --> Output Class Initialized
INFO - 2020-09-10 13:24:48 --> Security Class Initialized
DEBUG - 2020-09-10 13:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:24:48 --> Input Class Initialized
INFO - 2020-09-10 13:24:48 --> Language Class Initialized
INFO - 2020-09-10 13:24:48 --> Language Class Initialized
INFO - 2020-09-10 13:24:48 --> Config Class Initialized
INFO - 2020-09-10 13:24:48 --> Loader Class Initialized
INFO - 2020-09-10 13:24:48 --> Helper loaded: url_helper
INFO - 2020-09-10 13:24:48 --> Helper loaded: form_helper
INFO - 2020-09-10 13:24:48 --> Helper loaded: file_helper
INFO - 2020-09-10 13:24:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 13:24:48 --> Database Driver Class Initialized
DEBUG - 2020-09-10 13:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 13:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 13:24:48 --> Upload Class Initialized
INFO - 2020-09-10 13:24:48 --> Controller Class Initialized
DEBUG - 2020-09-10 13:24:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 13:24:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 13:24:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 13:24:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 13:24:48 --> Final output sent to browser
DEBUG - 2020-09-10 13:24:48 --> Total execution time: 0.0648
INFO - 2020-09-10 13:29:53 --> Config Class Initialized
INFO - 2020-09-10 13:29:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:29:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:29:53 --> Utf8 Class Initialized
INFO - 2020-09-10 13:29:53 --> URI Class Initialized
DEBUG - 2020-09-10 13:29:53 --> No URI present. Default controller set.
INFO - 2020-09-10 13:29:53 --> Router Class Initialized
INFO - 2020-09-10 13:29:53 --> Output Class Initialized
INFO - 2020-09-10 13:29:53 --> Security Class Initialized
DEBUG - 2020-09-10 13:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:29:53 --> Input Class Initialized
INFO - 2020-09-10 13:29:53 --> Language Class Initialized
INFO - 2020-09-10 13:29:53 --> Language Class Initialized
INFO - 2020-09-10 13:29:53 --> Config Class Initialized
INFO - 2020-09-10 13:29:53 --> Loader Class Initialized
INFO - 2020-09-10 13:29:53 --> Helper loaded: url_helper
INFO - 2020-09-10 13:29:53 --> Helper loaded: form_helper
INFO - 2020-09-10 13:29:53 --> Helper loaded: file_helper
INFO - 2020-09-10 13:29:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 13:29:53 --> Database Driver Class Initialized
DEBUG - 2020-09-10 13:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 13:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 13:29:53 --> Upload Class Initialized
INFO - 2020-09-10 13:29:53 --> Controller Class Initialized
DEBUG - 2020-09-10 13:29:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 13:29:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 13:29:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 13:29:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 13:29:53 --> Final output sent to browser
DEBUG - 2020-09-10 13:29:53 --> Total execution time: 0.0437
INFO - 2020-09-10 13:36:56 --> Config Class Initialized
INFO - 2020-09-10 13:36:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:36:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:36:56 --> Utf8 Class Initialized
INFO - 2020-09-10 13:36:56 --> URI Class Initialized
DEBUG - 2020-09-10 13:36:56 --> No URI present. Default controller set.
INFO - 2020-09-10 13:36:56 --> Router Class Initialized
INFO - 2020-09-10 13:36:56 --> Output Class Initialized
INFO - 2020-09-10 13:36:56 --> Security Class Initialized
DEBUG - 2020-09-10 13:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:36:56 --> Input Class Initialized
INFO - 2020-09-10 13:36:56 --> Language Class Initialized
INFO - 2020-09-10 13:36:56 --> Language Class Initialized
INFO - 2020-09-10 13:36:56 --> Config Class Initialized
INFO - 2020-09-10 13:36:56 --> Loader Class Initialized
INFO - 2020-09-10 13:36:56 --> Helper loaded: url_helper
INFO - 2020-09-10 13:36:56 --> Helper loaded: form_helper
INFO - 2020-09-10 13:36:56 --> Helper loaded: file_helper
INFO - 2020-09-10 13:36:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 13:36:56 --> Database Driver Class Initialized
DEBUG - 2020-09-10 13:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 13:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 13:36:56 --> Upload Class Initialized
INFO - 2020-09-10 13:36:56 --> Controller Class Initialized
DEBUG - 2020-09-10 13:36:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 13:36:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 13:36:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 13:36:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 13:36:56 --> Final output sent to browser
DEBUG - 2020-09-10 13:36:56 --> Total execution time: 0.0430
INFO - 2020-09-10 13:50:24 --> Config Class Initialized
INFO - 2020-09-10 13:50:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:50:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:50:24 --> Utf8 Class Initialized
INFO - 2020-09-10 13:50:24 --> URI Class Initialized
DEBUG - 2020-09-10 13:50:24 --> No URI present. Default controller set.
INFO - 2020-09-10 13:50:24 --> Router Class Initialized
INFO - 2020-09-10 13:50:24 --> Output Class Initialized
INFO - 2020-09-10 13:50:24 --> Security Class Initialized
DEBUG - 2020-09-10 13:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:50:24 --> Input Class Initialized
INFO - 2020-09-10 13:50:24 --> Language Class Initialized
INFO - 2020-09-10 13:50:24 --> Language Class Initialized
INFO - 2020-09-10 13:50:24 --> Config Class Initialized
INFO - 2020-09-10 13:50:24 --> Loader Class Initialized
INFO - 2020-09-10 13:50:24 --> Helper loaded: url_helper
INFO - 2020-09-10 13:50:24 --> Helper loaded: form_helper
INFO - 2020-09-10 13:50:24 --> Helper loaded: file_helper
INFO - 2020-09-10 13:50:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 13:50:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 13:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 13:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 13:50:24 --> Upload Class Initialized
INFO - 2020-09-10 13:50:24 --> Controller Class Initialized
DEBUG - 2020-09-10 13:50:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 13:50:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 13:50:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 13:50:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 13:50:24 --> Final output sent to browser
DEBUG - 2020-09-10 13:50:24 --> Total execution time: 0.0587
INFO - 2020-09-10 13:54:18 --> Config Class Initialized
INFO - 2020-09-10 13:54:18 --> Hooks Class Initialized
DEBUG - 2020-09-10 13:54:18 --> UTF-8 Support Enabled
INFO - 2020-09-10 13:54:18 --> Utf8 Class Initialized
INFO - 2020-09-10 13:54:18 --> URI Class Initialized
DEBUG - 2020-09-10 13:54:18 --> No URI present. Default controller set.
INFO - 2020-09-10 13:54:18 --> Router Class Initialized
INFO - 2020-09-10 13:54:18 --> Output Class Initialized
INFO - 2020-09-10 13:54:18 --> Security Class Initialized
DEBUG - 2020-09-10 13:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 13:54:18 --> Input Class Initialized
INFO - 2020-09-10 13:54:18 --> Language Class Initialized
INFO - 2020-09-10 13:54:18 --> Language Class Initialized
INFO - 2020-09-10 13:54:18 --> Config Class Initialized
INFO - 2020-09-10 13:54:18 --> Loader Class Initialized
INFO - 2020-09-10 13:54:18 --> Helper loaded: url_helper
INFO - 2020-09-10 13:54:18 --> Helper loaded: form_helper
INFO - 2020-09-10 13:54:18 --> Helper loaded: file_helper
INFO - 2020-09-10 13:54:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 13:54:18 --> Database Driver Class Initialized
DEBUG - 2020-09-10 13:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 13:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 13:54:18 --> Upload Class Initialized
INFO - 2020-09-10 13:54:18 --> Controller Class Initialized
DEBUG - 2020-09-10 13:54:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 13:54:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 13:54:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 13:54:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 13:54:18 --> Final output sent to browser
DEBUG - 2020-09-10 13:54:18 --> Total execution time: 0.0770
INFO - 2020-09-10 15:27:34 --> Config Class Initialized
INFO - 2020-09-10 15:27:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:27:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:27:34 --> Utf8 Class Initialized
INFO - 2020-09-10 15:27:34 --> URI Class Initialized
INFO - 2020-09-10 15:27:34 --> Router Class Initialized
INFO - 2020-09-10 15:27:34 --> Output Class Initialized
INFO - 2020-09-10 15:27:34 --> Security Class Initialized
DEBUG - 2020-09-10 15:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:27:34 --> Input Class Initialized
INFO - 2020-09-10 15:27:34 --> Language Class Initialized
INFO - 2020-09-10 15:27:34 --> Language Class Initialized
INFO - 2020-09-10 15:27:34 --> Config Class Initialized
INFO - 2020-09-10 15:27:34 --> Loader Class Initialized
INFO - 2020-09-10 15:27:34 --> Helper loaded: url_helper
INFO - 2020-09-10 15:27:34 --> Helper loaded: form_helper
INFO - 2020-09-10 15:27:34 --> Helper loaded: file_helper
INFO - 2020-09-10 15:27:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 15:27:34 --> Database Driver Class Initialized
DEBUG - 2020-09-10 15:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 15:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:27:34 --> Upload Class Initialized
INFO - 2020-09-10 15:27:34 --> Controller Class Initialized
ERROR - 2020-09-10 15:27:34 --> 404 Page Not Found: /index
INFO - 2020-09-10 15:27:35 --> Config Class Initialized
INFO - 2020-09-10 15:27:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:27:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:27:35 --> Utf8 Class Initialized
INFO - 2020-09-10 15:27:35 --> URI Class Initialized
INFO - 2020-09-10 15:27:35 --> Router Class Initialized
INFO - 2020-09-10 15:27:35 --> Output Class Initialized
INFO - 2020-09-10 15:27:35 --> Security Class Initialized
DEBUG - 2020-09-10 15:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:27:35 --> Input Class Initialized
INFO - 2020-09-10 15:27:35 --> Language Class Initialized
INFO - 2020-09-10 15:27:35 --> Language Class Initialized
INFO - 2020-09-10 15:27:35 --> Config Class Initialized
INFO - 2020-09-10 15:27:35 --> Loader Class Initialized
INFO - 2020-09-10 15:27:35 --> Helper loaded: url_helper
INFO - 2020-09-10 15:27:35 --> Helper loaded: form_helper
INFO - 2020-09-10 15:27:35 --> Helper loaded: file_helper
INFO - 2020-09-10 15:27:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 15:27:35 --> Database Driver Class Initialized
DEBUG - 2020-09-10 15:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 15:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:27:35 --> Upload Class Initialized
INFO - 2020-09-10 15:27:35 --> Controller Class Initialized
ERROR - 2020-09-10 15:27:35 --> 404 Page Not Found: /index
INFO - 2020-09-10 15:30:28 --> Config Class Initialized
INFO - 2020-09-10 15:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:30:28 --> Utf8 Class Initialized
INFO - 2020-09-10 15:30:28 --> URI Class Initialized
INFO - 2020-09-10 15:30:28 --> Router Class Initialized
INFO - 2020-09-10 15:30:28 --> Output Class Initialized
INFO - 2020-09-10 15:30:28 --> Security Class Initialized
DEBUG - 2020-09-10 15:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:30:28 --> Input Class Initialized
INFO - 2020-09-10 15:30:28 --> Language Class Initialized
INFO - 2020-09-10 15:30:28 --> Language Class Initialized
INFO - 2020-09-10 15:30:28 --> Config Class Initialized
INFO - 2020-09-10 15:30:28 --> Loader Class Initialized
INFO - 2020-09-10 15:30:28 --> Helper loaded: url_helper
INFO - 2020-09-10 15:30:28 --> Helper loaded: form_helper
INFO - 2020-09-10 15:30:28 --> Helper loaded: file_helper
INFO - 2020-09-10 15:30:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 15:30:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 15:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 15:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:30:28 --> Upload Class Initialized
INFO - 2020-09-10 15:30:28 --> Controller Class Initialized
ERROR - 2020-09-10 15:30:28 --> 404 Page Not Found: /index
INFO - 2020-09-10 15:53:53 --> Config Class Initialized
INFO - 2020-09-10 15:53:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:53:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:53:53 --> Utf8 Class Initialized
INFO - 2020-09-10 15:53:53 --> URI Class Initialized
INFO - 2020-09-10 15:53:53 --> Router Class Initialized
INFO - 2020-09-10 15:53:53 --> Output Class Initialized
INFO - 2020-09-10 15:53:53 --> Security Class Initialized
DEBUG - 2020-09-10 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:53:53 --> Input Class Initialized
INFO - 2020-09-10 15:53:53 --> Language Class Initialized
INFO - 2020-09-10 15:53:53 --> Language Class Initialized
INFO - 2020-09-10 15:53:53 --> Config Class Initialized
INFO - 2020-09-10 15:53:53 --> Loader Class Initialized
INFO - 2020-09-10 15:53:53 --> Helper loaded: url_helper
INFO - 2020-09-10 15:53:53 --> Helper loaded: form_helper
INFO - 2020-09-10 15:53:53 --> Helper loaded: file_helper
INFO - 2020-09-10 15:53:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 15:53:53 --> Database Driver Class Initialized
DEBUG - 2020-09-10 15:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:53:53 --> Upload Class Initialized
INFO - 2020-09-10 15:53:53 --> Controller Class Initialized
ERROR - 2020-09-10 15:53:53 --> 404 Page Not Found: /index
INFO - 2020-09-10 15:53:53 --> Config Class Initialized
INFO - 2020-09-10 15:53:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:53:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:53:53 --> Utf8 Class Initialized
INFO - 2020-09-10 15:53:53 --> URI Class Initialized
DEBUG - 2020-09-10 15:53:53 --> No URI present. Default controller set.
INFO - 2020-09-10 15:53:53 --> Router Class Initialized
INFO - 2020-09-10 15:53:53 --> Output Class Initialized
INFO - 2020-09-10 15:53:53 --> Security Class Initialized
DEBUG - 2020-09-10 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:53:53 --> Input Class Initialized
INFO - 2020-09-10 15:53:53 --> Language Class Initialized
INFO - 2020-09-10 15:53:53 --> Language Class Initialized
INFO - 2020-09-10 15:53:53 --> Config Class Initialized
INFO - 2020-09-10 15:53:53 --> Loader Class Initialized
INFO - 2020-09-10 15:53:53 --> Helper loaded: url_helper
INFO - 2020-09-10 15:53:53 --> Helper loaded: form_helper
INFO - 2020-09-10 15:53:53 --> Helper loaded: file_helper
INFO - 2020-09-10 15:53:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 15:53:53 --> Database Driver Class Initialized
DEBUG - 2020-09-10 15:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:53:53 --> Upload Class Initialized
INFO - 2020-09-10 15:53:53 --> Controller Class Initialized
DEBUG - 2020-09-10 15:53:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 15:53:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 15:53:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 15:53:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 15:53:53 --> Final output sent to browser
DEBUG - 2020-09-10 15:53:53 --> Total execution time: 0.0396
INFO - 2020-09-10 15:55:05 --> Config Class Initialized
INFO - 2020-09-10 15:55:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:55:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:55:05 --> Utf8 Class Initialized
INFO - 2020-09-10 15:55:05 --> URI Class Initialized
DEBUG - 2020-09-10 15:55:05 --> No URI present. Default controller set.
INFO - 2020-09-10 15:55:05 --> Router Class Initialized
INFO - 2020-09-10 15:55:05 --> Output Class Initialized
INFO - 2020-09-10 15:55:05 --> Security Class Initialized
DEBUG - 2020-09-10 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:55:05 --> Input Class Initialized
INFO - 2020-09-10 15:55:05 --> Language Class Initialized
INFO - 2020-09-10 15:55:05 --> Language Class Initialized
INFO - 2020-09-10 15:55:05 --> Config Class Initialized
INFO - 2020-09-10 15:55:05 --> Loader Class Initialized
INFO - 2020-09-10 15:55:05 --> Helper loaded: url_helper
INFO - 2020-09-10 15:55:05 --> Helper loaded: form_helper
INFO - 2020-09-10 15:55:05 --> Helper loaded: file_helper
INFO - 2020-09-10 15:55:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 15:55:05 --> Database Driver Class Initialized
DEBUG - 2020-09-10 15:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:55:05 --> Upload Class Initialized
INFO - 2020-09-10 15:55:05 --> Controller Class Initialized
DEBUG - 2020-09-10 15:55:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 15:55:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 15:55:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 15:55:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 15:55:05 --> Final output sent to browser
DEBUG - 2020-09-10 15:55:05 --> Total execution time: 0.0493
INFO - 2020-09-10 16:00:51 --> Config Class Initialized
INFO - 2020-09-10 16:00:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:00:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:00:51 --> Utf8 Class Initialized
INFO - 2020-09-10 16:00:51 --> URI Class Initialized
DEBUG - 2020-09-10 16:00:51 --> No URI present. Default controller set.
INFO - 2020-09-10 16:00:51 --> Router Class Initialized
INFO - 2020-09-10 16:00:51 --> Output Class Initialized
INFO - 2020-09-10 16:00:51 --> Security Class Initialized
DEBUG - 2020-09-10 16:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:00:51 --> Input Class Initialized
INFO - 2020-09-10 16:00:51 --> Language Class Initialized
INFO - 2020-09-10 16:00:51 --> Language Class Initialized
INFO - 2020-09-10 16:00:51 --> Config Class Initialized
INFO - 2020-09-10 16:00:51 --> Loader Class Initialized
INFO - 2020-09-10 16:00:51 --> Helper loaded: url_helper
INFO - 2020-09-10 16:00:51 --> Helper loaded: form_helper
INFO - 2020-09-10 16:00:51 --> Helper loaded: file_helper
INFO - 2020-09-10 16:00:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:00:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:00:51 --> Upload Class Initialized
INFO - 2020-09-10 16:00:51 --> Controller Class Initialized
DEBUG - 2020-09-10 16:00:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:00:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:00:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:00:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:00:51 --> Final output sent to browser
DEBUG - 2020-09-10 16:00:51 --> Total execution time: 0.0722
INFO - 2020-09-10 16:03:24 --> Config Class Initialized
INFO - 2020-09-10 16:03:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:03:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:03:24 --> Utf8 Class Initialized
INFO - 2020-09-10 16:03:24 --> URI Class Initialized
DEBUG - 2020-09-10 16:03:24 --> No URI present. Default controller set.
INFO - 2020-09-10 16:03:24 --> Router Class Initialized
INFO - 2020-09-10 16:03:24 --> Output Class Initialized
INFO - 2020-09-10 16:03:24 --> Security Class Initialized
DEBUG - 2020-09-10 16:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:03:24 --> Input Class Initialized
INFO - 2020-09-10 16:03:24 --> Language Class Initialized
INFO - 2020-09-10 16:03:24 --> Language Class Initialized
INFO - 2020-09-10 16:03:24 --> Config Class Initialized
INFO - 2020-09-10 16:03:24 --> Loader Class Initialized
INFO - 2020-09-10 16:03:24 --> Helper loaded: url_helper
INFO - 2020-09-10 16:03:24 --> Helper loaded: form_helper
INFO - 2020-09-10 16:03:24 --> Helper loaded: file_helper
INFO - 2020-09-10 16:03:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:03:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:03:24 --> Upload Class Initialized
INFO - 2020-09-10 16:03:24 --> Controller Class Initialized
DEBUG - 2020-09-10 16:03:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:03:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:03:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:03:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:03:24 --> Final output sent to browser
DEBUG - 2020-09-10 16:03:24 --> Total execution time: 0.0540
INFO - 2020-09-10 16:05:47 --> Config Class Initialized
INFO - 2020-09-10 16:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:05:47 --> Utf8 Class Initialized
INFO - 2020-09-10 16:05:47 --> URI Class Initialized
DEBUG - 2020-09-10 16:05:47 --> No URI present. Default controller set.
INFO - 2020-09-10 16:05:47 --> Router Class Initialized
INFO - 2020-09-10 16:05:47 --> Output Class Initialized
INFO - 2020-09-10 16:05:47 --> Security Class Initialized
DEBUG - 2020-09-10 16:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:05:47 --> Input Class Initialized
INFO - 2020-09-10 16:05:47 --> Language Class Initialized
INFO - 2020-09-10 16:05:47 --> Language Class Initialized
INFO - 2020-09-10 16:05:47 --> Config Class Initialized
INFO - 2020-09-10 16:05:47 --> Loader Class Initialized
INFO - 2020-09-10 16:05:47 --> Helper loaded: url_helper
INFO - 2020-09-10 16:05:47 --> Helper loaded: form_helper
INFO - 2020-09-10 16:05:47 --> Helper loaded: file_helper
INFO - 2020-09-10 16:05:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:05:47 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:05:47 --> Upload Class Initialized
INFO - 2020-09-10 16:05:47 --> Controller Class Initialized
DEBUG - 2020-09-10 16:05:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:05:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:05:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:05:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:05:47 --> Final output sent to browser
DEBUG - 2020-09-10 16:05:47 --> Total execution time: 0.0462
INFO - 2020-09-10 16:05:47 --> Config Class Initialized
INFO - 2020-09-10 16:05:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:05:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:05:47 --> Utf8 Class Initialized
INFO - 2020-09-10 16:05:47 --> URI Class Initialized
DEBUG - 2020-09-10 16:05:47 --> No URI present. Default controller set.
INFO - 2020-09-10 16:05:47 --> Router Class Initialized
INFO - 2020-09-10 16:05:47 --> Output Class Initialized
INFO - 2020-09-10 16:05:47 --> Security Class Initialized
DEBUG - 2020-09-10 16:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:05:47 --> Input Class Initialized
INFO - 2020-09-10 16:05:47 --> Language Class Initialized
INFO - 2020-09-10 16:05:48 --> Language Class Initialized
INFO - 2020-09-10 16:05:48 --> Config Class Initialized
INFO - 2020-09-10 16:05:48 --> Loader Class Initialized
INFO - 2020-09-10 16:05:48 --> Helper loaded: url_helper
INFO - 2020-09-10 16:05:48 --> Helper loaded: form_helper
INFO - 2020-09-10 16:05:48 --> Helper loaded: file_helper
INFO - 2020-09-10 16:05:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:05:48 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:05:48 --> Upload Class Initialized
INFO - 2020-09-10 16:05:48 --> Controller Class Initialized
DEBUG - 2020-09-10 16:05:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:05:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:05:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:05:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:05:48 --> Final output sent to browser
DEBUG - 2020-09-10 16:05:48 --> Total execution time: 0.0468
INFO - 2020-09-10 16:05:49 --> Config Class Initialized
INFO - 2020-09-10 16:05:49 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:05:49 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:05:49 --> Utf8 Class Initialized
INFO - 2020-09-10 16:05:49 --> URI Class Initialized
INFO - 2020-09-10 16:05:49 --> Router Class Initialized
INFO - 2020-09-10 16:05:49 --> Output Class Initialized
INFO - 2020-09-10 16:05:49 --> Security Class Initialized
DEBUG - 2020-09-10 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:05:49 --> Input Class Initialized
INFO - 2020-09-10 16:05:49 --> Language Class Initialized
INFO - 2020-09-10 16:05:49 --> Language Class Initialized
INFO - 2020-09-10 16:05:49 --> Config Class Initialized
INFO - 2020-09-10 16:05:49 --> Loader Class Initialized
INFO - 2020-09-10 16:05:49 --> Helper loaded: url_helper
INFO - 2020-09-10 16:05:49 --> Helper loaded: form_helper
INFO - 2020-09-10 16:05:49 --> Helper loaded: file_helper
INFO - 2020-09-10 16:05:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:05:49 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:05:49 --> Upload Class Initialized
INFO - 2020-09-10 16:05:49 --> Controller Class Initialized
DEBUG - 2020-09-10 16:05:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:05:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:05:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:05:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:05:49 --> Final output sent to browser
DEBUG - 2020-09-10 16:05:49 --> Total execution time: 0.0458
INFO - 2020-09-10 16:05:49 --> Config Class Initialized
INFO - 2020-09-10 16:05:49 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:05:49 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:05:49 --> Utf8 Class Initialized
INFO - 2020-09-10 16:05:49 --> URI Class Initialized
INFO - 2020-09-10 16:05:49 --> Router Class Initialized
INFO - 2020-09-10 16:05:49 --> Output Class Initialized
INFO - 2020-09-10 16:05:49 --> Security Class Initialized
DEBUG - 2020-09-10 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:05:49 --> Input Class Initialized
INFO - 2020-09-10 16:05:49 --> Language Class Initialized
INFO - 2020-09-10 16:05:49 --> Language Class Initialized
INFO - 2020-09-10 16:05:49 --> Config Class Initialized
INFO - 2020-09-10 16:05:49 --> Loader Class Initialized
INFO - 2020-09-10 16:05:49 --> Helper loaded: url_helper
INFO - 2020-09-10 16:05:49 --> Helper loaded: form_helper
INFO - 2020-09-10 16:05:49 --> Helper loaded: file_helper
INFO - 2020-09-10 16:05:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:05:49 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:05:49 --> Upload Class Initialized
INFO - 2020-09-10 16:05:49 --> Controller Class Initialized
DEBUG - 2020-09-10 16:05:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:05:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:05:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:05:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:05:49 --> Final output sent to browser
DEBUG - 2020-09-10 16:05:49 --> Total execution time: 0.0603
INFO - 2020-09-10 16:56:40 --> Config Class Initialized
INFO - 2020-09-10 16:56:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:56:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:56:40 --> Utf8 Class Initialized
INFO - 2020-09-10 16:56:40 --> URI Class Initialized
DEBUG - 2020-09-10 16:56:40 --> No URI present. Default controller set.
INFO - 2020-09-10 16:56:40 --> Router Class Initialized
INFO - 2020-09-10 16:56:40 --> Output Class Initialized
INFO - 2020-09-10 16:56:40 --> Security Class Initialized
DEBUG - 2020-09-10 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:56:40 --> Input Class Initialized
INFO - 2020-09-10 16:56:40 --> Language Class Initialized
INFO - 2020-09-10 16:56:40 --> Language Class Initialized
INFO - 2020-09-10 16:56:40 --> Config Class Initialized
INFO - 2020-09-10 16:56:40 --> Loader Class Initialized
INFO - 2020-09-10 16:56:40 --> Helper loaded: url_helper
INFO - 2020-09-10 16:56:40 --> Helper loaded: form_helper
INFO - 2020-09-10 16:56:40 --> Helper loaded: file_helper
INFO - 2020-09-10 16:56:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:56:40 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:56:40 --> Upload Class Initialized
INFO - 2020-09-10 16:56:40 --> Controller Class Initialized
DEBUG - 2020-09-10 16:56:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:56:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:56:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:56:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:56:40 --> Final output sent to browser
DEBUG - 2020-09-10 16:56:40 --> Total execution time: 0.0637
INFO - 2020-09-10 16:59:35 --> Config Class Initialized
INFO - 2020-09-10 16:59:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:59:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:59:35 --> Utf8 Class Initialized
INFO - 2020-09-10 16:59:35 --> URI Class Initialized
DEBUG - 2020-09-10 16:59:35 --> No URI present. Default controller set.
INFO - 2020-09-10 16:59:35 --> Router Class Initialized
INFO - 2020-09-10 16:59:35 --> Output Class Initialized
INFO - 2020-09-10 16:59:35 --> Security Class Initialized
DEBUG - 2020-09-10 16:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:59:35 --> Input Class Initialized
INFO - 2020-09-10 16:59:35 --> Language Class Initialized
INFO - 2020-09-10 16:59:35 --> Language Class Initialized
INFO - 2020-09-10 16:59:35 --> Config Class Initialized
INFO - 2020-09-10 16:59:35 --> Loader Class Initialized
INFO - 2020-09-10 16:59:35 --> Helper loaded: url_helper
INFO - 2020-09-10 16:59:35 --> Helper loaded: form_helper
INFO - 2020-09-10 16:59:35 --> Helper loaded: file_helper
INFO - 2020-09-10 16:59:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 16:59:35 --> Database Driver Class Initialized
DEBUG - 2020-09-10 16:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 16:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:59:35 --> Upload Class Initialized
INFO - 2020-09-10 16:59:35 --> Controller Class Initialized
DEBUG - 2020-09-10 16:59:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 16:59:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 16:59:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 16:59:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 16:59:35 --> Final output sent to browser
DEBUG - 2020-09-10 16:59:35 --> Total execution time: 0.0566
INFO - 2020-09-10 17:06:06 --> Config Class Initialized
INFO - 2020-09-10 17:06:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:06:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:06:06 --> Utf8 Class Initialized
INFO - 2020-09-10 17:06:06 --> URI Class Initialized
DEBUG - 2020-09-10 17:06:06 --> No URI present. Default controller set.
INFO - 2020-09-10 17:06:06 --> Router Class Initialized
INFO - 2020-09-10 17:06:06 --> Output Class Initialized
INFO - 2020-09-10 17:06:06 --> Security Class Initialized
DEBUG - 2020-09-10 17:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:06:06 --> Input Class Initialized
INFO - 2020-09-10 17:06:06 --> Language Class Initialized
INFO - 2020-09-10 17:06:06 --> Language Class Initialized
INFO - 2020-09-10 17:06:06 --> Config Class Initialized
INFO - 2020-09-10 17:06:06 --> Loader Class Initialized
INFO - 2020-09-10 17:06:06 --> Helper loaded: url_helper
INFO - 2020-09-10 17:06:06 --> Helper loaded: form_helper
INFO - 2020-09-10 17:06:06 --> Helper loaded: file_helper
INFO - 2020-09-10 17:06:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 17:06:06 --> Database Driver Class Initialized
DEBUG - 2020-09-10 17:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 17:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:06:06 --> Upload Class Initialized
INFO - 2020-09-10 17:06:06 --> Controller Class Initialized
DEBUG - 2020-09-10 17:06:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 17:06:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 17:06:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 17:06:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 17:06:06 --> Final output sent to browser
DEBUG - 2020-09-10 17:06:06 --> Total execution time: 0.0663
INFO - 2020-09-10 17:12:23 --> Config Class Initialized
INFO - 2020-09-10 17:12:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:12:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:12:23 --> Utf8 Class Initialized
INFO - 2020-09-10 17:12:23 --> URI Class Initialized
DEBUG - 2020-09-10 17:12:23 --> No URI present. Default controller set.
INFO - 2020-09-10 17:12:23 --> Router Class Initialized
INFO - 2020-09-10 17:12:23 --> Output Class Initialized
INFO - 2020-09-10 17:12:23 --> Security Class Initialized
DEBUG - 2020-09-10 17:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:12:23 --> Input Class Initialized
INFO - 2020-09-10 17:12:23 --> Language Class Initialized
INFO - 2020-09-10 17:12:23 --> Language Class Initialized
INFO - 2020-09-10 17:12:23 --> Config Class Initialized
INFO - 2020-09-10 17:12:23 --> Loader Class Initialized
INFO - 2020-09-10 17:12:23 --> Helper loaded: url_helper
INFO - 2020-09-10 17:12:23 --> Helper loaded: form_helper
INFO - 2020-09-10 17:12:23 --> Helper loaded: file_helper
INFO - 2020-09-10 17:12:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 17:12:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 17:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 17:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:12:23 --> Upload Class Initialized
INFO - 2020-09-10 17:12:23 --> Controller Class Initialized
DEBUG - 2020-09-10 17:12:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 17:12:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 17:12:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 17:12:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 17:12:23 --> Final output sent to browser
DEBUG - 2020-09-10 17:12:23 --> Total execution time: 0.0560
INFO - 2020-09-10 17:44:01 --> Config Class Initialized
INFO - 2020-09-10 17:44:01 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:44:01 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:44:01 --> Utf8 Class Initialized
INFO - 2020-09-10 17:44:01 --> URI Class Initialized
DEBUG - 2020-09-10 17:44:01 --> No URI present. Default controller set.
INFO - 2020-09-10 17:44:01 --> Router Class Initialized
INFO - 2020-09-10 17:44:01 --> Output Class Initialized
INFO - 2020-09-10 17:44:01 --> Security Class Initialized
DEBUG - 2020-09-10 17:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:44:01 --> Input Class Initialized
INFO - 2020-09-10 17:44:01 --> Language Class Initialized
INFO - 2020-09-10 17:44:01 --> Language Class Initialized
INFO - 2020-09-10 17:44:01 --> Config Class Initialized
INFO - 2020-09-10 17:44:01 --> Loader Class Initialized
INFO - 2020-09-10 17:44:01 --> Helper loaded: url_helper
INFO - 2020-09-10 17:44:01 --> Helper loaded: form_helper
INFO - 2020-09-10 17:44:01 --> Helper loaded: file_helper
INFO - 2020-09-10 17:44:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 17:44:01 --> Database Driver Class Initialized
DEBUG - 2020-09-10 17:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 17:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:44:01 --> Upload Class Initialized
INFO - 2020-09-10 17:44:01 --> Controller Class Initialized
DEBUG - 2020-09-10 17:44:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 17:44:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 17:44:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 17:44:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 17:44:01 --> Final output sent to browser
DEBUG - 2020-09-10 17:44:01 --> Total execution time: 0.0471
INFO - 2020-09-10 17:48:56 --> Config Class Initialized
INFO - 2020-09-10 17:48:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:48:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:48:56 --> Utf8 Class Initialized
INFO - 2020-09-10 17:48:56 --> URI Class Initialized
INFO - 2020-09-10 17:48:56 --> Router Class Initialized
INFO - 2020-09-10 17:48:56 --> Output Class Initialized
INFO - 2020-09-10 17:48:56 --> Security Class Initialized
DEBUG - 2020-09-10 17:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:48:56 --> Input Class Initialized
INFO - 2020-09-10 17:48:56 --> Language Class Initialized
INFO - 2020-09-10 17:48:56 --> Language Class Initialized
INFO - 2020-09-10 17:48:56 --> Config Class Initialized
INFO - 2020-09-10 17:48:56 --> Loader Class Initialized
INFO - 2020-09-10 17:48:56 --> Helper loaded: url_helper
INFO - 2020-09-10 17:48:56 --> Helper loaded: form_helper
INFO - 2020-09-10 17:48:56 --> Helper loaded: file_helper
INFO - 2020-09-10 17:48:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 17:48:56 --> Database Driver Class Initialized
DEBUG - 2020-09-10 17:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 17:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:48:56 --> Upload Class Initialized
INFO - 2020-09-10 17:48:56 --> Controller Class Initialized
ERROR - 2020-09-10 17:48:56 --> 404 Page Not Found: /index
INFO - 2020-09-10 17:49:00 --> Config Class Initialized
INFO - 2020-09-10 17:49:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:49:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:49:00 --> Utf8 Class Initialized
INFO - 2020-09-10 17:49:00 --> URI Class Initialized
INFO - 2020-09-10 17:49:00 --> Router Class Initialized
INFO - 2020-09-10 17:49:00 --> Output Class Initialized
INFO - 2020-09-10 17:49:00 --> Security Class Initialized
DEBUG - 2020-09-10 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:49:00 --> Input Class Initialized
INFO - 2020-09-10 17:49:00 --> Language Class Initialized
INFO - 2020-09-10 17:49:00 --> Language Class Initialized
INFO - 2020-09-10 17:49:00 --> Config Class Initialized
INFO - 2020-09-10 17:49:00 --> Loader Class Initialized
INFO - 2020-09-10 17:49:00 --> Helper loaded: url_helper
INFO - 2020-09-10 17:49:00 --> Helper loaded: form_helper
INFO - 2020-09-10 17:49:00 --> Helper loaded: file_helper
INFO - 2020-09-10 17:49:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 17:49:00 --> Database Driver Class Initialized
DEBUG - 2020-09-10 17:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 17:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:49:00 --> Upload Class Initialized
INFO - 2020-09-10 17:49:00 --> Controller Class Initialized
DEBUG - 2020-09-10 17:49:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 17:49:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-10 17:49:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 17:49:00 --> Final output sent to browser
DEBUG - 2020-09-10 17:49:00 --> Total execution time: 0.0551
INFO - 2020-09-10 18:14:11 --> Config Class Initialized
INFO - 2020-09-10 18:14:11 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:11 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:11 --> URI Class Initialized
DEBUG - 2020-09-10 18:14:11 --> No URI present. Default controller set.
INFO - 2020-09-10 18:14:11 --> Router Class Initialized
INFO - 2020-09-10 18:14:11 --> Output Class Initialized
INFO - 2020-09-10 18:14:11 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:11 --> Input Class Initialized
INFO - 2020-09-10 18:14:11 --> Language Class Initialized
INFO - 2020-09-10 18:14:11 --> Language Class Initialized
INFO - 2020-09-10 18:14:11 --> Config Class Initialized
INFO - 2020-09-10 18:14:11 --> Loader Class Initialized
INFO - 2020-09-10 18:14:11 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:11 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:11 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:11 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:11 --> Upload Class Initialized
INFO - 2020-09-10 18:14:12 --> Controller Class Initialized
DEBUG - 2020-09-10 18:14:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:14:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:14:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:14:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:14:12 --> Final output sent to browser
DEBUG - 2020-09-10 18:14:12 --> Total execution time: 0.0587
INFO - 2020-09-10 18:14:12 --> Config Class Initialized
INFO - 2020-09-10 18:14:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:12 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:12 --> URI Class Initialized
INFO - 2020-09-10 18:14:12 --> Router Class Initialized
INFO - 2020-09-10 18:14:12 --> Output Class Initialized
INFO - 2020-09-10 18:14:12 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:12 --> Input Class Initialized
INFO - 2020-09-10 18:14:12 --> Language Class Initialized
INFO - 2020-09-10 18:14:12 --> Language Class Initialized
INFO - 2020-09-10 18:14:12 --> Config Class Initialized
INFO - 2020-09-10 18:14:12 --> Loader Class Initialized
INFO - 2020-09-10 18:14:12 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:12 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:12 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:12 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:12 --> Upload Class Initialized
INFO - 2020-09-10 18:14:12 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:12 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:13 --> Config Class Initialized
INFO - 2020-09-10 18:14:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:13 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:13 --> URI Class Initialized
INFO - 2020-09-10 18:14:13 --> Router Class Initialized
INFO - 2020-09-10 18:14:13 --> Config Class Initialized
INFO - 2020-09-10 18:14:13 --> Hooks Class Initialized
INFO - 2020-09-10 18:14:13 --> Output Class Initialized
DEBUG - 2020-09-10 18:14:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:13 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:13 --> Security Class Initialized
INFO - 2020-09-10 18:14:13 --> URI Class Initialized
DEBUG - 2020-09-10 18:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:13 --> Input Class Initialized
INFO - 2020-09-10 18:14:13 --> Language Class Initialized
INFO - 2020-09-10 18:14:13 --> Language Class Initialized
INFO - 2020-09-10 18:14:13 --> Config Class Initialized
INFO - 2020-09-10 18:14:13 --> Router Class Initialized
INFO - 2020-09-10 18:14:13 --> Output Class Initialized
INFO - 2020-09-10 18:14:13 --> Loader Class Initialized
INFO - 2020-09-10 18:14:13 --> Security Class Initialized
INFO - 2020-09-10 18:14:13 --> Helper loaded: url_helper
DEBUG - 2020-09-10 18:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:13 --> Input Class Initialized
INFO - 2020-09-10 18:14:13 --> Language Class Initialized
INFO - 2020-09-10 18:14:13 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:13 --> Language Class Initialized
INFO - 2020-09-10 18:14:13 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:13 --> Config Class Initialized
INFO - 2020-09-10 18:14:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:13 --> Loader Class Initialized
INFO - 2020-09-10 18:14:13 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:13 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:13 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:13 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:13 --> Upload Class Initialized
INFO - 2020-09-10 18:14:13 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:13 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:13 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:13 --> Upload Class Initialized
INFO - 2020-09-10 18:14:13 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:13 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:13 --> Config Class Initialized
INFO - 2020-09-10 18:14:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:13 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:13 --> URI Class Initialized
INFO - 2020-09-10 18:14:13 --> Router Class Initialized
INFO - 2020-09-10 18:14:13 --> Output Class Initialized
INFO - 2020-09-10 18:14:13 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:13 --> Input Class Initialized
INFO - 2020-09-10 18:14:13 --> Language Class Initialized
INFO - 2020-09-10 18:14:13 --> Language Class Initialized
INFO - 2020-09-10 18:14:13 --> Config Class Initialized
INFO - 2020-09-10 18:14:13 --> Loader Class Initialized
INFO - 2020-09-10 18:14:13 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:13 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:13 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:13 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:13 --> Upload Class Initialized
INFO - 2020-09-10 18:14:13 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:13 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:16 --> Config Class Initialized
INFO - 2020-09-10 18:14:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:16 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:16 --> URI Class Initialized
INFO - 2020-09-10 18:14:16 --> Router Class Initialized
INFO - 2020-09-10 18:14:16 --> Output Class Initialized
INFO - 2020-09-10 18:14:16 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:16 --> Input Class Initialized
INFO - 2020-09-10 18:14:16 --> Language Class Initialized
INFO - 2020-09-10 18:14:16 --> Language Class Initialized
INFO - 2020-09-10 18:14:16 --> Config Class Initialized
INFO - 2020-09-10 18:14:16 --> Loader Class Initialized
INFO - 2020-09-10 18:14:16 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:16 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:16 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:16 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:16 --> Upload Class Initialized
INFO - 2020-09-10 18:14:16 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:16 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:18 --> Config Class Initialized
INFO - 2020-09-10 18:14:18 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:18 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:18 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:18 --> URI Class Initialized
DEBUG - 2020-09-10 18:14:18 --> No URI present. Default controller set.
INFO - 2020-09-10 18:14:18 --> Router Class Initialized
INFO - 2020-09-10 18:14:18 --> Output Class Initialized
INFO - 2020-09-10 18:14:18 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:18 --> Input Class Initialized
INFO - 2020-09-10 18:14:18 --> Language Class Initialized
INFO - 2020-09-10 18:14:18 --> Language Class Initialized
INFO - 2020-09-10 18:14:18 --> Config Class Initialized
INFO - 2020-09-10 18:14:18 --> Loader Class Initialized
INFO - 2020-09-10 18:14:18 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:18 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:18 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:18 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:18 --> Upload Class Initialized
INFO - 2020-09-10 18:14:18 --> Controller Class Initialized
DEBUG - 2020-09-10 18:14:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:14:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:14:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:14:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:14:18 --> Final output sent to browser
DEBUG - 2020-09-10 18:14:18 --> Total execution time: 0.0642
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:19 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:19 --> URI Class Initialized
INFO - 2020-09-10 18:14:19 --> Router Class Initialized
INFO - 2020-09-10 18:14:19 --> Output Class Initialized
INFO - 2020-09-10 18:14:19 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:19 --> Input Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Loader Class Initialized
INFO - 2020-09-10 18:14:19 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:19 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:19 --> Upload Class Initialized
INFO - 2020-09-10 18:14:19 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:19 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:19 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:19 --> URI Class Initialized
INFO - 2020-09-10 18:14:19 --> Router Class Initialized
INFO - 2020-09-10 18:14:19 --> Output Class Initialized
INFO - 2020-09-10 18:14:19 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:19 --> Input Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Loader Class Initialized
INFO - 2020-09-10 18:14:19 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:19 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:19 --> Upload Class Initialized
INFO - 2020-09-10 18:14:19 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:19 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:19 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:19 --> URI Class Initialized
INFO - 2020-09-10 18:14:19 --> Router Class Initialized
INFO - 2020-09-10 18:14:19 --> Output Class Initialized
INFO - 2020-09-10 18:14:19 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:19 --> Input Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Loader Class Initialized
INFO - 2020-09-10 18:14:19 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Hooks Class Initialized
INFO - 2020-09-10 18:14:19 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:14:19 --> Utf8 Class Initialized
INFO - 2020-09-10 18:14:19 --> URI Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:19 --> Upload Class Initialized
INFO - 2020-09-10 18:14:19 --> Router Class Initialized
INFO - 2020-09-10 18:14:19 --> Output Class Initialized
INFO - 2020-09-10 18:14:19 --> Security Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:14:19 --> Input Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Language Class Initialized
INFO - 2020-09-10 18:14:19 --> Config Class Initialized
INFO - 2020-09-10 18:14:19 --> Loader Class Initialized
INFO - 2020-09-10 18:14:19 --> Helper loaded: url_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: form_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: file_helper
INFO - 2020-09-10 18:14:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:14:19 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:14:19 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:19 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:14:19 --> Upload Class Initialized
INFO - 2020-09-10 18:14:19 --> Controller Class Initialized
ERROR - 2020-09-10 18:14:19 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:29:14 --> Config Class Initialized
INFO - 2020-09-10 18:29:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:29:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:29:14 --> Utf8 Class Initialized
INFO - 2020-09-10 18:29:14 --> URI Class Initialized
DEBUG - 2020-09-10 18:29:14 --> No URI present. Default controller set.
INFO - 2020-09-10 18:29:14 --> Router Class Initialized
INFO - 2020-09-10 18:29:14 --> Output Class Initialized
INFO - 2020-09-10 18:29:14 --> Security Class Initialized
DEBUG - 2020-09-10 18:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:29:14 --> Input Class Initialized
INFO - 2020-09-10 18:29:14 --> Language Class Initialized
INFO - 2020-09-10 18:29:14 --> Language Class Initialized
INFO - 2020-09-10 18:29:14 --> Config Class Initialized
INFO - 2020-09-10 18:29:14 --> Loader Class Initialized
INFO - 2020-09-10 18:29:14 --> Helper loaded: url_helper
INFO - 2020-09-10 18:29:14 --> Helper loaded: form_helper
INFO - 2020-09-10 18:29:14 --> Helper loaded: file_helper
INFO - 2020-09-10 18:29:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:29:14 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:29:14 --> Upload Class Initialized
INFO - 2020-09-10 18:29:14 --> Controller Class Initialized
DEBUG - 2020-09-10 18:29:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:29:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:29:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:29:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:29:14 --> Final output sent to browser
DEBUG - 2020-09-10 18:29:14 --> Total execution time: 0.0656
INFO - 2020-09-10 18:29:15 --> Config Class Initialized
INFO - 2020-09-10 18:29:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:29:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:29:15 --> Utf8 Class Initialized
INFO - 2020-09-10 18:29:15 --> URI Class Initialized
INFO - 2020-09-10 18:29:15 --> Router Class Initialized
INFO - 2020-09-10 18:29:15 --> Output Class Initialized
INFO - 2020-09-10 18:29:15 --> Security Class Initialized
DEBUG - 2020-09-10 18:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:29:15 --> Input Class Initialized
INFO - 2020-09-10 18:29:15 --> Language Class Initialized
INFO - 2020-09-10 18:29:15 --> Language Class Initialized
INFO - 2020-09-10 18:29:15 --> Config Class Initialized
INFO - 2020-09-10 18:29:15 --> Loader Class Initialized
INFO - 2020-09-10 18:29:15 --> Helper loaded: url_helper
INFO - 2020-09-10 18:29:15 --> Helper loaded: form_helper
INFO - 2020-09-10 18:29:15 --> Helper loaded: file_helper
INFO - 2020-09-10 18:29:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:29:15 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:29:15 --> Upload Class Initialized
INFO - 2020-09-10 18:29:15 --> Controller Class Initialized
ERROR - 2020-09-10 18:29:15 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:29:16 --> Config Class Initialized
INFO - 2020-09-10 18:29:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:29:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:29:16 --> Utf8 Class Initialized
INFO - 2020-09-10 18:29:16 --> URI Class Initialized
INFO - 2020-09-10 18:29:16 --> Router Class Initialized
INFO - 2020-09-10 18:29:16 --> Output Class Initialized
INFO - 2020-09-10 18:29:16 --> Security Class Initialized
INFO - 2020-09-10 18:29:16 --> Config Class Initialized
INFO - 2020-09-10 18:29:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:29:16 --> Input Class Initialized
INFO - 2020-09-10 18:29:16 --> Language Class Initialized
DEBUG - 2020-09-10 18:29:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:29:16 --> Utf8 Class Initialized
INFO - 2020-09-10 18:29:16 --> Language Class Initialized
INFO - 2020-09-10 18:29:16 --> Config Class Initialized
INFO - 2020-09-10 18:29:16 --> URI Class Initialized
INFO - 2020-09-10 18:29:16 --> Loader Class Initialized
INFO - 2020-09-10 18:29:16 --> Router Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: url_helper
INFO - 2020-09-10 18:29:16 --> Output Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: form_helper
INFO - 2020-09-10 18:29:16 --> Security Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: file_helper
DEBUG - 2020-09-10 18:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:29:16 --> Input Class Initialized
INFO - 2020-09-10 18:29:16 --> Language Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:29:16 --> Language Class Initialized
INFO - 2020-09-10 18:29:16 --> Config Class Initialized
INFO - 2020-09-10 18:29:16 --> Loader Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: url_helper
INFO - 2020-09-10 18:29:16 --> Helper loaded: form_helper
INFO - 2020-09-10 18:29:16 --> Helper loaded: file_helper
INFO - 2020-09-10 18:29:16 --> Database Driver Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-10 18:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:29:16 --> Upload Class Initialized
INFO - 2020-09-10 18:29:16 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:29:16 --> Controller Class Initialized
ERROR - 2020-09-10 18:29:16 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:29:16 --> Upload Class Initialized
INFO - 2020-09-10 18:29:16 --> Controller Class Initialized
ERROR - 2020-09-10 18:29:16 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:29:16 --> Config Class Initialized
INFO - 2020-09-10 18:29:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:29:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:29:16 --> Utf8 Class Initialized
INFO - 2020-09-10 18:29:16 --> URI Class Initialized
INFO - 2020-09-10 18:29:16 --> Router Class Initialized
INFO - 2020-09-10 18:29:16 --> Output Class Initialized
INFO - 2020-09-10 18:29:16 --> Security Class Initialized
DEBUG - 2020-09-10 18:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:29:16 --> Input Class Initialized
INFO - 2020-09-10 18:29:16 --> Language Class Initialized
INFO - 2020-09-10 18:29:16 --> Language Class Initialized
INFO - 2020-09-10 18:29:16 --> Config Class Initialized
INFO - 2020-09-10 18:29:16 --> Loader Class Initialized
INFO - 2020-09-10 18:29:16 --> Helper loaded: url_helper
INFO - 2020-09-10 18:29:16 --> Helper loaded: form_helper
INFO - 2020-09-10 18:29:16 --> Helper loaded: file_helper
INFO - 2020-09-10 18:29:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:29:16 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:29:16 --> Upload Class Initialized
INFO - 2020-09-10 18:29:16 --> Controller Class Initialized
ERROR - 2020-09-10 18:29:16 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:29:23 --> Config Class Initialized
INFO - 2020-09-10 18:29:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:29:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:29:23 --> Utf8 Class Initialized
INFO - 2020-09-10 18:29:23 --> URI Class Initialized
INFO - 2020-09-10 18:29:23 --> Router Class Initialized
INFO - 2020-09-10 18:29:23 --> Output Class Initialized
INFO - 2020-09-10 18:29:23 --> Security Class Initialized
DEBUG - 2020-09-10 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:29:23 --> Input Class Initialized
INFO - 2020-09-10 18:29:23 --> Language Class Initialized
INFO - 2020-09-10 18:29:23 --> Language Class Initialized
INFO - 2020-09-10 18:29:23 --> Config Class Initialized
INFO - 2020-09-10 18:29:23 --> Loader Class Initialized
INFO - 2020-09-10 18:29:23 --> Helper loaded: url_helper
INFO - 2020-09-10 18:29:23 --> Helper loaded: form_helper
INFO - 2020-09-10 18:29:23 --> Helper loaded: file_helper
INFO - 2020-09-10 18:29:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:29:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:29:23 --> Upload Class Initialized
INFO - 2020-09-10 18:29:23 --> Controller Class Initialized
ERROR - 2020-09-10 18:29:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:30:27 --> Config Class Initialized
INFO - 2020-09-10 18:30:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:30:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:30:27 --> Utf8 Class Initialized
INFO - 2020-09-10 18:30:27 --> URI Class Initialized
DEBUG - 2020-09-10 18:30:27 --> No URI present. Default controller set.
INFO - 2020-09-10 18:30:27 --> Router Class Initialized
INFO - 2020-09-10 18:30:27 --> Output Class Initialized
INFO - 2020-09-10 18:30:27 --> Security Class Initialized
DEBUG - 2020-09-10 18:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:30:27 --> Input Class Initialized
INFO - 2020-09-10 18:30:27 --> Language Class Initialized
INFO - 2020-09-10 18:30:27 --> Language Class Initialized
INFO - 2020-09-10 18:30:27 --> Config Class Initialized
INFO - 2020-09-10 18:30:27 --> Loader Class Initialized
INFO - 2020-09-10 18:30:27 --> Helper loaded: url_helper
INFO - 2020-09-10 18:30:27 --> Helper loaded: form_helper
INFO - 2020-09-10 18:30:27 --> Helper loaded: file_helper
INFO - 2020-09-10 18:30:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:30:27 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:30:27 --> Upload Class Initialized
INFO - 2020-09-10 18:30:27 --> Controller Class Initialized
DEBUG - 2020-09-10 18:30:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:30:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:30:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:30:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:30:27 --> Final output sent to browser
DEBUG - 2020-09-10 18:30:27 --> Total execution time: 0.0388
INFO - 2020-09-10 18:30:27 --> Config Class Initialized
INFO - 2020-09-10 18:30:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:30:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:30:27 --> Utf8 Class Initialized
INFO - 2020-09-10 18:30:27 --> URI Class Initialized
INFO - 2020-09-10 18:30:27 --> Router Class Initialized
INFO - 2020-09-10 18:30:27 --> Output Class Initialized
INFO - 2020-09-10 18:30:27 --> Security Class Initialized
DEBUG - 2020-09-10 18:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:30:27 --> Input Class Initialized
INFO - 2020-09-10 18:30:27 --> Language Class Initialized
INFO - 2020-09-10 18:30:27 --> Language Class Initialized
INFO - 2020-09-10 18:30:27 --> Config Class Initialized
INFO - 2020-09-10 18:30:27 --> Loader Class Initialized
INFO - 2020-09-10 18:30:27 --> Helper loaded: url_helper
INFO - 2020-09-10 18:30:27 --> Helper loaded: form_helper
INFO - 2020-09-10 18:30:27 --> Helper loaded: file_helper
INFO - 2020-09-10 18:30:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:30:27 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:30:27 --> Upload Class Initialized
INFO - 2020-09-10 18:30:27 --> Controller Class Initialized
ERROR - 2020-09-10 18:30:27 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:30:28 --> Config Class Initialized
INFO - 2020-09-10 18:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:30:28 --> Utf8 Class Initialized
INFO - 2020-09-10 18:30:28 --> Config Class Initialized
INFO - 2020-09-10 18:30:28 --> Hooks Class Initialized
INFO - 2020-09-10 18:30:28 --> URI Class Initialized
DEBUG - 2020-09-10 18:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:30:28 --> Utf8 Class Initialized
INFO - 2020-09-10 18:30:28 --> URI Class Initialized
INFO - 2020-09-10 18:30:28 --> Router Class Initialized
INFO - 2020-09-10 18:30:28 --> Router Class Initialized
INFO - 2020-09-10 18:30:28 --> Output Class Initialized
INFO - 2020-09-10 18:30:28 --> Output Class Initialized
INFO - 2020-09-10 18:30:28 --> Security Class Initialized
INFO - 2020-09-10 18:30:28 --> Security Class Initialized
DEBUG - 2020-09-10 18:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:30:28 --> Input Class Initialized
INFO - 2020-09-10 18:30:28 --> Language Class Initialized
DEBUG - 2020-09-10 18:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:30:28 --> Input Class Initialized
INFO - 2020-09-10 18:30:28 --> Language Class Initialized
INFO - 2020-09-10 18:30:28 --> Language Class Initialized
INFO - 2020-09-10 18:30:28 --> Config Class Initialized
INFO - 2020-09-10 18:30:28 --> Language Class Initialized
INFO - 2020-09-10 18:30:28 --> Config Class Initialized
INFO - 2020-09-10 18:30:28 --> Loader Class Initialized
INFO - 2020-09-10 18:30:28 --> Loader Class Initialized
INFO - 2020-09-10 18:30:28 --> Helper loaded: url_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: url_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: form_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: form_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: file_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: file_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:30:28 --> Database Driver Class Initialized
INFO - 2020-09-10 18:30:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:30:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-10 18:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:30:28 --> Upload Class Initialized
INFO - 2020-09-10 18:30:28 --> Controller Class Initialized
ERROR - 2020-09-10 18:30:28 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:30:28 --> Upload Class Initialized
INFO - 2020-09-10 18:30:28 --> Controller Class Initialized
ERROR - 2020-09-10 18:30:28 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:30:28 --> Config Class Initialized
INFO - 2020-09-10 18:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:30:28 --> Utf8 Class Initialized
INFO - 2020-09-10 18:30:28 --> URI Class Initialized
INFO - 2020-09-10 18:30:28 --> Router Class Initialized
INFO - 2020-09-10 18:30:28 --> Output Class Initialized
INFO - 2020-09-10 18:30:28 --> Security Class Initialized
DEBUG - 2020-09-10 18:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:30:28 --> Input Class Initialized
INFO - 2020-09-10 18:30:28 --> Language Class Initialized
INFO - 2020-09-10 18:30:28 --> Language Class Initialized
INFO - 2020-09-10 18:30:28 --> Config Class Initialized
INFO - 2020-09-10 18:30:28 --> Loader Class Initialized
INFO - 2020-09-10 18:30:28 --> Helper loaded: url_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: form_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: file_helper
INFO - 2020-09-10 18:30:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:30:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:30:28 --> Upload Class Initialized
INFO - 2020-09-10 18:30:28 --> Controller Class Initialized
ERROR - 2020-09-10 18:30:28 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:31:07 --> Config Class Initialized
INFO - 2020-09-10 18:31:07 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:31:07 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:31:07 --> Utf8 Class Initialized
INFO - 2020-09-10 18:31:07 --> URI Class Initialized
INFO - 2020-09-10 18:31:07 --> Router Class Initialized
INFO - 2020-09-10 18:31:07 --> Output Class Initialized
INFO - 2020-09-10 18:31:07 --> Security Class Initialized
DEBUG - 2020-09-10 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:31:07 --> Input Class Initialized
INFO - 2020-09-10 18:31:07 --> Language Class Initialized
INFO - 2020-09-10 18:31:07 --> Language Class Initialized
INFO - 2020-09-10 18:31:07 --> Config Class Initialized
INFO - 2020-09-10 18:31:07 --> Loader Class Initialized
INFO - 2020-09-10 18:31:07 --> Helper loaded: url_helper
INFO - 2020-09-10 18:31:07 --> Helper loaded: form_helper
INFO - 2020-09-10 18:31:07 --> Helper loaded: file_helper
INFO - 2020-09-10 18:31:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:31:07 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:31:07 --> Upload Class Initialized
INFO - 2020-09-10 18:31:07 --> Controller Class Initialized
ERROR - 2020-09-10 18:31:07 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:34:45 --> Config Class Initialized
INFO - 2020-09-10 18:34:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:34:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:34:45 --> Utf8 Class Initialized
INFO - 2020-09-10 18:34:45 --> URI Class Initialized
DEBUG - 2020-09-10 18:34:45 --> No URI present. Default controller set.
INFO - 2020-09-10 18:34:45 --> Router Class Initialized
INFO - 2020-09-10 18:34:45 --> Output Class Initialized
INFO - 2020-09-10 18:34:45 --> Security Class Initialized
DEBUG - 2020-09-10 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:34:45 --> Input Class Initialized
INFO - 2020-09-10 18:34:45 --> Language Class Initialized
INFO - 2020-09-10 18:34:45 --> Language Class Initialized
INFO - 2020-09-10 18:34:45 --> Config Class Initialized
INFO - 2020-09-10 18:34:45 --> Loader Class Initialized
INFO - 2020-09-10 18:34:45 --> Helper loaded: url_helper
INFO - 2020-09-10 18:34:45 --> Helper loaded: form_helper
INFO - 2020-09-10 18:34:45 --> Helper loaded: file_helper
INFO - 2020-09-10 18:34:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:34:45 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:34:45 --> Upload Class Initialized
INFO - 2020-09-10 18:34:45 --> Controller Class Initialized
DEBUG - 2020-09-10 18:34:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:34:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:34:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:34:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:34:45 --> Final output sent to browser
DEBUG - 2020-09-10 18:34:45 --> Total execution time: 0.0567
INFO - 2020-09-10 18:34:46 --> Config Class Initialized
INFO - 2020-09-10 18:34:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:34:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:34:46 --> Utf8 Class Initialized
INFO - 2020-09-10 18:34:46 --> URI Class Initialized
INFO - 2020-09-10 18:34:46 --> Config Class Initialized
INFO - 2020-09-10 18:34:46 --> Hooks Class Initialized
INFO - 2020-09-10 18:34:46 --> Router Class Initialized
DEBUG - 2020-09-10 18:34:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:34:46 --> Utf8 Class Initialized
INFO - 2020-09-10 18:34:46 --> URI Class Initialized
INFO - 2020-09-10 18:34:46 --> Output Class Initialized
INFO - 2020-09-10 18:34:46 --> Security Class Initialized
INFO - 2020-09-10 18:34:46 --> Router Class Initialized
DEBUG - 2020-09-10 18:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:34:46 --> Input Class Initialized
INFO - 2020-09-10 18:34:46 --> Language Class Initialized
INFO - 2020-09-10 18:34:46 --> Output Class Initialized
INFO - 2020-09-10 18:34:46 --> Language Class Initialized
INFO - 2020-09-10 18:34:46 --> Config Class Initialized
INFO - 2020-09-10 18:34:46 --> Security Class Initialized
DEBUG - 2020-09-10 18:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:34:46 --> Input Class Initialized
INFO - 2020-09-10 18:34:46 --> Language Class Initialized
INFO - 2020-09-10 18:34:46 --> Loader Class Initialized
INFO - 2020-09-10 18:34:46 --> Language Class Initialized
INFO - 2020-09-10 18:34:46 --> Config Class Initialized
INFO - 2020-09-10 18:34:46 --> Helper loaded: url_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: form_helper
INFO - 2020-09-10 18:34:46 --> Loader Class Initialized
INFO - 2020-09-10 18:34:46 --> Helper loaded: file_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: url_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: form_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: file_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:34:46 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:34:46 --> Database Driver Class Initialized
INFO - 2020-09-10 18:34:46 --> Upload Class Initialized
DEBUG - 2020-09-10 18:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:34:46 --> Controller Class Initialized
ERROR - 2020-09-10 18:34:46 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:34:46 --> Upload Class Initialized
INFO - 2020-09-10 18:34:46 --> Controller Class Initialized
ERROR - 2020-09-10 18:34:46 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:34:46 --> Config Class Initialized
INFO - 2020-09-10 18:34:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:34:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:34:46 --> Utf8 Class Initialized
INFO - 2020-09-10 18:34:46 --> URI Class Initialized
INFO - 2020-09-10 18:34:46 --> Router Class Initialized
INFO - 2020-09-10 18:34:46 --> Output Class Initialized
INFO - 2020-09-10 18:34:46 --> Security Class Initialized
DEBUG - 2020-09-10 18:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:34:46 --> Input Class Initialized
INFO - 2020-09-10 18:34:46 --> Language Class Initialized
INFO - 2020-09-10 18:34:46 --> Language Class Initialized
INFO - 2020-09-10 18:34:46 --> Config Class Initialized
INFO - 2020-09-10 18:34:46 --> Loader Class Initialized
INFO - 2020-09-10 18:34:46 --> Helper loaded: url_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: form_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: file_helper
INFO - 2020-09-10 18:34:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:34:46 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:34:46 --> Upload Class Initialized
INFO - 2020-09-10 18:34:46 --> Controller Class Initialized
ERROR - 2020-09-10 18:34:46 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:34:47 --> Config Class Initialized
INFO - 2020-09-10 18:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:34:47 --> Utf8 Class Initialized
INFO - 2020-09-10 18:34:47 --> URI Class Initialized
INFO - 2020-09-10 18:34:47 --> Router Class Initialized
INFO - 2020-09-10 18:34:47 --> Output Class Initialized
INFO - 2020-09-10 18:34:47 --> Security Class Initialized
DEBUG - 2020-09-10 18:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:34:47 --> Input Class Initialized
INFO - 2020-09-10 18:34:47 --> Language Class Initialized
INFO - 2020-09-10 18:34:47 --> Language Class Initialized
INFO - 2020-09-10 18:34:47 --> Config Class Initialized
INFO - 2020-09-10 18:34:47 --> Loader Class Initialized
INFO - 2020-09-10 18:34:47 --> Helper loaded: url_helper
INFO - 2020-09-10 18:34:47 --> Helper loaded: form_helper
INFO - 2020-09-10 18:34:47 --> Helper loaded: file_helper
INFO - 2020-09-10 18:34:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:34:47 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:34:47 --> Upload Class Initialized
INFO - 2020-09-10 18:34:47 --> Controller Class Initialized
ERROR - 2020-09-10 18:34:47 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:34:50 --> Config Class Initialized
INFO - 2020-09-10 18:34:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:34:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:34:50 --> Utf8 Class Initialized
INFO - 2020-09-10 18:34:50 --> URI Class Initialized
INFO - 2020-09-10 18:34:50 --> Router Class Initialized
INFO - 2020-09-10 18:34:50 --> Output Class Initialized
INFO - 2020-09-10 18:34:50 --> Security Class Initialized
DEBUG - 2020-09-10 18:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:34:50 --> Input Class Initialized
INFO - 2020-09-10 18:34:50 --> Language Class Initialized
INFO - 2020-09-10 18:34:50 --> Language Class Initialized
INFO - 2020-09-10 18:34:50 --> Config Class Initialized
INFO - 2020-09-10 18:34:50 --> Loader Class Initialized
INFO - 2020-09-10 18:34:50 --> Helper loaded: url_helper
INFO - 2020-09-10 18:34:50 --> Helper loaded: form_helper
INFO - 2020-09-10 18:34:50 --> Helper loaded: file_helper
INFO - 2020-09-10 18:34:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:34:50 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:34:50 --> Upload Class Initialized
INFO - 2020-09-10 18:34:50 --> Controller Class Initialized
ERROR - 2020-09-10 18:34:50 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:04 --> Config Class Initialized
INFO - 2020-09-10 18:35:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:04 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:04 --> URI Class Initialized
DEBUG - 2020-09-10 18:35:04 --> No URI present. Default controller set.
INFO - 2020-09-10 18:35:04 --> Router Class Initialized
INFO - 2020-09-10 18:35:04 --> Output Class Initialized
INFO - 2020-09-10 18:35:04 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:04 --> Input Class Initialized
INFO - 2020-09-10 18:35:04 --> Language Class Initialized
INFO - 2020-09-10 18:35:04 --> Language Class Initialized
INFO - 2020-09-10 18:35:04 --> Config Class Initialized
INFO - 2020-09-10 18:35:04 --> Loader Class Initialized
INFO - 2020-09-10 18:35:04 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:04 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:04 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:04 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:04 --> Upload Class Initialized
INFO - 2020-09-10 18:35:04 --> Controller Class Initialized
DEBUG - 2020-09-10 18:35:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:35:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:35:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:35:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:35:04 --> Final output sent to browser
DEBUG - 2020-09-10 18:35:04 --> Total execution time: 0.0548
INFO - 2020-09-10 18:35:04 --> Config Class Initialized
INFO - 2020-09-10 18:35:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:04 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:04 --> URI Class Initialized
INFO - 2020-09-10 18:35:04 --> Router Class Initialized
INFO - 2020-09-10 18:35:04 --> Output Class Initialized
INFO - 2020-09-10 18:35:04 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:04 --> Input Class Initialized
INFO - 2020-09-10 18:35:04 --> Language Class Initialized
INFO - 2020-09-10 18:35:04 --> Language Class Initialized
INFO - 2020-09-10 18:35:04 --> Config Class Initialized
INFO - 2020-09-10 18:35:04 --> Loader Class Initialized
INFO - 2020-09-10 18:35:04 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:04 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:04 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:04 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:04 --> Upload Class Initialized
INFO - 2020-09-10 18:35:04 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:04 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:05 --> Config Class Initialized
INFO - 2020-09-10 18:35:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:05 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:05 --> URI Class Initialized
INFO - 2020-09-10 18:35:05 --> Router Class Initialized
INFO - 2020-09-10 18:35:05 --> Output Class Initialized
INFO - 2020-09-10 18:35:05 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:05 --> Input Class Initialized
INFO - 2020-09-10 18:35:05 --> Language Class Initialized
INFO - 2020-09-10 18:35:05 --> Language Class Initialized
INFO - 2020-09-10 18:35:05 --> Config Class Initialized
INFO - 2020-09-10 18:35:05 --> Loader Class Initialized
INFO - 2020-09-10 18:35:05 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:05 --> Config Class Initialized
INFO - 2020-09-10 18:35:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:05 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:05 --> Database Driver Class Initialized
INFO - 2020-09-10 18:35:05 --> URI Class Initialized
INFO - 2020-09-10 18:35:05 --> Router Class Initialized
INFO - 2020-09-10 18:35:05 --> Output Class Initialized
INFO - 2020-09-10 18:35:05 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-10 18:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:05 --> Input Class Initialized
INFO - 2020-09-10 18:35:05 --> Language Class Initialized
INFO - 2020-09-10 18:35:05 --> Upload Class Initialized
INFO - 2020-09-10 18:35:05 --> Language Class Initialized
INFO - 2020-09-10 18:35:05 --> Config Class Initialized
INFO - 2020-09-10 18:35:05 --> Loader Class Initialized
INFO - 2020-09-10 18:35:05 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:05 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:05 --> Config Class Initialized
INFO - 2020-09-10 18:35:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:05 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:05 --> URI Class Initialized
INFO - 2020-09-10 18:35:05 --> Router Class Initialized
INFO - 2020-09-10 18:35:05 --> Output Class Initialized
INFO - 2020-09-10 18:35:05 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:05 --> Input Class Initialized
INFO - 2020-09-10 18:35:05 --> Language Class Initialized
INFO - 2020-09-10 18:35:05 --> Language Class Initialized
INFO - 2020-09-10 18:35:05 --> Config Class Initialized
INFO - 2020-09-10 18:35:05 --> Loader Class Initialized
INFO - 2020-09-10 18:35:05 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:05 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:05 --> Controller Class Initialized
INFO - 2020-09-10 18:35:05 --> Helper loaded: myhelper_helper
ERROR - 2020-09-10 18:35:05 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:05 --> Upload Class Initialized
INFO - 2020-09-10 18:35:05 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:05 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:05 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:05 --> Upload Class Initialized
INFO - 2020-09-10 18:35:05 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:05 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:50 --> Config Class Initialized
INFO - 2020-09-10 18:35:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:50 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:50 --> URI Class Initialized
DEBUG - 2020-09-10 18:35:50 --> No URI present. Default controller set.
INFO - 2020-09-10 18:35:50 --> Router Class Initialized
INFO - 2020-09-10 18:35:50 --> Output Class Initialized
INFO - 2020-09-10 18:35:50 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:50 --> Input Class Initialized
INFO - 2020-09-10 18:35:50 --> Language Class Initialized
INFO - 2020-09-10 18:35:50 --> Language Class Initialized
INFO - 2020-09-10 18:35:50 --> Config Class Initialized
INFO - 2020-09-10 18:35:50 --> Loader Class Initialized
INFO - 2020-09-10 18:35:50 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:50 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:50 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:50 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:50 --> Upload Class Initialized
INFO - 2020-09-10 18:35:50 --> Controller Class Initialized
DEBUG - 2020-09-10 18:35:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:35:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:35:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:35:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:35:50 --> Final output sent to browser
DEBUG - 2020-09-10 18:35:50 --> Total execution time: 0.0522
INFO - 2020-09-10 18:35:50 --> Config Class Initialized
INFO - 2020-09-10 18:35:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:50 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:50 --> URI Class Initialized
INFO - 2020-09-10 18:35:50 --> Router Class Initialized
INFO - 2020-09-10 18:35:50 --> Output Class Initialized
INFO - 2020-09-10 18:35:50 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:50 --> Input Class Initialized
INFO - 2020-09-10 18:35:50 --> Language Class Initialized
INFO - 2020-09-10 18:35:50 --> Language Class Initialized
INFO - 2020-09-10 18:35:50 --> Config Class Initialized
INFO - 2020-09-10 18:35:50 --> Loader Class Initialized
INFO - 2020-09-10 18:35:50 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:50 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:50 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:50 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:50 --> Upload Class Initialized
INFO - 2020-09-10 18:35:50 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:50 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:51 --> Config Class Initialized
INFO - 2020-09-10 18:35:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:51 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:51 --> URI Class Initialized
INFO - 2020-09-10 18:35:51 --> Router Class Initialized
INFO - 2020-09-10 18:35:51 --> Output Class Initialized
INFO - 2020-09-10 18:35:51 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:51 --> Input Class Initialized
INFO - 2020-09-10 18:35:51 --> Language Class Initialized
INFO - 2020-09-10 18:35:51 --> Language Class Initialized
INFO - 2020-09-10 18:35:51 --> Config Class Initialized
INFO - 2020-09-10 18:35:51 --> Loader Class Initialized
INFO - 2020-09-10 18:35:51 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:51 --> Upload Class Initialized
INFO - 2020-09-10 18:35:51 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:51 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:51 --> Config Class Initialized
INFO - 2020-09-10 18:35:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:51 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:51 --> URI Class Initialized
INFO - 2020-09-10 18:35:51 --> Router Class Initialized
INFO - 2020-09-10 18:35:51 --> Output Class Initialized
INFO - 2020-09-10 18:35:51 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:51 --> Input Class Initialized
INFO - 2020-09-10 18:35:51 --> Language Class Initialized
INFO - 2020-09-10 18:35:51 --> Language Class Initialized
INFO - 2020-09-10 18:35:51 --> Config Class Initialized
INFO - 2020-09-10 18:35:51 --> Loader Class Initialized
INFO - 2020-09-10 18:35:51 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:51 --> Upload Class Initialized
INFO - 2020-09-10 18:35:51 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:51 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:35:51 --> Config Class Initialized
INFO - 2020-09-10 18:35:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:35:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:35:51 --> Utf8 Class Initialized
INFO - 2020-09-10 18:35:51 --> URI Class Initialized
INFO - 2020-09-10 18:35:51 --> Router Class Initialized
INFO - 2020-09-10 18:35:51 --> Output Class Initialized
INFO - 2020-09-10 18:35:51 --> Security Class Initialized
DEBUG - 2020-09-10 18:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:35:51 --> Input Class Initialized
INFO - 2020-09-10 18:35:51 --> Language Class Initialized
INFO - 2020-09-10 18:35:51 --> Language Class Initialized
INFO - 2020-09-10 18:35:51 --> Config Class Initialized
INFO - 2020-09-10 18:35:51 --> Loader Class Initialized
INFO - 2020-09-10 18:35:51 --> Helper loaded: url_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: form_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: file_helper
INFO - 2020-09-10 18:35:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:35:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:35:51 --> Upload Class Initialized
INFO - 2020-09-10 18:35:51 --> Controller Class Initialized
ERROR - 2020-09-10 18:35:51 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:40:22 --> Config Class Initialized
INFO - 2020-09-10 18:40:22 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:40:22 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:40:22 --> Utf8 Class Initialized
INFO - 2020-09-10 18:40:22 --> URI Class Initialized
DEBUG - 2020-09-10 18:40:22 --> No URI present. Default controller set.
INFO - 2020-09-10 18:40:22 --> Router Class Initialized
INFO - 2020-09-10 18:40:22 --> Output Class Initialized
INFO - 2020-09-10 18:40:22 --> Security Class Initialized
DEBUG - 2020-09-10 18:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:40:22 --> Input Class Initialized
INFO - 2020-09-10 18:40:22 --> Language Class Initialized
INFO - 2020-09-10 18:40:22 --> Language Class Initialized
INFO - 2020-09-10 18:40:22 --> Config Class Initialized
INFO - 2020-09-10 18:40:22 --> Loader Class Initialized
INFO - 2020-09-10 18:40:22 --> Helper loaded: url_helper
INFO - 2020-09-10 18:40:22 --> Helper loaded: form_helper
INFO - 2020-09-10 18:40:22 --> Helper loaded: file_helper
INFO - 2020-09-10 18:40:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:40:22 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:40:22 --> Upload Class Initialized
INFO - 2020-09-10 18:40:22 --> Controller Class Initialized
DEBUG - 2020-09-10 18:40:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:40:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:40:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:40:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:40:22 --> Final output sent to browser
DEBUG - 2020-09-10 18:40:22 --> Total execution time: 0.0439
INFO - 2020-09-10 18:40:23 --> Config Class Initialized
INFO - 2020-09-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:40:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:40:23 --> Utf8 Class Initialized
INFO - 2020-09-10 18:40:23 --> URI Class Initialized
INFO - 2020-09-10 18:40:23 --> Router Class Initialized
INFO - 2020-09-10 18:40:23 --> Output Class Initialized
INFO - 2020-09-10 18:40:23 --> Security Class Initialized
DEBUG - 2020-09-10 18:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:40:23 --> Input Class Initialized
INFO - 2020-09-10 18:40:23 --> Language Class Initialized
INFO - 2020-09-10 18:40:23 --> Language Class Initialized
INFO - 2020-09-10 18:40:23 --> Config Class Initialized
INFO - 2020-09-10 18:40:23 --> Loader Class Initialized
INFO - 2020-09-10 18:40:23 --> Helper loaded: url_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: form_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: file_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:40:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:40:23 --> Upload Class Initialized
INFO - 2020-09-10 18:40:23 --> Controller Class Initialized
ERROR - 2020-09-10 18:40:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:40:23 --> Config Class Initialized
INFO - 2020-09-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:40:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:40:23 --> Utf8 Class Initialized
INFO - 2020-09-10 18:40:23 --> URI Class Initialized
INFO - 2020-09-10 18:40:23 --> Router Class Initialized
INFO - 2020-09-10 18:40:23 --> Output Class Initialized
INFO - 2020-09-10 18:40:23 --> Security Class Initialized
DEBUG - 2020-09-10 18:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:40:23 --> Input Class Initialized
INFO - 2020-09-10 18:40:23 --> Language Class Initialized
INFO - 2020-09-10 18:40:23 --> Language Class Initialized
INFO - 2020-09-10 18:40:23 --> Config Class Initialized
INFO - 2020-09-10 18:40:23 --> Loader Class Initialized
INFO - 2020-09-10 18:40:23 --> Helper loaded: url_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: form_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: file_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:40:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:40:23 --> Upload Class Initialized
INFO - 2020-09-10 18:40:23 --> Controller Class Initialized
ERROR - 2020-09-10 18:40:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:40:23 --> Config Class Initialized
INFO - 2020-09-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:40:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:40:23 --> Utf8 Class Initialized
INFO - 2020-09-10 18:40:23 --> URI Class Initialized
INFO - 2020-09-10 18:40:23 --> Router Class Initialized
INFO - 2020-09-10 18:40:23 --> Output Class Initialized
INFO - 2020-09-10 18:40:23 --> Security Class Initialized
DEBUG - 2020-09-10 18:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:40:23 --> Input Class Initialized
INFO - 2020-09-10 18:40:23 --> Language Class Initialized
INFO - 2020-09-10 18:40:23 --> Language Class Initialized
INFO - 2020-09-10 18:40:23 --> Config Class Initialized
INFO - 2020-09-10 18:40:23 --> Loader Class Initialized
INFO - 2020-09-10 18:40:23 --> Helper loaded: url_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: form_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: file_helper
INFO - 2020-09-10 18:40:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:40:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:40:23 --> Upload Class Initialized
INFO - 2020-09-10 18:40:23 --> Controller Class Initialized
ERROR - 2020-09-10 18:40:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:40:24 --> Config Class Initialized
INFO - 2020-09-10 18:40:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:40:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:40:24 --> Utf8 Class Initialized
INFO - 2020-09-10 18:40:24 --> URI Class Initialized
INFO - 2020-09-10 18:40:24 --> Router Class Initialized
INFO - 2020-09-10 18:40:24 --> Output Class Initialized
INFO - 2020-09-10 18:40:24 --> Security Class Initialized
DEBUG - 2020-09-10 18:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:40:24 --> Input Class Initialized
INFO - 2020-09-10 18:40:24 --> Language Class Initialized
INFO - 2020-09-10 18:40:24 --> Language Class Initialized
INFO - 2020-09-10 18:40:24 --> Config Class Initialized
INFO - 2020-09-10 18:40:24 --> Loader Class Initialized
INFO - 2020-09-10 18:40:24 --> Helper loaded: url_helper
INFO - 2020-09-10 18:40:24 --> Helper loaded: form_helper
INFO - 2020-09-10 18:40:24 --> Helper loaded: file_helper
INFO - 2020-09-10 18:40:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:40:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:40:24 --> Upload Class Initialized
INFO - 2020-09-10 18:40:24 --> Controller Class Initialized
ERROR - 2020-09-10 18:40:24 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:41:00 --> Config Class Initialized
INFO - 2020-09-10 18:41:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:00 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:00 --> URI Class Initialized
INFO - 2020-09-10 18:41:00 --> Router Class Initialized
INFO - 2020-09-10 18:41:00 --> Output Class Initialized
INFO - 2020-09-10 18:41:00 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:00 --> Input Class Initialized
INFO - 2020-09-10 18:41:00 --> Language Class Initialized
INFO - 2020-09-10 18:41:00 --> Language Class Initialized
INFO - 2020-09-10 18:41:00 --> Config Class Initialized
INFO - 2020-09-10 18:41:00 --> Loader Class Initialized
INFO - 2020-09-10 18:41:00 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:00 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:00 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:00 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:00 --> Upload Class Initialized
INFO - 2020-09-10 18:41:00 --> Controller Class Initialized
DEBUG - 2020-09-10 18:41:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:41:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-10 18:41:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:41:00 --> Final output sent to browser
DEBUG - 2020-09-10 18:41:00 --> Total execution time: 0.0488
INFO - 2020-09-10 18:41:01 --> Config Class Initialized
INFO - 2020-09-10 18:41:01 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:01 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:01 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:01 --> URI Class Initialized
DEBUG - 2020-09-10 18:41:01 --> No URI present. Default controller set.
INFO - 2020-09-10 18:41:01 --> Router Class Initialized
INFO - 2020-09-10 18:41:01 --> Output Class Initialized
INFO - 2020-09-10 18:41:01 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:01 --> Input Class Initialized
INFO - 2020-09-10 18:41:01 --> Language Class Initialized
INFO - 2020-09-10 18:41:01 --> Language Class Initialized
INFO - 2020-09-10 18:41:01 --> Config Class Initialized
INFO - 2020-09-10 18:41:01 --> Loader Class Initialized
INFO - 2020-09-10 18:41:01 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:01 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:01 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:01 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:01 --> Upload Class Initialized
INFO - 2020-09-10 18:41:01 --> Controller Class Initialized
DEBUG - 2020-09-10 18:41:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:41:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:41:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:41:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:41:01 --> Final output sent to browser
DEBUG - 2020-09-10 18:41:01 --> Total execution time: 0.0495
INFO - 2020-09-10 18:41:02 --> Config Class Initialized
INFO - 2020-09-10 18:41:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:02 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:02 --> URI Class Initialized
INFO - 2020-09-10 18:41:02 --> Router Class Initialized
INFO - 2020-09-10 18:41:02 --> Output Class Initialized
INFO - 2020-09-10 18:41:02 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:02 --> Input Class Initialized
INFO - 2020-09-10 18:41:02 --> Language Class Initialized
INFO - 2020-09-10 18:41:02 --> Language Class Initialized
INFO - 2020-09-10 18:41:02 --> Config Class Initialized
INFO - 2020-09-10 18:41:02 --> Loader Class Initialized
INFO - 2020-09-10 18:41:02 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:02 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:02 --> Upload Class Initialized
INFO - 2020-09-10 18:41:02 --> Controller Class Initialized
ERROR - 2020-09-10 18:41:02 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:41:02 --> Config Class Initialized
INFO - 2020-09-10 18:41:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:02 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:02 --> URI Class Initialized
INFO - 2020-09-10 18:41:02 --> Router Class Initialized
INFO - 2020-09-10 18:41:02 --> Output Class Initialized
INFO - 2020-09-10 18:41:02 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:02 --> Input Class Initialized
INFO - 2020-09-10 18:41:02 --> Language Class Initialized
INFO - 2020-09-10 18:41:02 --> Language Class Initialized
INFO - 2020-09-10 18:41:02 --> Config Class Initialized
INFO - 2020-09-10 18:41:02 --> Loader Class Initialized
INFO - 2020-09-10 18:41:02 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:02 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:02 --> Upload Class Initialized
INFO - 2020-09-10 18:41:02 --> Controller Class Initialized
ERROR - 2020-09-10 18:41:02 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:41:02 --> Config Class Initialized
INFO - 2020-09-10 18:41:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:02 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:02 --> URI Class Initialized
INFO - 2020-09-10 18:41:02 --> Router Class Initialized
INFO - 2020-09-10 18:41:02 --> Output Class Initialized
INFO - 2020-09-10 18:41:02 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:02 --> Input Class Initialized
INFO - 2020-09-10 18:41:02 --> Language Class Initialized
INFO - 2020-09-10 18:41:02 --> Language Class Initialized
INFO - 2020-09-10 18:41:02 --> Config Class Initialized
INFO - 2020-09-10 18:41:02 --> Loader Class Initialized
INFO - 2020-09-10 18:41:02 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:02 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:02 --> Upload Class Initialized
INFO - 2020-09-10 18:41:02 --> Controller Class Initialized
ERROR - 2020-09-10 18:41:02 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:41:20 --> Config Class Initialized
INFO - 2020-09-10 18:41:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:20 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:20 --> URI Class Initialized
INFO - 2020-09-10 18:41:20 --> Router Class Initialized
INFO - 2020-09-10 18:41:20 --> Output Class Initialized
INFO - 2020-09-10 18:41:20 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:20 --> Input Class Initialized
INFO - 2020-09-10 18:41:20 --> Language Class Initialized
INFO - 2020-09-10 18:41:20 --> Language Class Initialized
INFO - 2020-09-10 18:41:20 --> Config Class Initialized
INFO - 2020-09-10 18:41:20 --> Loader Class Initialized
INFO - 2020-09-10 18:41:20 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:20 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:20 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:20 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:20 --> Upload Class Initialized
INFO - 2020-09-10 18:41:20 --> Controller Class Initialized
DEBUG - 2020-09-10 18:41:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:41:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-10 18:41:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:41:20 --> Final output sent to browser
DEBUG - 2020-09-10 18:41:20 --> Total execution time: 0.0505
INFO - 2020-09-10 18:41:24 --> Config Class Initialized
INFO - 2020-09-10 18:41:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:24 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:24 --> URI Class Initialized
DEBUG - 2020-09-10 18:41:24 --> No URI present. Default controller set.
INFO - 2020-09-10 18:41:24 --> Router Class Initialized
INFO - 2020-09-10 18:41:24 --> Output Class Initialized
INFO - 2020-09-10 18:41:24 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:24 --> Input Class Initialized
INFO - 2020-09-10 18:41:24 --> Language Class Initialized
INFO - 2020-09-10 18:41:24 --> Language Class Initialized
INFO - 2020-09-10 18:41:24 --> Config Class Initialized
INFO - 2020-09-10 18:41:24 --> Loader Class Initialized
INFO - 2020-09-10 18:41:24 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:24 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:24 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:24 --> Upload Class Initialized
INFO - 2020-09-10 18:41:24 --> Controller Class Initialized
DEBUG - 2020-09-10 18:41:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 18:41:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 18:41:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 18:41:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 18:41:24 --> Final output sent to browser
DEBUG - 2020-09-10 18:41:24 --> Total execution time: 0.0590
INFO - 2020-09-10 18:41:25 --> Config Class Initialized
INFO - 2020-09-10 18:41:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:25 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:25 --> URI Class Initialized
INFO - 2020-09-10 18:41:25 --> Router Class Initialized
INFO - 2020-09-10 18:41:25 --> Output Class Initialized
INFO - 2020-09-10 18:41:25 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:25 --> Input Class Initialized
INFO - 2020-09-10 18:41:25 --> Language Class Initialized
INFO - 2020-09-10 18:41:25 --> Language Class Initialized
INFO - 2020-09-10 18:41:25 --> Config Class Initialized
INFO - 2020-09-10 18:41:25 --> Loader Class Initialized
INFO - 2020-09-10 18:41:25 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:25 --> Upload Class Initialized
INFO - 2020-09-10 18:41:25 --> Controller Class Initialized
ERROR - 2020-09-10 18:41:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:41:25 --> Config Class Initialized
INFO - 2020-09-10 18:41:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:25 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:25 --> URI Class Initialized
INFO - 2020-09-10 18:41:25 --> Router Class Initialized
INFO - 2020-09-10 18:41:25 --> Output Class Initialized
INFO - 2020-09-10 18:41:25 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:25 --> Input Class Initialized
INFO - 2020-09-10 18:41:25 --> Language Class Initialized
INFO - 2020-09-10 18:41:25 --> Language Class Initialized
INFO - 2020-09-10 18:41:25 --> Config Class Initialized
INFO - 2020-09-10 18:41:25 --> Loader Class Initialized
INFO - 2020-09-10 18:41:25 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:25 --> Upload Class Initialized
INFO - 2020-09-10 18:41:25 --> Controller Class Initialized
ERROR - 2020-09-10 18:41:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 18:41:25 --> Config Class Initialized
INFO - 2020-09-10 18:41:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 18:41:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 18:41:25 --> Utf8 Class Initialized
INFO - 2020-09-10 18:41:25 --> URI Class Initialized
INFO - 2020-09-10 18:41:25 --> Router Class Initialized
INFO - 2020-09-10 18:41:25 --> Output Class Initialized
INFO - 2020-09-10 18:41:25 --> Security Class Initialized
DEBUG - 2020-09-10 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 18:41:25 --> Input Class Initialized
INFO - 2020-09-10 18:41:25 --> Language Class Initialized
INFO - 2020-09-10 18:41:25 --> Language Class Initialized
INFO - 2020-09-10 18:41:25 --> Config Class Initialized
INFO - 2020-09-10 18:41:25 --> Loader Class Initialized
INFO - 2020-09-10 18:41:25 --> Helper loaded: url_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: form_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: file_helper
INFO - 2020-09-10 18:41:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 18:41:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 18:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 18:41:25 --> Upload Class Initialized
INFO - 2020-09-10 18:41:25 --> Controller Class Initialized
ERROR - 2020-09-10 18:41:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:25:28 --> Config Class Initialized
INFO - 2020-09-10 19:25:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:25:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:25:28 --> Utf8 Class Initialized
INFO - 2020-09-10 19:25:28 --> URI Class Initialized
DEBUG - 2020-09-10 19:25:28 --> No URI present. Default controller set.
INFO - 2020-09-10 19:25:28 --> Router Class Initialized
INFO - 2020-09-10 19:25:28 --> Output Class Initialized
INFO - 2020-09-10 19:25:28 --> Security Class Initialized
DEBUG - 2020-09-10 19:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:25:28 --> Input Class Initialized
INFO - 2020-09-10 19:25:28 --> Language Class Initialized
INFO - 2020-09-10 19:25:28 --> Language Class Initialized
INFO - 2020-09-10 19:25:28 --> Config Class Initialized
INFO - 2020-09-10 19:25:28 --> Loader Class Initialized
INFO - 2020-09-10 19:25:28 --> Helper loaded: url_helper
INFO - 2020-09-10 19:25:28 --> Helper loaded: form_helper
INFO - 2020-09-10 19:25:28 --> Helper loaded: file_helper
INFO - 2020-09-10 19:25:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:25:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:25:28 --> Upload Class Initialized
INFO - 2020-09-10 19:25:28 --> Controller Class Initialized
DEBUG - 2020-09-10 19:25:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 19:25:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 19:25:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 19:25:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 19:25:28 --> Final output sent to browser
DEBUG - 2020-09-10 19:25:28 --> Total execution time: 0.0631
INFO - 2020-09-10 19:25:29 --> Config Class Initialized
INFO - 2020-09-10 19:25:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:25:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:25:29 --> Utf8 Class Initialized
INFO - 2020-09-10 19:25:29 --> URI Class Initialized
DEBUG - 2020-09-10 19:25:29 --> No URI present. Default controller set.
INFO - 2020-09-10 19:25:29 --> Router Class Initialized
INFO - 2020-09-10 19:25:29 --> Output Class Initialized
INFO - 2020-09-10 19:25:29 --> Security Class Initialized
DEBUG - 2020-09-10 19:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:25:29 --> Input Class Initialized
INFO - 2020-09-10 19:25:29 --> Language Class Initialized
INFO - 2020-09-10 19:25:29 --> Language Class Initialized
INFO - 2020-09-10 19:25:29 --> Config Class Initialized
INFO - 2020-09-10 19:25:29 --> Loader Class Initialized
INFO - 2020-09-10 19:25:29 --> Helper loaded: url_helper
INFO - 2020-09-10 19:25:29 --> Helper loaded: form_helper
INFO - 2020-09-10 19:25:29 --> Helper loaded: file_helper
INFO - 2020-09-10 19:25:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:25:29 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:25:29 --> Upload Class Initialized
INFO - 2020-09-10 19:25:29 --> Controller Class Initialized
DEBUG - 2020-09-10 19:25:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 19:25:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 19:25:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 19:25:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 19:25:29 --> Final output sent to browser
DEBUG - 2020-09-10 19:25:29 --> Total execution time: 0.0588
INFO - 2020-09-10 19:31:52 --> Config Class Initialized
INFO - 2020-09-10 19:31:52 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:31:52 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:31:52 --> Utf8 Class Initialized
INFO - 2020-09-10 19:31:52 --> URI Class Initialized
INFO - 2020-09-10 19:31:52 --> Router Class Initialized
INFO - 2020-09-10 19:31:52 --> Output Class Initialized
INFO - 2020-09-10 19:31:52 --> Security Class Initialized
DEBUG - 2020-09-10 19:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:31:52 --> Input Class Initialized
INFO - 2020-09-10 19:31:52 --> Language Class Initialized
INFO - 2020-09-10 19:31:52 --> Language Class Initialized
INFO - 2020-09-10 19:31:52 --> Config Class Initialized
INFO - 2020-09-10 19:31:52 --> Loader Class Initialized
INFO - 2020-09-10 19:31:52 --> Helper loaded: url_helper
INFO - 2020-09-10 19:31:52 --> Helper loaded: form_helper
INFO - 2020-09-10 19:31:52 --> Helper loaded: file_helper
INFO - 2020-09-10 19:31:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:31:52 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:31:52 --> Upload Class Initialized
INFO - 2020-09-10 19:31:52 --> Controller Class Initialized
ERROR - 2020-09-10 19:31:52 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:31:54 --> Config Class Initialized
INFO - 2020-09-10 19:31:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:31:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:31:54 --> Utf8 Class Initialized
INFO - 2020-09-10 19:31:54 --> URI Class Initialized
DEBUG - 2020-09-10 19:31:54 --> No URI present. Default controller set.
INFO - 2020-09-10 19:31:54 --> Router Class Initialized
INFO - 2020-09-10 19:31:54 --> Output Class Initialized
INFO - 2020-09-10 19:31:54 --> Security Class Initialized
DEBUG - 2020-09-10 19:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:31:54 --> Input Class Initialized
INFO - 2020-09-10 19:31:54 --> Language Class Initialized
INFO - 2020-09-10 19:31:54 --> Language Class Initialized
INFO - 2020-09-10 19:31:54 --> Config Class Initialized
INFO - 2020-09-10 19:31:54 --> Loader Class Initialized
INFO - 2020-09-10 19:31:54 --> Helper loaded: url_helper
INFO - 2020-09-10 19:31:54 --> Helper loaded: form_helper
INFO - 2020-09-10 19:31:54 --> Helper loaded: file_helper
INFO - 2020-09-10 19:31:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:31:54 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:31:54 --> Upload Class Initialized
INFO - 2020-09-10 19:31:54 --> Controller Class Initialized
DEBUG - 2020-09-10 19:31:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 19:31:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 19:31:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 19:31:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 19:31:54 --> Final output sent to browser
DEBUG - 2020-09-10 19:31:54 --> Total execution time: 0.0496
INFO - 2020-09-10 19:35:40 --> Config Class Initialized
INFO - 2020-09-10 19:35:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:35:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:35:40 --> Utf8 Class Initialized
INFO - 2020-09-10 19:35:40 --> URI Class Initialized
DEBUG - 2020-09-10 19:35:40 --> No URI present. Default controller set.
INFO - 2020-09-10 19:35:40 --> Router Class Initialized
INFO - 2020-09-10 19:35:40 --> Output Class Initialized
INFO - 2020-09-10 19:35:40 --> Security Class Initialized
DEBUG - 2020-09-10 19:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:35:40 --> Input Class Initialized
INFO - 2020-09-10 19:35:40 --> Language Class Initialized
INFO - 2020-09-10 19:35:40 --> Language Class Initialized
INFO - 2020-09-10 19:35:40 --> Config Class Initialized
INFO - 2020-09-10 19:35:40 --> Loader Class Initialized
INFO - 2020-09-10 19:35:40 --> Helper loaded: url_helper
INFO - 2020-09-10 19:35:40 --> Helper loaded: form_helper
INFO - 2020-09-10 19:35:40 --> Helper loaded: file_helper
INFO - 2020-09-10 19:35:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:35:40 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:35:40 --> Upload Class Initialized
INFO - 2020-09-10 19:35:40 --> Controller Class Initialized
DEBUG - 2020-09-10 19:35:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 19:35:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 19:35:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 19:35:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 19:35:40 --> Final output sent to browser
DEBUG - 2020-09-10 19:35:40 --> Total execution time: 0.0466
INFO - 2020-09-10 19:36:41 --> Config Class Initialized
INFO - 2020-09-10 19:36:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:36:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:36:41 --> Utf8 Class Initialized
INFO - 2020-09-10 19:36:41 --> URI Class Initialized
DEBUG - 2020-09-10 19:36:41 --> No URI present. Default controller set.
INFO - 2020-09-10 19:36:41 --> Router Class Initialized
INFO - 2020-09-10 19:36:41 --> Output Class Initialized
INFO - 2020-09-10 19:36:41 --> Security Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:36:41 --> Input Class Initialized
INFO - 2020-09-10 19:36:41 --> Language Class Initialized
INFO - 2020-09-10 19:36:41 --> Language Class Initialized
INFO - 2020-09-10 19:36:41 --> Config Class Initialized
INFO - 2020-09-10 19:36:41 --> Loader Class Initialized
INFO - 2020-09-10 19:36:41 --> Helper loaded: url_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: form_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: file_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:36:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:36:41 --> Upload Class Initialized
INFO - 2020-09-10 19:36:41 --> Controller Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 19:36:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 19:36:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 19:36:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 19:36:41 --> Final output sent to browser
DEBUG - 2020-09-10 19:36:41 --> Total execution time: 0.0519
INFO - 2020-09-10 19:36:41 --> Config Class Initialized
INFO - 2020-09-10 19:36:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:36:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:36:41 --> Utf8 Class Initialized
INFO - 2020-09-10 19:36:41 --> URI Class Initialized
INFO - 2020-09-10 19:36:41 --> Router Class Initialized
INFO - 2020-09-10 19:36:41 --> Output Class Initialized
INFO - 2020-09-10 19:36:41 --> Security Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:36:41 --> Input Class Initialized
INFO - 2020-09-10 19:36:41 --> Language Class Initialized
INFO - 2020-09-10 19:36:41 --> Language Class Initialized
INFO - 2020-09-10 19:36:41 --> Config Class Initialized
INFO - 2020-09-10 19:36:41 --> Loader Class Initialized
INFO - 2020-09-10 19:36:41 --> Helper loaded: url_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: form_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: file_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:36:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:36:41 --> Upload Class Initialized
INFO - 2020-09-10 19:36:41 --> Controller Class Initialized
ERROR - 2020-09-10 19:36:41 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:36:41 --> Config Class Initialized
INFO - 2020-09-10 19:36:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:36:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:36:41 --> Utf8 Class Initialized
INFO - 2020-09-10 19:36:41 --> URI Class Initialized
INFO - 2020-09-10 19:36:41 --> Router Class Initialized
INFO - 2020-09-10 19:36:41 --> Output Class Initialized
INFO - 2020-09-10 19:36:41 --> Security Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:36:41 --> Input Class Initialized
INFO - 2020-09-10 19:36:41 --> Language Class Initialized
INFO - 2020-09-10 19:36:41 --> Language Class Initialized
INFO - 2020-09-10 19:36:41 --> Config Class Initialized
INFO - 2020-09-10 19:36:41 --> Loader Class Initialized
INFO - 2020-09-10 19:36:41 --> Helper loaded: url_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: form_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: file_helper
INFO - 2020-09-10 19:36:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:36:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:36:41 --> Upload Class Initialized
INFO - 2020-09-10 19:36:41 --> Controller Class Initialized
ERROR - 2020-09-10 19:36:41 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:36:42 --> Config Class Initialized
INFO - 2020-09-10 19:36:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:36:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:36:42 --> Utf8 Class Initialized
INFO - 2020-09-10 19:36:42 --> URI Class Initialized
INFO - 2020-09-10 19:36:42 --> Router Class Initialized
INFO - 2020-09-10 19:36:42 --> Output Class Initialized
INFO - 2020-09-10 19:36:42 --> Security Class Initialized
DEBUG - 2020-09-10 19:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:36:42 --> Input Class Initialized
INFO - 2020-09-10 19:36:42 --> Language Class Initialized
INFO - 2020-09-10 19:36:42 --> Language Class Initialized
INFO - 2020-09-10 19:36:42 --> Config Class Initialized
INFO - 2020-09-10 19:36:42 --> Loader Class Initialized
INFO - 2020-09-10 19:36:42 --> Helper loaded: url_helper
INFO - 2020-09-10 19:36:42 --> Helper loaded: form_helper
INFO - 2020-09-10 19:36:42 --> Helper loaded: file_helper
INFO - 2020-09-10 19:36:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:36:42 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:36:42 --> Upload Class Initialized
INFO - 2020-09-10 19:36:42 --> Controller Class Initialized
ERROR - 2020-09-10 19:36:42 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:36:42 --> Config Class Initialized
INFO - 2020-09-10 19:36:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:36:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:36:42 --> Utf8 Class Initialized
INFO - 2020-09-10 19:36:42 --> URI Class Initialized
INFO - 2020-09-10 19:36:42 --> Router Class Initialized
INFO - 2020-09-10 19:36:42 --> Output Class Initialized
INFO - 2020-09-10 19:36:42 --> Security Class Initialized
DEBUG - 2020-09-10 19:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:36:42 --> Input Class Initialized
INFO - 2020-09-10 19:36:42 --> Language Class Initialized
INFO - 2020-09-10 19:36:42 --> Language Class Initialized
INFO - 2020-09-10 19:36:42 --> Config Class Initialized
INFO - 2020-09-10 19:36:42 --> Loader Class Initialized
INFO - 2020-09-10 19:36:42 --> Helper loaded: url_helper
INFO - 2020-09-10 19:36:42 --> Helper loaded: form_helper
INFO - 2020-09-10 19:36:42 --> Helper loaded: file_helper
INFO - 2020-09-10 19:36:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:36:42 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:36:42 --> Upload Class Initialized
INFO - 2020-09-10 19:36:42 --> Controller Class Initialized
ERROR - 2020-09-10 19:36:42 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:36:43 --> Config Class Initialized
INFO - 2020-09-10 19:36:43 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:36:43 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:36:43 --> Utf8 Class Initialized
INFO - 2020-09-10 19:36:43 --> URI Class Initialized
INFO - 2020-09-10 19:36:43 --> Router Class Initialized
INFO - 2020-09-10 19:36:43 --> Output Class Initialized
INFO - 2020-09-10 19:36:43 --> Security Class Initialized
DEBUG - 2020-09-10 19:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:36:43 --> Input Class Initialized
INFO - 2020-09-10 19:36:43 --> Language Class Initialized
INFO - 2020-09-10 19:36:43 --> Language Class Initialized
INFO - 2020-09-10 19:36:43 --> Config Class Initialized
INFO - 2020-09-10 19:36:43 --> Loader Class Initialized
INFO - 2020-09-10 19:36:43 --> Helper loaded: url_helper
INFO - 2020-09-10 19:36:43 --> Helper loaded: form_helper
INFO - 2020-09-10 19:36:43 --> Helper loaded: file_helper
INFO - 2020-09-10 19:36:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:36:43 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:36:43 --> Upload Class Initialized
INFO - 2020-09-10 19:36:44 --> Controller Class Initialized
ERROR - 2020-09-10 19:36:44 --> 404 Page Not Found: /index
INFO - 2020-09-10 19:51:30 --> Config Class Initialized
INFO - 2020-09-10 19:51:30 --> Hooks Class Initialized
DEBUG - 2020-09-10 19:51:30 --> UTF-8 Support Enabled
INFO - 2020-09-10 19:51:30 --> Utf8 Class Initialized
INFO - 2020-09-10 19:51:30 --> URI Class Initialized
DEBUG - 2020-09-10 19:51:30 --> No URI present. Default controller set.
INFO - 2020-09-10 19:51:30 --> Router Class Initialized
INFO - 2020-09-10 19:51:30 --> Output Class Initialized
INFO - 2020-09-10 19:51:30 --> Security Class Initialized
DEBUG - 2020-09-10 19:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 19:51:30 --> Input Class Initialized
INFO - 2020-09-10 19:51:30 --> Language Class Initialized
INFO - 2020-09-10 19:51:30 --> Language Class Initialized
INFO - 2020-09-10 19:51:30 --> Config Class Initialized
INFO - 2020-09-10 19:51:30 --> Loader Class Initialized
INFO - 2020-09-10 19:51:30 --> Helper loaded: url_helper
INFO - 2020-09-10 19:51:30 --> Helper loaded: form_helper
INFO - 2020-09-10 19:51:30 --> Helper loaded: file_helper
INFO - 2020-09-10 19:51:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 19:51:30 --> Database Driver Class Initialized
DEBUG - 2020-09-10 19:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 19:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 19:51:30 --> Upload Class Initialized
INFO - 2020-09-10 19:51:30 --> Controller Class Initialized
DEBUG - 2020-09-10 19:51:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 19:51:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 19:51:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 19:51:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 19:51:30 --> Final output sent to browser
DEBUG - 2020-09-10 19:51:30 --> Total execution time: 0.0685
INFO - 2020-09-10 20:30:50 --> Config Class Initialized
INFO - 2020-09-10 20:30:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 20:30:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 20:30:50 --> Utf8 Class Initialized
INFO - 2020-09-10 20:30:50 --> URI Class Initialized
DEBUG - 2020-09-10 20:30:50 --> No URI present. Default controller set.
INFO - 2020-09-10 20:30:50 --> Router Class Initialized
INFO - 2020-09-10 20:30:50 --> Output Class Initialized
INFO - 2020-09-10 20:30:50 --> Security Class Initialized
DEBUG - 2020-09-10 20:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 20:30:50 --> Input Class Initialized
INFO - 2020-09-10 20:30:50 --> Language Class Initialized
INFO - 2020-09-10 20:30:50 --> Language Class Initialized
INFO - 2020-09-10 20:30:50 --> Config Class Initialized
INFO - 2020-09-10 20:30:50 --> Loader Class Initialized
INFO - 2020-09-10 20:30:50 --> Helper loaded: url_helper
INFO - 2020-09-10 20:30:50 --> Helper loaded: form_helper
INFO - 2020-09-10 20:30:50 --> Helper loaded: file_helper
INFO - 2020-09-10 20:30:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 20:30:50 --> Database Driver Class Initialized
DEBUG - 2020-09-10 20:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 20:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 20:30:50 --> Upload Class Initialized
INFO - 2020-09-10 20:30:50 --> Controller Class Initialized
DEBUG - 2020-09-10 20:30:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 20:30:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 20:30:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 20:30:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 20:30:50 --> Final output sent to browser
DEBUG - 2020-09-10 20:30:50 --> Total execution time: 0.0520
INFO - 2020-09-10 20:30:51 --> Config Class Initialized
INFO - 2020-09-10 20:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 20:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 20:30:51 --> Utf8 Class Initialized
INFO - 2020-09-10 20:30:51 --> URI Class Initialized
INFO - 2020-09-10 20:30:51 --> Router Class Initialized
INFO - 2020-09-10 20:30:51 --> Output Class Initialized
INFO - 2020-09-10 20:30:51 --> Security Class Initialized
DEBUG - 2020-09-10 20:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 20:30:51 --> Input Class Initialized
INFO - 2020-09-10 20:30:51 --> Language Class Initialized
INFO - 2020-09-10 20:30:51 --> Language Class Initialized
INFO - 2020-09-10 20:30:51 --> Config Class Initialized
INFO - 2020-09-10 20:30:51 --> Loader Class Initialized
INFO - 2020-09-10 20:30:51 --> Helper loaded: url_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: form_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: file_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 20:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 20:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 20:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 20:30:51 --> Upload Class Initialized
INFO - 2020-09-10 20:30:51 --> Controller Class Initialized
ERROR - 2020-09-10 20:30:51 --> 404 Page Not Found: /index
INFO - 2020-09-10 20:30:51 --> Config Class Initialized
INFO - 2020-09-10 20:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 20:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 20:30:51 --> Utf8 Class Initialized
INFO - 2020-09-10 20:30:51 --> URI Class Initialized
INFO - 2020-09-10 20:30:51 --> Router Class Initialized
INFO - 2020-09-10 20:30:51 --> Output Class Initialized
INFO - 2020-09-10 20:30:51 --> Security Class Initialized
DEBUG - 2020-09-10 20:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 20:30:51 --> Input Class Initialized
INFO - 2020-09-10 20:30:51 --> Language Class Initialized
INFO - 2020-09-10 20:30:51 --> Language Class Initialized
INFO - 2020-09-10 20:30:51 --> Config Class Initialized
INFO - 2020-09-10 20:30:51 --> Loader Class Initialized
INFO - 2020-09-10 20:30:51 --> Helper loaded: url_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: form_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: file_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 20:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 20:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 20:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 20:30:51 --> Upload Class Initialized
INFO - 2020-09-10 20:30:51 --> Controller Class Initialized
ERROR - 2020-09-10 20:30:51 --> 404 Page Not Found: /index
INFO - 2020-09-10 20:30:51 --> Config Class Initialized
INFO - 2020-09-10 20:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 20:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 20:30:51 --> Utf8 Class Initialized
INFO - 2020-09-10 20:30:51 --> URI Class Initialized
INFO - 2020-09-10 20:30:51 --> Router Class Initialized
INFO - 2020-09-10 20:30:51 --> Output Class Initialized
INFO - 2020-09-10 20:30:51 --> Security Class Initialized
DEBUG - 2020-09-10 20:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 20:30:51 --> Input Class Initialized
INFO - 2020-09-10 20:30:51 --> Language Class Initialized
INFO - 2020-09-10 20:30:51 --> Language Class Initialized
INFO - 2020-09-10 20:30:51 --> Config Class Initialized
INFO - 2020-09-10 20:30:51 --> Loader Class Initialized
INFO - 2020-09-10 20:30:51 --> Helper loaded: url_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: form_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: file_helper
INFO - 2020-09-10 20:30:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 20:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-10 20:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 20:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 20:30:51 --> Upload Class Initialized
INFO - 2020-09-10 20:30:51 --> Controller Class Initialized
ERROR - 2020-09-10 20:30:51 --> 404 Page Not Found: /index
INFO - 2020-09-10 20:30:53 --> Config Class Initialized
INFO - 2020-09-10 20:30:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 20:30:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 20:30:53 --> Utf8 Class Initialized
INFO - 2020-09-10 20:30:53 --> URI Class Initialized
INFO - 2020-09-10 20:30:53 --> Router Class Initialized
INFO - 2020-09-10 20:30:53 --> Output Class Initialized
INFO - 2020-09-10 20:30:53 --> Security Class Initialized
DEBUG - 2020-09-10 20:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 20:30:53 --> Input Class Initialized
INFO - 2020-09-10 20:30:53 --> Language Class Initialized
INFO - 2020-09-10 20:30:53 --> Language Class Initialized
INFO - 2020-09-10 20:30:53 --> Config Class Initialized
INFO - 2020-09-10 20:30:53 --> Loader Class Initialized
INFO - 2020-09-10 20:30:53 --> Helper loaded: url_helper
INFO - 2020-09-10 20:30:53 --> Helper loaded: form_helper
INFO - 2020-09-10 20:30:53 --> Helper loaded: file_helper
INFO - 2020-09-10 20:30:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 20:30:53 --> Database Driver Class Initialized
DEBUG - 2020-09-10 20:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 20:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 20:30:53 --> Upload Class Initialized
INFO - 2020-09-10 20:30:53 --> Controller Class Initialized
ERROR - 2020-09-10 20:30:53 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:11:58 --> Config Class Initialized
INFO - 2020-09-10 21:11:58 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:11:58 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:11:58 --> Utf8 Class Initialized
INFO - 2020-09-10 21:11:58 --> URI Class Initialized
DEBUG - 2020-09-10 21:11:58 --> No URI present. Default controller set.
INFO - 2020-09-10 21:11:58 --> Router Class Initialized
INFO - 2020-09-10 21:11:58 --> Output Class Initialized
INFO - 2020-09-10 21:11:58 --> Security Class Initialized
DEBUG - 2020-09-10 21:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:11:58 --> Input Class Initialized
INFO - 2020-09-10 21:11:58 --> Language Class Initialized
INFO - 2020-09-10 21:11:58 --> Language Class Initialized
INFO - 2020-09-10 21:11:58 --> Config Class Initialized
INFO - 2020-09-10 21:11:58 --> Loader Class Initialized
INFO - 2020-09-10 21:11:58 --> Helper loaded: url_helper
INFO - 2020-09-10 21:11:58 --> Helper loaded: form_helper
INFO - 2020-09-10 21:11:58 --> Helper loaded: file_helper
INFO - 2020-09-10 21:11:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:11:58 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:11:58 --> Upload Class Initialized
INFO - 2020-09-10 21:11:58 --> Controller Class Initialized
DEBUG - 2020-09-10 21:11:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 21:11:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 21:11:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 21:11:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 21:11:58 --> Final output sent to browser
DEBUG - 2020-09-10 21:11:58 --> Total execution time: 0.0599
INFO - 2020-09-10 21:16:23 --> Config Class Initialized
INFO - 2020-09-10 21:16:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:16:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:16:23 --> Utf8 Class Initialized
INFO - 2020-09-10 21:16:23 --> URI Class Initialized
INFO - 2020-09-10 21:16:23 --> Router Class Initialized
INFO - 2020-09-10 21:16:23 --> Output Class Initialized
INFO - 2020-09-10 21:16:23 --> Security Class Initialized
DEBUG - 2020-09-10 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:16:23 --> Input Class Initialized
INFO - 2020-09-10 21:16:23 --> Language Class Initialized
INFO - 2020-09-10 21:16:23 --> Language Class Initialized
INFO - 2020-09-10 21:16:23 --> Config Class Initialized
INFO - 2020-09-10 21:16:23 --> Loader Class Initialized
INFO - 2020-09-10 21:16:23 --> Helper loaded: url_helper
INFO - 2020-09-10 21:16:23 --> Helper loaded: form_helper
INFO - 2020-09-10 21:16:23 --> Helper loaded: file_helper
INFO - 2020-09-10 21:16:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:16:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:16:23 --> Upload Class Initialized
INFO - 2020-09-10 21:16:23 --> Controller Class Initialized
ERROR - 2020-09-10 21:16:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:16:23 --> Config Class Initialized
INFO - 2020-09-10 21:16:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:16:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:16:23 --> Utf8 Class Initialized
INFO - 2020-09-10 21:16:23 --> URI Class Initialized
INFO - 2020-09-10 21:16:23 --> Router Class Initialized
INFO - 2020-09-10 21:16:23 --> Output Class Initialized
INFO - 2020-09-10 21:16:23 --> Security Class Initialized
DEBUG - 2020-09-10 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:16:23 --> Input Class Initialized
INFO - 2020-09-10 21:16:23 --> Language Class Initialized
INFO - 2020-09-10 21:16:23 --> Language Class Initialized
INFO - 2020-09-10 21:16:23 --> Config Class Initialized
INFO - 2020-09-10 21:16:23 --> Loader Class Initialized
INFO - 2020-09-10 21:16:23 --> Helper loaded: url_helper
INFO - 2020-09-10 21:16:23 --> Helper loaded: form_helper
INFO - 2020-09-10 21:16:23 --> Helper loaded: file_helper
INFO - 2020-09-10 21:16:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:16:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:16:23 --> Upload Class Initialized
INFO - 2020-09-10 21:16:23 --> Controller Class Initialized
ERROR - 2020-09-10 21:16:23 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:23:12 --> Config Class Initialized
INFO - 2020-09-10 21:23:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:23:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:23:12 --> Utf8 Class Initialized
INFO - 2020-09-10 21:23:12 --> URI Class Initialized
INFO - 2020-09-10 21:23:12 --> Router Class Initialized
INFO - 2020-09-10 21:23:12 --> Output Class Initialized
INFO - 2020-09-10 21:23:12 --> Security Class Initialized
DEBUG - 2020-09-10 21:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:23:12 --> Input Class Initialized
INFO - 2020-09-10 21:23:12 --> Language Class Initialized
INFO - 2020-09-10 21:23:12 --> Language Class Initialized
INFO - 2020-09-10 21:23:12 --> Config Class Initialized
INFO - 2020-09-10 21:23:12 --> Loader Class Initialized
INFO - 2020-09-10 21:23:12 --> Helper loaded: url_helper
INFO - 2020-09-10 21:23:12 --> Helper loaded: form_helper
INFO - 2020-09-10 21:23:12 --> Helper loaded: file_helper
INFO - 2020-09-10 21:23:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:23:12 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:23:12 --> Upload Class Initialized
INFO - 2020-09-10 21:23:12 --> Controller Class Initialized
ERROR - 2020-09-10 21:23:12 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:31:52 --> Config Class Initialized
INFO - 2020-09-10 21:31:52 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:31:52 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:31:52 --> Utf8 Class Initialized
INFO - 2020-09-10 21:31:52 --> URI Class Initialized
DEBUG - 2020-09-10 21:31:52 --> No URI present. Default controller set.
INFO - 2020-09-10 21:31:52 --> Router Class Initialized
INFO - 2020-09-10 21:31:52 --> Output Class Initialized
INFO - 2020-09-10 21:31:52 --> Security Class Initialized
DEBUG - 2020-09-10 21:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:31:52 --> Input Class Initialized
INFO - 2020-09-10 21:31:52 --> Language Class Initialized
INFO - 2020-09-10 21:31:52 --> Language Class Initialized
INFO - 2020-09-10 21:31:52 --> Config Class Initialized
INFO - 2020-09-10 21:31:52 --> Loader Class Initialized
INFO - 2020-09-10 21:31:52 --> Helper loaded: url_helper
INFO - 2020-09-10 21:31:52 --> Helper loaded: form_helper
INFO - 2020-09-10 21:31:52 --> Helper loaded: file_helper
INFO - 2020-09-10 21:31:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:31:52 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:31:52 --> Upload Class Initialized
INFO - 2020-09-10 21:31:52 --> Controller Class Initialized
DEBUG - 2020-09-10 21:31:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 21:31:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 21:31:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 21:31:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 21:31:52 --> Final output sent to browser
DEBUG - 2020-09-10 21:31:52 --> Total execution time: 0.0566
INFO - 2020-09-10 21:31:53 --> Config Class Initialized
INFO - 2020-09-10 21:31:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:31:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:31:53 --> Utf8 Class Initialized
INFO - 2020-09-10 21:31:53 --> URI Class Initialized
INFO - 2020-09-10 21:31:53 --> Router Class Initialized
INFO - 2020-09-10 21:31:53 --> Output Class Initialized
INFO - 2020-09-10 21:31:53 --> Security Class Initialized
DEBUG - 2020-09-10 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:31:53 --> Input Class Initialized
INFO - 2020-09-10 21:31:53 --> Language Class Initialized
INFO - 2020-09-10 21:31:53 --> Language Class Initialized
INFO - 2020-09-10 21:31:53 --> Config Class Initialized
INFO - 2020-09-10 21:31:53 --> Loader Class Initialized
INFO - 2020-09-10 21:31:53 --> Helper loaded: url_helper
INFO - 2020-09-10 21:31:53 --> Helper loaded: form_helper
INFO - 2020-09-10 21:31:53 --> Helper loaded: file_helper
INFO - 2020-09-10 21:31:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:31:53 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:31:53 --> Upload Class Initialized
INFO - 2020-09-10 21:31:53 --> Controller Class Initialized
ERROR - 2020-09-10 21:31:53 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:31:54 --> Config Class Initialized
INFO - 2020-09-10 21:31:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:31:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:31:54 --> Utf8 Class Initialized
INFO - 2020-09-10 21:31:54 --> URI Class Initialized
INFO - 2020-09-10 21:31:54 --> Router Class Initialized
INFO - 2020-09-10 21:31:54 --> Output Class Initialized
INFO - 2020-09-10 21:31:54 --> Security Class Initialized
DEBUG - 2020-09-10 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:31:54 --> Input Class Initialized
INFO - 2020-09-10 21:31:54 --> Language Class Initialized
INFO - 2020-09-10 21:31:54 --> Language Class Initialized
INFO - 2020-09-10 21:31:54 --> Config Class Initialized
INFO - 2020-09-10 21:31:54 --> Loader Class Initialized
INFO - 2020-09-10 21:31:54 --> Helper loaded: url_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: form_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: file_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:31:54 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:31:54 --> Upload Class Initialized
INFO - 2020-09-10 21:31:54 --> Controller Class Initialized
ERROR - 2020-09-10 21:31:54 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:31:54 --> Config Class Initialized
INFO - 2020-09-10 21:31:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:31:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:31:54 --> Utf8 Class Initialized
INFO - 2020-09-10 21:31:54 --> URI Class Initialized
INFO - 2020-09-10 21:31:54 --> Router Class Initialized
INFO - 2020-09-10 21:31:54 --> Output Class Initialized
INFO - 2020-09-10 21:31:54 --> Security Class Initialized
DEBUG - 2020-09-10 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:31:54 --> Input Class Initialized
INFO - 2020-09-10 21:31:54 --> Language Class Initialized
INFO - 2020-09-10 21:31:54 --> Language Class Initialized
INFO - 2020-09-10 21:31:54 --> Config Class Initialized
INFO - 2020-09-10 21:31:54 --> Loader Class Initialized
INFO - 2020-09-10 21:31:54 --> Helper loaded: url_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: form_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: file_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:31:54 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:31:54 --> Upload Class Initialized
INFO - 2020-09-10 21:31:54 --> Controller Class Initialized
ERROR - 2020-09-10 21:31:54 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:31:54 --> Config Class Initialized
INFO - 2020-09-10 21:31:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:31:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:31:54 --> Utf8 Class Initialized
INFO - 2020-09-10 21:31:54 --> URI Class Initialized
INFO - 2020-09-10 21:31:54 --> Router Class Initialized
INFO - 2020-09-10 21:31:54 --> Output Class Initialized
INFO - 2020-09-10 21:31:54 --> Security Class Initialized
DEBUG - 2020-09-10 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:31:54 --> Input Class Initialized
INFO - 2020-09-10 21:31:54 --> Language Class Initialized
INFO - 2020-09-10 21:31:54 --> Language Class Initialized
INFO - 2020-09-10 21:31:54 --> Config Class Initialized
INFO - 2020-09-10 21:31:54 --> Loader Class Initialized
INFO - 2020-09-10 21:31:54 --> Helper loaded: url_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: form_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: file_helper
INFO - 2020-09-10 21:31:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:31:54 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:31:54 --> Upload Class Initialized
INFO - 2020-09-10 21:31:54 --> Controller Class Initialized
ERROR - 2020-09-10 21:31:54 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:31:57 --> Config Class Initialized
INFO - 2020-09-10 21:31:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:31:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:31:57 --> Utf8 Class Initialized
INFO - 2020-09-10 21:31:57 --> URI Class Initialized
INFO - 2020-09-10 21:31:57 --> Router Class Initialized
INFO - 2020-09-10 21:31:57 --> Output Class Initialized
INFO - 2020-09-10 21:31:57 --> Security Class Initialized
DEBUG - 2020-09-10 21:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:31:57 --> Input Class Initialized
INFO - 2020-09-10 21:31:57 --> Language Class Initialized
INFO - 2020-09-10 21:31:57 --> Language Class Initialized
INFO - 2020-09-10 21:31:57 --> Config Class Initialized
INFO - 2020-09-10 21:31:57 --> Loader Class Initialized
INFO - 2020-09-10 21:31:57 --> Helper loaded: url_helper
INFO - 2020-09-10 21:31:57 --> Helper loaded: form_helper
INFO - 2020-09-10 21:31:57 --> Helper loaded: file_helper
INFO - 2020-09-10 21:31:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:31:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:31:57 --> Upload Class Initialized
INFO - 2020-09-10 21:31:57 --> Controller Class Initialized
ERROR - 2020-09-10 21:31:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:35:16 --> Config Class Initialized
INFO - 2020-09-10 21:35:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:35:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:35:16 --> Utf8 Class Initialized
INFO - 2020-09-10 21:35:16 --> URI Class Initialized
INFO - 2020-09-10 21:35:16 --> Router Class Initialized
INFO - 2020-09-10 21:35:16 --> Output Class Initialized
INFO - 2020-09-10 21:35:17 --> Security Class Initialized
DEBUG - 2020-09-10 21:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:35:17 --> Input Class Initialized
INFO - 2020-09-10 21:35:17 --> Language Class Initialized
INFO - 2020-09-10 21:35:17 --> Language Class Initialized
INFO - 2020-09-10 21:35:17 --> Config Class Initialized
INFO - 2020-09-10 21:35:17 --> Loader Class Initialized
INFO - 2020-09-10 21:35:17 --> Helper loaded: url_helper
INFO - 2020-09-10 21:35:17 --> Helper loaded: form_helper
INFO - 2020-09-10 21:35:17 --> Helper loaded: file_helper
INFO - 2020-09-10 21:35:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:35:17 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:35:17 --> Upload Class Initialized
INFO - 2020-09-10 21:35:17 --> Controller Class Initialized
ERROR - 2020-09-10 21:35:17 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:35:32 --> Config Class Initialized
INFO - 2020-09-10 21:35:32 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:35:32 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:35:32 --> Utf8 Class Initialized
INFO - 2020-09-10 21:35:32 --> URI Class Initialized
DEBUG - 2020-09-10 21:35:32 --> No URI present. Default controller set.
INFO - 2020-09-10 21:35:32 --> Router Class Initialized
INFO - 2020-09-10 21:35:32 --> Output Class Initialized
INFO - 2020-09-10 21:35:32 --> Security Class Initialized
DEBUG - 2020-09-10 21:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:35:32 --> Input Class Initialized
INFO - 2020-09-10 21:35:32 --> Language Class Initialized
INFO - 2020-09-10 21:35:32 --> Language Class Initialized
INFO - 2020-09-10 21:35:32 --> Config Class Initialized
INFO - 2020-09-10 21:35:32 --> Loader Class Initialized
INFO - 2020-09-10 21:35:32 --> Helper loaded: url_helper
INFO - 2020-09-10 21:35:32 --> Helper loaded: form_helper
INFO - 2020-09-10 21:35:32 --> Helper loaded: file_helper
INFO - 2020-09-10 21:35:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:35:32 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:35:32 --> Upload Class Initialized
INFO - 2020-09-10 21:35:32 --> Controller Class Initialized
DEBUG - 2020-09-10 21:35:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 21:35:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 21:35:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 21:35:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 21:35:32 --> Final output sent to browser
DEBUG - 2020-09-10 21:35:32 --> Total execution time: 0.0692
INFO - 2020-09-10 21:35:34 --> Config Class Initialized
INFO - 2020-09-10 21:35:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:35:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:35:34 --> Utf8 Class Initialized
INFO - 2020-09-10 21:35:34 --> URI Class Initialized
INFO - 2020-09-10 21:35:34 --> Router Class Initialized
INFO - 2020-09-10 21:35:34 --> Output Class Initialized
INFO - 2020-09-10 21:35:34 --> Security Class Initialized
DEBUG - 2020-09-10 21:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:35:34 --> Input Class Initialized
INFO - 2020-09-10 21:35:34 --> Language Class Initialized
INFO - 2020-09-10 21:35:34 --> Language Class Initialized
INFO - 2020-09-10 21:35:34 --> Config Class Initialized
INFO - 2020-09-10 21:35:34 --> Loader Class Initialized
INFO - 2020-09-10 21:35:34 --> Helper loaded: url_helper
INFO - 2020-09-10 21:35:34 --> Helper loaded: form_helper
INFO - 2020-09-10 21:35:34 --> Helper loaded: file_helper
INFO - 2020-09-10 21:35:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:35:34 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:35:34 --> Upload Class Initialized
INFO - 2020-09-10 21:35:34 --> Controller Class Initialized
ERROR - 2020-09-10 21:35:34 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:35:35 --> Config Class Initialized
INFO - 2020-09-10 21:35:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:35:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:35:35 --> Utf8 Class Initialized
INFO - 2020-09-10 21:35:35 --> URI Class Initialized
INFO - 2020-09-10 21:35:35 --> Router Class Initialized
INFO - 2020-09-10 21:35:35 --> Output Class Initialized
INFO - 2020-09-10 21:35:35 --> Security Class Initialized
DEBUG - 2020-09-10 21:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:35:35 --> Input Class Initialized
INFO - 2020-09-10 21:35:35 --> Language Class Initialized
INFO - 2020-09-10 21:35:35 --> Language Class Initialized
INFO - 2020-09-10 21:35:35 --> Config Class Initialized
INFO - 2020-09-10 21:35:35 --> Loader Class Initialized
INFO - 2020-09-10 21:35:35 --> Helper loaded: url_helper
INFO - 2020-09-10 21:35:35 --> Helper loaded: form_helper
INFO - 2020-09-10 21:35:35 --> Helper loaded: file_helper
INFO - 2020-09-10 21:35:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:35:35 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:35:35 --> Upload Class Initialized
INFO - 2020-09-10 21:35:35 --> Controller Class Initialized
ERROR - 2020-09-10 21:35:35 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:35:36 --> Config Class Initialized
INFO - 2020-09-10 21:35:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:35:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:35:36 --> Utf8 Class Initialized
INFO - 2020-09-10 21:35:36 --> URI Class Initialized
INFO - 2020-09-10 21:35:36 --> Router Class Initialized
INFO - 2020-09-10 21:35:36 --> Output Class Initialized
INFO - 2020-09-10 21:35:36 --> Security Class Initialized
DEBUG - 2020-09-10 21:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:35:36 --> Input Class Initialized
INFO - 2020-09-10 21:35:36 --> Language Class Initialized
INFO - 2020-09-10 21:35:36 --> Language Class Initialized
INFO - 2020-09-10 21:35:36 --> Config Class Initialized
INFO - 2020-09-10 21:35:36 --> Loader Class Initialized
INFO - 2020-09-10 21:35:36 --> Helper loaded: url_helper
INFO - 2020-09-10 21:35:36 --> Helper loaded: form_helper
INFO - 2020-09-10 21:35:36 --> Helper loaded: file_helper
INFO - 2020-09-10 21:35:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:35:36 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:35:36 --> Upload Class Initialized
INFO - 2020-09-10 21:35:36 --> Controller Class Initialized
ERROR - 2020-09-10 21:35:36 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:35:36 --> Config Class Initialized
INFO - 2020-09-10 21:35:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:35:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:35:36 --> Utf8 Class Initialized
INFO - 2020-09-10 21:35:36 --> URI Class Initialized
INFO - 2020-09-10 21:35:36 --> Router Class Initialized
INFO - 2020-09-10 21:35:36 --> Output Class Initialized
INFO - 2020-09-10 21:35:36 --> Security Class Initialized
DEBUG - 2020-09-10 21:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:35:36 --> Input Class Initialized
INFO - 2020-09-10 21:35:36 --> Language Class Initialized
INFO - 2020-09-10 21:35:36 --> Language Class Initialized
INFO - 2020-09-10 21:35:36 --> Config Class Initialized
INFO - 2020-09-10 21:35:36 --> Loader Class Initialized
INFO - 2020-09-10 21:35:36 --> Helper loaded: url_helper
INFO - 2020-09-10 21:35:36 --> Helper loaded: form_helper
INFO - 2020-09-10 21:35:36 --> Helper loaded: file_helper
INFO - 2020-09-10 21:35:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:35:36 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:35:36 --> Upload Class Initialized
INFO - 2020-09-10 21:35:36 --> Controller Class Initialized
ERROR - 2020-09-10 21:35:36 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:38:55 --> Config Class Initialized
INFO - 2020-09-10 21:38:55 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:38:55 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:38:55 --> Utf8 Class Initialized
INFO - 2020-09-10 21:38:55 --> URI Class Initialized
DEBUG - 2020-09-10 21:38:55 --> No URI present. Default controller set.
INFO - 2020-09-10 21:38:55 --> Router Class Initialized
INFO - 2020-09-10 21:38:55 --> Output Class Initialized
INFO - 2020-09-10 21:38:55 --> Security Class Initialized
DEBUG - 2020-09-10 21:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:38:55 --> Input Class Initialized
INFO - 2020-09-10 21:38:55 --> Language Class Initialized
INFO - 2020-09-10 21:38:55 --> Language Class Initialized
INFO - 2020-09-10 21:38:55 --> Config Class Initialized
INFO - 2020-09-10 21:38:55 --> Loader Class Initialized
INFO - 2020-09-10 21:38:55 --> Helper loaded: url_helper
INFO - 2020-09-10 21:38:55 --> Helper loaded: form_helper
INFO - 2020-09-10 21:38:55 --> Helper loaded: file_helper
INFO - 2020-09-10 21:38:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:38:55 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:38:55 --> Upload Class Initialized
INFO - 2020-09-10 21:38:55 --> Controller Class Initialized
DEBUG - 2020-09-10 21:38:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 21:38:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 21:38:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 21:38:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 21:38:55 --> Final output sent to browser
DEBUG - 2020-09-10 21:38:55 --> Total execution time: 0.0664
INFO - 2020-09-10 21:38:57 --> Config Class Initialized
INFO - 2020-09-10 21:38:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:38:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:38:57 --> Utf8 Class Initialized
INFO - 2020-09-10 21:38:57 --> URI Class Initialized
INFO - 2020-09-10 21:38:57 --> Router Class Initialized
INFO - 2020-09-10 21:38:57 --> Output Class Initialized
INFO - 2020-09-10 21:38:57 --> Security Class Initialized
DEBUG - 2020-09-10 21:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:38:57 --> Input Class Initialized
INFO - 2020-09-10 21:38:57 --> Language Class Initialized
INFO - 2020-09-10 21:38:57 --> Language Class Initialized
INFO - 2020-09-10 21:38:57 --> Config Class Initialized
INFO - 2020-09-10 21:38:57 --> Loader Class Initialized
INFO - 2020-09-10 21:38:57 --> Helper loaded: url_helper
INFO - 2020-09-10 21:38:57 --> Helper loaded: form_helper
INFO - 2020-09-10 21:38:57 --> Helper loaded: file_helper
INFO - 2020-09-10 21:38:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:38:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:38:57 --> Upload Class Initialized
INFO - 2020-09-10 21:38:57 --> Controller Class Initialized
ERROR - 2020-09-10 21:38:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:38:59 --> Config Class Initialized
INFO - 2020-09-10 21:38:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:38:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:38:59 --> Utf8 Class Initialized
INFO - 2020-09-10 21:38:59 --> URI Class Initialized
INFO - 2020-09-10 21:38:59 --> Router Class Initialized
INFO - 2020-09-10 21:38:59 --> Output Class Initialized
INFO - 2020-09-10 21:38:59 --> Security Class Initialized
DEBUG - 2020-09-10 21:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:38:59 --> Input Class Initialized
INFO - 2020-09-10 21:38:59 --> Language Class Initialized
INFO - 2020-09-10 21:38:59 --> Language Class Initialized
INFO - 2020-09-10 21:38:59 --> Config Class Initialized
INFO - 2020-09-10 21:38:59 --> Loader Class Initialized
INFO - 2020-09-10 21:38:59 --> Helper loaded: url_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: form_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: file_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:38:59 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:38:59 --> Upload Class Initialized
INFO - 2020-09-10 21:38:59 --> Controller Class Initialized
ERROR - 2020-09-10 21:38:59 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:38:59 --> Config Class Initialized
INFO - 2020-09-10 21:38:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:38:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:38:59 --> Utf8 Class Initialized
INFO - 2020-09-10 21:38:59 --> URI Class Initialized
INFO - 2020-09-10 21:38:59 --> Router Class Initialized
INFO - 2020-09-10 21:38:59 --> Output Class Initialized
INFO - 2020-09-10 21:38:59 --> Security Class Initialized
DEBUG - 2020-09-10 21:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:38:59 --> Input Class Initialized
INFO - 2020-09-10 21:38:59 --> Language Class Initialized
INFO - 2020-09-10 21:38:59 --> Language Class Initialized
INFO - 2020-09-10 21:38:59 --> Config Class Initialized
INFO - 2020-09-10 21:38:59 --> Loader Class Initialized
INFO - 2020-09-10 21:38:59 --> Helper loaded: url_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: form_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: file_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:38:59 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:38:59 --> Upload Class Initialized
INFO - 2020-09-10 21:38:59 --> Controller Class Initialized
ERROR - 2020-09-10 21:38:59 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:38:59 --> Config Class Initialized
INFO - 2020-09-10 21:38:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:38:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:38:59 --> Utf8 Class Initialized
INFO - 2020-09-10 21:38:59 --> URI Class Initialized
INFO - 2020-09-10 21:38:59 --> Router Class Initialized
INFO - 2020-09-10 21:38:59 --> Output Class Initialized
INFO - 2020-09-10 21:38:59 --> Security Class Initialized
DEBUG - 2020-09-10 21:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:38:59 --> Input Class Initialized
INFO - 2020-09-10 21:38:59 --> Language Class Initialized
INFO - 2020-09-10 21:38:59 --> Language Class Initialized
INFO - 2020-09-10 21:38:59 --> Config Class Initialized
INFO - 2020-09-10 21:38:59 --> Loader Class Initialized
INFO - 2020-09-10 21:38:59 --> Helper loaded: url_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: form_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: file_helper
INFO - 2020-09-10 21:38:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:38:59 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:38:59 --> Upload Class Initialized
INFO - 2020-09-10 21:38:59 --> Controller Class Initialized
ERROR - 2020-09-10 21:38:59 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:39:02 --> Config Class Initialized
INFO - 2020-09-10 21:39:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:39:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:39:02 --> Utf8 Class Initialized
INFO - 2020-09-10 21:39:02 --> URI Class Initialized
DEBUG - 2020-09-10 21:39:02 --> No URI present. Default controller set.
INFO - 2020-09-10 21:39:02 --> Router Class Initialized
INFO - 2020-09-10 21:39:02 --> Output Class Initialized
INFO - 2020-09-10 21:39:02 --> Security Class Initialized
DEBUG - 2020-09-10 21:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:39:02 --> Input Class Initialized
INFO - 2020-09-10 21:39:02 --> Language Class Initialized
INFO - 2020-09-10 21:39:02 --> Language Class Initialized
INFO - 2020-09-10 21:39:02 --> Config Class Initialized
INFO - 2020-09-10 21:39:02 --> Loader Class Initialized
INFO - 2020-09-10 21:39:02 --> Helper loaded: url_helper
INFO - 2020-09-10 21:39:02 --> Helper loaded: form_helper
INFO - 2020-09-10 21:39:02 --> Helper loaded: file_helper
INFO - 2020-09-10 21:39:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:39:02 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:39:02 --> Upload Class Initialized
INFO - 2020-09-10 21:39:02 --> Controller Class Initialized
DEBUG - 2020-09-10 21:39:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 21:39:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 21:39:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 21:39:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 21:39:02 --> Final output sent to browser
DEBUG - 2020-09-10 21:39:02 --> Total execution time: 0.0435
INFO - 2020-09-10 21:39:04 --> Config Class Initialized
INFO - 2020-09-10 21:39:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:39:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:39:04 --> Utf8 Class Initialized
INFO - 2020-09-10 21:39:04 --> URI Class Initialized
INFO - 2020-09-10 21:39:04 --> Router Class Initialized
INFO - 2020-09-10 21:39:04 --> Output Class Initialized
INFO - 2020-09-10 21:39:04 --> Security Class Initialized
DEBUG - 2020-09-10 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:39:04 --> Input Class Initialized
INFO - 2020-09-10 21:39:04 --> Language Class Initialized
INFO - 2020-09-10 21:39:04 --> Language Class Initialized
INFO - 2020-09-10 21:39:04 --> Config Class Initialized
INFO - 2020-09-10 21:39:04 --> Loader Class Initialized
INFO - 2020-09-10 21:39:04 --> Helper loaded: url_helper
INFO - 2020-09-10 21:39:04 --> Helper loaded: form_helper
INFO - 2020-09-10 21:39:04 --> Helper loaded: file_helper
INFO - 2020-09-10 21:39:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:39:04 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:39:04 --> Upload Class Initialized
INFO - 2020-09-10 21:39:04 --> Controller Class Initialized
ERROR - 2020-09-10 21:39:04 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:39:04 --> Config Class Initialized
INFO - 2020-09-10 21:39:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:39:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:39:04 --> Utf8 Class Initialized
INFO - 2020-09-10 21:39:04 --> URI Class Initialized
INFO - 2020-09-10 21:39:04 --> Router Class Initialized
INFO - 2020-09-10 21:39:04 --> Output Class Initialized
INFO - 2020-09-10 21:39:04 --> Security Class Initialized
DEBUG - 2020-09-10 21:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:39:04 --> Input Class Initialized
INFO - 2020-09-10 21:39:04 --> Language Class Initialized
INFO - 2020-09-10 21:39:04 --> Language Class Initialized
INFO - 2020-09-10 21:39:04 --> Config Class Initialized
INFO - 2020-09-10 21:39:04 --> Loader Class Initialized
INFO - 2020-09-10 21:39:04 --> Helper loaded: url_helper
INFO - 2020-09-10 21:39:04 --> Helper loaded: form_helper
INFO - 2020-09-10 21:39:04 --> Helper loaded: file_helper
INFO - 2020-09-10 21:39:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:39:04 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:39:04 --> Upload Class Initialized
INFO - 2020-09-10 21:39:04 --> Controller Class Initialized
ERROR - 2020-09-10 21:39:04 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:39:05 --> Config Class Initialized
INFO - 2020-09-10 21:39:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:39:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:39:05 --> Utf8 Class Initialized
INFO - 2020-09-10 21:39:05 --> URI Class Initialized
INFO - 2020-09-10 21:39:05 --> Router Class Initialized
INFO - 2020-09-10 21:39:05 --> Output Class Initialized
INFO - 2020-09-10 21:39:05 --> Security Class Initialized
DEBUG - 2020-09-10 21:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:39:05 --> Input Class Initialized
INFO - 2020-09-10 21:39:05 --> Language Class Initialized
INFO - 2020-09-10 21:39:05 --> Language Class Initialized
INFO - 2020-09-10 21:39:05 --> Config Class Initialized
INFO - 2020-09-10 21:39:05 --> Loader Class Initialized
INFO - 2020-09-10 21:39:05 --> Helper loaded: url_helper
INFO - 2020-09-10 21:39:05 --> Helper loaded: form_helper
INFO - 2020-09-10 21:39:05 --> Helper loaded: file_helper
INFO - 2020-09-10 21:39:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:39:05 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:39:05 --> Upload Class Initialized
INFO - 2020-09-10 21:39:05 --> Controller Class Initialized
ERROR - 2020-09-10 21:39:05 --> 404 Page Not Found: /index
INFO - 2020-09-10 21:39:08 --> Config Class Initialized
INFO - 2020-09-10 21:39:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 21:39:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 21:39:08 --> Utf8 Class Initialized
INFO - 2020-09-10 21:39:08 --> URI Class Initialized
INFO - 2020-09-10 21:39:08 --> Router Class Initialized
INFO - 2020-09-10 21:39:08 --> Output Class Initialized
INFO - 2020-09-10 21:39:08 --> Security Class Initialized
DEBUG - 2020-09-10 21:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 21:39:08 --> Input Class Initialized
INFO - 2020-09-10 21:39:08 --> Language Class Initialized
INFO - 2020-09-10 21:39:08 --> Language Class Initialized
INFO - 2020-09-10 21:39:08 --> Config Class Initialized
INFO - 2020-09-10 21:39:08 --> Loader Class Initialized
INFO - 2020-09-10 21:39:08 --> Helper loaded: url_helper
INFO - 2020-09-10 21:39:08 --> Helper loaded: form_helper
INFO - 2020-09-10 21:39:08 --> Helper loaded: file_helper
INFO - 2020-09-10 21:39:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 21:39:08 --> Database Driver Class Initialized
DEBUG - 2020-09-10 21:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 21:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 21:39:08 --> Upload Class Initialized
INFO - 2020-09-10 21:39:08 --> Controller Class Initialized
ERROR - 2020-09-10 21:39:08 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:00:31 --> Config Class Initialized
INFO - 2020-09-10 22:00:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:00:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:00:31 --> Utf8 Class Initialized
INFO - 2020-09-10 22:00:31 --> URI Class Initialized
INFO - 2020-09-10 22:00:31 --> Router Class Initialized
INFO - 2020-09-10 22:00:31 --> Output Class Initialized
INFO - 2020-09-10 22:00:31 --> Security Class Initialized
DEBUG - 2020-09-10 22:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:00:31 --> Input Class Initialized
INFO - 2020-09-10 22:00:31 --> Language Class Initialized
INFO - 2020-09-10 22:00:31 --> Language Class Initialized
INFO - 2020-09-10 22:00:31 --> Config Class Initialized
INFO - 2020-09-10 22:00:31 --> Loader Class Initialized
INFO - 2020-09-10 22:00:31 --> Helper loaded: url_helper
INFO - 2020-09-10 22:00:31 --> Helper loaded: form_helper
INFO - 2020-09-10 22:00:31 --> Helper loaded: file_helper
INFO - 2020-09-10 22:00:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:00:31 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:00:31 --> Upload Class Initialized
INFO - 2020-09-10 22:00:31 --> Controller Class Initialized
ERROR - 2020-09-10 22:00:31 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:08:10 --> Config Class Initialized
INFO - 2020-09-10 22:08:10 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:08:10 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:08:10 --> Utf8 Class Initialized
INFO - 2020-09-10 22:08:10 --> URI Class Initialized
DEBUG - 2020-09-10 22:08:10 --> No URI present. Default controller set.
INFO - 2020-09-10 22:08:10 --> Router Class Initialized
INFO - 2020-09-10 22:08:10 --> Output Class Initialized
INFO - 2020-09-10 22:08:10 --> Security Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:08:10 --> Input Class Initialized
INFO - 2020-09-10 22:08:10 --> Language Class Initialized
INFO - 2020-09-10 22:08:10 --> Language Class Initialized
INFO - 2020-09-10 22:08:10 --> Config Class Initialized
INFO - 2020-09-10 22:08:10 --> Loader Class Initialized
INFO - 2020-09-10 22:08:10 --> Helper loaded: url_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: form_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: file_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:08:10 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:08:10 --> Upload Class Initialized
INFO - 2020-09-10 22:08:10 --> Controller Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 22:08:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 22:08:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 22:08:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 22:08:10 --> Final output sent to browser
DEBUG - 2020-09-10 22:08:10 --> Total execution time: 0.0772
INFO - 2020-09-10 22:08:10 --> Config Class Initialized
INFO - 2020-09-10 22:08:10 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:08:10 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:08:10 --> Utf8 Class Initialized
INFO - 2020-09-10 22:08:10 --> URI Class Initialized
INFO - 2020-09-10 22:08:10 --> Router Class Initialized
INFO - 2020-09-10 22:08:10 --> Output Class Initialized
INFO - 2020-09-10 22:08:10 --> Security Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:08:10 --> Input Class Initialized
INFO - 2020-09-10 22:08:10 --> Language Class Initialized
INFO - 2020-09-10 22:08:10 --> Language Class Initialized
INFO - 2020-09-10 22:08:10 --> Config Class Initialized
INFO - 2020-09-10 22:08:10 --> Loader Class Initialized
INFO - 2020-09-10 22:08:10 --> Helper loaded: url_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: form_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: file_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:08:10 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:08:10 --> Upload Class Initialized
INFO - 2020-09-10 22:08:10 --> Controller Class Initialized
ERROR - 2020-09-10 22:08:10 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:08:10 --> Config Class Initialized
INFO - 2020-09-10 22:08:10 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:08:10 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:08:10 --> Utf8 Class Initialized
INFO - 2020-09-10 22:08:10 --> URI Class Initialized
INFO - 2020-09-10 22:08:10 --> Router Class Initialized
INFO - 2020-09-10 22:08:10 --> Output Class Initialized
INFO - 2020-09-10 22:08:10 --> Security Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:08:10 --> Input Class Initialized
INFO - 2020-09-10 22:08:10 --> Language Class Initialized
INFO - 2020-09-10 22:08:10 --> Language Class Initialized
INFO - 2020-09-10 22:08:10 --> Config Class Initialized
INFO - 2020-09-10 22:08:10 --> Loader Class Initialized
INFO - 2020-09-10 22:08:10 --> Helper loaded: url_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: form_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: file_helper
INFO - 2020-09-10 22:08:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:08:10 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:08:10 --> Upload Class Initialized
INFO - 2020-09-10 22:08:11 --> Controller Class Initialized
ERROR - 2020-09-10 22:08:11 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:08:11 --> Config Class Initialized
INFO - 2020-09-10 22:08:11 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:08:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:08:11 --> Utf8 Class Initialized
INFO - 2020-09-10 22:08:11 --> URI Class Initialized
INFO - 2020-09-10 22:08:11 --> Config Class Initialized
INFO - 2020-09-10 22:08:11 --> Hooks Class Initialized
INFO - 2020-09-10 22:08:11 --> Router Class Initialized
DEBUG - 2020-09-10 22:08:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:08:11 --> Utf8 Class Initialized
INFO - 2020-09-10 22:08:11 --> Output Class Initialized
INFO - 2020-09-10 22:08:11 --> URI Class Initialized
INFO - 2020-09-10 22:08:11 --> Security Class Initialized
DEBUG - 2020-09-10 22:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:08:11 --> Input Class Initialized
INFO - 2020-09-10 22:08:11 --> Language Class Initialized
INFO - 2020-09-10 22:08:11 --> Language Class Initialized
INFO - 2020-09-10 22:08:11 --> Config Class Initialized
INFO - 2020-09-10 22:08:11 --> Router Class Initialized
INFO - 2020-09-10 22:08:11 --> Loader Class Initialized
INFO - 2020-09-10 22:08:11 --> Output Class Initialized
INFO - 2020-09-10 22:08:11 --> Helper loaded: url_helper
INFO - 2020-09-10 22:08:11 --> Helper loaded: form_helper
INFO - 2020-09-10 22:08:11 --> Security Class Initialized
INFO - 2020-09-10 22:08:11 --> Helper loaded: file_helper
DEBUG - 2020-09-10 22:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:08:11 --> Input Class Initialized
INFO - 2020-09-10 22:08:11 --> Language Class Initialized
INFO - 2020-09-10 22:08:11 --> Language Class Initialized
INFO - 2020-09-10 22:08:11 --> Config Class Initialized
INFO - 2020-09-10 22:08:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:08:11 --> Loader Class Initialized
INFO - 2020-09-10 22:08:11 --> Helper loaded: url_helper
INFO - 2020-09-10 22:08:11 --> Helper loaded: form_helper
INFO - 2020-09-10 22:08:11 --> Helper loaded: file_helper
INFO - 2020-09-10 22:08:11 --> Database Driver Class Initialized
INFO - 2020-09-10 22:08:11 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-10 22:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:08:11 --> Upload Class Initialized
INFO - 2020-09-10 22:08:11 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:08:11 --> Controller Class Initialized
ERROR - 2020-09-10 22:08:11 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:08:11 --> Upload Class Initialized
INFO - 2020-09-10 22:08:11 --> Controller Class Initialized
ERROR - 2020-09-10 22:08:11 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:43:56 --> Config Class Initialized
INFO - 2020-09-10 22:43:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:43:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:43:56 --> Utf8 Class Initialized
INFO - 2020-09-10 22:43:56 --> URI Class Initialized
DEBUG - 2020-09-10 22:43:56 --> No URI present. Default controller set.
INFO - 2020-09-10 22:43:56 --> Router Class Initialized
INFO - 2020-09-10 22:43:56 --> Output Class Initialized
INFO - 2020-09-10 22:43:56 --> Security Class Initialized
DEBUG - 2020-09-10 22:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:43:56 --> Input Class Initialized
INFO - 2020-09-10 22:43:56 --> Language Class Initialized
INFO - 2020-09-10 22:43:56 --> Language Class Initialized
INFO - 2020-09-10 22:43:56 --> Config Class Initialized
INFO - 2020-09-10 22:43:56 --> Loader Class Initialized
INFO - 2020-09-10 22:43:56 --> Helper loaded: url_helper
INFO - 2020-09-10 22:43:56 --> Helper loaded: form_helper
INFO - 2020-09-10 22:43:56 --> Helper loaded: file_helper
INFO - 2020-09-10 22:43:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:43:56 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:43:56 --> Upload Class Initialized
INFO - 2020-09-10 22:43:56 --> Controller Class Initialized
DEBUG - 2020-09-10 22:43:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 22:43:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 22:43:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 22:43:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 22:43:56 --> Final output sent to browser
DEBUG - 2020-09-10 22:43:56 --> Total execution time: 0.0508
INFO - 2020-09-10 22:43:57 --> Config Class Initialized
INFO - 2020-09-10 22:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:43:57 --> Utf8 Class Initialized
INFO - 2020-09-10 22:43:57 --> URI Class Initialized
INFO - 2020-09-10 22:43:57 --> Router Class Initialized
INFO - 2020-09-10 22:43:57 --> Output Class Initialized
INFO - 2020-09-10 22:43:57 --> Security Class Initialized
DEBUG - 2020-09-10 22:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:43:57 --> Input Class Initialized
INFO - 2020-09-10 22:43:57 --> Language Class Initialized
INFO - 2020-09-10 22:43:57 --> Language Class Initialized
INFO - 2020-09-10 22:43:57 --> Config Class Initialized
INFO - 2020-09-10 22:43:57 --> Loader Class Initialized
INFO - 2020-09-10 22:43:57 --> Helper loaded: url_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: form_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: file_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:43:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:43:57 --> Upload Class Initialized
INFO - 2020-09-10 22:43:57 --> Controller Class Initialized
ERROR - 2020-09-10 22:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:43:57 --> Config Class Initialized
INFO - 2020-09-10 22:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:43:57 --> Utf8 Class Initialized
INFO - 2020-09-10 22:43:57 --> URI Class Initialized
INFO - 2020-09-10 22:43:57 --> Router Class Initialized
INFO - 2020-09-10 22:43:57 --> Output Class Initialized
INFO - 2020-09-10 22:43:57 --> Security Class Initialized
DEBUG - 2020-09-10 22:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:43:57 --> Input Class Initialized
INFO - 2020-09-10 22:43:57 --> Language Class Initialized
INFO - 2020-09-10 22:43:57 --> Language Class Initialized
INFO - 2020-09-10 22:43:57 --> Config Class Initialized
INFO - 2020-09-10 22:43:57 --> Loader Class Initialized
INFO - 2020-09-10 22:43:57 --> Helper loaded: url_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: form_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: file_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:43:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:43:57 --> Upload Class Initialized
INFO - 2020-09-10 22:43:57 --> Controller Class Initialized
ERROR - 2020-09-10 22:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:43:57 --> Config Class Initialized
INFO - 2020-09-10 22:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:43:57 --> Utf8 Class Initialized
INFO - 2020-09-10 22:43:57 --> URI Class Initialized
INFO - 2020-09-10 22:43:57 --> Router Class Initialized
INFO - 2020-09-10 22:43:57 --> Output Class Initialized
INFO - 2020-09-10 22:43:57 --> Security Class Initialized
DEBUG - 2020-09-10 22:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:43:57 --> Input Class Initialized
INFO - 2020-09-10 22:43:57 --> Language Class Initialized
INFO - 2020-09-10 22:43:57 --> Language Class Initialized
INFO - 2020-09-10 22:43:57 --> Config Class Initialized
INFO - 2020-09-10 22:43:57 --> Loader Class Initialized
INFO - 2020-09-10 22:43:57 --> Helper loaded: url_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: form_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: file_helper
INFO - 2020-09-10 22:43:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:43:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:43:57 --> Upload Class Initialized
INFO - 2020-09-10 22:43:57 --> Controller Class Initialized
ERROR - 2020-09-10 22:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:43:58 --> Config Class Initialized
INFO - 2020-09-10 22:43:58 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:43:58 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:43:58 --> Utf8 Class Initialized
INFO - 2020-09-10 22:43:58 --> URI Class Initialized
INFO - 2020-09-10 22:43:58 --> Router Class Initialized
INFO - 2020-09-10 22:43:58 --> Output Class Initialized
INFO - 2020-09-10 22:43:58 --> Security Class Initialized
DEBUG - 2020-09-10 22:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:43:58 --> Input Class Initialized
INFO - 2020-09-10 22:43:58 --> Language Class Initialized
INFO - 2020-09-10 22:43:58 --> Language Class Initialized
INFO - 2020-09-10 22:43:58 --> Config Class Initialized
INFO - 2020-09-10 22:43:58 --> Loader Class Initialized
INFO - 2020-09-10 22:43:58 --> Helper loaded: url_helper
INFO - 2020-09-10 22:43:58 --> Helper loaded: form_helper
INFO - 2020-09-10 22:43:58 --> Helper loaded: file_helper
INFO - 2020-09-10 22:43:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:43:58 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:43:58 --> Upload Class Initialized
INFO - 2020-09-10 22:43:58 --> Controller Class Initialized
ERROR - 2020-09-10 22:43:58 --> 404 Page Not Found: /index
INFO - 2020-09-10 22:54:18 --> Config Class Initialized
INFO - 2020-09-10 22:54:18 --> Hooks Class Initialized
DEBUG - 2020-09-10 22:54:18 --> UTF-8 Support Enabled
INFO - 2020-09-10 22:54:18 --> Utf8 Class Initialized
INFO - 2020-09-10 22:54:18 --> URI Class Initialized
DEBUG - 2020-09-10 22:54:18 --> No URI present. Default controller set.
INFO - 2020-09-10 22:54:18 --> Router Class Initialized
INFO - 2020-09-10 22:54:18 --> Output Class Initialized
INFO - 2020-09-10 22:54:18 --> Security Class Initialized
DEBUG - 2020-09-10 22:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 22:54:18 --> Input Class Initialized
INFO - 2020-09-10 22:54:18 --> Language Class Initialized
INFO - 2020-09-10 22:54:18 --> Language Class Initialized
INFO - 2020-09-10 22:54:18 --> Config Class Initialized
INFO - 2020-09-10 22:54:18 --> Loader Class Initialized
INFO - 2020-09-10 22:54:18 --> Helper loaded: url_helper
INFO - 2020-09-10 22:54:18 --> Helper loaded: form_helper
INFO - 2020-09-10 22:54:18 --> Helper loaded: file_helper
INFO - 2020-09-10 22:54:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 22:54:18 --> Database Driver Class Initialized
DEBUG - 2020-09-10 22:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 22:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 22:54:18 --> Upload Class Initialized
INFO - 2020-09-10 22:54:18 --> Controller Class Initialized
DEBUG - 2020-09-10 22:54:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 22:54:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 22:54:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 22:54:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 22:54:18 --> Final output sent to browser
DEBUG - 2020-09-10 22:54:18 --> Total execution time: 0.0686
INFO - 2020-09-10 23:25:18 --> Config Class Initialized
INFO - 2020-09-10 23:25:18 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:25:18 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:25:18 --> Utf8 Class Initialized
INFO - 2020-09-10 23:25:18 --> URI Class Initialized
DEBUG - 2020-09-10 23:25:18 --> No URI present. Default controller set.
INFO - 2020-09-10 23:25:18 --> Router Class Initialized
INFO - 2020-09-10 23:25:18 --> Output Class Initialized
INFO - 2020-09-10 23:25:18 --> Security Class Initialized
DEBUG - 2020-09-10 23:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:25:18 --> Input Class Initialized
INFO - 2020-09-10 23:25:18 --> Language Class Initialized
INFO - 2020-09-10 23:25:18 --> Language Class Initialized
INFO - 2020-09-10 23:25:18 --> Config Class Initialized
INFO - 2020-09-10 23:25:18 --> Loader Class Initialized
INFO - 2020-09-10 23:25:18 --> Helper loaded: url_helper
INFO - 2020-09-10 23:25:18 --> Helper loaded: form_helper
INFO - 2020-09-10 23:25:18 --> Helper loaded: file_helper
INFO - 2020-09-10 23:25:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:25:18 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:25:18 --> Upload Class Initialized
INFO - 2020-09-10 23:25:18 --> Controller Class Initialized
DEBUG - 2020-09-10 23:25:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 23:25:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 23:25:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 23:25:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 23:25:18 --> Final output sent to browser
DEBUG - 2020-09-10 23:25:18 --> Total execution time: 0.0418
INFO - 2020-09-10 23:27:06 --> Config Class Initialized
INFO - 2020-09-10 23:27:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:27:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:27:06 --> Utf8 Class Initialized
INFO - 2020-09-10 23:27:06 --> URI Class Initialized
DEBUG - 2020-09-10 23:27:06 --> No URI present. Default controller set.
INFO - 2020-09-10 23:27:06 --> Router Class Initialized
INFO - 2020-09-10 23:27:06 --> Output Class Initialized
INFO - 2020-09-10 23:27:06 --> Security Class Initialized
DEBUG - 2020-09-10 23:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:27:06 --> Input Class Initialized
INFO - 2020-09-10 23:27:06 --> Language Class Initialized
INFO - 2020-09-10 23:27:06 --> Language Class Initialized
INFO - 2020-09-10 23:27:06 --> Config Class Initialized
INFO - 2020-09-10 23:27:06 --> Loader Class Initialized
INFO - 2020-09-10 23:27:06 --> Helper loaded: url_helper
INFO - 2020-09-10 23:27:06 --> Helper loaded: form_helper
INFO - 2020-09-10 23:27:06 --> Helper loaded: file_helper
INFO - 2020-09-10 23:27:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:27:06 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:27:06 --> Upload Class Initialized
INFO - 2020-09-10 23:27:06 --> Controller Class Initialized
DEBUG - 2020-09-10 23:27:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 23:27:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 23:27:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 23:27:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 23:27:06 --> Final output sent to browser
DEBUG - 2020-09-10 23:27:06 --> Total execution time: 0.0419
INFO - 2020-09-10 23:30:23 --> Config Class Initialized
INFO - 2020-09-10 23:30:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:23 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:23 --> URI Class Initialized
DEBUG - 2020-09-10 23:30:23 --> No URI present. Default controller set.
INFO - 2020-09-10 23:30:23 --> Router Class Initialized
INFO - 2020-09-10 23:30:23 --> Output Class Initialized
INFO - 2020-09-10 23:30:23 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:23 --> Input Class Initialized
INFO - 2020-09-10 23:30:23 --> Language Class Initialized
INFO - 2020-09-10 23:30:23 --> Language Class Initialized
INFO - 2020-09-10 23:30:23 --> Config Class Initialized
INFO - 2020-09-10 23:30:23 --> Loader Class Initialized
INFO - 2020-09-10 23:30:23 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:23 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:23 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:23 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:23 --> Upload Class Initialized
INFO - 2020-09-10 23:30:23 --> Controller Class Initialized
DEBUG - 2020-09-10 23:30:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 23:30:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 23:30:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 23:30:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 23:30:23 --> Final output sent to browser
DEBUG - 2020-09-10 23:30:23 --> Total execution time: 0.0621
INFO - 2020-09-10 23:30:24 --> Config Class Initialized
INFO - 2020-09-10 23:30:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:24 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:24 --> URI Class Initialized
INFO - 2020-09-10 23:30:24 --> Router Class Initialized
INFO - 2020-09-10 23:30:24 --> Output Class Initialized
INFO - 2020-09-10 23:30:24 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:24 --> Input Class Initialized
INFO - 2020-09-10 23:30:24 --> Language Class Initialized
INFO - 2020-09-10 23:30:24 --> Language Class Initialized
INFO - 2020-09-10 23:30:24 --> Config Class Initialized
INFO - 2020-09-10 23:30:24 --> Loader Class Initialized
INFO - 2020-09-10 23:30:24 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:24 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:24 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:24 --> Upload Class Initialized
INFO - 2020-09-10 23:30:24 --> Controller Class Initialized
ERROR - 2020-09-10 23:30:24 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:30:24 --> Config Class Initialized
INFO - 2020-09-10 23:30:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:24 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:24 --> URI Class Initialized
INFO - 2020-09-10 23:30:24 --> Router Class Initialized
INFO - 2020-09-10 23:30:24 --> Output Class Initialized
INFO - 2020-09-10 23:30:24 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:24 --> Input Class Initialized
INFO - 2020-09-10 23:30:24 --> Language Class Initialized
INFO - 2020-09-10 23:30:24 --> Language Class Initialized
INFO - 2020-09-10 23:30:24 --> Config Class Initialized
INFO - 2020-09-10 23:30:24 --> Loader Class Initialized
INFO - 2020-09-10 23:30:24 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:24 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:24 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:24 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:24 --> Upload Class Initialized
INFO - 2020-09-10 23:30:24 --> Controller Class Initialized
ERROR - 2020-09-10 23:30:24 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:30:24 --> Config Class Initialized
INFO - 2020-09-10 23:30:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:25 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:25 --> URI Class Initialized
INFO - 2020-09-10 23:30:25 --> Router Class Initialized
INFO - 2020-09-10 23:30:25 --> Output Class Initialized
INFO - 2020-09-10 23:30:25 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:25 --> Input Class Initialized
INFO - 2020-09-10 23:30:25 --> Language Class Initialized
INFO - 2020-09-10 23:30:25 --> Language Class Initialized
INFO - 2020-09-10 23:30:25 --> Config Class Initialized
INFO - 2020-09-10 23:30:25 --> Loader Class Initialized
INFO - 2020-09-10 23:30:25 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:25 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:25 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:25 --> Upload Class Initialized
INFO - 2020-09-10 23:30:25 --> Controller Class Initialized
ERROR - 2020-09-10 23:30:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:30:25 --> Config Class Initialized
INFO - 2020-09-10 23:30:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:25 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:25 --> URI Class Initialized
INFO - 2020-09-10 23:30:25 --> Router Class Initialized
INFO - 2020-09-10 23:30:25 --> Output Class Initialized
INFO - 2020-09-10 23:30:25 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:25 --> Input Class Initialized
INFO - 2020-09-10 23:30:25 --> Language Class Initialized
INFO - 2020-09-10 23:30:25 --> Language Class Initialized
INFO - 2020-09-10 23:30:25 --> Config Class Initialized
INFO - 2020-09-10 23:30:25 --> Loader Class Initialized
INFO - 2020-09-10 23:30:25 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:25 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:25 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:25 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:25 --> Upload Class Initialized
INFO - 2020-09-10 23:30:25 --> Controller Class Initialized
ERROR - 2020-09-10 23:30:25 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:30:28 --> Config Class Initialized
INFO - 2020-09-10 23:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:28 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:28 --> URI Class Initialized
INFO - 2020-09-10 23:30:28 --> Router Class Initialized
INFO - 2020-09-10 23:30:28 --> Output Class Initialized
INFO - 2020-09-10 23:30:28 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:28 --> Input Class Initialized
INFO - 2020-09-10 23:30:28 --> Language Class Initialized
INFO - 2020-09-10 23:30:28 --> Language Class Initialized
INFO - 2020-09-10 23:30:28 --> Config Class Initialized
INFO - 2020-09-10 23:30:28 --> Loader Class Initialized
INFO - 2020-09-10 23:30:28 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:28 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:28 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:28 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:28 --> Upload Class Initialized
INFO - 2020-09-10 23:30:28 --> Controller Class Initialized
ERROR - 2020-09-10 23:30:28 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:30:38 --> Config Class Initialized
INFO - 2020-09-10 23:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:30:38 --> Utf8 Class Initialized
INFO - 2020-09-10 23:30:38 --> URI Class Initialized
DEBUG - 2020-09-10 23:30:38 --> No URI present. Default controller set.
INFO - 2020-09-10 23:30:38 --> Router Class Initialized
INFO - 2020-09-10 23:30:38 --> Output Class Initialized
INFO - 2020-09-10 23:30:38 --> Security Class Initialized
DEBUG - 2020-09-10 23:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:30:38 --> Input Class Initialized
INFO - 2020-09-10 23:30:38 --> Language Class Initialized
INFO - 2020-09-10 23:30:38 --> Language Class Initialized
INFO - 2020-09-10 23:30:38 --> Config Class Initialized
INFO - 2020-09-10 23:30:38 --> Loader Class Initialized
INFO - 2020-09-10 23:30:38 --> Helper loaded: url_helper
INFO - 2020-09-10 23:30:38 --> Helper loaded: form_helper
INFO - 2020-09-10 23:30:38 --> Helper loaded: file_helper
INFO - 2020-09-10 23:30:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:30:38 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:30:38 --> Upload Class Initialized
INFO - 2020-09-10 23:30:38 --> Controller Class Initialized
DEBUG - 2020-09-10 23:30:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 23:30:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 23:30:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 23:30:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 23:30:38 --> Final output sent to browser
DEBUG - 2020-09-10 23:30:38 --> Total execution time: 0.0585
INFO - 2020-09-10 23:31:02 --> Config Class Initialized
INFO - 2020-09-10 23:31:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:31:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:31:02 --> Utf8 Class Initialized
INFO - 2020-09-10 23:31:02 --> URI Class Initialized
DEBUG - 2020-09-10 23:31:02 --> No URI present. Default controller set.
INFO - 2020-09-10 23:31:02 --> Router Class Initialized
INFO - 2020-09-10 23:31:02 --> Output Class Initialized
INFO - 2020-09-10 23:31:02 --> Security Class Initialized
DEBUG - 2020-09-10 23:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:31:02 --> Input Class Initialized
INFO - 2020-09-10 23:31:02 --> Language Class Initialized
INFO - 2020-09-10 23:31:02 --> Language Class Initialized
INFO - 2020-09-10 23:31:02 --> Config Class Initialized
INFO - 2020-09-10 23:31:02 --> Loader Class Initialized
INFO - 2020-09-10 23:31:02 --> Helper loaded: url_helper
INFO - 2020-09-10 23:31:02 --> Helper loaded: form_helper
INFO - 2020-09-10 23:31:02 --> Helper loaded: file_helper
INFO - 2020-09-10 23:31:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:31:02 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:31:02 --> Upload Class Initialized
INFO - 2020-09-10 23:31:02 --> Controller Class Initialized
DEBUG - 2020-09-10 23:31:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 23:31:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 23:31:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 23:31:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 23:31:02 --> Final output sent to browser
DEBUG - 2020-09-10 23:31:02 --> Total execution time: 0.0473
INFO - 2020-09-10 23:31:06 --> Config Class Initialized
INFO - 2020-09-10 23:31:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:31:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:31:06 --> Utf8 Class Initialized
INFO - 2020-09-10 23:31:06 --> URI Class Initialized
INFO - 2020-09-10 23:31:06 --> Router Class Initialized
INFO - 2020-09-10 23:31:06 --> Output Class Initialized
INFO - 2020-09-10 23:31:06 --> Security Class Initialized
DEBUG - 2020-09-10 23:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:31:06 --> Input Class Initialized
INFO - 2020-09-10 23:31:06 --> Language Class Initialized
INFO - 2020-09-10 23:31:06 --> Language Class Initialized
INFO - 2020-09-10 23:31:06 --> Config Class Initialized
INFO - 2020-09-10 23:31:06 --> Loader Class Initialized
INFO - 2020-09-10 23:31:06 --> Helper loaded: url_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: form_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: file_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:31:07 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:31:07 --> Upload Class Initialized
INFO - 2020-09-10 23:31:07 --> Controller Class Initialized
ERROR - 2020-09-10 23:31:07 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:31:07 --> Config Class Initialized
INFO - 2020-09-10 23:31:07 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:31:07 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:31:07 --> Utf8 Class Initialized
INFO - 2020-09-10 23:31:07 --> URI Class Initialized
INFO - 2020-09-10 23:31:07 --> Router Class Initialized
INFO - 2020-09-10 23:31:07 --> Output Class Initialized
INFO - 2020-09-10 23:31:07 --> Security Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:31:07 --> Input Class Initialized
INFO - 2020-09-10 23:31:07 --> Language Class Initialized
INFO - 2020-09-10 23:31:07 --> Language Class Initialized
INFO - 2020-09-10 23:31:07 --> Config Class Initialized
INFO - 2020-09-10 23:31:07 --> Loader Class Initialized
INFO - 2020-09-10 23:31:07 --> Helper loaded: url_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: form_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: file_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:31:07 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:31:07 --> Upload Class Initialized
INFO - 2020-09-10 23:31:07 --> Controller Class Initialized
ERROR - 2020-09-10 23:31:07 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:31:07 --> Config Class Initialized
INFO - 2020-09-10 23:31:07 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:31:07 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:31:07 --> Utf8 Class Initialized
INFO - 2020-09-10 23:31:07 --> URI Class Initialized
INFO - 2020-09-10 23:31:07 --> Router Class Initialized
INFO - 2020-09-10 23:31:07 --> Output Class Initialized
INFO - 2020-09-10 23:31:07 --> Security Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:31:07 --> Input Class Initialized
INFO - 2020-09-10 23:31:07 --> Language Class Initialized
INFO - 2020-09-10 23:31:07 --> Language Class Initialized
INFO - 2020-09-10 23:31:07 --> Config Class Initialized
INFO - 2020-09-10 23:31:07 --> Loader Class Initialized
INFO - 2020-09-10 23:31:07 --> Helper loaded: url_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: form_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: file_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:31:07 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:31:07 --> Upload Class Initialized
INFO - 2020-09-10 23:31:07 --> Controller Class Initialized
ERROR - 2020-09-10 23:31:07 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:31:07 --> Config Class Initialized
INFO - 2020-09-10 23:31:07 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:31:07 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:31:07 --> Utf8 Class Initialized
INFO - 2020-09-10 23:31:07 --> URI Class Initialized
INFO - 2020-09-10 23:31:07 --> Router Class Initialized
INFO - 2020-09-10 23:31:07 --> Output Class Initialized
INFO - 2020-09-10 23:31:07 --> Security Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:31:07 --> Input Class Initialized
INFO - 2020-09-10 23:31:07 --> Language Class Initialized
INFO - 2020-09-10 23:31:07 --> Language Class Initialized
INFO - 2020-09-10 23:31:07 --> Config Class Initialized
INFO - 2020-09-10 23:31:07 --> Loader Class Initialized
INFO - 2020-09-10 23:31:07 --> Helper loaded: url_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: form_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: file_helper
INFO - 2020-09-10 23:31:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:31:07 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:31:07 --> Upload Class Initialized
INFO - 2020-09-10 23:31:07 --> Controller Class Initialized
ERROR - 2020-09-10 23:31:07 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:33:04 --> Config Class Initialized
INFO - 2020-09-10 23:33:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:33:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:33:04 --> Utf8 Class Initialized
INFO - 2020-09-10 23:33:04 --> URI Class Initialized
INFO - 2020-09-10 23:33:04 --> Router Class Initialized
INFO - 2020-09-10 23:33:04 --> Output Class Initialized
INFO - 2020-09-10 23:33:04 --> Security Class Initialized
DEBUG - 2020-09-10 23:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:33:04 --> Input Class Initialized
INFO - 2020-09-10 23:33:04 --> Language Class Initialized
INFO - 2020-09-10 23:33:04 --> Language Class Initialized
INFO - 2020-09-10 23:33:04 --> Config Class Initialized
INFO - 2020-09-10 23:33:04 --> Loader Class Initialized
INFO - 2020-09-10 23:33:04 --> Helper loaded: url_helper
INFO - 2020-09-10 23:33:04 --> Helper loaded: form_helper
INFO - 2020-09-10 23:33:04 --> Helper loaded: file_helper
INFO - 2020-09-10 23:33:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:33:04 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:33:04 --> Upload Class Initialized
INFO - 2020-09-10 23:33:04 --> Controller Class Initialized
ERROR - 2020-09-10 23:33:04 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:36:57 --> Config Class Initialized
INFO - 2020-09-10 23:36:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:36:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:36:57 --> Utf8 Class Initialized
INFO - 2020-09-10 23:36:57 --> URI Class Initialized
INFO - 2020-09-10 23:36:57 --> Router Class Initialized
INFO - 2020-09-10 23:36:57 --> Output Class Initialized
INFO - 2020-09-10 23:36:57 --> Security Class Initialized
DEBUG - 2020-09-10 23:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:36:57 --> Input Class Initialized
INFO - 2020-09-10 23:36:57 --> Language Class Initialized
INFO - 2020-09-10 23:36:57 --> Language Class Initialized
INFO - 2020-09-10 23:36:57 --> Config Class Initialized
INFO - 2020-09-10 23:36:57 --> Loader Class Initialized
INFO - 2020-09-10 23:36:57 --> Helper loaded: url_helper
INFO - 2020-09-10 23:36:57 --> Helper loaded: form_helper
INFO - 2020-09-10 23:36:57 --> Helper loaded: file_helper
INFO - 2020-09-10 23:36:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:36:57 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:36:57 --> Upload Class Initialized
INFO - 2020-09-10 23:36:57 --> Controller Class Initialized
ERROR - 2020-09-10 23:36:57 --> 404 Page Not Found: /index
INFO - 2020-09-10 23:43:05 --> Config Class Initialized
INFO - 2020-09-10 23:43:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 23:43:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 23:43:05 --> Utf8 Class Initialized
INFO - 2020-09-10 23:43:05 --> URI Class Initialized
DEBUG - 2020-09-10 23:43:05 --> No URI present. Default controller set.
INFO - 2020-09-10 23:43:05 --> Router Class Initialized
INFO - 2020-09-10 23:43:05 --> Output Class Initialized
INFO - 2020-09-10 23:43:05 --> Security Class Initialized
DEBUG - 2020-09-10 23:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 23:43:05 --> Input Class Initialized
INFO - 2020-09-10 23:43:05 --> Language Class Initialized
INFO - 2020-09-10 23:43:05 --> Language Class Initialized
INFO - 2020-09-10 23:43:05 --> Config Class Initialized
INFO - 2020-09-10 23:43:05 --> Loader Class Initialized
INFO - 2020-09-10 23:43:05 --> Helper loaded: url_helper
INFO - 2020-09-10 23:43:05 --> Helper loaded: form_helper
INFO - 2020-09-10 23:43:05 --> Helper loaded: file_helper
INFO - 2020-09-10 23:43:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-10 23:43:05 --> Database Driver Class Initialized
DEBUG - 2020-09-10 23:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-10 23:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 23:43:05 --> Upload Class Initialized
INFO - 2020-09-10 23:43:05 --> Controller Class Initialized
DEBUG - 2020-09-10 23:43:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-10 23:43:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-10 23:43:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-10 23:43:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-10 23:43:05 --> Final output sent to browser
DEBUG - 2020-09-10 23:43:05 --> Total execution time: 0.0575
