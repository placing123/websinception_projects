<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-11 00:07:38 --> Config Class Initialized
INFO - 2020-09-11 00:07:38 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:07:38 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:07:38 --> Utf8 Class Initialized
INFO - 2020-09-11 00:07:38 --> URI Class Initialized
DEBUG - 2020-09-11 00:07:38 --> No URI present. Default controller set.
INFO - 2020-09-11 00:07:38 --> Router Class Initialized
INFO - 2020-09-11 00:07:38 --> Output Class Initialized
INFO - 2020-09-11 00:07:38 --> Security Class Initialized
DEBUG - 2020-09-11 00:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:07:38 --> Input Class Initialized
INFO - 2020-09-11 00:07:38 --> Language Class Initialized
INFO - 2020-09-11 00:07:38 --> Language Class Initialized
INFO - 2020-09-11 00:07:38 --> Config Class Initialized
INFO - 2020-09-11 00:07:38 --> Loader Class Initialized
INFO - 2020-09-11 00:07:38 --> Helper loaded: url_helper
INFO - 2020-09-11 00:07:38 --> Helper loaded: form_helper
INFO - 2020-09-11 00:07:38 --> Helper loaded: file_helper
INFO - 2020-09-11 00:07:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:07:38 --> Database Driver Class Initialized
DEBUG - 2020-09-11 00:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:07:38 --> Upload Class Initialized
INFO - 2020-09-11 00:07:38 --> Controller Class Initialized
DEBUG - 2020-09-11 00:07:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 00:07:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 00:07:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 00:07:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 00:07:38 --> Final output sent to browser
DEBUG - 2020-09-11 00:07:38 --> Total execution time: 0.0508
INFO - 2020-09-11 00:07:39 --> Config Class Initialized
INFO - 2020-09-11 00:07:39 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:07:39 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:07:39 --> Utf8 Class Initialized
INFO - 2020-09-11 00:07:39 --> URI Class Initialized
INFO - 2020-09-11 00:07:39 --> Router Class Initialized
INFO - 2020-09-11 00:07:39 --> Output Class Initialized
INFO - 2020-09-11 00:07:39 --> Security Class Initialized
DEBUG - 2020-09-11 00:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:07:39 --> Input Class Initialized
INFO - 2020-09-11 00:07:39 --> Language Class Initialized
INFO - 2020-09-11 00:07:39 --> Language Class Initialized
INFO - 2020-09-11 00:07:39 --> Config Class Initialized
INFO - 2020-09-11 00:07:39 --> Loader Class Initialized
INFO - 2020-09-11 00:07:39 --> Helper loaded: url_helper
INFO - 2020-09-11 00:07:39 --> Helper loaded: form_helper
INFO - 2020-09-11 00:07:39 --> Helper loaded: file_helper
INFO - 2020-09-11 00:07:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:07:39 --> Database Driver Class Initialized
DEBUG - 2020-09-11 00:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:07:39 --> Upload Class Initialized
INFO - 2020-09-11 00:07:39 --> Controller Class Initialized
ERROR - 2020-09-11 00:07:39 --> 404 Page Not Found: /index
INFO - 2020-09-11 00:07:40 --> Config Class Initialized
INFO - 2020-09-11 00:07:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:07:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:07:40 --> Utf8 Class Initialized
INFO - 2020-09-11 00:07:40 --> URI Class Initialized
INFO - 2020-09-11 00:07:40 --> Router Class Initialized
INFO - 2020-09-11 00:07:40 --> Output Class Initialized
INFO - 2020-09-11 00:07:40 --> Security Class Initialized
DEBUG - 2020-09-11 00:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:07:40 --> Input Class Initialized
INFO - 2020-09-11 00:07:40 --> Language Class Initialized
INFO - 2020-09-11 00:07:40 --> Language Class Initialized
INFO - 2020-09-11 00:07:40 --> Config Class Initialized
INFO - 2020-09-11 00:07:40 --> Loader Class Initialized
INFO - 2020-09-11 00:07:40 --> Helper loaded: url_helper
INFO - 2020-09-11 00:07:40 --> Helper loaded: form_helper
INFO - 2020-09-11 00:07:40 --> Helper loaded: file_helper
INFO - 2020-09-11 00:07:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:07:40 --> Database Driver Class Initialized
DEBUG - 2020-09-11 00:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:07:40 --> Upload Class Initialized
INFO - 2020-09-11 00:07:40 --> Controller Class Initialized
ERROR - 2020-09-11 00:07:40 --> 404 Page Not Found: /index
INFO - 2020-09-11 00:07:40 --> Config Class Initialized
INFO - 2020-09-11 00:07:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:07:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:07:40 --> Utf8 Class Initialized
INFO - 2020-09-11 00:07:40 --> URI Class Initialized
INFO - 2020-09-11 00:07:40 --> Router Class Initialized
INFO - 2020-09-11 00:07:40 --> Output Class Initialized
INFO - 2020-09-11 00:07:40 --> Security Class Initialized
INFO - 2020-09-11 00:07:40 --> Config Class Initialized
INFO - 2020-09-11 00:07:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:07:40 --> Input Class Initialized
INFO - 2020-09-11 00:07:40 --> Language Class Initialized
INFO - 2020-09-11 00:07:40 --> Language Class Initialized
INFO - 2020-09-11 00:07:40 --> Config Class Initialized
DEBUG - 2020-09-11 00:07:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:07:40 --> Utf8 Class Initialized
INFO - 2020-09-11 00:07:40 --> URI Class Initialized
INFO - 2020-09-11 00:07:40 --> Loader Class Initialized
INFO - 2020-09-11 00:07:40 --> Helper loaded: url_helper
INFO - 2020-09-11 00:07:40 --> Router Class Initialized
INFO - 2020-09-11 00:07:40 --> Helper loaded: form_helper
INFO - 2020-09-11 00:07:40 --> Helper loaded: file_helper
INFO - 2020-09-11 00:07:40 --> Output Class Initialized
INFO - 2020-09-11 00:07:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:07:40 --> Security Class Initialized
DEBUG - 2020-09-11 00:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:07:40 --> Input Class Initialized
INFO - 2020-09-11 00:07:40 --> Language Class Initialized
INFO - 2020-09-11 00:07:40 --> Language Class Initialized
INFO - 2020-09-11 00:07:40 --> Config Class Initialized
INFO - 2020-09-11 00:07:40 --> Database Driver Class Initialized
INFO - 2020-09-11 00:07:40 --> Loader Class Initialized
DEBUG - 2020-09-11 00:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:07:40 --> Helper loaded: url_helper
INFO - 2020-09-11 00:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:07:40 --> Upload Class Initialized
INFO - 2020-09-11 00:07:40 --> Helper loaded: form_helper
INFO - 2020-09-11 00:07:40 --> Helper loaded: file_helper
INFO - 2020-09-11 00:07:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:07:40 --> Database Driver Class Initialized
DEBUG - 2020-09-11 00:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:07:40 --> Controller Class Initialized
ERROR - 2020-09-11 00:07:40 --> 404 Page Not Found: /index
INFO - 2020-09-11 00:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:07:40 --> Upload Class Initialized
INFO - 2020-09-11 00:07:40 --> Controller Class Initialized
ERROR - 2020-09-11 00:07:40 --> 404 Page Not Found: /index
INFO - 2020-09-11 00:57:30 --> Config Class Initialized
INFO - 2020-09-11 00:57:30 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:57:31 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:57:31 --> Utf8 Class Initialized
INFO - 2020-09-11 00:57:31 --> URI Class Initialized
INFO - 2020-09-11 00:57:31 --> Router Class Initialized
INFO - 2020-09-11 00:57:31 --> Output Class Initialized
INFO - 2020-09-11 00:57:31 --> Security Class Initialized
DEBUG - 2020-09-11 00:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:57:31 --> Input Class Initialized
INFO - 2020-09-11 00:57:31 --> Language Class Initialized
INFO - 2020-09-11 00:57:31 --> Language Class Initialized
INFO - 2020-09-11 00:57:31 --> Config Class Initialized
INFO - 2020-09-11 00:57:31 --> Loader Class Initialized
INFO - 2020-09-11 00:57:31 --> Helper loaded: url_helper
INFO - 2020-09-11 00:57:31 --> Helper loaded: form_helper
INFO - 2020-09-11 00:57:31 --> Helper loaded: file_helper
INFO - 2020-09-11 00:57:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:57:31 --> Database Driver Class Initialized
DEBUG - 2020-09-11 00:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:57:31 --> Upload Class Initialized
INFO - 2020-09-11 00:57:31 --> Controller Class Initialized
ERROR - 2020-09-11 00:57:31 --> 404 Page Not Found: /index
INFO - 2020-09-11 00:57:31 --> Config Class Initialized
INFO - 2020-09-11 00:57:31 --> Hooks Class Initialized
DEBUG - 2020-09-11 00:57:31 --> UTF-8 Support Enabled
INFO - 2020-09-11 00:57:31 --> Utf8 Class Initialized
INFO - 2020-09-11 00:57:31 --> URI Class Initialized
INFO - 2020-09-11 00:57:31 --> Router Class Initialized
INFO - 2020-09-11 00:57:31 --> Output Class Initialized
INFO - 2020-09-11 00:57:31 --> Security Class Initialized
DEBUG - 2020-09-11 00:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 00:57:31 --> Input Class Initialized
INFO - 2020-09-11 00:57:31 --> Language Class Initialized
INFO - 2020-09-11 00:57:31 --> Language Class Initialized
INFO - 2020-09-11 00:57:31 --> Config Class Initialized
INFO - 2020-09-11 00:57:31 --> Loader Class Initialized
INFO - 2020-09-11 00:57:31 --> Helper loaded: url_helper
INFO - 2020-09-11 00:57:31 --> Helper loaded: form_helper
INFO - 2020-09-11 00:57:31 --> Helper loaded: file_helper
INFO - 2020-09-11 00:57:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 00:57:31 --> Database Driver Class Initialized
DEBUG - 2020-09-11 00:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 00:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 00:57:31 --> Upload Class Initialized
INFO - 2020-09-11 00:57:31 --> Controller Class Initialized
ERROR - 2020-09-11 00:57:31 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:12:16 --> Config Class Initialized
INFO - 2020-09-11 02:12:16 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:12:16 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:12:16 --> Utf8 Class Initialized
INFO - 2020-09-11 02:12:16 --> URI Class Initialized
INFO - 2020-09-11 02:12:16 --> Router Class Initialized
INFO - 2020-09-11 02:12:16 --> Output Class Initialized
INFO - 2020-09-11 02:12:16 --> Security Class Initialized
DEBUG - 2020-09-11 02:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:12:16 --> Input Class Initialized
INFO - 2020-09-11 02:12:16 --> Language Class Initialized
INFO - 2020-09-11 02:12:16 --> Language Class Initialized
INFO - 2020-09-11 02:12:16 --> Config Class Initialized
INFO - 2020-09-11 02:12:16 --> Loader Class Initialized
INFO - 2020-09-11 02:12:16 --> Helper loaded: url_helper
INFO - 2020-09-11 02:12:16 --> Helper loaded: form_helper
INFO - 2020-09-11 02:12:16 --> Helper loaded: file_helper
INFO - 2020-09-11 02:12:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:12:16 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:12:16 --> Upload Class Initialized
INFO - 2020-09-11 02:12:16 --> Controller Class Initialized
ERROR - 2020-09-11 02:12:16 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:12:17 --> Config Class Initialized
INFO - 2020-09-11 02:12:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:12:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:12:17 --> Utf8 Class Initialized
INFO - 2020-09-11 02:12:17 --> URI Class Initialized
INFO - 2020-09-11 02:12:17 --> Router Class Initialized
INFO - 2020-09-11 02:12:17 --> Output Class Initialized
INFO - 2020-09-11 02:12:17 --> Security Class Initialized
DEBUG - 2020-09-11 02:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:12:17 --> Input Class Initialized
INFO - 2020-09-11 02:12:17 --> Language Class Initialized
INFO - 2020-09-11 02:12:17 --> Language Class Initialized
INFO - 2020-09-11 02:12:17 --> Config Class Initialized
INFO - 2020-09-11 02:12:17 --> Loader Class Initialized
INFO - 2020-09-11 02:12:17 --> Helper loaded: url_helper
INFO - 2020-09-11 02:12:17 --> Helper loaded: form_helper
INFO - 2020-09-11 02:12:17 --> Helper loaded: file_helper
INFO - 2020-09-11 02:12:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:12:17 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:12:17 --> Upload Class Initialized
INFO - 2020-09-11 02:12:17 --> Controller Class Initialized
ERROR - 2020-09-11 02:12:17 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:12:29 --> Config Class Initialized
INFO - 2020-09-11 02:12:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:12:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:12:29 --> Utf8 Class Initialized
INFO - 2020-09-11 02:12:29 --> URI Class Initialized
INFO - 2020-09-11 02:12:29 --> Router Class Initialized
INFO - 2020-09-11 02:12:29 --> Output Class Initialized
INFO - 2020-09-11 02:12:29 --> Security Class Initialized
DEBUG - 2020-09-11 02:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:12:29 --> Input Class Initialized
INFO - 2020-09-11 02:12:29 --> Language Class Initialized
INFO - 2020-09-11 02:12:29 --> Language Class Initialized
INFO - 2020-09-11 02:12:29 --> Config Class Initialized
INFO - 2020-09-11 02:12:29 --> Loader Class Initialized
INFO - 2020-09-11 02:12:29 --> Helper loaded: url_helper
INFO - 2020-09-11 02:12:29 --> Helper loaded: form_helper
INFO - 2020-09-11 02:12:29 --> Helper loaded: file_helper
INFO - 2020-09-11 02:12:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:12:29 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:12:29 --> Upload Class Initialized
INFO - 2020-09-11 02:12:29 --> Controller Class Initialized
ERROR - 2020-09-11 02:12:29 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:15:33 --> Config Class Initialized
INFO - 2020-09-11 02:15:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:15:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:15:33 --> Utf8 Class Initialized
INFO - 2020-09-11 02:15:33 --> URI Class Initialized
DEBUG - 2020-09-11 02:15:33 --> No URI present. Default controller set.
INFO - 2020-09-11 02:15:33 --> Router Class Initialized
INFO - 2020-09-11 02:15:33 --> Output Class Initialized
INFO - 2020-09-11 02:15:33 --> Security Class Initialized
DEBUG - 2020-09-11 02:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:15:33 --> Input Class Initialized
INFO - 2020-09-11 02:15:33 --> Language Class Initialized
INFO - 2020-09-11 02:15:33 --> Language Class Initialized
INFO - 2020-09-11 02:15:33 --> Config Class Initialized
INFO - 2020-09-11 02:15:33 --> Loader Class Initialized
INFO - 2020-09-11 02:15:33 --> Helper loaded: url_helper
INFO - 2020-09-11 02:15:33 --> Helper loaded: form_helper
INFO - 2020-09-11 02:15:33 --> Helper loaded: file_helper
INFO - 2020-09-11 02:15:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:15:33 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:15:33 --> Upload Class Initialized
INFO - 2020-09-11 02:15:33 --> Controller Class Initialized
DEBUG - 2020-09-11 02:15:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 02:15:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 02:15:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 02:15:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 02:15:33 --> Final output sent to browser
DEBUG - 2020-09-11 02:15:33 --> Total execution time: 0.0640
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:15:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:15:36 --> Utf8 Class Initialized
INFO - 2020-09-11 02:15:36 --> URI Class Initialized
INFO - 2020-09-11 02:15:36 --> Router Class Initialized
INFO - 2020-09-11 02:15:36 --> Output Class Initialized
INFO - 2020-09-11 02:15:36 --> Security Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:15:36 --> Input Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Loader Class Initialized
INFO - 2020-09-11 02:15:36 --> Helper loaded: url_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: form_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: file_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:15:36 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:15:36 --> Upload Class Initialized
INFO - 2020-09-11 02:15:36 --> Controller Class Initialized
ERROR - 2020-09-11 02:15:36 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:15:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:15:36 --> Utf8 Class Initialized
INFO - 2020-09-11 02:15:36 --> URI Class Initialized
INFO - 2020-09-11 02:15:36 --> Router Class Initialized
INFO - 2020-09-11 02:15:36 --> Output Class Initialized
INFO - 2020-09-11 02:15:36 --> Security Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:15:36 --> Input Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Loader Class Initialized
INFO - 2020-09-11 02:15:36 --> Helper loaded: url_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: form_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: file_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:15:36 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:15:36 --> Upload Class Initialized
INFO - 2020-09-11 02:15:36 --> Controller Class Initialized
ERROR - 2020-09-11 02:15:36 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:15:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:15:36 --> Utf8 Class Initialized
INFO - 2020-09-11 02:15:36 --> URI Class Initialized
INFO - 2020-09-11 02:15:36 --> Router Class Initialized
INFO - 2020-09-11 02:15:36 --> Output Class Initialized
INFO - 2020-09-11 02:15:36 --> Security Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:15:36 --> Input Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Loader Class Initialized
INFO - 2020-09-11 02:15:36 --> Helper loaded: url_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: form_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: file_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:15:36 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:15:36 --> Upload Class Initialized
INFO - 2020-09-11 02:15:36 --> Controller Class Initialized
ERROR - 2020-09-11 02:15:36 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:15:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:15:36 --> Utf8 Class Initialized
INFO - 2020-09-11 02:15:36 --> URI Class Initialized
INFO - 2020-09-11 02:15:36 --> Router Class Initialized
INFO - 2020-09-11 02:15:36 --> Output Class Initialized
INFO - 2020-09-11 02:15:36 --> Security Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:15:36 --> Input Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Language Class Initialized
INFO - 2020-09-11 02:15:36 --> Config Class Initialized
INFO - 2020-09-11 02:15:36 --> Loader Class Initialized
INFO - 2020-09-11 02:15:36 --> Helper loaded: url_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: form_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: file_helper
INFO - 2020-09-11 02:15:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:15:36 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:15:36 --> Upload Class Initialized
INFO - 2020-09-11 02:15:36 --> Controller Class Initialized
ERROR - 2020-09-11 02:15:36 --> 404 Page Not Found: /index
INFO - 2020-09-11 02:17:52 --> Config Class Initialized
INFO - 2020-09-11 02:17:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:17:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:17:52 --> Utf8 Class Initialized
INFO - 2020-09-11 02:17:52 --> URI Class Initialized
DEBUG - 2020-09-11 02:17:52 --> No URI present. Default controller set.
INFO - 2020-09-11 02:17:52 --> Router Class Initialized
INFO - 2020-09-11 02:17:52 --> Output Class Initialized
INFO - 2020-09-11 02:17:52 --> Security Class Initialized
DEBUG - 2020-09-11 02:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:17:52 --> Input Class Initialized
INFO - 2020-09-11 02:17:52 --> Language Class Initialized
INFO - 2020-09-11 02:17:52 --> Language Class Initialized
INFO - 2020-09-11 02:17:52 --> Config Class Initialized
INFO - 2020-09-11 02:17:52 --> Loader Class Initialized
INFO - 2020-09-11 02:17:52 --> Helper loaded: url_helper
INFO - 2020-09-11 02:17:52 --> Helper loaded: form_helper
INFO - 2020-09-11 02:17:52 --> Helper loaded: file_helper
INFO - 2020-09-11 02:17:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:17:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:17:52 --> Upload Class Initialized
INFO - 2020-09-11 02:17:52 --> Controller Class Initialized
DEBUG - 2020-09-11 02:17:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 02:17:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 02:17:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 02:17:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 02:17:52 --> Final output sent to browser
DEBUG - 2020-09-11 02:17:52 --> Total execution time: 0.0721
INFO - 2020-09-11 02:17:57 --> Config Class Initialized
INFO - 2020-09-11 02:17:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 02:17:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 02:17:57 --> Utf8 Class Initialized
INFO - 2020-09-11 02:17:57 --> URI Class Initialized
INFO - 2020-09-11 02:17:57 --> Router Class Initialized
INFO - 2020-09-11 02:17:57 --> Output Class Initialized
INFO - 2020-09-11 02:17:57 --> Security Class Initialized
DEBUG - 2020-09-11 02:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 02:17:57 --> Input Class Initialized
INFO - 2020-09-11 02:17:57 --> Language Class Initialized
INFO - 2020-09-11 02:17:57 --> Language Class Initialized
INFO - 2020-09-11 02:17:57 --> Config Class Initialized
INFO - 2020-09-11 02:17:57 --> Loader Class Initialized
INFO - 2020-09-11 02:17:57 --> Helper loaded: url_helper
INFO - 2020-09-11 02:17:57 --> Helper loaded: form_helper
INFO - 2020-09-11 02:17:57 --> Helper loaded: file_helper
INFO - 2020-09-11 02:17:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 02:17:57 --> Database Driver Class Initialized
DEBUG - 2020-09-11 02:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 02:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 02:17:57 --> Upload Class Initialized
INFO - 2020-09-11 02:17:57 --> Controller Class Initialized
ERROR - 2020-09-11 02:17:57 --> 404 Page Not Found: /index
INFO - 2020-09-11 03:12:48 --> Config Class Initialized
INFO - 2020-09-11 03:12:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 03:12:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 03:12:48 --> Utf8 Class Initialized
INFO - 2020-09-11 03:12:48 --> URI Class Initialized
DEBUG - 2020-09-11 03:12:48 --> No URI present. Default controller set.
INFO - 2020-09-11 03:12:48 --> Router Class Initialized
INFO - 2020-09-11 03:12:48 --> Output Class Initialized
INFO - 2020-09-11 03:12:48 --> Security Class Initialized
DEBUG - 2020-09-11 03:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 03:12:48 --> Input Class Initialized
INFO - 2020-09-11 03:12:48 --> Language Class Initialized
INFO - 2020-09-11 03:12:48 --> Language Class Initialized
INFO - 2020-09-11 03:12:48 --> Config Class Initialized
INFO - 2020-09-11 03:12:48 --> Loader Class Initialized
INFO - 2020-09-11 03:12:48 --> Helper loaded: url_helper
INFO - 2020-09-11 03:12:48 --> Helper loaded: form_helper
INFO - 2020-09-11 03:12:48 --> Helper loaded: file_helper
INFO - 2020-09-11 03:12:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 03:12:48 --> Database Driver Class Initialized
DEBUG - 2020-09-11 03:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 03:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 03:12:48 --> Upload Class Initialized
INFO - 2020-09-11 03:12:48 --> Controller Class Initialized
DEBUG - 2020-09-11 03:12:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 03:12:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 03:12:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 03:12:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 03:12:48 --> Final output sent to browser
DEBUG - 2020-09-11 03:12:48 --> Total execution time: 0.0568
INFO - 2020-09-11 03:44:32 --> Config Class Initialized
INFO - 2020-09-11 03:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 03:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 03:44:32 --> Utf8 Class Initialized
INFO - 2020-09-11 03:44:32 --> URI Class Initialized
INFO - 2020-09-11 03:44:32 --> Router Class Initialized
INFO - 2020-09-11 03:44:32 --> Output Class Initialized
INFO - 2020-09-11 03:44:32 --> Security Class Initialized
DEBUG - 2020-09-11 03:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 03:44:32 --> Input Class Initialized
INFO - 2020-09-11 03:44:32 --> Language Class Initialized
INFO - 2020-09-11 03:44:32 --> Language Class Initialized
INFO - 2020-09-11 03:44:32 --> Config Class Initialized
INFO - 2020-09-11 03:44:32 --> Loader Class Initialized
INFO - 2020-09-11 03:44:32 --> Helper loaded: url_helper
INFO - 2020-09-11 03:44:32 --> Helper loaded: form_helper
INFO - 2020-09-11 03:44:32 --> Helper loaded: file_helper
INFO - 2020-09-11 03:44:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 03:44:32 --> Database Driver Class Initialized
DEBUG - 2020-09-11 03:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 03:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 03:44:32 --> Upload Class Initialized
INFO - 2020-09-11 03:44:32 --> Controller Class Initialized
ERROR - 2020-09-11 03:44:32 --> 404 Page Not Found: /index
INFO - 2020-09-11 03:44:33 --> Config Class Initialized
INFO - 2020-09-11 03:44:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 03:44:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 03:44:33 --> Utf8 Class Initialized
INFO - 2020-09-11 03:44:33 --> URI Class Initialized
INFO - 2020-09-11 03:44:33 --> Router Class Initialized
INFO - 2020-09-11 03:44:33 --> Output Class Initialized
INFO - 2020-09-11 03:44:33 --> Security Class Initialized
DEBUG - 2020-09-11 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 03:44:33 --> Input Class Initialized
INFO - 2020-09-11 03:44:33 --> Language Class Initialized
INFO - 2020-09-11 03:44:33 --> Language Class Initialized
INFO - 2020-09-11 03:44:33 --> Config Class Initialized
INFO - 2020-09-11 03:44:33 --> Loader Class Initialized
INFO - 2020-09-11 03:44:33 --> Helper loaded: url_helper
INFO - 2020-09-11 03:44:33 --> Helper loaded: form_helper
INFO - 2020-09-11 03:44:33 --> Helper loaded: file_helper
INFO - 2020-09-11 03:44:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 03:44:33 --> Database Driver Class Initialized
DEBUG - 2020-09-11 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 03:44:33 --> Upload Class Initialized
INFO - 2020-09-11 03:44:33 --> Controller Class Initialized
ERROR - 2020-09-11 03:44:33 --> 404 Page Not Found: /index
INFO - 2020-09-11 03:51:52 --> Config Class Initialized
INFO - 2020-09-11 03:51:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 03:51:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 03:51:52 --> Utf8 Class Initialized
INFO - 2020-09-11 03:51:52 --> URI Class Initialized
DEBUG - 2020-09-11 03:51:52 --> No URI present. Default controller set.
INFO - 2020-09-11 03:51:52 --> Router Class Initialized
INFO - 2020-09-11 03:51:52 --> Output Class Initialized
INFO - 2020-09-11 03:51:52 --> Security Class Initialized
DEBUG - 2020-09-11 03:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 03:51:52 --> Input Class Initialized
INFO - 2020-09-11 03:51:52 --> Language Class Initialized
INFO - 2020-09-11 03:51:52 --> Language Class Initialized
INFO - 2020-09-11 03:51:52 --> Config Class Initialized
INFO - 2020-09-11 03:51:52 --> Loader Class Initialized
INFO - 2020-09-11 03:51:52 --> Helper loaded: url_helper
INFO - 2020-09-11 03:51:52 --> Helper loaded: form_helper
INFO - 2020-09-11 03:51:52 --> Helper loaded: file_helper
INFO - 2020-09-11 03:51:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 03:51:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 03:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 03:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 03:51:52 --> Upload Class Initialized
INFO - 2020-09-11 03:51:52 --> Controller Class Initialized
DEBUG - 2020-09-11 03:51:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 03:51:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 03:51:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 03:51:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 03:51:52 --> Final output sent to browser
DEBUG - 2020-09-11 03:51:52 --> Total execution time: 0.0603
INFO - 2020-09-11 03:54:43 --> Config Class Initialized
INFO - 2020-09-11 03:54:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 03:54:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 03:54:43 --> Utf8 Class Initialized
INFO - 2020-09-11 03:54:43 --> URI Class Initialized
INFO - 2020-09-11 03:54:43 --> Router Class Initialized
INFO - 2020-09-11 03:54:43 --> Output Class Initialized
INFO - 2020-09-11 03:54:43 --> Security Class Initialized
DEBUG - 2020-09-11 03:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 03:54:43 --> Input Class Initialized
INFO - 2020-09-11 03:54:43 --> Language Class Initialized
INFO - 2020-09-11 03:54:43 --> Language Class Initialized
INFO - 2020-09-11 03:54:43 --> Config Class Initialized
INFO - 2020-09-11 03:54:43 --> Loader Class Initialized
INFO - 2020-09-11 03:54:43 --> Helper loaded: url_helper
INFO - 2020-09-11 03:54:43 --> Helper loaded: form_helper
INFO - 2020-09-11 03:54:43 --> Helper loaded: file_helper
INFO - 2020-09-11 03:54:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 03:54:43 --> Database Driver Class Initialized
DEBUG - 2020-09-11 03:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 03:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 03:54:43 --> Upload Class Initialized
INFO - 2020-09-11 03:54:44 --> Controller Class Initialized
ERROR - 2020-09-11 03:54:44 --> 404 Page Not Found: /index
INFO - 2020-09-11 03:55:26 --> Config Class Initialized
INFO - 2020-09-11 03:55:26 --> Hooks Class Initialized
DEBUG - 2020-09-11 03:55:26 --> UTF-8 Support Enabled
INFO - 2020-09-11 03:55:26 --> Utf8 Class Initialized
INFO - 2020-09-11 03:55:26 --> URI Class Initialized
INFO - 2020-09-11 03:55:26 --> Router Class Initialized
INFO - 2020-09-11 03:55:26 --> Output Class Initialized
INFO - 2020-09-11 03:55:26 --> Security Class Initialized
DEBUG - 2020-09-11 03:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 03:55:26 --> Input Class Initialized
INFO - 2020-09-11 03:55:26 --> Language Class Initialized
INFO - 2020-09-11 03:55:26 --> Language Class Initialized
INFO - 2020-09-11 03:55:26 --> Config Class Initialized
INFO - 2020-09-11 03:55:26 --> Loader Class Initialized
INFO - 2020-09-11 03:55:26 --> Helper loaded: url_helper
INFO - 2020-09-11 03:55:26 --> Helper loaded: form_helper
INFO - 2020-09-11 03:55:26 --> Helper loaded: file_helper
INFO - 2020-09-11 03:55:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 03:55:26 --> Database Driver Class Initialized
DEBUG - 2020-09-11 03:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 03:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 03:55:26 --> Upload Class Initialized
INFO - 2020-09-11 03:55:26 --> Controller Class Initialized
ERROR - 2020-09-11 03:55:26 --> 404 Page Not Found: /index
INFO - 2020-09-11 05:30:08 --> Config Class Initialized
INFO - 2020-09-11 05:30:08 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:08 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:08 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:08 --> URI Class Initialized
INFO - 2020-09-11 05:30:08 --> Router Class Initialized
INFO - 2020-09-11 05:30:08 --> Output Class Initialized
INFO - 2020-09-11 05:30:08 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:08 --> Input Class Initialized
INFO - 2020-09-11 05:30:08 --> Language Class Initialized
INFO - 2020-09-11 05:30:08 --> Language Class Initialized
INFO - 2020-09-11 05:30:08 --> Config Class Initialized
INFO - 2020-09-11 05:30:08 --> Loader Class Initialized
INFO - 2020-09-11 05:30:08 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:08 --> Helper loaded: form_helper
INFO - 2020-09-11 05:30:08 --> Helper loaded: file_helper
INFO - 2020-09-11 05:30:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 05:30:08 --> Database Driver Class Initialized
DEBUG - 2020-09-11 05:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 05:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:08 --> Upload Class Initialized
INFO - 2020-09-11 05:30:08 --> Controller Class Initialized
ERROR - 2020-09-11 05:30:08 --> 404 Page Not Found: /index
INFO - 2020-09-11 05:52:09 --> Config Class Initialized
INFO - 2020-09-11 05:52:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:52:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:52:09 --> Utf8 Class Initialized
INFO - 2020-09-11 05:52:09 --> URI Class Initialized
DEBUG - 2020-09-11 05:52:09 --> No URI present. Default controller set.
INFO - 2020-09-11 05:52:09 --> Router Class Initialized
INFO - 2020-09-11 05:52:09 --> Output Class Initialized
INFO - 2020-09-11 05:52:09 --> Security Class Initialized
DEBUG - 2020-09-11 05:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:52:09 --> Input Class Initialized
INFO - 2020-09-11 05:52:09 --> Language Class Initialized
INFO - 2020-09-11 05:52:09 --> Language Class Initialized
INFO - 2020-09-11 05:52:09 --> Config Class Initialized
INFO - 2020-09-11 05:52:09 --> Loader Class Initialized
INFO - 2020-09-11 05:52:09 --> Helper loaded: url_helper
INFO - 2020-09-11 05:52:09 --> Helper loaded: form_helper
INFO - 2020-09-11 05:52:09 --> Helper loaded: file_helper
INFO - 2020-09-11 05:52:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 05:52:09 --> Database Driver Class Initialized
DEBUG - 2020-09-11 05:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 05:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:52:09 --> Upload Class Initialized
INFO - 2020-09-11 05:52:09 --> Controller Class Initialized
DEBUG - 2020-09-11 05:52:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 05:52:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 05:52:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 05:52:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 05:52:09 --> Final output sent to browser
DEBUG - 2020-09-11 05:52:09 --> Total execution time: 0.0505
INFO - 2020-09-11 06:38:18 --> Config Class Initialized
INFO - 2020-09-11 06:38:18 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:38:18 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:38:18 --> Utf8 Class Initialized
INFO - 2020-09-11 06:38:18 --> URI Class Initialized
INFO - 2020-09-11 06:38:18 --> Router Class Initialized
INFO - 2020-09-11 06:38:18 --> Output Class Initialized
INFO - 2020-09-11 06:38:18 --> Security Class Initialized
DEBUG - 2020-09-11 06:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:38:18 --> Input Class Initialized
INFO - 2020-09-11 06:38:18 --> Language Class Initialized
INFO - 2020-09-11 06:38:18 --> Language Class Initialized
INFO - 2020-09-11 06:38:18 --> Config Class Initialized
INFO - 2020-09-11 06:38:18 --> Loader Class Initialized
INFO - 2020-09-11 06:38:18 --> Helper loaded: url_helper
INFO - 2020-09-11 06:38:18 --> Helper loaded: form_helper
INFO - 2020-09-11 06:38:18 --> Helper loaded: file_helper
INFO - 2020-09-11 06:38:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:38:18 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:38:18 --> Upload Class Initialized
INFO - 2020-09-11 06:38:18 --> Controller Class Initialized
ERROR - 2020-09-11 06:38:18 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:44:57 --> Config Class Initialized
INFO - 2020-09-11 06:44:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:44:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:44:57 --> Utf8 Class Initialized
INFO - 2020-09-11 06:44:57 --> URI Class Initialized
DEBUG - 2020-09-11 06:44:57 --> No URI present. Default controller set.
INFO - 2020-09-11 06:44:57 --> Router Class Initialized
INFO - 2020-09-11 06:44:57 --> Output Class Initialized
INFO - 2020-09-11 06:44:57 --> Security Class Initialized
DEBUG - 2020-09-11 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:44:57 --> Input Class Initialized
INFO - 2020-09-11 06:44:57 --> Language Class Initialized
INFO - 2020-09-11 06:44:57 --> Language Class Initialized
INFO - 2020-09-11 06:44:57 --> Config Class Initialized
INFO - 2020-09-11 06:44:57 --> Loader Class Initialized
INFO - 2020-09-11 06:44:57 --> Helper loaded: url_helper
INFO - 2020-09-11 06:44:57 --> Helper loaded: form_helper
INFO - 2020-09-11 06:44:57 --> Helper loaded: file_helper
INFO - 2020-09-11 06:44:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:44:57 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:44:57 --> Upload Class Initialized
INFO - 2020-09-11 06:44:57 --> Controller Class Initialized
DEBUG - 2020-09-11 06:44:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 06:44:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 06:44:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 06:44:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 06:44:57 --> Final output sent to browser
DEBUG - 2020-09-11 06:44:57 --> Total execution time: 0.0739
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:45:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:45:00 --> Utf8 Class Initialized
INFO - 2020-09-11 06:45:00 --> URI Class Initialized
INFO - 2020-09-11 06:45:00 --> Router Class Initialized
INFO - 2020-09-11 06:45:00 --> Output Class Initialized
INFO - 2020-09-11 06:45:00 --> Security Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:45:00 --> Input Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Loader Class Initialized
INFO - 2020-09-11 06:45:00 --> Helper loaded: url_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: form_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: file_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:45:00 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:45:00 --> Upload Class Initialized
INFO - 2020-09-11 06:45:00 --> Controller Class Initialized
ERROR - 2020-09-11 06:45:00 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:45:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:45:00 --> Utf8 Class Initialized
INFO - 2020-09-11 06:45:00 --> URI Class Initialized
INFO - 2020-09-11 06:45:00 --> Router Class Initialized
INFO - 2020-09-11 06:45:00 --> Output Class Initialized
INFO - 2020-09-11 06:45:00 --> Security Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:45:00 --> Input Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Loader Class Initialized
INFO - 2020-09-11 06:45:00 --> Helper loaded: url_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: form_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: file_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:45:00 --> Database Driver Class Initialized
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:45:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-11 06:45:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:45:00 --> Utf8 Class Initialized
INFO - 2020-09-11 06:45:00 --> Upload Class Initialized
INFO - 2020-09-11 06:45:00 --> URI Class Initialized
INFO - 2020-09-11 06:45:00 --> Router Class Initialized
INFO - 2020-09-11 06:45:00 --> Output Class Initialized
INFO - 2020-09-11 06:45:00 --> Security Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:45:00 --> Input Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Loader Class Initialized
INFO - 2020-09-11 06:45:00 --> Helper loaded: url_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: form_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: file_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:45:00 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:45:00 --> Controller Class Initialized
ERROR - 2020-09-11 06:45:00 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:45:00 --> Upload Class Initialized
INFO - 2020-09-11 06:45:00 --> Controller Class Initialized
ERROR - 2020-09-11 06:45:00 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:45:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:45:00 --> Utf8 Class Initialized
INFO - 2020-09-11 06:45:00 --> URI Class Initialized
INFO - 2020-09-11 06:45:00 --> Router Class Initialized
INFO - 2020-09-11 06:45:00 --> Output Class Initialized
INFO - 2020-09-11 06:45:00 --> Security Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:45:00 --> Input Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Language Class Initialized
INFO - 2020-09-11 06:45:00 --> Config Class Initialized
INFO - 2020-09-11 06:45:00 --> Loader Class Initialized
INFO - 2020-09-11 06:45:00 --> Helper loaded: url_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: form_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: file_helper
INFO - 2020-09-11 06:45:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:45:00 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:45:00 --> Upload Class Initialized
INFO - 2020-09-11 06:45:00 --> Controller Class Initialized
ERROR - 2020-09-11 06:45:00 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:47:50 --> Config Class Initialized
INFO - 2020-09-11 06:47:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:47:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:47:50 --> Utf8 Class Initialized
INFO - 2020-09-11 06:47:50 --> URI Class Initialized
INFO - 2020-09-11 06:47:50 --> Router Class Initialized
INFO - 2020-09-11 06:47:50 --> Output Class Initialized
INFO - 2020-09-11 06:47:50 --> Security Class Initialized
DEBUG - 2020-09-11 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:47:50 --> Input Class Initialized
INFO - 2020-09-11 06:47:50 --> Language Class Initialized
INFO - 2020-09-11 06:47:50 --> Language Class Initialized
INFO - 2020-09-11 06:47:50 --> Config Class Initialized
INFO - 2020-09-11 06:47:50 --> Loader Class Initialized
INFO - 2020-09-11 06:47:50 --> Helper loaded: url_helper
INFO - 2020-09-11 06:47:50 --> Helper loaded: form_helper
INFO - 2020-09-11 06:47:50 --> Helper loaded: file_helper
INFO - 2020-09-11 06:47:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:47:50 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:47:50 --> Upload Class Initialized
INFO - 2020-09-11 06:47:50 --> Controller Class Initialized
ERROR - 2020-09-11 06:47:50 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:50:47 --> Config Class Initialized
INFO - 2020-09-11 06:50:47 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:47 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:47 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:47 --> URI Class Initialized
DEBUG - 2020-09-11 06:50:47 --> No URI present. Default controller set.
INFO - 2020-09-11 06:50:47 --> Router Class Initialized
INFO - 2020-09-11 06:50:47 --> Output Class Initialized
INFO - 2020-09-11 06:50:47 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:47 --> Input Class Initialized
INFO - 2020-09-11 06:50:47 --> Language Class Initialized
INFO - 2020-09-11 06:50:47 --> Language Class Initialized
INFO - 2020-09-11 06:50:47 --> Config Class Initialized
INFO - 2020-09-11 06:50:47 --> Loader Class Initialized
INFO - 2020-09-11 06:50:47 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:47 --> Helper loaded: form_helper
INFO - 2020-09-11 06:50:47 --> Helper loaded: file_helper
INFO - 2020-09-11 06:50:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:50:47 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:47 --> Upload Class Initialized
INFO - 2020-09-11 06:50:47 --> Controller Class Initialized
DEBUG - 2020-09-11 06:50:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 06:50:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 06:50:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 06:50:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 06:50:47 --> Final output sent to browser
DEBUG - 2020-09-11 06:50:47 --> Total execution time: 0.0484
INFO - 2020-09-11 06:50:48 --> Config Class Initialized
INFO - 2020-09-11 06:50:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:48 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:48 --> URI Class Initialized
INFO - 2020-09-11 06:50:48 --> Router Class Initialized
INFO - 2020-09-11 06:50:48 --> Output Class Initialized
INFO - 2020-09-11 06:50:48 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:48 --> Input Class Initialized
INFO - 2020-09-11 06:50:48 --> Language Class Initialized
INFO - 2020-09-11 06:50:48 --> Language Class Initialized
INFO - 2020-09-11 06:50:48 --> Config Class Initialized
INFO - 2020-09-11 06:50:48 --> Loader Class Initialized
INFO - 2020-09-11 06:50:48 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:48 --> Helper loaded: form_helper
INFO - 2020-09-11 06:50:48 --> Helper loaded: file_helper
INFO - 2020-09-11 06:50:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:50:48 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:48 --> Upload Class Initialized
INFO - 2020-09-11 06:50:48 --> Controller Class Initialized
ERROR - 2020-09-11 06:50:48 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:50:48 --> Config Class Initialized
INFO - 2020-09-11 06:50:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:48 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:48 --> URI Class Initialized
INFO - 2020-09-11 06:50:48 --> Router Class Initialized
INFO - 2020-09-11 06:50:48 --> Output Class Initialized
INFO - 2020-09-11 06:50:48 --> Config Class Initialized
INFO - 2020-09-11 06:50:48 --> Hooks Class Initialized
INFO - 2020-09-11 06:50:48 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:48 --> Input Class Initialized
DEBUG - 2020-09-11 06:50:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:48 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:48 --> Language Class Initialized
INFO - 2020-09-11 06:50:48 --> Language Class Initialized
INFO - 2020-09-11 06:50:48 --> Config Class Initialized
INFO - 2020-09-11 06:50:48 --> URI Class Initialized
INFO - 2020-09-11 06:50:48 --> Loader Class Initialized
INFO - 2020-09-11 06:50:48 --> Router Class Initialized
INFO - 2020-09-11 06:50:48 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:48 --> Output Class Initialized
INFO - 2020-09-11 06:50:48 --> Helper loaded: form_helper
INFO - 2020-09-11 06:50:48 --> Helper loaded: file_helper
INFO - 2020-09-11 06:50:48 --> Security Class Initialized
INFO - 2020-09-11 06:50:48 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-11 06:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:48 --> Input Class Initialized
INFO - 2020-09-11 06:50:48 --> Language Class Initialized
INFO - 2020-09-11 06:50:48 --> Language Class Initialized
INFO - 2020-09-11 06:50:48 --> Config Class Initialized
INFO - 2020-09-11 06:50:48 --> Loader Class Initialized
INFO - 2020-09-11 06:50:48 --> Database Driver Class Initialized
INFO - 2020-09-11 06:50:48 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:48 --> Helper loaded: form_helper
DEBUG - 2020-09-11 06:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:50:48 --> Helper loaded: file_helper
INFO - 2020-09-11 06:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:48 --> Upload Class Initialized
INFO - 2020-09-11 06:50:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:50:48 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:50:48 --> Controller Class Initialized
ERROR - 2020-09-11 06:50:48 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:48 --> Upload Class Initialized
INFO - 2020-09-11 06:50:49 --> Controller Class Initialized
ERROR - 2020-09-11 06:50:49 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:50:49 --> Config Class Initialized
INFO - 2020-09-11 06:50:49 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:49 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:49 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:49 --> URI Class Initialized
INFO - 2020-09-11 06:50:49 --> Router Class Initialized
INFO - 2020-09-11 06:50:49 --> Output Class Initialized
INFO - 2020-09-11 06:50:49 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:49 --> Input Class Initialized
INFO - 2020-09-11 06:50:49 --> Language Class Initialized
INFO - 2020-09-11 06:50:49 --> Language Class Initialized
INFO - 2020-09-11 06:50:49 --> Config Class Initialized
INFO - 2020-09-11 06:50:49 --> Loader Class Initialized
INFO - 2020-09-11 06:50:49 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:49 --> Helper loaded: form_helper
INFO - 2020-09-11 06:50:49 --> Helper loaded: file_helper
INFO - 2020-09-11 06:50:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:50:49 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:49 --> Upload Class Initialized
INFO - 2020-09-11 06:50:49 --> Controller Class Initialized
ERROR - 2020-09-11 06:50:49 --> 404 Page Not Found: /index
INFO - 2020-09-11 06:50:49 --> Config Class Initialized
INFO - 2020-09-11 06:50:49 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:49 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:49 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:49 --> URI Class Initialized
INFO - 2020-09-11 06:50:49 --> Router Class Initialized
INFO - 2020-09-11 06:50:49 --> Output Class Initialized
INFO - 2020-09-11 06:50:49 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:49 --> Input Class Initialized
INFO - 2020-09-11 06:50:49 --> Language Class Initialized
INFO - 2020-09-11 06:50:49 --> Language Class Initialized
INFO - 2020-09-11 06:50:49 --> Config Class Initialized
INFO - 2020-09-11 06:50:49 --> Loader Class Initialized
INFO - 2020-09-11 06:50:49 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:49 --> Helper loaded: form_helper
INFO - 2020-09-11 06:50:49 --> Helper loaded: file_helper
INFO - 2020-09-11 06:50:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 06:50:49 --> Database Driver Class Initialized
DEBUG - 2020-09-11 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 06:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:49 --> Upload Class Initialized
INFO - 2020-09-11 06:50:49 --> Controller Class Initialized
ERROR - 2020-09-11 06:50:49 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:00:14 --> Config Class Initialized
INFO - 2020-09-11 07:00:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:00:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:00:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:00:14 --> URI Class Initialized
INFO - 2020-09-11 07:00:14 --> Router Class Initialized
INFO - 2020-09-11 07:00:14 --> Output Class Initialized
INFO - 2020-09-11 07:00:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:00:14 --> Input Class Initialized
INFO - 2020-09-11 07:00:14 --> Language Class Initialized
INFO - 2020-09-11 07:00:14 --> Language Class Initialized
INFO - 2020-09-11 07:00:14 --> Config Class Initialized
INFO - 2020-09-11 07:00:14 --> Loader Class Initialized
INFO - 2020-09-11 07:00:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:00:14 --> Helper loaded: form_helper
INFO - 2020-09-11 07:00:14 --> Helper loaded: file_helper
INFO - 2020-09-11 07:00:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:00:14 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:00:14 --> Upload Class Initialized
INFO - 2020-09-11 07:00:14 --> Controller Class Initialized
ERROR - 2020-09-11 07:00:14 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:10:14 --> Config Class Initialized
INFO - 2020-09-11 07:10:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:14 --> URI Class Initialized
DEBUG - 2020-09-11 07:10:14 --> No URI present. Default controller set.
INFO - 2020-09-11 07:10:14 --> Router Class Initialized
INFO - 2020-09-11 07:10:14 --> Output Class Initialized
INFO - 2020-09-11 07:10:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:14 --> Input Class Initialized
INFO - 2020-09-11 07:10:14 --> Language Class Initialized
INFO - 2020-09-11 07:10:14 --> Language Class Initialized
INFO - 2020-09-11 07:10:14 --> Config Class Initialized
INFO - 2020-09-11 07:10:14 --> Loader Class Initialized
INFO - 2020-09-11 07:10:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:14 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:14 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:14 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:14 --> Upload Class Initialized
INFO - 2020-09-11 07:10:14 --> Controller Class Initialized
DEBUG - 2020-09-11 07:10:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 07:10:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 07:10:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 07:10:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 07:10:14 --> Final output sent to browser
DEBUG - 2020-09-11 07:10:14 --> Total execution time: 0.0644
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:19 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:19 --> URI Class Initialized
INFO - 2020-09-11 07:10:19 --> Router Class Initialized
INFO - 2020-09-11 07:10:19 --> Output Class Initialized
INFO - 2020-09-11 07:10:19 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:19 --> Input Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Loader Class Initialized
INFO - 2020-09-11 07:10:19 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:19 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:19 --> Upload Class Initialized
INFO - 2020-09-11 07:10:19 --> Controller Class Initialized
ERROR - 2020-09-11 07:10:19 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:19 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:19 --> URI Class Initialized
INFO - 2020-09-11 07:10:19 --> Router Class Initialized
INFO - 2020-09-11 07:10:19 --> Output Class Initialized
INFO - 2020-09-11 07:10:19 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:19 --> Input Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Loader Class Initialized
INFO - 2020-09-11 07:10:19 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:19 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:19 --> Upload Class Initialized
INFO - 2020-09-11 07:10:19 --> Controller Class Initialized
ERROR - 2020-09-11 07:10:19 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:19 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:19 --> URI Class Initialized
INFO - 2020-09-11 07:10:19 --> Router Class Initialized
INFO - 2020-09-11 07:10:19 --> Output Class Initialized
INFO - 2020-09-11 07:10:19 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:19 --> Input Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Loader Class Initialized
INFO - 2020-09-11 07:10:19 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:19 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:19 --> Upload Class Initialized
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:19 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:19 --> URI Class Initialized
INFO - 2020-09-11 07:10:19 --> Router Class Initialized
INFO - 2020-09-11 07:10:19 --> Output Class Initialized
INFO - 2020-09-11 07:10:19 --> Security Class Initialized
INFO - 2020-09-11 07:10:19 --> Controller Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:19 --> Input Class Initialized
ERROR - 2020-09-11 07:10:19 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Language Class Initialized
INFO - 2020-09-11 07:10:19 --> Config Class Initialized
INFO - 2020-09-11 07:10:19 --> Loader Class Initialized
INFO - 2020-09-11 07:10:19 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:19 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:19 --> Upload Class Initialized
INFO - 2020-09-11 07:10:19 --> Controller Class Initialized
ERROR - 2020-09-11 07:10:19 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:10:22 --> Config Class Initialized
INFO - 2020-09-11 07:10:22 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:22 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:22 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:22 --> URI Class Initialized
INFO - 2020-09-11 07:10:22 --> Router Class Initialized
INFO - 2020-09-11 07:10:22 --> Output Class Initialized
INFO - 2020-09-11 07:10:22 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:22 --> Input Class Initialized
INFO - 2020-09-11 07:10:22 --> Language Class Initialized
INFO - 2020-09-11 07:10:22 --> Language Class Initialized
INFO - 2020-09-11 07:10:22 --> Config Class Initialized
INFO - 2020-09-11 07:10:22 --> Loader Class Initialized
INFO - 2020-09-11 07:10:22 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:22 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:22 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:22 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:22 --> Upload Class Initialized
INFO - 2020-09-11 07:10:22 --> Controller Class Initialized
ERROR - 2020-09-11 07:10:22 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:10:52 --> Config Class Initialized
INFO - 2020-09-11 07:10:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:52 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:52 --> URI Class Initialized
INFO - 2020-09-11 07:10:52 --> Router Class Initialized
INFO - 2020-09-11 07:10:52 --> Output Class Initialized
INFO - 2020-09-11 07:10:52 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:52 --> Input Class Initialized
INFO - 2020-09-11 07:10:52 --> Language Class Initialized
INFO - 2020-09-11 07:10:52 --> Language Class Initialized
INFO - 2020-09-11 07:10:52 --> Config Class Initialized
INFO - 2020-09-11 07:10:52 --> Loader Class Initialized
INFO - 2020-09-11 07:10:52 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:52 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:52 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:52 --> Upload Class Initialized
INFO - 2020-09-11 07:10:52 --> Controller Class Initialized
DEBUG - 2020-09-11 07:10:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 07:10:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-11 07:10:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 07:10:52 --> Final output sent to browser
DEBUG - 2020-09-11 07:10:52 --> Total execution time: 0.0519
INFO - 2020-09-11 07:10:52 --> Config Class Initialized
INFO - 2020-09-11 07:10:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:10:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:10:52 --> Utf8 Class Initialized
INFO - 2020-09-11 07:10:52 --> URI Class Initialized
INFO - 2020-09-11 07:10:52 --> Router Class Initialized
INFO - 2020-09-11 07:10:52 --> Output Class Initialized
INFO - 2020-09-11 07:10:52 --> Security Class Initialized
DEBUG - 2020-09-11 07:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:10:52 --> Input Class Initialized
INFO - 2020-09-11 07:10:52 --> Language Class Initialized
INFO - 2020-09-11 07:10:52 --> Language Class Initialized
INFO - 2020-09-11 07:10:52 --> Config Class Initialized
INFO - 2020-09-11 07:10:52 --> Loader Class Initialized
INFO - 2020-09-11 07:10:52 --> Helper loaded: url_helper
INFO - 2020-09-11 07:10:52 --> Helper loaded: form_helper
INFO - 2020-09-11 07:10:52 --> Helper loaded: file_helper
INFO - 2020-09-11 07:10:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:10:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:10:52 --> Upload Class Initialized
INFO - 2020-09-11 07:10:52 --> Controller Class Initialized
ERROR - 2020-09-11 07:10:52 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:13:30 --> Config Class Initialized
INFO - 2020-09-11 07:13:30 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:13:30 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:13:30 --> Utf8 Class Initialized
INFO - 2020-09-11 07:13:30 --> URI Class Initialized
DEBUG - 2020-09-11 07:13:30 --> No URI present. Default controller set.
INFO - 2020-09-11 07:13:30 --> Router Class Initialized
INFO - 2020-09-11 07:13:30 --> Output Class Initialized
INFO - 2020-09-11 07:13:30 --> Security Class Initialized
DEBUG - 2020-09-11 07:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:13:30 --> Input Class Initialized
INFO - 2020-09-11 07:13:30 --> Language Class Initialized
INFO - 2020-09-11 07:13:30 --> Language Class Initialized
INFO - 2020-09-11 07:13:30 --> Config Class Initialized
INFO - 2020-09-11 07:13:30 --> Loader Class Initialized
INFO - 2020-09-11 07:13:30 --> Helper loaded: url_helper
INFO - 2020-09-11 07:13:30 --> Helper loaded: form_helper
INFO - 2020-09-11 07:13:30 --> Helper loaded: file_helper
INFO - 2020-09-11 07:13:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:13:30 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:13:30 --> Upload Class Initialized
INFO - 2020-09-11 07:13:30 --> Controller Class Initialized
DEBUG - 2020-09-11 07:13:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 07:13:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 07:13:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 07:13:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 07:13:30 --> Final output sent to browser
DEBUG - 2020-09-11 07:13:30 --> Total execution time: 0.0685
INFO - 2020-09-11 07:13:31 --> Config Class Initialized
INFO - 2020-09-11 07:13:31 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:13:31 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:13:31 --> Utf8 Class Initialized
INFO - 2020-09-11 07:13:31 --> URI Class Initialized
INFO - 2020-09-11 07:13:31 --> Router Class Initialized
INFO - 2020-09-11 07:13:31 --> Output Class Initialized
INFO - 2020-09-11 07:13:31 --> Security Class Initialized
DEBUG - 2020-09-11 07:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:13:31 --> Input Class Initialized
INFO - 2020-09-11 07:13:31 --> Language Class Initialized
INFO - 2020-09-11 07:13:31 --> Language Class Initialized
INFO - 2020-09-11 07:13:31 --> Config Class Initialized
INFO - 2020-09-11 07:13:31 --> Loader Class Initialized
INFO - 2020-09-11 07:13:31 --> Helper loaded: url_helper
INFO - 2020-09-11 07:13:31 --> Helper loaded: form_helper
INFO - 2020-09-11 07:13:31 --> Helper loaded: file_helper
INFO - 2020-09-11 07:13:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:13:31 --> Config Class Initialized
INFO - 2020-09-11 07:13:31 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:13:31 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:13:31 --> Utf8 Class Initialized
INFO - 2020-09-11 07:13:31 --> Database Driver Class Initialized
INFO - 2020-09-11 07:13:31 --> URI Class Initialized
INFO - 2020-09-11 07:13:31 --> Router Class Initialized
DEBUG - 2020-09-11 07:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:13:31 --> Output Class Initialized
INFO - 2020-09-11 07:13:31 --> Upload Class Initialized
INFO - 2020-09-11 07:13:31 --> Security Class Initialized
DEBUG - 2020-09-11 07:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:13:31 --> Input Class Initialized
INFO - 2020-09-11 07:13:31 --> Language Class Initialized
INFO - 2020-09-11 07:13:31 --> Language Class Initialized
INFO - 2020-09-11 07:13:31 --> Config Class Initialized
INFO - 2020-09-11 07:13:31 --> Loader Class Initialized
INFO - 2020-09-11 07:13:31 --> Helper loaded: url_helper
INFO - 2020-09-11 07:13:31 --> Helper loaded: form_helper
INFO - 2020-09-11 07:13:31 --> Helper loaded: file_helper
INFO - 2020-09-11 07:13:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:13:31 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:13:31 --> Controller Class Initialized
ERROR - 2020-09-11 07:13:31 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:13:31 --> Upload Class Initialized
INFO - 2020-09-11 07:13:31 --> Controller Class Initialized
ERROR - 2020-09-11 07:13:31 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:13:32 --> Config Class Initialized
INFO - 2020-09-11 07:13:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:13:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:13:32 --> Utf8 Class Initialized
INFO - 2020-09-11 07:13:32 --> URI Class Initialized
INFO - 2020-09-11 07:13:32 --> Config Class Initialized
INFO - 2020-09-11 07:13:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:13:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:13:32 --> Utf8 Class Initialized
INFO - 2020-09-11 07:13:32 --> Router Class Initialized
INFO - 2020-09-11 07:13:32 --> URI Class Initialized
INFO - 2020-09-11 07:13:32 --> Output Class Initialized
INFO - 2020-09-11 07:13:32 --> Router Class Initialized
INFO - 2020-09-11 07:13:32 --> Security Class Initialized
INFO - 2020-09-11 07:13:32 --> Output Class Initialized
DEBUG - 2020-09-11 07:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:13:32 --> Input Class Initialized
INFO - 2020-09-11 07:13:32 --> Language Class Initialized
INFO - 2020-09-11 07:13:32 --> Security Class Initialized
INFO - 2020-09-11 07:13:32 --> Language Class Initialized
INFO - 2020-09-11 07:13:32 --> Config Class Initialized
DEBUG - 2020-09-11 07:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:13:32 --> Input Class Initialized
INFO - 2020-09-11 07:13:32 --> Language Class Initialized
INFO - 2020-09-11 07:13:32 --> Language Class Initialized
INFO - 2020-09-11 07:13:32 --> Config Class Initialized
INFO - 2020-09-11 07:13:32 --> Loader Class Initialized
INFO - 2020-09-11 07:13:32 --> Loader Class Initialized
INFO - 2020-09-11 07:13:32 --> Helper loaded: url_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: url_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: form_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: form_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: file_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: file_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:13:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:13:32 --> Database Driver Class Initialized
INFO - 2020-09-11 07:13:32 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:13:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-11 07:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:13:32 --> Upload Class Initialized
INFO - 2020-09-11 07:13:32 --> Controller Class Initialized
ERROR - 2020-09-11 07:13:32 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:13:32 --> Upload Class Initialized
INFO - 2020-09-11 07:13:32 --> Controller Class Initialized
ERROR - 2020-09-11 07:13:32 --> 404 Page Not Found: /index
INFO - 2020-09-11 07:18:32 --> Config Class Initialized
INFO - 2020-09-11 07:18:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:18:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:18:32 --> Utf8 Class Initialized
INFO - 2020-09-11 07:18:32 --> URI Class Initialized
INFO - 2020-09-11 07:18:32 --> Router Class Initialized
INFO - 2020-09-11 07:18:32 --> Output Class Initialized
INFO - 2020-09-11 07:18:32 --> Security Class Initialized
DEBUG - 2020-09-11 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:18:32 --> Input Class Initialized
INFO - 2020-09-11 07:18:32 --> Language Class Initialized
INFO - 2020-09-11 07:18:32 --> Language Class Initialized
INFO - 2020-09-11 07:18:32 --> Config Class Initialized
INFO - 2020-09-11 07:18:32 --> Loader Class Initialized
INFO - 2020-09-11 07:18:32 --> Helper loaded: url_helper
INFO - 2020-09-11 07:18:32 --> Helper loaded: form_helper
INFO - 2020-09-11 07:18:32 --> Helper loaded: file_helper
INFO - 2020-09-11 07:18:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 07:18:32 --> Database Driver Class Initialized
DEBUG - 2020-09-11 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:18:32 --> Upload Class Initialized
INFO - 2020-09-11 07:18:32 --> Controller Class Initialized
ERROR - 2020-09-11 07:18:32 --> 404 Page Not Found: /index
INFO - 2020-09-11 09:00:21 --> Config Class Initialized
INFO - 2020-09-11 09:00:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 09:00:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 09:00:21 --> Utf8 Class Initialized
INFO - 2020-09-11 09:00:21 --> URI Class Initialized
DEBUG - 2020-09-11 09:00:21 --> No URI present. Default controller set.
INFO - 2020-09-11 09:00:21 --> Router Class Initialized
INFO - 2020-09-11 09:00:21 --> Output Class Initialized
INFO - 2020-09-11 09:00:21 --> Security Class Initialized
DEBUG - 2020-09-11 09:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 09:00:21 --> Input Class Initialized
INFO - 2020-09-11 09:00:21 --> Language Class Initialized
INFO - 2020-09-11 09:00:21 --> Language Class Initialized
INFO - 2020-09-11 09:00:21 --> Config Class Initialized
INFO - 2020-09-11 09:00:21 --> Loader Class Initialized
INFO - 2020-09-11 09:00:21 --> Helper loaded: url_helper
INFO - 2020-09-11 09:00:21 --> Helper loaded: form_helper
INFO - 2020-09-11 09:00:21 --> Helper loaded: file_helper
INFO - 2020-09-11 09:00:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 09:00:21 --> Database Driver Class Initialized
DEBUG - 2020-09-11 09:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 09:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 09:00:21 --> Upload Class Initialized
INFO - 2020-09-11 09:00:21 --> Controller Class Initialized
DEBUG - 2020-09-11 09:00:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 09:00:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 09:00:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 09:00:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 09:00:21 --> Final output sent to browser
DEBUG - 2020-09-11 09:00:21 --> Total execution time: 0.0540
INFO - 2020-09-11 10:12:00 --> Config Class Initialized
INFO - 2020-09-11 10:12:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 10:12:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 10:12:00 --> Utf8 Class Initialized
INFO - 2020-09-11 10:12:00 --> URI Class Initialized
INFO - 2020-09-11 10:12:00 --> Router Class Initialized
INFO - 2020-09-11 10:12:00 --> Output Class Initialized
INFO - 2020-09-11 10:12:00 --> Security Class Initialized
DEBUG - 2020-09-11 10:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 10:12:00 --> Input Class Initialized
INFO - 2020-09-11 10:12:00 --> Language Class Initialized
INFO - 2020-09-11 10:12:00 --> Language Class Initialized
INFO - 2020-09-11 10:12:00 --> Config Class Initialized
INFO - 2020-09-11 10:12:00 --> Loader Class Initialized
INFO - 2020-09-11 10:12:00 --> Helper loaded: url_helper
INFO - 2020-09-11 10:12:00 --> Helper loaded: form_helper
INFO - 2020-09-11 10:12:00 --> Helper loaded: file_helper
INFO - 2020-09-11 10:12:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 10:12:00 --> Database Driver Class Initialized
DEBUG - 2020-09-11 10:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 10:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 10:12:00 --> Upload Class Initialized
INFO - 2020-09-11 10:12:00 --> Controller Class Initialized
ERROR - 2020-09-11 10:12:00 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:31:57 --> Config Class Initialized
INFO - 2020-09-11 11:31:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:57 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:57 --> URI Class Initialized
DEBUG - 2020-09-11 11:31:57 --> No URI present. Default controller set.
INFO - 2020-09-11 11:31:57 --> Router Class Initialized
INFO - 2020-09-11 11:31:57 --> Output Class Initialized
INFO - 2020-09-11 11:31:57 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:57 --> Input Class Initialized
INFO - 2020-09-11 11:31:57 --> Language Class Initialized
INFO - 2020-09-11 11:31:57 --> Language Class Initialized
INFO - 2020-09-11 11:31:57 --> Config Class Initialized
INFO - 2020-09-11 11:31:57 --> Loader Class Initialized
INFO - 2020-09-11 11:31:57 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:57 --> Helper loaded: form_helper
INFO - 2020-09-11 11:31:57 --> Helper loaded: file_helper
INFO - 2020-09-11 11:31:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:31:57 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:57 --> Upload Class Initialized
INFO - 2020-09-11 11:31:57 --> Controller Class Initialized
DEBUG - 2020-09-11 11:31:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 11:31:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 11:31:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 11:31:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 11:31:57 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:57 --> Total execution time: 0.0538
INFO - 2020-09-11 11:33:14 --> Config Class Initialized
INFO - 2020-09-11 11:33:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:33:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:33:14 --> Utf8 Class Initialized
INFO - 2020-09-11 11:33:14 --> URI Class Initialized
INFO - 2020-09-11 11:33:14 --> Router Class Initialized
INFO - 2020-09-11 11:33:14 --> Output Class Initialized
INFO - 2020-09-11 11:33:14 --> Security Class Initialized
DEBUG - 2020-09-11 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:33:14 --> Input Class Initialized
INFO - 2020-09-11 11:33:14 --> Language Class Initialized
INFO - 2020-09-11 11:33:14 --> Language Class Initialized
INFO - 2020-09-11 11:33:14 --> Config Class Initialized
INFO - 2020-09-11 11:33:14 --> Loader Class Initialized
INFO - 2020-09-11 11:33:14 --> Helper loaded: url_helper
INFO - 2020-09-11 11:33:14 --> Helper loaded: form_helper
INFO - 2020-09-11 11:33:14 --> Helper loaded: file_helper
INFO - 2020-09-11 11:33:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:33:14 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:33:14 --> Upload Class Initialized
INFO - 2020-09-11 11:33:14 --> Controller Class Initialized
ERROR - 2020-09-11 11:33:14 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:33:18 --> Config Class Initialized
INFO - 2020-09-11 11:33:18 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:33:18 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:33:18 --> Utf8 Class Initialized
INFO - 2020-09-11 11:33:18 --> URI Class Initialized
INFO - 2020-09-11 11:33:18 --> Router Class Initialized
INFO - 2020-09-11 11:33:18 --> Output Class Initialized
INFO - 2020-09-11 11:33:18 --> Security Class Initialized
DEBUG - 2020-09-11 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:33:18 --> Input Class Initialized
INFO - 2020-09-11 11:33:18 --> Language Class Initialized
INFO - 2020-09-11 11:33:18 --> Language Class Initialized
INFO - 2020-09-11 11:33:18 --> Config Class Initialized
INFO - 2020-09-11 11:33:18 --> Loader Class Initialized
INFO - 2020-09-11 11:33:18 --> Helper loaded: url_helper
INFO - 2020-09-11 11:33:18 --> Helper loaded: form_helper
INFO - 2020-09-11 11:33:18 --> Helper loaded: file_helper
INFO - 2020-09-11 11:33:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:33:18 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:33:18 --> Upload Class Initialized
INFO - 2020-09-11 11:33:18 --> Controller Class Initialized
ERROR - 2020-09-11 11:33:18 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:33:21 --> Config Class Initialized
INFO - 2020-09-11 11:33:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:33:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:33:21 --> Utf8 Class Initialized
INFO - 2020-09-11 11:33:21 --> URI Class Initialized
INFO - 2020-09-11 11:33:21 --> Router Class Initialized
INFO - 2020-09-11 11:33:21 --> Output Class Initialized
INFO - 2020-09-11 11:33:21 --> Security Class Initialized
DEBUG - 2020-09-11 11:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:33:21 --> Input Class Initialized
INFO - 2020-09-11 11:33:21 --> Language Class Initialized
INFO - 2020-09-11 11:33:21 --> Language Class Initialized
INFO - 2020-09-11 11:33:21 --> Config Class Initialized
INFO - 2020-09-11 11:33:21 --> Loader Class Initialized
INFO - 2020-09-11 11:33:21 --> Helper loaded: url_helper
INFO - 2020-09-11 11:33:21 --> Helper loaded: form_helper
INFO - 2020-09-11 11:33:21 --> Helper loaded: file_helper
INFO - 2020-09-11 11:33:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:33:21 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:33:21 --> Upload Class Initialized
INFO - 2020-09-11 11:33:21 --> Controller Class Initialized
ERROR - 2020-09-11 11:33:21 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:33:52 --> Config Class Initialized
INFO - 2020-09-11 11:33:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:33:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:33:52 --> Utf8 Class Initialized
INFO - 2020-09-11 11:33:52 --> URI Class Initialized
INFO - 2020-09-11 11:33:52 --> Router Class Initialized
INFO - 2020-09-11 11:33:52 --> Output Class Initialized
INFO - 2020-09-11 11:33:52 --> Security Class Initialized
DEBUG - 2020-09-11 11:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:33:52 --> Input Class Initialized
INFO - 2020-09-11 11:33:52 --> Language Class Initialized
INFO - 2020-09-11 11:33:52 --> Language Class Initialized
INFO - 2020-09-11 11:33:52 --> Config Class Initialized
INFO - 2020-09-11 11:33:52 --> Loader Class Initialized
INFO - 2020-09-11 11:33:52 --> Helper loaded: url_helper
INFO - 2020-09-11 11:33:52 --> Helper loaded: form_helper
INFO - 2020-09-11 11:33:52 --> Helper loaded: file_helper
INFO - 2020-09-11 11:33:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:33:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:33:52 --> Upload Class Initialized
INFO - 2020-09-11 11:33:52 --> Controller Class Initialized
ERROR - 2020-09-11 11:33:52 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:41:26 --> Config Class Initialized
INFO - 2020-09-11 11:41:26 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:41:26 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:41:26 --> Utf8 Class Initialized
INFO - 2020-09-11 11:41:26 --> URI Class Initialized
DEBUG - 2020-09-11 11:41:26 --> No URI present. Default controller set.
INFO - 2020-09-11 11:41:26 --> Router Class Initialized
INFO - 2020-09-11 11:41:26 --> Output Class Initialized
INFO - 2020-09-11 11:41:26 --> Security Class Initialized
DEBUG - 2020-09-11 11:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:41:26 --> Input Class Initialized
INFO - 2020-09-11 11:41:26 --> Language Class Initialized
INFO - 2020-09-11 11:41:26 --> Language Class Initialized
INFO - 2020-09-11 11:41:26 --> Config Class Initialized
INFO - 2020-09-11 11:41:26 --> Loader Class Initialized
INFO - 2020-09-11 11:41:26 --> Helper loaded: url_helper
INFO - 2020-09-11 11:41:26 --> Helper loaded: form_helper
INFO - 2020-09-11 11:41:26 --> Helper loaded: file_helper
INFO - 2020-09-11 11:41:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:41:26 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:41:26 --> Upload Class Initialized
INFO - 2020-09-11 11:41:26 --> Controller Class Initialized
DEBUG - 2020-09-11 11:41:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 11:41:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 11:41:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 11:41:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 11:41:26 --> Final output sent to browser
DEBUG - 2020-09-11 11:41:26 --> Total execution time: 0.0556
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:41:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:41:29 --> Utf8 Class Initialized
INFO - 2020-09-11 11:41:29 --> URI Class Initialized
INFO - 2020-09-11 11:41:29 --> Router Class Initialized
INFO - 2020-09-11 11:41:29 --> Output Class Initialized
INFO - 2020-09-11 11:41:29 --> Security Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:41:29 --> Input Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Loader Class Initialized
INFO - 2020-09-11 11:41:29 --> Helper loaded: url_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: form_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: file_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:41:29 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:41:29 --> Upload Class Initialized
INFO - 2020-09-11 11:41:29 --> Controller Class Initialized
ERROR - 2020-09-11 11:41:29 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:41:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:41:29 --> Utf8 Class Initialized
INFO - 2020-09-11 11:41:29 --> URI Class Initialized
INFO - 2020-09-11 11:41:29 --> Router Class Initialized
INFO - 2020-09-11 11:41:29 --> Output Class Initialized
INFO - 2020-09-11 11:41:29 --> Security Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:41:29 --> Input Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Loader Class Initialized
INFO - 2020-09-11 11:41:29 --> Helper loaded: url_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: form_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: file_helper
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Hooks Class Initialized
INFO - 2020-09-11 11:41:29 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-11 11:41:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:41:29 --> Utf8 Class Initialized
INFO - 2020-09-11 11:41:29 --> URI Class Initialized
INFO - 2020-09-11 11:41:29 --> Router Class Initialized
INFO - 2020-09-11 11:41:29 --> Output Class Initialized
INFO - 2020-09-11 11:41:29 --> Security Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:41:29 --> Input Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Database Driver Class Initialized
INFO - 2020-09-11 11:41:29 --> Loader Class Initialized
INFO - 2020-09-11 11:41:29 --> Helper loaded: url_helper
DEBUG - 2020-09-11 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:41:29 --> Helper loaded: form_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: file_helper
INFO - 2020-09-11 11:41:29 --> Upload Class Initialized
INFO - 2020-09-11 11:41:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:41:29 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:41:29 --> Controller Class Initialized
ERROR - 2020-09-11 11:41:29 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:41:29 --> Upload Class Initialized
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:41:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:41:29 --> Utf8 Class Initialized
INFO - 2020-09-11 11:41:29 --> URI Class Initialized
INFO - 2020-09-11 11:41:29 --> Router Class Initialized
INFO - 2020-09-11 11:41:29 --> Output Class Initialized
INFO - 2020-09-11 11:41:29 --> Security Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:41:29 --> Input Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Language Class Initialized
INFO - 2020-09-11 11:41:29 --> Config Class Initialized
INFO - 2020-09-11 11:41:29 --> Controller Class Initialized
ERROR - 2020-09-11 11:41:29 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:41:29 --> Loader Class Initialized
INFO - 2020-09-11 11:41:29 --> Helper loaded: url_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: form_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: file_helper
INFO - 2020-09-11 11:41:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:41:29 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:41:29 --> Upload Class Initialized
INFO - 2020-09-11 11:41:29 --> Controller Class Initialized
ERROR - 2020-09-11 11:41:29 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:41:33 --> Config Class Initialized
INFO - 2020-09-11 11:41:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:41:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:41:33 --> Utf8 Class Initialized
INFO - 2020-09-11 11:41:33 --> URI Class Initialized
INFO - 2020-09-11 11:41:33 --> Router Class Initialized
INFO - 2020-09-11 11:41:33 --> Output Class Initialized
INFO - 2020-09-11 11:41:33 --> Security Class Initialized
DEBUG - 2020-09-11 11:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:41:33 --> Input Class Initialized
INFO - 2020-09-11 11:41:33 --> Language Class Initialized
INFO - 2020-09-11 11:41:33 --> Language Class Initialized
INFO - 2020-09-11 11:41:33 --> Config Class Initialized
INFO - 2020-09-11 11:41:33 --> Loader Class Initialized
INFO - 2020-09-11 11:41:33 --> Helper loaded: url_helper
INFO - 2020-09-11 11:41:33 --> Helper loaded: form_helper
INFO - 2020-09-11 11:41:33 --> Helper loaded: file_helper
INFO - 2020-09-11 11:41:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:41:33 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:41:33 --> Upload Class Initialized
INFO - 2020-09-11 11:41:33 --> Controller Class Initialized
ERROR - 2020-09-11 11:41:33 --> 404 Page Not Found: /index
INFO - 2020-09-11 11:42:07 --> Config Class Initialized
INFO - 2020-09-11 11:42:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:42:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:42:07 --> Utf8 Class Initialized
INFO - 2020-09-11 11:42:07 --> URI Class Initialized
DEBUG - 2020-09-11 11:42:07 --> No URI present. Default controller set.
INFO - 2020-09-11 11:42:07 --> Router Class Initialized
INFO - 2020-09-11 11:42:07 --> Output Class Initialized
INFO - 2020-09-11 11:42:07 --> Security Class Initialized
DEBUG - 2020-09-11 11:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:42:07 --> Input Class Initialized
INFO - 2020-09-11 11:42:07 --> Language Class Initialized
INFO - 2020-09-11 11:42:07 --> Language Class Initialized
INFO - 2020-09-11 11:42:07 --> Config Class Initialized
INFO - 2020-09-11 11:42:07 --> Loader Class Initialized
INFO - 2020-09-11 11:42:07 --> Helper loaded: url_helper
INFO - 2020-09-11 11:42:07 --> Helper loaded: form_helper
INFO - 2020-09-11 11:42:07 --> Helper loaded: file_helper
INFO - 2020-09-11 11:42:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 11:42:08 --> Database Driver Class Initialized
DEBUG - 2020-09-11 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:42:08 --> Upload Class Initialized
INFO - 2020-09-11 11:42:08 --> Controller Class Initialized
DEBUG - 2020-09-11 11:42:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 11:42:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 11:42:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 11:42:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 11:42:08 --> Final output sent to browser
DEBUG - 2020-09-11 11:42:08 --> Total execution time: 0.0627
INFO - 2020-09-11 12:43:56 --> Config Class Initialized
INFO - 2020-09-11 12:43:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:43:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:43:56 --> Utf8 Class Initialized
INFO - 2020-09-11 12:43:56 --> URI Class Initialized
DEBUG - 2020-09-11 12:43:56 --> No URI present. Default controller set.
INFO - 2020-09-11 12:43:56 --> Router Class Initialized
INFO - 2020-09-11 12:43:56 --> Output Class Initialized
INFO - 2020-09-11 12:43:56 --> Security Class Initialized
DEBUG - 2020-09-11 12:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:43:56 --> Input Class Initialized
INFO - 2020-09-11 12:43:56 --> Language Class Initialized
INFO - 2020-09-11 12:43:56 --> Language Class Initialized
INFO - 2020-09-11 12:43:56 --> Config Class Initialized
INFO - 2020-09-11 12:43:56 --> Loader Class Initialized
INFO - 2020-09-11 12:43:56 --> Helper loaded: url_helper
INFO - 2020-09-11 12:43:56 --> Helper loaded: form_helper
INFO - 2020-09-11 12:43:56 --> Helper loaded: file_helper
INFO - 2020-09-11 12:43:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:43:56 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:43:56 --> Upload Class Initialized
INFO - 2020-09-11 12:43:56 --> Controller Class Initialized
DEBUG - 2020-09-11 12:43:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 12:43:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 12:43:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 12:43:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 12:43:56 --> Final output sent to browser
DEBUG - 2020-09-11 12:43:56 --> Total execution time: 0.0507
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:43:57 --> Utf8 Class Initialized
INFO - 2020-09-11 12:43:57 --> URI Class Initialized
INFO - 2020-09-11 12:43:57 --> Router Class Initialized
INFO - 2020-09-11 12:43:57 --> Output Class Initialized
INFO - 2020-09-11 12:43:57 --> Security Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:43:57 --> Input Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Loader Class Initialized
INFO - 2020-09-11 12:43:57 --> Helper loaded: url_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: form_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: file_helper
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:43:57 --> Utf8 Class Initialized
INFO - 2020-09-11 12:43:57 --> URI Class Initialized
INFO - 2020-09-11 12:43:57 --> Router Class Initialized
INFO - 2020-09-11 12:43:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:43:57 --> Output Class Initialized
INFO - 2020-09-11 12:43:57 --> Security Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:43:57 --> Input Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Database Driver Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Loader Class Initialized
INFO - 2020-09-11 12:43:57 --> Helper loaded: url_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: form_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: file_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-11 12:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:43:57 --> Upload Class Initialized
INFO - 2020-09-11 12:43:57 --> Database Driver Class Initialized
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-09-11 12:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:43:57 --> Utf8 Class Initialized
INFO - 2020-09-11 12:43:57 --> URI Class Initialized
INFO - 2020-09-11 12:43:57 --> Router Class Initialized
INFO - 2020-09-11 12:43:57 --> Output Class Initialized
INFO - 2020-09-11 12:43:57 --> Security Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:43:57 --> Input Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Controller Class Initialized
INFO - 2020-09-11 12:43:57 --> Loader Class Initialized
ERROR - 2020-09-11 12:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:43:57 --> Helper loaded: url_helper
INFO - 2020-09-11 12:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:43:57 --> Helper loaded: form_helper
INFO - 2020-09-11 12:43:57 --> Upload Class Initialized
INFO - 2020-09-11 12:43:57 --> Helper loaded: file_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:43:57 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:43:57 --> Controller Class Initialized
ERROR - 2020-09-11 12:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:43:57 --> Upload Class Initialized
INFO - 2020-09-11 12:43:57 --> Controller Class Initialized
ERROR - 2020-09-11 12:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:43:57 --> Utf8 Class Initialized
INFO - 2020-09-11 12:43:57 --> URI Class Initialized
INFO - 2020-09-11 12:43:57 --> Router Class Initialized
INFO - 2020-09-11 12:43:57 --> Output Class Initialized
INFO - 2020-09-11 12:43:57 --> Security Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:43:57 --> Input Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Language Class Initialized
INFO - 2020-09-11 12:43:57 --> Config Class Initialized
INFO - 2020-09-11 12:43:57 --> Loader Class Initialized
INFO - 2020-09-11 12:43:57 --> Helper loaded: url_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: form_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: file_helper
INFO - 2020-09-11 12:43:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:43:57 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:43:57 --> Upload Class Initialized
INFO - 2020-09-11 12:43:57 --> Controller Class Initialized
ERROR - 2020-09-11 12:43:57 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:43:58 --> Config Class Initialized
INFO - 2020-09-11 12:43:58 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:43:58 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:43:58 --> Utf8 Class Initialized
INFO - 2020-09-11 12:43:58 --> URI Class Initialized
INFO - 2020-09-11 12:43:58 --> Router Class Initialized
INFO - 2020-09-11 12:43:58 --> Output Class Initialized
INFO - 2020-09-11 12:43:58 --> Security Class Initialized
DEBUG - 2020-09-11 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:43:58 --> Input Class Initialized
INFO - 2020-09-11 12:43:58 --> Language Class Initialized
INFO - 2020-09-11 12:43:58 --> Language Class Initialized
INFO - 2020-09-11 12:43:58 --> Config Class Initialized
INFO - 2020-09-11 12:43:58 --> Loader Class Initialized
INFO - 2020-09-11 12:43:58 --> Helper loaded: url_helper
INFO - 2020-09-11 12:43:58 --> Helper loaded: form_helper
INFO - 2020-09-11 12:43:58 --> Helper loaded: file_helper
INFO - 2020-09-11 12:43:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:43:58 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:43:58 --> Upload Class Initialized
INFO - 2020-09-11 12:43:58 --> Controller Class Initialized
ERROR - 2020-09-11 12:43:58 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:44:23 --> Config Class Initialized
INFO - 2020-09-11 12:44:23 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:44:23 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:44:23 --> Utf8 Class Initialized
INFO - 2020-09-11 12:44:23 --> URI Class Initialized
INFO - 2020-09-11 12:44:23 --> Router Class Initialized
INFO - 2020-09-11 12:44:23 --> Output Class Initialized
INFO - 2020-09-11 12:44:23 --> Security Class Initialized
DEBUG - 2020-09-11 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:44:23 --> Input Class Initialized
INFO - 2020-09-11 12:44:23 --> Language Class Initialized
INFO - 2020-09-11 12:44:23 --> Language Class Initialized
INFO - 2020-09-11 12:44:23 --> Config Class Initialized
INFO - 2020-09-11 12:44:23 --> Loader Class Initialized
INFO - 2020-09-11 12:44:23 --> Helper loaded: url_helper
INFO - 2020-09-11 12:44:23 --> Helper loaded: form_helper
INFO - 2020-09-11 12:44:23 --> Helper loaded: file_helper
INFO - 2020-09-11 12:44:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:44:23 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:44:23 --> Upload Class Initialized
INFO - 2020-09-11 12:44:23 --> Controller Class Initialized
DEBUG - 2020-09-11 12:44:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 12:44:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-11 12:44:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 12:44:23 --> Final output sent to browser
DEBUG - 2020-09-11 12:44:23 --> Total execution time: 0.0555
INFO - 2020-09-11 12:44:28 --> Config Class Initialized
INFO - 2020-09-11 12:44:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:44:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:44:28 --> Utf8 Class Initialized
INFO - 2020-09-11 12:44:28 --> URI Class Initialized
INFO - 2020-09-11 12:44:28 --> Router Class Initialized
INFO - 2020-09-11 12:44:28 --> Output Class Initialized
INFO - 2020-09-11 12:44:28 --> Security Class Initialized
DEBUG - 2020-09-11 12:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:44:28 --> Input Class Initialized
INFO - 2020-09-11 12:44:28 --> Language Class Initialized
INFO - 2020-09-11 12:44:28 --> Language Class Initialized
INFO - 2020-09-11 12:44:28 --> Config Class Initialized
INFO - 2020-09-11 12:44:28 --> Loader Class Initialized
INFO - 2020-09-11 12:44:28 --> Helper loaded: url_helper
INFO - 2020-09-11 12:44:28 --> Helper loaded: form_helper
INFO - 2020-09-11 12:44:28 --> Helper loaded: file_helper
INFO - 2020-09-11 12:44:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:44:28 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:44:28 --> Upload Class Initialized
INFO - 2020-09-11 12:44:28 --> Controller Class Initialized
ERROR - 2020-09-11 12:44:28 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:45:23 --> Config Class Initialized
INFO - 2020-09-11 12:45:23 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:45:23 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:45:23 --> Utf8 Class Initialized
INFO - 2020-09-11 12:45:23 --> URI Class Initialized
DEBUG - 2020-09-11 12:45:23 --> No URI present. Default controller set.
INFO - 2020-09-11 12:45:23 --> Router Class Initialized
INFO - 2020-09-11 12:45:23 --> Output Class Initialized
INFO - 2020-09-11 12:45:23 --> Security Class Initialized
DEBUG - 2020-09-11 12:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:45:23 --> Input Class Initialized
INFO - 2020-09-11 12:45:23 --> Language Class Initialized
INFO - 2020-09-11 12:45:23 --> Language Class Initialized
INFO - 2020-09-11 12:45:23 --> Config Class Initialized
INFO - 2020-09-11 12:45:23 --> Loader Class Initialized
INFO - 2020-09-11 12:45:23 --> Helper loaded: url_helper
INFO - 2020-09-11 12:45:23 --> Helper loaded: form_helper
INFO - 2020-09-11 12:45:23 --> Helper loaded: file_helper
INFO - 2020-09-11 12:45:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:45:23 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:45:23 --> Upload Class Initialized
INFO - 2020-09-11 12:45:23 --> Controller Class Initialized
DEBUG - 2020-09-11 12:45:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 12:45:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 12:45:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 12:45:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 12:45:23 --> Final output sent to browser
DEBUG - 2020-09-11 12:45:23 --> Total execution time: 0.0580
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:45:24 --> Utf8 Class Initialized
INFO - 2020-09-11 12:45:24 --> URI Class Initialized
INFO - 2020-09-11 12:45:24 --> Router Class Initialized
INFO - 2020-09-11 12:45:24 --> Output Class Initialized
INFO - 2020-09-11 12:45:24 --> Security Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:45:24 --> Input Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Loader Class Initialized
INFO - 2020-09-11 12:45:24 --> Helper loaded: url_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: form_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: file_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:45:24 --> Database Driver Class Initialized
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:45:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-11 12:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:45:24 --> Utf8 Class Initialized
INFO - 2020-09-11 12:45:24 --> Upload Class Initialized
INFO - 2020-09-11 12:45:24 --> URI Class Initialized
INFO - 2020-09-11 12:45:24 --> Router Class Initialized
INFO - 2020-09-11 12:45:24 --> Output Class Initialized
INFO - 2020-09-11 12:45:24 --> Security Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:45:24 --> Input Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Loader Class Initialized
INFO - 2020-09-11 12:45:24 --> Helper loaded: url_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: form_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: file_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:45:24 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:45:24 --> Controller Class Initialized
ERROR - 2020-09-11 12:45:24 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:45:24 --> Upload Class Initialized
INFO - 2020-09-11 12:45:24 --> Controller Class Initialized
ERROR - 2020-09-11 12:45:24 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:45:24 --> Utf8 Class Initialized
INFO - 2020-09-11 12:45:24 --> URI Class Initialized
INFO - 2020-09-11 12:45:24 --> Router Class Initialized
INFO - 2020-09-11 12:45:24 --> Output Class Initialized
INFO - 2020-09-11 12:45:24 --> Security Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:45:24 --> Input Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Loader Class Initialized
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Hooks Class Initialized
INFO - 2020-09-11 12:45:24 --> Helper loaded: url_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: form_helper
DEBUG - 2020-09-11 12:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:45:24 --> Utf8 Class Initialized
INFO - 2020-09-11 12:45:24 --> Helper loaded: file_helper
INFO - 2020-09-11 12:45:24 --> URI Class Initialized
INFO - 2020-09-11 12:45:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:45:24 --> Router Class Initialized
INFO - 2020-09-11 12:45:24 --> Output Class Initialized
INFO - 2020-09-11 12:45:24 --> Security Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:45:24 --> Input Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Language Class Initialized
INFO - 2020-09-11 12:45:24 --> Config Class Initialized
INFO - 2020-09-11 12:45:24 --> Database Driver Class Initialized
INFO - 2020-09-11 12:45:24 --> Loader Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:45:24 --> Helper loaded: url_helper
INFO - 2020-09-11 12:45:24 --> Upload Class Initialized
INFO - 2020-09-11 12:45:24 --> Helper loaded: form_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: file_helper
INFO - 2020-09-11 12:45:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:45:24 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:45:24 --> Controller Class Initialized
ERROR - 2020-09-11 12:45:24 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:45:24 --> Upload Class Initialized
INFO - 2020-09-11 12:45:24 --> Controller Class Initialized
ERROR - 2020-09-11 12:45:24 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:45:25 --> Config Class Initialized
INFO - 2020-09-11 12:45:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:45:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:45:25 --> Utf8 Class Initialized
INFO - 2020-09-11 12:45:25 --> URI Class Initialized
INFO - 2020-09-11 12:45:25 --> Router Class Initialized
INFO - 2020-09-11 12:45:25 --> Output Class Initialized
INFO - 2020-09-11 12:45:25 --> Security Class Initialized
DEBUG - 2020-09-11 12:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:45:25 --> Input Class Initialized
INFO - 2020-09-11 12:45:25 --> Language Class Initialized
INFO - 2020-09-11 12:45:25 --> Language Class Initialized
INFO - 2020-09-11 12:45:25 --> Config Class Initialized
INFO - 2020-09-11 12:45:25 --> Loader Class Initialized
INFO - 2020-09-11 12:45:25 --> Helper loaded: url_helper
INFO - 2020-09-11 12:45:25 --> Helper loaded: form_helper
INFO - 2020-09-11 12:45:25 --> Helper loaded: file_helper
INFO - 2020-09-11 12:45:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:45:25 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:45:25 --> Upload Class Initialized
INFO - 2020-09-11 12:45:25 --> Controller Class Initialized
ERROR - 2020-09-11 12:45:25 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:57:37 --> Config Class Initialized
INFO - 2020-09-11 12:57:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:57:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:57:37 --> Utf8 Class Initialized
INFO - 2020-09-11 12:57:37 --> URI Class Initialized
INFO - 2020-09-11 12:57:37 --> Router Class Initialized
INFO - 2020-09-11 12:57:37 --> Output Class Initialized
INFO - 2020-09-11 12:57:37 --> Security Class Initialized
DEBUG - 2020-09-11 12:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:57:37 --> Input Class Initialized
INFO - 2020-09-11 12:57:37 --> Language Class Initialized
INFO - 2020-09-11 12:57:37 --> Language Class Initialized
INFO - 2020-09-11 12:57:37 --> Config Class Initialized
INFO - 2020-09-11 12:57:37 --> Loader Class Initialized
INFO - 2020-09-11 12:57:37 --> Helper loaded: url_helper
INFO - 2020-09-11 12:57:37 --> Helper loaded: form_helper
INFO - 2020-09-11 12:57:37 --> Helper loaded: file_helper
INFO - 2020-09-11 12:57:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:57:37 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:57:37 --> Upload Class Initialized
INFO - 2020-09-11 12:57:38 --> Controller Class Initialized
ERROR - 2020-09-11 12:57:38 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:57:42 --> Config Class Initialized
INFO - 2020-09-11 12:57:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:57:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:57:42 --> Utf8 Class Initialized
INFO - 2020-09-11 12:57:42 --> URI Class Initialized
INFO - 2020-09-11 12:57:42 --> Router Class Initialized
INFO - 2020-09-11 12:57:42 --> Output Class Initialized
INFO - 2020-09-11 12:57:42 --> Security Class Initialized
DEBUG - 2020-09-11 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:57:42 --> Input Class Initialized
INFO - 2020-09-11 12:57:42 --> Language Class Initialized
INFO - 2020-09-11 12:57:42 --> Language Class Initialized
INFO - 2020-09-11 12:57:42 --> Config Class Initialized
INFO - 2020-09-11 12:57:42 --> Loader Class Initialized
INFO - 2020-09-11 12:57:42 --> Helper loaded: url_helper
INFO - 2020-09-11 12:57:42 --> Helper loaded: form_helper
INFO - 2020-09-11 12:57:42 --> Helper loaded: file_helper
INFO - 2020-09-11 12:57:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:57:42 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:57:42 --> Upload Class Initialized
INFO - 2020-09-11 12:57:42 --> Controller Class Initialized
ERROR - 2020-09-11 12:57:42 --> 404 Page Not Found: /index
INFO - 2020-09-11 12:57:45 --> Config Class Initialized
INFO - 2020-09-11 12:57:45 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:57:45 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:57:45 --> Utf8 Class Initialized
INFO - 2020-09-11 12:57:45 --> URI Class Initialized
INFO - 2020-09-11 12:57:45 --> Router Class Initialized
INFO - 2020-09-11 12:57:45 --> Output Class Initialized
INFO - 2020-09-11 12:57:45 --> Security Class Initialized
DEBUG - 2020-09-11 12:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:57:45 --> Input Class Initialized
INFO - 2020-09-11 12:57:45 --> Language Class Initialized
INFO - 2020-09-11 12:57:45 --> Language Class Initialized
INFO - 2020-09-11 12:57:45 --> Config Class Initialized
INFO - 2020-09-11 12:57:45 --> Loader Class Initialized
INFO - 2020-09-11 12:57:45 --> Helper loaded: url_helper
INFO - 2020-09-11 12:57:45 --> Helper loaded: form_helper
INFO - 2020-09-11 12:57:45 --> Helper loaded: file_helper
INFO - 2020-09-11 12:57:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 12:57:45 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 12:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:57:45 --> Upload Class Initialized
INFO - 2020-09-11 12:57:45 --> Controller Class Initialized
ERROR - 2020-09-11 12:57:45 --> 404 Page Not Found: /index
INFO - 2020-09-11 13:50:48 --> Config Class Initialized
INFO - 2020-09-11 13:50:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:50:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:50:48 --> Utf8 Class Initialized
INFO - 2020-09-11 13:50:48 --> URI Class Initialized
DEBUG - 2020-09-11 13:50:48 --> No URI present. Default controller set.
INFO - 2020-09-11 13:50:48 --> Router Class Initialized
INFO - 2020-09-11 13:50:48 --> Output Class Initialized
INFO - 2020-09-11 13:50:48 --> Security Class Initialized
DEBUG - 2020-09-11 13:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:50:48 --> Input Class Initialized
INFO - 2020-09-11 13:50:48 --> Language Class Initialized
INFO - 2020-09-11 13:50:48 --> Language Class Initialized
INFO - 2020-09-11 13:50:48 --> Config Class Initialized
INFO - 2020-09-11 13:50:48 --> Loader Class Initialized
INFO - 2020-09-11 13:50:48 --> Helper loaded: url_helper
INFO - 2020-09-11 13:50:48 --> Helper loaded: form_helper
INFO - 2020-09-11 13:50:48 --> Helper loaded: file_helper
INFO - 2020-09-11 13:50:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 13:50:48 --> Database Driver Class Initialized
DEBUG - 2020-09-11 13:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 13:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:50:48 --> Upload Class Initialized
INFO - 2020-09-11 13:50:48 --> Controller Class Initialized
DEBUG - 2020-09-11 13:50:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 13:50:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 13:50:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 13:50:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 13:50:48 --> Final output sent to browser
DEBUG - 2020-09-11 13:50:48 --> Total execution time: 0.0550
INFO - 2020-09-11 13:51:20 --> Config Class Initialized
INFO - 2020-09-11 13:51:20 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:51:20 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:51:20 --> Utf8 Class Initialized
INFO - 2020-09-11 13:51:20 --> URI Class Initialized
INFO - 2020-09-11 13:51:20 --> Router Class Initialized
INFO - 2020-09-11 13:51:20 --> Output Class Initialized
INFO - 2020-09-11 13:51:20 --> Security Class Initialized
DEBUG - 2020-09-11 13:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:51:20 --> Input Class Initialized
INFO - 2020-09-11 13:51:20 --> Language Class Initialized
INFO - 2020-09-11 13:51:20 --> Language Class Initialized
INFO - 2020-09-11 13:51:20 --> Config Class Initialized
INFO - 2020-09-11 13:51:20 --> Loader Class Initialized
INFO - 2020-09-11 13:51:20 --> Helper loaded: url_helper
INFO - 2020-09-11 13:51:20 --> Helper loaded: form_helper
INFO - 2020-09-11 13:51:20 --> Helper loaded: file_helper
INFO - 2020-09-11 13:51:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 13:51:20 --> Database Driver Class Initialized
DEBUG - 2020-09-11 13:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 13:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:51:20 --> Upload Class Initialized
INFO - 2020-09-11 13:51:20 --> Controller Class Initialized
ERROR - 2020-09-11 13:51:20 --> 404 Page Not Found: /index
INFO - 2020-09-11 13:51:20 --> Config Class Initialized
INFO - 2020-09-11 13:51:20 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:51:20 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:51:20 --> Utf8 Class Initialized
INFO - 2020-09-11 13:51:20 --> URI Class Initialized
INFO - 2020-09-11 13:51:20 --> Router Class Initialized
INFO - 2020-09-11 13:51:20 --> Output Class Initialized
INFO - 2020-09-11 13:51:20 --> Security Class Initialized
DEBUG - 2020-09-11 13:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:51:20 --> Input Class Initialized
INFO - 2020-09-11 13:51:20 --> Language Class Initialized
INFO - 2020-09-11 13:51:20 --> Language Class Initialized
INFO - 2020-09-11 13:51:20 --> Config Class Initialized
INFO - 2020-09-11 13:51:20 --> Loader Class Initialized
INFO - 2020-09-11 13:51:20 --> Helper loaded: url_helper
INFO - 2020-09-11 13:51:20 --> Helper loaded: form_helper
INFO - 2020-09-11 13:51:20 --> Helper loaded: file_helper
INFO - 2020-09-11 13:51:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 13:51:21 --> Database Driver Class Initialized
DEBUG - 2020-09-11 13:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:51:21 --> Upload Class Initialized
INFO - 2020-09-11 13:51:21 --> Controller Class Initialized
ERROR - 2020-09-11 13:51:21 --> 404 Page Not Found: /index
INFO - 2020-09-11 13:51:21 --> Config Class Initialized
INFO - 2020-09-11 13:51:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:51:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:51:21 --> Utf8 Class Initialized
INFO - 2020-09-11 13:51:21 --> URI Class Initialized
INFO - 2020-09-11 13:51:21 --> Router Class Initialized
INFO - 2020-09-11 13:51:21 --> Output Class Initialized
INFO - 2020-09-11 13:51:21 --> Security Class Initialized
DEBUG - 2020-09-11 13:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:51:21 --> Input Class Initialized
INFO - 2020-09-11 13:51:21 --> Language Class Initialized
INFO - 2020-09-11 13:51:21 --> Language Class Initialized
INFO - 2020-09-11 13:51:21 --> Config Class Initialized
INFO - 2020-09-11 13:51:21 --> Loader Class Initialized
INFO - 2020-09-11 13:51:21 --> Helper loaded: url_helper
INFO - 2020-09-11 13:51:21 --> Helper loaded: form_helper
INFO - 2020-09-11 13:51:21 --> Helper loaded: file_helper
INFO - 2020-09-11 13:51:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 13:51:21 --> Database Driver Class Initialized
DEBUG - 2020-09-11 13:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:51:21 --> Upload Class Initialized
INFO - 2020-09-11 13:51:21 --> Controller Class Initialized
ERROR - 2020-09-11 13:51:21 --> 404 Page Not Found: /index
INFO - 2020-09-11 13:51:22 --> Config Class Initialized
INFO - 2020-09-11 13:51:22 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:51:22 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:51:22 --> Utf8 Class Initialized
INFO - 2020-09-11 13:51:22 --> URI Class Initialized
INFO - 2020-09-11 13:51:22 --> Router Class Initialized
INFO - 2020-09-11 13:51:22 --> Output Class Initialized
INFO - 2020-09-11 13:51:22 --> Security Class Initialized
DEBUG - 2020-09-11 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:51:22 --> Input Class Initialized
INFO - 2020-09-11 13:51:22 --> Language Class Initialized
INFO - 2020-09-11 13:51:22 --> Language Class Initialized
INFO - 2020-09-11 13:51:22 --> Config Class Initialized
INFO - 2020-09-11 13:51:22 --> Loader Class Initialized
INFO - 2020-09-11 13:51:22 --> Helper loaded: url_helper
INFO - 2020-09-11 13:51:22 --> Helper loaded: form_helper
INFO - 2020-09-11 13:51:22 --> Helper loaded: file_helper
INFO - 2020-09-11 13:51:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 13:51:22 --> Database Driver Class Initialized
DEBUG - 2020-09-11 13:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 13:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:51:22 --> Upload Class Initialized
INFO - 2020-09-11 13:51:22 --> Controller Class Initialized
ERROR - 2020-09-11 13:51:22 --> 404 Page Not Found: /index
INFO - 2020-09-11 13:52:30 --> Config Class Initialized
INFO - 2020-09-11 13:52:30 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:52:30 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:52:30 --> Utf8 Class Initialized
INFO - 2020-09-11 13:52:30 --> URI Class Initialized
INFO - 2020-09-11 13:52:30 --> Router Class Initialized
INFO - 2020-09-11 13:52:30 --> Output Class Initialized
INFO - 2020-09-11 13:52:30 --> Security Class Initialized
DEBUG - 2020-09-11 13:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:52:30 --> Input Class Initialized
INFO - 2020-09-11 13:52:30 --> Language Class Initialized
INFO - 2020-09-11 13:52:30 --> Language Class Initialized
INFO - 2020-09-11 13:52:30 --> Config Class Initialized
INFO - 2020-09-11 13:52:30 --> Loader Class Initialized
INFO - 2020-09-11 13:52:30 --> Helper loaded: url_helper
INFO - 2020-09-11 13:52:30 --> Helper loaded: form_helper
INFO - 2020-09-11 13:52:30 --> Helper loaded: file_helper
INFO - 2020-09-11 13:52:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 13:52:30 --> Database Driver Class Initialized
DEBUG - 2020-09-11 13:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 13:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:52:30 --> Upload Class Initialized
INFO - 2020-09-11 13:52:30 --> Controller Class Initialized
ERROR - 2020-09-11 13:52:30 --> 404 Page Not Found: /index
INFO - 2020-09-11 14:18:13 --> Config Class Initialized
INFO - 2020-09-11 14:18:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 14:18:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 14:18:13 --> Utf8 Class Initialized
INFO - 2020-09-11 14:18:13 --> URI Class Initialized
DEBUG - 2020-09-11 14:18:13 --> No URI present. Default controller set.
INFO - 2020-09-11 14:18:13 --> Router Class Initialized
INFO - 2020-09-11 14:18:13 --> Output Class Initialized
INFO - 2020-09-11 14:18:13 --> Security Class Initialized
DEBUG - 2020-09-11 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 14:18:13 --> Input Class Initialized
INFO - 2020-09-11 14:18:13 --> Language Class Initialized
INFO - 2020-09-11 14:18:13 --> Language Class Initialized
INFO - 2020-09-11 14:18:13 --> Config Class Initialized
INFO - 2020-09-11 14:18:13 --> Loader Class Initialized
INFO - 2020-09-11 14:18:13 --> Helper loaded: url_helper
INFO - 2020-09-11 14:18:13 --> Helper loaded: form_helper
INFO - 2020-09-11 14:18:13 --> Helper loaded: file_helper
INFO - 2020-09-11 14:18:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 14:18:13 --> Database Driver Class Initialized
DEBUG - 2020-09-11 14:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 14:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 14:18:13 --> Upload Class Initialized
INFO - 2020-09-11 14:18:13 --> Controller Class Initialized
DEBUG - 2020-09-11 14:18:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 14:18:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 14:18:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 14:18:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 14:18:13 --> Final output sent to browser
DEBUG - 2020-09-11 14:18:13 --> Total execution time: 0.0613
INFO - 2020-09-11 16:05:19 --> Config Class Initialized
INFO - 2020-09-11 16:05:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:05:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:05:19 --> Utf8 Class Initialized
INFO - 2020-09-11 16:05:19 --> URI Class Initialized
INFO - 2020-09-11 16:05:19 --> Router Class Initialized
INFO - 2020-09-11 16:05:19 --> Output Class Initialized
INFO - 2020-09-11 16:05:19 --> Security Class Initialized
DEBUG - 2020-09-11 16:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:05:19 --> Input Class Initialized
INFO - 2020-09-11 16:05:19 --> Language Class Initialized
INFO - 2020-09-11 16:05:19 --> Language Class Initialized
INFO - 2020-09-11 16:05:19 --> Config Class Initialized
INFO - 2020-09-11 16:05:19 --> Loader Class Initialized
INFO - 2020-09-11 16:05:19 --> Helper loaded: url_helper
INFO - 2020-09-11 16:05:19 --> Helper loaded: form_helper
INFO - 2020-09-11 16:05:19 --> Helper loaded: file_helper
INFO - 2020-09-11 16:05:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:05:19 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:05:19 --> Upload Class Initialized
INFO - 2020-09-11 16:05:19 --> Controller Class Initialized
ERROR - 2020-09-11 16:05:19 --> 404 Page Not Found: /index
INFO - 2020-09-11 16:05:20 --> Config Class Initialized
INFO - 2020-09-11 16:05:20 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:05:20 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:05:20 --> Utf8 Class Initialized
INFO - 2020-09-11 16:05:20 --> URI Class Initialized
DEBUG - 2020-09-11 16:05:20 --> No URI present. Default controller set.
INFO - 2020-09-11 16:05:20 --> Router Class Initialized
INFO - 2020-09-11 16:05:20 --> Output Class Initialized
INFO - 2020-09-11 16:05:20 --> Security Class Initialized
DEBUG - 2020-09-11 16:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:05:20 --> Input Class Initialized
INFO - 2020-09-11 16:05:20 --> Language Class Initialized
INFO - 2020-09-11 16:05:20 --> Language Class Initialized
INFO - 2020-09-11 16:05:20 --> Config Class Initialized
INFO - 2020-09-11 16:05:20 --> Loader Class Initialized
INFO - 2020-09-11 16:05:20 --> Helper loaded: url_helper
INFO - 2020-09-11 16:05:20 --> Helper loaded: form_helper
INFO - 2020-09-11 16:05:20 --> Helper loaded: file_helper
INFO - 2020-09-11 16:05:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:05:20 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:05:20 --> Upload Class Initialized
INFO - 2020-09-11 16:05:20 --> Controller Class Initialized
DEBUG - 2020-09-11 16:05:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 16:05:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 16:05:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 16:05:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 16:05:20 --> Final output sent to browser
DEBUG - 2020-09-11 16:05:20 --> Total execution time: 0.0405
INFO - 2020-09-11 16:05:23 --> Config Class Initialized
INFO - 2020-09-11 16:05:23 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:05:23 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:05:23 --> Utf8 Class Initialized
INFO - 2020-09-11 16:05:23 --> URI Class Initialized
INFO - 2020-09-11 16:05:23 --> Router Class Initialized
INFO - 2020-09-11 16:05:23 --> Output Class Initialized
INFO - 2020-09-11 16:05:23 --> Security Class Initialized
DEBUG - 2020-09-11 16:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:05:23 --> Input Class Initialized
INFO - 2020-09-11 16:05:23 --> Language Class Initialized
INFO - 2020-09-11 16:05:23 --> Language Class Initialized
INFO - 2020-09-11 16:05:23 --> Config Class Initialized
INFO - 2020-09-11 16:05:23 --> Loader Class Initialized
INFO - 2020-09-11 16:05:23 --> Helper loaded: url_helper
INFO - 2020-09-11 16:05:23 --> Helper loaded: form_helper
INFO - 2020-09-11 16:05:23 --> Helper loaded: file_helper
INFO - 2020-09-11 16:05:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:05:23 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:05:23 --> Upload Class Initialized
INFO - 2020-09-11 16:05:23 --> Controller Class Initialized
ERROR - 2020-09-11 16:05:23 --> 404 Page Not Found: /index
INFO - 2020-09-11 16:32:56 --> Config Class Initialized
INFO - 2020-09-11 16:32:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:32:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:32:56 --> Utf8 Class Initialized
INFO - 2020-09-11 16:32:56 --> URI Class Initialized
DEBUG - 2020-09-11 16:32:56 --> No URI present. Default controller set.
INFO - 2020-09-11 16:32:56 --> Router Class Initialized
INFO - 2020-09-11 16:32:56 --> Output Class Initialized
INFO - 2020-09-11 16:32:56 --> Security Class Initialized
DEBUG - 2020-09-11 16:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:32:56 --> Input Class Initialized
INFO - 2020-09-11 16:32:56 --> Language Class Initialized
INFO - 2020-09-11 16:32:56 --> Language Class Initialized
INFO - 2020-09-11 16:32:56 --> Config Class Initialized
INFO - 2020-09-11 16:32:56 --> Loader Class Initialized
INFO - 2020-09-11 16:32:56 --> Helper loaded: url_helper
INFO - 2020-09-11 16:32:56 --> Helper loaded: form_helper
INFO - 2020-09-11 16:32:56 --> Helper loaded: file_helper
INFO - 2020-09-11 16:32:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:32:56 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:32:56 --> Upload Class Initialized
INFO - 2020-09-11 16:32:56 --> Controller Class Initialized
DEBUG - 2020-09-11 16:32:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 16:32:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 16:32:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 16:32:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 16:32:56 --> Final output sent to browser
DEBUG - 2020-09-11 16:32:56 --> Total execution time: 0.0440
INFO - 2020-09-11 16:33:36 --> Config Class Initialized
INFO - 2020-09-11 16:33:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:33:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:33:36 --> Utf8 Class Initialized
INFO - 2020-09-11 16:33:36 --> URI Class Initialized
INFO - 2020-09-11 16:33:36 --> Router Class Initialized
INFO - 2020-09-11 16:33:36 --> Output Class Initialized
INFO - 2020-09-11 16:33:36 --> Security Class Initialized
DEBUG - 2020-09-11 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:33:36 --> Input Class Initialized
INFO - 2020-09-11 16:33:36 --> Language Class Initialized
INFO - 2020-09-11 16:33:36 --> Language Class Initialized
INFO - 2020-09-11 16:33:36 --> Config Class Initialized
INFO - 2020-09-11 16:33:36 --> Loader Class Initialized
INFO - 2020-09-11 16:33:36 --> Helper loaded: url_helper
INFO - 2020-09-11 16:33:36 --> Helper loaded: form_helper
INFO - 2020-09-11 16:33:36 --> Helper loaded: file_helper
INFO - 2020-09-11 16:33:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:33:36 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:33:36 --> Upload Class Initialized
INFO - 2020-09-11 16:33:36 --> Controller Class Initialized
ERROR - 2020-09-11 16:33:36 --> 404 Page Not Found: /index
INFO - 2020-09-11 16:33:36 --> Config Class Initialized
INFO - 2020-09-11 16:33:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:33:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:33:36 --> Utf8 Class Initialized
INFO - 2020-09-11 16:33:36 --> URI Class Initialized
INFO - 2020-09-11 16:33:36 --> Router Class Initialized
INFO - 2020-09-11 16:33:36 --> Output Class Initialized
INFO - 2020-09-11 16:33:36 --> Security Class Initialized
DEBUG - 2020-09-11 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:33:36 --> Input Class Initialized
INFO - 2020-09-11 16:33:36 --> Language Class Initialized
INFO - 2020-09-11 16:33:36 --> Language Class Initialized
INFO - 2020-09-11 16:33:36 --> Config Class Initialized
INFO - 2020-09-11 16:33:36 --> Loader Class Initialized
INFO - 2020-09-11 16:33:36 --> Helper loaded: url_helper
INFO - 2020-09-11 16:33:36 --> Helper loaded: form_helper
INFO - 2020-09-11 16:33:36 --> Helper loaded: file_helper
INFO - 2020-09-11 16:33:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:33:36 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:33:36 --> Upload Class Initialized
INFO - 2020-09-11 16:33:36 --> Controller Class Initialized
ERROR - 2020-09-11 16:33:36 --> 404 Page Not Found: /index
INFO - 2020-09-11 16:33:37 --> Config Class Initialized
INFO - 2020-09-11 16:33:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:33:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:33:37 --> Utf8 Class Initialized
INFO - 2020-09-11 16:33:37 --> URI Class Initialized
INFO - 2020-09-11 16:33:37 --> Router Class Initialized
INFO - 2020-09-11 16:33:37 --> Output Class Initialized
INFO - 2020-09-11 16:33:37 --> Security Class Initialized
DEBUG - 2020-09-11 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:33:37 --> Input Class Initialized
INFO - 2020-09-11 16:33:37 --> Language Class Initialized
INFO - 2020-09-11 16:33:37 --> Language Class Initialized
INFO - 2020-09-11 16:33:37 --> Config Class Initialized
INFO - 2020-09-11 16:33:37 --> Loader Class Initialized
INFO - 2020-09-11 16:33:37 --> Helper loaded: url_helper
INFO - 2020-09-11 16:33:37 --> Helper loaded: form_helper
INFO - 2020-09-11 16:33:37 --> Helper loaded: file_helper
INFO - 2020-09-11 16:33:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:33:37 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:33:37 --> Upload Class Initialized
INFO - 2020-09-11 16:33:37 --> Controller Class Initialized
ERROR - 2020-09-11 16:33:37 --> 404 Page Not Found: /index
INFO - 2020-09-11 16:33:37 --> Config Class Initialized
INFO - 2020-09-11 16:33:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:33:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:33:37 --> Utf8 Class Initialized
INFO - 2020-09-11 16:33:37 --> URI Class Initialized
INFO - 2020-09-11 16:33:37 --> Router Class Initialized
INFO - 2020-09-11 16:33:37 --> Output Class Initialized
INFO - 2020-09-11 16:33:37 --> Security Class Initialized
DEBUG - 2020-09-11 16:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:33:37 --> Input Class Initialized
INFO - 2020-09-11 16:33:37 --> Language Class Initialized
INFO - 2020-09-11 16:33:37 --> Language Class Initialized
INFO - 2020-09-11 16:33:37 --> Config Class Initialized
INFO - 2020-09-11 16:33:37 --> Loader Class Initialized
INFO - 2020-09-11 16:33:37 --> Helper loaded: url_helper
INFO - 2020-09-11 16:33:37 --> Helper loaded: form_helper
INFO - 2020-09-11 16:33:37 --> Helper loaded: file_helper
INFO - 2020-09-11 16:33:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:33:37 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:33:37 --> Upload Class Initialized
INFO - 2020-09-11 16:33:37 --> Controller Class Initialized
ERROR - 2020-09-11 16:33:37 --> 404 Page Not Found: /index
INFO - 2020-09-11 16:38:43 --> Config Class Initialized
INFO - 2020-09-11 16:38:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:38:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:38:43 --> Utf8 Class Initialized
INFO - 2020-09-11 16:38:43 --> URI Class Initialized
DEBUG - 2020-09-11 16:38:43 --> No URI present. Default controller set.
INFO - 2020-09-11 16:38:43 --> Router Class Initialized
INFO - 2020-09-11 16:38:43 --> Output Class Initialized
INFO - 2020-09-11 16:38:43 --> Security Class Initialized
DEBUG - 2020-09-11 16:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:38:43 --> Input Class Initialized
INFO - 2020-09-11 16:38:43 --> Language Class Initialized
INFO - 2020-09-11 16:38:43 --> Language Class Initialized
INFO - 2020-09-11 16:38:43 --> Config Class Initialized
INFO - 2020-09-11 16:38:43 --> Loader Class Initialized
INFO - 2020-09-11 16:38:43 --> Helper loaded: url_helper
INFO - 2020-09-11 16:38:43 --> Helper loaded: form_helper
INFO - 2020-09-11 16:38:43 --> Helper loaded: file_helper
INFO - 2020-09-11 16:38:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:38:43 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:38:43 --> Upload Class Initialized
INFO - 2020-09-11 16:38:43 --> Controller Class Initialized
DEBUG - 2020-09-11 16:38:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 16:38:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 16:38:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 16:38:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 16:38:43 --> Final output sent to browser
DEBUG - 2020-09-11 16:38:43 --> Total execution time: 0.0468
INFO - 2020-09-11 16:39:15 --> Config Class Initialized
INFO - 2020-09-11 16:39:15 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:39:15 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:39:15 --> Utf8 Class Initialized
INFO - 2020-09-11 16:39:15 --> URI Class Initialized
DEBUG - 2020-09-11 16:39:15 --> No URI present. Default controller set.
INFO - 2020-09-11 16:39:15 --> Router Class Initialized
INFO - 2020-09-11 16:39:15 --> Output Class Initialized
INFO - 2020-09-11 16:39:15 --> Security Class Initialized
DEBUG - 2020-09-11 16:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:39:15 --> Input Class Initialized
INFO - 2020-09-11 16:39:15 --> Language Class Initialized
INFO - 2020-09-11 16:39:15 --> Language Class Initialized
INFO - 2020-09-11 16:39:15 --> Config Class Initialized
INFO - 2020-09-11 16:39:15 --> Loader Class Initialized
INFO - 2020-09-11 16:39:15 --> Helper loaded: url_helper
INFO - 2020-09-11 16:39:15 --> Helper loaded: form_helper
INFO - 2020-09-11 16:39:15 --> Helper loaded: file_helper
INFO - 2020-09-11 16:39:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:39:15 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:39:15 --> Upload Class Initialized
INFO - 2020-09-11 16:39:15 --> Controller Class Initialized
DEBUG - 2020-09-11 16:39:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 16:39:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 16:39:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 16:39:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 16:39:15 --> Final output sent to browser
DEBUG - 2020-09-11 16:39:15 --> Total execution time: 0.0568
INFO - 2020-09-11 16:49:51 --> Config Class Initialized
INFO - 2020-09-11 16:49:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 16:49:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 16:49:51 --> Utf8 Class Initialized
INFO - 2020-09-11 16:49:51 --> URI Class Initialized
DEBUG - 2020-09-11 16:49:51 --> No URI present. Default controller set.
INFO - 2020-09-11 16:49:51 --> Router Class Initialized
INFO - 2020-09-11 16:49:51 --> Output Class Initialized
INFO - 2020-09-11 16:49:51 --> Security Class Initialized
DEBUG - 2020-09-11 16:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 16:49:51 --> Input Class Initialized
INFO - 2020-09-11 16:49:51 --> Language Class Initialized
INFO - 2020-09-11 16:49:51 --> Language Class Initialized
INFO - 2020-09-11 16:49:51 --> Config Class Initialized
INFO - 2020-09-11 16:49:51 --> Loader Class Initialized
INFO - 2020-09-11 16:49:51 --> Helper loaded: url_helper
INFO - 2020-09-11 16:49:51 --> Helper loaded: form_helper
INFO - 2020-09-11 16:49:51 --> Helper loaded: file_helper
INFO - 2020-09-11 16:49:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 16:49:51 --> Database Driver Class Initialized
DEBUG - 2020-09-11 16:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 16:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 16:49:51 --> Upload Class Initialized
INFO - 2020-09-11 16:49:51 --> Controller Class Initialized
DEBUG - 2020-09-11 16:49:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 16:49:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 16:49:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 16:49:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 16:49:51 --> Final output sent to browser
DEBUG - 2020-09-11 16:49:51 --> Total execution time: 0.0530
INFO - 2020-09-11 17:02:50 --> Config Class Initialized
INFO - 2020-09-11 17:02:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:02:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:02:50 --> Utf8 Class Initialized
INFO - 2020-09-11 17:02:50 --> URI Class Initialized
DEBUG - 2020-09-11 17:02:50 --> No URI present. Default controller set.
INFO - 2020-09-11 17:02:50 --> Router Class Initialized
INFO - 2020-09-11 17:02:50 --> Output Class Initialized
INFO - 2020-09-11 17:02:50 --> Security Class Initialized
DEBUG - 2020-09-11 17:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:02:50 --> Input Class Initialized
INFO - 2020-09-11 17:02:50 --> Language Class Initialized
INFO - 2020-09-11 17:02:50 --> Language Class Initialized
INFO - 2020-09-11 17:02:50 --> Config Class Initialized
INFO - 2020-09-11 17:02:50 --> Loader Class Initialized
INFO - 2020-09-11 17:02:50 --> Helper loaded: url_helper
INFO - 2020-09-11 17:02:50 --> Helper loaded: form_helper
INFO - 2020-09-11 17:02:50 --> Helper loaded: file_helper
INFO - 2020-09-11 17:02:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:02:50 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:02:50 --> Upload Class Initialized
INFO - 2020-09-11 17:02:50 --> Controller Class Initialized
DEBUG - 2020-09-11 17:02:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 17:02:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 17:02:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 17:02:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 17:02:50 --> Final output sent to browser
DEBUG - 2020-09-11 17:02:50 --> Total execution time: 0.0551
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:02:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:02:51 --> Utf8 Class Initialized
INFO - 2020-09-11 17:02:51 --> URI Class Initialized
INFO - 2020-09-11 17:02:51 --> Router Class Initialized
INFO - 2020-09-11 17:02:51 --> Output Class Initialized
INFO - 2020-09-11 17:02:51 --> Security Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:02:51 --> Input Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Loader Class Initialized
INFO - 2020-09-11 17:02:51 --> Helper loaded: url_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: form_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: file_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:02:51 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:02:51 --> Upload Class Initialized
INFO - 2020-09-11 17:02:51 --> Controller Class Initialized
ERROR - 2020-09-11 17:02:51 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:02:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:02:51 --> Utf8 Class Initialized
INFO - 2020-09-11 17:02:51 --> URI Class Initialized
INFO - 2020-09-11 17:02:51 --> Router Class Initialized
INFO - 2020-09-11 17:02:51 --> Output Class Initialized
INFO - 2020-09-11 17:02:51 --> Security Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:02:51 --> Input Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Loader Class Initialized
INFO - 2020-09-11 17:02:51 --> Helper loaded: url_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: form_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: file_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:02:51 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:02:51 --> Upload Class Initialized
INFO - 2020-09-11 17:02:51 --> Controller Class Initialized
ERROR - 2020-09-11 17:02:51 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:02:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:02:51 --> Utf8 Class Initialized
INFO - 2020-09-11 17:02:51 --> URI Class Initialized
INFO - 2020-09-11 17:02:51 --> Router Class Initialized
INFO - 2020-09-11 17:02:51 --> Output Class Initialized
INFO - 2020-09-11 17:02:51 --> Security Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:02:51 --> Input Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Loader Class Initialized
INFO - 2020-09-11 17:02:51 --> Helper loaded: url_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: form_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: file_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:02:51 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:02:51 --> Upload Class Initialized
INFO - 2020-09-11 17:02:51 --> Controller Class Initialized
ERROR - 2020-09-11 17:02:51 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:02:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:02:51 --> Utf8 Class Initialized
INFO - 2020-09-11 17:02:51 --> URI Class Initialized
INFO - 2020-09-11 17:02:51 --> Router Class Initialized
INFO - 2020-09-11 17:02:51 --> Output Class Initialized
INFO - 2020-09-11 17:02:51 --> Security Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:02:51 --> Input Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Language Class Initialized
INFO - 2020-09-11 17:02:51 --> Config Class Initialized
INFO - 2020-09-11 17:02:51 --> Loader Class Initialized
INFO - 2020-09-11 17:02:51 --> Helper loaded: url_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: form_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: file_helper
INFO - 2020-09-11 17:02:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:02:51 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:02:51 --> Upload Class Initialized
INFO - 2020-09-11 17:02:51 --> Controller Class Initialized
ERROR - 2020-09-11 17:02:51 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:02:52 --> Config Class Initialized
INFO - 2020-09-11 17:02:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:02:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:02:52 --> Utf8 Class Initialized
INFO - 2020-09-11 17:02:52 --> URI Class Initialized
INFO - 2020-09-11 17:02:52 --> Router Class Initialized
INFO - 2020-09-11 17:02:52 --> Output Class Initialized
INFO - 2020-09-11 17:02:52 --> Security Class Initialized
DEBUG - 2020-09-11 17:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:02:52 --> Input Class Initialized
INFO - 2020-09-11 17:02:52 --> Language Class Initialized
INFO - 2020-09-11 17:02:52 --> Language Class Initialized
INFO - 2020-09-11 17:02:52 --> Config Class Initialized
INFO - 2020-09-11 17:02:52 --> Loader Class Initialized
INFO - 2020-09-11 17:02:52 --> Helper loaded: url_helper
INFO - 2020-09-11 17:02:52 --> Helper loaded: form_helper
INFO - 2020-09-11 17:02:52 --> Helper loaded: file_helper
INFO - 2020-09-11 17:02:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:02:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:02:52 --> Upload Class Initialized
INFO - 2020-09-11 17:02:52 --> Controller Class Initialized
ERROR - 2020-09-11 17:02:52 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:03:41 --> Config Class Initialized
INFO - 2020-09-11 17:03:41 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:03:41 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:03:41 --> Utf8 Class Initialized
INFO - 2020-09-11 17:03:41 --> URI Class Initialized
DEBUG - 2020-09-11 17:03:41 --> No URI present. Default controller set.
INFO - 2020-09-11 17:03:41 --> Router Class Initialized
INFO - 2020-09-11 17:03:41 --> Output Class Initialized
INFO - 2020-09-11 17:03:41 --> Security Class Initialized
DEBUG - 2020-09-11 17:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:03:41 --> Input Class Initialized
INFO - 2020-09-11 17:03:41 --> Language Class Initialized
INFO - 2020-09-11 17:03:41 --> Language Class Initialized
INFO - 2020-09-11 17:03:41 --> Config Class Initialized
INFO - 2020-09-11 17:03:41 --> Loader Class Initialized
INFO - 2020-09-11 17:03:41 --> Helper loaded: url_helper
INFO - 2020-09-11 17:03:41 --> Helper loaded: form_helper
INFO - 2020-09-11 17:03:41 --> Helper loaded: file_helper
INFO - 2020-09-11 17:03:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:03:41 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:03:41 --> Upload Class Initialized
INFO - 2020-09-11 17:03:41 --> Controller Class Initialized
DEBUG - 2020-09-11 17:03:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 17:03:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 17:03:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 17:03:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 17:03:41 --> Final output sent to browser
DEBUG - 2020-09-11 17:03:41 --> Total execution time: 0.0561
INFO - 2020-09-11 17:03:57 --> Config Class Initialized
INFO - 2020-09-11 17:03:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:03:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:03:57 --> Utf8 Class Initialized
INFO - 2020-09-11 17:03:57 --> URI Class Initialized
INFO - 2020-09-11 17:03:57 --> Router Class Initialized
INFO - 2020-09-11 17:03:57 --> Output Class Initialized
INFO - 2020-09-11 17:03:57 --> Security Class Initialized
DEBUG - 2020-09-11 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:03:57 --> Input Class Initialized
INFO - 2020-09-11 17:03:57 --> Language Class Initialized
INFO - 2020-09-11 17:03:57 --> Language Class Initialized
INFO - 2020-09-11 17:03:57 --> Config Class Initialized
INFO - 2020-09-11 17:03:57 --> Loader Class Initialized
INFO - 2020-09-11 17:03:57 --> Helper loaded: url_helper
INFO - 2020-09-11 17:03:57 --> Helper loaded: form_helper
INFO - 2020-09-11 17:03:57 --> Helper loaded: file_helper
INFO - 2020-09-11 17:03:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:03:57 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:03:57 --> Upload Class Initialized
INFO - 2020-09-11 17:03:57 --> Controller Class Initialized
ERROR - 2020-09-11 17:03:57 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:03:58 --> Config Class Initialized
INFO - 2020-09-11 17:03:58 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:03:58 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:03:58 --> Utf8 Class Initialized
INFO - 2020-09-11 17:03:58 --> URI Class Initialized
INFO - 2020-09-11 17:03:58 --> Router Class Initialized
INFO - 2020-09-11 17:03:58 --> Config Class Initialized
INFO - 2020-09-11 17:03:58 --> Output Class Initialized
INFO - 2020-09-11 17:03:58 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:03:58 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:03:58 --> Security Class Initialized
INFO - 2020-09-11 17:03:58 --> Utf8 Class Initialized
INFO - 2020-09-11 17:03:58 --> URI Class Initialized
DEBUG - 2020-09-11 17:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:03:58 --> Input Class Initialized
INFO - 2020-09-11 17:03:58 --> Language Class Initialized
INFO - 2020-09-11 17:03:58 --> Router Class Initialized
INFO - 2020-09-11 17:03:58 --> Language Class Initialized
INFO - 2020-09-11 17:03:58 --> Config Class Initialized
INFO - 2020-09-11 17:03:58 --> Output Class Initialized
INFO - 2020-09-11 17:03:58 --> Security Class Initialized
DEBUG - 2020-09-11 17:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:03:58 --> Input Class Initialized
INFO - 2020-09-11 17:03:58 --> Loader Class Initialized
INFO - 2020-09-11 17:03:58 --> Language Class Initialized
INFO - 2020-09-11 17:03:58 --> Language Class Initialized
INFO - 2020-09-11 17:03:58 --> Config Class Initialized
INFO - 2020-09-11 17:03:58 --> Helper loaded: url_helper
INFO - 2020-09-11 17:03:58 --> Helper loaded: form_helper
INFO - 2020-09-11 17:03:58 --> Loader Class Initialized
INFO - 2020-09-11 17:03:58 --> Helper loaded: file_helper
INFO - 2020-09-11 17:03:58 --> Helper loaded: url_helper
INFO - 2020-09-11 17:03:58 --> Helper loaded: form_helper
INFO - 2020-09-11 17:03:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:03:58 --> Helper loaded: file_helper
INFO - 2020-09-11 17:03:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:03:58 --> Database Driver Class Initialized
INFO - 2020-09-11 17:03:58 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:03:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-11 17:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:03:58 --> Upload Class Initialized
INFO - 2020-09-11 17:03:58 --> Controller Class Initialized
ERROR - 2020-09-11 17:03:58 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:03:58 --> Upload Class Initialized
INFO - 2020-09-11 17:03:58 --> Controller Class Initialized
ERROR - 2020-09-11 17:03:58 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:04:05 --> Config Class Initialized
INFO - 2020-09-11 17:04:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:04:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:04:05 --> Utf8 Class Initialized
INFO - 2020-09-11 17:04:05 --> URI Class Initialized
INFO - 2020-09-11 17:04:05 --> Router Class Initialized
INFO - 2020-09-11 17:04:05 --> Output Class Initialized
INFO - 2020-09-11 17:04:05 --> Security Class Initialized
DEBUG - 2020-09-11 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:04:05 --> Input Class Initialized
INFO - 2020-09-11 17:04:05 --> Language Class Initialized
INFO - 2020-09-11 17:04:05 --> Language Class Initialized
INFO - 2020-09-11 17:04:05 --> Config Class Initialized
INFO - 2020-09-11 17:04:05 --> Loader Class Initialized
INFO - 2020-09-11 17:04:05 --> Helper loaded: url_helper
INFO - 2020-09-11 17:04:05 --> Helper loaded: form_helper
INFO - 2020-09-11 17:04:05 --> Helper loaded: file_helper
INFO - 2020-09-11 17:04:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:04:05 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:04:05 --> Upload Class Initialized
INFO - 2020-09-11 17:04:05 --> Controller Class Initialized
ERROR - 2020-09-11 17:04:05 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:11:24 --> Config Class Initialized
INFO - 2020-09-11 17:11:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:11:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:11:24 --> Utf8 Class Initialized
INFO - 2020-09-11 17:11:24 --> URI Class Initialized
DEBUG - 2020-09-11 17:11:24 --> No URI present. Default controller set.
INFO - 2020-09-11 17:11:24 --> Router Class Initialized
INFO - 2020-09-11 17:11:24 --> Output Class Initialized
INFO - 2020-09-11 17:11:24 --> Security Class Initialized
DEBUG - 2020-09-11 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:11:24 --> Input Class Initialized
INFO - 2020-09-11 17:11:24 --> Language Class Initialized
INFO - 2020-09-11 17:11:24 --> Language Class Initialized
INFO - 2020-09-11 17:11:24 --> Config Class Initialized
INFO - 2020-09-11 17:11:24 --> Loader Class Initialized
INFO - 2020-09-11 17:11:24 --> Helper loaded: url_helper
INFO - 2020-09-11 17:11:24 --> Helper loaded: form_helper
INFO - 2020-09-11 17:11:24 --> Helper loaded: file_helper
INFO - 2020-09-11 17:11:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:11:24 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:11:24 --> Upload Class Initialized
INFO - 2020-09-11 17:11:24 --> Controller Class Initialized
DEBUG - 2020-09-11 17:11:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 17:11:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 17:11:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 17:11:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 17:11:24 --> Final output sent to browser
DEBUG - 2020-09-11 17:11:24 --> Total execution time: 0.0567
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:11:27 --> Utf8 Class Initialized
INFO - 2020-09-11 17:11:27 --> URI Class Initialized
INFO - 2020-09-11 17:11:27 --> Router Class Initialized
INFO - 2020-09-11 17:11:27 --> Output Class Initialized
INFO - 2020-09-11 17:11:27 --> Security Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:11:27 --> Input Class Initialized
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Loader Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: url_helper
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Hooks Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: form_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: file_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-11 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:11:27 --> Utf8 Class Initialized
INFO - 2020-09-11 17:11:27 --> URI Class Initialized
INFO - 2020-09-11 17:11:27 --> Router Class Initialized
INFO - 2020-09-11 17:11:27 --> Output Class Initialized
INFO - 2020-09-11 17:11:27 --> Security Class Initialized
INFO - 2020-09-11 17:11:27 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-09-11 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:11:27 --> Input Class Initialized
INFO - 2020-09-11 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Upload Class Initialized
INFO - 2020-09-11 17:11:27 --> Loader Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: url_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: form_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: file_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:11:27 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:11:27 --> Utf8 Class Initialized
INFO - 2020-09-11 17:11:27 --> URI Class Initialized
INFO - 2020-09-11 17:11:27 --> Router Class Initialized
INFO - 2020-09-11 17:11:27 --> Output Class Initialized
INFO - 2020-09-11 17:11:27 --> Security Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:11:27 --> Input Class Initialized
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Loader Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: url_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: form_helper
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Hooks Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: file_helper
DEBUG - 2020-09-11 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:11:27 --> Utf8 Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:11:27 --> URI Class Initialized
INFO - 2020-09-11 17:11:27 --> Controller Class Initialized
ERROR - 2020-09-11 17:11:27 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:11:27 --> Upload Class Initialized
INFO - 2020-09-11 17:11:27 --> Database Driver Class Initialized
INFO - 2020-09-11 17:11:27 --> Router Class Initialized
INFO - 2020-09-11 17:11:27 --> Output Class Initialized
INFO - 2020-09-11 17:11:27 --> Security Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:11:27 --> Input Class Initialized
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:11:27 --> Language Class Initialized
INFO - 2020-09-11 17:11:27 --> Config Class Initialized
INFO - 2020-09-11 17:11:27 --> Loader Class Initialized
INFO - 2020-09-11 17:11:27 --> Helper loaded: url_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: form_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: file_helper
INFO - 2020-09-11 17:11:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:11:27 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:11:27 --> Controller Class Initialized
ERROR - 2020-09-11 17:11:27 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:11:27 --> Upload Class Initialized
INFO - 2020-09-11 17:11:27 --> Controller Class Initialized
ERROR - 2020-09-11 17:11:27 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:11:27 --> Upload Class Initialized
INFO - 2020-09-11 17:11:27 --> Controller Class Initialized
ERROR - 2020-09-11 17:11:27 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:11:30 --> Config Class Initialized
INFO - 2020-09-11 17:11:30 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:11:30 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:11:30 --> Utf8 Class Initialized
INFO - 2020-09-11 17:11:30 --> URI Class Initialized
INFO - 2020-09-11 17:11:30 --> Router Class Initialized
INFO - 2020-09-11 17:11:30 --> Output Class Initialized
INFO - 2020-09-11 17:11:30 --> Security Class Initialized
DEBUG - 2020-09-11 17:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:11:30 --> Input Class Initialized
INFO - 2020-09-11 17:11:30 --> Language Class Initialized
INFO - 2020-09-11 17:11:30 --> Language Class Initialized
INFO - 2020-09-11 17:11:30 --> Config Class Initialized
INFO - 2020-09-11 17:11:30 --> Loader Class Initialized
INFO - 2020-09-11 17:11:30 --> Helper loaded: url_helper
INFO - 2020-09-11 17:11:30 --> Helper loaded: form_helper
INFO - 2020-09-11 17:11:30 --> Helper loaded: file_helper
INFO - 2020-09-11 17:11:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:11:30 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:11:30 --> Upload Class Initialized
INFO - 2020-09-11 17:11:30 --> Controller Class Initialized
ERROR - 2020-09-11 17:11:30 --> 404 Page Not Found: /index
INFO - 2020-09-11 17:45:44 --> Config Class Initialized
INFO - 2020-09-11 17:45:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:45:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:45:44 --> Utf8 Class Initialized
INFO - 2020-09-11 17:45:44 --> URI Class Initialized
DEBUG - 2020-09-11 17:45:44 --> No URI present. Default controller set.
INFO - 2020-09-11 17:45:44 --> Router Class Initialized
INFO - 2020-09-11 17:45:44 --> Output Class Initialized
INFO - 2020-09-11 17:45:44 --> Security Class Initialized
DEBUG - 2020-09-11 17:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:45:44 --> Input Class Initialized
INFO - 2020-09-11 17:45:44 --> Language Class Initialized
INFO - 2020-09-11 17:45:44 --> Language Class Initialized
INFO - 2020-09-11 17:45:44 --> Config Class Initialized
INFO - 2020-09-11 17:45:44 --> Loader Class Initialized
INFO - 2020-09-11 17:45:44 --> Helper loaded: url_helper
INFO - 2020-09-11 17:45:44 --> Helper loaded: form_helper
INFO - 2020-09-11 17:45:44 --> Helper loaded: file_helper
INFO - 2020-09-11 17:45:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 17:45:44 --> Database Driver Class Initialized
DEBUG - 2020-09-11 17:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 17:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:45:44 --> Upload Class Initialized
INFO - 2020-09-11 17:45:44 --> Controller Class Initialized
DEBUG - 2020-09-11 17:45:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 17:45:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 17:45:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 17:45:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 17:45:44 --> Final output sent to browser
DEBUG - 2020-09-11 17:45:44 --> Total execution time: 0.0497
INFO - 2020-09-11 18:45:43 --> Config Class Initialized
INFO - 2020-09-11 18:45:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:45:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:45:43 --> Utf8 Class Initialized
INFO - 2020-09-11 18:45:43 --> URI Class Initialized
DEBUG - 2020-09-11 18:45:43 --> No URI present. Default controller set.
INFO - 2020-09-11 18:45:43 --> Router Class Initialized
INFO - 2020-09-11 18:45:43 --> Output Class Initialized
INFO - 2020-09-11 18:45:43 --> Security Class Initialized
DEBUG - 2020-09-11 18:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:45:43 --> Input Class Initialized
INFO - 2020-09-11 18:45:43 --> Language Class Initialized
INFO - 2020-09-11 18:45:43 --> Language Class Initialized
INFO - 2020-09-11 18:45:43 --> Config Class Initialized
INFO - 2020-09-11 18:45:43 --> Loader Class Initialized
INFO - 2020-09-11 18:45:43 --> Helper loaded: url_helper
INFO - 2020-09-11 18:45:43 --> Helper loaded: form_helper
INFO - 2020-09-11 18:45:43 --> Helper loaded: file_helper
INFO - 2020-09-11 18:45:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 18:45:43 --> Database Driver Class Initialized
DEBUG - 2020-09-11 18:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 18:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:45:43 --> Upload Class Initialized
INFO - 2020-09-11 18:45:43 --> Controller Class Initialized
DEBUG - 2020-09-11 18:45:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 18:45:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 18:45:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 18:45:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 18:45:43 --> Final output sent to browser
DEBUG - 2020-09-11 18:45:43 --> Total execution time: 0.0588
INFO - 2020-09-11 20:00:55 --> Config Class Initialized
INFO - 2020-09-11 20:00:55 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:00:55 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:00:55 --> Utf8 Class Initialized
INFO - 2020-09-11 20:00:55 --> URI Class Initialized
DEBUG - 2020-09-11 20:00:55 --> No URI present. Default controller set.
INFO - 2020-09-11 20:00:55 --> Router Class Initialized
INFO - 2020-09-11 20:00:55 --> Output Class Initialized
INFO - 2020-09-11 20:00:55 --> Security Class Initialized
DEBUG - 2020-09-11 20:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:00:55 --> Input Class Initialized
INFO - 2020-09-11 20:00:55 --> Language Class Initialized
INFO - 2020-09-11 20:00:55 --> Language Class Initialized
INFO - 2020-09-11 20:00:55 --> Config Class Initialized
INFO - 2020-09-11 20:00:55 --> Loader Class Initialized
INFO - 2020-09-11 20:00:55 --> Helper loaded: url_helper
INFO - 2020-09-11 20:00:55 --> Helper loaded: form_helper
INFO - 2020-09-11 20:00:55 --> Helper loaded: file_helper
INFO - 2020-09-11 20:00:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:00:55 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:00:55 --> Upload Class Initialized
INFO - 2020-09-11 20:00:55 --> Controller Class Initialized
DEBUG - 2020-09-11 20:00:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 20:00:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 20:00:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 20:00:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 20:00:55 --> Final output sent to browser
DEBUG - 2020-09-11 20:00:55 --> Total execution time: 0.0719
INFO - 2020-09-11 20:00:56 --> Config Class Initialized
INFO - 2020-09-11 20:00:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:00:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:00:56 --> Utf8 Class Initialized
INFO - 2020-09-11 20:00:56 --> URI Class Initialized
DEBUG - 2020-09-11 20:00:56 --> No URI present. Default controller set.
INFO - 2020-09-11 20:00:56 --> Router Class Initialized
INFO - 2020-09-11 20:00:56 --> Output Class Initialized
INFO - 2020-09-11 20:00:56 --> Security Class Initialized
DEBUG - 2020-09-11 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:00:56 --> Input Class Initialized
INFO - 2020-09-11 20:00:56 --> Language Class Initialized
INFO - 2020-09-11 20:00:56 --> Language Class Initialized
INFO - 2020-09-11 20:00:56 --> Config Class Initialized
INFO - 2020-09-11 20:00:56 --> Loader Class Initialized
INFO - 2020-09-11 20:00:56 --> Helper loaded: url_helper
INFO - 2020-09-11 20:00:56 --> Helper loaded: form_helper
INFO - 2020-09-11 20:00:56 --> Helper loaded: file_helper
INFO - 2020-09-11 20:00:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:00:56 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:00:56 --> Upload Class Initialized
INFO - 2020-09-11 20:00:56 --> Controller Class Initialized
DEBUG - 2020-09-11 20:00:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 20:00:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 20:00:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 20:00:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 20:00:56 --> Final output sent to browser
DEBUG - 2020-09-11 20:00:56 --> Total execution time: 0.0546
INFO - 2020-09-11 20:55:42 --> Config Class Initialized
INFO - 2020-09-11 20:55:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:55:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:55:42 --> Utf8 Class Initialized
INFO - 2020-09-11 20:55:42 --> URI Class Initialized
INFO - 2020-09-11 20:55:42 --> Router Class Initialized
INFO - 2020-09-11 20:55:42 --> Output Class Initialized
INFO - 2020-09-11 20:55:42 --> Security Class Initialized
DEBUG - 2020-09-11 20:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:55:42 --> Input Class Initialized
INFO - 2020-09-11 20:55:42 --> Language Class Initialized
INFO - 2020-09-11 20:55:42 --> Language Class Initialized
INFO - 2020-09-11 20:55:42 --> Config Class Initialized
INFO - 2020-09-11 20:55:42 --> Loader Class Initialized
INFO - 2020-09-11 20:55:42 --> Helper loaded: url_helper
INFO - 2020-09-11 20:55:42 --> Helper loaded: form_helper
INFO - 2020-09-11 20:55:42 --> Helper loaded: file_helper
INFO - 2020-09-11 20:55:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:55:42 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:55:42 --> Upload Class Initialized
INFO - 2020-09-11 20:55:42 --> Controller Class Initialized
ERROR - 2020-09-11 20:55:42 --> 404 Page Not Found: /index
INFO - 2020-09-11 20:55:44 --> Config Class Initialized
INFO - 2020-09-11 20:55:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:55:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:55:44 --> Utf8 Class Initialized
INFO - 2020-09-11 20:55:44 --> URI Class Initialized
INFO - 2020-09-11 20:55:44 --> Router Class Initialized
INFO - 2020-09-11 20:55:44 --> Output Class Initialized
INFO - 2020-09-11 20:55:44 --> Security Class Initialized
DEBUG - 2020-09-11 20:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:55:44 --> Input Class Initialized
INFO - 2020-09-11 20:55:44 --> Language Class Initialized
INFO - 2020-09-11 20:55:44 --> Language Class Initialized
INFO - 2020-09-11 20:55:44 --> Config Class Initialized
INFO - 2020-09-11 20:55:44 --> Loader Class Initialized
INFO - 2020-09-11 20:55:44 --> Helper loaded: url_helper
INFO - 2020-09-11 20:55:44 --> Helper loaded: form_helper
INFO - 2020-09-11 20:55:44 --> Helper loaded: file_helper
INFO - 2020-09-11 20:55:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:55:44 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:55:44 --> Upload Class Initialized
INFO - 2020-09-11 20:55:44 --> Controller Class Initialized
ERROR - 2020-09-11 20:55:44 --> 404 Page Not Found: /index
INFO - 2020-09-11 20:56:40 --> Config Class Initialized
INFO - 2020-09-11 20:56:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:56:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:56:40 --> Utf8 Class Initialized
INFO - 2020-09-11 20:56:40 --> URI Class Initialized
INFO - 2020-09-11 20:56:40 --> Router Class Initialized
INFO - 2020-09-11 20:56:40 --> Output Class Initialized
INFO - 2020-09-11 20:56:40 --> Security Class Initialized
DEBUG - 2020-09-11 20:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:56:40 --> Input Class Initialized
INFO - 2020-09-11 20:56:40 --> Language Class Initialized
INFO - 2020-09-11 20:56:40 --> Language Class Initialized
INFO - 2020-09-11 20:56:40 --> Config Class Initialized
INFO - 2020-09-11 20:56:40 --> Loader Class Initialized
INFO - 2020-09-11 20:56:40 --> Helper loaded: url_helper
INFO - 2020-09-11 20:56:40 --> Helper loaded: form_helper
INFO - 2020-09-11 20:56:40 --> Helper loaded: file_helper
INFO - 2020-09-11 20:56:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:56:40 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:56:40 --> Upload Class Initialized
INFO - 2020-09-11 20:56:40 --> Controller Class Initialized
ERROR - 2020-09-11 20:56:40 --> 404 Page Not Found: /index
INFO - 2020-09-11 20:57:21 --> Config Class Initialized
INFO - 2020-09-11 20:57:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:57:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:57:21 --> Utf8 Class Initialized
INFO - 2020-09-11 20:57:21 --> URI Class Initialized
INFO - 2020-09-11 20:57:21 --> Router Class Initialized
INFO - 2020-09-11 20:57:21 --> Output Class Initialized
INFO - 2020-09-11 20:57:21 --> Security Class Initialized
DEBUG - 2020-09-11 20:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:57:21 --> Input Class Initialized
INFO - 2020-09-11 20:57:21 --> Language Class Initialized
INFO - 2020-09-11 20:57:21 --> Language Class Initialized
INFO - 2020-09-11 20:57:21 --> Config Class Initialized
INFO - 2020-09-11 20:57:21 --> Loader Class Initialized
INFO - 2020-09-11 20:57:21 --> Helper loaded: url_helper
INFO - 2020-09-11 20:57:21 --> Helper loaded: form_helper
INFO - 2020-09-11 20:57:21 --> Helper loaded: file_helper
INFO - 2020-09-11 20:57:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:57:21 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:57:21 --> Upload Class Initialized
INFO - 2020-09-11 20:57:21 --> Controller Class Initialized
ERROR - 2020-09-11 20:57:21 --> 404 Page Not Found: /index
INFO - 2020-09-11 20:58:11 --> Config Class Initialized
INFO - 2020-09-11 20:58:11 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:58:11 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:58:11 --> Utf8 Class Initialized
INFO - 2020-09-11 20:58:11 --> URI Class Initialized
INFO - 2020-09-11 20:58:11 --> Router Class Initialized
INFO - 2020-09-11 20:58:11 --> Output Class Initialized
INFO - 2020-09-11 20:58:11 --> Security Class Initialized
DEBUG - 2020-09-11 20:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:58:11 --> Input Class Initialized
INFO - 2020-09-11 20:58:11 --> Language Class Initialized
INFO - 2020-09-11 20:58:11 --> Language Class Initialized
INFO - 2020-09-11 20:58:11 --> Config Class Initialized
INFO - 2020-09-11 20:58:11 --> Loader Class Initialized
INFO - 2020-09-11 20:58:11 --> Helper loaded: url_helper
INFO - 2020-09-11 20:58:11 --> Helper loaded: form_helper
INFO - 2020-09-11 20:58:11 --> Helper loaded: file_helper
INFO - 2020-09-11 20:58:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:58:11 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:58:11 --> Upload Class Initialized
INFO - 2020-09-11 20:58:11 --> Controller Class Initialized
ERROR - 2020-09-11 20:58:11 --> 404 Page Not Found: /index
INFO - 2020-09-11 20:59:06 --> Config Class Initialized
INFO - 2020-09-11 20:59:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:59:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:59:06 --> Utf8 Class Initialized
INFO - 2020-09-11 20:59:06 --> URI Class Initialized
INFO - 2020-09-11 20:59:06 --> Router Class Initialized
INFO - 2020-09-11 20:59:06 --> Output Class Initialized
INFO - 2020-09-11 20:59:06 --> Security Class Initialized
DEBUG - 2020-09-11 20:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:59:06 --> Input Class Initialized
INFO - 2020-09-11 20:59:06 --> Language Class Initialized
INFO - 2020-09-11 20:59:06 --> Language Class Initialized
INFO - 2020-09-11 20:59:06 --> Config Class Initialized
INFO - 2020-09-11 20:59:06 --> Loader Class Initialized
INFO - 2020-09-11 20:59:06 --> Helper loaded: url_helper
INFO - 2020-09-11 20:59:06 --> Helper loaded: form_helper
INFO - 2020-09-11 20:59:06 --> Helper loaded: file_helper
INFO - 2020-09-11 20:59:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:59:06 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:59:06 --> Upload Class Initialized
INFO - 2020-09-11 20:59:06 --> Controller Class Initialized
ERROR - 2020-09-11 20:59:06 --> 404 Page Not Found: /index
INFO - 2020-09-11 20:59:08 --> Config Class Initialized
INFO - 2020-09-11 20:59:08 --> Hooks Class Initialized
DEBUG - 2020-09-11 20:59:08 --> UTF-8 Support Enabled
INFO - 2020-09-11 20:59:08 --> Utf8 Class Initialized
INFO - 2020-09-11 20:59:08 --> URI Class Initialized
INFO - 2020-09-11 20:59:08 --> Router Class Initialized
INFO - 2020-09-11 20:59:08 --> Output Class Initialized
INFO - 2020-09-11 20:59:08 --> Security Class Initialized
DEBUG - 2020-09-11 20:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 20:59:08 --> Input Class Initialized
INFO - 2020-09-11 20:59:08 --> Language Class Initialized
INFO - 2020-09-11 20:59:08 --> Language Class Initialized
INFO - 2020-09-11 20:59:08 --> Config Class Initialized
INFO - 2020-09-11 20:59:08 --> Loader Class Initialized
INFO - 2020-09-11 20:59:08 --> Helper loaded: url_helper
INFO - 2020-09-11 20:59:08 --> Helper loaded: form_helper
INFO - 2020-09-11 20:59:08 --> Helper loaded: file_helper
INFO - 2020-09-11 20:59:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 20:59:08 --> Database Driver Class Initialized
DEBUG - 2020-09-11 20:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 20:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 20:59:08 --> Upload Class Initialized
INFO - 2020-09-11 20:59:08 --> Controller Class Initialized
ERROR - 2020-09-11 20:59:08 --> 404 Page Not Found: /index
INFO - 2020-09-11 22:05:41 --> Config Class Initialized
INFO - 2020-09-11 22:05:41 --> Hooks Class Initialized
DEBUG - 2020-09-11 22:05:41 --> UTF-8 Support Enabled
INFO - 2020-09-11 22:05:41 --> Utf8 Class Initialized
INFO - 2020-09-11 22:05:41 --> URI Class Initialized
INFO - 2020-09-11 22:05:41 --> Router Class Initialized
INFO - 2020-09-11 22:05:41 --> Output Class Initialized
INFO - 2020-09-11 22:05:41 --> Security Class Initialized
DEBUG - 2020-09-11 22:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 22:05:41 --> Input Class Initialized
INFO - 2020-09-11 22:05:41 --> Language Class Initialized
INFO - 2020-09-11 22:05:41 --> Language Class Initialized
INFO - 2020-09-11 22:05:41 --> Config Class Initialized
INFO - 2020-09-11 22:05:41 --> Loader Class Initialized
INFO - 2020-09-11 22:05:41 --> Helper loaded: url_helper
INFO - 2020-09-11 22:05:41 --> Helper loaded: form_helper
INFO - 2020-09-11 22:05:41 --> Helper loaded: file_helper
INFO - 2020-09-11 22:05:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 22:05:41 --> Database Driver Class Initialized
DEBUG - 2020-09-11 22:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 22:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 22:05:41 --> Upload Class Initialized
INFO - 2020-09-11 22:05:41 --> Controller Class Initialized
ERROR - 2020-09-11 22:05:41 --> 404 Page Not Found: /index
INFO - 2020-09-11 22:58:42 --> Config Class Initialized
INFO - 2020-09-11 22:58:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 22:58:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 22:58:42 --> Utf8 Class Initialized
INFO - 2020-09-11 22:58:42 --> URI Class Initialized
INFO - 2020-09-11 22:58:42 --> Router Class Initialized
INFO - 2020-09-11 22:58:42 --> Output Class Initialized
INFO - 2020-09-11 22:58:42 --> Security Class Initialized
DEBUG - 2020-09-11 22:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 22:58:42 --> Input Class Initialized
INFO - 2020-09-11 22:58:42 --> Language Class Initialized
INFO - 2020-09-11 22:58:42 --> Language Class Initialized
INFO - 2020-09-11 22:58:42 --> Config Class Initialized
INFO - 2020-09-11 22:58:42 --> Loader Class Initialized
INFO - 2020-09-11 22:58:42 --> Helper loaded: url_helper
INFO - 2020-09-11 22:58:42 --> Helper loaded: form_helper
INFO - 2020-09-11 22:58:42 --> Helper loaded: file_helper
INFO - 2020-09-11 22:58:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 22:58:42 --> Database Driver Class Initialized
DEBUG - 2020-09-11 22:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 22:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 22:58:42 --> Upload Class Initialized
INFO - 2020-09-11 22:58:42 --> Controller Class Initialized
ERROR - 2020-09-11 22:58:42 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:19 --> Config Class Initialized
INFO - 2020-09-11 23:11:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:19 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:19 --> URI Class Initialized
INFO - 2020-09-11 23:11:19 --> Router Class Initialized
INFO - 2020-09-11 23:11:19 --> Output Class Initialized
INFO - 2020-09-11 23:11:19 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:19 --> Input Class Initialized
INFO - 2020-09-11 23:11:19 --> Language Class Initialized
INFO - 2020-09-11 23:11:19 --> Language Class Initialized
INFO - 2020-09-11 23:11:19 --> Config Class Initialized
INFO - 2020-09-11 23:11:19 --> Loader Class Initialized
INFO - 2020-09-11 23:11:19 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:19 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:19 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:19 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:19 --> Upload Class Initialized
INFO - 2020-09-11 23:11:19 --> Controller Class Initialized
DEBUG - 2020-09-11 23:11:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:11:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-11 23:11:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:11:19 --> Final output sent to browser
DEBUG - 2020-09-11 23:11:19 --> Total execution time: 0.0607
INFO - 2020-09-11 23:11:20 --> Config Class Initialized
INFO - 2020-09-11 23:11:20 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:20 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:20 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:20 --> URI Class Initialized
INFO - 2020-09-11 23:11:20 --> Router Class Initialized
INFO - 2020-09-11 23:11:20 --> Output Class Initialized
INFO - 2020-09-11 23:11:20 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:20 --> Input Class Initialized
INFO - 2020-09-11 23:11:20 --> Language Class Initialized
INFO - 2020-09-11 23:11:20 --> Language Class Initialized
INFO - 2020-09-11 23:11:20 --> Config Class Initialized
INFO - 2020-09-11 23:11:20 --> Loader Class Initialized
INFO - 2020-09-11 23:11:20 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:20 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:20 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:20 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:20 --> Upload Class Initialized
INFO - 2020-09-11 23:11:20 --> Controller Class Initialized
DEBUG - 2020-09-11 23:11:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:11:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-11 23:11:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:11:20 --> Final output sent to browser
DEBUG - 2020-09-11 23:11:20 --> Total execution time: 0.0503
INFO - 2020-09-11 23:11:20 --> Config Class Initialized
INFO - 2020-09-11 23:11:20 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:20 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:20 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:20 --> URI Class Initialized
INFO - 2020-09-11 23:11:20 --> Router Class Initialized
INFO - 2020-09-11 23:11:20 --> Output Class Initialized
INFO - 2020-09-11 23:11:20 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:20 --> Input Class Initialized
INFO - 2020-09-11 23:11:20 --> Language Class Initialized
INFO - 2020-09-11 23:11:20 --> Language Class Initialized
INFO - 2020-09-11 23:11:20 --> Config Class Initialized
INFO - 2020-09-11 23:11:20 --> Loader Class Initialized
INFO - 2020-09-11 23:11:20 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:20 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:20 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:20 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:20 --> Upload Class Initialized
INFO - 2020-09-11 23:11:20 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:20 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:21 --> Config Class Initialized
INFO - 2020-09-11 23:11:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:21 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:21 --> URI Class Initialized
INFO - 2020-09-11 23:11:21 --> Router Class Initialized
INFO - 2020-09-11 23:11:21 --> Output Class Initialized
INFO - 2020-09-11 23:11:21 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:21 --> Input Class Initialized
INFO - 2020-09-11 23:11:21 --> Language Class Initialized
INFO - 2020-09-11 23:11:21 --> Language Class Initialized
INFO - 2020-09-11 23:11:21 --> Config Class Initialized
INFO - 2020-09-11 23:11:21 --> Loader Class Initialized
INFO - 2020-09-11 23:11:21 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:21 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:21 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:21 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:21 --> Upload Class Initialized
INFO - 2020-09-11 23:11:21 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:21 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:43 --> Config Class Initialized
INFO - 2020-09-11 23:11:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:43 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:43 --> URI Class Initialized
DEBUG - 2020-09-11 23:11:43 --> No URI present. Default controller set.
INFO - 2020-09-11 23:11:43 --> Router Class Initialized
INFO - 2020-09-11 23:11:43 --> Output Class Initialized
INFO - 2020-09-11 23:11:43 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:43 --> Input Class Initialized
INFO - 2020-09-11 23:11:43 --> Language Class Initialized
INFO - 2020-09-11 23:11:43 --> Language Class Initialized
INFO - 2020-09-11 23:11:43 --> Config Class Initialized
INFO - 2020-09-11 23:11:43 --> Loader Class Initialized
INFO - 2020-09-11 23:11:43 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:43 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:43 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:43 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:43 --> Upload Class Initialized
INFO - 2020-09-11 23:11:43 --> Controller Class Initialized
DEBUG - 2020-09-11 23:11:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:11:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 23:11:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 23:11:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:11:43 --> Final output sent to browser
DEBUG - 2020-09-11 23:11:43 --> Total execution time: 0.0492
INFO - 2020-09-11 23:11:44 --> Config Class Initialized
INFO - 2020-09-11 23:11:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:44 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:44 --> URI Class Initialized
INFO - 2020-09-11 23:11:44 --> Router Class Initialized
INFO - 2020-09-11 23:11:44 --> Output Class Initialized
INFO - 2020-09-11 23:11:44 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:44 --> Input Class Initialized
INFO - 2020-09-11 23:11:44 --> Language Class Initialized
INFO - 2020-09-11 23:11:44 --> Language Class Initialized
INFO - 2020-09-11 23:11:44 --> Config Class Initialized
INFO - 2020-09-11 23:11:44 --> Loader Class Initialized
INFO - 2020-09-11 23:11:44 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:44 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:44 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:44 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:44 --> Upload Class Initialized
INFO - 2020-09-11 23:11:44 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:44 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:45 --> Config Class Initialized
INFO - 2020-09-11 23:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:45 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:45 --> URI Class Initialized
INFO - 2020-09-11 23:11:45 --> Router Class Initialized
INFO - 2020-09-11 23:11:45 --> Output Class Initialized
INFO - 2020-09-11 23:11:45 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:45 --> Input Class Initialized
INFO - 2020-09-11 23:11:45 --> Language Class Initialized
INFO - 2020-09-11 23:11:45 --> Language Class Initialized
INFO - 2020-09-11 23:11:45 --> Config Class Initialized
INFO - 2020-09-11 23:11:45 --> Loader Class Initialized
INFO - 2020-09-11 23:11:45 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:45 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:45 --> Upload Class Initialized
INFO - 2020-09-11 23:11:45 --> Config Class Initialized
INFO - 2020-09-11 23:11:45 --> Hooks Class Initialized
INFO - 2020-09-11 23:11:45 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:45 --> 404 Page Not Found: /index
DEBUG - 2020-09-11 23:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:45 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:45 --> URI Class Initialized
INFO - 2020-09-11 23:11:45 --> Router Class Initialized
INFO - 2020-09-11 23:11:45 --> Output Class Initialized
INFO - 2020-09-11 23:11:45 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:45 --> Input Class Initialized
INFO - 2020-09-11 23:11:45 --> Language Class Initialized
INFO - 2020-09-11 23:11:45 --> Language Class Initialized
INFO - 2020-09-11 23:11:45 --> Config Class Initialized
INFO - 2020-09-11 23:11:45 --> Loader Class Initialized
INFO - 2020-09-11 23:11:45 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:45 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:45 --> Upload Class Initialized
INFO - 2020-09-11 23:11:45 --> Config Class Initialized
INFO - 2020-09-11 23:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:45 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:45 --> URI Class Initialized
INFO - 2020-09-11 23:11:45 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:45 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:45 --> Router Class Initialized
INFO - 2020-09-11 23:11:45 --> Output Class Initialized
INFO - 2020-09-11 23:11:45 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:45 --> Input Class Initialized
INFO - 2020-09-11 23:11:45 --> Language Class Initialized
INFO - 2020-09-11 23:11:45 --> Language Class Initialized
INFO - 2020-09-11 23:11:45 --> Config Class Initialized
INFO - 2020-09-11 23:11:45 --> Loader Class Initialized
INFO - 2020-09-11 23:11:45 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:45 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:45 --> Upload Class Initialized
INFO - 2020-09-11 23:11:45 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:45 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:52 --> Config Class Initialized
INFO - 2020-09-11 23:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:52 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:52 --> URI Class Initialized
INFO - 2020-09-11 23:11:52 --> Router Class Initialized
INFO - 2020-09-11 23:11:52 --> Output Class Initialized
INFO - 2020-09-11 23:11:52 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:52 --> Input Class Initialized
INFO - 2020-09-11 23:11:52 --> Language Class Initialized
INFO - 2020-09-11 23:11:52 --> Language Class Initialized
INFO - 2020-09-11 23:11:52 --> Config Class Initialized
INFO - 2020-09-11 23:11:52 --> Loader Class Initialized
INFO - 2020-09-11 23:11:52 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:52 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:52 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:52 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:52 --> Upload Class Initialized
INFO - 2020-09-11 23:11:52 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:52 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:11:58 --> Config Class Initialized
INFO - 2020-09-11 23:11:58 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:58 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:58 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:58 --> URI Class Initialized
INFO - 2020-09-11 23:11:58 --> Router Class Initialized
INFO - 2020-09-11 23:11:58 --> Output Class Initialized
INFO - 2020-09-11 23:11:58 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:58 --> Input Class Initialized
INFO - 2020-09-11 23:11:58 --> Language Class Initialized
INFO - 2020-09-11 23:11:58 --> Language Class Initialized
INFO - 2020-09-11 23:11:58 --> Config Class Initialized
INFO - 2020-09-11 23:11:58 --> Loader Class Initialized
INFO - 2020-09-11 23:11:58 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:58 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:58 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:58 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:58 --> Upload Class Initialized
INFO - 2020-09-11 23:11:58 --> Controller Class Initialized
DEBUG - 2020-09-11 23:11:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:11:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-11 23:11:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:11:58 --> Final output sent to browser
DEBUG - 2020-09-11 23:11:58 --> Total execution time: 0.0506
INFO - 2020-09-11 23:11:59 --> Config Class Initialized
INFO - 2020-09-11 23:11:59 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:11:59 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:11:59 --> Utf8 Class Initialized
INFO - 2020-09-11 23:11:59 --> URI Class Initialized
INFO - 2020-09-11 23:11:59 --> Router Class Initialized
INFO - 2020-09-11 23:11:59 --> Output Class Initialized
INFO - 2020-09-11 23:11:59 --> Security Class Initialized
DEBUG - 2020-09-11 23:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:11:59 --> Input Class Initialized
INFO - 2020-09-11 23:11:59 --> Language Class Initialized
INFO - 2020-09-11 23:11:59 --> Language Class Initialized
INFO - 2020-09-11 23:11:59 --> Config Class Initialized
INFO - 2020-09-11 23:11:59 --> Loader Class Initialized
INFO - 2020-09-11 23:11:59 --> Helper loaded: url_helper
INFO - 2020-09-11 23:11:59 --> Helper loaded: form_helper
INFO - 2020-09-11 23:11:59 --> Helper loaded: file_helper
INFO - 2020-09-11 23:11:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:11:59 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:11:59 --> Upload Class Initialized
INFO - 2020-09-11 23:11:59 --> Controller Class Initialized
ERROR - 2020-09-11 23:11:59 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:12:12 --> Config Class Initialized
INFO - 2020-09-11 23:12:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:12:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:12:12 --> Utf8 Class Initialized
INFO - 2020-09-11 23:12:12 --> URI Class Initialized
INFO - 2020-09-11 23:12:12 --> Router Class Initialized
INFO - 2020-09-11 23:12:12 --> Output Class Initialized
INFO - 2020-09-11 23:12:12 --> Security Class Initialized
DEBUG - 2020-09-11 23:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:12:12 --> Input Class Initialized
INFO - 2020-09-11 23:12:12 --> Language Class Initialized
INFO - 2020-09-11 23:12:12 --> Language Class Initialized
INFO - 2020-09-11 23:12:12 --> Config Class Initialized
INFO - 2020-09-11 23:12:12 --> Loader Class Initialized
INFO - 2020-09-11 23:12:12 --> Helper loaded: url_helper
INFO - 2020-09-11 23:12:12 --> Helper loaded: form_helper
INFO - 2020-09-11 23:12:12 --> Helper loaded: file_helper
INFO - 2020-09-11 23:12:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:12:12 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:12:12 --> Upload Class Initialized
INFO - 2020-09-11 23:12:12 --> Controller Class Initialized
DEBUG - 2020-09-11 23:12:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:12:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-11 23:12:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:12:12 --> Final output sent to browser
DEBUG - 2020-09-11 23:12:12 --> Total execution time: 0.0543
INFO - 2020-09-11 23:12:34 --> Config Class Initialized
INFO - 2020-09-11 23:12:34 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:12:34 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:12:34 --> Utf8 Class Initialized
INFO - 2020-09-11 23:12:34 --> URI Class Initialized
INFO - 2020-09-11 23:12:34 --> Router Class Initialized
INFO - 2020-09-11 23:12:34 --> Output Class Initialized
INFO - 2020-09-11 23:12:34 --> Security Class Initialized
DEBUG - 2020-09-11 23:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:12:34 --> Input Class Initialized
INFO - 2020-09-11 23:12:34 --> Language Class Initialized
INFO - 2020-09-11 23:12:34 --> Language Class Initialized
INFO - 2020-09-11 23:12:34 --> Config Class Initialized
INFO - 2020-09-11 23:12:34 --> Loader Class Initialized
INFO - 2020-09-11 23:12:34 --> Helper loaded: url_helper
INFO - 2020-09-11 23:12:34 --> Helper loaded: form_helper
INFO - 2020-09-11 23:12:34 --> Helper loaded: file_helper
INFO - 2020-09-11 23:12:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:12:34 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:12:34 --> Upload Class Initialized
INFO - 2020-09-11 23:12:34 --> Controller Class Initialized
DEBUG - 2020-09-11 23:12:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:12:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-11 23:12:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:12:34 --> Final output sent to browser
DEBUG - 2020-09-11 23:12:34 --> Total execution time: 0.0446
INFO - 2020-09-11 23:12:35 --> Config Class Initialized
INFO - 2020-09-11 23:12:35 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:12:35 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:12:35 --> Utf8 Class Initialized
INFO - 2020-09-11 23:12:35 --> URI Class Initialized
INFO - 2020-09-11 23:12:35 --> Router Class Initialized
INFO - 2020-09-11 23:12:35 --> Output Class Initialized
INFO - 2020-09-11 23:12:35 --> Security Class Initialized
DEBUG - 2020-09-11 23:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:12:35 --> Input Class Initialized
INFO - 2020-09-11 23:12:35 --> Language Class Initialized
INFO - 2020-09-11 23:12:35 --> Language Class Initialized
INFO - 2020-09-11 23:12:35 --> Config Class Initialized
INFO - 2020-09-11 23:12:35 --> Loader Class Initialized
INFO - 2020-09-11 23:12:35 --> Helper loaded: url_helper
INFO - 2020-09-11 23:12:35 --> Helper loaded: form_helper
INFO - 2020-09-11 23:12:35 --> Helper loaded: file_helper
INFO - 2020-09-11 23:12:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:12:35 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:12:35 --> Upload Class Initialized
INFO - 2020-09-11 23:12:35 --> Controller Class Initialized
ERROR - 2020-09-11 23:12:35 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:15:03 --> Config Class Initialized
INFO - 2020-09-11 23:15:03 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:15:03 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:15:03 --> Utf8 Class Initialized
INFO - 2020-09-11 23:15:03 --> URI Class Initialized
DEBUG - 2020-09-11 23:15:03 --> No URI present. Default controller set.
INFO - 2020-09-11 23:15:03 --> Router Class Initialized
INFO - 2020-09-11 23:15:03 --> Output Class Initialized
INFO - 2020-09-11 23:15:03 --> Security Class Initialized
DEBUG - 2020-09-11 23:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:15:03 --> Input Class Initialized
INFO - 2020-09-11 23:15:03 --> Language Class Initialized
INFO - 2020-09-11 23:15:03 --> Language Class Initialized
INFO - 2020-09-11 23:15:03 --> Config Class Initialized
INFO - 2020-09-11 23:15:03 --> Loader Class Initialized
INFO - 2020-09-11 23:15:03 --> Helper loaded: url_helper
INFO - 2020-09-11 23:15:03 --> Helper loaded: form_helper
INFO - 2020-09-11 23:15:03 --> Helper loaded: file_helper
INFO - 2020-09-11 23:15:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:15:03 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:15:03 --> Upload Class Initialized
INFO - 2020-09-11 23:15:03 --> Controller Class Initialized
DEBUG - 2020-09-11 23:15:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:15:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 23:15:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 23:15:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:15:03 --> Final output sent to browser
DEBUG - 2020-09-11 23:15:03 --> Total execution time: 0.0480
INFO - 2020-09-11 23:15:09 --> Config Class Initialized
INFO - 2020-09-11 23:15:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:15:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:15:09 --> Utf8 Class Initialized
INFO - 2020-09-11 23:15:09 --> URI Class Initialized
INFO - 2020-09-11 23:15:09 --> Router Class Initialized
INFO - 2020-09-11 23:15:09 --> Output Class Initialized
INFO - 2020-09-11 23:15:09 --> Security Class Initialized
DEBUG - 2020-09-11 23:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:15:09 --> Input Class Initialized
INFO - 2020-09-11 23:15:09 --> Language Class Initialized
INFO - 2020-09-11 23:15:09 --> Language Class Initialized
INFO - 2020-09-11 23:15:09 --> Config Class Initialized
INFO - 2020-09-11 23:15:09 --> Loader Class Initialized
INFO - 2020-09-11 23:15:09 --> Helper loaded: url_helper
INFO - 2020-09-11 23:15:09 --> Helper loaded: form_helper
INFO - 2020-09-11 23:15:09 --> Helper loaded: file_helper
INFO - 2020-09-11 23:15:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:15:09 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:15:09 --> Upload Class Initialized
INFO - 2020-09-11 23:15:09 --> Controller Class Initialized
ERROR - 2020-09-11 23:15:09 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:15:10 --> Config Class Initialized
INFO - 2020-09-11 23:15:10 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:15:10 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:15:10 --> Utf8 Class Initialized
INFO - 2020-09-11 23:15:10 --> URI Class Initialized
INFO - 2020-09-11 23:15:10 --> Router Class Initialized
INFO - 2020-09-11 23:15:10 --> Output Class Initialized
INFO - 2020-09-11 23:15:10 --> Security Class Initialized
DEBUG - 2020-09-11 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:15:10 --> Input Class Initialized
INFO - 2020-09-11 23:15:10 --> Language Class Initialized
INFO - 2020-09-11 23:15:10 --> Language Class Initialized
INFO - 2020-09-11 23:15:10 --> Config Class Initialized
INFO - 2020-09-11 23:15:10 --> Loader Class Initialized
INFO - 2020-09-11 23:15:10 --> Helper loaded: url_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: form_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: file_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:15:10 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:15:10 --> Upload Class Initialized
INFO - 2020-09-11 23:15:10 --> Config Class Initialized
INFO - 2020-09-11 23:15:10 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:15:10 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:15:10 --> Utf8 Class Initialized
INFO - 2020-09-11 23:15:10 --> URI Class Initialized
INFO - 2020-09-11 23:15:10 --> Router Class Initialized
INFO - 2020-09-11 23:15:10 --> Output Class Initialized
INFO - 2020-09-11 23:15:10 --> Security Class Initialized
DEBUG - 2020-09-11 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:15:10 --> Input Class Initialized
INFO - 2020-09-11 23:15:10 --> Language Class Initialized
INFO - 2020-09-11 23:15:10 --> Language Class Initialized
INFO - 2020-09-11 23:15:10 --> Config Class Initialized
INFO - 2020-09-11 23:15:10 --> Loader Class Initialized
INFO - 2020-09-11 23:15:10 --> Helper loaded: url_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: form_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: file_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:15:10 --> Database Driver Class Initialized
INFO - 2020-09-11 23:15:10 --> Config Class Initialized
INFO - 2020-09-11 23:15:10 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:15:10 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:15:10 --> Utf8 Class Initialized
INFO - 2020-09-11 23:15:10 --> Controller Class Initialized
INFO - 2020-09-11 23:15:10 --> URI Class Initialized
ERROR - 2020-09-11 23:15:10 --> 404 Page Not Found: /index
DEBUG - 2020-09-11 23:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:15:10 --> Upload Class Initialized
INFO - 2020-09-11 23:15:10 --> Router Class Initialized
INFO - 2020-09-11 23:15:10 --> Output Class Initialized
INFO - 2020-09-11 23:15:10 --> Security Class Initialized
DEBUG - 2020-09-11 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:15:10 --> Input Class Initialized
INFO - 2020-09-11 23:15:10 --> Language Class Initialized
INFO - 2020-09-11 23:15:10 --> Language Class Initialized
INFO - 2020-09-11 23:15:10 --> Config Class Initialized
INFO - 2020-09-11 23:15:10 --> Loader Class Initialized
INFO - 2020-09-11 23:15:10 --> Helper loaded: url_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: form_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: file_helper
INFO - 2020-09-11 23:15:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:15:10 --> Controller Class Initialized
ERROR - 2020-09-11 23:15:10 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:15:10 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:15:10 --> Upload Class Initialized
INFO - 2020-09-11 23:15:10 --> Controller Class Initialized
ERROR - 2020-09-11 23:15:10 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:38:22 --> Config Class Initialized
INFO - 2020-09-11 23:38:22 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:38:22 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:38:22 --> Utf8 Class Initialized
INFO - 2020-09-11 23:38:22 --> URI Class Initialized
INFO - 2020-09-11 23:38:22 --> Router Class Initialized
INFO - 2020-09-11 23:38:22 --> Output Class Initialized
INFO - 2020-09-11 23:38:22 --> Security Class Initialized
DEBUG - 2020-09-11 23:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:38:22 --> Input Class Initialized
INFO - 2020-09-11 23:38:22 --> Language Class Initialized
INFO - 2020-09-11 23:38:22 --> Language Class Initialized
INFO - 2020-09-11 23:38:22 --> Config Class Initialized
INFO - 2020-09-11 23:38:22 --> Loader Class Initialized
INFO - 2020-09-11 23:38:22 --> Helper loaded: url_helper
INFO - 2020-09-11 23:38:22 --> Helper loaded: form_helper
INFO - 2020-09-11 23:38:22 --> Helper loaded: file_helper
INFO - 2020-09-11 23:38:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:38:22 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:38:22 --> Upload Class Initialized
INFO - 2020-09-11 23:38:22 --> Controller Class Initialized
ERROR - 2020-09-11 23:38:22 --> 404 Page Not Found: /index
INFO - 2020-09-11 23:38:23 --> Config Class Initialized
INFO - 2020-09-11 23:38:23 --> Hooks Class Initialized
DEBUG - 2020-09-11 23:38:23 --> UTF-8 Support Enabled
INFO - 2020-09-11 23:38:23 --> Utf8 Class Initialized
INFO - 2020-09-11 23:38:23 --> URI Class Initialized
DEBUG - 2020-09-11 23:38:23 --> No URI present. Default controller set.
INFO - 2020-09-11 23:38:23 --> Router Class Initialized
INFO - 2020-09-11 23:38:23 --> Output Class Initialized
INFO - 2020-09-11 23:38:23 --> Security Class Initialized
DEBUG - 2020-09-11 23:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 23:38:23 --> Input Class Initialized
INFO - 2020-09-11 23:38:23 --> Language Class Initialized
INFO - 2020-09-11 23:38:23 --> Language Class Initialized
INFO - 2020-09-11 23:38:23 --> Config Class Initialized
INFO - 2020-09-11 23:38:23 --> Loader Class Initialized
INFO - 2020-09-11 23:38:23 --> Helper loaded: url_helper
INFO - 2020-09-11 23:38:23 --> Helper loaded: form_helper
INFO - 2020-09-11 23:38:23 --> Helper loaded: file_helper
INFO - 2020-09-11 23:38:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-11 23:38:23 --> Database Driver Class Initialized
DEBUG - 2020-09-11 23:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-11 23:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 23:38:23 --> Upload Class Initialized
INFO - 2020-09-11 23:38:23 --> Controller Class Initialized
DEBUG - 2020-09-11 23:38:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-11 23:38:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-11 23:38:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-11 23:38:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-11 23:38:23 --> Final output sent to browser
DEBUG - 2020-09-11 23:38:23 --> Total execution time: 0.0513
