<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-12 00:02:52 --> Config Class Initialized
INFO - 2020-09-12 00:02:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:02:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:02:52 --> Utf8 Class Initialized
INFO - 2020-09-12 00:02:52 --> URI Class Initialized
DEBUG - 2020-09-12 00:02:52 --> No URI present. Default controller set.
INFO - 2020-09-12 00:02:52 --> Router Class Initialized
INFO - 2020-09-12 00:02:52 --> Output Class Initialized
INFO - 2020-09-12 00:02:52 --> Security Class Initialized
DEBUG - 2020-09-12 00:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:02:52 --> Input Class Initialized
INFO - 2020-09-12 00:02:52 --> Language Class Initialized
INFO - 2020-09-12 00:02:52 --> Language Class Initialized
INFO - 2020-09-12 00:02:52 --> Config Class Initialized
INFO - 2020-09-12 00:02:52 --> Loader Class Initialized
INFO - 2020-09-12 00:02:52 --> Helper loaded: url_helper
INFO - 2020-09-12 00:02:52 --> Helper loaded: form_helper
INFO - 2020-09-12 00:02:52 --> Helper loaded: file_helper
INFO - 2020-09-12 00:02:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:02:52 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:02:52 --> Upload Class Initialized
INFO - 2020-09-12 00:02:52 --> Controller Class Initialized
DEBUG - 2020-09-12 00:02:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 00:02:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 00:02:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 00:02:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 00:02:52 --> Final output sent to browser
DEBUG - 2020-09-12 00:02:52 --> Total execution time: 0.0450
INFO - 2020-09-12 00:23:00 --> Config Class Initialized
INFO - 2020-09-12 00:23:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:23:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:23:00 --> Utf8 Class Initialized
INFO - 2020-09-12 00:23:00 --> URI Class Initialized
DEBUG - 2020-09-12 00:23:00 --> No URI present. Default controller set.
INFO - 2020-09-12 00:23:00 --> Router Class Initialized
INFO - 2020-09-12 00:23:00 --> Output Class Initialized
INFO - 2020-09-12 00:23:00 --> Security Class Initialized
DEBUG - 2020-09-12 00:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:23:00 --> Input Class Initialized
INFO - 2020-09-12 00:23:00 --> Language Class Initialized
INFO - 2020-09-12 00:23:00 --> Language Class Initialized
INFO - 2020-09-12 00:23:00 --> Config Class Initialized
INFO - 2020-09-12 00:23:00 --> Loader Class Initialized
INFO - 2020-09-12 00:23:00 --> Helper loaded: url_helper
INFO - 2020-09-12 00:23:00 --> Helper loaded: form_helper
INFO - 2020-09-12 00:23:00 --> Helper loaded: file_helper
INFO - 2020-09-12 00:23:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:23:00 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:23:00 --> Upload Class Initialized
INFO - 2020-09-12 00:23:00 --> Controller Class Initialized
DEBUG - 2020-09-12 00:23:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 00:23:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 00:23:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 00:23:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 00:23:00 --> Final output sent to browser
DEBUG - 2020-09-12 00:23:00 --> Total execution time: 0.0462
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:23:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:23:12 --> Utf8 Class Initialized
INFO - 2020-09-12 00:23:12 --> URI Class Initialized
INFO - 2020-09-12 00:23:12 --> Router Class Initialized
INFO - 2020-09-12 00:23:12 --> Output Class Initialized
INFO - 2020-09-12 00:23:12 --> Security Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:23:12 --> Input Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Loader Class Initialized
INFO - 2020-09-12 00:23:12 --> Helper loaded: url_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: form_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: file_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:23:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:23:12 --> Upload Class Initialized
INFO - 2020-09-12 00:23:12 --> Controller Class Initialized
ERROR - 2020-09-12 00:23:12 --> 404 Page Not Found: /index
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:23:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:23:12 --> Utf8 Class Initialized
INFO - 2020-09-12 00:23:12 --> URI Class Initialized
INFO - 2020-09-12 00:23:12 --> Router Class Initialized
INFO - 2020-09-12 00:23:12 --> Output Class Initialized
INFO - 2020-09-12 00:23:12 --> Security Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:23:12 --> Input Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Loader Class Initialized
INFO - 2020-09-12 00:23:12 --> Helper loaded: url_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: form_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: file_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:23:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:23:12 --> Upload Class Initialized
INFO - 2020-09-12 00:23:12 --> Controller Class Initialized
ERROR - 2020-09-12 00:23:12 --> 404 Page Not Found: /index
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:23:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:23:12 --> Utf8 Class Initialized
INFO - 2020-09-12 00:23:12 --> URI Class Initialized
INFO - 2020-09-12 00:23:12 --> Router Class Initialized
INFO - 2020-09-12 00:23:12 --> Output Class Initialized
INFO - 2020-09-12 00:23:12 --> Security Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:23:12 --> Input Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Loader Class Initialized
INFO - 2020-09-12 00:23:12 --> Helper loaded: url_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: form_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: file_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:23:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:23:12 --> Upload Class Initialized
INFO - 2020-09-12 00:23:12 --> Controller Class Initialized
ERROR - 2020-09-12 00:23:12 --> 404 Page Not Found: /index
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:23:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:23:12 --> Utf8 Class Initialized
INFO - 2020-09-12 00:23:12 --> URI Class Initialized
INFO - 2020-09-12 00:23:12 --> Router Class Initialized
INFO - 2020-09-12 00:23:12 --> Output Class Initialized
INFO - 2020-09-12 00:23:12 --> Security Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:23:12 --> Input Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Language Class Initialized
INFO - 2020-09-12 00:23:12 --> Config Class Initialized
INFO - 2020-09-12 00:23:12 --> Loader Class Initialized
INFO - 2020-09-12 00:23:12 --> Helper loaded: url_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: form_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: file_helper
INFO - 2020-09-12 00:23:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:23:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:23:12 --> Upload Class Initialized
INFO - 2020-09-12 00:23:12 --> Controller Class Initialized
ERROR - 2020-09-12 00:23:12 --> 404 Page Not Found: /index
INFO - 2020-09-12 00:23:19 --> Config Class Initialized
INFO - 2020-09-12 00:23:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 00:23:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 00:23:19 --> Utf8 Class Initialized
INFO - 2020-09-12 00:23:19 --> URI Class Initialized
INFO - 2020-09-12 00:23:19 --> Router Class Initialized
INFO - 2020-09-12 00:23:19 --> Output Class Initialized
INFO - 2020-09-12 00:23:19 --> Security Class Initialized
DEBUG - 2020-09-12 00:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 00:23:19 --> Input Class Initialized
INFO - 2020-09-12 00:23:19 --> Language Class Initialized
INFO - 2020-09-12 00:23:19 --> Language Class Initialized
INFO - 2020-09-12 00:23:19 --> Config Class Initialized
INFO - 2020-09-12 00:23:19 --> Loader Class Initialized
INFO - 2020-09-12 00:23:19 --> Helper loaded: url_helper
INFO - 2020-09-12 00:23:19 --> Helper loaded: form_helper
INFO - 2020-09-12 00:23:19 --> Helper loaded: file_helper
INFO - 2020-09-12 00:23:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 00:23:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 00:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 00:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 00:23:19 --> Upload Class Initialized
INFO - 2020-09-12 00:23:19 --> Controller Class Initialized
ERROR - 2020-09-12 00:23:19 --> 404 Page Not Found: /index
INFO - 2020-09-12 01:28:13 --> Config Class Initialized
INFO - 2020-09-12 01:28:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 01:28:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 01:28:13 --> Utf8 Class Initialized
INFO - 2020-09-12 01:28:13 --> URI Class Initialized
DEBUG - 2020-09-12 01:28:13 --> No URI present. Default controller set.
INFO - 2020-09-12 01:28:13 --> Router Class Initialized
INFO - 2020-09-12 01:28:13 --> Output Class Initialized
INFO - 2020-09-12 01:28:13 --> Security Class Initialized
DEBUG - 2020-09-12 01:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 01:28:13 --> Input Class Initialized
INFO - 2020-09-12 01:28:13 --> Language Class Initialized
INFO - 2020-09-12 01:28:13 --> Language Class Initialized
INFO - 2020-09-12 01:28:13 --> Config Class Initialized
INFO - 2020-09-12 01:28:13 --> Loader Class Initialized
INFO - 2020-09-12 01:28:13 --> Helper loaded: url_helper
INFO - 2020-09-12 01:28:13 --> Helper loaded: form_helper
INFO - 2020-09-12 01:28:13 --> Helper loaded: file_helper
INFO - 2020-09-12 01:28:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 01:28:13 --> Database Driver Class Initialized
DEBUG - 2020-09-12 01:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 01:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 01:28:13 --> Upload Class Initialized
INFO - 2020-09-12 01:28:13 --> Controller Class Initialized
DEBUG - 2020-09-12 01:28:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 01:28:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 01:28:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 01:28:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 01:28:13 --> Final output sent to browser
DEBUG - 2020-09-12 01:28:13 --> Total execution time: 0.0628
INFO - 2020-09-12 02:09:09 --> Config Class Initialized
INFO - 2020-09-12 02:09:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 02:09:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 02:09:09 --> Utf8 Class Initialized
INFO - 2020-09-12 02:09:09 --> URI Class Initialized
INFO - 2020-09-12 02:09:09 --> Router Class Initialized
INFO - 2020-09-12 02:09:09 --> Output Class Initialized
INFO - 2020-09-12 02:09:09 --> Security Class Initialized
DEBUG - 2020-09-12 02:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 02:09:09 --> Input Class Initialized
INFO - 2020-09-12 02:09:09 --> Language Class Initialized
INFO - 2020-09-12 02:09:09 --> Language Class Initialized
INFO - 2020-09-12 02:09:09 --> Config Class Initialized
INFO - 2020-09-12 02:09:09 --> Loader Class Initialized
INFO - 2020-09-12 02:09:09 --> Helper loaded: url_helper
INFO - 2020-09-12 02:09:09 --> Helper loaded: form_helper
INFO - 2020-09-12 02:09:09 --> Helper loaded: file_helper
INFO - 2020-09-12 02:09:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 02:09:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 02:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 02:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 02:09:09 --> Upload Class Initialized
INFO - 2020-09-12 02:09:09 --> Controller Class Initialized
ERROR - 2020-09-12 02:09:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 02:09:09 --> Config Class Initialized
INFO - 2020-09-12 02:09:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 02:09:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 02:09:09 --> Utf8 Class Initialized
INFO - 2020-09-12 02:09:09 --> URI Class Initialized
INFO - 2020-09-12 02:09:09 --> Router Class Initialized
INFO - 2020-09-12 02:09:09 --> Output Class Initialized
INFO - 2020-09-12 02:09:09 --> Security Class Initialized
DEBUG - 2020-09-12 02:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 02:09:09 --> Input Class Initialized
INFO - 2020-09-12 02:09:09 --> Language Class Initialized
INFO - 2020-09-12 02:09:09 --> Language Class Initialized
INFO - 2020-09-12 02:09:09 --> Config Class Initialized
INFO - 2020-09-12 02:09:09 --> Loader Class Initialized
INFO - 2020-09-12 02:09:09 --> Helper loaded: url_helper
INFO - 2020-09-12 02:09:09 --> Helper loaded: form_helper
INFO - 2020-09-12 02:09:09 --> Helper loaded: file_helper
INFO - 2020-09-12 02:09:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 02:09:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 02:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 02:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 02:09:09 --> Upload Class Initialized
INFO - 2020-09-12 02:09:09 --> Controller Class Initialized
ERROR - 2020-09-12 02:09:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 02:09:15 --> Config Class Initialized
INFO - 2020-09-12 02:09:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 02:09:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 02:09:15 --> Utf8 Class Initialized
INFO - 2020-09-12 02:09:15 --> URI Class Initialized
INFO - 2020-09-12 02:09:15 --> Router Class Initialized
INFO - 2020-09-12 02:09:15 --> Output Class Initialized
INFO - 2020-09-12 02:09:15 --> Security Class Initialized
DEBUG - 2020-09-12 02:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 02:09:15 --> Input Class Initialized
INFO - 2020-09-12 02:09:15 --> Language Class Initialized
INFO - 2020-09-12 02:09:15 --> Language Class Initialized
INFO - 2020-09-12 02:09:15 --> Config Class Initialized
INFO - 2020-09-12 02:09:15 --> Loader Class Initialized
INFO - 2020-09-12 02:09:15 --> Helper loaded: url_helper
INFO - 2020-09-12 02:09:15 --> Helper loaded: form_helper
INFO - 2020-09-12 02:09:15 --> Helper loaded: file_helper
INFO - 2020-09-12 02:09:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 02:09:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 02:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 02:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 02:09:15 --> Upload Class Initialized
INFO - 2020-09-12 02:09:15 --> Controller Class Initialized
ERROR - 2020-09-12 02:09:15 --> 404 Page Not Found: /index
INFO - 2020-09-12 02:16:26 --> Config Class Initialized
INFO - 2020-09-12 02:16:26 --> Hooks Class Initialized
DEBUG - 2020-09-12 02:16:26 --> UTF-8 Support Enabled
INFO - 2020-09-12 02:16:26 --> Utf8 Class Initialized
INFO - 2020-09-12 02:16:26 --> URI Class Initialized
DEBUG - 2020-09-12 02:16:26 --> No URI present. Default controller set.
INFO - 2020-09-12 02:16:26 --> Router Class Initialized
INFO - 2020-09-12 02:16:26 --> Output Class Initialized
INFO - 2020-09-12 02:16:26 --> Security Class Initialized
DEBUG - 2020-09-12 02:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 02:16:26 --> Input Class Initialized
INFO - 2020-09-12 02:16:26 --> Language Class Initialized
INFO - 2020-09-12 02:16:26 --> Language Class Initialized
INFO - 2020-09-12 02:16:26 --> Config Class Initialized
INFO - 2020-09-12 02:16:26 --> Loader Class Initialized
INFO - 2020-09-12 02:16:26 --> Helper loaded: url_helper
INFO - 2020-09-12 02:16:26 --> Helper loaded: form_helper
INFO - 2020-09-12 02:16:26 --> Helper loaded: file_helper
INFO - 2020-09-12 02:16:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 02:16:26 --> Database Driver Class Initialized
DEBUG - 2020-09-12 02:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 02:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 02:16:26 --> Upload Class Initialized
INFO - 2020-09-12 02:16:26 --> Controller Class Initialized
DEBUG - 2020-09-12 02:16:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 02:16:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 02:16:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 02:16:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 02:16:26 --> Final output sent to browser
DEBUG - 2020-09-12 02:16:26 --> Total execution time: 0.0420
INFO - 2020-09-12 02:23:47 --> Config Class Initialized
INFO - 2020-09-12 02:23:47 --> Hooks Class Initialized
DEBUG - 2020-09-12 02:23:47 --> UTF-8 Support Enabled
INFO - 2020-09-12 02:23:47 --> Utf8 Class Initialized
INFO - 2020-09-12 02:23:47 --> URI Class Initialized
INFO - 2020-09-12 02:23:47 --> Router Class Initialized
INFO - 2020-09-12 02:23:47 --> Output Class Initialized
INFO - 2020-09-12 02:23:47 --> Security Class Initialized
DEBUG - 2020-09-12 02:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 02:23:47 --> Input Class Initialized
INFO - 2020-09-12 02:23:47 --> Language Class Initialized
INFO - 2020-09-12 02:23:47 --> Language Class Initialized
INFO - 2020-09-12 02:23:47 --> Config Class Initialized
INFO - 2020-09-12 02:23:47 --> Loader Class Initialized
INFO - 2020-09-12 02:23:47 --> Helper loaded: url_helper
INFO - 2020-09-12 02:23:47 --> Helper loaded: form_helper
INFO - 2020-09-12 02:23:47 --> Helper loaded: file_helper
INFO - 2020-09-12 02:23:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 02:23:47 --> Database Driver Class Initialized
DEBUG - 2020-09-12 02:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 02:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 02:23:47 --> Upload Class Initialized
INFO - 2020-09-12 02:23:47 --> Controller Class Initialized
ERROR - 2020-09-12 02:23:47 --> 404 Page Not Found: /index
INFO - 2020-09-12 02:24:15 --> Config Class Initialized
INFO - 2020-09-12 02:24:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 02:24:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 02:24:15 --> Utf8 Class Initialized
INFO - 2020-09-12 02:24:15 --> URI Class Initialized
INFO - 2020-09-12 02:24:15 --> Router Class Initialized
INFO - 2020-09-12 02:24:15 --> Output Class Initialized
INFO - 2020-09-12 02:24:15 --> Security Class Initialized
DEBUG - 2020-09-12 02:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 02:24:15 --> Input Class Initialized
INFO - 2020-09-12 02:24:15 --> Language Class Initialized
INFO - 2020-09-12 02:24:15 --> Language Class Initialized
INFO - 2020-09-12 02:24:15 --> Config Class Initialized
INFO - 2020-09-12 02:24:15 --> Loader Class Initialized
INFO - 2020-09-12 02:24:15 --> Helper loaded: url_helper
INFO - 2020-09-12 02:24:15 --> Helper loaded: form_helper
INFO - 2020-09-12 02:24:15 --> Helper loaded: file_helper
INFO - 2020-09-12 02:24:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 02:24:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 02:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 02:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 02:24:15 --> Upload Class Initialized
INFO - 2020-09-12 02:24:15 --> Controller Class Initialized
ERROR - 2020-09-12 02:24:15 --> 404 Page Not Found: /index
INFO - 2020-09-12 03:08:56 --> Config Class Initialized
INFO - 2020-09-12 03:08:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 03:08:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 03:08:56 --> Utf8 Class Initialized
INFO - 2020-09-12 03:08:56 --> URI Class Initialized
INFO - 2020-09-12 03:08:56 --> Router Class Initialized
INFO - 2020-09-12 03:08:56 --> Output Class Initialized
INFO - 2020-09-12 03:08:56 --> Security Class Initialized
DEBUG - 2020-09-12 03:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 03:08:56 --> Input Class Initialized
INFO - 2020-09-12 03:08:56 --> Language Class Initialized
INFO - 2020-09-12 03:08:56 --> Language Class Initialized
INFO - 2020-09-12 03:08:56 --> Config Class Initialized
INFO - 2020-09-12 03:08:56 --> Loader Class Initialized
INFO - 2020-09-12 03:08:56 --> Helper loaded: url_helper
INFO - 2020-09-12 03:08:56 --> Helper loaded: form_helper
INFO - 2020-09-12 03:08:56 --> Helper loaded: file_helper
INFO - 2020-09-12 03:08:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 03:08:56 --> Database Driver Class Initialized
DEBUG - 2020-09-12 03:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 03:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 03:08:56 --> Upload Class Initialized
INFO - 2020-09-12 03:08:56 --> Controller Class Initialized
ERROR - 2020-09-12 03:08:56 --> 404 Page Not Found: /index
INFO - 2020-09-12 03:21:14 --> Config Class Initialized
INFO - 2020-09-12 03:21:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 03:21:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 03:21:14 --> Utf8 Class Initialized
INFO - 2020-09-12 03:21:14 --> URI Class Initialized
DEBUG - 2020-09-12 03:21:14 --> No URI present. Default controller set.
INFO - 2020-09-12 03:21:14 --> Router Class Initialized
INFO - 2020-09-12 03:21:14 --> Output Class Initialized
INFO - 2020-09-12 03:21:14 --> Security Class Initialized
DEBUG - 2020-09-12 03:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 03:21:14 --> Input Class Initialized
INFO - 2020-09-12 03:21:14 --> Language Class Initialized
INFO - 2020-09-12 03:21:14 --> Language Class Initialized
INFO - 2020-09-12 03:21:14 --> Config Class Initialized
INFO - 2020-09-12 03:21:14 --> Loader Class Initialized
INFO - 2020-09-12 03:21:14 --> Helper loaded: url_helper
INFO - 2020-09-12 03:21:14 --> Helper loaded: form_helper
INFO - 2020-09-12 03:21:14 --> Helper loaded: file_helper
INFO - 2020-09-12 03:21:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 03:21:14 --> Database Driver Class Initialized
DEBUG - 2020-09-12 03:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 03:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 03:21:14 --> Upload Class Initialized
INFO - 2020-09-12 03:21:14 --> Controller Class Initialized
DEBUG - 2020-09-12 03:21:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 03:21:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 03:21:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 03:21:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 03:21:14 --> Final output sent to browser
DEBUG - 2020-09-12 03:21:14 --> Total execution time: 0.0593
INFO - 2020-09-12 03:27:04 --> Config Class Initialized
INFO - 2020-09-12 03:27:04 --> Hooks Class Initialized
DEBUG - 2020-09-12 03:27:04 --> UTF-8 Support Enabled
INFO - 2020-09-12 03:27:04 --> Utf8 Class Initialized
INFO - 2020-09-12 03:27:04 --> URI Class Initialized
INFO - 2020-09-12 03:27:04 --> Router Class Initialized
INFO - 2020-09-12 03:27:04 --> Output Class Initialized
INFO - 2020-09-12 03:27:04 --> Security Class Initialized
DEBUG - 2020-09-12 03:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 03:27:04 --> Input Class Initialized
INFO - 2020-09-12 03:27:04 --> Language Class Initialized
INFO - 2020-09-12 03:27:04 --> Language Class Initialized
INFO - 2020-09-12 03:27:04 --> Config Class Initialized
INFO - 2020-09-12 03:27:04 --> Loader Class Initialized
INFO - 2020-09-12 03:27:04 --> Helper loaded: url_helper
INFO - 2020-09-12 03:27:04 --> Helper loaded: form_helper
INFO - 2020-09-12 03:27:04 --> Helper loaded: file_helper
INFO - 2020-09-12 03:27:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 03:27:04 --> Database Driver Class Initialized
DEBUG - 2020-09-12 03:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 03:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 03:27:04 --> Upload Class Initialized
INFO - 2020-09-12 03:27:04 --> Controller Class Initialized
ERROR - 2020-09-12 03:27:04 --> 404 Page Not Found: /index
INFO - 2020-09-12 03:43:51 --> Config Class Initialized
INFO - 2020-09-12 03:43:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 03:43:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 03:43:51 --> Utf8 Class Initialized
INFO - 2020-09-12 03:43:51 --> URI Class Initialized
INFO - 2020-09-12 03:43:51 --> Router Class Initialized
INFO - 2020-09-12 03:43:51 --> Output Class Initialized
INFO - 2020-09-12 03:43:51 --> Security Class Initialized
DEBUG - 2020-09-12 03:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 03:43:51 --> Input Class Initialized
INFO - 2020-09-12 03:43:51 --> Language Class Initialized
INFO - 2020-09-12 03:43:51 --> Language Class Initialized
INFO - 2020-09-12 03:43:51 --> Config Class Initialized
INFO - 2020-09-12 03:43:51 --> Loader Class Initialized
INFO - 2020-09-12 03:43:51 --> Helper loaded: url_helper
INFO - 2020-09-12 03:43:51 --> Helper loaded: form_helper
INFO - 2020-09-12 03:43:51 --> Helper loaded: file_helper
INFO - 2020-09-12 03:43:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 03:43:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 03:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 03:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 03:43:51 --> Upload Class Initialized
INFO - 2020-09-12 03:43:51 --> Controller Class Initialized
ERROR - 2020-09-12 03:43:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 03:44:00 --> Config Class Initialized
INFO - 2020-09-12 03:44:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 03:44:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 03:44:00 --> Utf8 Class Initialized
INFO - 2020-09-12 03:44:00 --> URI Class Initialized
INFO - 2020-09-12 03:44:00 --> Router Class Initialized
INFO - 2020-09-12 03:44:00 --> Output Class Initialized
INFO - 2020-09-12 03:44:00 --> Security Class Initialized
DEBUG - 2020-09-12 03:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 03:44:00 --> Input Class Initialized
INFO - 2020-09-12 03:44:00 --> Language Class Initialized
INFO - 2020-09-12 03:44:00 --> Language Class Initialized
INFO - 2020-09-12 03:44:00 --> Config Class Initialized
INFO - 2020-09-12 03:44:00 --> Loader Class Initialized
INFO - 2020-09-12 03:44:00 --> Helper loaded: url_helper
INFO - 2020-09-12 03:44:00 --> Helper loaded: form_helper
INFO - 2020-09-12 03:44:00 --> Helper loaded: file_helper
INFO - 2020-09-12 03:44:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 03:44:00 --> Database Driver Class Initialized
DEBUG - 2020-09-12 03:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 03:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 03:44:00 --> Upload Class Initialized
INFO - 2020-09-12 03:44:00 --> Controller Class Initialized
ERROR - 2020-09-12 03:44:00 --> 404 Page Not Found: /index
INFO - 2020-09-12 03:53:14 --> Config Class Initialized
INFO - 2020-09-12 03:53:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 03:53:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 03:53:14 --> Utf8 Class Initialized
INFO - 2020-09-12 03:53:14 --> URI Class Initialized
DEBUG - 2020-09-12 03:53:14 --> No URI present. Default controller set.
INFO - 2020-09-12 03:53:14 --> Router Class Initialized
INFO - 2020-09-12 03:53:14 --> Output Class Initialized
INFO - 2020-09-12 03:53:14 --> Security Class Initialized
DEBUG - 2020-09-12 03:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 03:53:14 --> Input Class Initialized
INFO - 2020-09-12 03:53:14 --> Language Class Initialized
INFO - 2020-09-12 03:53:14 --> Language Class Initialized
INFO - 2020-09-12 03:53:14 --> Config Class Initialized
INFO - 2020-09-12 03:53:14 --> Loader Class Initialized
INFO - 2020-09-12 03:53:14 --> Helper loaded: url_helper
INFO - 2020-09-12 03:53:14 --> Helper loaded: form_helper
INFO - 2020-09-12 03:53:14 --> Helper loaded: file_helper
INFO - 2020-09-12 03:53:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 03:53:14 --> Database Driver Class Initialized
DEBUG - 2020-09-12 03:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 03:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 03:53:14 --> Upload Class Initialized
INFO - 2020-09-12 03:53:14 --> Controller Class Initialized
DEBUG - 2020-09-12 03:53:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 03:53:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 03:53:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 03:53:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 03:53:14 --> Final output sent to browser
DEBUG - 2020-09-12 03:53:14 --> Total execution time: 0.0558
INFO - 2020-09-12 04:21:13 --> Config Class Initialized
INFO - 2020-09-12 04:21:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 04:21:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 04:21:13 --> Utf8 Class Initialized
INFO - 2020-09-12 04:21:13 --> URI Class Initialized
DEBUG - 2020-09-12 04:21:13 --> No URI present. Default controller set.
INFO - 2020-09-12 04:21:13 --> Router Class Initialized
INFO - 2020-09-12 04:21:13 --> Output Class Initialized
INFO - 2020-09-12 04:21:13 --> Security Class Initialized
DEBUG - 2020-09-12 04:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 04:21:13 --> Input Class Initialized
INFO - 2020-09-12 04:21:13 --> Language Class Initialized
INFO - 2020-09-12 04:21:13 --> Language Class Initialized
INFO - 2020-09-12 04:21:13 --> Config Class Initialized
INFO - 2020-09-12 04:21:13 --> Loader Class Initialized
INFO - 2020-09-12 04:21:13 --> Helper loaded: url_helper
INFO - 2020-09-12 04:21:13 --> Helper loaded: form_helper
INFO - 2020-09-12 04:21:13 --> Helper loaded: file_helper
INFO - 2020-09-12 04:21:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 04:21:13 --> Database Driver Class Initialized
DEBUG - 2020-09-12 04:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 04:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 04:21:13 --> Upload Class Initialized
INFO - 2020-09-12 04:21:13 --> Controller Class Initialized
DEBUG - 2020-09-12 04:21:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 04:21:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 04:21:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 04:21:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 04:21:13 --> Final output sent to browser
DEBUG - 2020-09-12 04:21:13 --> Total execution time: 0.0538
INFO - 2020-09-12 05:04:42 --> Config Class Initialized
INFO - 2020-09-12 05:04:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:04:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:04:42 --> Utf8 Class Initialized
INFO - 2020-09-12 05:04:42 --> URI Class Initialized
INFO - 2020-09-12 05:04:42 --> Router Class Initialized
INFO - 2020-09-12 05:04:42 --> Output Class Initialized
INFO - 2020-09-12 05:04:42 --> Security Class Initialized
DEBUG - 2020-09-12 05:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:04:42 --> Input Class Initialized
INFO - 2020-09-12 05:04:42 --> Language Class Initialized
INFO - 2020-09-12 05:04:42 --> Language Class Initialized
INFO - 2020-09-12 05:04:42 --> Config Class Initialized
INFO - 2020-09-12 05:04:42 --> Loader Class Initialized
INFO - 2020-09-12 05:04:42 --> Helper loaded: url_helper
INFO - 2020-09-12 05:04:42 --> Helper loaded: form_helper
INFO - 2020-09-12 05:04:42 --> Helper loaded: file_helper
INFO - 2020-09-12 05:04:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:04:42 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:04:42 --> Upload Class Initialized
INFO - 2020-09-12 05:04:42 --> Controller Class Initialized
ERROR - 2020-09-12 05:04:42 --> 404 Page Not Found: /index
INFO - 2020-09-12 05:14:14 --> Config Class Initialized
INFO - 2020-09-12 05:14:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:14:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:14:14 --> Utf8 Class Initialized
INFO - 2020-09-12 05:14:14 --> URI Class Initialized
DEBUG - 2020-09-12 05:14:14 --> No URI present. Default controller set.
INFO - 2020-09-12 05:14:14 --> Router Class Initialized
INFO - 2020-09-12 05:14:14 --> Output Class Initialized
INFO - 2020-09-12 05:14:14 --> Security Class Initialized
DEBUG - 2020-09-12 05:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:14:14 --> Input Class Initialized
INFO - 2020-09-12 05:14:14 --> Language Class Initialized
INFO - 2020-09-12 05:14:14 --> Language Class Initialized
INFO - 2020-09-12 05:14:14 --> Config Class Initialized
INFO - 2020-09-12 05:14:14 --> Loader Class Initialized
INFO - 2020-09-12 05:14:14 --> Helper loaded: url_helper
INFO - 2020-09-12 05:14:14 --> Helper loaded: form_helper
INFO - 2020-09-12 05:14:14 --> Helper loaded: file_helper
INFO - 2020-09-12 05:14:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:14:14 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:14:14 --> Upload Class Initialized
INFO - 2020-09-12 05:14:14 --> Controller Class Initialized
DEBUG - 2020-09-12 05:14:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:14:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 05:14:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 05:14:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:14:14 --> Final output sent to browser
DEBUG - 2020-09-12 05:14:14 --> Total execution time: 0.0627
INFO - 2020-09-12 05:14:14 --> Config Class Initialized
INFO - 2020-09-12 05:14:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:14:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:14:14 --> Utf8 Class Initialized
INFO - 2020-09-12 05:14:14 --> URI Class Initialized
DEBUG - 2020-09-12 05:14:14 --> No URI present. Default controller set.
INFO - 2020-09-12 05:14:14 --> Router Class Initialized
INFO - 2020-09-12 05:14:14 --> Output Class Initialized
INFO - 2020-09-12 05:14:14 --> Security Class Initialized
DEBUG - 2020-09-12 05:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:14:14 --> Input Class Initialized
INFO - 2020-09-12 05:14:14 --> Language Class Initialized
INFO - 2020-09-12 05:14:14 --> Language Class Initialized
INFO - 2020-09-12 05:14:14 --> Config Class Initialized
INFO - 2020-09-12 05:14:14 --> Loader Class Initialized
INFO - 2020-09-12 05:14:14 --> Helper loaded: url_helper
INFO - 2020-09-12 05:14:14 --> Helper loaded: form_helper
INFO - 2020-09-12 05:14:14 --> Helper loaded: file_helper
INFO - 2020-09-12 05:14:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:14:14 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:14:14 --> Upload Class Initialized
INFO - 2020-09-12 05:14:14 --> Controller Class Initialized
DEBUG - 2020-09-12 05:14:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:14:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 05:14:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 05:14:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:14:14 --> Final output sent to browser
DEBUG - 2020-09-12 05:14:14 --> Total execution time: 0.0508
INFO - 2020-09-12 05:56:22 --> Config Class Initialized
INFO - 2020-09-12 05:56:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:56:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:56:22 --> Utf8 Class Initialized
INFO - 2020-09-12 05:56:22 --> URI Class Initialized
INFO - 2020-09-12 05:56:22 --> Router Class Initialized
INFO - 2020-09-12 05:56:22 --> Output Class Initialized
INFO - 2020-09-12 05:56:22 --> Security Class Initialized
DEBUG - 2020-09-12 05:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:56:22 --> Input Class Initialized
INFO - 2020-09-12 05:56:22 --> Language Class Initialized
INFO - 2020-09-12 05:56:22 --> Language Class Initialized
INFO - 2020-09-12 05:56:22 --> Config Class Initialized
INFO - 2020-09-12 05:56:22 --> Loader Class Initialized
INFO - 2020-09-12 05:56:22 --> Helper loaded: url_helper
INFO - 2020-09-12 05:56:22 --> Helper loaded: form_helper
INFO - 2020-09-12 05:56:22 --> Helper loaded: file_helper
INFO - 2020-09-12 05:56:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:56:22 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:56:22 --> Upload Class Initialized
INFO - 2020-09-12 05:56:22 --> Controller Class Initialized
ERROR - 2020-09-12 05:56:22 --> 404 Page Not Found: /index
INFO - 2020-09-12 05:56:30 --> Config Class Initialized
INFO - 2020-09-12 05:56:30 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:56:30 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:56:30 --> Utf8 Class Initialized
INFO - 2020-09-12 05:56:30 --> URI Class Initialized
INFO - 2020-09-12 05:56:30 --> Router Class Initialized
INFO - 2020-09-12 05:56:30 --> Output Class Initialized
INFO - 2020-09-12 05:56:30 --> Security Class Initialized
DEBUG - 2020-09-12 05:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:56:30 --> Input Class Initialized
INFO - 2020-09-12 05:56:30 --> Language Class Initialized
INFO - 2020-09-12 05:56:30 --> Language Class Initialized
INFO - 2020-09-12 05:56:30 --> Config Class Initialized
INFO - 2020-09-12 05:56:30 --> Loader Class Initialized
INFO - 2020-09-12 05:56:30 --> Helper loaded: url_helper
INFO - 2020-09-12 05:56:30 --> Helper loaded: form_helper
INFO - 2020-09-12 05:56:30 --> Helper loaded: file_helper
INFO - 2020-09-12 05:56:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:56:30 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:56:30 --> Upload Class Initialized
INFO - 2020-09-12 05:56:30 --> Controller Class Initialized
ERROR - 2020-09-12 05:56:30 --> 404 Page Not Found: /index
INFO - 2020-09-12 05:56:34 --> Config Class Initialized
INFO - 2020-09-12 05:56:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:56:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:56:34 --> Utf8 Class Initialized
INFO - 2020-09-12 05:56:34 --> URI Class Initialized
DEBUG - 2020-09-12 05:56:34 --> No URI present. Default controller set.
INFO - 2020-09-12 05:56:34 --> Router Class Initialized
INFO - 2020-09-12 05:56:34 --> Output Class Initialized
INFO - 2020-09-12 05:56:34 --> Security Class Initialized
DEBUG - 2020-09-12 05:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:56:34 --> Input Class Initialized
INFO - 2020-09-12 05:56:34 --> Language Class Initialized
INFO - 2020-09-12 05:56:34 --> Language Class Initialized
INFO - 2020-09-12 05:56:34 --> Config Class Initialized
INFO - 2020-09-12 05:56:34 --> Loader Class Initialized
INFO - 2020-09-12 05:56:34 --> Helper loaded: url_helper
INFO - 2020-09-12 05:56:34 --> Helper loaded: form_helper
INFO - 2020-09-12 05:56:34 --> Helper loaded: file_helper
INFO - 2020-09-12 05:56:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:56:34 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:56:34 --> Upload Class Initialized
INFO - 2020-09-12 05:56:34 --> Controller Class Initialized
DEBUG - 2020-09-12 05:56:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:56:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 05:56:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 05:56:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:56:34 --> Final output sent to browser
DEBUG - 2020-09-12 05:56:34 --> Total execution time: 0.0385
INFO - 2020-09-12 05:56:40 --> Config Class Initialized
INFO - 2020-09-12 05:56:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:56:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:56:40 --> Utf8 Class Initialized
INFO - 2020-09-12 05:56:40 --> URI Class Initialized
DEBUG - 2020-09-12 05:56:40 --> No URI present. Default controller set.
INFO - 2020-09-12 05:56:40 --> Router Class Initialized
INFO - 2020-09-12 05:56:40 --> Output Class Initialized
INFO - 2020-09-12 05:56:40 --> Security Class Initialized
DEBUG - 2020-09-12 05:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:56:40 --> Input Class Initialized
INFO - 2020-09-12 05:56:40 --> Language Class Initialized
INFO - 2020-09-12 05:56:40 --> Language Class Initialized
INFO - 2020-09-12 05:56:40 --> Config Class Initialized
INFO - 2020-09-12 05:56:40 --> Loader Class Initialized
INFO - 2020-09-12 05:56:40 --> Helper loaded: url_helper
INFO - 2020-09-12 05:56:40 --> Helper loaded: form_helper
INFO - 2020-09-12 05:56:40 --> Helper loaded: file_helper
INFO - 2020-09-12 05:56:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:56:40 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:56:40 --> Upload Class Initialized
INFO - 2020-09-12 05:56:40 --> Controller Class Initialized
DEBUG - 2020-09-12 05:56:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:56:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 05:56:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 05:56:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:56:40 --> Final output sent to browser
DEBUG - 2020-09-12 05:56:40 --> Total execution time: 0.0394
INFO - 2020-09-12 05:57:00 --> Config Class Initialized
INFO - 2020-09-12 05:57:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:00 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:00 --> URI Class Initialized
INFO - 2020-09-12 05:57:00 --> Router Class Initialized
INFO - 2020-09-12 05:57:00 --> Output Class Initialized
INFO - 2020-09-12 05:57:00 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:00 --> Input Class Initialized
INFO - 2020-09-12 05:57:00 --> Language Class Initialized
INFO - 2020-09-12 05:57:00 --> Language Class Initialized
INFO - 2020-09-12 05:57:00 --> Config Class Initialized
INFO - 2020-09-12 05:57:00 --> Loader Class Initialized
INFO - 2020-09-12 05:57:00 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:00 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:00 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:00 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:00 --> Upload Class Initialized
INFO - 2020-09-12 05:57:01 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/terms_and_conditions.php
DEBUG - 2020-09-12 05:57:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:01 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:01 --> Total execution time: 0.0490
INFO - 2020-09-12 05:57:04 --> Config Class Initialized
INFO - 2020-09-12 05:57:04 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:04 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:04 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:04 --> URI Class Initialized
INFO - 2020-09-12 05:57:04 --> Router Class Initialized
INFO - 2020-09-12 05:57:04 --> Output Class Initialized
INFO - 2020-09-12 05:57:04 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:04 --> Input Class Initialized
INFO - 2020-09-12 05:57:04 --> Language Class Initialized
INFO - 2020-09-12 05:57:04 --> Language Class Initialized
INFO - 2020-09-12 05:57:04 --> Config Class Initialized
INFO - 2020-09-12 05:57:04 --> Loader Class Initialized
INFO - 2020-09-12 05:57:04 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:04 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:04 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:04 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:04 --> Upload Class Initialized
INFO - 2020-09-12 05:57:04 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-12 05:57:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:04 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:04 --> Total execution time: 0.0575
INFO - 2020-09-12 05:57:07 --> Config Class Initialized
INFO - 2020-09-12 05:57:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:07 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:07 --> URI Class Initialized
INFO - 2020-09-12 05:57:07 --> Router Class Initialized
INFO - 2020-09-12 05:57:07 --> Output Class Initialized
INFO - 2020-09-12 05:57:07 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:07 --> Input Class Initialized
INFO - 2020-09-12 05:57:07 --> Language Class Initialized
INFO - 2020-09-12 05:57:07 --> Language Class Initialized
INFO - 2020-09-12 05:57:07 --> Config Class Initialized
INFO - 2020-09-12 05:57:07 --> Loader Class Initialized
INFO - 2020-09-12 05:57:07 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:07 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:07 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:07 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:07 --> Upload Class Initialized
INFO - 2020-09-12 05:57:07 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/refund_policy.php
DEBUG - 2020-09-12 05:57:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:07 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:07 --> Total execution time: 0.0459
INFO - 2020-09-12 05:57:10 --> Config Class Initialized
INFO - 2020-09-12 05:57:10 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:10 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:10 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:10 --> URI Class Initialized
INFO - 2020-09-12 05:57:10 --> Router Class Initialized
INFO - 2020-09-12 05:57:10 --> Output Class Initialized
INFO - 2020-09-12 05:57:10 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:10 --> Input Class Initialized
INFO - 2020-09-12 05:57:10 --> Language Class Initialized
INFO - 2020-09-12 05:57:10 --> Language Class Initialized
INFO - 2020-09-12 05:57:10 --> Config Class Initialized
INFO - 2020-09-12 05:57:10 --> Loader Class Initialized
INFO - 2020-09-12 05:57:10 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:10 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:10 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:10 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:10 --> Upload Class Initialized
INFO - 2020-09-12 05:57:10 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-12 05:57:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:10 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:10 --> Total execution time: 0.0600
INFO - 2020-09-12 05:57:13 --> Config Class Initialized
INFO - 2020-09-12 05:57:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:13 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:13 --> URI Class Initialized
INFO - 2020-09-12 05:57:13 --> Router Class Initialized
INFO - 2020-09-12 05:57:13 --> Output Class Initialized
INFO - 2020-09-12 05:57:13 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:13 --> Input Class Initialized
INFO - 2020-09-12 05:57:13 --> Language Class Initialized
INFO - 2020-09-12 05:57:13 --> Language Class Initialized
INFO - 2020-09-12 05:57:13 --> Config Class Initialized
INFO - 2020-09-12 05:57:13 --> Loader Class Initialized
INFO - 2020-09-12 05:57:13 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:13 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:13 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:13 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:13 --> Upload Class Initialized
INFO - 2020-09-12 05:57:13 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-12 05:57:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:13 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:13 --> Total execution time: 0.0691
INFO - 2020-09-12 05:57:17 --> Config Class Initialized
INFO - 2020-09-12 05:57:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:17 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:17 --> URI Class Initialized
INFO - 2020-09-12 05:57:17 --> Router Class Initialized
INFO - 2020-09-12 05:57:17 --> Output Class Initialized
INFO - 2020-09-12 05:57:17 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:17 --> Input Class Initialized
INFO - 2020-09-12 05:57:17 --> Language Class Initialized
INFO - 2020-09-12 05:57:17 --> Language Class Initialized
INFO - 2020-09-12 05:57:17 --> Config Class Initialized
INFO - 2020-09-12 05:57:17 --> Loader Class Initialized
INFO - 2020-09-12 05:57:17 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:17 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:17 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:17 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:17 --> Upload Class Initialized
INFO - 2020-09-12 05:57:17 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 05:57:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 05:57:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:17 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:17 --> Total execution time: 0.0532
INFO - 2020-09-12 05:57:19 --> Config Class Initialized
INFO - 2020-09-12 05:57:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:19 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:19 --> URI Class Initialized
INFO - 2020-09-12 05:57:19 --> Router Class Initialized
INFO - 2020-09-12 05:57:19 --> Output Class Initialized
INFO - 2020-09-12 05:57:19 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:19 --> Input Class Initialized
INFO - 2020-09-12 05:57:19 --> Language Class Initialized
INFO - 2020-09-12 05:57:19 --> Language Class Initialized
INFO - 2020-09-12 05:57:19 --> Config Class Initialized
INFO - 2020-09-12 05:57:19 --> Loader Class Initialized
INFO - 2020-09-12 05:57:19 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:19 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:19 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:19 --> Upload Class Initialized
INFO - 2020-09-12 05:57:19 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-12 05:57:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:19 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:19 --> Total execution time: 0.0560
INFO - 2020-09-12 05:57:22 --> Config Class Initialized
INFO - 2020-09-12 05:57:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:22 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:22 --> URI Class Initialized
INFO - 2020-09-12 05:57:22 --> Router Class Initialized
INFO - 2020-09-12 05:57:22 --> Output Class Initialized
INFO - 2020-09-12 05:57:22 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:22 --> Input Class Initialized
INFO - 2020-09-12 05:57:22 --> Language Class Initialized
INFO - 2020-09-12 05:57:22 --> Language Class Initialized
INFO - 2020-09-12 05:57:22 --> Config Class Initialized
INFO - 2020-09-12 05:57:22 --> Loader Class Initialized
INFO - 2020-09-12 05:57:22 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:22 --> Helper loaded: form_helper
INFO - 2020-09-12 05:57:22 --> Helper loaded: file_helper
INFO - 2020-09-12 05:57:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 05:57:22 --> Database Driver Class Initialized
DEBUG - 2020-09-12 05:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 05:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:22 --> Upload Class Initialized
INFO - 2020-09-12 05:57:22 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 05:57:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/privacy_policy.php
DEBUG - 2020-09-12 05:57:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 05:57:22 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:22 --> Total execution time: 0.0567
INFO - 2020-09-12 07:10:16 --> Config Class Initialized
INFO - 2020-09-12 07:10:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:10:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:10:16 --> Utf8 Class Initialized
INFO - 2020-09-12 07:10:16 --> URI Class Initialized
INFO - 2020-09-12 07:10:16 --> Router Class Initialized
INFO - 2020-09-12 07:10:16 --> Output Class Initialized
INFO - 2020-09-12 07:10:16 --> Security Class Initialized
DEBUG - 2020-09-12 07:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:10:16 --> Input Class Initialized
INFO - 2020-09-12 07:10:16 --> Language Class Initialized
INFO - 2020-09-12 07:10:16 --> Language Class Initialized
INFO - 2020-09-12 07:10:16 --> Config Class Initialized
INFO - 2020-09-12 07:10:16 --> Loader Class Initialized
INFO - 2020-09-12 07:10:16 --> Helper loaded: url_helper
INFO - 2020-09-12 07:10:16 --> Helper loaded: form_helper
INFO - 2020-09-12 07:10:16 --> Helper loaded: file_helper
INFO - 2020-09-12 07:10:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:10:16 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:10:16 --> Upload Class Initialized
INFO - 2020-09-12 07:10:16 --> Controller Class Initialized
ERROR - 2020-09-12 07:10:16 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:10:17 --> Config Class Initialized
INFO - 2020-09-12 07:10:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:10:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:10:17 --> Utf8 Class Initialized
INFO - 2020-09-12 07:10:17 --> URI Class Initialized
DEBUG - 2020-09-12 07:10:17 --> No URI present. Default controller set.
INFO - 2020-09-12 07:10:17 --> Router Class Initialized
INFO - 2020-09-12 07:10:17 --> Output Class Initialized
INFO - 2020-09-12 07:10:17 --> Security Class Initialized
DEBUG - 2020-09-12 07:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:10:17 --> Input Class Initialized
INFO - 2020-09-12 07:10:17 --> Language Class Initialized
INFO - 2020-09-12 07:10:17 --> Language Class Initialized
INFO - 2020-09-12 07:10:17 --> Config Class Initialized
INFO - 2020-09-12 07:10:17 --> Loader Class Initialized
INFO - 2020-09-12 07:10:17 --> Helper loaded: url_helper
INFO - 2020-09-12 07:10:17 --> Helper loaded: form_helper
INFO - 2020-09-12 07:10:17 --> Helper loaded: file_helper
INFO - 2020-09-12 07:10:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:10:17 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:10:17 --> Upload Class Initialized
INFO - 2020-09-12 07:10:17 --> Controller Class Initialized
DEBUG - 2020-09-12 07:10:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 07:10:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 07:10:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 07:10:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 07:10:17 --> Final output sent to browser
DEBUG - 2020-09-12 07:10:17 --> Total execution time: 0.0412
INFO - 2020-09-12 07:33:35 --> Config Class Initialized
INFO - 2020-09-12 07:33:35 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:35 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:35 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:35 --> URI Class Initialized
DEBUG - 2020-09-12 07:33:35 --> No URI present. Default controller set.
INFO - 2020-09-12 07:33:35 --> Router Class Initialized
INFO - 2020-09-12 07:33:35 --> Output Class Initialized
INFO - 2020-09-12 07:33:35 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:35 --> Input Class Initialized
INFO - 2020-09-12 07:33:35 --> Language Class Initialized
INFO - 2020-09-12 07:33:35 --> Language Class Initialized
INFO - 2020-09-12 07:33:35 --> Config Class Initialized
INFO - 2020-09-12 07:33:35 --> Loader Class Initialized
INFO - 2020-09-12 07:33:35 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:35 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:35 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:36 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:36 --> Upload Class Initialized
INFO - 2020-09-12 07:33:36 --> Controller Class Initialized
DEBUG - 2020-09-12 07:33:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 07:33:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 07:33:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 07:33:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 07:33:36 --> Final output sent to browser
DEBUG - 2020-09-12 07:33:36 --> Total execution time: 0.0581
INFO - 2020-09-12 07:33:36 --> Config Class Initialized
INFO - 2020-09-12 07:33:36 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:36 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:36 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:36 --> URI Class Initialized
INFO - 2020-09-12 07:33:36 --> Router Class Initialized
INFO - 2020-09-12 07:33:36 --> Output Class Initialized
INFO - 2020-09-12 07:33:36 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:36 --> Input Class Initialized
INFO - 2020-09-12 07:33:36 --> Language Class Initialized
INFO - 2020-09-12 07:33:36 --> Language Class Initialized
INFO - 2020-09-12 07:33:36 --> Config Class Initialized
INFO - 2020-09-12 07:33:36 --> Loader Class Initialized
INFO - 2020-09-12 07:33:36 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:36 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:36 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:36 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:36 --> Upload Class Initialized
INFO - 2020-09-12 07:33:36 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:36 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:37 --> Config Class Initialized
INFO - 2020-09-12 07:33:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:37 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:37 --> URI Class Initialized
INFO - 2020-09-12 07:33:37 --> Router Class Initialized
INFO - 2020-09-12 07:33:37 --> Output Class Initialized
INFO - 2020-09-12 07:33:37 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:37 --> Input Class Initialized
INFO - 2020-09-12 07:33:37 --> Language Class Initialized
INFO - 2020-09-12 07:33:37 --> Language Class Initialized
INFO - 2020-09-12 07:33:37 --> Config Class Initialized
INFO - 2020-09-12 07:33:37 --> Loader Class Initialized
INFO - 2020-09-12 07:33:37 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:37 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:37 --> Upload Class Initialized
INFO - 2020-09-12 07:33:37 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:37 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:37 --> Config Class Initialized
INFO - 2020-09-12 07:33:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:37 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:37 --> URI Class Initialized
INFO - 2020-09-12 07:33:37 --> Router Class Initialized
INFO - 2020-09-12 07:33:37 --> Output Class Initialized
INFO - 2020-09-12 07:33:37 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:37 --> Input Class Initialized
INFO - 2020-09-12 07:33:37 --> Language Class Initialized
INFO - 2020-09-12 07:33:37 --> Language Class Initialized
INFO - 2020-09-12 07:33:37 --> Config Class Initialized
INFO - 2020-09-12 07:33:37 --> Loader Class Initialized
INFO - 2020-09-12 07:33:37 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:37 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:37 --> Upload Class Initialized
INFO - 2020-09-12 07:33:37 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:37 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:37 --> Config Class Initialized
INFO - 2020-09-12 07:33:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:37 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:37 --> URI Class Initialized
INFO - 2020-09-12 07:33:37 --> Router Class Initialized
INFO - 2020-09-12 07:33:37 --> Output Class Initialized
INFO - 2020-09-12 07:33:37 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:37 --> Input Class Initialized
INFO - 2020-09-12 07:33:37 --> Language Class Initialized
INFO - 2020-09-12 07:33:37 --> Language Class Initialized
INFO - 2020-09-12 07:33:37 --> Config Class Initialized
INFO - 2020-09-12 07:33:37 --> Loader Class Initialized
INFO - 2020-09-12 07:33:37 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:37 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:37 --> Upload Class Initialized
INFO - 2020-09-12 07:33:37 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:37 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:40 --> Config Class Initialized
INFO - 2020-09-12 07:33:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:40 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:40 --> URI Class Initialized
DEBUG - 2020-09-12 07:33:40 --> No URI present. Default controller set.
INFO - 2020-09-12 07:33:40 --> Router Class Initialized
INFO - 2020-09-12 07:33:40 --> Output Class Initialized
INFO - 2020-09-12 07:33:40 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:40 --> Input Class Initialized
INFO - 2020-09-12 07:33:40 --> Language Class Initialized
INFO - 2020-09-12 07:33:40 --> Language Class Initialized
INFO - 2020-09-12 07:33:40 --> Config Class Initialized
INFO - 2020-09-12 07:33:40 --> Loader Class Initialized
INFO - 2020-09-12 07:33:40 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:40 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:40 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:40 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:40 --> Upload Class Initialized
INFO - 2020-09-12 07:33:40 --> Controller Class Initialized
DEBUG - 2020-09-12 07:33:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 07:33:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 07:33:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 07:33:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 07:33:40 --> Final output sent to browser
DEBUG - 2020-09-12 07:33:40 --> Total execution time: 0.0535
INFO - 2020-09-12 07:33:40 --> Config Class Initialized
INFO - 2020-09-12 07:33:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:41 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:41 --> URI Class Initialized
INFO - 2020-09-12 07:33:41 --> Router Class Initialized
INFO - 2020-09-12 07:33:41 --> Output Class Initialized
INFO - 2020-09-12 07:33:41 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:41 --> Input Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:41 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:41 --> URI Class Initialized
INFO - 2020-09-12 07:33:41 --> Loader Class Initialized
INFO - 2020-09-12 07:33:41 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:41 --> Router Class Initialized
INFO - 2020-09-12 07:33:41 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:41 --> Output Class Initialized
INFO - 2020-09-12 07:33:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:41 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:41 --> Input Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Database Driver Class Initialized
INFO - 2020-09-12 07:33:41 --> Loader Class Initialized
INFO - 2020-09-12 07:33:41 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:41 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:41 --> Database Driver Class Initialized
INFO - 2020-09-12 07:33:41 --> URI Class Initialized
INFO - 2020-09-12 07:33:41 --> Router Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:41 --> Output Class Initialized
INFO - 2020-09-12 07:33:41 --> Upload Class Initialized
INFO - 2020-09-12 07:33:41 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:41 --> Input Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Loader Class Initialized
INFO - 2020-09-12 07:33:41 --> Helper loaded: url_helper
DEBUG - 2020-09-12 07:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:41 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:41 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:41 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:41 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:41 --> Upload Class Initialized
INFO - 2020-09-12 07:33:41 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:41 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:41 --> Upload Class Initialized
INFO - 2020-09-12 07:33:41 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:41 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:41 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:41 --> URI Class Initialized
INFO - 2020-09-12 07:33:41 --> Router Class Initialized
INFO - 2020-09-12 07:33:41 --> Output Class Initialized
INFO - 2020-09-12 07:33:41 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:41 --> Input Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Language Class Initialized
INFO - 2020-09-12 07:33:41 --> Config Class Initialized
INFO - 2020-09-12 07:33:41 --> Loader Class Initialized
INFO - 2020-09-12 07:33:41 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:41 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:41 --> Upload Class Initialized
INFO - 2020-09-12 07:33:41 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:41 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:33:42 --> Config Class Initialized
INFO - 2020-09-12 07:33:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:33:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:33:42 --> Utf8 Class Initialized
INFO - 2020-09-12 07:33:42 --> URI Class Initialized
INFO - 2020-09-12 07:33:42 --> Router Class Initialized
INFO - 2020-09-12 07:33:42 --> Output Class Initialized
INFO - 2020-09-12 07:33:42 --> Security Class Initialized
DEBUG - 2020-09-12 07:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:33:42 --> Input Class Initialized
INFO - 2020-09-12 07:33:42 --> Language Class Initialized
INFO - 2020-09-12 07:33:42 --> Language Class Initialized
INFO - 2020-09-12 07:33:42 --> Config Class Initialized
INFO - 2020-09-12 07:33:42 --> Loader Class Initialized
INFO - 2020-09-12 07:33:42 --> Helper loaded: url_helper
INFO - 2020-09-12 07:33:42 --> Helper loaded: form_helper
INFO - 2020-09-12 07:33:42 --> Helper loaded: file_helper
INFO - 2020-09-12 07:33:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:33:42 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:33:42 --> Upload Class Initialized
INFO - 2020-09-12 07:33:42 --> Controller Class Initialized
ERROR - 2020-09-12 07:33:42 --> 404 Page Not Found: /index
INFO - 2020-09-12 07:36:33 --> Config Class Initialized
INFO - 2020-09-12 07:36:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:36:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:36:33 --> Utf8 Class Initialized
INFO - 2020-09-12 07:36:33 --> URI Class Initialized
DEBUG - 2020-09-12 07:36:33 --> No URI present. Default controller set.
INFO - 2020-09-12 07:36:33 --> Router Class Initialized
INFO - 2020-09-12 07:36:33 --> Output Class Initialized
INFO - 2020-09-12 07:36:33 --> Security Class Initialized
DEBUG - 2020-09-12 07:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:36:33 --> Input Class Initialized
INFO - 2020-09-12 07:36:33 --> Language Class Initialized
INFO - 2020-09-12 07:36:33 --> Language Class Initialized
INFO - 2020-09-12 07:36:33 --> Config Class Initialized
INFO - 2020-09-12 07:36:33 --> Loader Class Initialized
INFO - 2020-09-12 07:36:33 --> Helper loaded: url_helper
INFO - 2020-09-12 07:36:33 --> Helper loaded: form_helper
INFO - 2020-09-12 07:36:33 --> Helper loaded: file_helper
INFO - 2020-09-12 07:36:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 07:36:33 --> Database Driver Class Initialized
DEBUG - 2020-09-12 07:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 07:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:36:33 --> Upload Class Initialized
INFO - 2020-09-12 07:36:33 --> Controller Class Initialized
DEBUG - 2020-09-12 07:36:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 07:36:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 07:36:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 07:36:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 07:36:33 --> Final output sent to browser
DEBUG - 2020-09-12 07:36:33 --> Total execution time: 0.0618
INFO - 2020-09-12 08:13:15 --> Config Class Initialized
INFO - 2020-09-12 08:13:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:13:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:13:15 --> Utf8 Class Initialized
INFO - 2020-09-12 08:13:15 --> URI Class Initialized
DEBUG - 2020-09-12 08:13:15 --> No URI present. Default controller set.
INFO - 2020-09-12 08:13:15 --> Router Class Initialized
INFO - 2020-09-12 08:13:15 --> Output Class Initialized
INFO - 2020-09-12 08:13:15 --> Security Class Initialized
DEBUG - 2020-09-12 08:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:13:15 --> Input Class Initialized
INFO - 2020-09-12 08:13:15 --> Language Class Initialized
INFO - 2020-09-12 08:13:15 --> Language Class Initialized
INFO - 2020-09-12 08:13:15 --> Config Class Initialized
INFO - 2020-09-12 08:13:15 --> Loader Class Initialized
INFO - 2020-09-12 08:13:15 --> Helper loaded: url_helper
INFO - 2020-09-12 08:13:15 --> Helper loaded: form_helper
INFO - 2020-09-12 08:13:15 --> Helper loaded: file_helper
INFO - 2020-09-12 08:13:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:13:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:13:15 --> Upload Class Initialized
INFO - 2020-09-12 08:13:15 --> Controller Class Initialized
DEBUG - 2020-09-12 08:13:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 08:13:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 08:13:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 08:13:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 08:13:15 --> Final output sent to browser
DEBUG - 2020-09-12 08:13:15 --> Total execution time: 0.0554
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:13:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:13:19 --> Utf8 Class Initialized
INFO - 2020-09-12 08:13:19 --> URI Class Initialized
INFO - 2020-09-12 08:13:19 --> Router Class Initialized
INFO - 2020-09-12 08:13:19 --> Output Class Initialized
INFO - 2020-09-12 08:13:19 --> Security Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:13:19 --> Input Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Loader Class Initialized
INFO - 2020-09-12 08:13:19 --> Helper loaded: url_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: form_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: file_helper
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Hooks Class Initialized
INFO - 2020-09-12 08:13:19 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-12 08:13:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:13:19 --> Utf8 Class Initialized
INFO - 2020-09-12 08:13:19 --> URI Class Initialized
INFO - 2020-09-12 08:13:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:13:19 --> Upload Class Initialized
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Hooks Class Initialized
INFO - 2020-09-12 08:13:19 --> Router Class Initialized
INFO - 2020-09-12 08:13:19 --> Output Class Initialized
INFO - 2020-09-12 08:13:19 --> Security Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:13:19 --> Input Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Loader Class Initialized
INFO - 2020-09-12 08:13:19 --> Helper loaded: url_helper
DEBUG - 2020-09-12 08:13:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:13:19 --> Utf8 Class Initialized
INFO - 2020-09-12 08:13:19 --> URI Class Initialized
INFO - 2020-09-12 08:13:19 --> Router Class Initialized
INFO - 2020-09-12 08:13:19 --> Output Class Initialized
INFO - 2020-09-12 08:13:19 --> Security Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:13:19 --> Input Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Helper loaded: form_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: file_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:13:19 --> Controller Class Initialized
ERROR - 2020-09-12 08:13:19 --> 404 Page Not Found: /index
INFO - 2020-09-12 08:13:19 --> Database Driver Class Initialized
INFO - 2020-09-12 08:13:19 --> Loader Class Initialized
INFO - 2020-09-12 08:13:19 --> Helper loaded: url_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: form_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: file_helper
DEBUG - 2020-09-12 08:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:13:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:13:19 --> Upload Class Initialized
INFO - 2020-09-12 08:13:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:13:19 --> Upload Class Initialized
INFO - 2020-09-12 08:13:19 --> Controller Class Initialized
ERROR - 2020-09-12 08:13:19 --> 404 Page Not Found: /index
INFO - 2020-09-12 08:13:19 --> Controller Class Initialized
ERROR - 2020-09-12 08:13:19 --> 404 Page Not Found: /index
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:13:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:13:19 --> Utf8 Class Initialized
INFO - 2020-09-12 08:13:19 --> URI Class Initialized
INFO - 2020-09-12 08:13:19 --> Router Class Initialized
INFO - 2020-09-12 08:13:19 --> Output Class Initialized
INFO - 2020-09-12 08:13:19 --> Security Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:13:19 --> Input Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Language Class Initialized
INFO - 2020-09-12 08:13:19 --> Config Class Initialized
INFO - 2020-09-12 08:13:19 --> Loader Class Initialized
INFO - 2020-09-12 08:13:19 --> Helper loaded: url_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: form_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: file_helper
INFO - 2020-09-12 08:13:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:13:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:13:19 --> Upload Class Initialized
INFO - 2020-09-12 08:13:19 --> Controller Class Initialized
ERROR - 2020-09-12 08:13:19 --> 404 Page Not Found: /index
INFO - 2020-09-12 08:13:20 --> Config Class Initialized
INFO - 2020-09-12 08:13:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:13:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:13:20 --> Utf8 Class Initialized
INFO - 2020-09-12 08:13:20 --> URI Class Initialized
INFO - 2020-09-12 08:13:20 --> Router Class Initialized
INFO - 2020-09-12 08:13:20 --> Output Class Initialized
INFO - 2020-09-12 08:13:20 --> Security Class Initialized
DEBUG - 2020-09-12 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:13:20 --> Input Class Initialized
INFO - 2020-09-12 08:13:20 --> Language Class Initialized
INFO - 2020-09-12 08:13:20 --> Language Class Initialized
INFO - 2020-09-12 08:13:20 --> Config Class Initialized
INFO - 2020-09-12 08:13:20 --> Loader Class Initialized
INFO - 2020-09-12 08:13:20 --> Helper loaded: url_helper
INFO - 2020-09-12 08:13:20 --> Helper loaded: form_helper
INFO - 2020-09-12 08:13:20 --> Helper loaded: file_helper
INFO - 2020-09-12 08:13:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:13:20 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:13:20 --> Upload Class Initialized
INFO - 2020-09-12 08:13:20 --> Controller Class Initialized
ERROR - 2020-09-12 08:13:20 --> 404 Page Not Found: /index
INFO - 2020-09-12 08:19:24 --> Config Class Initialized
INFO - 2020-09-12 08:19:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:19:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:19:24 --> Utf8 Class Initialized
INFO - 2020-09-12 08:19:24 --> URI Class Initialized
INFO - 2020-09-12 08:19:24 --> Router Class Initialized
INFO - 2020-09-12 08:19:24 --> Output Class Initialized
INFO - 2020-09-12 08:19:24 --> Security Class Initialized
DEBUG - 2020-09-12 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:19:24 --> Input Class Initialized
INFO - 2020-09-12 08:19:24 --> Language Class Initialized
INFO - 2020-09-12 08:19:24 --> Language Class Initialized
INFO - 2020-09-12 08:19:24 --> Config Class Initialized
INFO - 2020-09-12 08:19:24 --> Loader Class Initialized
INFO - 2020-09-12 08:19:24 --> Helper loaded: url_helper
INFO - 2020-09-12 08:19:24 --> Helper loaded: form_helper
INFO - 2020-09-12 08:19:24 --> Helper loaded: file_helper
INFO - 2020-09-12 08:19:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:19:24 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:19:24 --> Upload Class Initialized
INFO - 2020-09-12 08:19:24 --> Controller Class Initialized
ERROR - 2020-09-12 08:19:24 --> 404 Page Not Found: /index
INFO - 2020-09-12 08:36:39 --> Config Class Initialized
INFO - 2020-09-12 08:36:39 --> Hooks Class Initialized
DEBUG - 2020-09-12 08:36:39 --> UTF-8 Support Enabled
INFO - 2020-09-12 08:36:39 --> Utf8 Class Initialized
INFO - 2020-09-12 08:36:39 --> URI Class Initialized
DEBUG - 2020-09-12 08:36:39 --> No URI present. Default controller set.
INFO - 2020-09-12 08:36:39 --> Router Class Initialized
INFO - 2020-09-12 08:36:39 --> Output Class Initialized
INFO - 2020-09-12 08:36:39 --> Security Class Initialized
DEBUG - 2020-09-12 08:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 08:36:39 --> Input Class Initialized
INFO - 2020-09-12 08:36:39 --> Language Class Initialized
INFO - 2020-09-12 08:36:39 --> Language Class Initialized
INFO - 2020-09-12 08:36:39 --> Config Class Initialized
INFO - 2020-09-12 08:36:39 --> Loader Class Initialized
INFO - 2020-09-12 08:36:39 --> Helper loaded: url_helper
INFO - 2020-09-12 08:36:39 --> Helper loaded: form_helper
INFO - 2020-09-12 08:36:39 --> Helper loaded: file_helper
INFO - 2020-09-12 08:36:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 08:36:39 --> Database Driver Class Initialized
DEBUG - 2020-09-12 08:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 08:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 08:36:39 --> Upload Class Initialized
INFO - 2020-09-12 08:36:39 --> Controller Class Initialized
DEBUG - 2020-09-12 08:36:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 08:36:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 08:36:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 08:36:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 08:36:39 --> Final output sent to browser
DEBUG - 2020-09-12 08:36:39 --> Total execution time: 0.0421
INFO - 2020-09-12 09:09:21 --> Config Class Initialized
INFO - 2020-09-12 09:09:21 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:09:21 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:09:21 --> Utf8 Class Initialized
INFO - 2020-09-12 09:09:21 --> URI Class Initialized
DEBUG - 2020-09-12 09:09:21 --> No URI present. Default controller set.
INFO - 2020-09-12 09:09:21 --> Router Class Initialized
INFO - 2020-09-12 09:09:21 --> Output Class Initialized
INFO - 2020-09-12 09:09:21 --> Security Class Initialized
DEBUG - 2020-09-12 09:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:09:21 --> Input Class Initialized
INFO - 2020-09-12 09:09:21 --> Language Class Initialized
INFO - 2020-09-12 09:09:21 --> Language Class Initialized
INFO - 2020-09-12 09:09:21 --> Config Class Initialized
INFO - 2020-09-12 09:09:21 --> Loader Class Initialized
INFO - 2020-09-12 09:09:21 --> Helper loaded: url_helper
INFO - 2020-09-12 09:09:21 --> Helper loaded: form_helper
INFO - 2020-09-12 09:09:21 --> Helper loaded: file_helper
INFO - 2020-09-12 09:09:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:09:21 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:09:21 --> Upload Class Initialized
INFO - 2020-09-12 09:09:21 --> Controller Class Initialized
DEBUG - 2020-09-12 09:09:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:09:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:09:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:09:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:09:21 --> Final output sent to browser
DEBUG - 2020-09-12 09:09:21 --> Total execution time: 0.0669
INFO - 2020-09-12 09:13:48 --> Config Class Initialized
INFO - 2020-09-12 09:13:48 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:13:48 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:13:48 --> Utf8 Class Initialized
INFO - 2020-09-12 09:13:48 --> URI Class Initialized
INFO - 2020-09-12 09:13:48 --> Router Class Initialized
INFO - 2020-09-12 09:13:48 --> Output Class Initialized
INFO - 2020-09-12 09:13:48 --> Security Class Initialized
DEBUG - 2020-09-12 09:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:13:48 --> Input Class Initialized
INFO - 2020-09-12 09:13:48 --> Language Class Initialized
INFO - 2020-09-12 09:13:48 --> Language Class Initialized
INFO - 2020-09-12 09:13:48 --> Config Class Initialized
INFO - 2020-09-12 09:13:48 --> Loader Class Initialized
INFO - 2020-09-12 09:13:48 --> Helper loaded: url_helper
INFO - 2020-09-12 09:13:48 --> Helper loaded: form_helper
INFO - 2020-09-12 09:13:48 --> Helper loaded: file_helper
INFO - 2020-09-12 09:13:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:13:48 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:13:48 --> Upload Class Initialized
INFO - 2020-09-12 09:13:48 --> Controller Class Initialized
ERROR - 2020-09-12 09:13:48 --> 404 Page Not Found: /index
INFO - 2020-09-12 09:14:16 --> Config Class Initialized
INFO - 2020-09-12 09:14:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:14:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:14:16 --> Utf8 Class Initialized
INFO - 2020-09-12 09:14:16 --> URI Class Initialized
DEBUG - 2020-09-12 09:14:16 --> No URI present. Default controller set.
INFO - 2020-09-12 09:14:16 --> Router Class Initialized
INFO - 2020-09-12 09:14:16 --> Output Class Initialized
INFO - 2020-09-12 09:14:16 --> Security Class Initialized
DEBUG - 2020-09-12 09:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:14:16 --> Input Class Initialized
INFO - 2020-09-12 09:14:16 --> Language Class Initialized
INFO - 2020-09-12 09:14:16 --> Language Class Initialized
INFO - 2020-09-12 09:14:16 --> Config Class Initialized
INFO - 2020-09-12 09:14:16 --> Loader Class Initialized
INFO - 2020-09-12 09:14:16 --> Helper loaded: url_helper
INFO - 2020-09-12 09:14:16 --> Helper loaded: form_helper
INFO - 2020-09-12 09:14:16 --> Helper loaded: file_helper
INFO - 2020-09-12 09:14:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:14:16 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:14:16 --> Upload Class Initialized
INFO - 2020-09-12 09:14:16 --> Controller Class Initialized
DEBUG - 2020-09-12 09:14:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:14:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:14:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:14:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:14:16 --> Final output sent to browser
DEBUG - 2020-09-12 09:14:16 --> Total execution time: 0.0657
INFO - 2020-09-12 09:15:01 --> Config Class Initialized
INFO - 2020-09-12 09:15:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:15:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:15:01 --> Utf8 Class Initialized
INFO - 2020-09-12 09:15:01 --> URI Class Initialized
DEBUG - 2020-09-12 09:15:01 --> No URI present. Default controller set.
INFO - 2020-09-12 09:15:01 --> Router Class Initialized
INFO - 2020-09-12 09:15:01 --> Output Class Initialized
INFO - 2020-09-12 09:15:01 --> Security Class Initialized
DEBUG - 2020-09-12 09:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:15:01 --> Input Class Initialized
INFO - 2020-09-12 09:15:01 --> Language Class Initialized
INFO - 2020-09-12 09:15:01 --> Language Class Initialized
INFO - 2020-09-12 09:15:01 --> Config Class Initialized
INFO - 2020-09-12 09:15:01 --> Loader Class Initialized
INFO - 2020-09-12 09:15:02 --> Helper loaded: url_helper
INFO - 2020-09-12 09:15:02 --> Helper loaded: form_helper
INFO - 2020-09-12 09:15:02 --> Helper loaded: file_helper
INFO - 2020-09-12 09:15:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:15:02 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:15:02 --> Upload Class Initialized
INFO - 2020-09-12 09:15:02 --> Controller Class Initialized
DEBUG - 2020-09-12 09:15:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:15:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:15:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:15:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:15:02 --> Final output sent to browser
DEBUG - 2020-09-12 09:15:02 --> Total execution time: 0.1256
INFO - 2020-09-12 09:17:23 --> Config Class Initialized
INFO - 2020-09-12 09:17:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:17:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:17:23 --> Utf8 Class Initialized
INFO - 2020-09-12 09:17:23 --> URI Class Initialized
DEBUG - 2020-09-12 09:17:23 --> No URI present. Default controller set.
INFO - 2020-09-12 09:17:23 --> Router Class Initialized
INFO - 2020-09-12 09:17:23 --> Output Class Initialized
INFO - 2020-09-12 09:17:23 --> Security Class Initialized
DEBUG - 2020-09-12 09:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:17:23 --> Input Class Initialized
INFO - 2020-09-12 09:17:23 --> Language Class Initialized
INFO - 2020-09-12 09:17:23 --> Language Class Initialized
INFO - 2020-09-12 09:17:23 --> Config Class Initialized
INFO - 2020-09-12 09:17:23 --> Loader Class Initialized
INFO - 2020-09-12 09:17:23 --> Helper loaded: url_helper
INFO - 2020-09-12 09:17:23 --> Helper loaded: form_helper
INFO - 2020-09-12 09:17:23 --> Helper loaded: file_helper
INFO - 2020-09-12 09:17:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:17:23 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:17:23 --> Upload Class Initialized
INFO - 2020-09-12 09:17:23 --> Controller Class Initialized
DEBUG - 2020-09-12 09:17:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:17:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:17:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:17:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:17:23 --> Final output sent to browser
DEBUG - 2020-09-12 09:17:23 --> Total execution time: 0.0467
INFO - 2020-09-12 09:25:19 --> Config Class Initialized
INFO - 2020-09-12 09:25:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:25:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:25:19 --> Utf8 Class Initialized
INFO - 2020-09-12 09:25:19 --> URI Class Initialized
DEBUG - 2020-09-12 09:25:19 --> No URI present. Default controller set.
INFO - 2020-09-12 09:25:19 --> Router Class Initialized
INFO - 2020-09-12 09:25:19 --> Output Class Initialized
INFO - 2020-09-12 09:25:19 --> Security Class Initialized
DEBUG - 2020-09-12 09:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:25:19 --> Input Class Initialized
INFO - 2020-09-12 09:25:19 --> Language Class Initialized
INFO - 2020-09-12 09:25:19 --> Language Class Initialized
INFO - 2020-09-12 09:25:19 --> Config Class Initialized
INFO - 2020-09-12 09:25:19 --> Loader Class Initialized
INFO - 2020-09-12 09:25:19 --> Helper loaded: url_helper
INFO - 2020-09-12 09:25:19 --> Helper loaded: form_helper
INFO - 2020-09-12 09:25:19 --> Helper loaded: file_helper
INFO - 2020-09-12 09:25:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:25:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:25:19 --> Upload Class Initialized
INFO - 2020-09-12 09:25:19 --> Controller Class Initialized
DEBUG - 2020-09-12 09:25:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:25:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:25:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:25:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:25:19 --> Final output sent to browser
DEBUG - 2020-09-12 09:25:19 --> Total execution time: 0.0753
INFO - 2020-09-12 09:49:02 --> Config Class Initialized
INFO - 2020-09-12 09:49:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:49:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:49:02 --> Utf8 Class Initialized
INFO - 2020-09-12 09:49:02 --> URI Class Initialized
DEBUG - 2020-09-12 09:49:02 --> No URI present. Default controller set.
INFO - 2020-09-12 09:49:02 --> Router Class Initialized
INFO - 2020-09-12 09:49:02 --> Output Class Initialized
INFO - 2020-09-12 09:49:02 --> Security Class Initialized
DEBUG - 2020-09-12 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:49:02 --> Input Class Initialized
INFO - 2020-09-12 09:49:02 --> Language Class Initialized
INFO - 2020-09-12 09:49:02 --> Language Class Initialized
INFO - 2020-09-12 09:49:02 --> Config Class Initialized
INFO - 2020-09-12 09:49:02 --> Loader Class Initialized
INFO - 2020-09-12 09:49:02 --> Helper loaded: url_helper
INFO - 2020-09-12 09:49:02 --> Helper loaded: form_helper
INFO - 2020-09-12 09:49:02 --> Helper loaded: file_helper
INFO - 2020-09-12 09:49:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:49:02 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:49:02 --> Upload Class Initialized
INFO - 2020-09-12 09:49:02 --> Controller Class Initialized
DEBUG - 2020-09-12 09:49:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:49:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:49:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:49:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:49:02 --> Final output sent to browser
DEBUG - 2020-09-12 09:49:02 --> Total execution time: 0.0605
INFO - 2020-09-12 09:58:29 --> Config Class Initialized
INFO - 2020-09-12 09:58:29 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:58:29 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:58:29 --> Utf8 Class Initialized
INFO - 2020-09-12 09:58:29 --> URI Class Initialized
DEBUG - 2020-09-12 09:58:29 --> No URI present. Default controller set.
INFO - 2020-09-12 09:58:29 --> Router Class Initialized
INFO - 2020-09-12 09:58:29 --> Output Class Initialized
INFO - 2020-09-12 09:58:29 --> Security Class Initialized
DEBUG - 2020-09-12 09:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:58:29 --> Input Class Initialized
INFO - 2020-09-12 09:58:29 --> Language Class Initialized
INFO - 2020-09-12 09:58:29 --> Language Class Initialized
INFO - 2020-09-12 09:58:29 --> Config Class Initialized
INFO - 2020-09-12 09:58:29 --> Loader Class Initialized
INFO - 2020-09-12 09:58:29 --> Helper loaded: url_helper
INFO - 2020-09-12 09:58:29 --> Helper loaded: form_helper
INFO - 2020-09-12 09:58:29 --> Helper loaded: file_helper
INFO - 2020-09-12 09:58:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 09:58:29 --> Database Driver Class Initialized
DEBUG - 2020-09-12 09:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 09:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:58:29 --> Upload Class Initialized
INFO - 2020-09-12 09:58:29 --> Controller Class Initialized
DEBUG - 2020-09-12 09:58:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 09:58:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 09:58:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 09:58:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 09:58:29 --> Final output sent to browser
DEBUG - 2020-09-12 09:58:29 --> Total execution time: 0.0706
INFO - 2020-09-12 10:03:45 --> Config Class Initialized
INFO - 2020-09-12 10:03:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:45 --> URI Class Initialized
DEBUG - 2020-09-12 10:03:45 --> No URI present. Default controller set.
INFO - 2020-09-12 10:03:45 --> Router Class Initialized
INFO - 2020-09-12 10:03:45 --> Output Class Initialized
INFO - 2020-09-12 10:03:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:45 --> Input Class Initialized
INFO - 2020-09-12 10:03:45 --> Language Class Initialized
INFO - 2020-09-12 10:03:45 --> Language Class Initialized
INFO - 2020-09-12 10:03:45 --> Config Class Initialized
INFO - 2020-09-12 10:03:45 --> Loader Class Initialized
INFO - 2020-09-12 10:03:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:45 --> Helper loaded: form_helper
INFO - 2020-09-12 10:03:45 --> Helper loaded: file_helper
INFO - 2020-09-12 10:03:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:03:45 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:45 --> Upload Class Initialized
INFO - 2020-09-12 10:03:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:03:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 10:03:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 10:03:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 10:03:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 10:03:45 --> Final output sent to browser
DEBUG - 2020-09-12 10:03:45 --> Total execution time: 0.0545
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:51 --> URI Class Initialized
INFO - 2020-09-12 10:03:51 --> Router Class Initialized
INFO - 2020-09-12 10:03:51 --> Output Class Initialized
INFO - 2020-09-12 10:03:51 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:51 --> Input Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Loader Class Initialized
INFO - 2020-09-12 10:03:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: form_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: file_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:03:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:51 --> Upload Class Initialized
INFO - 2020-09-12 10:03:51 --> Controller Class Initialized
ERROR - 2020-09-12 10:03:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:51 --> URI Class Initialized
INFO - 2020-09-12 10:03:51 --> Router Class Initialized
INFO - 2020-09-12 10:03:51 --> Output Class Initialized
INFO - 2020-09-12 10:03:51 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:51 --> Input Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Loader Class Initialized
INFO - 2020-09-12 10:03:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: form_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: file_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:03:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:51 --> Upload Class Initialized
INFO - 2020-09-12 10:03:51 --> Controller Class Initialized
ERROR - 2020-09-12 10:03:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:51 --> URI Class Initialized
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Hooks Class Initialized
INFO - 2020-09-12 10:03:51 --> Router Class Initialized
DEBUG - 2020-09-12 10:03:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:51 --> URI Class Initialized
INFO - 2020-09-12 10:03:51 --> Output Class Initialized
INFO - 2020-09-12 10:03:51 --> Security Class Initialized
INFO - 2020-09-12 10:03:51 --> Router Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:51 --> Input Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Output Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:51 --> Input Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Language Class Initialized
INFO - 2020-09-12 10:03:51 --> Config Class Initialized
INFO - 2020-09-12 10:03:51 --> Loader Class Initialized
INFO - 2020-09-12 10:03:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:51 --> Loader Class Initialized
INFO - 2020-09-12 10:03:51 --> Helper loaded: form_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: file_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: form_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: file_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:03:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:03:51 --> Database Driver Class Initialized
INFO - 2020-09-12 10:03:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:51 --> Upload Class Initialized
DEBUG - 2020-09-12 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:03:51 --> Controller Class Initialized
ERROR - 2020-09-12 10:03:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:51 --> Upload Class Initialized
INFO - 2020-09-12 10:03:51 --> Controller Class Initialized
ERROR - 2020-09-12 10:03:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:03:54 --> Config Class Initialized
INFO - 2020-09-12 10:03:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:54 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:54 --> URI Class Initialized
INFO - 2020-09-12 10:03:54 --> Router Class Initialized
INFO - 2020-09-12 10:03:54 --> Output Class Initialized
INFO - 2020-09-12 10:03:54 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:54 --> Input Class Initialized
INFO - 2020-09-12 10:03:54 --> Language Class Initialized
INFO - 2020-09-12 10:03:54 --> Language Class Initialized
INFO - 2020-09-12 10:03:54 --> Config Class Initialized
INFO - 2020-09-12 10:03:54 --> Loader Class Initialized
INFO - 2020-09-12 10:03:54 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:54 --> Helper loaded: form_helper
INFO - 2020-09-12 10:03:54 --> Helper loaded: file_helper
INFO - 2020-09-12 10:03:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:03:54 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:54 --> Upload Class Initialized
INFO - 2020-09-12 10:03:54 --> Controller Class Initialized
ERROR - 2020-09-12 10:03:54 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:07:59 --> Config Class Initialized
INFO - 2020-09-12 10:07:59 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:07:59 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:07:59 --> Utf8 Class Initialized
INFO - 2020-09-12 10:07:59 --> URI Class Initialized
DEBUG - 2020-09-12 10:07:59 --> No URI present. Default controller set.
INFO - 2020-09-12 10:07:59 --> Router Class Initialized
INFO - 2020-09-12 10:07:59 --> Output Class Initialized
INFO - 2020-09-12 10:07:59 --> Security Class Initialized
DEBUG - 2020-09-12 10:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:07:59 --> Input Class Initialized
INFO - 2020-09-12 10:07:59 --> Language Class Initialized
INFO - 2020-09-12 10:07:59 --> Language Class Initialized
INFO - 2020-09-12 10:07:59 --> Config Class Initialized
INFO - 2020-09-12 10:07:59 --> Loader Class Initialized
INFO - 2020-09-12 10:07:59 --> Helper loaded: url_helper
INFO - 2020-09-12 10:07:59 --> Helper loaded: form_helper
INFO - 2020-09-12 10:07:59 --> Helper loaded: file_helper
INFO - 2020-09-12 10:07:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:07:59 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:07:59 --> Upload Class Initialized
INFO - 2020-09-12 10:07:59 --> Controller Class Initialized
DEBUG - 2020-09-12 10:07:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 10:07:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 10:07:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 10:07:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 10:07:59 --> Final output sent to browser
DEBUG - 2020-09-12 10:07:59 --> Total execution time: 0.0688
INFO - 2020-09-12 10:08:00 --> Config Class Initialized
INFO - 2020-09-12 10:08:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:08:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:08:00 --> Utf8 Class Initialized
INFO - 2020-09-12 10:08:00 --> URI Class Initialized
INFO - 2020-09-12 10:08:00 --> Router Class Initialized
INFO - 2020-09-12 10:08:00 --> Config Class Initialized
INFO - 2020-09-12 10:08:00 --> Hooks Class Initialized
INFO - 2020-09-12 10:08:00 --> Output Class Initialized
INFO - 2020-09-12 10:08:00 --> Security Class Initialized
DEBUG - 2020-09-12 10:08:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:08:00 --> Utf8 Class Initialized
INFO - 2020-09-12 10:08:00 --> URI Class Initialized
DEBUG - 2020-09-12 10:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:08:00 --> Input Class Initialized
INFO - 2020-09-12 10:08:00 --> Language Class Initialized
INFO - 2020-09-12 10:08:00 --> Language Class Initialized
INFO - 2020-09-12 10:08:00 --> Config Class Initialized
INFO - 2020-09-12 10:08:00 --> Router Class Initialized
INFO - 2020-09-12 10:08:00 --> Output Class Initialized
INFO - 2020-09-12 10:08:00 --> Loader Class Initialized
INFO - 2020-09-12 10:08:00 --> Security Class Initialized
INFO - 2020-09-12 10:08:00 --> Helper loaded: url_helper
DEBUG - 2020-09-12 10:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:08:00 --> Input Class Initialized
INFO - 2020-09-12 10:08:00 --> Language Class Initialized
INFO - 2020-09-12 10:08:00 --> Helper loaded: form_helper
INFO - 2020-09-12 10:08:00 --> Language Class Initialized
INFO - 2020-09-12 10:08:00 --> Config Class Initialized
INFO - 2020-09-12 10:08:00 --> Helper loaded: file_helper
INFO - 2020-09-12 10:08:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:08:00 --> Loader Class Initialized
INFO - 2020-09-12 10:08:00 --> Helper loaded: url_helper
INFO - 2020-09-12 10:08:00 --> Helper loaded: form_helper
INFO - 2020-09-12 10:08:00 --> Helper loaded: file_helper
INFO - 2020-09-12 10:08:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:08:00 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:08:00 --> Upload Class Initialized
INFO - 2020-09-12 10:08:00 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:08:00 --> Controller Class Initialized
ERROR - 2020-09-12 10:08:00 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:08:00 --> Upload Class Initialized
INFO - 2020-09-12 10:08:00 --> Controller Class Initialized
ERROR - 2020-09-12 10:08:00 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:08:01 --> Config Class Initialized
INFO - 2020-09-12 10:08:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:08:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:08:01 --> Utf8 Class Initialized
INFO - 2020-09-12 10:08:01 --> URI Class Initialized
INFO - 2020-09-12 10:08:01 --> Router Class Initialized
INFO - 2020-09-12 10:08:01 --> Output Class Initialized
INFO - 2020-09-12 10:08:01 --> Security Class Initialized
DEBUG - 2020-09-12 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:08:01 --> Input Class Initialized
INFO - 2020-09-12 10:08:01 --> Language Class Initialized
INFO - 2020-09-12 10:08:01 --> Language Class Initialized
INFO - 2020-09-12 10:08:01 --> Config Class Initialized
INFO - 2020-09-12 10:08:01 --> Loader Class Initialized
INFO - 2020-09-12 10:08:01 --> Helper loaded: url_helper
INFO - 2020-09-12 10:08:01 --> Helper loaded: form_helper
INFO - 2020-09-12 10:08:01 --> Helper loaded: file_helper
INFO - 2020-09-12 10:08:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:08:01 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:08:01 --> Upload Class Initialized
INFO - 2020-09-12 10:08:01 --> Controller Class Initialized
ERROR - 2020-09-12 10:08:01 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:08:01 --> Config Class Initialized
INFO - 2020-09-12 10:08:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:08:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:08:01 --> Utf8 Class Initialized
INFO - 2020-09-12 10:08:01 --> URI Class Initialized
INFO - 2020-09-12 10:08:01 --> Router Class Initialized
INFO - 2020-09-12 10:08:01 --> Output Class Initialized
INFO - 2020-09-12 10:08:01 --> Security Class Initialized
DEBUG - 2020-09-12 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:08:01 --> Input Class Initialized
INFO - 2020-09-12 10:08:01 --> Language Class Initialized
INFO - 2020-09-12 10:08:01 --> Language Class Initialized
INFO - 2020-09-12 10:08:01 --> Config Class Initialized
INFO - 2020-09-12 10:08:01 --> Loader Class Initialized
INFO - 2020-09-12 10:08:01 --> Helper loaded: url_helper
INFO - 2020-09-12 10:08:01 --> Helper loaded: form_helper
INFO - 2020-09-12 10:08:01 --> Helper loaded: file_helper
INFO - 2020-09-12 10:08:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:08:01 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:08:01 --> Upload Class Initialized
INFO - 2020-09-12 10:08:01 --> Controller Class Initialized
ERROR - 2020-09-12 10:08:01 --> 404 Page Not Found: /index
INFO - 2020-09-12 10:08:02 --> Config Class Initialized
INFO - 2020-09-12 10:08:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:08:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:08:02 --> Utf8 Class Initialized
INFO - 2020-09-12 10:08:02 --> URI Class Initialized
INFO - 2020-09-12 10:08:02 --> Router Class Initialized
INFO - 2020-09-12 10:08:02 --> Output Class Initialized
INFO - 2020-09-12 10:08:02 --> Security Class Initialized
DEBUG - 2020-09-12 10:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:08:02 --> Input Class Initialized
INFO - 2020-09-12 10:08:02 --> Language Class Initialized
INFO - 2020-09-12 10:08:02 --> Language Class Initialized
INFO - 2020-09-12 10:08:02 --> Config Class Initialized
INFO - 2020-09-12 10:08:02 --> Loader Class Initialized
INFO - 2020-09-12 10:08:02 --> Helper loaded: url_helper
INFO - 2020-09-12 10:08:02 --> Helper loaded: form_helper
INFO - 2020-09-12 10:08:02 --> Helper loaded: file_helper
INFO - 2020-09-12 10:08:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 10:08:02 --> Database Driver Class Initialized
DEBUG - 2020-09-12 10:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 10:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:08:02 --> Upload Class Initialized
INFO - 2020-09-12 10:08:02 --> Controller Class Initialized
ERROR - 2020-09-12 10:08:02 --> 404 Page Not Found: /index
INFO - 2020-09-12 11:02:23 --> Config Class Initialized
INFO - 2020-09-12 11:02:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:02:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:02:23 --> Utf8 Class Initialized
INFO - 2020-09-12 11:02:23 --> URI Class Initialized
DEBUG - 2020-09-12 11:02:23 --> No URI present. Default controller set.
INFO - 2020-09-12 11:02:23 --> Router Class Initialized
INFO - 2020-09-12 11:02:23 --> Output Class Initialized
INFO - 2020-09-12 11:02:23 --> Security Class Initialized
DEBUG - 2020-09-12 11:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:02:23 --> Input Class Initialized
INFO - 2020-09-12 11:02:23 --> Language Class Initialized
INFO - 2020-09-12 11:02:23 --> Language Class Initialized
INFO - 2020-09-12 11:02:23 --> Config Class Initialized
INFO - 2020-09-12 11:02:23 --> Loader Class Initialized
INFO - 2020-09-12 11:02:23 --> Helper loaded: url_helper
INFO - 2020-09-12 11:02:23 --> Helper loaded: form_helper
INFO - 2020-09-12 11:02:23 --> Helper loaded: file_helper
INFO - 2020-09-12 11:02:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:02:23 --> Database Driver Class Initialized
DEBUG - 2020-09-12 11:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:02:23 --> Upload Class Initialized
INFO - 2020-09-12 11:02:23 --> Controller Class Initialized
DEBUG - 2020-09-12 11:02:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 11:02:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 11:02:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 11:02:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 11:02:23 --> Final output sent to browser
DEBUG - 2020-09-12 11:02:23 --> Total execution time: 0.0669
INFO - 2020-09-12 11:54:05 --> Config Class Initialized
INFO - 2020-09-12 11:54:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:54:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:54:05 --> Utf8 Class Initialized
INFO - 2020-09-12 11:54:05 --> URI Class Initialized
DEBUG - 2020-09-12 11:54:05 --> No URI present. Default controller set.
INFO - 2020-09-12 11:54:05 --> Router Class Initialized
INFO - 2020-09-12 11:54:05 --> Output Class Initialized
INFO - 2020-09-12 11:54:05 --> Security Class Initialized
DEBUG - 2020-09-12 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:54:05 --> Input Class Initialized
INFO - 2020-09-12 11:54:05 --> Language Class Initialized
INFO - 2020-09-12 11:54:05 --> Language Class Initialized
INFO - 2020-09-12 11:54:05 --> Config Class Initialized
INFO - 2020-09-12 11:54:05 --> Loader Class Initialized
INFO - 2020-09-12 11:54:05 --> Helper loaded: url_helper
INFO - 2020-09-12 11:54:05 --> Helper loaded: form_helper
INFO - 2020-09-12 11:54:05 --> Helper loaded: file_helper
INFO - 2020-09-12 11:54:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:54:05 --> Database Driver Class Initialized
DEBUG - 2020-09-12 11:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:54:05 --> Upload Class Initialized
INFO - 2020-09-12 11:54:05 --> Controller Class Initialized
DEBUG - 2020-09-12 11:54:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 11:54:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 11:54:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 11:54:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 11:54:05 --> Final output sent to browser
DEBUG - 2020-09-12 11:54:05 --> Total execution time: 0.0628
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Hooks Class Initialized
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:54:08 --> Utf8 Class Initialized
DEBUG - 2020-09-12 11:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:54:08 --> Utf8 Class Initialized
INFO - 2020-09-12 11:54:08 --> URI Class Initialized
INFO - 2020-09-12 11:54:08 --> URI Class Initialized
INFO - 2020-09-12 11:54:08 --> Router Class Initialized
INFO - 2020-09-12 11:54:08 --> Router Class Initialized
INFO - 2020-09-12 11:54:08 --> Output Class Initialized
INFO - 2020-09-12 11:54:08 --> Output Class Initialized
INFO - 2020-09-12 11:54:08 --> Security Class Initialized
INFO - 2020-09-12 11:54:08 --> Security Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:54:08 --> Input Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Input Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Loader Class Initialized
INFO - 2020-09-12 11:54:08 --> Loader Class Initialized
INFO - 2020-09-12 11:54:08 --> Helper loaded: url_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: url_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: form_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: file_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: form_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: file_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:54:08 --> Database Driver Class Initialized
INFO - 2020-09-12 11:54:08 --> Database Driver Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:54:08 --> Upload Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:54:08 --> Controller Class Initialized
ERROR - 2020-09-12 11:54:08 --> 404 Page Not Found: /index
INFO - 2020-09-12 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:54:08 --> Upload Class Initialized
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:54:08 --> Utf8 Class Initialized
INFO - 2020-09-12 11:54:08 --> URI Class Initialized
INFO - 2020-09-12 11:54:08 --> Controller Class Initialized
ERROR - 2020-09-12 11:54:08 --> 404 Page Not Found: /index
INFO - 2020-09-12 11:54:08 --> Router Class Initialized
INFO - 2020-09-12 11:54:08 --> Output Class Initialized
INFO - 2020-09-12 11:54:08 --> Security Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:54:08 --> Input Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Loader Class Initialized
INFO - 2020-09-12 11:54:08 --> Helper loaded: url_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: form_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: file_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:54:08 --> Database Driver Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:54:08 --> Upload Class Initialized
INFO - 2020-09-12 11:54:08 --> Controller Class Initialized
ERROR - 2020-09-12 11:54:08 --> 404 Page Not Found: /index
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:54:08 --> Utf8 Class Initialized
INFO - 2020-09-12 11:54:08 --> URI Class Initialized
INFO - 2020-09-12 11:54:08 --> Router Class Initialized
INFO - 2020-09-12 11:54:08 --> Output Class Initialized
INFO - 2020-09-12 11:54:08 --> Security Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:54:08 --> Input Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Language Class Initialized
INFO - 2020-09-12 11:54:08 --> Config Class Initialized
INFO - 2020-09-12 11:54:08 --> Loader Class Initialized
INFO - 2020-09-12 11:54:08 --> Helper loaded: url_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: form_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: file_helper
INFO - 2020-09-12 11:54:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:54:08 --> Database Driver Class Initialized
DEBUG - 2020-09-12 11:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:54:08 --> Upload Class Initialized
INFO - 2020-09-12 11:54:08 --> Controller Class Initialized
ERROR - 2020-09-12 11:54:08 --> 404 Page Not Found: /index
INFO - 2020-09-12 11:54:10 --> Config Class Initialized
INFO - 2020-09-12 11:54:10 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:54:10 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:54:10 --> Utf8 Class Initialized
INFO - 2020-09-12 11:54:10 --> URI Class Initialized
INFO - 2020-09-12 11:54:10 --> Router Class Initialized
INFO - 2020-09-12 11:54:10 --> Output Class Initialized
INFO - 2020-09-12 11:54:10 --> Security Class Initialized
DEBUG - 2020-09-12 11:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:54:10 --> Input Class Initialized
INFO - 2020-09-12 11:54:10 --> Language Class Initialized
INFO - 2020-09-12 11:54:10 --> Language Class Initialized
INFO - 2020-09-12 11:54:10 --> Config Class Initialized
INFO - 2020-09-12 11:54:10 --> Loader Class Initialized
INFO - 2020-09-12 11:54:10 --> Helper loaded: url_helper
INFO - 2020-09-12 11:54:10 --> Helper loaded: form_helper
INFO - 2020-09-12 11:54:10 --> Helper loaded: file_helper
INFO - 2020-09-12 11:54:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 11:54:10 --> Database Driver Class Initialized
DEBUG - 2020-09-12 11:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 11:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:54:10 --> Upload Class Initialized
INFO - 2020-09-12 11:54:10 --> Controller Class Initialized
ERROR - 2020-09-12 11:54:10 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:14:24 --> Config Class Initialized
INFO - 2020-09-12 12:14:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:14:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:14:24 --> Utf8 Class Initialized
INFO - 2020-09-12 12:14:24 --> URI Class Initialized
DEBUG - 2020-09-12 12:14:24 --> No URI present. Default controller set.
INFO - 2020-09-12 12:14:24 --> Router Class Initialized
INFO - 2020-09-12 12:14:24 --> Output Class Initialized
INFO - 2020-09-12 12:14:24 --> Security Class Initialized
DEBUG - 2020-09-12 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:14:24 --> Input Class Initialized
INFO - 2020-09-12 12:14:24 --> Language Class Initialized
INFO - 2020-09-12 12:14:24 --> Language Class Initialized
INFO - 2020-09-12 12:14:24 --> Config Class Initialized
INFO - 2020-09-12 12:14:24 --> Loader Class Initialized
INFO - 2020-09-12 12:14:24 --> Helper loaded: url_helper
INFO - 2020-09-12 12:14:24 --> Helper loaded: form_helper
INFO - 2020-09-12 12:14:24 --> Helper loaded: file_helper
INFO - 2020-09-12 12:14:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:14:24 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:14:24 --> Upload Class Initialized
INFO - 2020-09-12 12:14:24 --> Controller Class Initialized
DEBUG - 2020-09-12 12:14:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 12:14:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 12:14:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 12:14:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 12:14:24 --> Final output sent to browser
DEBUG - 2020-09-12 12:14:24 --> Total execution time: 0.0693
INFO - 2020-09-12 12:14:24 --> Config Class Initialized
INFO - 2020-09-12 12:14:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:14:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:14:24 --> Utf8 Class Initialized
INFO - 2020-09-12 12:14:24 --> URI Class Initialized
DEBUG - 2020-09-12 12:14:24 --> No URI present. Default controller set.
INFO - 2020-09-12 12:14:24 --> Router Class Initialized
INFO - 2020-09-12 12:14:24 --> Output Class Initialized
INFO - 2020-09-12 12:14:24 --> Security Class Initialized
DEBUG - 2020-09-12 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:14:24 --> Input Class Initialized
INFO - 2020-09-12 12:14:24 --> Language Class Initialized
INFO - 2020-09-12 12:14:24 --> Language Class Initialized
INFO - 2020-09-12 12:14:24 --> Config Class Initialized
INFO - 2020-09-12 12:14:24 --> Loader Class Initialized
INFO - 2020-09-12 12:14:24 --> Helper loaded: url_helper
INFO - 2020-09-12 12:14:24 --> Helper loaded: form_helper
INFO - 2020-09-12 12:14:24 --> Helper loaded: file_helper
INFO - 2020-09-12 12:14:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:14:24 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:14:24 --> Upload Class Initialized
INFO - 2020-09-12 12:14:24 --> Controller Class Initialized
DEBUG - 2020-09-12 12:14:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 12:14:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 12:14:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 12:14:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 12:14:24 --> Final output sent to browser
DEBUG - 2020-09-12 12:14:24 --> Total execution time: 0.0588
INFO - 2020-09-12 12:22:22 --> Config Class Initialized
INFO - 2020-09-12 12:22:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:22:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:22:22 --> Utf8 Class Initialized
INFO - 2020-09-12 12:22:22 --> URI Class Initialized
INFO - 2020-09-12 12:22:22 --> Router Class Initialized
INFO - 2020-09-12 12:22:22 --> Output Class Initialized
INFO - 2020-09-12 12:22:22 --> Security Class Initialized
DEBUG - 2020-09-12 12:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:22:22 --> Input Class Initialized
INFO - 2020-09-12 12:22:22 --> Language Class Initialized
INFO - 2020-09-12 12:22:22 --> Language Class Initialized
INFO - 2020-09-12 12:22:22 --> Config Class Initialized
INFO - 2020-09-12 12:22:22 --> Loader Class Initialized
INFO - 2020-09-12 12:22:22 --> Helper loaded: url_helper
INFO - 2020-09-12 12:22:22 --> Helper loaded: form_helper
INFO - 2020-09-12 12:22:22 --> Helper loaded: file_helper
INFO - 2020-09-12 12:22:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:22:22 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:22:22 --> Upload Class Initialized
INFO - 2020-09-12 12:22:22 --> Controller Class Initialized
ERROR - 2020-09-12 12:22:22 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:45:24 --> Config Class Initialized
INFO - 2020-09-12 12:45:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:45:24 --> Utf8 Class Initialized
INFO - 2020-09-12 12:45:24 --> URI Class Initialized
DEBUG - 2020-09-12 12:45:24 --> No URI present. Default controller set.
INFO - 2020-09-12 12:45:24 --> Router Class Initialized
INFO - 2020-09-12 12:45:24 --> Output Class Initialized
INFO - 2020-09-12 12:45:24 --> Security Class Initialized
DEBUG - 2020-09-12 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:45:24 --> Input Class Initialized
INFO - 2020-09-12 12:45:24 --> Language Class Initialized
INFO - 2020-09-12 12:45:24 --> Language Class Initialized
INFO - 2020-09-12 12:45:24 --> Config Class Initialized
INFO - 2020-09-12 12:45:24 --> Loader Class Initialized
INFO - 2020-09-12 12:45:24 --> Helper loaded: url_helper
INFO - 2020-09-12 12:45:24 --> Helper loaded: form_helper
INFO - 2020-09-12 12:45:24 --> Helper loaded: file_helper
INFO - 2020-09-12 12:45:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:45:24 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:45:24 --> Upload Class Initialized
INFO - 2020-09-12 12:45:24 --> Controller Class Initialized
DEBUG - 2020-09-12 12:45:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 12:45:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 12:45:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 12:45:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 12:45:24 --> Final output sent to browser
DEBUG - 2020-09-12 12:45:24 --> Total execution time: 0.0521
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:45:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:45:27 --> Utf8 Class Initialized
INFO - 2020-09-12 12:45:27 --> URI Class Initialized
INFO - 2020-09-12 12:45:27 --> Router Class Initialized
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Hooks Class Initialized
INFO - 2020-09-12 12:45:27 --> Output Class Initialized
DEBUG - 2020-09-12 12:45:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:45:27 --> Utf8 Class Initialized
INFO - 2020-09-12 12:45:27 --> Security Class Initialized
DEBUG - 2020-09-12 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:45:27 --> Input Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> URI Class Initialized
INFO - 2020-09-12 12:45:27 --> Loader Class Initialized
INFO - 2020-09-12 12:45:27 --> Router Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: url_helper
INFO - 2020-09-12 12:45:27 --> Output Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: form_helper
INFO - 2020-09-12 12:45:27 --> Security Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: file_helper
DEBUG - 2020-09-12 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:45:27 --> Input Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:45:27 --> Database Driver Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Loader Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: url_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: form_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: file_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: myhelper_helper
DEBUG - 2020-09-12 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:45:27 --> Upload Class Initialized
INFO - 2020-09-12 12:45:27 --> Database Driver Class Initialized
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:45:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:45:27 --> Utf8 Class Initialized
INFO - 2020-09-12 12:45:27 --> URI Class Initialized
INFO - 2020-09-12 12:45:27 --> Controller Class Initialized
ERROR - 2020-09-12 12:45:27 --> 404 Page Not Found: /index
DEBUG - 2020-09-12 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:45:27 --> Upload Class Initialized
INFO - 2020-09-12 12:45:27 --> Router Class Initialized
INFO - 2020-09-12 12:45:27 --> Output Class Initialized
INFO - 2020-09-12 12:45:27 --> Security Class Initialized
DEBUG - 2020-09-12 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:45:27 --> Input Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Loader Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: url_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: form_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: file_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:45:27 --> Database Driver Class Initialized
INFO - 2020-09-12 12:45:27 --> Controller Class Initialized
DEBUG - 2020-09-12 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-09-12 12:45:27 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:45:27 --> Upload Class Initialized
INFO - 2020-09-12 12:45:27 --> Controller Class Initialized
ERROR - 2020-09-12 12:45:27 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:45:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:45:27 --> Utf8 Class Initialized
INFO - 2020-09-12 12:45:27 --> URI Class Initialized
INFO - 2020-09-12 12:45:27 --> Router Class Initialized
INFO - 2020-09-12 12:45:27 --> Output Class Initialized
INFO - 2020-09-12 12:45:27 --> Security Class Initialized
DEBUG - 2020-09-12 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:45:27 --> Input Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Language Class Initialized
INFO - 2020-09-12 12:45:27 --> Config Class Initialized
INFO - 2020-09-12 12:45:27 --> Loader Class Initialized
INFO - 2020-09-12 12:45:27 --> Helper loaded: url_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: form_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: file_helper
INFO - 2020-09-12 12:45:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:45:27 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:45:27 --> Upload Class Initialized
INFO - 2020-09-12 12:45:27 --> Controller Class Initialized
ERROR - 2020-09-12 12:45:27 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:45:31 --> Config Class Initialized
INFO - 2020-09-12 12:45:31 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:45:31 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:45:31 --> Utf8 Class Initialized
INFO - 2020-09-12 12:45:31 --> URI Class Initialized
INFO - 2020-09-12 12:45:31 --> Router Class Initialized
INFO - 2020-09-12 12:45:31 --> Output Class Initialized
INFO - 2020-09-12 12:45:31 --> Security Class Initialized
DEBUG - 2020-09-12 12:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:45:31 --> Input Class Initialized
INFO - 2020-09-12 12:45:31 --> Language Class Initialized
INFO - 2020-09-12 12:45:31 --> Language Class Initialized
INFO - 2020-09-12 12:45:31 --> Config Class Initialized
INFO - 2020-09-12 12:45:31 --> Loader Class Initialized
INFO - 2020-09-12 12:45:31 --> Helper loaded: url_helper
INFO - 2020-09-12 12:45:31 --> Helper loaded: form_helper
INFO - 2020-09-12 12:45:31 --> Helper loaded: file_helper
INFO - 2020-09-12 12:45:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:45:31 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:45:31 --> Upload Class Initialized
INFO - 2020-09-12 12:45:31 --> Controller Class Initialized
ERROR - 2020-09-12 12:45:31 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:46:23 --> Config Class Initialized
INFO - 2020-09-12 12:46:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:46:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:46:23 --> Utf8 Class Initialized
INFO - 2020-09-12 12:46:23 --> URI Class Initialized
DEBUG - 2020-09-12 12:46:23 --> No URI present. Default controller set.
INFO - 2020-09-12 12:46:23 --> Router Class Initialized
INFO - 2020-09-12 12:46:23 --> Output Class Initialized
INFO - 2020-09-12 12:46:23 --> Security Class Initialized
DEBUG - 2020-09-12 12:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:46:23 --> Input Class Initialized
INFO - 2020-09-12 12:46:23 --> Language Class Initialized
INFO - 2020-09-12 12:46:23 --> Language Class Initialized
INFO - 2020-09-12 12:46:23 --> Config Class Initialized
INFO - 2020-09-12 12:46:23 --> Loader Class Initialized
INFO - 2020-09-12 12:46:23 --> Helper loaded: url_helper
INFO - 2020-09-12 12:46:23 --> Helper loaded: form_helper
INFO - 2020-09-12 12:46:23 --> Helper loaded: file_helper
INFO - 2020-09-12 12:46:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:46:23 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:46:23 --> Upload Class Initialized
INFO - 2020-09-12 12:46:23 --> Controller Class Initialized
DEBUG - 2020-09-12 12:46:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 12:46:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 12:46:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 12:46:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 12:46:23 --> Final output sent to browser
DEBUG - 2020-09-12 12:46:23 --> Total execution time: 0.0637
INFO - 2020-09-12 12:46:24 --> Config Class Initialized
INFO - 2020-09-12 12:46:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:46:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:46:24 --> Utf8 Class Initialized
INFO - 2020-09-12 12:46:24 --> URI Class Initialized
INFO - 2020-09-12 12:46:24 --> Router Class Initialized
INFO - 2020-09-12 12:46:24 --> Output Class Initialized
INFO - 2020-09-12 12:46:24 --> Security Class Initialized
DEBUG - 2020-09-12 12:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:46:24 --> Input Class Initialized
INFO - 2020-09-12 12:46:24 --> Language Class Initialized
INFO - 2020-09-12 12:46:24 --> Language Class Initialized
INFO - 2020-09-12 12:46:24 --> Config Class Initialized
INFO - 2020-09-12 12:46:24 --> Loader Class Initialized
INFO - 2020-09-12 12:46:24 --> Helper loaded: url_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: form_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: file_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:46:24 --> Config Class Initialized
INFO - 2020-09-12 12:46:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:46:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:46:24 --> Utf8 Class Initialized
INFO - 2020-09-12 12:46:24 --> Database Driver Class Initialized
INFO - 2020-09-12 12:46:24 --> URI Class Initialized
DEBUG - 2020-09-12 12:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:46:24 --> Router Class Initialized
INFO - 2020-09-12 12:46:24 --> Upload Class Initialized
INFO - 2020-09-12 12:46:24 --> Output Class Initialized
INFO - 2020-09-12 12:46:24 --> Security Class Initialized
DEBUG - 2020-09-12 12:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:46:24 --> Input Class Initialized
INFO - 2020-09-12 12:46:24 --> Language Class Initialized
INFO - 2020-09-12 12:46:24 --> Language Class Initialized
INFO - 2020-09-12 12:46:24 --> Config Class Initialized
INFO - 2020-09-12 12:46:24 --> Loader Class Initialized
INFO - 2020-09-12 12:46:24 --> Helper loaded: url_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: form_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: file_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:46:24 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:46:24 --> Controller Class Initialized
ERROR - 2020-09-12 12:46:24 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:46:24 --> Upload Class Initialized
INFO - 2020-09-12 12:46:24 --> Config Class Initialized
INFO - 2020-09-12 12:46:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:46:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:46:24 --> Utf8 Class Initialized
INFO - 2020-09-12 12:46:24 --> URI Class Initialized
INFO - 2020-09-12 12:46:24 --> Router Class Initialized
INFO - 2020-09-12 12:46:24 --> Output Class Initialized
INFO - 2020-09-12 12:46:24 --> Controller Class Initialized
INFO - 2020-09-12 12:46:24 --> Security Class Initialized
ERROR - 2020-09-12 12:46:24 --> 404 Page Not Found: /index
DEBUG - 2020-09-12 12:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:46:24 --> Input Class Initialized
INFO - 2020-09-12 12:46:24 --> Language Class Initialized
INFO - 2020-09-12 12:46:24 --> Language Class Initialized
INFO - 2020-09-12 12:46:24 --> Config Class Initialized
INFO - 2020-09-12 12:46:24 --> Loader Class Initialized
INFO - 2020-09-12 12:46:24 --> Helper loaded: url_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: form_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: file_helper
INFO - 2020-09-12 12:46:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:46:24 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:46:24 --> Upload Class Initialized
INFO - 2020-09-12 12:46:24 --> Controller Class Initialized
ERROR - 2020-09-12 12:46:24 --> 404 Page Not Found: /index
INFO - 2020-09-12 12:46:25 --> Config Class Initialized
INFO - 2020-09-12 12:46:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 12:46:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 12:46:25 --> Utf8 Class Initialized
INFO - 2020-09-12 12:46:25 --> URI Class Initialized
INFO - 2020-09-12 12:46:25 --> Router Class Initialized
INFO - 2020-09-12 12:46:25 --> Output Class Initialized
INFO - 2020-09-12 12:46:25 --> Security Class Initialized
DEBUG - 2020-09-12 12:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 12:46:25 --> Input Class Initialized
INFO - 2020-09-12 12:46:25 --> Language Class Initialized
INFO - 2020-09-12 12:46:25 --> Language Class Initialized
INFO - 2020-09-12 12:46:25 --> Config Class Initialized
INFO - 2020-09-12 12:46:25 --> Loader Class Initialized
INFO - 2020-09-12 12:46:25 --> Helper loaded: url_helper
INFO - 2020-09-12 12:46:25 --> Helper loaded: form_helper
INFO - 2020-09-12 12:46:25 --> Helper loaded: file_helper
INFO - 2020-09-12 12:46:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 12:46:25 --> Database Driver Class Initialized
DEBUG - 2020-09-12 12:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 12:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 12:46:25 --> Upload Class Initialized
INFO - 2020-09-12 12:46:25 --> Controller Class Initialized
ERROR - 2020-09-12 12:46:25 --> 404 Page Not Found: /index
INFO - 2020-09-12 13:35:40 --> Config Class Initialized
INFO - 2020-09-12 13:35:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 13:35:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 13:35:40 --> Utf8 Class Initialized
INFO - 2020-09-12 13:35:40 --> URI Class Initialized
DEBUG - 2020-09-12 13:35:40 --> No URI present. Default controller set.
INFO - 2020-09-12 13:35:40 --> Router Class Initialized
INFO - 2020-09-12 13:35:40 --> Output Class Initialized
INFO - 2020-09-12 13:35:40 --> Security Class Initialized
DEBUG - 2020-09-12 13:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 13:35:40 --> Input Class Initialized
INFO - 2020-09-12 13:35:40 --> Language Class Initialized
INFO - 2020-09-12 13:35:40 --> Language Class Initialized
INFO - 2020-09-12 13:35:40 --> Config Class Initialized
INFO - 2020-09-12 13:35:40 --> Loader Class Initialized
INFO - 2020-09-12 13:35:40 --> Helper loaded: url_helper
INFO - 2020-09-12 13:35:40 --> Helper loaded: form_helper
INFO - 2020-09-12 13:35:40 --> Helper loaded: file_helper
INFO - 2020-09-12 13:35:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 13:35:40 --> Database Driver Class Initialized
DEBUG - 2020-09-12 13:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 13:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 13:35:40 --> Upload Class Initialized
INFO - 2020-09-12 13:35:40 --> Controller Class Initialized
DEBUG - 2020-09-12 13:35:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 13:35:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 13:35:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 13:35:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 13:35:40 --> Final output sent to browser
DEBUG - 2020-09-12 13:35:40 --> Total execution time: 0.0714
INFO - 2020-09-12 13:58:33 --> Config Class Initialized
INFO - 2020-09-12 13:58:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 13:58:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 13:58:33 --> Utf8 Class Initialized
INFO - 2020-09-12 13:58:33 --> URI Class Initialized
DEBUG - 2020-09-12 13:58:33 --> No URI present. Default controller set.
INFO - 2020-09-12 13:58:33 --> Router Class Initialized
INFO - 2020-09-12 13:58:33 --> Output Class Initialized
INFO - 2020-09-12 13:58:33 --> Security Class Initialized
DEBUG - 2020-09-12 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 13:58:33 --> Input Class Initialized
INFO - 2020-09-12 13:58:33 --> Language Class Initialized
INFO - 2020-09-12 13:58:33 --> Language Class Initialized
INFO - 2020-09-12 13:58:33 --> Config Class Initialized
INFO - 2020-09-12 13:58:33 --> Loader Class Initialized
INFO - 2020-09-12 13:58:33 --> Helper loaded: url_helper
INFO - 2020-09-12 13:58:33 --> Helper loaded: form_helper
INFO - 2020-09-12 13:58:33 --> Helper loaded: file_helper
INFO - 2020-09-12 13:58:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 13:58:33 --> Database Driver Class Initialized
DEBUG - 2020-09-12 13:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 13:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 13:58:33 --> Upload Class Initialized
INFO - 2020-09-12 13:58:33 --> Controller Class Initialized
DEBUG - 2020-09-12 13:58:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 13:58:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 13:58:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 13:58:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 13:58:33 --> Final output sent to browser
DEBUG - 2020-09-12 13:58:33 --> Total execution time: 0.0397
INFO - 2020-09-12 13:59:57 --> Config Class Initialized
INFO - 2020-09-12 13:59:57 --> Hooks Class Initialized
DEBUG - 2020-09-12 13:59:57 --> UTF-8 Support Enabled
INFO - 2020-09-12 13:59:57 --> Utf8 Class Initialized
INFO - 2020-09-12 13:59:57 --> URI Class Initialized
DEBUG - 2020-09-12 13:59:57 --> No URI present. Default controller set.
INFO - 2020-09-12 13:59:57 --> Router Class Initialized
INFO - 2020-09-12 13:59:57 --> Output Class Initialized
INFO - 2020-09-12 13:59:57 --> Security Class Initialized
DEBUG - 2020-09-12 13:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 13:59:57 --> Input Class Initialized
INFO - 2020-09-12 13:59:57 --> Language Class Initialized
INFO - 2020-09-12 13:59:57 --> Language Class Initialized
INFO - 2020-09-12 13:59:57 --> Config Class Initialized
INFO - 2020-09-12 13:59:57 --> Loader Class Initialized
INFO - 2020-09-12 13:59:57 --> Helper loaded: url_helper
INFO - 2020-09-12 13:59:57 --> Helper loaded: form_helper
INFO - 2020-09-12 13:59:57 --> Helper loaded: file_helper
INFO - 2020-09-12 13:59:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 13:59:57 --> Database Driver Class Initialized
DEBUG - 2020-09-12 13:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 13:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 13:59:57 --> Upload Class Initialized
INFO - 2020-09-12 13:59:57 --> Controller Class Initialized
DEBUG - 2020-09-12 13:59:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 13:59:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 13:59:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 13:59:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 13:59:57 --> Final output sent to browser
DEBUG - 2020-09-12 13:59:57 --> Total execution time: 0.0505
INFO - 2020-09-12 14:13:16 --> Config Class Initialized
INFO - 2020-09-12 14:13:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 14:13:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 14:13:16 --> Utf8 Class Initialized
INFO - 2020-09-12 14:13:16 --> URI Class Initialized
INFO - 2020-09-12 14:13:16 --> Router Class Initialized
INFO - 2020-09-12 14:13:16 --> Output Class Initialized
INFO - 2020-09-12 14:13:16 --> Security Class Initialized
DEBUG - 2020-09-12 14:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 14:13:16 --> Input Class Initialized
INFO - 2020-09-12 14:13:16 --> Language Class Initialized
INFO - 2020-09-12 14:13:16 --> Language Class Initialized
INFO - 2020-09-12 14:13:16 --> Config Class Initialized
INFO - 2020-09-12 14:13:16 --> Loader Class Initialized
INFO - 2020-09-12 14:13:16 --> Helper loaded: url_helper
INFO - 2020-09-12 14:13:16 --> Helper loaded: form_helper
INFO - 2020-09-12 14:13:16 --> Helper loaded: file_helper
INFO - 2020-09-12 14:13:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 14:13:16 --> Database Driver Class Initialized
DEBUG - 2020-09-12 14:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 14:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 14:13:16 --> Upload Class Initialized
INFO - 2020-09-12 14:13:16 --> Controller Class Initialized
ERROR - 2020-09-12 14:13:16 --> 404 Page Not Found: /index
INFO - 2020-09-12 14:13:17 --> Config Class Initialized
INFO - 2020-09-12 14:13:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 14:13:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 14:13:17 --> Utf8 Class Initialized
INFO - 2020-09-12 14:13:17 --> URI Class Initialized
INFO - 2020-09-12 14:13:17 --> Router Class Initialized
INFO - 2020-09-12 14:13:17 --> Output Class Initialized
INFO - 2020-09-12 14:13:17 --> Security Class Initialized
DEBUG - 2020-09-12 14:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 14:13:17 --> Input Class Initialized
INFO - 2020-09-12 14:13:17 --> Language Class Initialized
INFO - 2020-09-12 14:13:17 --> Language Class Initialized
INFO - 2020-09-12 14:13:17 --> Config Class Initialized
INFO - 2020-09-12 14:13:17 --> Loader Class Initialized
INFO - 2020-09-12 14:13:17 --> Helper loaded: url_helper
INFO - 2020-09-12 14:13:17 --> Helper loaded: form_helper
INFO - 2020-09-12 14:13:17 --> Helper loaded: file_helper
INFO - 2020-09-12 14:13:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 14:13:17 --> Database Driver Class Initialized
DEBUG - 2020-09-12 14:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 14:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 14:13:17 --> Upload Class Initialized
INFO - 2020-09-12 14:13:17 --> Controller Class Initialized
ERROR - 2020-09-12 14:13:17 --> 404 Page Not Found: /index
INFO - 2020-09-12 14:13:17 --> Config Class Initialized
INFO - 2020-09-12 14:13:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 14:13:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 14:13:17 --> Utf8 Class Initialized
INFO - 2020-09-12 14:13:17 --> URI Class Initialized
INFO - 2020-09-12 14:13:17 --> Router Class Initialized
INFO - 2020-09-12 14:13:17 --> Output Class Initialized
INFO - 2020-09-12 14:13:17 --> Security Class Initialized
DEBUG - 2020-09-12 14:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 14:13:17 --> Input Class Initialized
INFO - 2020-09-12 14:13:17 --> Language Class Initialized
INFO - 2020-09-12 14:13:17 --> Language Class Initialized
INFO - 2020-09-12 14:13:17 --> Config Class Initialized
INFO - 2020-09-12 14:13:17 --> Loader Class Initialized
INFO - 2020-09-12 14:13:17 --> Helper loaded: url_helper
INFO - 2020-09-12 14:13:17 --> Helper loaded: form_helper
INFO - 2020-09-12 14:13:17 --> Helper loaded: file_helper
INFO - 2020-09-12 14:13:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 14:13:17 --> Database Driver Class Initialized
DEBUG - 2020-09-12 14:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 14:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 14:13:17 --> Upload Class Initialized
INFO - 2020-09-12 14:13:17 --> Controller Class Initialized
ERROR - 2020-09-12 14:13:17 --> 404 Page Not Found: /index
INFO - 2020-09-12 14:13:18 --> Config Class Initialized
INFO - 2020-09-12 14:13:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 14:13:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 14:13:18 --> Utf8 Class Initialized
INFO - 2020-09-12 14:13:18 --> URI Class Initialized
DEBUG - 2020-09-12 14:13:18 --> No URI present. Default controller set.
INFO - 2020-09-12 14:13:18 --> Router Class Initialized
INFO - 2020-09-12 14:13:18 --> Output Class Initialized
INFO - 2020-09-12 14:13:18 --> Security Class Initialized
DEBUG - 2020-09-12 14:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 14:13:18 --> Input Class Initialized
INFO - 2020-09-12 14:13:18 --> Language Class Initialized
INFO - 2020-09-12 14:13:18 --> Language Class Initialized
INFO - 2020-09-12 14:13:18 --> Config Class Initialized
INFO - 2020-09-12 14:13:18 --> Loader Class Initialized
INFO - 2020-09-12 14:13:18 --> Helper loaded: url_helper
INFO - 2020-09-12 14:13:18 --> Helper loaded: form_helper
INFO - 2020-09-12 14:13:18 --> Helper loaded: file_helper
INFO - 2020-09-12 14:13:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 14:13:18 --> Database Driver Class Initialized
DEBUG - 2020-09-12 14:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 14:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 14:13:18 --> Upload Class Initialized
INFO - 2020-09-12 14:13:18 --> Controller Class Initialized
DEBUG - 2020-09-12 14:13:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 14:13:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 14:13:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 14:13:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 14:13:18 --> Final output sent to browser
DEBUG - 2020-09-12 14:13:18 --> Total execution time: 0.0369
INFO - 2020-09-12 14:27:31 --> Config Class Initialized
INFO - 2020-09-12 14:27:31 --> Hooks Class Initialized
DEBUG - 2020-09-12 14:27:31 --> UTF-8 Support Enabled
INFO - 2020-09-12 14:27:31 --> Utf8 Class Initialized
INFO - 2020-09-12 14:27:31 --> URI Class Initialized
DEBUG - 2020-09-12 14:27:31 --> No URI present. Default controller set.
INFO - 2020-09-12 14:27:31 --> Router Class Initialized
INFO - 2020-09-12 14:27:31 --> Output Class Initialized
INFO - 2020-09-12 14:27:31 --> Security Class Initialized
DEBUG - 2020-09-12 14:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 14:27:31 --> Input Class Initialized
INFO - 2020-09-12 14:27:31 --> Language Class Initialized
INFO - 2020-09-12 14:27:31 --> Language Class Initialized
INFO - 2020-09-12 14:27:31 --> Config Class Initialized
INFO - 2020-09-12 14:27:31 --> Loader Class Initialized
INFO - 2020-09-12 14:27:31 --> Helper loaded: url_helper
INFO - 2020-09-12 14:27:31 --> Helper loaded: form_helper
INFO - 2020-09-12 14:27:31 --> Helper loaded: file_helper
INFO - 2020-09-12 14:27:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 14:27:31 --> Database Driver Class Initialized
DEBUG - 2020-09-12 14:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 14:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 14:27:31 --> Upload Class Initialized
INFO - 2020-09-12 14:27:31 --> Controller Class Initialized
DEBUG - 2020-09-12 14:27:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 14:27:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 14:27:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 14:27:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 14:27:31 --> Final output sent to browser
DEBUG - 2020-09-12 14:27:31 --> Total execution time: 0.0653
INFO - 2020-09-12 14:35:12 --> Config Class Initialized
INFO - 2020-09-12 14:35:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 14:35:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 14:35:12 --> Utf8 Class Initialized
INFO - 2020-09-12 14:35:12 --> URI Class Initialized
INFO - 2020-09-12 14:35:12 --> Router Class Initialized
INFO - 2020-09-12 14:35:12 --> Output Class Initialized
INFO - 2020-09-12 14:35:12 --> Security Class Initialized
DEBUG - 2020-09-12 14:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 14:35:12 --> Input Class Initialized
INFO - 2020-09-12 14:35:12 --> Language Class Initialized
INFO - 2020-09-12 14:35:12 --> Language Class Initialized
INFO - 2020-09-12 14:35:12 --> Config Class Initialized
INFO - 2020-09-12 14:35:12 --> Loader Class Initialized
INFO - 2020-09-12 14:35:12 --> Helper loaded: url_helper
INFO - 2020-09-12 14:35:12 --> Helper loaded: form_helper
INFO - 2020-09-12 14:35:12 --> Helper loaded: file_helper
INFO - 2020-09-12 14:35:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 14:35:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 14:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 14:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 14:35:12 --> Upload Class Initialized
INFO - 2020-09-12 14:35:12 --> Controller Class Initialized
ERROR - 2020-09-12 14:35:12 --> 404 Page Not Found: /index
INFO - 2020-09-12 15:44:00 --> Config Class Initialized
INFO - 2020-09-12 15:44:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 15:44:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 15:44:00 --> Utf8 Class Initialized
INFO - 2020-09-12 15:44:00 --> URI Class Initialized
INFO - 2020-09-12 15:44:00 --> Router Class Initialized
INFO - 2020-09-12 15:44:00 --> Output Class Initialized
INFO - 2020-09-12 15:44:00 --> Security Class Initialized
DEBUG - 2020-09-12 15:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 15:44:00 --> Input Class Initialized
INFO - 2020-09-12 15:44:00 --> Language Class Initialized
INFO - 2020-09-12 15:44:00 --> Language Class Initialized
INFO - 2020-09-12 15:44:00 --> Config Class Initialized
INFO - 2020-09-12 15:44:00 --> Loader Class Initialized
INFO - 2020-09-12 15:44:00 --> Helper loaded: url_helper
INFO - 2020-09-12 15:44:00 --> Helper loaded: form_helper
INFO - 2020-09-12 15:44:00 --> Helper loaded: file_helper
INFO - 2020-09-12 15:44:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 15:44:00 --> Database Driver Class Initialized
DEBUG - 2020-09-12 15:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 15:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 15:44:00 --> Upload Class Initialized
INFO - 2020-09-12 15:44:00 --> Controller Class Initialized
ERROR - 2020-09-12 15:44:00 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:17:44 --> Config Class Initialized
INFO - 2020-09-12 16:17:44 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:17:44 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:17:44 --> Utf8 Class Initialized
INFO - 2020-09-12 16:17:44 --> URI Class Initialized
INFO - 2020-09-12 16:17:44 --> Router Class Initialized
INFO - 2020-09-12 16:17:44 --> Output Class Initialized
INFO - 2020-09-12 16:17:44 --> Security Class Initialized
DEBUG - 2020-09-12 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:17:44 --> Input Class Initialized
INFO - 2020-09-12 16:17:44 --> Language Class Initialized
INFO - 2020-09-12 16:17:44 --> Language Class Initialized
INFO - 2020-09-12 16:17:44 --> Config Class Initialized
INFO - 2020-09-12 16:17:44 --> Loader Class Initialized
INFO - 2020-09-12 16:17:44 --> Helper loaded: url_helper
INFO - 2020-09-12 16:17:44 --> Helper loaded: form_helper
INFO - 2020-09-12 16:17:44 --> Helper loaded: file_helper
INFO - 2020-09-12 16:17:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:17:44 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:17:44 --> Upload Class Initialized
INFO - 2020-09-12 16:17:44 --> Controller Class Initialized
ERROR - 2020-09-12 16:17:44 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:17:47 --> Config Class Initialized
INFO - 2020-09-12 16:17:47 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:17:47 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:17:47 --> Utf8 Class Initialized
INFO - 2020-09-12 16:17:47 --> URI Class Initialized
INFO - 2020-09-12 16:17:47 --> Router Class Initialized
INFO - 2020-09-12 16:17:47 --> Output Class Initialized
INFO - 2020-09-12 16:17:47 --> Security Class Initialized
DEBUG - 2020-09-12 16:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:17:47 --> Input Class Initialized
INFO - 2020-09-12 16:17:47 --> Language Class Initialized
INFO - 2020-09-12 16:17:47 --> Language Class Initialized
INFO - 2020-09-12 16:17:47 --> Config Class Initialized
INFO - 2020-09-12 16:17:47 --> Loader Class Initialized
INFO - 2020-09-12 16:17:47 --> Helper loaded: url_helper
INFO - 2020-09-12 16:17:47 --> Helper loaded: form_helper
INFO - 2020-09-12 16:17:47 --> Helper loaded: file_helper
INFO - 2020-09-12 16:17:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:17:47 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:17:47 --> Upload Class Initialized
INFO - 2020-09-12 16:17:47 --> Controller Class Initialized
ERROR - 2020-09-12 16:17:47 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:17:52 --> Config Class Initialized
INFO - 2020-09-12 16:17:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:17:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:17:52 --> Utf8 Class Initialized
INFO - 2020-09-12 16:17:52 --> URI Class Initialized
INFO - 2020-09-12 16:17:52 --> Router Class Initialized
INFO - 2020-09-12 16:17:52 --> Output Class Initialized
INFO - 2020-09-12 16:17:52 --> Security Class Initialized
DEBUG - 2020-09-12 16:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:17:52 --> Input Class Initialized
INFO - 2020-09-12 16:17:52 --> Language Class Initialized
INFO - 2020-09-12 16:17:52 --> Language Class Initialized
INFO - 2020-09-12 16:17:52 --> Config Class Initialized
INFO - 2020-09-12 16:17:52 --> Loader Class Initialized
INFO - 2020-09-12 16:17:52 --> Helper loaded: url_helper
INFO - 2020-09-12 16:17:52 --> Helper loaded: form_helper
INFO - 2020-09-12 16:17:52 --> Helper loaded: file_helper
INFO - 2020-09-12 16:17:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:17:52 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:17:52 --> Upload Class Initialized
INFO - 2020-09-12 16:17:52 --> Controller Class Initialized
ERROR - 2020-09-12 16:17:52 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:19:03 --> Config Class Initialized
INFO - 2020-09-12 16:19:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:19:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:19:03 --> Utf8 Class Initialized
INFO - 2020-09-12 16:19:03 --> URI Class Initialized
DEBUG - 2020-09-12 16:19:03 --> No URI present. Default controller set.
INFO - 2020-09-12 16:19:03 --> Router Class Initialized
INFO - 2020-09-12 16:19:03 --> Output Class Initialized
INFO - 2020-09-12 16:19:03 --> Security Class Initialized
DEBUG - 2020-09-12 16:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:19:03 --> Input Class Initialized
INFO - 2020-09-12 16:19:03 --> Language Class Initialized
INFO - 2020-09-12 16:19:03 --> Language Class Initialized
INFO - 2020-09-12 16:19:03 --> Config Class Initialized
INFO - 2020-09-12 16:19:03 --> Loader Class Initialized
INFO - 2020-09-12 16:19:03 --> Helper loaded: url_helper
INFO - 2020-09-12 16:19:03 --> Helper loaded: form_helper
INFO - 2020-09-12 16:19:03 --> Helper loaded: file_helper
INFO - 2020-09-12 16:19:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:19:03 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:19:03 --> Upload Class Initialized
INFO - 2020-09-12 16:19:03 --> Controller Class Initialized
DEBUG - 2020-09-12 16:19:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 16:19:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 16:19:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 16:19:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 16:19:03 --> Final output sent to browser
DEBUG - 2020-09-12 16:19:03 --> Total execution time: 0.0425
INFO - 2020-09-12 16:19:06 --> Config Class Initialized
INFO - 2020-09-12 16:19:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:19:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:19:06 --> Utf8 Class Initialized
INFO - 2020-09-12 16:19:06 --> URI Class Initialized
INFO - 2020-09-12 16:19:06 --> Router Class Initialized
INFO - 2020-09-12 16:19:06 --> Output Class Initialized
INFO - 2020-09-12 16:19:06 --> Security Class Initialized
DEBUG - 2020-09-12 16:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:19:06 --> Input Class Initialized
INFO - 2020-09-12 16:19:06 --> Language Class Initialized
INFO - 2020-09-12 16:19:06 --> Language Class Initialized
INFO - 2020-09-12 16:19:06 --> Config Class Initialized
INFO - 2020-09-12 16:19:06 --> Loader Class Initialized
INFO - 2020-09-12 16:19:06 --> Helper loaded: url_helper
INFO - 2020-09-12 16:19:06 --> Helper loaded: form_helper
INFO - 2020-09-12 16:19:06 --> Helper loaded: file_helper
INFO - 2020-09-12 16:19:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:19:06 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:19:06 --> Upload Class Initialized
INFO - 2020-09-12 16:19:06 --> Controller Class Initialized
ERROR - 2020-09-12 16:19:06 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:19:06 --> Config Class Initialized
INFO - 2020-09-12 16:19:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:19:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:19:06 --> Utf8 Class Initialized
INFO - 2020-09-12 16:19:06 --> URI Class Initialized
INFO - 2020-09-12 16:19:06 --> Router Class Initialized
INFO - 2020-09-12 16:19:06 --> Output Class Initialized
INFO - 2020-09-12 16:19:06 --> Security Class Initialized
DEBUG - 2020-09-12 16:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:19:06 --> Input Class Initialized
INFO - 2020-09-12 16:19:06 --> Language Class Initialized
INFO - 2020-09-12 16:19:06 --> Language Class Initialized
INFO - 2020-09-12 16:19:06 --> Config Class Initialized
INFO - 2020-09-12 16:19:07 --> Loader Class Initialized
INFO - 2020-09-12 16:19:07 --> Helper loaded: url_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: form_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: file_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:19:07 --> Config Class Initialized
INFO - 2020-09-12 16:19:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:19:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:19:07 --> Utf8 Class Initialized
INFO - 2020-09-12 16:19:07 --> URI Class Initialized
INFO - 2020-09-12 16:19:07 --> Database Driver Class Initialized
INFO - 2020-09-12 16:19:07 --> Router Class Initialized
DEBUG - 2020-09-12 16:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:19:07 --> Output Class Initialized
INFO - 2020-09-12 16:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:19:07 --> Upload Class Initialized
INFO - 2020-09-12 16:19:07 --> Security Class Initialized
DEBUG - 2020-09-12 16:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:19:07 --> Input Class Initialized
INFO - 2020-09-12 16:19:07 --> Language Class Initialized
INFO - 2020-09-12 16:19:07 --> Language Class Initialized
INFO - 2020-09-12 16:19:07 --> Config Class Initialized
INFO - 2020-09-12 16:19:07 --> Loader Class Initialized
INFO - 2020-09-12 16:19:07 --> Helper loaded: url_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: form_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: file_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:19:07 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:19:07 --> Controller Class Initialized
ERROR - 2020-09-12 16:19:07 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:19:07 --> Upload Class Initialized
INFO - 2020-09-12 16:19:07 --> Controller Class Initialized
ERROR - 2020-09-12 16:19:07 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:19:07 --> Config Class Initialized
INFO - 2020-09-12 16:19:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:19:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:19:07 --> Utf8 Class Initialized
INFO - 2020-09-12 16:19:07 --> URI Class Initialized
INFO - 2020-09-12 16:19:07 --> Router Class Initialized
INFO - 2020-09-12 16:19:07 --> Output Class Initialized
INFO - 2020-09-12 16:19:07 --> Security Class Initialized
DEBUG - 2020-09-12 16:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:19:07 --> Input Class Initialized
INFO - 2020-09-12 16:19:07 --> Language Class Initialized
INFO - 2020-09-12 16:19:07 --> Language Class Initialized
INFO - 2020-09-12 16:19:07 --> Config Class Initialized
INFO - 2020-09-12 16:19:07 --> Loader Class Initialized
INFO - 2020-09-12 16:19:07 --> Helper loaded: url_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: form_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: file_helper
INFO - 2020-09-12 16:19:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:19:07 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:19:07 --> Upload Class Initialized
INFO - 2020-09-12 16:19:07 --> Controller Class Initialized
ERROR - 2020-09-12 16:19:07 --> 404 Page Not Found: /index
INFO - 2020-09-12 16:19:09 --> Config Class Initialized
INFO - 2020-09-12 16:19:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 16:19:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 16:19:09 --> Utf8 Class Initialized
INFO - 2020-09-12 16:19:09 --> URI Class Initialized
INFO - 2020-09-12 16:19:09 --> Router Class Initialized
INFO - 2020-09-12 16:19:09 --> Output Class Initialized
INFO - 2020-09-12 16:19:09 --> Security Class Initialized
DEBUG - 2020-09-12 16:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 16:19:09 --> Input Class Initialized
INFO - 2020-09-12 16:19:09 --> Language Class Initialized
INFO - 2020-09-12 16:19:09 --> Language Class Initialized
INFO - 2020-09-12 16:19:09 --> Config Class Initialized
INFO - 2020-09-12 16:19:09 --> Loader Class Initialized
INFO - 2020-09-12 16:19:09 --> Helper loaded: url_helper
INFO - 2020-09-12 16:19:09 --> Helper loaded: form_helper
INFO - 2020-09-12 16:19:09 --> Helper loaded: file_helper
INFO - 2020-09-12 16:19:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 16:19:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 16:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 16:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 16:19:09 --> Upload Class Initialized
INFO - 2020-09-12 16:19:09 --> Controller Class Initialized
ERROR - 2020-09-12 16:19:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 17:50:39 --> Config Class Initialized
INFO - 2020-09-12 17:50:39 --> Hooks Class Initialized
DEBUG - 2020-09-12 17:50:39 --> UTF-8 Support Enabled
INFO - 2020-09-12 17:50:39 --> Utf8 Class Initialized
INFO - 2020-09-12 17:50:39 --> URI Class Initialized
INFO - 2020-09-12 17:50:39 --> Router Class Initialized
INFO - 2020-09-12 17:50:39 --> Output Class Initialized
INFO - 2020-09-12 17:50:39 --> Security Class Initialized
DEBUG - 2020-09-12 17:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 17:50:39 --> Input Class Initialized
INFO - 2020-09-12 17:50:39 --> Language Class Initialized
INFO - 2020-09-12 17:50:39 --> Language Class Initialized
INFO - 2020-09-12 17:50:39 --> Config Class Initialized
INFO - 2020-09-12 17:50:39 --> Loader Class Initialized
INFO - 2020-09-12 17:50:39 --> Helper loaded: url_helper
INFO - 2020-09-12 17:50:39 --> Helper loaded: form_helper
INFO - 2020-09-12 17:50:39 --> Helper loaded: file_helper
INFO - 2020-09-12 17:50:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 17:50:39 --> Database Driver Class Initialized
DEBUG - 2020-09-12 17:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 17:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 17:50:39 --> Upload Class Initialized
INFO - 2020-09-12 17:50:39 --> Controller Class Initialized
ERROR - 2020-09-12 17:50:39 --> 404 Page Not Found: /index
INFO - 2020-09-12 18:01:26 --> Config Class Initialized
INFO - 2020-09-12 18:01:26 --> Hooks Class Initialized
DEBUG - 2020-09-12 18:01:26 --> UTF-8 Support Enabled
INFO - 2020-09-12 18:01:26 --> Utf8 Class Initialized
INFO - 2020-09-12 18:01:26 --> URI Class Initialized
DEBUG - 2020-09-12 18:01:26 --> No URI present. Default controller set.
INFO - 2020-09-12 18:01:26 --> Router Class Initialized
INFO - 2020-09-12 18:01:26 --> Output Class Initialized
INFO - 2020-09-12 18:01:26 --> Security Class Initialized
DEBUG - 2020-09-12 18:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 18:01:26 --> Input Class Initialized
INFO - 2020-09-12 18:01:26 --> Language Class Initialized
INFO - 2020-09-12 18:01:26 --> Language Class Initialized
INFO - 2020-09-12 18:01:26 --> Config Class Initialized
INFO - 2020-09-12 18:01:26 --> Loader Class Initialized
INFO - 2020-09-12 18:01:26 --> Helper loaded: url_helper
INFO - 2020-09-12 18:01:26 --> Helper loaded: form_helper
INFO - 2020-09-12 18:01:26 --> Helper loaded: file_helper
INFO - 2020-09-12 18:01:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 18:01:26 --> Database Driver Class Initialized
DEBUG - 2020-09-12 18:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 18:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 18:01:26 --> Upload Class Initialized
INFO - 2020-09-12 18:01:26 --> Controller Class Initialized
DEBUG - 2020-09-12 18:01:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 18:01:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 18:01:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 18:01:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 18:01:26 --> Final output sent to browser
DEBUG - 2020-09-12 18:01:26 --> Total execution time: 0.0547
INFO - 2020-09-12 18:24:05 --> Config Class Initialized
INFO - 2020-09-12 18:24:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 18:24:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 18:24:05 --> Utf8 Class Initialized
INFO - 2020-09-12 18:24:05 --> URI Class Initialized
INFO - 2020-09-12 18:24:05 --> Router Class Initialized
INFO - 2020-09-12 18:24:05 --> Output Class Initialized
INFO - 2020-09-12 18:24:05 --> Security Class Initialized
DEBUG - 2020-09-12 18:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 18:24:05 --> Input Class Initialized
INFO - 2020-09-12 18:24:05 --> Language Class Initialized
INFO - 2020-09-12 18:24:05 --> Language Class Initialized
INFO - 2020-09-12 18:24:05 --> Config Class Initialized
INFO - 2020-09-12 18:24:05 --> Loader Class Initialized
INFO - 2020-09-12 18:24:05 --> Helper loaded: url_helper
INFO - 2020-09-12 18:24:05 --> Helper loaded: form_helper
INFO - 2020-09-12 18:24:05 --> Helper loaded: file_helper
INFO - 2020-09-12 18:24:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 18:24:05 --> Database Driver Class Initialized
DEBUG - 2020-09-12 18:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 18:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 18:24:05 --> Upload Class Initialized
INFO - 2020-09-12 18:24:05 --> Controller Class Initialized
ERROR - 2020-09-12 18:24:05 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:15:53 --> Config Class Initialized
INFO - 2020-09-12 19:15:53 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:15:53 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:15:53 --> Utf8 Class Initialized
INFO - 2020-09-12 19:15:53 --> URI Class Initialized
DEBUG - 2020-09-12 19:15:53 --> No URI present. Default controller set.
INFO - 2020-09-12 19:15:53 --> Router Class Initialized
INFO - 2020-09-12 19:15:53 --> Output Class Initialized
INFO - 2020-09-12 19:15:53 --> Security Class Initialized
DEBUG - 2020-09-12 19:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:15:53 --> Input Class Initialized
INFO - 2020-09-12 19:15:53 --> Language Class Initialized
INFO - 2020-09-12 19:15:53 --> Language Class Initialized
INFO - 2020-09-12 19:15:53 --> Config Class Initialized
INFO - 2020-09-12 19:15:53 --> Loader Class Initialized
INFO - 2020-09-12 19:15:53 --> Helper loaded: url_helper
INFO - 2020-09-12 19:15:53 --> Helper loaded: form_helper
INFO - 2020-09-12 19:15:53 --> Helper loaded: file_helper
INFO - 2020-09-12 19:15:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:15:53 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:15:53 --> Upload Class Initialized
INFO - 2020-09-12 19:15:53 --> Controller Class Initialized
DEBUG - 2020-09-12 19:15:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 19:15:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 19:15:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 19:15:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 19:15:53 --> Final output sent to browser
DEBUG - 2020-09-12 19:15:53 --> Total execution time: 0.0510
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:15:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:15:58 --> Utf8 Class Initialized
INFO - 2020-09-12 19:15:58 --> URI Class Initialized
INFO - 2020-09-12 19:15:58 --> Router Class Initialized
INFO - 2020-09-12 19:15:58 --> Output Class Initialized
INFO - 2020-09-12 19:15:58 --> Security Class Initialized
DEBUG - 2020-09-12 19:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:15:58 --> Input Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Loader Class Initialized
INFO - 2020-09-12 19:15:58 --> Helper loaded: url_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: form_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: file_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:15:58 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:15:58 --> Upload Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:15:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:15:58 --> Utf8 Class Initialized
INFO - 2020-09-12 19:15:58 --> URI Class Initialized
INFO - 2020-09-12 19:15:58 --> Controller Class Initialized
ERROR - 2020-09-12 19:15:58 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:15:58 --> Router Class Initialized
INFO - 2020-09-12 19:15:58 --> Output Class Initialized
INFO - 2020-09-12 19:15:58 --> Security Class Initialized
DEBUG - 2020-09-12 19:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:15:58 --> Input Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Loader Class Initialized
INFO - 2020-09-12 19:15:58 --> Helper loaded: url_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: form_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: file_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:15:58 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:15:58 --> Upload Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:15:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:15:58 --> Utf8 Class Initialized
INFO - 2020-09-12 19:15:58 --> URI Class Initialized
INFO - 2020-09-12 19:15:58 --> Router Class Initialized
INFO - 2020-09-12 19:15:58 --> Output Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Hooks Class Initialized
INFO - 2020-09-12 19:15:58 --> Security Class Initialized
DEBUG - 2020-09-12 19:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:15:58 --> Input Class Initialized
DEBUG - 2020-09-12 19:15:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:15:58 --> Utf8 Class Initialized
INFO - 2020-09-12 19:15:58 --> URI Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Router Class Initialized
INFO - 2020-09-12 19:15:58 --> Output Class Initialized
INFO - 2020-09-12 19:15:58 --> Security Class Initialized
DEBUG - 2020-09-12 19:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:15:58 --> Input Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Loader Class Initialized
INFO - 2020-09-12 19:15:58 --> Language Class Initialized
INFO - 2020-09-12 19:15:58 --> Config Class Initialized
INFO - 2020-09-12 19:15:58 --> Helper loaded: url_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: form_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: file_helper
INFO - 2020-09-12 19:15:58 --> Loader Class Initialized
INFO - 2020-09-12 19:15:58 --> Helper loaded: url_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: form_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: file_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:15:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:15:58 --> Database Driver Class Initialized
INFO - 2020-09-12 19:15:58 --> Database Driver Class Initialized
INFO - 2020-09-12 19:15:58 --> Controller Class Initialized
ERROR - 2020-09-12 19:15:58 --> 404 Page Not Found: /index
DEBUG - 2020-09-12 19:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:15:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-12 19:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:15:58 --> Upload Class Initialized
INFO - 2020-09-12 19:15:58 --> Controller Class Initialized
ERROR - 2020-09-12 19:15:58 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:15:58 --> Upload Class Initialized
INFO - 2020-09-12 19:15:58 --> Controller Class Initialized
ERROR - 2020-09-12 19:15:58 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:01 --> Config Class Initialized
INFO - 2020-09-12 19:16:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:01 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:01 --> URI Class Initialized
INFO - 2020-09-12 19:16:01 --> Router Class Initialized
INFO - 2020-09-12 19:16:01 --> Output Class Initialized
INFO - 2020-09-12 19:16:01 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:01 --> Input Class Initialized
INFO - 2020-09-12 19:16:01 --> Language Class Initialized
INFO - 2020-09-12 19:16:01 --> Language Class Initialized
INFO - 2020-09-12 19:16:01 --> Config Class Initialized
INFO - 2020-09-12 19:16:01 --> Loader Class Initialized
INFO - 2020-09-12 19:16:01 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:01 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:01 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:01 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:01 --> Upload Class Initialized
INFO - 2020-09-12 19:16:01 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:01 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:03 --> Config Class Initialized
INFO - 2020-09-12 19:16:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:03 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:03 --> URI Class Initialized
DEBUG - 2020-09-12 19:16:03 --> No URI present. Default controller set.
INFO - 2020-09-12 19:16:03 --> Router Class Initialized
INFO - 2020-09-12 19:16:03 --> Output Class Initialized
INFO - 2020-09-12 19:16:03 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:03 --> Input Class Initialized
INFO - 2020-09-12 19:16:03 --> Language Class Initialized
INFO - 2020-09-12 19:16:03 --> Language Class Initialized
INFO - 2020-09-12 19:16:03 --> Config Class Initialized
INFO - 2020-09-12 19:16:03 --> Loader Class Initialized
INFO - 2020-09-12 19:16:03 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:03 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:03 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:03 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:03 --> Upload Class Initialized
INFO - 2020-09-12 19:16:03 --> Controller Class Initialized
DEBUG - 2020-09-12 19:16:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 19:16:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 19:16:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 19:16:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 19:16:03 --> Final output sent to browser
DEBUG - 2020-09-12 19:16:03 --> Total execution time: 0.0376
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:09 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:09 --> URI Class Initialized
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Hooks Class Initialized
INFO - 2020-09-12 19:16:09 --> Router Class Initialized
DEBUG - 2020-09-12 19:16:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:09 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:09 --> Output Class Initialized
INFO - 2020-09-12 19:16:09 --> URI Class Initialized
INFO - 2020-09-12 19:16:09 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:09 --> Input Class Initialized
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Router Class Initialized
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Output Class Initialized
INFO - 2020-09-12 19:16:09 --> Loader Class Initialized
INFO - 2020-09-12 19:16:09 --> Security Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: url_helper
DEBUG - 2020-09-12 19:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:09 --> Input Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:09 --> Loader Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:09 --> Database Driver Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: file_helper
DEBUG - 2020-09-12 19:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:09 --> Upload Class Initialized
INFO - 2020-09-12 19:16:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:09 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:09 --> Upload Class Initialized
INFO - 2020-09-12 19:16:09 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:09 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:09 --> URI Class Initialized
INFO - 2020-09-12 19:16:09 --> Router Class Initialized
INFO - 2020-09-12 19:16:09 --> Output Class Initialized
INFO - 2020-09-12 19:16:09 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:09 --> Input Class Initialized
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Loader Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:09 --> Upload Class Initialized
INFO - 2020-09-12 19:16:09 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:09 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:09 --> URI Class Initialized
INFO - 2020-09-12 19:16:09 --> Router Class Initialized
INFO - 2020-09-12 19:16:09 --> Output Class Initialized
INFO - 2020-09-12 19:16:09 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:09 --> Input Class Initialized
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Language Class Initialized
INFO - 2020-09-12 19:16:09 --> Config Class Initialized
INFO - 2020-09-12 19:16:09 --> Loader Class Initialized
INFO - 2020-09-12 19:16:09 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:09 --> Upload Class Initialized
INFO - 2020-09-12 19:16:09 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:11 --> Config Class Initialized
INFO - 2020-09-12 19:16:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:11 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:11 --> URI Class Initialized
INFO - 2020-09-12 19:16:11 --> Router Class Initialized
INFO - 2020-09-12 19:16:11 --> Output Class Initialized
INFO - 2020-09-12 19:16:11 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:11 --> Input Class Initialized
INFO - 2020-09-12 19:16:11 --> Language Class Initialized
INFO - 2020-09-12 19:16:11 --> Language Class Initialized
INFO - 2020-09-12 19:16:11 --> Config Class Initialized
INFO - 2020-09-12 19:16:11 --> Loader Class Initialized
INFO - 2020-09-12 19:16:11 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:11 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:11 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:11 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:11 --> Upload Class Initialized
INFO - 2020-09-12 19:16:11 --> Controller Class Initialized
DEBUG - 2020-09-12 19:16:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 19:16:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-12 19:16:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 19:16:11 --> Final output sent to browser
DEBUG - 2020-09-12 19:16:11 --> Total execution time: 0.0707
INFO - 2020-09-12 19:16:12 --> Config Class Initialized
INFO - 2020-09-12 19:16:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:12 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:12 --> URI Class Initialized
INFO - 2020-09-12 19:16:12 --> Router Class Initialized
INFO - 2020-09-12 19:16:12 --> Output Class Initialized
INFO - 2020-09-12 19:16:12 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:12 --> Input Class Initialized
INFO - 2020-09-12 19:16:12 --> Language Class Initialized
INFO - 2020-09-12 19:16:12 --> Language Class Initialized
INFO - 2020-09-12 19:16:12 --> Config Class Initialized
INFO - 2020-09-12 19:16:12 --> Loader Class Initialized
INFO - 2020-09-12 19:16:12 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:12 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:12 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:12 --> Upload Class Initialized
INFO - 2020-09-12 19:16:12 --> Controller Class Initialized
DEBUG - 2020-09-12 19:16:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 19:16:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-12 19:16:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 19:16:12 --> Final output sent to browser
DEBUG - 2020-09-12 19:16:12 --> Total execution time: 0.0500
INFO - 2020-09-12 19:16:12 --> Config Class Initialized
INFO - 2020-09-12 19:16:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:12 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:12 --> URI Class Initialized
INFO - 2020-09-12 19:16:12 --> Router Class Initialized
INFO - 2020-09-12 19:16:12 --> Output Class Initialized
INFO - 2020-09-12 19:16:12 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:12 --> Input Class Initialized
INFO - 2020-09-12 19:16:12 --> Language Class Initialized
INFO - 2020-09-12 19:16:12 --> Language Class Initialized
INFO - 2020-09-12 19:16:12 --> Config Class Initialized
INFO - 2020-09-12 19:16:12 --> Loader Class Initialized
INFO - 2020-09-12 19:16:12 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:12 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:12 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:12 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:12 --> Upload Class Initialized
INFO - 2020-09-12 19:16:12 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:12 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:13 --> Config Class Initialized
INFO - 2020-09-12 19:16:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:13 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:13 --> URI Class Initialized
INFO - 2020-09-12 19:16:13 --> Router Class Initialized
INFO - 2020-09-12 19:16:13 --> Output Class Initialized
INFO - 2020-09-12 19:16:13 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:13 --> Input Class Initialized
INFO - 2020-09-12 19:16:13 --> Language Class Initialized
INFO - 2020-09-12 19:16:13 --> Language Class Initialized
INFO - 2020-09-12 19:16:13 --> Config Class Initialized
INFO - 2020-09-12 19:16:13 --> Loader Class Initialized
INFO - 2020-09-12 19:16:13 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:13 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:13 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:13 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:13 --> Upload Class Initialized
INFO - 2020-09-12 19:16:13 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:13 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:13 --> Config Class Initialized
INFO - 2020-09-12 19:16:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:13 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:13 --> URI Class Initialized
INFO - 2020-09-12 19:16:13 --> Router Class Initialized
INFO - 2020-09-12 19:16:13 --> Output Class Initialized
INFO - 2020-09-12 19:16:13 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:13 --> Input Class Initialized
INFO - 2020-09-12 19:16:13 --> Language Class Initialized
INFO - 2020-09-12 19:16:13 --> Language Class Initialized
INFO - 2020-09-12 19:16:13 --> Config Class Initialized
INFO - 2020-09-12 19:16:13 --> Loader Class Initialized
INFO - 2020-09-12 19:16:13 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:13 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:13 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:13 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:13 --> Upload Class Initialized
INFO - 2020-09-12 19:16:13 --> Controller Class Initialized
ERROR - 2020-09-12 19:16:13 --> 404 Page Not Found: /index
INFO - 2020-09-12 19:16:15 --> Config Class Initialized
INFO - 2020-09-12 19:16:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 19:16:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 19:16:15 --> Utf8 Class Initialized
INFO - 2020-09-12 19:16:15 --> URI Class Initialized
INFO - 2020-09-12 19:16:15 --> Router Class Initialized
INFO - 2020-09-12 19:16:15 --> Output Class Initialized
INFO - 2020-09-12 19:16:15 --> Security Class Initialized
DEBUG - 2020-09-12 19:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 19:16:15 --> Input Class Initialized
INFO - 2020-09-12 19:16:15 --> Language Class Initialized
INFO - 2020-09-12 19:16:15 --> Language Class Initialized
INFO - 2020-09-12 19:16:15 --> Config Class Initialized
INFO - 2020-09-12 19:16:15 --> Loader Class Initialized
INFO - 2020-09-12 19:16:15 --> Helper loaded: url_helper
INFO - 2020-09-12 19:16:15 --> Helper loaded: form_helper
INFO - 2020-09-12 19:16:15 --> Helper loaded: file_helper
INFO - 2020-09-12 19:16:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 19:16:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 19:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 19:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 19:16:15 --> Upload Class Initialized
INFO - 2020-09-12 19:16:15 --> Controller Class Initialized
DEBUG - 2020-09-12 19:16:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 19:16:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-12 19:16:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 19:16:15 --> Final output sent to browser
DEBUG - 2020-09-12 19:16:15 --> Total execution time: 0.0337
INFO - 2020-09-12 20:56:52 --> Config Class Initialized
INFO - 2020-09-12 20:56:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 20:56:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 20:56:52 --> Utf8 Class Initialized
INFO - 2020-09-12 20:56:52 --> URI Class Initialized
DEBUG - 2020-09-12 20:56:52 --> No URI present. Default controller set.
INFO - 2020-09-12 20:56:52 --> Router Class Initialized
INFO - 2020-09-12 20:56:52 --> Output Class Initialized
INFO - 2020-09-12 20:56:52 --> Security Class Initialized
DEBUG - 2020-09-12 20:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 20:56:52 --> Input Class Initialized
INFO - 2020-09-12 20:56:52 --> Language Class Initialized
INFO - 2020-09-12 20:56:52 --> Language Class Initialized
INFO - 2020-09-12 20:56:52 --> Config Class Initialized
INFO - 2020-09-12 20:56:52 --> Loader Class Initialized
INFO - 2020-09-12 20:56:52 --> Helper loaded: url_helper
INFO - 2020-09-12 20:56:52 --> Helper loaded: form_helper
INFO - 2020-09-12 20:56:52 --> Helper loaded: file_helper
INFO - 2020-09-12 20:56:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 20:56:52 --> Database Driver Class Initialized
DEBUG - 2020-09-12 20:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 20:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 20:56:52 --> Upload Class Initialized
INFO - 2020-09-12 20:56:52 --> Controller Class Initialized
DEBUG - 2020-09-12 20:56:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 20:56:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 20:56:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 20:56:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 20:56:52 --> Final output sent to browser
DEBUG - 2020-09-12 20:56:52 --> Total execution time: 0.0638
INFO - 2020-09-12 20:57:15 --> Config Class Initialized
INFO - 2020-09-12 20:57:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 20:57:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 20:57:15 --> Utf8 Class Initialized
INFO - 2020-09-12 20:57:15 --> URI Class Initialized
INFO - 2020-09-12 20:57:15 --> Router Class Initialized
INFO - 2020-09-12 20:57:15 --> Output Class Initialized
INFO - 2020-09-12 20:57:15 --> Security Class Initialized
DEBUG - 2020-09-12 20:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 20:57:15 --> Input Class Initialized
INFO - 2020-09-12 20:57:15 --> Language Class Initialized
INFO - 2020-09-12 20:57:15 --> Language Class Initialized
INFO - 2020-09-12 20:57:15 --> Config Class Initialized
INFO - 2020-09-12 20:57:15 --> Loader Class Initialized
INFO - 2020-09-12 20:57:15 --> Helper loaded: url_helper
INFO - 2020-09-12 20:57:15 --> Helper loaded: form_helper
INFO - 2020-09-12 20:57:15 --> Helper loaded: file_helper
INFO - 2020-09-12 20:57:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 20:57:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 20:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 20:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 20:57:15 --> Upload Class Initialized
INFO - 2020-09-12 20:57:15 --> Controller Class Initialized
ERROR - 2020-09-12 20:57:15 --> 404 Page Not Found: /index
INFO - 2020-09-12 20:57:18 --> Config Class Initialized
INFO - 2020-09-12 20:57:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 20:57:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 20:57:18 --> Utf8 Class Initialized
INFO - 2020-09-12 20:57:18 --> URI Class Initialized
INFO - 2020-09-12 20:57:18 --> Router Class Initialized
INFO - 2020-09-12 20:57:18 --> Output Class Initialized
INFO - 2020-09-12 20:57:18 --> Security Class Initialized
DEBUG - 2020-09-12 20:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 20:57:18 --> Input Class Initialized
INFO - 2020-09-12 20:57:18 --> Language Class Initialized
INFO - 2020-09-12 20:57:18 --> Language Class Initialized
INFO - 2020-09-12 20:57:18 --> Config Class Initialized
INFO - 2020-09-12 20:57:18 --> Loader Class Initialized
INFO - 2020-09-12 20:57:18 --> Helper loaded: url_helper
INFO - 2020-09-12 20:57:18 --> Helper loaded: form_helper
INFO - 2020-09-12 20:57:18 --> Helper loaded: file_helper
INFO - 2020-09-12 20:57:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 20:57:18 --> Database Driver Class Initialized
DEBUG - 2020-09-12 20:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 20:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 20:57:18 --> Upload Class Initialized
INFO - 2020-09-12 20:57:18 --> Controller Class Initialized
ERROR - 2020-09-12 20:57:18 --> 404 Page Not Found: /index
INFO - 2020-09-12 20:57:22 --> Config Class Initialized
INFO - 2020-09-12 20:57:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 20:57:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 20:57:22 --> Utf8 Class Initialized
INFO - 2020-09-12 20:57:22 --> URI Class Initialized
INFO - 2020-09-12 20:57:22 --> Router Class Initialized
INFO - 2020-09-12 20:57:22 --> Output Class Initialized
INFO - 2020-09-12 20:57:22 --> Security Class Initialized
DEBUG - 2020-09-12 20:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 20:57:22 --> Input Class Initialized
INFO - 2020-09-12 20:57:22 --> Language Class Initialized
INFO - 2020-09-12 20:57:22 --> Language Class Initialized
INFO - 2020-09-12 20:57:22 --> Config Class Initialized
INFO - 2020-09-12 20:57:22 --> Loader Class Initialized
INFO - 2020-09-12 20:57:22 --> Helper loaded: url_helper
INFO - 2020-09-12 20:57:22 --> Helper loaded: form_helper
INFO - 2020-09-12 20:57:22 --> Helper loaded: file_helper
INFO - 2020-09-12 20:57:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 20:57:22 --> Database Driver Class Initialized
DEBUG - 2020-09-12 20:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 20:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 20:57:22 --> Upload Class Initialized
INFO - 2020-09-12 20:57:22 --> Controller Class Initialized
ERROR - 2020-09-12 20:57:22 --> 404 Page Not Found: /index
INFO - 2020-09-12 20:57:51 --> Config Class Initialized
INFO - 2020-09-12 20:57:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 20:57:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 20:57:51 --> Utf8 Class Initialized
INFO - 2020-09-12 20:57:51 --> URI Class Initialized
INFO - 2020-09-12 20:57:51 --> Router Class Initialized
INFO - 2020-09-12 20:57:51 --> Output Class Initialized
INFO - 2020-09-12 20:57:51 --> Security Class Initialized
DEBUG - 2020-09-12 20:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 20:57:51 --> Input Class Initialized
INFO - 2020-09-12 20:57:51 --> Language Class Initialized
INFO - 2020-09-12 20:57:51 --> Language Class Initialized
INFO - 2020-09-12 20:57:51 --> Config Class Initialized
INFO - 2020-09-12 20:57:51 --> Loader Class Initialized
INFO - 2020-09-12 20:57:51 --> Helper loaded: url_helper
INFO - 2020-09-12 20:57:51 --> Helper loaded: form_helper
INFO - 2020-09-12 20:57:51 --> Helper loaded: file_helper
INFO - 2020-09-12 20:57:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 20:57:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 20:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 20:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 20:57:51 --> Upload Class Initialized
INFO - 2020-09-12 20:57:51 --> Controller Class Initialized
ERROR - 2020-09-12 20:57:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:07 --> Config Class Initialized
INFO - 2020-09-12 21:04:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:07 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:07 --> URI Class Initialized
DEBUG - 2020-09-12 21:04:07 --> No URI present. Default controller set.
INFO - 2020-09-12 21:04:07 --> Router Class Initialized
INFO - 2020-09-12 21:04:07 --> Output Class Initialized
INFO - 2020-09-12 21:04:07 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:07 --> Input Class Initialized
INFO - 2020-09-12 21:04:07 --> Language Class Initialized
INFO - 2020-09-12 21:04:07 --> Language Class Initialized
INFO - 2020-09-12 21:04:07 --> Config Class Initialized
INFO - 2020-09-12 21:04:07 --> Loader Class Initialized
INFO - 2020-09-12 21:04:07 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:07 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:07 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:07 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:07 --> Upload Class Initialized
INFO - 2020-09-12 21:04:07 --> Controller Class Initialized
DEBUG - 2020-09-12 21:04:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:04:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 21:04:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 21:04:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:04:07 --> Final output sent to browser
DEBUG - 2020-09-12 21:04:07 --> Total execution time: 0.0496
INFO - 2020-09-12 21:04:08 --> Config Class Initialized
INFO - 2020-09-12 21:04:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:08 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:08 --> URI Class Initialized
INFO - 2020-09-12 21:04:08 --> Router Class Initialized
INFO - 2020-09-12 21:04:08 --> Output Class Initialized
INFO - 2020-09-12 21:04:08 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:08 --> Input Class Initialized
INFO - 2020-09-12 21:04:08 --> Language Class Initialized
INFO - 2020-09-12 21:04:08 --> Language Class Initialized
INFO - 2020-09-12 21:04:08 --> Config Class Initialized
INFO - 2020-09-12 21:04:08 --> Loader Class Initialized
INFO - 2020-09-12 21:04:08 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:08 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:08 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:08 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:08 --> Upload Class Initialized
INFO - 2020-09-12 21:04:08 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:08 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:08 --> Config Class Initialized
INFO - 2020-09-12 21:04:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:08 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:08 --> URI Class Initialized
INFO - 2020-09-12 21:04:08 --> Router Class Initialized
INFO - 2020-09-12 21:04:08 --> Output Class Initialized
INFO - 2020-09-12 21:04:08 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:08 --> Input Class Initialized
INFO - 2020-09-12 21:04:08 --> Language Class Initialized
INFO - 2020-09-12 21:04:08 --> Language Class Initialized
INFO - 2020-09-12 21:04:08 --> Config Class Initialized
INFO - 2020-09-12 21:04:08 --> Loader Class Initialized
INFO - 2020-09-12 21:04:08 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:08 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:08 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:08 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:08 --> Upload Class Initialized
INFO - 2020-09-12 21:04:09 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:09 --> Config Class Initialized
INFO - 2020-09-12 21:04:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:09 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:09 --> URI Class Initialized
INFO - 2020-09-12 21:04:09 --> Router Class Initialized
INFO - 2020-09-12 21:04:09 --> Output Class Initialized
INFO - 2020-09-12 21:04:09 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:09 --> Input Class Initialized
INFO - 2020-09-12 21:04:09 --> Language Class Initialized
INFO - 2020-09-12 21:04:09 --> Language Class Initialized
INFO - 2020-09-12 21:04:09 --> Config Class Initialized
INFO - 2020-09-12 21:04:09 --> Loader Class Initialized
INFO - 2020-09-12 21:04:09 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:09 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:09 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:09 --> Upload Class Initialized
INFO - 2020-09-12 21:04:09 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:09 --> Config Class Initialized
INFO - 2020-09-12 21:04:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:09 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:09 --> URI Class Initialized
INFO - 2020-09-12 21:04:09 --> Router Class Initialized
INFO - 2020-09-12 21:04:09 --> Output Class Initialized
INFO - 2020-09-12 21:04:09 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:09 --> Input Class Initialized
INFO - 2020-09-12 21:04:09 --> Language Class Initialized
INFO - 2020-09-12 21:04:09 --> Language Class Initialized
INFO - 2020-09-12 21:04:09 --> Config Class Initialized
INFO - 2020-09-12 21:04:09 --> Loader Class Initialized
INFO - 2020-09-12 21:04:09 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:09 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:09 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:09 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:09 --> Upload Class Initialized
INFO - 2020-09-12 21:04:09 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:09 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:09 --> Config Class Initialized
INFO - 2020-09-12 21:04:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:10 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:10 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:10 --> URI Class Initialized
INFO - 2020-09-12 21:04:10 --> Router Class Initialized
INFO - 2020-09-12 21:04:10 --> Output Class Initialized
INFO - 2020-09-12 21:04:10 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:10 --> Input Class Initialized
INFO - 2020-09-12 21:04:10 --> Language Class Initialized
INFO - 2020-09-12 21:04:10 --> Language Class Initialized
INFO - 2020-09-12 21:04:10 --> Config Class Initialized
INFO - 2020-09-12 21:04:10 --> Loader Class Initialized
INFO - 2020-09-12 21:04:10 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:10 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:10 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:10 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:10 --> Upload Class Initialized
INFO - 2020-09-12 21:04:10 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:10 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:20 --> Config Class Initialized
INFO - 2020-09-12 21:04:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:20 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:20 --> URI Class Initialized
INFO - 2020-09-12 21:04:20 --> Router Class Initialized
INFO - 2020-09-12 21:04:20 --> Output Class Initialized
INFO - 2020-09-12 21:04:20 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:20 --> Input Class Initialized
INFO - 2020-09-12 21:04:20 --> Language Class Initialized
INFO - 2020-09-12 21:04:20 --> Language Class Initialized
INFO - 2020-09-12 21:04:20 --> Config Class Initialized
INFO - 2020-09-12 21:04:20 --> Loader Class Initialized
INFO - 2020-09-12 21:04:20 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:20 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:20 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:20 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:20 --> Upload Class Initialized
INFO - 2020-09-12 21:04:20 --> Controller Class Initialized
DEBUG - 2020-09-12 21:04:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:04:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-12 21:04:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:04:20 --> Final output sent to browser
DEBUG - 2020-09-12 21:04:20 --> Total execution time: 0.0476
INFO - 2020-09-12 21:04:21 --> Config Class Initialized
INFO - 2020-09-12 21:04:21 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:21 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:21 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:21 --> URI Class Initialized
INFO - 2020-09-12 21:04:21 --> Router Class Initialized
INFO - 2020-09-12 21:04:21 --> Output Class Initialized
INFO - 2020-09-12 21:04:21 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:21 --> Input Class Initialized
INFO - 2020-09-12 21:04:21 --> Language Class Initialized
INFO - 2020-09-12 21:04:21 --> Language Class Initialized
INFO - 2020-09-12 21:04:21 --> Config Class Initialized
INFO - 2020-09-12 21:04:21 --> Loader Class Initialized
INFO - 2020-09-12 21:04:21 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:21 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:21 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:21 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:21 --> Upload Class Initialized
INFO - 2020-09-12 21:04:21 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:21 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:04:23 --> Config Class Initialized
INFO - 2020-09-12 21:04:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:23 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:23 --> URI Class Initialized
INFO - 2020-09-12 21:04:23 --> Router Class Initialized
INFO - 2020-09-12 21:04:23 --> Output Class Initialized
INFO - 2020-09-12 21:04:23 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:23 --> Input Class Initialized
INFO - 2020-09-12 21:04:23 --> Language Class Initialized
INFO - 2020-09-12 21:04:23 --> Language Class Initialized
INFO - 2020-09-12 21:04:23 --> Config Class Initialized
INFO - 2020-09-12 21:04:23 --> Loader Class Initialized
INFO - 2020-09-12 21:04:23 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:23 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:23 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:23 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:23 --> Upload Class Initialized
INFO - 2020-09-12 21:04:23 --> Controller Class Initialized
DEBUG - 2020-09-12 21:04:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:04:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-12 21:04:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:04:23 --> Final output sent to browser
DEBUG - 2020-09-12 21:04:23 --> Total execution time: 0.0628
INFO - 2020-09-12 21:04:26 --> Config Class Initialized
INFO - 2020-09-12 21:04:26 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:04:26 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:04:26 --> Utf8 Class Initialized
INFO - 2020-09-12 21:04:26 --> URI Class Initialized
INFO - 2020-09-12 21:04:26 --> Router Class Initialized
INFO - 2020-09-12 21:04:26 --> Output Class Initialized
INFO - 2020-09-12 21:04:26 --> Security Class Initialized
DEBUG - 2020-09-12 21:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:04:26 --> Input Class Initialized
INFO - 2020-09-12 21:04:26 --> Language Class Initialized
INFO - 2020-09-12 21:04:26 --> Language Class Initialized
INFO - 2020-09-12 21:04:26 --> Config Class Initialized
INFO - 2020-09-12 21:04:26 --> Loader Class Initialized
INFO - 2020-09-12 21:04:26 --> Helper loaded: url_helper
INFO - 2020-09-12 21:04:26 --> Helper loaded: form_helper
INFO - 2020-09-12 21:04:26 --> Helper loaded: file_helper
INFO - 2020-09-12 21:04:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:04:26 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:04:26 --> Upload Class Initialized
INFO - 2020-09-12 21:04:26 --> Controller Class Initialized
ERROR - 2020-09-12 21:04:26 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:02 --> Config Class Initialized
INFO - 2020-09-12 21:05:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:02 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:02 --> URI Class Initialized
INFO - 2020-09-12 21:05:02 --> Router Class Initialized
INFO - 2020-09-12 21:05:02 --> Output Class Initialized
INFO - 2020-09-12 21:05:02 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:02 --> Input Class Initialized
INFO - 2020-09-12 21:05:02 --> Language Class Initialized
INFO - 2020-09-12 21:05:02 --> Language Class Initialized
INFO - 2020-09-12 21:05:02 --> Config Class Initialized
INFO - 2020-09-12 21:05:02 --> Loader Class Initialized
INFO - 2020-09-12 21:05:02 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:02 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:02 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:02 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:02 --> Upload Class Initialized
INFO - 2020-09-12 21:05:02 --> Controller Class Initialized
DEBUG - 2020-09-12 21:05:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:05:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/legality.php
DEBUG - 2020-09-12 21:05:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:05:02 --> Final output sent to browser
DEBUG - 2020-09-12 21:05:02 --> Total execution time: 0.0489
INFO - 2020-09-12 21:05:03 --> Config Class Initialized
INFO - 2020-09-12 21:05:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:03 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:03 --> URI Class Initialized
INFO - 2020-09-12 21:05:03 --> Router Class Initialized
INFO - 2020-09-12 21:05:03 --> Output Class Initialized
INFO - 2020-09-12 21:05:03 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:03 --> Input Class Initialized
INFO - 2020-09-12 21:05:03 --> Language Class Initialized
INFO - 2020-09-12 21:05:03 --> Language Class Initialized
INFO - 2020-09-12 21:05:03 --> Config Class Initialized
INFO - 2020-09-12 21:05:03 --> Loader Class Initialized
INFO - 2020-09-12 21:05:03 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:03 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:03 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:03 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:03 --> Upload Class Initialized
INFO - 2020-09-12 21:05:03 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:03 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:15 --> Config Class Initialized
INFO - 2020-09-12 21:05:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:15 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:15 --> URI Class Initialized
INFO - 2020-09-12 21:05:15 --> Router Class Initialized
INFO - 2020-09-12 21:05:15 --> Output Class Initialized
INFO - 2020-09-12 21:05:15 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:15 --> Input Class Initialized
INFO - 2020-09-12 21:05:15 --> Language Class Initialized
INFO - 2020-09-12 21:05:15 --> Language Class Initialized
INFO - 2020-09-12 21:05:15 --> Config Class Initialized
INFO - 2020-09-12 21:05:15 --> Loader Class Initialized
INFO - 2020-09-12 21:05:15 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:15 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:15 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:15 --> Upload Class Initialized
INFO - 2020-09-12 21:05:15 --> Controller Class Initialized
DEBUG - 2020-09-12 21:05:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:05:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/withdraw_cash.php
DEBUG - 2020-09-12 21:05:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:05:15 --> Final output sent to browser
DEBUG - 2020-09-12 21:05:15 --> Total execution time: 0.0620
INFO - 2020-09-12 21:05:15 --> Config Class Initialized
INFO - 2020-09-12 21:05:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:15 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:15 --> URI Class Initialized
INFO - 2020-09-12 21:05:15 --> Router Class Initialized
INFO - 2020-09-12 21:05:15 --> Output Class Initialized
INFO - 2020-09-12 21:05:15 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:15 --> Input Class Initialized
INFO - 2020-09-12 21:05:15 --> Language Class Initialized
INFO - 2020-09-12 21:05:15 --> Language Class Initialized
INFO - 2020-09-12 21:05:15 --> Config Class Initialized
INFO - 2020-09-12 21:05:15 --> Loader Class Initialized
INFO - 2020-09-12 21:05:15 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:15 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:15 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:15 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:15 --> Upload Class Initialized
INFO - 2020-09-12 21:05:15 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:15 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:36 --> Config Class Initialized
INFO - 2020-09-12 21:05:36 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:36 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:36 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:36 --> URI Class Initialized
DEBUG - 2020-09-12 21:05:36 --> No URI present. Default controller set.
INFO - 2020-09-12 21:05:36 --> Router Class Initialized
INFO - 2020-09-12 21:05:36 --> Output Class Initialized
INFO - 2020-09-12 21:05:36 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:36 --> Input Class Initialized
INFO - 2020-09-12 21:05:36 --> Language Class Initialized
INFO - 2020-09-12 21:05:36 --> Language Class Initialized
INFO - 2020-09-12 21:05:36 --> Config Class Initialized
INFO - 2020-09-12 21:05:36 --> Loader Class Initialized
INFO - 2020-09-12 21:05:36 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:36 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:36 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:36 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:36 --> Upload Class Initialized
INFO - 2020-09-12 21:05:36 --> Controller Class Initialized
DEBUG - 2020-09-12 21:05:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:05:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 21:05:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 21:05:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:05:36 --> Final output sent to browser
DEBUG - 2020-09-12 21:05:36 --> Total execution time: 0.0508
INFO - 2020-09-12 21:05:36 --> Config Class Initialized
INFO - 2020-09-12 21:05:36 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:36 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:36 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:36 --> URI Class Initialized
INFO - 2020-09-12 21:05:36 --> Router Class Initialized
INFO - 2020-09-12 21:05:36 --> Output Class Initialized
INFO - 2020-09-12 21:05:36 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:36 --> Input Class Initialized
INFO - 2020-09-12 21:05:36 --> Language Class Initialized
INFO - 2020-09-12 21:05:36 --> Language Class Initialized
INFO - 2020-09-12 21:05:36 --> Config Class Initialized
INFO - 2020-09-12 21:05:36 --> Loader Class Initialized
INFO - 2020-09-12 21:05:36 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:36 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:36 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:36 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:36 --> Upload Class Initialized
INFO - 2020-09-12 21:05:37 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:37 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:37 --> Config Class Initialized
INFO - 2020-09-12 21:05:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:37 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:37 --> URI Class Initialized
INFO - 2020-09-12 21:05:37 --> Router Class Initialized
INFO - 2020-09-12 21:05:37 --> Output Class Initialized
INFO - 2020-09-12 21:05:37 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:37 --> Input Class Initialized
INFO - 2020-09-12 21:05:37 --> Language Class Initialized
INFO - 2020-09-12 21:05:37 --> Language Class Initialized
INFO - 2020-09-12 21:05:37 --> Config Class Initialized
INFO - 2020-09-12 21:05:37 --> Loader Class Initialized
INFO - 2020-09-12 21:05:37 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:37 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:37 --> Upload Class Initialized
INFO - 2020-09-12 21:05:37 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:37 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:37 --> Config Class Initialized
INFO - 2020-09-12 21:05:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:37 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:37 --> URI Class Initialized
INFO - 2020-09-12 21:05:37 --> Router Class Initialized
INFO - 2020-09-12 21:05:37 --> Output Class Initialized
INFO - 2020-09-12 21:05:37 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:37 --> Input Class Initialized
INFO - 2020-09-12 21:05:37 --> Language Class Initialized
INFO - 2020-09-12 21:05:37 --> Language Class Initialized
INFO - 2020-09-12 21:05:37 --> Config Class Initialized
INFO - 2020-09-12 21:05:37 --> Loader Class Initialized
INFO - 2020-09-12 21:05:37 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:37 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:37 --> Upload Class Initialized
INFO - 2020-09-12 21:05:37 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:37 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:37 --> Config Class Initialized
INFO - 2020-09-12 21:05:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:37 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:37 --> URI Class Initialized
INFO - 2020-09-12 21:05:37 --> Router Class Initialized
INFO - 2020-09-12 21:05:37 --> Output Class Initialized
INFO - 2020-09-12 21:05:37 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:37 --> Input Class Initialized
INFO - 2020-09-12 21:05:37 --> Language Class Initialized
INFO - 2020-09-12 21:05:37 --> Language Class Initialized
INFO - 2020-09-12 21:05:37 --> Config Class Initialized
INFO - 2020-09-12 21:05:37 --> Loader Class Initialized
INFO - 2020-09-12 21:05:37 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:37 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:37 --> Upload Class Initialized
INFO - 2020-09-12 21:05:38 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:38 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:05:38 --> Config Class Initialized
INFO - 2020-09-12 21:05:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:05:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:05:38 --> Utf8 Class Initialized
INFO - 2020-09-12 21:05:38 --> URI Class Initialized
INFO - 2020-09-12 21:05:38 --> Router Class Initialized
INFO - 2020-09-12 21:05:38 --> Output Class Initialized
INFO - 2020-09-12 21:05:38 --> Security Class Initialized
DEBUG - 2020-09-12 21:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:05:38 --> Input Class Initialized
INFO - 2020-09-12 21:05:38 --> Language Class Initialized
INFO - 2020-09-12 21:05:38 --> Language Class Initialized
INFO - 2020-09-12 21:05:38 --> Config Class Initialized
INFO - 2020-09-12 21:05:38 --> Loader Class Initialized
INFO - 2020-09-12 21:05:38 --> Helper loaded: url_helper
INFO - 2020-09-12 21:05:38 --> Helper loaded: form_helper
INFO - 2020-09-12 21:05:38 --> Helper loaded: file_helper
INFO - 2020-09-12 21:05:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:05:38 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:05:38 --> Upload Class Initialized
INFO - 2020-09-12 21:05:38 --> Controller Class Initialized
ERROR - 2020-09-12 21:05:38 --> 404 Page Not Found: /index
INFO - 2020-09-12 21:33:42 --> Config Class Initialized
INFO - 2020-09-12 21:33:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 21:33:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 21:33:42 --> Utf8 Class Initialized
INFO - 2020-09-12 21:33:42 --> URI Class Initialized
DEBUG - 2020-09-12 21:33:42 --> No URI present. Default controller set.
INFO - 2020-09-12 21:33:42 --> Router Class Initialized
INFO - 2020-09-12 21:33:42 --> Output Class Initialized
INFO - 2020-09-12 21:33:42 --> Security Class Initialized
DEBUG - 2020-09-12 21:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 21:33:42 --> Input Class Initialized
INFO - 2020-09-12 21:33:42 --> Language Class Initialized
INFO - 2020-09-12 21:33:42 --> Language Class Initialized
INFO - 2020-09-12 21:33:42 --> Config Class Initialized
INFO - 2020-09-12 21:33:42 --> Loader Class Initialized
INFO - 2020-09-12 21:33:42 --> Helper loaded: url_helper
INFO - 2020-09-12 21:33:42 --> Helper loaded: form_helper
INFO - 2020-09-12 21:33:42 --> Helper loaded: file_helper
INFO - 2020-09-12 21:33:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 21:33:42 --> Database Driver Class Initialized
DEBUG - 2020-09-12 21:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 21:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 21:33:42 --> Upload Class Initialized
INFO - 2020-09-12 21:33:42 --> Controller Class Initialized
DEBUG - 2020-09-12 21:33:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 21:33:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 21:33:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 21:33:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 21:33:42 --> Final output sent to browser
DEBUG - 2020-09-12 21:33:42 --> Total execution time: 0.0465
INFO - 2020-09-12 22:11:49 --> Config Class Initialized
INFO - 2020-09-12 22:11:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:11:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:11:49 --> Utf8 Class Initialized
INFO - 2020-09-12 22:11:49 --> URI Class Initialized
DEBUG - 2020-09-12 22:11:49 --> No URI present. Default controller set.
INFO - 2020-09-12 22:11:49 --> Router Class Initialized
INFO - 2020-09-12 22:11:49 --> Output Class Initialized
INFO - 2020-09-12 22:11:49 --> Security Class Initialized
DEBUG - 2020-09-12 22:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:11:49 --> Input Class Initialized
INFO - 2020-09-12 22:11:49 --> Language Class Initialized
INFO - 2020-09-12 22:11:49 --> Language Class Initialized
INFO - 2020-09-12 22:11:49 --> Config Class Initialized
INFO - 2020-09-12 22:11:49 --> Loader Class Initialized
INFO - 2020-09-12 22:11:49 --> Helper loaded: url_helper
INFO - 2020-09-12 22:11:49 --> Helper loaded: form_helper
INFO - 2020-09-12 22:11:49 --> Helper loaded: file_helper
INFO - 2020-09-12 22:11:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:11:49 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:11:49 --> Upload Class Initialized
INFO - 2020-09-12 22:11:49 --> Controller Class Initialized
DEBUG - 2020-09-12 22:11:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 22:11:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 22:11:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 22:11:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 22:11:49 --> Final output sent to browser
DEBUG - 2020-09-12 22:11:49 --> Total execution time: 0.0576
INFO - 2020-09-12 22:11:51 --> Config Class Initialized
INFO - 2020-09-12 22:11:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:11:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:11:51 --> Utf8 Class Initialized
INFO - 2020-09-12 22:11:51 --> URI Class Initialized
INFO - 2020-09-12 22:11:51 --> Router Class Initialized
INFO - 2020-09-12 22:11:51 --> Output Class Initialized
INFO - 2020-09-12 22:11:51 --> Security Class Initialized
DEBUG - 2020-09-12 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:11:51 --> Input Class Initialized
INFO - 2020-09-12 22:11:51 --> Language Class Initialized
INFO - 2020-09-12 22:11:51 --> Language Class Initialized
INFO - 2020-09-12 22:11:51 --> Config Class Initialized
INFO - 2020-09-12 22:11:51 --> Loader Class Initialized
INFO - 2020-09-12 22:11:51 --> Helper loaded: url_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: form_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: file_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:11:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:11:51 --> Upload Class Initialized
INFO - 2020-09-12 22:11:51 --> Controller Class Initialized
ERROR - 2020-09-12 22:11:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:11:51 --> Config Class Initialized
INFO - 2020-09-12 22:11:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:11:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:11:51 --> Utf8 Class Initialized
INFO - 2020-09-12 22:11:51 --> URI Class Initialized
INFO - 2020-09-12 22:11:51 --> Router Class Initialized
INFO - 2020-09-12 22:11:51 --> Output Class Initialized
INFO - 2020-09-12 22:11:51 --> Security Class Initialized
DEBUG - 2020-09-12 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:11:51 --> Input Class Initialized
INFO - 2020-09-12 22:11:51 --> Language Class Initialized
INFO - 2020-09-12 22:11:51 --> Language Class Initialized
INFO - 2020-09-12 22:11:51 --> Config Class Initialized
INFO - 2020-09-12 22:11:51 --> Loader Class Initialized
INFO - 2020-09-12 22:11:51 --> Helper loaded: url_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: form_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: file_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:11:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:11:51 --> Upload Class Initialized
INFO - 2020-09-12 22:11:51 --> Controller Class Initialized
ERROR - 2020-09-12 22:11:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:11:51 --> Config Class Initialized
INFO - 2020-09-12 22:11:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:11:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:11:51 --> Utf8 Class Initialized
INFO - 2020-09-12 22:11:51 --> URI Class Initialized
INFO - 2020-09-12 22:11:51 --> Router Class Initialized
INFO - 2020-09-12 22:11:51 --> Output Class Initialized
INFO - 2020-09-12 22:11:51 --> Security Class Initialized
DEBUG - 2020-09-12 22:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:11:51 --> Input Class Initialized
INFO - 2020-09-12 22:11:51 --> Language Class Initialized
INFO - 2020-09-12 22:11:51 --> Language Class Initialized
INFO - 2020-09-12 22:11:51 --> Config Class Initialized
INFO - 2020-09-12 22:11:51 --> Loader Class Initialized
INFO - 2020-09-12 22:11:51 --> Helper loaded: url_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: form_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: file_helper
INFO - 2020-09-12 22:11:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:11:51 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:11:51 --> Upload Class Initialized
INFO - 2020-09-12 22:11:51 --> Controller Class Initialized
ERROR - 2020-09-12 22:11:51 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:11:52 --> Config Class Initialized
INFO - 2020-09-12 22:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:11:52 --> Utf8 Class Initialized
INFO - 2020-09-12 22:11:52 --> URI Class Initialized
INFO - 2020-09-12 22:11:52 --> Router Class Initialized
INFO - 2020-09-12 22:11:52 --> Output Class Initialized
INFO - 2020-09-12 22:11:52 --> Security Class Initialized
DEBUG - 2020-09-12 22:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:11:52 --> Input Class Initialized
INFO - 2020-09-12 22:11:52 --> Language Class Initialized
INFO - 2020-09-12 22:11:52 --> Language Class Initialized
INFO - 2020-09-12 22:11:52 --> Config Class Initialized
INFO - 2020-09-12 22:11:52 --> Loader Class Initialized
INFO - 2020-09-12 22:11:52 --> Helper loaded: url_helper
INFO - 2020-09-12 22:11:52 --> Helper loaded: form_helper
INFO - 2020-09-12 22:11:52 --> Helper loaded: file_helper
INFO - 2020-09-12 22:11:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:11:52 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:11:52 --> Upload Class Initialized
INFO - 2020-09-12 22:11:52 --> Controller Class Initialized
ERROR - 2020-09-12 22:11:52 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:48 --> Config Class Initialized
INFO - 2020-09-12 22:31:48 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:48 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:48 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:48 --> URI Class Initialized
DEBUG - 2020-09-12 22:31:48 --> No URI present. Default controller set.
INFO - 2020-09-12 22:31:48 --> Router Class Initialized
INFO - 2020-09-12 22:31:48 --> Output Class Initialized
INFO - 2020-09-12 22:31:48 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:48 --> Input Class Initialized
INFO - 2020-09-12 22:31:48 --> Language Class Initialized
INFO - 2020-09-12 22:31:48 --> Language Class Initialized
INFO - 2020-09-12 22:31:48 --> Config Class Initialized
INFO - 2020-09-12 22:31:48 --> Loader Class Initialized
INFO - 2020-09-12 22:31:48 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:48 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:48 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:48 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:48 --> Upload Class Initialized
INFO - 2020-09-12 22:31:48 --> Controller Class Initialized
DEBUG - 2020-09-12 22:31:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 22:31:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 22:31:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 22:31:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 22:31:48 --> Final output sent to browser
DEBUG - 2020-09-12 22:31:48 --> Total execution time: 0.0622
INFO - 2020-09-12 22:31:49 --> Config Class Initialized
INFO - 2020-09-12 22:31:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:49 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:49 --> URI Class Initialized
INFO - 2020-09-12 22:31:49 --> Router Class Initialized
INFO - 2020-09-12 22:31:49 --> Output Class Initialized
INFO - 2020-09-12 22:31:49 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:49 --> Input Class Initialized
INFO - 2020-09-12 22:31:49 --> Language Class Initialized
INFO - 2020-09-12 22:31:49 --> Language Class Initialized
INFO - 2020-09-12 22:31:49 --> Config Class Initialized
INFO - 2020-09-12 22:31:49 --> Loader Class Initialized
INFO - 2020-09-12 22:31:49 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:49 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:49 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:49 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:49 --> Upload Class Initialized
INFO - 2020-09-12 22:31:49 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:49 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:49 --> Config Class Initialized
INFO - 2020-09-12 22:31:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:49 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:49 --> URI Class Initialized
INFO - 2020-09-12 22:31:49 --> Router Class Initialized
INFO - 2020-09-12 22:31:49 --> Output Class Initialized
INFO - 2020-09-12 22:31:49 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:49 --> Input Class Initialized
INFO - 2020-09-12 22:31:49 --> Language Class Initialized
INFO - 2020-09-12 22:31:49 --> Language Class Initialized
INFO - 2020-09-12 22:31:49 --> Config Class Initialized
INFO - 2020-09-12 22:31:49 --> Loader Class Initialized
INFO - 2020-09-12 22:31:49 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:49 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:49 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:49 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:49 --> Upload Class Initialized
INFO - 2020-09-12 22:31:49 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:49 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:50 --> Config Class Initialized
INFO - 2020-09-12 22:31:50 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:50 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:50 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:50 --> URI Class Initialized
INFO - 2020-09-12 22:31:50 --> Router Class Initialized
INFO - 2020-09-12 22:31:50 --> Output Class Initialized
INFO - 2020-09-12 22:31:50 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:50 --> Input Class Initialized
INFO - 2020-09-12 22:31:50 --> Language Class Initialized
INFO - 2020-09-12 22:31:50 --> Language Class Initialized
INFO - 2020-09-12 22:31:50 --> Config Class Initialized
INFO - 2020-09-12 22:31:50 --> Loader Class Initialized
INFO - 2020-09-12 22:31:50 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:50 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:50 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:50 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:50 --> Upload Class Initialized
INFO - 2020-09-12 22:31:50 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:50 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:50 --> Config Class Initialized
INFO - 2020-09-12 22:31:50 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:50 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:50 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:50 --> URI Class Initialized
INFO - 2020-09-12 22:31:50 --> Router Class Initialized
INFO - 2020-09-12 22:31:50 --> Output Class Initialized
INFO - 2020-09-12 22:31:50 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:50 --> Input Class Initialized
INFO - 2020-09-12 22:31:50 --> Language Class Initialized
INFO - 2020-09-12 22:31:50 --> Language Class Initialized
INFO - 2020-09-12 22:31:50 --> Config Class Initialized
INFO - 2020-09-12 22:31:50 --> Loader Class Initialized
INFO - 2020-09-12 22:31:50 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:50 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:50 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:50 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:50 --> Upload Class Initialized
INFO - 2020-09-12 22:31:50 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:50 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:54 --> Config Class Initialized
INFO - 2020-09-12 22:31:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:54 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:54 --> URI Class Initialized
DEBUG - 2020-09-12 22:31:54 --> No URI present. Default controller set.
INFO - 2020-09-12 22:31:54 --> Router Class Initialized
INFO - 2020-09-12 22:31:54 --> Output Class Initialized
INFO - 2020-09-12 22:31:54 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:54 --> Input Class Initialized
INFO - 2020-09-12 22:31:54 --> Language Class Initialized
INFO - 2020-09-12 22:31:54 --> Language Class Initialized
INFO - 2020-09-12 22:31:54 --> Config Class Initialized
INFO - 2020-09-12 22:31:54 --> Loader Class Initialized
INFO - 2020-09-12 22:31:54 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:54 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:54 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:54 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:54 --> Upload Class Initialized
INFO - 2020-09-12 22:31:54 --> Controller Class Initialized
DEBUG - 2020-09-12 22:31:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 22:31:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 22:31:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 22:31:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 22:31:54 --> Final output sent to browser
DEBUG - 2020-09-12 22:31:54 --> Total execution time: 0.0576
INFO - 2020-09-12 22:31:55 --> Config Class Initialized
INFO - 2020-09-12 22:31:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:55 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:55 --> URI Class Initialized
INFO - 2020-09-12 22:31:55 --> Router Class Initialized
INFO - 2020-09-12 22:31:55 --> Output Class Initialized
INFO - 2020-09-12 22:31:55 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:55 --> Input Class Initialized
INFO - 2020-09-12 22:31:55 --> Language Class Initialized
INFO - 2020-09-12 22:31:55 --> Language Class Initialized
INFO - 2020-09-12 22:31:55 --> Config Class Initialized
INFO - 2020-09-12 22:31:55 --> Loader Class Initialized
INFO - 2020-09-12 22:31:55 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:55 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:55 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:55 --> Config Class Initialized
INFO - 2020-09-12 22:31:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:55 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:55 --> URI Class Initialized
INFO - 2020-09-12 22:31:55 --> Database Driver Class Initialized
INFO - 2020-09-12 22:31:55 --> Router Class Initialized
INFO - 2020-09-12 22:31:55 --> Output Class Initialized
DEBUG - 2020-09-12 22:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:55 --> Security Class Initialized
INFO - 2020-09-12 22:31:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-12 22:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:55 --> Input Class Initialized
INFO - 2020-09-12 22:31:55 --> Language Class Initialized
INFO - 2020-09-12 22:31:55 --> Upload Class Initialized
INFO - 2020-09-12 22:31:55 --> Language Class Initialized
INFO - 2020-09-12 22:31:55 --> Config Class Initialized
INFO - 2020-09-12 22:31:55 --> Loader Class Initialized
INFO - 2020-09-12 22:31:55 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:55 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:55 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:55 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:55 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:55 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:55 --> Upload Class Initialized
INFO - 2020-09-12 22:31:55 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:55 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:56 --> Config Class Initialized
INFO - 2020-09-12 22:31:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:56 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:56 --> URI Class Initialized
INFO - 2020-09-12 22:31:56 --> Config Class Initialized
INFO - 2020-09-12 22:31:56 --> Hooks Class Initialized
INFO - 2020-09-12 22:31:56 --> Router Class Initialized
DEBUG - 2020-09-12 22:31:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:56 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:56 --> URI Class Initialized
INFO - 2020-09-12 22:31:56 --> Output Class Initialized
INFO - 2020-09-12 22:31:56 --> Security Class Initialized
INFO - 2020-09-12 22:31:56 --> Router Class Initialized
DEBUG - 2020-09-12 22:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:56 --> Input Class Initialized
INFO - 2020-09-12 22:31:56 --> Language Class Initialized
INFO - 2020-09-12 22:31:56 --> Output Class Initialized
INFO - 2020-09-12 22:31:56 --> Language Class Initialized
INFO - 2020-09-12 22:31:56 --> Config Class Initialized
INFO - 2020-09-12 22:31:56 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:56 --> Input Class Initialized
INFO - 2020-09-12 22:31:56 --> Loader Class Initialized
INFO - 2020-09-12 22:31:56 --> Language Class Initialized
INFO - 2020-09-12 22:31:56 --> Language Class Initialized
INFO - 2020-09-12 22:31:56 --> Config Class Initialized
INFO - 2020-09-12 22:31:56 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:56 --> Loader Class Initialized
INFO - 2020-09-12 22:31:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:56 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:56 --> Database Driver Class Initialized
INFO - 2020-09-12 22:31:56 --> Upload Class Initialized
DEBUG - 2020-09-12 22:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:56 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:56 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:56 --> Upload Class Initialized
INFO - 2020-09-12 22:31:56 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:56 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:56 --> Config Class Initialized
INFO - 2020-09-12 22:31:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:56 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:56 --> URI Class Initialized
INFO - 2020-09-12 22:31:56 --> Router Class Initialized
INFO - 2020-09-12 22:31:56 --> Output Class Initialized
INFO - 2020-09-12 22:31:56 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:56 --> Input Class Initialized
INFO - 2020-09-12 22:31:56 --> Language Class Initialized
INFO - 2020-09-12 22:31:56 --> Language Class Initialized
INFO - 2020-09-12 22:31:56 --> Config Class Initialized
INFO - 2020-09-12 22:31:56 --> Loader Class Initialized
INFO - 2020-09-12 22:31:56 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:56 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:56 --> Upload Class Initialized
INFO - 2020-09-12 22:31:56 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:56 --> 404 Page Not Found: /index
INFO - 2020-09-12 22:31:57 --> Config Class Initialized
INFO - 2020-09-12 22:31:57 --> Hooks Class Initialized
DEBUG - 2020-09-12 22:31:57 --> UTF-8 Support Enabled
INFO - 2020-09-12 22:31:57 --> Utf8 Class Initialized
INFO - 2020-09-12 22:31:57 --> URI Class Initialized
INFO - 2020-09-12 22:31:57 --> Router Class Initialized
INFO - 2020-09-12 22:31:57 --> Output Class Initialized
INFO - 2020-09-12 22:31:57 --> Security Class Initialized
DEBUG - 2020-09-12 22:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 22:31:57 --> Input Class Initialized
INFO - 2020-09-12 22:31:57 --> Language Class Initialized
INFO - 2020-09-12 22:31:57 --> Language Class Initialized
INFO - 2020-09-12 22:31:57 --> Config Class Initialized
INFO - 2020-09-12 22:31:57 --> Loader Class Initialized
INFO - 2020-09-12 22:31:57 --> Helper loaded: url_helper
INFO - 2020-09-12 22:31:57 --> Helper loaded: form_helper
INFO - 2020-09-12 22:31:57 --> Helper loaded: file_helper
INFO - 2020-09-12 22:31:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 22:31:57 --> Database Driver Class Initialized
DEBUG - 2020-09-12 22:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 22:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 22:31:57 --> Upload Class Initialized
INFO - 2020-09-12 22:31:57 --> Controller Class Initialized
ERROR - 2020-09-12 22:31:57 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:15:18 --> Config Class Initialized
INFO - 2020-09-12 23:15:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:15:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:15:18 --> Utf8 Class Initialized
INFO - 2020-09-12 23:15:18 --> URI Class Initialized
DEBUG - 2020-09-12 23:15:18 --> No URI present. Default controller set.
INFO - 2020-09-12 23:15:18 --> Router Class Initialized
INFO - 2020-09-12 23:15:18 --> Output Class Initialized
INFO - 2020-09-12 23:15:18 --> Security Class Initialized
DEBUG - 2020-09-12 23:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:15:18 --> Input Class Initialized
INFO - 2020-09-12 23:15:18 --> Language Class Initialized
INFO - 2020-09-12 23:15:18 --> Language Class Initialized
INFO - 2020-09-12 23:15:18 --> Config Class Initialized
INFO - 2020-09-12 23:15:18 --> Loader Class Initialized
INFO - 2020-09-12 23:15:18 --> Helper loaded: url_helper
INFO - 2020-09-12 23:15:18 --> Helper loaded: form_helper
INFO - 2020-09-12 23:15:18 --> Helper loaded: file_helper
INFO - 2020-09-12 23:15:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:15:18 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:15:18 --> Upload Class Initialized
INFO - 2020-09-12 23:15:18 --> Controller Class Initialized
DEBUG - 2020-09-12 23:15:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 23:15:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 23:15:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 23:15:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 23:15:18 --> Final output sent to browser
DEBUG - 2020-09-12 23:15:18 --> Total execution time: 0.0554
INFO - 2020-09-12 23:15:30 --> Config Class Initialized
INFO - 2020-09-12 23:15:30 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:15:30 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:15:30 --> Utf8 Class Initialized
INFO - 2020-09-12 23:15:30 --> URI Class Initialized
INFO - 2020-09-12 23:15:30 --> Router Class Initialized
INFO - 2020-09-12 23:15:30 --> Output Class Initialized
INFO - 2020-09-12 23:15:30 --> Security Class Initialized
DEBUG - 2020-09-12 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:15:30 --> Input Class Initialized
INFO - 2020-09-12 23:15:30 --> Language Class Initialized
INFO - 2020-09-12 23:15:30 --> Language Class Initialized
INFO - 2020-09-12 23:15:30 --> Config Class Initialized
INFO - 2020-09-12 23:15:30 --> Loader Class Initialized
INFO - 2020-09-12 23:15:30 --> Helper loaded: url_helper
INFO - 2020-09-12 23:15:30 --> Helper loaded: form_helper
INFO - 2020-09-12 23:15:30 --> Helper loaded: file_helper
INFO - 2020-09-12 23:15:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:15:30 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:15:30 --> Upload Class Initialized
INFO - 2020-09-12 23:15:30 --> Controller Class Initialized
ERROR - 2020-09-12 23:15:30 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:15:31 --> Config Class Initialized
INFO - 2020-09-12 23:15:31 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:15:31 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:15:31 --> Utf8 Class Initialized
INFO - 2020-09-12 23:15:31 --> URI Class Initialized
INFO - 2020-09-12 23:15:31 --> Router Class Initialized
INFO - 2020-09-12 23:15:31 --> Output Class Initialized
INFO - 2020-09-12 23:15:31 --> Security Class Initialized
DEBUG - 2020-09-12 23:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:15:31 --> Input Class Initialized
INFO - 2020-09-12 23:15:31 --> Language Class Initialized
INFO - 2020-09-12 23:15:31 --> Language Class Initialized
INFO - 2020-09-12 23:15:31 --> Config Class Initialized
INFO - 2020-09-12 23:15:31 --> Loader Class Initialized
INFO - 2020-09-12 23:15:31 --> Helper loaded: url_helper
INFO - 2020-09-12 23:15:31 --> Helper loaded: form_helper
INFO - 2020-09-12 23:15:31 --> Helper loaded: file_helper
INFO - 2020-09-12 23:15:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:15:31 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:15:31 --> Upload Class Initialized
INFO - 2020-09-12 23:15:31 --> Controller Class Initialized
ERROR - 2020-09-12 23:15:31 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:15:32 --> Config Class Initialized
INFO - 2020-09-12 23:15:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:15:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:15:32 --> Utf8 Class Initialized
INFO - 2020-09-12 23:15:32 --> URI Class Initialized
INFO - 2020-09-12 23:15:32 --> Router Class Initialized
INFO - 2020-09-12 23:15:32 --> Output Class Initialized
INFO - 2020-09-12 23:15:32 --> Security Class Initialized
DEBUG - 2020-09-12 23:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:15:32 --> Input Class Initialized
INFO - 2020-09-12 23:15:32 --> Language Class Initialized
INFO - 2020-09-12 23:15:32 --> Language Class Initialized
INFO - 2020-09-12 23:15:32 --> Config Class Initialized
INFO - 2020-09-12 23:15:32 --> Loader Class Initialized
INFO - 2020-09-12 23:15:32 --> Helper loaded: url_helper
INFO - 2020-09-12 23:15:32 --> Helper loaded: form_helper
INFO - 2020-09-12 23:15:32 --> Helper loaded: file_helper
INFO - 2020-09-12 23:15:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:15:32 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:15:32 --> Upload Class Initialized
INFO - 2020-09-12 23:15:32 --> Controller Class Initialized
ERROR - 2020-09-12 23:15:32 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:15:35 --> Config Class Initialized
INFO - 2020-09-12 23:15:35 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:15:35 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:15:35 --> Utf8 Class Initialized
INFO - 2020-09-12 23:15:35 --> URI Class Initialized
INFO - 2020-09-12 23:15:35 --> Router Class Initialized
INFO - 2020-09-12 23:15:35 --> Output Class Initialized
INFO - 2020-09-12 23:15:35 --> Security Class Initialized
DEBUG - 2020-09-12 23:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:15:35 --> Input Class Initialized
INFO - 2020-09-12 23:15:35 --> Language Class Initialized
INFO - 2020-09-12 23:15:35 --> Language Class Initialized
INFO - 2020-09-12 23:15:35 --> Config Class Initialized
INFO - 2020-09-12 23:15:35 --> Loader Class Initialized
INFO - 2020-09-12 23:15:35 --> Helper loaded: url_helper
INFO - 2020-09-12 23:15:35 --> Helper loaded: form_helper
INFO - 2020-09-12 23:15:35 --> Helper loaded: file_helper
INFO - 2020-09-12 23:15:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:15:35 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:15:35 --> Upload Class Initialized
INFO - 2020-09-12 23:15:35 --> Controller Class Initialized
ERROR - 2020-09-12 23:15:35 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:23:19 --> Config Class Initialized
INFO - 2020-09-12 23:23:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:23:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:23:19 --> Utf8 Class Initialized
INFO - 2020-09-12 23:23:19 --> URI Class Initialized
DEBUG - 2020-09-12 23:23:19 --> No URI present. Default controller set.
INFO - 2020-09-12 23:23:19 --> Router Class Initialized
INFO - 2020-09-12 23:23:19 --> Output Class Initialized
INFO - 2020-09-12 23:23:19 --> Security Class Initialized
DEBUG - 2020-09-12 23:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:23:19 --> Input Class Initialized
INFO - 2020-09-12 23:23:19 --> Language Class Initialized
INFO - 2020-09-12 23:23:19 --> Language Class Initialized
INFO - 2020-09-12 23:23:19 --> Config Class Initialized
INFO - 2020-09-12 23:23:19 --> Loader Class Initialized
INFO - 2020-09-12 23:23:19 --> Helper loaded: url_helper
INFO - 2020-09-12 23:23:19 --> Helper loaded: form_helper
INFO - 2020-09-12 23:23:19 --> Helper loaded: file_helper
INFO - 2020-09-12 23:23:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:23:19 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:23:19 --> Upload Class Initialized
INFO - 2020-09-12 23:23:19 --> Controller Class Initialized
DEBUG - 2020-09-12 23:23:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 23:23:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 23:23:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 23:23:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 23:23:19 --> Final output sent to browser
DEBUG - 2020-09-12 23:23:19 --> Total execution time: 0.0489
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:23:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:23:20 --> Utf8 Class Initialized
INFO - 2020-09-12 23:23:20 --> URI Class Initialized
INFO - 2020-09-12 23:23:20 --> Router Class Initialized
INFO - 2020-09-12 23:23:20 --> Output Class Initialized
INFO - 2020-09-12 23:23:20 --> Security Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:23:20 --> Input Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Loader Class Initialized
INFO - 2020-09-12 23:23:20 --> Helper loaded: url_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: form_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: file_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:23:20 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:23:20 --> Upload Class Initialized
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:23:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:23:20 --> Utf8 Class Initialized
INFO - 2020-09-12 23:23:20 --> URI Class Initialized
INFO - 2020-09-12 23:23:20 --> Router Class Initialized
INFO - 2020-09-12 23:23:20 --> Output Class Initialized
INFO - 2020-09-12 23:23:20 --> Controller Class Initialized
ERROR - 2020-09-12 23:23:20 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:23:20 --> Security Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:23:20 --> Input Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Loader Class Initialized
INFO - 2020-09-12 23:23:20 --> Helper loaded: url_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: form_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: file_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:23:20 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:23:20 --> Upload Class Initialized
INFO - 2020-09-12 23:23:20 --> Controller Class Initialized
ERROR - 2020-09-12 23:23:20 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:23:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:23:20 --> Utf8 Class Initialized
INFO - 2020-09-12 23:23:20 --> URI Class Initialized
INFO - 2020-09-12 23:23:20 --> Router Class Initialized
INFO - 2020-09-12 23:23:20 --> Output Class Initialized
INFO - 2020-09-12 23:23:20 --> Security Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:23:20 --> Input Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Loader Class Initialized
INFO - 2020-09-12 23:23:20 --> Helper loaded: url_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: form_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: file_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:23:20 --> Database Driver Class Initialized
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:23:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:23:20 --> Utf8 Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:23:20 --> URI Class Initialized
INFO - 2020-09-12 23:23:20 --> Upload Class Initialized
INFO - 2020-09-12 23:23:20 --> Router Class Initialized
INFO - 2020-09-12 23:23:20 --> Output Class Initialized
INFO - 2020-09-12 23:23:20 --> Security Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:23:20 --> Input Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Language Class Initialized
INFO - 2020-09-12 23:23:20 --> Config Class Initialized
INFO - 2020-09-12 23:23:20 --> Loader Class Initialized
INFO - 2020-09-12 23:23:20 --> Helper loaded: url_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: form_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: file_helper
INFO - 2020-09-12 23:23:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:23:20 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:23:20 --> Controller Class Initialized
ERROR - 2020-09-12 23:23:20 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:23:20 --> Upload Class Initialized
INFO - 2020-09-12 23:23:20 --> Controller Class Initialized
ERROR - 2020-09-12 23:23:20 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:23:21 --> Config Class Initialized
INFO - 2020-09-12 23:23:21 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:23:21 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:23:21 --> Utf8 Class Initialized
INFO - 2020-09-12 23:23:21 --> URI Class Initialized
INFO - 2020-09-12 23:23:21 --> Router Class Initialized
INFO - 2020-09-12 23:23:21 --> Output Class Initialized
INFO - 2020-09-12 23:23:21 --> Security Class Initialized
DEBUG - 2020-09-12 23:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:23:21 --> Input Class Initialized
INFO - 2020-09-12 23:23:21 --> Language Class Initialized
INFO - 2020-09-12 23:23:21 --> Language Class Initialized
INFO - 2020-09-12 23:23:21 --> Config Class Initialized
INFO - 2020-09-12 23:23:21 --> Loader Class Initialized
INFO - 2020-09-12 23:23:21 --> Helper loaded: url_helper
INFO - 2020-09-12 23:23:21 --> Helper loaded: form_helper
INFO - 2020-09-12 23:23:21 --> Helper loaded: file_helper
INFO - 2020-09-12 23:23:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:23:21 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:23:21 --> Upload Class Initialized
INFO - 2020-09-12 23:23:21 --> Controller Class Initialized
ERROR - 2020-09-12 23:23:21 --> 404 Page Not Found: /index
INFO - 2020-09-12 23:33:32 --> Config Class Initialized
INFO - 2020-09-12 23:33:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:33:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:33:32 --> Utf8 Class Initialized
INFO - 2020-09-12 23:33:32 --> URI Class Initialized
DEBUG - 2020-09-12 23:33:32 --> No URI present. Default controller set.
INFO - 2020-09-12 23:33:32 --> Router Class Initialized
INFO - 2020-09-12 23:33:32 --> Output Class Initialized
INFO - 2020-09-12 23:33:32 --> Security Class Initialized
DEBUG - 2020-09-12 23:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:33:32 --> Input Class Initialized
INFO - 2020-09-12 23:33:32 --> Language Class Initialized
INFO - 2020-09-12 23:33:32 --> Language Class Initialized
INFO - 2020-09-12 23:33:32 --> Config Class Initialized
INFO - 2020-09-12 23:33:32 --> Loader Class Initialized
INFO - 2020-09-12 23:33:32 --> Helper loaded: url_helper
INFO - 2020-09-12 23:33:32 --> Helper loaded: form_helper
INFO - 2020-09-12 23:33:32 --> Helper loaded: file_helper
INFO - 2020-09-12 23:33:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:33:32 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:33:32 --> Upload Class Initialized
INFO - 2020-09-12 23:33:32 --> Controller Class Initialized
DEBUG - 2020-09-12 23:33:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 23:33:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 23:33:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 23:33:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 23:33:32 --> Final output sent to browser
DEBUG - 2020-09-12 23:33:32 --> Total execution time: 0.0540
INFO - 2020-09-12 23:37:38 --> Config Class Initialized
INFO - 2020-09-12 23:37:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 23:37:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 23:37:38 --> Utf8 Class Initialized
INFO - 2020-09-12 23:37:38 --> URI Class Initialized
DEBUG - 2020-09-12 23:37:38 --> No URI present. Default controller set.
INFO - 2020-09-12 23:37:38 --> Router Class Initialized
INFO - 2020-09-12 23:37:38 --> Output Class Initialized
INFO - 2020-09-12 23:37:38 --> Security Class Initialized
DEBUG - 2020-09-12 23:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 23:37:38 --> Input Class Initialized
INFO - 2020-09-12 23:37:38 --> Language Class Initialized
INFO - 2020-09-12 23:37:38 --> Language Class Initialized
INFO - 2020-09-12 23:37:38 --> Config Class Initialized
INFO - 2020-09-12 23:37:38 --> Loader Class Initialized
INFO - 2020-09-12 23:37:38 --> Helper loaded: url_helper
INFO - 2020-09-12 23:37:38 --> Helper loaded: form_helper
INFO - 2020-09-12 23:37:38 --> Helper loaded: file_helper
INFO - 2020-09-12 23:37:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-12 23:37:38 --> Database Driver Class Initialized
DEBUG - 2020-09-12 23:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-12 23:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 23:37:38 --> Upload Class Initialized
INFO - 2020-09-12 23:37:38 --> Controller Class Initialized
DEBUG - 2020-09-12 23:37:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-12 23:37:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-12 23:37:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-12 23:37:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-12 23:37:38 --> Final output sent to browser
DEBUG - 2020-09-12 23:37:38 --> Total execution time: 0.0547
