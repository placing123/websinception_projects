<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-13 00:03:06 --> Config Class Initialized
INFO - 2020-09-13 00:03:06 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:06 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:06 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:06 --> URI Class Initialized
DEBUG - 2020-09-13 00:03:06 --> No URI present. Default controller set.
INFO - 2020-09-13 00:03:06 --> Router Class Initialized
INFO - 2020-09-13 00:03:06 --> Output Class Initialized
INFO - 2020-09-13 00:03:06 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:06 --> Input Class Initialized
INFO - 2020-09-13 00:03:06 --> Language Class Initialized
INFO - 2020-09-13 00:03:06 --> Language Class Initialized
INFO - 2020-09-13 00:03:06 --> Config Class Initialized
INFO - 2020-09-13 00:03:06 --> Loader Class Initialized
INFO - 2020-09-13 00:03:06 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:06 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:06 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:06 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:06 --> Upload Class Initialized
INFO - 2020-09-13 00:03:06 --> Controller Class Initialized
DEBUG - 2020-09-13 00:03:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:03:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:03:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:03:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:03:06 --> Final output sent to browser
DEBUG - 2020-09-13 00:03:06 --> Total execution time: 0.0549
INFO - 2020-09-13 00:03:06 --> Config Class Initialized
INFO - 2020-09-13 00:03:06 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:06 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:06 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:06 --> URI Class Initialized
DEBUG - 2020-09-13 00:03:06 --> No URI present. Default controller set.
INFO - 2020-09-13 00:03:06 --> Router Class Initialized
INFO - 2020-09-13 00:03:06 --> Output Class Initialized
INFO - 2020-09-13 00:03:06 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:06 --> Input Class Initialized
INFO - 2020-09-13 00:03:06 --> Language Class Initialized
INFO - 2020-09-13 00:03:06 --> Language Class Initialized
INFO - 2020-09-13 00:03:06 --> Config Class Initialized
INFO - 2020-09-13 00:03:06 --> Loader Class Initialized
INFO - 2020-09-13 00:03:06 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:06 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:06 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:06 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:06 --> Upload Class Initialized
INFO - 2020-09-13 00:03:06 --> Controller Class Initialized
DEBUG - 2020-09-13 00:03:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:03:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:03:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:03:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:03:06 --> Final output sent to browser
DEBUG - 2020-09-13 00:03:06 --> Total execution time: 0.0355
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:07 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:07 --> URI Class Initialized
INFO - 2020-09-13 00:03:07 --> Router Class Initialized
INFO - 2020-09-13 00:03:07 --> Output Class Initialized
INFO - 2020-09-13 00:03:07 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:07 --> Input Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Loader Class Initialized
INFO - 2020-09-13 00:03:07 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:07 --> Upload Class Initialized
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:07 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:07 --> URI Class Initialized
INFO - 2020-09-13 00:03:07 --> Router Class Initialized
INFO - 2020-09-13 00:03:07 --> Output Class Initialized
INFO - 2020-09-13 00:03:07 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:07 --> Input Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Loader Class Initialized
INFO - 2020-09-13 00:03:07 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:07 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:07 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:07 --> Upload Class Initialized
INFO - 2020-09-13 00:03:07 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:07 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:07 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:07 --> URI Class Initialized
INFO - 2020-09-13 00:03:07 --> Router Class Initialized
INFO - 2020-09-13 00:03:07 --> Output Class Initialized
INFO - 2020-09-13 00:03:07 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:07 --> Input Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Loader Class Initialized
INFO - 2020-09-13 00:03:07 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:07 --> Upload Class Initialized
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:07 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:07 --> URI Class Initialized
INFO - 2020-09-13 00:03:07 --> Router Class Initialized
INFO - 2020-09-13 00:03:07 --> Output Class Initialized
INFO - 2020-09-13 00:03:07 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:07 --> Input Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Language Class Initialized
INFO - 2020-09-13 00:03:07 --> Config Class Initialized
INFO - 2020-09-13 00:03:07 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:07 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:07 --> Loader Class Initialized
INFO - 2020-09-13 00:03:07 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:07 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:07 --> Upload Class Initialized
INFO - 2020-09-13 00:03:07 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:07 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:08 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:08 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:08 --> URI Class Initialized
INFO - 2020-09-13 00:03:08 --> Router Class Initialized
INFO - 2020-09-13 00:03:08 --> Output Class Initialized
INFO - 2020-09-13 00:03:08 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:08 --> Input Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Loader Class Initialized
INFO - 2020-09-13 00:03:08 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:08 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:08 --> Upload Class Initialized
INFO - 2020-09-13 00:03:08 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:08 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:08 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:08 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:08 --> URI Class Initialized
INFO - 2020-09-13 00:03:08 --> Router Class Initialized
INFO - 2020-09-13 00:03:08 --> Output Class Initialized
INFO - 2020-09-13 00:03:08 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:08 --> Input Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Loader Class Initialized
INFO - 2020-09-13 00:03:08 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:08 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:08 --> Upload Class Initialized
INFO - 2020-09-13 00:03:08 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:08 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:08 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:08 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:08 --> URI Class Initialized
INFO - 2020-09-13 00:03:08 --> Router Class Initialized
INFO - 2020-09-13 00:03:08 --> Output Class Initialized
INFO - 2020-09-13 00:03:08 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:08 --> Input Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Loader Class Initialized
INFO - 2020-09-13 00:03:08 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:08 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:08 --> Upload Class Initialized
INFO - 2020-09-13 00:03:08 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:08 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:08 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:08 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:08 --> URI Class Initialized
INFO - 2020-09-13 00:03:08 --> Router Class Initialized
INFO - 2020-09-13 00:03:08 --> Output Class Initialized
INFO - 2020-09-13 00:03:08 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:08 --> Input Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Language Class Initialized
INFO - 2020-09-13 00:03:08 --> Config Class Initialized
INFO - 2020-09-13 00:03:08 --> Loader Class Initialized
INFO - 2020-09-13 00:03:08 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:08 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:08 --> Upload Class Initialized
INFO - 2020-09-13 00:03:08 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:08 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:03:17 --> Config Class Initialized
INFO - 2020-09-13 00:03:17 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:03:17 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:03:17 --> Utf8 Class Initialized
INFO - 2020-09-13 00:03:17 --> URI Class Initialized
INFO - 2020-09-13 00:03:17 --> Router Class Initialized
INFO - 2020-09-13 00:03:17 --> Output Class Initialized
INFO - 2020-09-13 00:03:17 --> Security Class Initialized
DEBUG - 2020-09-13 00:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:03:17 --> Input Class Initialized
INFO - 2020-09-13 00:03:17 --> Language Class Initialized
INFO - 2020-09-13 00:03:17 --> Language Class Initialized
INFO - 2020-09-13 00:03:17 --> Config Class Initialized
INFO - 2020-09-13 00:03:17 --> Loader Class Initialized
INFO - 2020-09-13 00:03:17 --> Helper loaded: url_helper
INFO - 2020-09-13 00:03:17 --> Helper loaded: form_helper
INFO - 2020-09-13 00:03:17 --> Helper loaded: file_helper
INFO - 2020-09-13 00:03:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:03:17 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:03:17 --> Upload Class Initialized
INFO - 2020-09-13 00:03:17 --> Controller Class Initialized
ERROR - 2020-09-13 00:03:17 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:19:41 --> Config Class Initialized
INFO - 2020-09-13 00:19:41 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:19:41 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:19:41 --> Utf8 Class Initialized
INFO - 2020-09-13 00:19:41 --> URI Class Initialized
DEBUG - 2020-09-13 00:19:41 --> No URI present. Default controller set.
INFO - 2020-09-13 00:19:41 --> Router Class Initialized
INFO - 2020-09-13 00:19:41 --> Output Class Initialized
INFO - 2020-09-13 00:19:41 --> Security Class Initialized
DEBUG - 2020-09-13 00:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:19:41 --> Input Class Initialized
INFO - 2020-09-13 00:19:41 --> Language Class Initialized
INFO - 2020-09-13 00:19:41 --> Language Class Initialized
INFO - 2020-09-13 00:19:41 --> Config Class Initialized
INFO - 2020-09-13 00:19:41 --> Loader Class Initialized
INFO - 2020-09-13 00:19:41 --> Helper loaded: url_helper
INFO - 2020-09-13 00:19:41 --> Helper loaded: form_helper
INFO - 2020-09-13 00:19:41 --> Helper loaded: file_helper
INFO - 2020-09-13 00:19:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:19:41 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:19:41 --> Upload Class Initialized
INFO - 2020-09-13 00:19:41 --> Controller Class Initialized
DEBUG - 2020-09-13 00:19:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:19:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:19:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:19:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:19:41 --> Final output sent to browser
DEBUG - 2020-09-13 00:19:41 --> Total execution time: 0.0572
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:19:42 --> Utf8 Class Initialized
INFO - 2020-09-13 00:19:42 --> URI Class Initialized
INFO - 2020-09-13 00:19:42 --> Router Class Initialized
INFO - 2020-09-13 00:19:42 --> Output Class Initialized
INFO - 2020-09-13 00:19:42 --> Security Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:19:42 --> Input Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Loader Class Initialized
INFO - 2020-09-13 00:19:42 --> Helper loaded: url_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: form_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: file_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Hooks Class Initialized
INFO - 2020-09-13 00:19:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-13 00:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:19:42 --> Upload Class Initialized
INFO - 2020-09-13 00:19:42 --> Utf8 Class Initialized
INFO - 2020-09-13 00:19:42 --> URI Class Initialized
INFO - 2020-09-13 00:19:42 --> Router Class Initialized
INFO - 2020-09-13 00:19:42 --> Output Class Initialized
INFO - 2020-09-13 00:19:42 --> Security Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:19:42 --> Input Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Loader Class Initialized
INFO - 2020-09-13 00:19:42 --> Helper loaded: url_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: form_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: file_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:19:42 --> Controller Class Initialized
ERROR - 2020-09-13 00:19:42 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:19:42 --> Upload Class Initialized
INFO - 2020-09-13 00:19:42 --> Controller Class Initialized
ERROR - 2020-09-13 00:19:42 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:19:42 --> Utf8 Class Initialized
INFO - 2020-09-13 00:19:42 --> URI Class Initialized
INFO - 2020-09-13 00:19:42 --> Router Class Initialized
INFO - 2020-09-13 00:19:42 --> Output Class Initialized
INFO - 2020-09-13 00:19:42 --> Security Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:19:42 --> Input Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Loader Class Initialized
INFO - 2020-09-13 00:19:42 --> Helper loaded: url_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: form_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: file_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:19:42 --> Upload Class Initialized
INFO - 2020-09-13 00:19:42 --> Controller Class Initialized
ERROR - 2020-09-13 00:19:42 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:19:42 --> Utf8 Class Initialized
INFO - 2020-09-13 00:19:42 --> URI Class Initialized
INFO - 2020-09-13 00:19:42 --> Router Class Initialized
INFO - 2020-09-13 00:19:42 --> Output Class Initialized
INFO - 2020-09-13 00:19:42 --> Security Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:19:42 --> Input Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Language Class Initialized
INFO - 2020-09-13 00:19:42 --> Config Class Initialized
INFO - 2020-09-13 00:19:42 --> Loader Class Initialized
INFO - 2020-09-13 00:19:42 --> Helper loaded: url_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: form_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: file_helper
INFO - 2020-09-13 00:19:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:19:42 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:19:42 --> Upload Class Initialized
INFO - 2020-09-13 00:19:42 --> Controller Class Initialized
ERROR - 2020-09-13 00:19:42 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:28:56 --> Utf8 Class Initialized
INFO - 2020-09-13 00:28:56 --> URI Class Initialized
DEBUG - 2020-09-13 00:28:56 --> No URI present. Default controller set.
INFO - 2020-09-13 00:28:56 --> Router Class Initialized
INFO - 2020-09-13 00:28:56 --> Output Class Initialized
INFO - 2020-09-13 00:28:56 --> Security Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:28:56 --> Input Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Loader Class Initialized
INFO - 2020-09-13 00:28:56 --> Helper loaded: url_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: form_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: file_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:28:56 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:28:56 --> Upload Class Initialized
INFO - 2020-09-13 00:28:56 --> Controller Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:28:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:28:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:28:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:28:56 --> Final output sent to browser
DEBUG - 2020-09-13 00:28:56 --> Total execution time: 0.0419
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:28:56 --> Utf8 Class Initialized
INFO - 2020-09-13 00:28:56 --> URI Class Initialized
INFO - 2020-09-13 00:28:56 --> Router Class Initialized
INFO - 2020-09-13 00:28:56 --> Output Class Initialized
INFO - 2020-09-13 00:28:56 --> Security Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:28:56 --> Input Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Loader Class Initialized
INFO - 2020-09-13 00:28:56 --> Helper loaded: url_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: form_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: file_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:28:56 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:28:56 --> Upload Class Initialized
INFO - 2020-09-13 00:28:56 --> Controller Class Initialized
ERROR - 2020-09-13 00:28:56 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:28:56 --> Utf8 Class Initialized
INFO - 2020-09-13 00:28:56 --> URI Class Initialized
INFO - 2020-09-13 00:28:56 --> Router Class Initialized
INFO - 2020-09-13 00:28:56 --> Output Class Initialized
INFO - 2020-09-13 00:28:56 --> Security Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:28:56 --> Input Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Loader Class Initialized
INFO - 2020-09-13 00:28:56 --> Helper loaded: url_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: form_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: file_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:28:56 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:28:56 --> Upload Class Initialized
INFO - 2020-09-13 00:28:56 --> Controller Class Initialized
ERROR - 2020-09-13 00:28:56 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:28:56 --> Utf8 Class Initialized
INFO - 2020-09-13 00:28:56 --> URI Class Initialized
INFO - 2020-09-13 00:28:56 --> Router Class Initialized
INFO - 2020-09-13 00:28:56 --> Output Class Initialized
INFO - 2020-09-13 00:28:56 --> Security Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:28:56 --> Input Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Loader Class Initialized
INFO - 2020-09-13 00:28:56 --> Helper loaded: url_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: form_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: file_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:28:56 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:28:56 --> Upload Class Initialized
INFO - 2020-09-13 00:28:56 --> Controller Class Initialized
ERROR - 2020-09-13 00:28:56 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:28:56 --> Utf8 Class Initialized
INFO - 2020-09-13 00:28:56 --> URI Class Initialized
INFO - 2020-09-13 00:28:56 --> Router Class Initialized
INFO - 2020-09-13 00:28:56 --> Output Class Initialized
INFO - 2020-09-13 00:28:56 --> Security Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:28:56 --> Input Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Language Class Initialized
INFO - 2020-09-13 00:28:56 --> Config Class Initialized
INFO - 2020-09-13 00:28:56 --> Loader Class Initialized
INFO - 2020-09-13 00:28:56 --> Helper loaded: url_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: form_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: file_helper
INFO - 2020-09-13 00:28:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:28:56 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:28:56 --> Upload Class Initialized
INFO - 2020-09-13 00:28:56 --> Controller Class Initialized
ERROR - 2020-09-13 00:28:56 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:01 --> Config Class Initialized
INFO - 2020-09-13 00:29:01 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:01 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:01 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:01 --> URI Class Initialized
INFO - 2020-09-13 00:29:01 --> Router Class Initialized
INFO - 2020-09-13 00:29:01 --> Output Class Initialized
INFO - 2020-09-13 00:29:01 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:01 --> Input Class Initialized
INFO - 2020-09-13 00:29:01 --> Language Class Initialized
INFO - 2020-09-13 00:29:01 --> Language Class Initialized
INFO - 2020-09-13 00:29:01 --> Config Class Initialized
INFO - 2020-09-13 00:29:01 --> Loader Class Initialized
INFO - 2020-09-13 00:29:01 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:01 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:01 --> Upload Class Initialized
INFO - 2020-09-13 00:29:01 --> Controller Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:29:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:29:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:29:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:29:01 --> Final output sent to browser
DEBUG - 2020-09-13 00:29:01 --> Total execution time: 0.0470
INFO - 2020-09-13 00:29:01 --> Config Class Initialized
INFO - 2020-09-13 00:29:01 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:01 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:01 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:01 --> URI Class Initialized
INFO - 2020-09-13 00:29:01 --> Router Class Initialized
INFO - 2020-09-13 00:29:01 --> Output Class Initialized
INFO - 2020-09-13 00:29:01 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:01 --> Input Class Initialized
INFO - 2020-09-13 00:29:01 --> Language Class Initialized
INFO - 2020-09-13 00:29:01 --> Language Class Initialized
INFO - 2020-09-13 00:29:01 --> Config Class Initialized
INFO - 2020-09-13 00:29:01 --> Loader Class Initialized
INFO - 2020-09-13 00:29:01 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:01 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:01 --> Upload Class Initialized
INFO - 2020-09-13 00:29:01 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:01 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:01 --> Config Class Initialized
INFO - 2020-09-13 00:29:01 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:01 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:01 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:01 --> URI Class Initialized
INFO - 2020-09-13 00:29:01 --> Router Class Initialized
INFO - 2020-09-13 00:29:01 --> Output Class Initialized
INFO - 2020-09-13 00:29:01 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:01 --> Input Class Initialized
INFO - 2020-09-13 00:29:01 --> Language Class Initialized
INFO - 2020-09-13 00:29:01 --> Language Class Initialized
INFO - 2020-09-13 00:29:01 --> Config Class Initialized
INFO - 2020-09-13 00:29:01 --> Loader Class Initialized
INFO - 2020-09-13 00:29:01 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:01 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:01 --> Upload Class Initialized
INFO - 2020-09-13 00:29:01 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:01 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:02 --> Config Class Initialized
INFO - 2020-09-13 00:29:02 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:02 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:02 --> URI Class Initialized
INFO - 2020-09-13 00:29:02 --> Router Class Initialized
INFO - 2020-09-13 00:29:02 --> Output Class Initialized
INFO - 2020-09-13 00:29:02 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:02 --> Input Class Initialized
INFO - 2020-09-13 00:29:02 --> Language Class Initialized
INFO - 2020-09-13 00:29:02 --> Language Class Initialized
INFO - 2020-09-13 00:29:02 --> Config Class Initialized
INFO - 2020-09-13 00:29:02 --> Loader Class Initialized
INFO - 2020-09-13 00:29:02 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:02 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:02 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:02 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:02 --> Upload Class Initialized
INFO - 2020-09-13 00:29:02 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:02 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:02 --> Config Class Initialized
INFO - 2020-09-13 00:29:02 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:02 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:02 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:02 --> URI Class Initialized
INFO - 2020-09-13 00:29:02 --> Router Class Initialized
INFO - 2020-09-13 00:29:02 --> Output Class Initialized
INFO - 2020-09-13 00:29:02 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:02 --> Input Class Initialized
INFO - 2020-09-13 00:29:02 --> Language Class Initialized
INFO - 2020-09-13 00:29:02 --> Language Class Initialized
INFO - 2020-09-13 00:29:02 --> Config Class Initialized
INFO - 2020-09-13 00:29:02 --> Loader Class Initialized
INFO - 2020-09-13 00:29:02 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:02 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:02 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:02 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:02 --> Upload Class Initialized
INFO - 2020-09-13 00:29:02 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:02 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:29 --> Config Class Initialized
INFO - 2020-09-13 00:29:29 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:29 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:29 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:29 --> URI Class Initialized
DEBUG - 2020-09-13 00:29:29 --> No URI present. Default controller set.
INFO - 2020-09-13 00:29:29 --> Router Class Initialized
INFO - 2020-09-13 00:29:29 --> Output Class Initialized
INFO - 2020-09-13 00:29:29 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:29 --> Input Class Initialized
INFO - 2020-09-13 00:29:29 --> Language Class Initialized
INFO - 2020-09-13 00:29:29 --> Language Class Initialized
INFO - 2020-09-13 00:29:29 --> Config Class Initialized
INFO - 2020-09-13 00:29:29 --> Loader Class Initialized
INFO - 2020-09-13 00:29:29 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:29 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:29 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:29 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:29 --> Upload Class Initialized
INFO - 2020-09-13 00:29:29 --> Controller Class Initialized
DEBUG - 2020-09-13 00:29:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:29:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:29:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:29:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:29:29 --> Final output sent to browser
DEBUG - 2020-09-13 00:29:29 --> Total execution time: 0.0580
INFO - 2020-09-13 00:29:41 --> Config Class Initialized
INFO - 2020-09-13 00:29:41 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:41 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:41 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:41 --> URI Class Initialized
INFO - 2020-09-13 00:29:41 --> Router Class Initialized
INFO - 2020-09-13 00:29:41 --> Output Class Initialized
INFO - 2020-09-13 00:29:41 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:41 --> Input Class Initialized
INFO - 2020-09-13 00:29:41 --> Language Class Initialized
INFO - 2020-09-13 00:29:41 --> Language Class Initialized
INFO - 2020-09-13 00:29:41 --> Config Class Initialized
INFO - 2020-09-13 00:29:41 --> Loader Class Initialized
INFO - 2020-09-13 00:29:41 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:41 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:41 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:41 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:41 --> Upload Class Initialized
INFO - 2020-09-13 00:29:41 --> Controller Class Initialized
DEBUG - 2020-09-13 00:29:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:29:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:29:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:29:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:29:41 --> Final output sent to browser
DEBUG - 2020-09-13 00:29:41 --> Total execution time: 0.0515
INFO - 2020-09-13 00:29:44 --> Config Class Initialized
INFO - 2020-09-13 00:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:44 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:44 --> URI Class Initialized
INFO - 2020-09-13 00:29:44 --> Router Class Initialized
INFO - 2020-09-13 00:29:44 --> Output Class Initialized
INFO - 2020-09-13 00:29:44 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:44 --> Input Class Initialized
INFO - 2020-09-13 00:29:44 --> Language Class Initialized
INFO - 2020-09-13 00:29:44 --> Language Class Initialized
INFO - 2020-09-13 00:29:44 --> Config Class Initialized
INFO - 2020-09-13 00:29:44 --> Loader Class Initialized
INFO - 2020-09-13 00:29:44 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:44 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:44 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:44 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:44 --> Upload Class Initialized
INFO - 2020-09-13 00:29:44 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:44 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:44 --> Config Class Initialized
INFO - 2020-09-13 00:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:44 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:44 --> URI Class Initialized
INFO - 2020-09-13 00:29:44 --> Router Class Initialized
INFO - 2020-09-13 00:29:44 --> Output Class Initialized
INFO - 2020-09-13 00:29:44 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:44 --> Input Class Initialized
INFO - 2020-09-13 00:29:44 --> Language Class Initialized
INFO - 2020-09-13 00:29:44 --> Language Class Initialized
INFO - 2020-09-13 00:29:44 --> Config Class Initialized
INFO - 2020-09-13 00:29:44 --> Loader Class Initialized
INFO - 2020-09-13 00:29:44 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:44 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:44 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:44 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:44 --> Upload Class Initialized
INFO - 2020-09-13 00:29:44 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:44 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:45 --> Config Class Initialized
INFO - 2020-09-13 00:29:45 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:45 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:45 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:45 --> URI Class Initialized
INFO - 2020-09-13 00:29:45 --> Router Class Initialized
INFO - 2020-09-13 00:29:45 --> Output Class Initialized
INFO - 2020-09-13 00:29:45 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:45 --> Input Class Initialized
INFO - 2020-09-13 00:29:45 --> Language Class Initialized
INFO - 2020-09-13 00:29:45 --> Language Class Initialized
INFO - 2020-09-13 00:29:45 --> Config Class Initialized
INFO - 2020-09-13 00:29:45 --> Loader Class Initialized
INFO - 2020-09-13 00:29:45 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:45 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:45 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:45 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:45 --> Upload Class Initialized
INFO - 2020-09-13 00:29:45 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:45 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:45 --> Config Class Initialized
INFO - 2020-09-13 00:29:45 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:45 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:45 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:45 --> URI Class Initialized
INFO - 2020-09-13 00:29:45 --> Router Class Initialized
INFO - 2020-09-13 00:29:45 --> Output Class Initialized
INFO - 2020-09-13 00:29:45 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:45 --> Input Class Initialized
INFO - 2020-09-13 00:29:45 --> Language Class Initialized
INFO - 2020-09-13 00:29:45 --> Language Class Initialized
INFO - 2020-09-13 00:29:45 --> Config Class Initialized
INFO - 2020-09-13 00:29:45 --> Loader Class Initialized
INFO - 2020-09-13 00:29:45 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:45 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:45 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:45 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:45 --> Upload Class Initialized
INFO - 2020-09-13 00:29:45 --> Controller Class Initialized
ERROR - 2020-09-13 00:29:45 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:29:53 --> Config Class Initialized
INFO - 2020-09-13 00:29:53 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:29:53 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:29:53 --> Utf8 Class Initialized
INFO - 2020-09-13 00:29:53 --> URI Class Initialized
INFO - 2020-09-13 00:29:53 --> Router Class Initialized
INFO - 2020-09-13 00:29:53 --> Output Class Initialized
INFO - 2020-09-13 00:29:53 --> Security Class Initialized
DEBUG - 2020-09-13 00:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:29:53 --> Input Class Initialized
INFO - 2020-09-13 00:29:53 --> Language Class Initialized
INFO - 2020-09-13 00:29:53 --> Language Class Initialized
INFO - 2020-09-13 00:29:53 --> Config Class Initialized
INFO - 2020-09-13 00:29:53 --> Loader Class Initialized
INFO - 2020-09-13 00:29:53 --> Helper loaded: url_helper
INFO - 2020-09-13 00:29:53 --> Helper loaded: form_helper
INFO - 2020-09-13 00:29:53 --> Helper loaded: file_helper
INFO - 2020-09-13 00:29:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:29:53 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:29:53 --> Upload Class Initialized
INFO - 2020-09-13 00:29:54 --> Controller Class Initialized
DEBUG - 2020-09-13 00:29:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:29:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:29:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:29:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:29:54 --> Final output sent to browser
DEBUG - 2020-09-13 00:29:54 --> Total execution time: 0.0555
INFO - 2020-09-13 00:30:13 --> Config Class Initialized
INFO - 2020-09-13 00:30:13 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:30:13 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:30:13 --> Utf8 Class Initialized
INFO - 2020-09-13 00:30:13 --> URI Class Initialized
INFO - 2020-09-13 00:30:13 --> Router Class Initialized
INFO - 2020-09-13 00:30:13 --> Output Class Initialized
INFO - 2020-09-13 00:30:13 --> Security Class Initialized
DEBUG - 2020-09-13 00:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:30:13 --> Input Class Initialized
INFO - 2020-09-13 00:30:13 --> Language Class Initialized
INFO - 2020-09-13 00:30:13 --> Language Class Initialized
INFO - 2020-09-13 00:30:13 --> Config Class Initialized
INFO - 2020-09-13 00:30:13 --> Loader Class Initialized
INFO - 2020-09-13 00:30:13 --> Helper loaded: url_helper
INFO - 2020-09-13 00:30:13 --> Helper loaded: form_helper
INFO - 2020-09-13 00:30:13 --> Helper loaded: file_helper
INFO - 2020-09-13 00:30:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:30:13 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:30:13 --> Upload Class Initialized
INFO - 2020-09-13 00:30:13 --> Controller Class Initialized
ERROR - 2020-09-13 00:30:13 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:36:20 --> Config Class Initialized
INFO - 2020-09-13 00:36:20 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:36:20 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:36:20 --> Utf8 Class Initialized
INFO - 2020-09-13 00:36:20 --> URI Class Initialized
INFO - 2020-09-13 00:36:20 --> Router Class Initialized
INFO - 2020-09-13 00:36:20 --> Output Class Initialized
INFO - 2020-09-13 00:36:20 --> Security Class Initialized
DEBUG - 2020-09-13 00:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:36:20 --> Input Class Initialized
INFO - 2020-09-13 00:36:20 --> Language Class Initialized
INFO - 2020-09-13 00:36:20 --> Language Class Initialized
INFO - 2020-09-13 00:36:20 --> Config Class Initialized
INFO - 2020-09-13 00:36:20 --> Loader Class Initialized
INFO - 2020-09-13 00:36:20 --> Helper loaded: url_helper
INFO - 2020-09-13 00:36:20 --> Helper loaded: form_helper
INFO - 2020-09-13 00:36:20 --> Helper loaded: file_helper
INFO - 2020-09-13 00:36:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:36:20 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:36:20 --> Upload Class Initialized
INFO - 2020-09-13 00:36:20 --> Controller Class Initialized
ERROR - 2020-09-13 00:36:20 --> 404 Page Not Found: /index
INFO - 2020-09-13 00:36:30 --> Config Class Initialized
INFO - 2020-09-13 00:36:30 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:36:30 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:36:30 --> Utf8 Class Initialized
INFO - 2020-09-13 00:36:30 --> URI Class Initialized
DEBUG - 2020-09-13 00:36:30 --> No URI present. Default controller set.
INFO - 2020-09-13 00:36:30 --> Router Class Initialized
INFO - 2020-09-13 00:36:30 --> Output Class Initialized
INFO - 2020-09-13 00:36:30 --> Security Class Initialized
DEBUG - 2020-09-13 00:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:36:30 --> Input Class Initialized
INFO - 2020-09-13 00:36:30 --> Language Class Initialized
INFO - 2020-09-13 00:36:30 --> Language Class Initialized
INFO - 2020-09-13 00:36:30 --> Config Class Initialized
INFO - 2020-09-13 00:36:30 --> Loader Class Initialized
INFO - 2020-09-13 00:36:30 --> Helper loaded: url_helper
INFO - 2020-09-13 00:36:30 --> Helper loaded: form_helper
INFO - 2020-09-13 00:36:30 --> Helper loaded: file_helper
INFO - 2020-09-13 00:36:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:36:30 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:36:30 --> Upload Class Initialized
INFO - 2020-09-13 00:36:30 --> Controller Class Initialized
DEBUG - 2020-09-13 00:36:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:36:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:36:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:36:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:36:30 --> Final output sent to browser
DEBUG - 2020-09-13 00:36:30 --> Total execution time: 0.0580
INFO - 2020-09-13 00:36:41 --> Config Class Initialized
INFO - 2020-09-13 00:36:41 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:36:41 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:36:41 --> Utf8 Class Initialized
INFO - 2020-09-13 00:36:41 --> URI Class Initialized
DEBUG - 2020-09-13 00:36:41 --> No URI present. Default controller set.
INFO - 2020-09-13 00:36:41 --> Router Class Initialized
INFO - 2020-09-13 00:36:41 --> Output Class Initialized
INFO - 2020-09-13 00:36:41 --> Security Class Initialized
DEBUG - 2020-09-13 00:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:36:41 --> Input Class Initialized
INFO - 2020-09-13 00:36:41 --> Language Class Initialized
INFO - 2020-09-13 00:36:41 --> Language Class Initialized
INFO - 2020-09-13 00:36:41 --> Config Class Initialized
INFO - 2020-09-13 00:36:41 --> Loader Class Initialized
INFO - 2020-09-13 00:36:41 --> Helper loaded: url_helper
INFO - 2020-09-13 00:36:41 --> Helper loaded: form_helper
INFO - 2020-09-13 00:36:41 --> Helper loaded: file_helper
INFO - 2020-09-13 00:36:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:36:41 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:36:41 --> Upload Class Initialized
INFO - 2020-09-13 00:36:41 --> Controller Class Initialized
DEBUG - 2020-09-13 00:36:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:36:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:36:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:36:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:36:41 --> Final output sent to browser
DEBUG - 2020-09-13 00:36:41 --> Total execution time: 0.0454
INFO - 2020-09-13 00:37:09 --> Config Class Initialized
INFO - 2020-09-13 00:37:09 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:37:09 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:37:09 --> Utf8 Class Initialized
INFO - 2020-09-13 00:37:09 --> URI Class Initialized
INFO - 2020-09-13 00:37:09 --> Router Class Initialized
INFO - 2020-09-13 00:37:09 --> Output Class Initialized
INFO - 2020-09-13 00:37:09 --> Security Class Initialized
DEBUG - 2020-09-13 00:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:37:09 --> Input Class Initialized
INFO - 2020-09-13 00:37:09 --> Language Class Initialized
INFO - 2020-09-13 00:37:09 --> Language Class Initialized
INFO - 2020-09-13 00:37:09 --> Config Class Initialized
INFO - 2020-09-13 00:37:09 --> Loader Class Initialized
INFO - 2020-09-13 00:37:09 --> Helper loaded: url_helper
INFO - 2020-09-13 00:37:09 --> Helper loaded: form_helper
INFO - 2020-09-13 00:37:09 --> Helper loaded: file_helper
INFO - 2020-09-13 00:37:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:37:09 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:37:09 --> Upload Class Initialized
INFO - 2020-09-13 00:37:09 --> Controller Class Initialized
DEBUG - 2020-09-13 00:37:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:37:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 00:37:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 00:37:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:37:09 --> Final output sent to browser
DEBUG - 2020-09-13 00:37:09 --> Total execution time: 0.0620
INFO - 2020-09-13 00:38:05 --> Config Class Initialized
INFO - 2020-09-13 00:38:05 --> Hooks Class Initialized
DEBUG - 2020-09-13 00:38:05 --> UTF-8 Support Enabled
INFO - 2020-09-13 00:38:05 --> Utf8 Class Initialized
INFO - 2020-09-13 00:38:05 --> URI Class Initialized
INFO - 2020-09-13 00:38:05 --> Router Class Initialized
INFO - 2020-09-13 00:38:05 --> Output Class Initialized
INFO - 2020-09-13 00:38:05 --> Security Class Initialized
DEBUG - 2020-09-13 00:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 00:38:05 --> Input Class Initialized
INFO - 2020-09-13 00:38:05 --> Language Class Initialized
INFO - 2020-09-13 00:38:05 --> Language Class Initialized
INFO - 2020-09-13 00:38:05 --> Config Class Initialized
INFO - 2020-09-13 00:38:05 --> Loader Class Initialized
INFO - 2020-09-13 00:38:05 --> Helper loaded: url_helper
INFO - 2020-09-13 00:38:05 --> Helper loaded: form_helper
INFO - 2020-09-13 00:38:05 --> Helper loaded: file_helper
INFO - 2020-09-13 00:38:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 00:38:05 --> Database Driver Class Initialized
DEBUG - 2020-09-13 00:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 00:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 00:38:05 --> Upload Class Initialized
INFO - 2020-09-13 00:38:05 --> Controller Class Initialized
DEBUG - 2020-09-13 00:38:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 00:38:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/about.php
DEBUG - 2020-09-13 00:38:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 00:38:05 --> Final output sent to browser
DEBUG - 2020-09-13 00:38:05 --> Total execution time: 0.0522
INFO - 2020-09-13 01:24:44 --> Config Class Initialized
INFO - 2020-09-13 01:24:44 --> Hooks Class Initialized
DEBUG - 2020-09-13 01:24:44 --> UTF-8 Support Enabled
INFO - 2020-09-13 01:24:44 --> Utf8 Class Initialized
INFO - 2020-09-13 01:24:44 --> URI Class Initialized
DEBUG - 2020-09-13 01:24:44 --> No URI present. Default controller set.
INFO - 2020-09-13 01:24:44 --> Router Class Initialized
INFO - 2020-09-13 01:24:44 --> Output Class Initialized
INFO - 2020-09-13 01:24:44 --> Security Class Initialized
DEBUG - 2020-09-13 01:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 01:24:44 --> Input Class Initialized
INFO - 2020-09-13 01:24:44 --> Language Class Initialized
INFO - 2020-09-13 01:24:44 --> Language Class Initialized
INFO - 2020-09-13 01:24:44 --> Config Class Initialized
INFO - 2020-09-13 01:24:44 --> Loader Class Initialized
INFO - 2020-09-13 01:24:44 --> Helper loaded: url_helper
INFO - 2020-09-13 01:24:44 --> Helper loaded: form_helper
INFO - 2020-09-13 01:24:44 --> Helper loaded: file_helper
INFO - 2020-09-13 01:24:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 01:24:44 --> Database Driver Class Initialized
DEBUG - 2020-09-13 01:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 01:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 01:24:44 --> Upload Class Initialized
INFO - 2020-09-13 01:24:44 --> Controller Class Initialized
DEBUG - 2020-09-13 01:24:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 01:24:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 01:24:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 01:24:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 01:24:44 --> Final output sent to browser
DEBUG - 2020-09-13 01:24:44 --> Total execution time: 0.0497
INFO - 2020-09-13 01:26:56 --> Config Class Initialized
INFO - 2020-09-13 01:26:56 --> Hooks Class Initialized
DEBUG - 2020-09-13 01:26:56 --> UTF-8 Support Enabled
INFO - 2020-09-13 01:26:56 --> Utf8 Class Initialized
INFO - 2020-09-13 01:26:56 --> URI Class Initialized
INFO - 2020-09-13 01:26:56 --> Router Class Initialized
INFO - 2020-09-13 01:26:56 --> Output Class Initialized
INFO - 2020-09-13 01:26:56 --> Security Class Initialized
DEBUG - 2020-09-13 01:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 01:26:56 --> Input Class Initialized
INFO - 2020-09-13 01:26:56 --> Language Class Initialized
INFO - 2020-09-13 01:26:56 --> Language Class Initialized
INFO - 2020-09-13 01:26:56 --> Config Class Initialized
INFO - 2020-09-13 01:26:56 --> Loader Class Initialized
INFO - 2020-09-13 01:26:56 --> Helper loaded: url_helper
INFO - 2020-09-13 01:26:56 --> Helper loaded: form_helper
INFO - 2020-09-13 01:26:56 --> Helper loaded: file_helper
INFO - 2020-09-13 01:26:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 01:26:56 --> Database Driver Class Initialized
DEBUG - 2020-09-13 01:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 01:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 01:26:56 --> Upload Class Initialized
INFO - 2020-09-13 01:26:56 --> Controller Class Initialized
ERROR - 2020-09-13 01:26:56 --> 404 Page Not Found: /index
INFO - 2020-09-13 01:26:58 --> Config Class Initialized
INFO - 2020-09-13 01:26:58 --> Hooks Class Initialized
DEBUG - 2020-09-13 01:26:58 --> UTF-8 Support Enabled
INFO - 2020-09-13 01:26:58 --> Utf8 Class Initialized
INFO - 2020-09-13 01:26:58 --> URI Class Initialized
DEBUG - 2020-09-13 01:26:58 --> No URI present. Default controller set.
INFO - 2020-09-13 01:26:58 --> Router Class Initialized
INFO - 2020-09-13 01:26:58 --> Output Class Initialized
INFO - 2020-09-13 01:26:58 --> Security Class Initialized
DEBUG - 2020-09-13 01:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 01:26:58 --> Input Class Initialized
INFO - 2020-09-13 01:26:58 --> Language Class Initialized
INFO - 2020-09-13 01:26:58 --> Language Class Initialized
INFO - 2020-09-13 01:26:58 --> Config Class Initialized
INFO - 2020-09-13 01:26:58 --> Loader Class Initialized
INFO - 2020-09-13 01:26:58 --> Helper loaded: url_helper
INFO - 2020-09-13 01:26:58 --> Helper loaded: form_helper
INFO - 2020-09-13 01:26:58 --> Helper loaded: file_helper
INFO - 2020-09-13 01:26:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 01:26:58 --> Database Driver Class Initialized
DEBUG - 2020-09-13 01:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 01:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 01:26:58 --> Upload Class Initialized
INFO - 2020-09-13 01:26:58 --> Controller Class Initialized
DEBUG - 2020-09-13 01:26:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 01:26:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 01:26:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 01:26:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 01:26:58 --> Final output sent to browser
DEBUG - 2020-09-13 01:26:58 --> Total execution time: 0.0439
INFO - 2020-09-13 01:55:43 --> Config Class Initialized
INFO - 2020-09-13 01:55:43 --> Hooks Class Initialized
DEBUG - 2020-09-13 01:55:43 --> UTF-8 Support Enabled
INFO - 2020-09-13 01:55:43 --> Utf8 Class Initialized
INFO - 2020-09-13 01:55:43 --> URI Class Initialized
DEBUG - 2020-09-13 01:55:43 --> No URI present. Default controller set.
INFO - 2020-09-13 01:55:43 --> Router Class Initialized
INFO - 2020-09-13 01:55:43 --> Output Class Initialized
INFO - 2020-09-13 01:55:43 --> Security Class Initialized
DEBUG - 2020-09-13 01:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 01:55:43 --> Input Class Initialized
INFO - 2020-09-13 01:55:43 --> Language Class Initialized
INFO - 2020-09-13 01:55:43 --> Language Class Initialized
INFO - 2020-09-13 01:55:43 --> Config Class Initialized
INFO - 2020-09-13 01:55:43 --> Loader Class Initialized
INFO - 2020-09-13 01:55:43 --> Helper loaded: url_helper
INFO - 2020-09-13 01:55:43 --> Helper loaded: form_helper
INFO - 2020-09-13 01:55:43 --> Helper loaded: file_helper
INFO - 2020-09-13 01:55:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 01:55:43 --> Database Driver Class Initialized
DEBUG - 2020-09-13 01:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 01:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 01:55:43 --> Upload Class Initialized
INFO - 2020-09-13 01:55:43 --> Controller Class Initialized
DEBUG - 2020-09-13 01:55:43 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 01:55:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 01:55:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 01:55:43 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 01:55:43 --> Final output sent to browser
DEBUG - 2020-09-13 01:55:43 --> Total execution time: 0.0425
INFO - 2020-09-13 02:26:37 --> Config Class Initialized
INFO - 2020-09-13 02:26:37 --> Hooks Class Initialized
DEBUG - 2020-09-13 02:26:37 --> UTF-8 Support Enabled
INFO - 2020-09-13 02:26:37 --> Utf8 Class Initialized
INFO - 2020-09-13 02:26:37 --> URI Class Initialized
DEBUG - 2020-09-13 02:26:37 --> No URI present. Default controller set.
INFO - 2020-09-13 02:26:37 --> Router Class Initialized
INFO - 2020-09-13 02:26:37 --> Output Class Initialized
INFO - 2020-09-13 02:26:37 --> Security Class Initialized
DEBUG - 2020-09-13 02:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 02:26:37 --> Input Class Initialized
INFO - 2020-09-13 02:26:37 --> Language Class Initialized
INFO - 2020-09-13 02:26:37 --> Language Class Initialized
INFO - 2020-09-13 02:26:37 --> Config Class Initialized
INFO - 2020-09-13 02:26:37 --> Loader Class Initialized
INFO - 2020-09-13 02:26:37 --> Helper loaded: url_helper
INFO - 2020-09-13 02:26:37 --> Helper loaded: form_helper
INFO - 2020-09-13 02:26:37 --> Helper loaded: file_helper
INFO - 2020-09-13 02:26:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 02:26:37 --> Database Driver Class Initialized
DEBUG - 2020-09-13 02:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 02:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 02:26:37 --> Upload Class Initialized
INFO - 2020-09-13 02:26:37 --> Controller Class Initialized
DEBUG - 2020-09-13 02:26:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 02:26:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 02:26:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 02:26:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 02:26:37 --> Final output sent to browser
DEBUG - 2020-09-13 02:26:37 --> Total execution time: 0.0636
INFO - 2020-09-13 02:26:48 --> Config Class Initialized
INFO - 2020-09-13 02:26:48 --> Hooks Class Initialized
DEBUG - 2020-09-13 02:26:48 --> UTF-8 Support Enabled
INFO - 2020-09-13 02:26:48 --> Utf8 Class Initialized
INFO - 2020-09-13 02:26:48 --> URI Class Initialized
DEBUG - 2020-09-13 02:26:48 --> No URI present. Default controller set.
INFO - 2020-09-13 02:26:48 --> Router Class Initialized
INFO - 2020-09-13 02:26:48 --> Output Class Initialized
INFO - 2020-09-13 02:26:48 --> Security Class Initialized
DEBUG - 2020-09-13 02:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 02:26:48 --> Input Class Initialized
INFO - 2020-09-13 02:26:48 --> Language Class Initialized
INFO - 2020-09-13 02:26:48 --> Language Class Initialized
INFO - 2020-09-13 02:26:48 --> Config Class Initialized
INFO - 2020-09-13 02:26:48 --> Loader Class Initialized
INFO - 2020-09-13 02:26:48 --> Helper loaded: url_helper
INFO - 2020-09-13 02:26:48 --> Helper loaded: form_helper
INFO - 2020-09-13 02:26:48 --> Helper loaded: file_helper
INFO - 2020-09-13 02:26:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 02:26:48 --> Database Driver Class Initialized
DEBUG - 2020-09-13 02:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 02:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 02:26:48 --> Upload Class Initialized
INFO - 2020-09-13 02:26:48 --> Controller Class Initialized
DEBUG - 2020-09-13 02:26:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 02:26:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 02:26:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 02:26:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 02:26:48 --> Final output sent to browser
DEBUG - 2020-09-13 02:26:48 --> Total execution time: 0.0509
INFO - 2020-09-13 03:23:40 --> Config Class Initialized
INFO - 2020-09-13 03:23:40 --> Hooks Class Initialized
DEBUG - 2020-09-13 03:23:40 --> UTF-8 Support Enabled
INFO - 2020-09-13 03:23:40 --> Utf8 Class Initialized
INFO - 2020-09-13 03:23:40 --> URI Class Initialized
INFO - 2020-09-13 03:23:40 --> Router Class Initialized
INFO - 2020-09-13 03:23:40 --> Output Class Initialized
INFO - 2020-09-13 03:23:40 --> Security Class Initialized
DEBUG - 2020-09-13 03:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 03:23:40 --> Input Class Initialized
INFO - 2020-09-13 03:23:40 --> Language Class Initialized
INFO - 2020-09-13 03:23:40 --> Language Class Initialized
INFO - 2020-09-13 03:23:40 --> Config Class Initialized
INFO - 2020-09-13 03:23:40 --> Loader Class Initialized
INFO - 2020-09-13 03:23:40 --> Helper loaded: url_helper
INFO - 2020-09-13 03:23:40 --> Helper loaded: form_helper
INFO - 2020-09-13 03:23:40 --> Helper loaded: file_helper
INFO - 2020-09-13 03:23:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 03:23:40 --> Database Driver Class Initialized
DEBUG - 2020-09-13 03:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 03:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 03:23:40 --> Upload Class Initialized
INFO - 2020-09-13 03:23:40 --> Controller Class Initialized
ERROR - 2020-09-13 03:23:40 --> 404 Page Not Found: /index
INFO - 2020-09-13 03:25:31 --> Config Class Initialized
INFO - 2020-09-13 03:25:31 --> Hooks Class Initialized
DEBUG - 2020-09-13 03:25:31 --> UTF-8 Support Enabled
INFO - 2020-09-13 03:25:31 --> Utf8 Class Initialized
INFO - 2020-09-13 03:25:32 --> URI Class Initialized
INFO - 2020-09-13 03:25:32 --> Router Class Initialized
INFO - 2020-09-13 03:25:32 --> Output Class Initialized
INFO - 2020-09-13 03:25:32 --> Security Class Initialized
DEBUG - 2020-09-13 03:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 03:25:32 --> Input Class Initialized
INFO - 2020-09-13 03:25:32 --> Language Class Initialized
INFO - 2020-09-13 03:25:32 --> Language Class Initialized
INFO - 2020-09-13 03:25:32 --> Config Class Initialized
INFO - 2020-09-13 03:25:32 --> Loader Class Initialized
INFO - 2020-09-13 03:25:32 --> Helper loaded: url_helper
INFO - 2020-09-13 03:25:32 --> Helper loaded: form_helper
INFO - 2020-09-13 03:25:32 --> Helper loaded: file_helper
INFO - 2020-09-13 03:25:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 03:25:32 --> Database Driver Class Initialized
DEBUG - 2020-09-13 03:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 03:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 03:25:32 --> Upload Class Initialized
INFO - 2020-09-13 03:25:32 --> Controller Class Initialized
ERROR - 2020-09-13 03:25:32 --> 404 Page Not Found: /index
INFO - 2020-09-13 04:08:44 --> Config Class Initialized
INFO - 2020-09-13 04:08:44 --> Hooks Class Initialized
DEBUG - 2020-09-13 04:08:44 --> UTF-8 Support Enabled
INFO - 2020-09-13 04:08:44 --> Utf8 Class Initialized
INFO - 2020-09-13 04:08:44 --> URI Class Initialized
DEBUG - 2020-09-13 04:08:44 --> No URI present. Default controller set.
INFO - 2020-09-13 04:08:44 --> Router Class Initialized
INFO - 2020-09-13 04:08:44 --> Output Class Initialized
INFO - 2020-09-13 04:08:44 --> Security Class Initialized
DEBUG - 2020-09-13 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 04:08:44 --> Input Class Initialized
INFO - 2020-09-13 04:08:44 --> Language Class Initialized
INFO - 2020-09-13 04:08:44 --> Language Class Initialized
INFO - 2020-09-13 04:08:44 --> Config Class Initialized
INFO - 2020-09-13 04:08:44 --> Loader Class Initialized
INFO - 2020-09-13 04:08:44 --> Helper loaded: url_helper
INFO - 2020-09-13 04:08:44 --> Helper loaded: form_helper
INFO - 2020-09-13 04:08:44 --> Helper loaded: file_helper
INFO - 2020-09-13 04:08:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 04:08:44 --> Database Driver Class Initialized
DEBUG - 2020-09-13 04:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 04:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 04:08:44 --> Upload Class Initialized
INFO - 2020-09-13 04:08:44 --> Controller Class Initialized
DEBUG - 2020-09-13 04:08:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 04:08:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 04:08:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 04:08:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 04:08:44 --> Final output sent to browser
DEBUG - 2020-09-13 04:08:44 --> Total execution time: 0.0444
INFO - 2020-09-13 05:54:37 --> Config Class Initialized
INFO - 2020-09-13 05:54:37 --> Hooks Class Initialized
DEBUG - 2020-09-13 05:54:37 --> UTF-8 Support Enabled
INFO - 2020-09-13 05:54:37 --> Utf8 Class Initialized
INFO - 2020-09-13 05:54:37 --> URI Class Initialized
DEBUG - 2020-09-13 05:54:37 --> No URI present. Default controller set.
INFO - 2020-09-13 05:54:37 --> Router Class Initialized
INFO - 2020-09-13 05:54:37 --> Output Class Initialized
INFO - 2020-09-13 05:54:37 --> Security Class Initialized
DEBUG - 2020-09-13 05:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 05:54:37 --> Input Class Initialized
INFO - 2020-09-13 05:54:37 --> Language Class Initialized
INFO - 2020-09-13 05:54:37 --> Language Class Initialized
INFO - 2020-09-13 05:54:37 --> Config Class Initialized
INFO - 2020-09-13 05:54:37 --> Loader Class Initialized
INFO - 2020-09-13 05:54:37 --> Helper loaded: url_helper
INFO - 2020-09-13 05:54:37 --> Helper loaded: form_helper
INFO - 2020-09-13 05:54:37 --> Helper loaded: file_helper
INFO - 2020-09-13 05:54:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 05:54:37 --> Database Driver Class Initialized
DEBUG - 2020-09-13 05:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 05:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 05:54:37 --> Upload Class Initialized
INFO - 2020-09-13 05:54:37 --> Controller Class Initialized
DEBUG - 2020-09-13 05:54:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 05:54:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 05:54:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 05:54:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 05:54:37 --> Final output sent to browser
DEBUG - 2020-09-13 05:54:37 --> Total execution time: 0.0440
INFO - 2020-09-13 05:56:39 --> Config Class Initialized
INFO - 2020-09-13 05:56:39 --> Hooks Class Initialized
DEBUG - 2020-09-13 05:56:39 --> UTF-8 Support Enabled
INFO - 2020-09-13 05:56:39 --> Utf8 Class Initialized
INFO - 2020-09-13 05:56:39 --> URI Class Initialized
DEBUG - 2020-09-13 05:56:39 --> No URI present. Default controller set.
INFO - 2020-09-13 05:56:39 --> Router Class Initialized
INFO - 2020-09-13 05:56:39 --> Output Class Initialized
INFO - 2020-09-13 05:56:39 --> Security Class Initialized
DEBUG - 2020-09-13 05:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 05:56:39 --> Input Class Initialized
INFO - 2020-09-13 05:56:39 --> Language Class Initialized
INFO - 2020-09-13 05:56:39 --> Language Class Initialized
INFO - 2020-09-13 05:56:39 --> Config Class Initialized
INFO - 2020-09-13 05:56:39 --> Loader Class Initialized
INFO - 2020-09-13 05:56:39 --> Helper loaded: url_helper
INFO - 2020-09-13 05:56:39 --> Helper loaded: form_helper
INFO - 2020-09-13 05:56:39 --> Helper loaded: file_helper
INFO - 2020-09-13 05:56:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 05:56:39 --> Database Driver Class Initialized
DEBUG - 2020-09-13 05:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 05:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 05:56:39 --> Upload Class Initialized
INFO - 2020-09-13 05:56:39 --> Controller Class Initialized
DEBUG - 2020-09-13 05:56:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 05:56:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 05:56:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 05:56:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 05:56:39 --> Final output sent to browser
DEBUG - 2020-09-13 05:56:39 --> Total execution time: 0.0498
INFO - 2020-09-13 06:02:55 --> Config Class Initialized
INFO - 2020-09-13 06:02:55 --> Hooks Class Initialized
DEBUG - 2020-09-13 06:02:55 --> UTF-8 Support Enabled
INFO - 2020-09-13 06:02:55 --> Utf8 Class Initialized
INFO - 2020-09-13 06:02:55 --> URI Class Initialized
INFO - 2020-09-13 06:02:55 --> Router Class Initialized
INFO - 2020-09-13 06:02:55 --> Output Class Initialized
INFO - 2020-09-13 06:02:55 --> Security Class Initialized
DEBUG - 2020-09-13 06:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 06:02:55 --> Input Class Initialized
INFO - 2020-09-13 06:02:55 --> Language Class Initialized
INFO - 2020-09-13 06:02:55 --> Language Class Initialized
INFO - 2020-09-13 06:02:55 --> Config Class Initialized
INFO - 2020-09-13 06:02:55 --> Loader Class Initialized
INFO - 2020-09-13 06:02:55 --> Helper loaded: url_helper
INFO - 2020-09-13 06:02:55 --> Helper loaded: form_helper
INFO - 2020-09-13 06:02:55 --> Helper loaded: file_helper
INFO - 2020-09-13 06:02:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 06:02:55 --> Database Driver Class Initialized
DEBUG - 2020-09-13 06:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 06:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 06:02:55 --> Upload Class Initialized
INFO - 2020-09-13 06:02:55 --> Controller Class Initialized
ERROR - 2020-09-13 06:02:55 --> 404 Page Not Found: /index
INFO - 2020-09-13 06:21:11 --> Config Class Initialized
INFO - 2020-09-13 06:21:11 --> Hooks Class Initialized
DEBUG - 2020-09-13 06:21:11 --> UTF-8 Support Enabled
INFO - 2020-09-13 06:21:11 --> Utf8 Class Initialized
INFO - 2020-09-13 06:21:11 --> URI Class Initialized
DEBUG - 2020-09-13 06:21:11 --> No URI present. Default controller set.
INFO - 2020-09-13 06:21:11 --> Router Class Initialized
INFO - 2020-09-13 06:21:11 --> Output Class Initialized
INFO - 2020-09-13 06:21:11 --> Security Class Initialized
DEBUG - 2020-09-13 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 06:21:11 --> Input Class Initialized
INFO - 2020-09-13 06:21:11 --> Language Class Initialized
INFO - 2020-09-13 06:21:11 --> Language Class Initialized
INFO - 2020-09-13 06:21:11 --> Config Class Initialized
INFO - 2020-09-13 06:21:11 --> Loader Class Initialized
INFO - 2020-09-13 06:21:11 --> Helper loaded: url_helper
INFO - 2020-09-13 06:21:11 --> Helper loaded: form_helper
INFO - 2020-09-13 06:21:11 --> Helper loaded: file_helper
INFO - 2020-09-13 06:21:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 06:21:11 --> Database Driver Class Initialized
DEBUG - 2020-09-13 06:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 06:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 06:21:11 --> Upload Class Initialized
INFO - 2020-09-13 06:21:11 --> Controller Class Initialized
DEBUG - 2020-09-13 06:21:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 06:21:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 06:21:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 06:21:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 06:21:11 --> Final output sent to browser
DEBUG - 2020-09-13 06:21:11 --> Total execution time: 0.0579
INFO - 2020-09-13 06:32:45 --> Config Class Initialized
INFO - 2020-09-13 06:32:45 --> Hooks Class Initialized
DEBUG - 2020-09-13 06:32:45 --> UTF-8 Support Enabled
INFO - 2020-09-13 06:32:45 --> Utf8 Class Initialized
INFO - 2020-09-13 06:32:45 --> URI Class Initialized
INFO - 2020-09-13 06:32:45 --> Router Class Initialized
INFO - 2020-09-13 06:32:45 --> Output Class Initialized
INFO - 2020-09-13 06:32:45 --> Security Class Initialized
DEBUG - 2020-09-13 06:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 06:32:45 --> Input Class Initialized
INFO - 2020-09-13 06:32:45 --> Language Class Initialized
INFO - 2020-09-13 06:32:45 --> Language Class Initialized
INFO - 2020-09-13 06:32:45 --> Config Class Initialized
INFO - 2020-09-13 06:32:45 --> Loader Class Initialized
INFO - 2020-09-13 06:32:45 --> Helper loaded: url_helper
INFO - 2020-09-13 06:32:45 --> Helper loaded: form_helper
INFO - 2020-09-13 06:32:45 --> Helper loaded: file_helper
INFO - 2020-09-13 06:32:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 06:32:45 --> Database Driver Class Initialized
DEBUG - 2020-09-13 06:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 06:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 06:32:45 --> Upload Class Initialized
INFO - 2020-09-13 06:32:45 --> Controller Class Initialized
ERROR - 2020-09-13 06:32:45 --> 404 Page Not Found: /index
INFO - 2020-09-13 06:32:45 --> Config Class Initialized
INFO - 2020-09-13 06:32:45 --> Hooks Class Initialized
DEBUG - 2020-09-13 06:32:45 --> UTF-8 Support Enabled
INFO - 2020-09-13 06:32:45 --> Utf8 Class Initialized
INFO - 2020-09-13 06:32:45 --> URI Class Initialized
INFO - 2020-09-13 06:32:45 --> Router Class Initialized
INFO - 2020-09-13 06:32:45 --> Output Class Initialized
INFO - 2020-09-13 06:32:45 --> Security Class Initialized
DEBUG - 2020-09-13 06:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 06:32:45 --> Input Class Initialized
INFO - 2020-09-13 06:32:45 --> Language Class Initialized
INFO - 2020-09-13 06:32:45 --> Language Class Initialized
INFO - 2020-09-13 06:32:45 --> Config Class Initialized
INFO - 2020-09-13 06:32:45 --> Loader Class Initialized
INFO - 2020-09-13 06:32:45 --> Helper loaded: url_helper
INFO - 2020-09-13 06:32:45 --> Helper loaded: form_helper
INFO - 2020-09-13 06:32:45 --> Helper loaded: file_helper
INFO - 2020-09-13 06:32:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 06:32:45 --> Database Driver Class Initialized
DEBUG - 2020-09-13 06:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 06:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 06:32:45 --> Upload Class Initialized
INFO - 2020-09-13 06:32:45 --> Controller Class Initialized
ERROR - 2020-09-13 06:32:45 --> 404 Page Not Found: /index
INFO - 2020-09-13 06:51:46 --> Config Class Initialized
INFO - 2020-09-13 06:51:46 --> Hooks Class Initialized
DEBUG - 2020-09-13 06:51:46 --> UTF-8 Support Enabled
INFO - 2020-09-13 06:51:46 --> Utf8 Class Initialized
INFO - 2020-09-13 06:51:46 --> URI Class Initialized
DEBUG - 2020-09-13 06:51:46 --> No URI present. Default controller set.
INFO - 2020-09-13 06:51:46 --> Router Class Initialized
INFO - 2020-09-13 06:51:46 --> Output Class Initialized
INFO - 2020-09-13 06:51:46 --> Security Class Initialized
DEBUG - 2020-09-13 06:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 06:51:46 --> Input Class Initialized
INFO - 2020-09-13 06:51:46 --> Language Class Initialized
INFO - 2020-09-13 06:51:46 --> Language Class Initialized
INFO - 2020-09-13 06:51:46 --> Config Class Initialized
INFO - 2020-09-13 06:51:46 --> Loader Class Initialized
INFO - 2020-09-13 06:51:46 --> Helper loaded: url_helper
INFO - 2020-09-13 06:51:46 --> Helper loaded: form_helper
INFO - 2020-09-13 06:51:46 --> Helper loaded: file_helper
INFO - 2020-09-13 06:51:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 06:51:46 --> Database Driver Class Initialized
DEBUG - 2020-09-13 06:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 06:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 06:51:46 --> Upload Class Initialized
INFO - 2020-09-13 06:51:46 --> Controller Class Initialized
DEBUG - 2020-09-13 06:51:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 06:51:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 06:51:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 06:51:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 06:51:46 --> Final output sent to browser
DEBUG - 2020-09-13 06:51:46 --> Total execution time: 0.0522
INFO - 2020-09-13 07:02:17 --> Config Class Initialized
INFO - 2020-09-13 07:02:17 --> Hooks Class Initialized
DEBUG - 2020-09-13 07:02:17 --> UTF-8 Support Enabled
INFO - 2020-09-13 07:02:17 --> Utf8 Class Initialized
INFO - 2020-09-13 07:02:17 --> URI Class Initialized
DEBUG - 2020-09-13 07:02:17 --> No URI present. Default controller set.
INFO - 2020-09-13 07:02:17 --> Router Class Initialized
INFO - 2020-09-13 07:02:17 --> Output Class Initialized
INFO - 2020-09-13 07:02:17 --> Security Class Initialized
DEBUG - 2020-09-13 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 07:02:17 --> Input Class Initialized
INFO - 2020-09-13 07:02:17 --> Language Class Initialized
INFO - 2020-09-13 07:02:17 --> Language Class Initialized
INFO - 2020-09-13 07:02:17 --> Config Class Initialized
INFO - 2020-09-13 07:02:17 --> Loader Class Initialized
INFO - 2020-09-13 07:02:17 --> Helper loaded: url_helper
INFO - 2020-09-13 07:02:17 --> Helper loaded: form_helper
INFO - 2020-09-13 07:02:17 --> Helper loaded: file_helper
INFO - 2020-09-13 07:02:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 07:02:17 --> Database Driver Class Initialized
DEBUG - 2020-09-13 07:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 07:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 07:02:17 --> Upload Class Initialized
INFO - 2020-09-13 07:02:17 --> Controller Class Initialized
DEBUG - 2020-09-13 07:02:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 07:02:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 07:02:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 07:02:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 07:02:17 --> Final output sent to browser
DEBUG - 2020-09-13 07:02:17 --> Total execution time: 0.0610
INFO - 2020-09-13 07:11:31 --> Config Class Initialized
INFO - 2020-09-13 07:11:31 --> Hooks Class Initialized
DEBUG - 2020-09-13 07:11:31 --> UTF-8 Support Enabled
INFO - 2020-09-13 07:11:31 --> Utf8 Class Initialized
INFO - 2020-09-13 07:11:31 --> URI Class Initialized
INFO - 2020-09-13 07:11:31 --> Router Class Initialized
INFO - 2020-09-13 07:11:31 --> Output Class Initialized
INFO - 2020-09-13 07:11:31 --> Security Class Initialized
DEBUG - 2020-09-13 07:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 07:11:31 --> Input Class Initialized
INFO - 2020-09-13 07:11:31 --> Language Class Initialized
INFO - 2020-09-13 07:11:31 --> Language Class Initialized
INFO - 2020-09-13 07:11:31 --> Config Class Initialized
INFO - 2020-09-13 07:11:31 --> Loader Class Initialized
INFO - 2020-09-13 07:11:31 --> Helper loaded: url_helper
INFO - 2020-09-13 07:11:31 --> Helper loaded: form_helper
INFO - 2020-09-13 07:11:31 --> Helper loaded: file_helper
INFO - 2020-09-13 07:11:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 07:11:31 --> Database Driver Class Initialized
DEBUG - 2020-09-13 07:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 07:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 07:11:31 --> Upload Class Initialized
INFO - 2020-09-13 07:11:31 --> Controller Class Initialized
ERROR - 2020-09-13 07:11:31 --> 404 Page Not Found: /index
INFO - 2020-09-13 07:11:34 --> Config Class Initialized
INFO - 2020-09-13 07:11:34 --> Hooks Class Initialized
DEBUG - 2020-09-13 07:11:34 --> UTF-8 Support Enabled
INFO - 2020-09-13 07:11:34 --> Utf8 Class Initialized
INFO - 2020-09-13 07:11:34 --> URI Class Initialized
INFO - 2020-09-13 07:11:34 --> Router Class Initialized
INFO - 2020-09-13 07:11:34 --> Output Class Initialized
INFO - 2020-09-13 07:11:34 --> Security Class Initialized
DEBUG - 2020-09-13 07:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 07:11:34 --> Input Class Initialized
INFO - 2020-09-13 07:11:34 --> Language Class Initialized
INFO - 2020-09-13 07:11:34 --> Language Class Initialized
INFO - 2020-09-13 07:11:34 --> Config Class Initialized
INFO - 2020-09-13 07:11:34 --> Loader Class Initialized
INFO - 2020-09-13 07:11:34 --> Helper loaded: url_helper
INFO - 2020-09-13 07:11:34 --> Helper loaded: form_helper
INFO - 2020-09-13 07:11:34 --> Helper loaded: file_helper
INFO - 2020-09-13 07:11:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 07:11:34 --> Database Driver Class Initialized
DEBUG - 2020-09-13 07:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 07:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 07:11:34 --> Upload Class Initialized
INFO - 2020-09-13 07:11:34 --> Controller Class Initialized
ERROR - 2020-09-13 07:11:34 --> 404 Page Not Found: /index
INFO - 2020-09-13 07:26:23 --> Config Class Initialized
INFO - 2020-09-13 07:26:23 --> Hooks Class Initialized
DEBUG - 2020-09-13 07:26:23 --> UTF-8 Support Enabled
INFO - 2020-09-13 07:26:23 --> Utf8 Class Initialized
INFO - 2020-09-13 07:26:23 --> URI Class Initialized
DEBUG - 2020-09-13 07:26:23 --> No URI present. Default controller set.
INFO - 2020-09-13 07:26:23 --> Router Class Initialized
INFO - 2020-09-13 07:26:23 --> Output Class Initialized
INFO - 2020-09-13 07:26:23 --> Security Class Initialized
DEBUG - 2020-09-13 07:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 07:26:23 --> Input Class Initialized
INFO - 2020-09-13 07:26:23 --> Language Class Initialized
INFO - 2020-09-13 07:26:23 --> Language Class Initialized
INFO - 2020-09-13 07:26:23 --> Config Class Initialized
INFO - 2020-09-13 07:26:23 --> Loader Class Initialized
INFO - 2020-09-13 07:26:23 --> Helper loaded: url_helper
INFO - 2020-09-13 07:26:23 --> Helper loaded: form_helper
INFO - 2020-09-13 07:26:23 --> Helper loaded: file_helper
INFO - 2020-09-13 07:26:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 07:26:23 --> Database Driver Class Initialized
DEBUG - 2020-09-13 07:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 07:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 07:26:23 --> Upload Class Initialized
INFO - 2020-09-13 07:26:23 --> Controller Class Initialized
DEBUG - 2020-09-13 07:26:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 07:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 07:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 07:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 07:26:23 --> Final output sent to browser
DEBUG - 2020-09-13 07:26:23 --> Total execution time: 0.0682
INFO - 2020-09-13 07:26:25 --> Config Class Initialized
INFO - 2020-09-13 07:26:25 --> Hooks Class Initialized
DEBUG - 2020-09-13 07:26:25 --> UTF-8 Support Enabled
INFO - 2020-09-13 07:26:25 --> Utf8 Class Initialized
INFO - 2020-09-13 07:26:25 --> URI Class Initialized
INFO - 2020-09-13 07:26:25 --> Router Class Initialized
INFO - 2020-09-13 07:26:25 --> Output Class Initialized
INFO - 2020-09-13 07:26:25 --> Security Class Initialized
DEBUG - 2020-09-13 07:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 07:26:25 --> Input Class Initialized
INFO - 2020-09-13 07:26:25 --> Language Class Initialized
INFO - 2020-09-13 07:26:25 --> Language Class Initialized
INFO - 2020-09-13 07:26:25 --> Config Class Initialized
INFO - 2020-09-13 07:26:25 --> Loader Class Initialized
INFO - 2020-09-13 07:26:25 --> Helper loaded: url_helper
INFO - 2020-09-13 07:26:25 --> Helper loaded: form_helper
INFO - 2020-09-13 07:26:25 --> Helper loaded: file_helper
INFO - 2020-09-13 07:26:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 07:26:25 --> Database Driver Class Initialized
DEBUG - 2020-09-13 07:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 07:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 07:26:25 --> Upload Class Initialized
INFO - 2020-09-13 07:26:25 --> Controller Class Initialized
ERROR - 2020-09-13 07:26:25 --> 404 Page Not Found: /index
INFO - 2020-09-13 09:09:50 --> Config Class Initialized
INFO - 2020-09-13 09:09:50 --> Hooks Class Initialized
DEBUG - 2020-09-13 09:09:50 --> UTF-8 Support Enabled
INFO - 2020-09-13 09:09:50 --> Utf8 Class Initialized
INFO - 2020-09-13 09:09:50 --> URI Class Initialized
INFO - 2020-09-13 09:09:50 --> Router Class Initialized
INFO - 2020-09-13 09:09:50 --> Output Class Initialized
INFO - 2020-09-13 09:09:50 --> Security Class Initialized
DEBUG - 2020-09-13 09:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 09:09:50 --> Input Class Initialized
INFO - 2020-09-13 09:09:50 --> Language Class Initialized
INFO - 2020-09-13 09:09:50 --> Language Class Initialized
INFO - 2020-09-13 09:09:50 --> Config Class Initialized
INFO - 2020-09-13 09:09:50 --> Loader Class Initialized
INFO - 2020-09-13 09:09:50 --> Helper loaded: url_helper
INFO - 2020-09-13 09:09:50 --> Helper loaded: form_helper
INFO - 2020-09-13 09:09:50 --> Helper loaded: file_helper
INFO - 2020-09-13 09:09:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 09:09:50 --> Database Driver Class Initialized
DEBUG - 2020-09-13 09:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 09:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 09:09:50 --> Upload Class Initialized
INFO - 2020-09-13 09:09:50 --> Controller Class Initialized
ERROR - 2020-09-13 09:09:50 --> 404 Page Not Found: /index
INFO - 2020-09-13 09:44:02 --> Config Class Initialized
INFO - 2020-09-13 09:44:02 --> Hooks Class Initialized
DEBUG - 2020-09-13 09:44:02 --> UTF-8 Support Enabled
INFO - 2020-09-13 09:44:02 --> Utf8 Class Initialized
INFO - 2020-09-13 09:44:02 --> URI Class Initialized
DEBUG - 2020-09-13 09:44:02 --> No URI present. Default controller set.
INFO - 2020-09-13 09:44:02 --> Router Class Initialized
INFO - 2020-09-13 09:44:02 --> Output Class Initialized
INFO - 2020-09-13 09:44:02 --> Security Class Initialized
DEBUG - 2020-09-13 09:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 09:44:02 --> Input Class Initialized
INFO - 2020-09-13 09:44:02 --> Language Class Initialized
INFO - 2020-09-13 09:44:02 --> Language Class Initialized
INFO - 2020-09-13 09:44:02 --> Config Class Initialized
INFO - 2020-09-13 09:44:02 --> Loader Class Initialized
INFO - 2020-09-13 09:44:02 --> Helper loaded: url_helper
INFO - 2020-09-13 09:44:02 --> Helper loaded: form_helper
INFO - 2020-09-13 09:44:02 --> Helper loaded: file_helper
INFO - 2020-09-13 09:44:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 09:44:02 --> Database Driver Class Initialized
DEBUG - 2020-09-13 09:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 09:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 09:44:02 --> Upload Class Initialized
INFO - 2020-09-13 09:44:02 --> Controller Class Initialized
DEBUG - 2020-09-13 09:44:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 09:44:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 09:44:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 09:44:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 09:44:02 --> Final output sent to browser
DEBUG - 2020-09-13 09:44:02 --> Total execution time: 0.1707
INFO - 2020-09-13 09:58:58 --> Config Class Initialized
INFO - 2020-09-13 09:58:58 --> Hooks Class Initialized
DEBUG - 2020-09-13 09:58:58 --> UTF-8 Support Enabled
INFO - 2020-09-13 09:58:58 --> Utf8 Class Initialized
INFO - 2020-09-13 09:58:58 --> URI Class Initialized
INFO - 2020-09-13 09:58:58 --> Router Class Initialized
INFO - 2020-09-13 09:58:58 --> Output Class Initialized
INFO - 2020-09-13 09:58:58 --> Security Class Initialized
DEBUG - 2020-09-13 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 09:58:58 --> Input Class Initialized
INFO - 2020-09-13 09:58:58 --> Language Class Initialized
INFO - 2020-09-13 09:58:58 --> Language Class Initialized
INFO - 2020-09-13 09:58:58 --> Config Class Initialized
INFO - 2020-09-13 09:58:58 --> Loader Class Initialized
INFO - 2020-09-13 09:58:58 --> Helper loaded: url_helper
INFO - 2020-09-13 09:58:58 --> Helper loaded: form_helper
INFO - 2020-09-13 09:58:58 --> Helper loaded: file_helper
INFO - 2020-09-13 09:58:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 09:58:58 --> Database Driver Class Initialized
DEBUG - 2020-09-13 09:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 09:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 09:58:58 --> Upload Class Initialized
INFO - 2020-09-13 09:58:58 --> Controller Class Initialized
ERROR - 2020-09-13 09:58:58 --> 404 Page Not Found: /index
INFO - 2020-09-13 09:59:00 --> Config Class Initialized
INFO - 2020-09-13 09:59:00 --> Hooks Class Initialized
DEBUG - 2020-09-13 09:59:00 --> UTF-8 Support Enabled
INFO - 2020-09-13 09:59:00 --> Utf8 Class Initialized
INFO - 2020-09-13 09:59:00 --> URI Class Initialized
DEBUG - 2020-09-13 09:59:00 --> No URI present. Default controller set.
INFO - 2020-09-13 09:59:00 --> Router Class Initialized
INFO - 2020-09-13 09:59:00 --> Output Class Initialized
INFO - 2020-09-13 09:59:00 --> Security Class Initialized
DEBUG - 2020-09-13 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 09:59:00 --> Input Class Initialized
INFO - 2020-09-13 09:59:00 --> Language Class Initialized
INFO - 2020-09-13 09:59:00 --> Language Class Initialized
INFO - 2020-09-13 09:59:00 --> Config Class Initialized
INFO - 2020-09-13 09:59:00 --> Loader Class Initialized
INFO - 2020-09-13 09:59:00 --> Helper loaded: url_helper
INFO - 2020-09-13 09:59:00 --> Helper loaded: form_helper
INFO - 2020-09-13 09:59:00 --> Helper loaded: file_helper
INFO - 2020-09-13 09:59:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 09:59:00 --> Database Driver Class Initialized
DEBUG - 2020-09-13 09:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 09:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 09:59:00 --> Upload Class Initialized
INFO - 2020-09-13 09:59:00 --> Controller Class Initialized
DEBUG - 2020-09-13 09:59:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 09:59:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 09:59:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 09:59:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 09:59:00 --> Final output sent to browser
DEBUG - 2020-09-13 09:59:00 --> Total execution time: 0.0528
INFO - 2020-09-13 10:11:13 --> Config Class Initialized
INFO - 2020-09-13 10:11:13 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:11:13 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:11:13 --> Utf8 Class Initialized
INFO - 2020-09-13 10:11:13 --> URI Class Initialized
DEBUG - 2020-09-13 10:11:13 --> No URI present. Default controller set.
INFO - 2020-09-13 10:11:13 --> Router Class Initialized
INFO - 2020-09-13 10:11:13 --> Output Class Initialized
INFO - 2020-09-13 10:11:13 --> Security Class Initialized
DEBUG - 2020-09-13 10:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:11:13 --> Input Class Initialized
INFO - 2020-09-13 10:11:13 --> Language Class Initialized
INFO - 2020-09-13 10:11:13 --> Language Class Initialized
INFO - 2020-09-13 10:11:13 --> Config Class Initialized
INFO - 2020-09-13 10:11:13 --> Loader Class Initialized
INFO - 2020-09-13 10:11:13 --> Helper loaded: url_helper
INFO - 2020-09-13 10:11:13 --> Helper loaded: form_helper
INFO - 2020-09-13 10:11:13 --> Helper loaded: file_helper
INFO - 2020-09-13 10:11:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:11:13 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:11:13 --> Upload Class Initialized
INFO - 2020-09-13 10:11:13 --> Controller Class Initialized
DEBUG - 2020-09-13 10:11:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:11:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:11:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:11:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:11:13 --> Final output sent to browser
DEBUG - 2020-09-13 10:11:13 --> Total execution time: 0.0523
INFO - 2020-09-13 10:11:15 --> Config Class Initialized
INFO - 2020-09-13 10:11:15 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:11:15 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:11:15 --> Utf8 Class Initialized
INFO - 2020-09-13 10:11:15 --> URI Class Initialized
INFO - 2020-09-13 10:11:15 --> Router Class Initialized
INFO - 2020-09-13 10:11:15 --> Output Class Initialized
INFO - 2020-09-13 10:11:15 --> Security Class Initialized
DEBUG - 2020-09-13 10:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:11:15 --> Input Class Initialized
INFO - 2020-09-13 10:11:15 --> Language Class Initialized
INFO - 2020-09-13 10:11:15 --> Language Class Initialized
INFO - 2020-09-13 10:11:15 --> Config Class Initialized
INFO - 2020-09-13 10:11:15 --> Loader Class Initialized
INFO - 2020-09-13 10:11:15 --> Helper loaded: url_helper
INFO - 2020-09-13 10:11:15 --> Helper loaded: form_helper
INFO - 2020-09-13 10:11:15 --> Helper loaded: file_helper
INFO - 2020-09-13 10:11:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:11:15 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:11:15 --> Upload Class Initialized
INFO - 2020-09-13 10:11:15 --> Controller Class Initialized
ERROR - 2020-09-13 10:11:15 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:12:18 --> Config Class Initialized
INFO - 2020-09-13 10:12:18 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:12:18 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:12:18 --> Utf8 Class Initialized
INFO - 2020-09-13 10:12:18 --> URI Class Initialized
DEBUG - 2020-09-13 10:12:18 --> No URI present. Default controller set.
INFO - 2020-09-13 10:12:18 --> Router Class Initialized
INFO - 2020-09-13 10:12:18 --> Output Class Initialized
INFO - 2020-09-13 10:12:18 --> Security Class Initialized
DEBUG - 2020-09-13 10:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:12:18 --> Input Class Initialized
INFO - 2020-09-13 10:12:18 --> Language Class Initialized
INFO - 2020-09-13 10:12:18 --> Language Class Initialized
INFO - 2020-09-13 10:12:18 --> Config Class Initialized
INFO - 2020-09-13 10:12:18 --> Loader Class Initialized
INFO - 2020-09-13 10:12:18 --> Helper loaded: url_helper
INFO - 2020-09-13 10:12:18 --> Helper loaded: form_helper
INFO - 2020-09-13 10:12:18 --> Helper loaded: file_helper
INFO - 2020-09-13 10:12:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:12:18 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:12:18 --> Upload Class Initialized
INFO - 2020-09-13 10:12:18 --> Controller Class Initialized
DEBUG - 2020-09-13 10:12:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:12:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:12:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:12:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:12:18 --> Final output sent to browser
DEBUG - 2020-09-13 10:12:18 --> Total execution time: 0.0591
INFO - 2020-09-13 10:13:02 --> Config Class Initialized
INFO - 2020-09-13 10:13:02 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:13:02 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:13:02 --> Utf8 Class Initialized
INFO - 2020-09-13 10:13:02 --> URI Class Initialized
DEBUG - 2020-09-13 10:13:02 --> No URI present. Default controller set.
INFO - 2020-09-13 10:13:02 --> Router Class Initialized
INFO - 2020-09-13 10:13:02 --> Output Class Initialized
INFO - 2020-09-13 10:13:02 --> Security Class Initialized
DEBUG - 2020-09-13 10:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:13:02 --> Input Class Initialized
INFO - 2020-09-13 10:13:02 --> Language Class Initialized
INFO - 2020-09-13 10:13:02 --> Language Class Initialized
INFO - 2020-09-13 10:13:02 --> Config Class Initialized
INFO - 2020-09-13 10:13:02 --> Loader Class Initialized
INFO - 2020-09-13 10:13:02 --> Helper loaded: url_helper
INFO - 2020-09-13 10:13:02 --> Helper loaded: form_helper
INFO - 2020-09-13 10:13:02 --> Helper loaded: file_helper
INFO - 2020-09-13 10:13:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:13:02 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:13:02 --> Upload Class Initialized
INFO - 2020-09-13 10:13:02 --> Controller Class Initialized
DEBUG - 2020-09-13 10:13:02 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:13:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:13:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:13:02 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:13:02 --> Final output sent to browser
DEBUG - 2020-09-13 10:13:02 --> Total execution time: 0.0449
INFO - 2020-09-13 10:13:06 --> Config Class Initialized
INFO - 2020-09-13 10:13:06 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:13:06 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:13:06 --> Utf8 Class Initialized
INFO - 2020-09-13 10:13:06 --> URI Class Initialized
INFO - 2020-09-13 10:13:06 --> Router Class Initialized
INFO - 2020-09-13 10:13:06 --> Output Class Initialized
INFO - 2020-09-13 10:13:06 --> Security Class Initialized
DEBUG - 2020-09-13 10:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:13:06 --> Input Class Initialized
INFO - 2020-09-13 10:13:06 --> Language Class Initialized
INFO - 2020-09-13 10:13:06 --> Language Class Initialized
INFO - 2020-09-13 10:13:06 --> Config Class Initialized
INFO - 2020-09-13 10:13:06 --> Loader Class Initialized
INFO - 2020-09-13 10:13:06 --> Helper loaded: url_helper
INFO - 2020-09-13 10:13:06 --> Helper loaded: form_helper
INFO - 2020-09-13 10:13:06 --> Helper loaded: file_helper
INFO - 2020-09-13 10:13:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:13:06 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:13:06 --> Upload Class Initialized
INFO - 2020-09-13 10:13:06 --> Controller Class Initialized
ERROR - 2020-09-13 10:13:06 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:14:04 --> Config Class Initialized
INFO - 2020-09-13 10:14:04 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:14:04 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:14:04 --> Utf8 Class Initialized
INFO - 2020-09-13 10:14:04 --> URI Class Initialized
DEBUG - 2020-09-13 10:14:04 --> No URI present. Default controller set.
INFO - 2020-09-13 10:14:04 --> Router Class Initialized
INFO - 2020-09-13 10:14:04 --> Output Class Initialized
INFO - 2020-09-13 10:14:04 --> Security Class Initialized
DEBUG - 2020-09-13 10:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:14:04 --> Input Class Initialized
INFO - 2020-09-13 10:14:04 --> Language Class Initialized
INFO - 2020-09-13 10:14:04 --> Language Class Initialized
INFO - 2020-09-13 10:14:04 --> Config Class Initialized
INFO - 2020-09-13 10:14:04 --> Loader Class Initialized
INFO - 2020-09-13 10:14:04 --> Helper loaded: url_helper
INFO - 2020-09-13 10:14:04 --> Helper loaded: form_helper
INFO - 2020-09-13 10:14:04 --> Helper loaded: file_helper
INFO - 2020-09-13 10:14:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:14:04 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:14:04 --> Upload Class Initialized
INFO - 2020-09-13 10:14:04 --> Controller Class Initialized
DEBUG - 2020-09-13 10:14:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:14:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:14:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:14:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:14:04 --> Final output sent to browser
DEBUG - 2020-09-13 10:14:04 --> Total execution time: 0.0368
INFO - 2020-09-13 10:14:28 --> Config Class Initialized
INFO - 2020-09-13 10:14:28 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:14:28 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:14:28 --> Utf8 Class Initialized
INFO - 2020-09-13 10:14:28 --> URI Class Initialized
DEBUG - 2020-09-13 10:14:28 --> No URI present. Default controller set.
INFO - 2020-09-13 10:14:28 --> Router Class Initialized
INFO - 2020-09-13 10:14:28 --> Output Class Initialized
INFO - 2020-09-13 10:14:28 --> Security Class Initialized
DEBUG - 2020-09-13 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:14:28 --> Input Class Initialized
INFO - 2020-09-13 10:14:28 --> Language Class Initialized
INFO - 2020-09-13 10:14:28 --> Language Class Initialized
INFO - 2020-09-13 10:14:28 --> Config Class Initialized
INFO - 2020-09-13 10:14:28 --> Loader Class Initialized
INFO - 2020-09-13 10:14:28 --> Helper loaded: url_helper
INFO - 2020-09-13 10:14:28 --> Helper loaded: form_helper
INFO - 2020-09-13 10:14:28 --> Helper loaded: file_helper
INFO - 2020-09-13 10:14:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:14:28 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:14:28 --> Upload Class Initialized
INFO - 2020-09-13 10:14:28 --> Controller Class Initialized
DEBUG - 2020-09-13 10:14:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:14:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:14:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:14:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:14:28 --> Final output sent to browser
DEBUG - 2020-09-13 10:14:28 --> Total execution time: 0.0537
INFO - 2020-09-13 10:15:41 --> Config Class Initialized
INFO - 2020-09-13 10:15:41 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:15:41 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:15:41 --> Utf8 Class Initialized
INFO - 2020-09-13 10:15:41 --> URI Class Initialized
DEBUG - 2020-09-13 10:15:41 --> No URI present. Default controller set.
INFO - 2020-09-13 10:15:41 --> Router Class Initialized
INFO - 2020-09-13 10:15:41 --> Output Class Initialized
INFO - 2020-09-13 10:15:41 --> Security Class Initialized
DEBUG - 2020-09-13 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:15:41 --> Input Class Initialized
INFO - 2020-09-13 10:15:41 --> Language Class Initialized
INFO - 2020-09-13 10:15:41 --> Language Class Initialized
INFO - 2020-09-13 10:15:41 --> Config Class Initialized
INFO - 2020-09-13 10:15:41 --> Loader Class Initialized
INFO - 2020-09-13 10:15:41 --> Helper loaded: url_helper
INFO - 2020-09-13 10:15:41 --> Helper loaded: form_helper
INFO - 2020-09-13 10:15:41 --> Helper loaded: file_helper
INFO - 2020-09-13 10:15:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:15:41 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:15:41 --> Upload Class Initialized
INFO - 2020-09-13 10:15:41 --> Controller Class Initialized
DEBUG - 2020-09-13 10:15:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:15:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:15:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:15:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:15:41 --> Final output sent to browser
DEBUG - 2020-09-13 10:15:41 --> Total execution time: 0.0540
INFO - 2020-09-13 10:15:48 --> Config Class Initialized
INFO - 2020-09-13 10:15:48 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:15:48 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:15:48 --> Utf8 Class Initialized
INFO - 2020-09-13 10:15:48 --> URI Class Initialized
DEBUG - 2020-09-13 10:15:48 --> No URI present. Default controller set.
INFO - 2020-09-13 10:15:48 --> Router Class Initialized
INFO - 2020-09-13 10:15:48 --> Output Class Initialized
INFO - 2020-09-13 10:15:48 --> Security Class Initialized
DEBUG - 2020-09-13 10:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:15:48 --> Input Class Initialized
INFO - 2020-09-13 10:15:48 --> Language Class Initialized
INFO - 2020-09-13 10:15:48 --> Language Class Initialized
INFO - 2020-09-13 10:15:48 --> Config Class Initialized
INFO - 2020-09-13 10:15:48 --> Loader Class Initialized
INFO - 2020-09-13 10:15:48 --> Helper loaded: url_helper
INFO - 2020-09-13 10:15:48 --> Helper loaded: form_helper
INFO - 2020-09-13 10:15:48 --> Helper loaded: file_helper
INFO - 2020-09-13 10:15:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:15:48 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:15:48 --> Upload Class Initialized
INFO - 2020-09-13 10:15:48 --> Controller Class Initialized
DEBUG - 2020-09-13 10:15:48 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:15:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:15:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:15:48 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:15:48 --> Final output sent to browser
DEBUG - 2020-09-13 10:15:48 --> Total execution time: 0.0466
INFO - 2020-09-13 10:16:01 --> Config Class Initialized
INFO - 2020-09-13 10:16:01 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:16:01 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:16:01 --> Utf8 Class Initialized
INFO - 2020-09-13 10:16:01 --> URI Class Initialized
DEBUG - 2020-09-13 10:16:01 --> No URI present. Default controller set.
INFO - 2020-09-13 10:16:01 --> Router Class Initialized
INFO - 2020-09-13 10:16:01 --> Output Class Initialized
INFO - 2020-09-13 10:16:01 --> Security Class Initialized
DEBUG - 2020-09-13 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:16:01 --> Input Class Initialized
INFO - 2020-09-13 10:16:01 --> Language Class Initialized
INFO - 2020-09-13 10:16:01 --> Language Class Initialized
INFO - 2020-09-13 10:16:01 --> Config Class Initialized
INFO - 2020-09-13 10:16:01 --> Loader Class Initialized
INFO - 2020-09-13 10:16:01 --> Helper loaded: url_helper
INFO - 2020-09-13 10:16:01 --> Helper loaded: form_helper
INFO - 2020-09-13 10:16:01 --> Helper loaded: file_helper
INFO - 2020-09-13 10:16:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:16:01 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:16:01 --> Upload Class Initialized
INFO - 2020-09-13 10:16:01 --> Controller Class Initialized
DEBUG - 2020-09-13 10:16:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:16:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:16:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:16:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:16:01 --> Final output sent to browser
DEBUG - 2020-09-13 10:16:01 --> Total execution time: 0.0458
INFO - 2020-09-13 10:16:26 --> Config Class Initialized
INFO - 2020-09-13 10:16:26 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:16:26 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:16:26 --> Utf8 Class Initialized
INFO - 2020-09-13 10:16:26 --> URI Class Initialized
INFO - 2020-09-13 10:16:26 --> Router Class Initialized
INFO - 2020-09-13 10:16:26 --> Output Class Initialized
INFO - 2020-09-13 10:16:26 --> Security Class Initialized
DEBUG - 2020-09-13 10:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:16:26 --> Input Class Initialized
INFO - 2020-09-13 10:16:26 --> Language Class Initialized
INFO - 2020-09-13 10:16:26 --> Language Class Initialized
INFO - 2020-09-13 10:16:26 --> Config Class Initialized
INFO - 2020-09-13 10:16:26 --> Loader Class Initialized
INFO - 2020-09-13 10:16:26 --> Helper loaded: url_helper
INFO - 2020-09-13 10:16:26 --> Helper loaded: form_helper
INFO - 2020-09-13 10:16:26 --> Helper loaded: file_helper
INFO - 2020-09-13 10:16:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:16:26 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:16:26 --> Upload Class Initialized
INFO - 2020-09-13 10:16:26 --> Controller Class Initialized
ERROR - 2020-09-13 10:16:26 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:16:27 --> Config Class Initialized
INFO - 2020-09-13 10:16:27 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:16:27 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:16:27 --> Utf8 Class Initialized
INFO - 2020-09-13 10:16:27 --> URI Class Initialized
INFO - 2020-09-13 10:16:27 --> Router Class Initialized
INFO - 2020-09-13 10:16:27 --> Output Class Initialized
INFO - 2020-09-13 10:16:27 --> Security Class Initialized
DEBUG - 2020-09-13 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:16:27 --> Input Class Initialized
INFO - 2020-09-13 10:16:27 --> Language Class Initialized
INFO - 2020-09-13 10:16:27 --> Language Class Initialized
INFO - 2020-09-13 10:16:27 --> Config Class Initialized
INFO - 2020-09-13 10:16:27 --> Loader Class Initialized
INFO - 2020-09-13 10:16:27 --> Helper loaded: url_helper
INFO - 2020-09-13 10:16:27 --> Helper loaded: form_helper
INFO - 2020-09-13 10:16:27 --> Helper loaded: file_helper
INFO - 2020-09-13 10:16:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:16:27 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:16:27 --> Upload Class Initialized
INFO - 2020-09-13 10:16:27 --> Controller Class Initialized
ERROR - 2020-09-13 10:16:27 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:16:29 --> Config Class Initialized
INFO - 2020-09-13 10:16:29 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:16:29 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:16:29 --> Utf8 Class Initialized
INFO - 2020-09-13 10:16:29 --> URI Class Initialized
INFO - 2020-09-13 10:16:29 --> Router Class Initialized
INFO - 2020-09-13 10:16:29 --> Output Class Initialized
INFO - 2020-09-13 10:16:29 --> Security Class Initialized
DEBUG - 2020-09-13 10:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:16:29 --> Input Class Initialized
INFO - 2020-09-13 10:16:29 --> Language Class Initialized
INFO - 2020-09-13 10:16:29 --> Language Class Initialized
INFO - 2020-09-13 10:16:29 --> Config Class Initialized
INFO - 2020-09-13 10:16:29 --> Loader Class Initialized
INFO - 2020-09-13 10:16:29 --> Helper loaded: url_helper
INFO - 2020-09-13 10:16:29 --> Helper loaded: form_helper
INFO - 2020-09-13 10:16:29 --> Helper loaded: file_helper
INFO - 2020-09-13 10:16:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:16:29 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:16:29 --> Upload Class Initialized
INFO - 2020-09-13 10:16:29 --> Controller Class Initialized
ERROR - 2020-09-13 10:16:29 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:16:36 --> Config Class Initialized
INFO - 2020-09-13 10:16:36 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:16:36 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:16:36 --> Utf8 Class Initialized
INFO - 2020-09-13 10:16:36 --> URI Class Initialized
DEBUG - 2020-09-13 10:16:36 --> No URI present. Default controller set.
INFO - 2020-09-13 10:16:36 --> Router Class Initialized
INFO - 2020-09-13 10:16:36 --> Output Class Initialized
INFO - 2020-09-13 10:16:36 --> Security Class Initialized
DEBUG - 2020-09-13 10:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:16:36 --> Input Class Initialized
INFO - 2020-09-13 10:16:36 --> Language Class Initialized
INFO - 2020-09-13 10:16:36 --> Language Class Initialized
INFO - 2020-09-13 10:16:36 --> Config Class Initialized
INFO - 2020-09-13 10:16:36 --> Loader Class Initialized
INFO - 2020-09-13 10:16:36 --> Helper loaded: url_helper
INFO - 2020-09-13 10:16:36 --> Helper loaded: form_helper
INFO - 2020-09-13 10:16:36 --> Helper loaded: file_helper
INFO - 2020-09-13 10:16:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:16:36 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:16:36 --> Upload Class Initialized
INFO - 2020-09-13 10:16:36 --> Controller Class Initialized
DEBUG - 2020-09-13 10:16:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:16:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:16:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:16:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:16:36 --> Final output sent to browser
DEBUG - 2020-09-13 10:16:36 --> Total execution time: 0.0526
INFO - 2020-09-13 10:16:38 --> Config Class Initialized
INFO - 2020-09-13 10:16:38 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:16:38 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:16:38 --> Utf8 Class Initialized
INFO - 2020-09-13 10:16:38 --> URI Class Initialized
DEBUG - 2020-09-13 10:16:38 --> No URI present. Default controller set.
INFO - 2020-09-13 10:16:38 --> Router Class Initialized
INFO - 2020-09-13 10:16:38 --> Output Class Initialized
INFO - 2020-09-13 10:16:38 --> Security Class Initialized
DEBUG - 2020-09-13 10:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:16:38 --> Input Class Initialized
INFO - 2020-09-13 10:16:38 --> Language Class Initialized
INFO - 2020-09-13 10:16:38 --> Language Class Initialized
INFO - 2020-09-13 10:16:38 --> Config Class Initialized
INFO - 2020-09-13 10:16:38 --> Loader Class Initialized
INFO - 2020-09-13 10:16:38 --> Helper loaded: url_helper
INFO - 2020-09-13 10:16:38 --> Helper loaded: form_helper
INFO - 2020-09-13 10:16:38 --> Helper loaded: file_helper
INFO - 2020-09-13 10:16:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:16:38 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:16:38 --> Upload Class Initialized
INFO - 2020-09-13 10:16:38 --> Controller Class Initialized
DEBUG - 2020-09-13 10:16:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:16:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:16:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:16:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:16:38 --> Final output sent to browser
DEBUG - 2020-09-13 10:16:38 --> Total execution time: 0.0392
INFO - 2020-09-13 10:17:22 --> Config Class Initialized
INFO - 2020-09-13 10:17:22 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:17:22 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:17:22 --> Utf8 Class Initialized
INFO - 2020-09-13 10:17:22 --> URI Class Initialized
DEBUG - 2020-09-13 10:17:22 --> No URI present. Default controller set.
INFO - 2020-09-13 10:17:22 --> Router Class Initialized
INFO - 2020-09-13 10:17:22 --> Output Class Initialized
INFO - 2020-09-13 10:17:22 --> Security Class Initialized
DEBUG - 2020-09-13 10:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:17:22 --> Input Class Initialized
INFO - 2020-09-13 10:17:22 --> Language Class Initialized
INFO - 2020-09-13 10:17:22 --> Language Class Initialized
INFO - 2020-09-13 10:17:22 --> Config Class Initialized
INFO - 2020-09-13 10:17:22 --> Loader Class Initialized
INFO - 2020-09-13 10:17:22 --> Helper loaded: url_helper
INFO - 2020-09-13 10:17:22 --> Helper loaded: form_helper
INFO - 2020-09-13 10:17:22 --> Helper loaded: file_helper
INFO - 2020-09-13 10:17:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:17:22 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:17:22 --> Upload Class Initialized
INFO - 2020-09-13 10:17:22 --> Controller Class Initialized
DEBUG - 2020-09-13 10:17:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:17:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:17:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:17:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:17:22 --> Final output sent to browser
DEBUG - 2020-09-13 10:17:22 --> Total execution time: 0.0517
INFO - 2020-09-13 10:17:24 --> Config Class Initialized
INFO - 2020-09-13 10:17:24 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:17:24 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:17:24 --> Utf8 Class Initialized
INFO - 2020-09-13 10:17:24 --> URI Class Initialized
DEBUG - 2020-09-13 10:17:24 --> No URI present. Default controller set.
INFO - 2020-09-13 10:17:24 --> Router Class Initialized
INFO - 2020-09-13 10:17:24 --> Output Class Initialized
INFO - 2020-09-13 10:17:24 --> Security Class Initialized
DEBUG - 2020-09-13 10:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:17:24 --> Input Class Initialized
INFO - 2020-09-13 10:17:24 --> Language Class Initialized
INFO - 2020-09-13 10:17:24 --> Language Class Initialized
INFO - 2020-09-13 10:17:24 --> Config Class Initialized
INFO - 2020-09-13 10:17:24 --> Loader Class Initialized
INFO - 2020-09-13 10:17:24 --> Helper loaded: url_helper
INFO - 2020-09-13 10:17:24 --> Helper loaded: form_helper
INFO - 2020-09-13 10:17:24 --> Helper loaded: file_helper
INFO - 2020-09-13 10:17:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:17:24 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:17:24 --> Upload Class Initialized
INFO - 2020-09-13 10:17:24 --> Controller Class Initialized
DEBUG - 2020-09-13 10:17:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:17:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:17:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:17:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:17:24 --> Final output sent to browser
DEBUG - 2020-09-13 10:17:24 --> Total execution time: 0.0476
INFO - 2020-09-13 10:17:26 --> Config Class Initialized
INFO - 2020-09-13 10:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:17:26 --> Utf8 Class Initialized
INFO - 2020-09-13 10:17:26 --> URI Class Initialized
INFO - 2020-09-13 10:17:26 --> Router Class Initialized
INFO - 2020-09-13 10:17:26 --> Output Class Initialized
INFO - 2020-09-13 10:17:26 --> Security Class Initialized
DEBUG - 2020-09-13 10:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:17:26 --> Input Class Initialized
INFO - 2020-09-13 10:17:26 --> Language Class Initialized
INFO - 2020-09-13 10:17:26 --> Language Class Initialized
INFO - 2020-09-13 10:17:26 --> Config Class Initialized
INFO - 2020-09-13 10:17:26 --> Loader Class Initialized
INFO - 2020-09-13 10:17:26 --> Helper loaded: url_helper
INFO - 2020-09-13 10:17:26 --> Helper loaded: form_helper
INFO - 2020-09-13 10:17:26 --> Helper loaded: file_helper
INFO - 2020-09-13 10:17:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:17:26 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:17:26 --> Upload Class Initialized
INFO - 2020-09-13 10:17:26 --> Controller Class Initialized
ERROR - 2020-09-13 10:17:26 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:17:30 --> Config Class Initialized
INFO - 2020-09-13 10:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:17:30 --> Utf8 Class Initialized
INFO - 2020-09-13 10:17:30 --> URI Class Initialized
DEBUG - 2020-09-13 10:17:30 --> No URI present. Default controller set.
INFO - 2020-09-13 10:17:30 --> Router Class Initialized
INFO - 2020-09-13 10:17:30 --> Output Class Initialized
INFO - 2020-09-13 10:17:30 --> Security Class Initialized
DEBUG - 2020-09-13 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:17:30 --> Input Class Initialized
INFO - 2020-09-13 10:17:30 --> Language Class Initialized
INFO - 2020-09-13 10:17:30 --> Language Class Initialized
INFO - 2020-09-13 10:17:30 --> Config Class Initialized
INFO - 2020-09-13 10:17:30 --> Loader Class Initialized
INFO - 2020-09-13 10:17:30 --> Helper loaded: url_helper
INFO - 2020-09-13 10:17:30 --> Helper loaded: form_helper
INFO - 2020-09-13 10:17:30 --> Helper loaded: file_helper
INFO - 2020-09-13 10:17:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:17:30 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:17:30 --> Upload Class Initialized
INFO - 2020-09-13 10:17:30 --> Controller Class Initialized
DEBUG - 2020-09-13 10:17:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:17:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:17:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:17:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:17:30 --> Final output sent to browser
DEBUG - 2020-09-13 10:17:30 --> Total execution time: 0.0532
INFO - 2020-09-13 10:17:38 --> Config Class Initialized
INFO - 2020-09-13 10:17:38 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:17:38 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:17:38 --> Utf8 Class Initialized
INFO - 2020-09-13 10:17:38 --> URI Class Initialized
DEBUG - 2020-09-13 10:17:38 --> No URI present. Default controller set.
INFO - 2020-09-13 10:17:38 --> Router Class Initialized
INFO - 2020-09-13 10:17:38 --> Output Class Initialized
INFO - 2020-09-13 10:17:38 --> Security Class Initialized
DEBUG - 2020-09-13 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:17:38 --> Input Class Initialized
INFO - 2020-09-13 10:17:38 --> Language Class Initialized
INFO - 2020-09-13 10:17:38 --> Language Class Initialized
INFO - 2020-09-13 10:17:38 --> Config Class Initialized
INFO - 2020-09-13 10:17:38 --> Loader Class Initialized
INFO - 2020-09-13 10:17:38 --> Helper loaded: url_helper
INFO - 2020-09-13 10:17:38 --> Helper loaded: form_helper
INFO - 2020-09-13 10:17:38 --> Helper loaded: file_helper
INFO - 2020-09-13 10:17:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:17:38 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:17:38 --> Upload Class Initialized
INFO - 2020-09-13 10:17:38 --> Controller Class Initialized
DEBUG - 2020-09-13 10:17:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:17:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:17:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:17:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:17:38 --> Final output sent to browser
DEBUG - 2020-09-13 10:17:38 --> Total execution time: 0.0539
INFO - 2020-09-13 10:18:09 --> Config Class Initialized
INFO - 2020-09-13 10:18:09 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:18:09 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:18:09 --> Utf8 Class Initialized
INFO - 2020-09-13 10:18:09 --> URI Class Initialized
INFO - 2020-09-13 10:18:09 --> Router Class Initialized
INFO - 2020-09-13 10:18:09 --> Output Class Initialized
INFO - 2020-09-13 10:18:09 --> Security Class Initialized
DEBUG - 2020-09-13 10:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:18:09 --> Input Class Initialized
INFO - 2020-09-13 10:18:09 --> Language Class Initialized
INFO - 2020-09-13 10:18:09 --> Language Class Initialized
INFO - 2020-09-13 10:18:09 --> Config Class Initialized
INFO - 2020-09-13 10:18:09 --> Loader Class Initialized
INFO - 2020-09-13 10:18:09 --> Helper loaded: url_helper
INFO - 2020-09-13 10:18:09 --> Helper loaded: form_helper
INFO - 2020-09-13 10:18:09 --> Helper loaded: file_helper
INFO - 2020-09-13 10:18:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:18:09 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:18:09 --> Upload Class Initialized
INFO - 2020-09-13 10:18:09 --> Controller Class Initialized
ERROR - 2020-09-13 10:18:09 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:18:11 --> Config Class Initialized
INFO - 2020-09-13 10:18:11 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:18:11 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:18:11 --> Utf8 Class Initialized
INFO - 2020-09-13 10:18:11 --> URI Class Initialized
DEBUG - 2020-09-13 10:18:11 --> No URI present. Default controller set.
INFO - 2020-09-13 10:18:11 --> Router Class Initialized
INFO - 2020-09-13 10:18:11 --> Output Class Initialized
INFO - 2020-09-13 10:18:11 --> Security Class Initialized
DEBUG - 2020-09-13 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:18:11 --> Input Class Initialized
INFO - 2020-09-13 10:18:11 --> Language Class Initialized
INFO - 2020-09-13 10:18:11 --> Language Class Initialized
INFO - 2020-09-13 10:18:11 --> Config Class Initialized
INFO - 2020-09-13 10:18:11 --> Loader Class Initialized
INFO - 2020-09-13 10:18:11 --> Helper loaded: url_helper
INFO - 2020-09-13 10:18:11 --> Helper loaded: form_helper
INFO - 2020-09-13 10:18:11 --> Helper loaded: file_helper
INFO - 2020-09-13 10:18:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:18:11 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:18:11 --> Upload Class Initialized
INFO - 2020-09-13 10:18:11 --> Controller Class Initialized
DEBUG - 2020-09-13 10:18:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:18:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:18:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:18:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:18:11 --> Final output sent to browser
DEBUG - 2020-09-13 10:18:11 --> Total execution time: 0.0455
INFO - 2020-09-13 10:18:21 --> Config Class Initialized
INFO - 2020-09-13 10:18:21 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:18:21 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:18:21 --> Utf8 Class Initialized
INFO - 2020-09-13 10:18:21 --> URI Class Initialized
DEBUG - 2020-09-13 10:18:21 --> No URI present. Default controller set.
INFO - 2020-09-13 10:18:21 --> Router Class Initialized
INFO - 2020-09-13 10:18:21 --> Output Class Initialized
INFO - 2020-09-13 10:18:21 --> Security Class Initialized
DEBUG - 2020-09-13 10:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:18:21 --> Input Class Initialized
INFO - 2020-09-13 10:18:21 --> Language Class Initialized
INFO - 2020-09-13 10:18:21 --> Language Class Initialized
INFO - 2020-09-13 10:18:21 --> Config Class Initialized
INFO - 2020-09-13 10:18:21 --> Loader Class Initialized
INFO - 2020-09-13 10:18:21 --> Helper loaded: url_helper
INFO - 2020-09-13 10:18:21 --> Helper loaded: form_helper
INFO - 2020-09-13 10:18:21 --> Helper loaded: file_helper
INFO - 2020-09-13 10:18:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:18:21 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:18:21 --> Upload Class Initialized
INFO - 2020-09-13 10:18:21 --> Controller Class Initialized
DEBUG - 2020-09-13 10:18:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:18:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:18:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:18:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:18:21 --> Final output sent to browser
DEBUG - 2020-09-13 10:18:21 --> Total execution time: 0.0505
INFO - 2020-09-13 10:18:34 --> Config Class Initialized
INFO - 2020-09-13 10:18:34 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:18:34 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:18:34 --> Utf8 Class Initialized
INFO - 2020-09-13 10:18:34 --> URI Class Initialized
DEBUG - 2020-09-13 10:18:34 --> No URI present. Default controller set.
INFO - 2020-09-13 10:18:34 --> Router Class Initialized
INFO - 2020-09-13 10:18:34 --> Output Class Initialized
INFO - 2020-09-13 10:18:34 --> Security Class Initialized
DEBUG - 2020-09-13 10:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:18:34 --> Input Class Initialized
INFO - 2020-09-13 10:18:34 --> Language Class Initialized
INFO - 2020-09-13 10:18:34 --> Language Class Initialized
INFO - 2020-09-13 10:18:34 --> Config Class Initialized
INFO - 2020-09-13 10:18:34 --> Loader Class Initialized
INFO - 2020-09-13 10:18:34 --> Helper loaded: url_helper
INFO - 2020-09-13 10:18:34 --> Helper loaded: form_helper
INFO - 2020-09-13 10:18:34 --> Helper loaded: file_helper
INFO - 2020-09-13 10:18:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:18:34 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:18:34 --> Upload Class Initialized
INFO - 2020-09-13 10:18:34 --> Controller Class Initialized
DEBUG - 2020-09-13 10:18:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:18:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:18:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:18:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:18:34 --> Final output sent to browser
DEBUG - 2020-09-13 10:18:34 --> Total execution time: 0.0483
INFO - 2020-09-13 10:18:47 --> Config Class Initialized
INFO - 2020-09-13 10:18:47 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:18:47 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:18:47 --> Utf8 Class Initialized
INFO - 2020-09-13 10:18:47 --> URI Class Initialized
INFO - 2020-09-13 10:18:47 --> Router Class Initialized
INFO - 2020-09-13 10:18:47 --> Output Class Initialized
INFO - 2020-09-13 10:18:47 --> Security Class Initialized
DEBUG - 2020-09-13 10:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:18:47 --> Input Class Initialized
INFO - 2020-09-13 10:18:47 --> Language Class Initialized
INFO - 2020-09-13 10:18:47 --> Language Class Initialized
INFO - 2020-09-13 10:18:47 --> Config Class Initialized
INFO - 2020-09-13 10:18:47 --> Loader Class Initialized
INFO - 2020-09-13 10:18:47 --> Helper loaded: url_helper
INFO - 2020-09-13 10:18:47 --> Helper loaded: form_helper
INFO - 2020-09-13 10:18:47 --> Helper loaded: file_helper
INFO - 2020-09-13 10:18:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:18:47 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:18:47 --> Upload Class Initialized
INFO - 2020-09-13 10:18:47 --> Controller Class Initialized
ERROR - 2020-09-13 10:18:47 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:20:07 --> Config Class Initialized
INFO - 2020-09-13 10:20:07 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:07 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:07 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:07 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:07 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:07 --> Router Class Initialized
INFO - 2020-09-13 10:20:07 --> Output Class Initialized
INFO - 2020-09-13 10:20:07 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:07 --> Input Class Initialized
INFO - 2020-09-13 10:20:07 --> Language Class Initialized
INFO - 2020-09-13 10:20:07 --> Language Class Initialized
INFO - 2020-09-13 10:20:07 --> Config Class Initialized
INFO - 2020-09-13 10:20:07 --> Loader Class Initialized
INFO - 2020-09-13 10:20:07 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:07 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:07 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:07 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:07 --> Upload Class Initialized
INFO - 2020-09-13 10:20:07 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:07 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:07 --> Total execution time: 0.0566
INFO - 2020-09-13 10:20:24 --> Config Class Initialized
INFO - 2020-09-13 10:20:24 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:24 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:24 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:24 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:24 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:24 --> Router Class Initialized
INFO - 2020-09-13 10:20:24 --> Output Class Initialized
INFO - 2020-09-13 10:20:24 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:24 --> Input Class Initialized
INFO - 2020-09-13 10:20:24 --> Language Class Initialized
INFO - 2020-09-13 10:20:24 --> Language Class Initialized
INFO - 2020-09-13 10:20:24 --> Config Class Initialized
INFO - 2020-09-13 10:20:24 --> Loader Class Initialized
INFO - 2020-09-13 10:20:24 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:24 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:24 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:24 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:24 --> Upload Class Initialized
INFO - 2020-09-13 10:20:24 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:24 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:24 --> Total execution time: 0.0535
INFO - 2020-09-13 10:20:27 --> Config Class Initialized
INFO - 2020-09-13 10:20:27 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:27 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:27 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:27 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:27 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:27 --> Router Class Initialized
INFO - 2020-09-13 10:20:27 --> Output Class Initialized
INFO - 2020-09-13 10:20:27 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:27 --> Input Class Initialized
INFO - 2020-09-13 10:20:27 --> Language Class Initialized
INFO - 2020-09-13 10:20:27 --> Language Class Initialized
INFO - 2020-09-13 10:20:27 --> Config Class Initialized
INFO - 2020-09-13 10:20:27 --> Loader Class Initialized
INFO - 2020-09-13 10:20:27 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:27 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:27 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:27 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:27 --> Upload Class Initialized
INFO - 2020-09-13 10:20:27 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:27 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:27 --> Total execution time: 0.0521
INFO - 2020-09-13 10:20:46 --> Config Class Initialized
INFO - 2020-09-13 10:20:46 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:46 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:46 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:46 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:46 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:46 --> Router Class Initialized
INFO - 2020-09-13 10:20:46 --> Output Class Initialized
INFO - 2020-09-13 10:20:46 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:46 --> Input Class Initialized
INFO - 2020-09-13 10:20:46 --> Language Class Initialized
INFO - 2020-09-13 10:20:46 --> Language Class Initialized
INFO - 2020-09-13 10:20:46 --> Config Class Initialized
INFO - 2020-09-13 10:20:46 --> Loader Class Initialized
INFO - 2020-09-13 10:20:46 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:46 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:46 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:46 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:46 --> Upload Class Initialized
INFO - 2020-09-13 10:20:46 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:46 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:46 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:46 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:46 --> Total execution time: 0.0567
INFO - 2020-09-13 10:20:49 --> Config Class Initialized
INFO - 2020-09-13 10:20:49 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:49 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:49 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:49 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:49 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:49 --> Router Class Initialized
INFO - 2020-09-13 10:20:49 --> Output Class Initialized
INFO - 2020-09-13 10:20:49 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:49 --> Input Class Initialized
INFO - 2020-09-13 10:20:49 --> Language Class Initialized
INFO - 2020-09-13 10:20:49 --> Language Class Initialized
INFO - 2020-09-13 10:20:49 --> Config Class Initialized
INFO - 2020-09-13 10:20:49 --> Loader Class Initialized
INFO - 2020-09-13 10:20:49 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:49 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:49 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:49 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:49 --> Upload Class Initialized
INFO - 2020-09-13 10:20:49 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:49 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:49 --> Total execution time: 0.0488
INFO - 2020-09-13 10:20:51 --> Config Class Initialized
INFO - 2020-09-13 10:20:51 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:51 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:51 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:51 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:51 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:51 --> Router Class Initialized
INFO - 2020-09-13 10:20:51 --> Output Class Initialized
INFO - 2020-09-13 10:20:51 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:51 --> Input Class Initialized
INFO - 2020-09-13 10:20:51 --> Language Class Initialized
INFO - 2020-09-13 10:20:51 --> Language Class Initialized
INFO - 2020-09-13 10:20:51 --> Config Class Initialized
INFO - 2020-09-13 10:20:51 --> Loader Class Initialized
INFO - 2020-09-13 10:20:51 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:51 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:51 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:51 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:51 --> Upload Class Initialized
INFO - 2020-09-13 10:20:51 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:51 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:51 --> Total execution time: 0.0582
INFO - 2020-09-13 10:20:54 --> Config Class Initialized
INFO - 2020-09-13 10:20:54 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:20:54 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:20:54 --> Utf8 Class Initialized
INFO - 2020-09-13 10:20:54 --> URI Class Initialized
DEBUG - 2020-09-13 10:20:54 --> No URI present. Default controller set.
INFO - 2020-09-13 10:20:54 --> Router Class Initialized
INFO - 2020-09-13 10:20:54 --> Output Class Initialized
INFO - 2020-09-13 10:20:54 --> Security Class Initialized
DEBUG - 2020-09-13 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:20:54 --> Input Class Initialized
INFO - 2020-09-13 10:20:54 --> Language Class Initialized
INFO - 2020-09-13 10:20:54 --> Language Class Initialized
INFO - 2020-09-13 10:20:54 --> Config Class Initialized
INFO - 2020-09-13 10:20:54 --> Loader Class Initialized
INFO - 2020-09-13 10:20:54 --> Helper loaded: url_helper
INFO - 2020-09-13 10:20:54 --> Helper loaded: form_helper
INFO - 2020-09-13 10:20:54 --> Helper loaded: file_helper
INFO - 2020-09-13 10:20:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:20:54 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:20:54 --> Upload Class Initialized
INFO - 2020-09-13 10:20:54 --> Controller Class Initialized
DEBUG - 2020-09-13 10:20:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:20:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:20:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:20:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:20:54 --> Final output sent to browser
DEBUG - 2020-09-13 10:20:54 --> Total execution time: 0.0538
INFO - 2020-09-13 10:21:57 --> Config Class Initialized
INFO - 2020-09-13 10:21:57 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:21:57 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:21:57 --> Utf8 Class Initialized
INFO - 2020-09-13 10:21:57 --> URI Class Initialized
DEBUG - 2020-09-13 10:21:57 --> No URI present. Default controller set.
INFO - 2020-09-13 10:21:57 --> Router Class Initialized
INFO - 2020-09-13 10:21:57 --> Output Class Initialized
INFO - 2020-09-13 10:21:57 --> Security Class Initialized
DEBUG - 2020-09-13 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:21:57 --> Input Class Initialized
INFO - 2020-09-13 10:21:57 --> Language Class Initialized
INFO - 2020-09-13 10:21:57 --> Language Class Initialized
INFO - 2020-09-13 10:21:57 --> Config Class Initialized
INFO - 2020-09-13 10:21:57 --> Loader Class Initialized
INFO - 2020-09-13 10:21:57 --> Helper loaded: url_helper
INFO - 2020-09-13 10:21:57 --> Helper loaded: form_helper
INFO - 2020-09-13 10:21:57 --> Helper loaded: file_helper
INFO - 2020-09-13 10:21:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:21:57 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:21:57 --> Upload Class Initialized
INFO - 2020-09-13 10:21:57 --> Controller Class Initialized
DEBUG - 2020-09-13 10:21:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:21:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:21:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:21:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:21:57 --> Final output sent to browser
DEBUG - 2020-09-13 10:21:57 --> Total execution time: 0.0489
INFO - 2020-09-13 10:21:58 --> Config Class Initialized
INFO - 2020-09-13 10:21:58 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:21:58 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:21:58 --> Utf8 Class Initialized
INFO - 2020-09-13 10:21:58 --> URI Class Initialized
INFO - 2020-09-13 10:21:58 --> Router Class Initialized
INFO - 2020-09-13 10:21:58 --> Output Class Initialized
INFO - 2020-09-13 10:21:58 --> Security Class Initialized
DEBUG - 2020-09-13 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:21:58 --> Input Class Initialized
INFO - 2020-09-13 10:21:58 --> Language Class Initialized
INFO - 2020-09-13 10:21:58 --> Language Class Initialized
INFO - 2020-09-13 10:21:58 --> Config Class Initialized
INFO - 2020-09-13 10:21:58 --> Loader Class Initialized
INFO - 2020-09-13 10:21:58 --> Helper loaded: url_helper
INFO - 2020-09-13 10:21:58 --> Helper loaded: form_helper
INFO - 2020-09-13 10:21:58 --> Helper loaded: file_helper
INFO - 2020-09-13 10:21:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:21:58 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:21:58 --> Upload Class Initialized
INFO - 2020-09-13 10:21:58 --> Controller Class Initialized
ERROR - 2020-09-13 10:21:58 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:22:07 --> Config Class Initialized
INFO - 2020-09-13 10:22:07 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:07 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:07 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:07 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:07 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:07 --> Router Class Initialized
INFO - 2020-09-13 10:22:07 --> Output Class Initialized
INFO - 2020-09-13 10:22:07 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:07 --> Input Class Initialized
INFO - 2020-09-13 10:22:07 --> Language Class Initialized
INFO - 2020-09-13 10:22:07 --> Language Class Initialized
INFO - 2020-09-13 10:22:07 --> Config Class Initialized
INFO - 2020-09-13 10:22:07 --> Loader Class Initialized
INFO - 2020-09-13 10:22:07 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:07 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:07 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:07 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:07 --> Upload Class Initialized
INFO - 2020-09-13 10:22:07 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:07 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:07 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:07 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:07 --> Total execution time: 0.0508
INFO - 2020-09-13 10:22:09 --> Config Class Initialized
INFO - 2020-09-13 10:22:09 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:09 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:09 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:09 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:09 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:09 --> Router Class Initialized
INFO - 2020-09-13 10:22:09 --> Output Class Initialized
INFO - 2020-09-13 10:22:09 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:09 --> Input Class Initialized
INFO - 2020-09-13 10:22:09 --> Language Class Initialized
INFO - 2020-09-13 10:22:09 --> Language Class Initialized
INFO - 2020-09-13 10:22:09 --> Config Class Initialized
INFO - 2020-09-13 10:22:09 --> Loader Class Initialized
INFO - 2020-09-13 10:22:09 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:09 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:09 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:09 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:09 --> Upload Class Initialized
INFO - 2020-09-13 10:22:10 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:10 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:10 --> Total execution time: 0.0415
INFO - 2020-09-13 10:22:12 --> Config Class Initialized
INFO - 2020-09-13 10:22:12 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:12 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:12 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:12 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:12 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:12 --> Router Class Initialized
INFO - 2020-09-13 10:22:12 --> Output Class Initialized
INFO - 2020-09-13 10:22:12 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:12 --> Input Class Initialized
INFO - 2020-09-13 10:22:12 --> Language Class Initialized
INFO - 2020-09-13 10:22:12 --> Language Class Initialized
INFO - 2020-09-13 10:22:12 --> Config Class Initialized
INFO - 2020-09-13 10:22:12 --> Loader Class Initialized
INFO - 2020-09-13 10:22:12 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:12 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:12 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:12 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:12 --> Upload Class Initialized
INFO - 2020-09-13 10:22:12 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:12 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:12 --> Total execution time: 0.0476
INFO - 2020-09-13 10:22:14 --> Config Class Initialized
INFO - 2020-09-13 10:22:14 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:14 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:14 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:14 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:14 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:14 --> Router Class Initialized
INFO - 2020-09-13 10:22:14 --> Output Class Initialized
INFO - 2020-09-13 10:22:14 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:14 --> Input Class Initialized
INFO - 2020-09-13 10:22:14 --> Language Class Initialized
INFO - 2020-09-13 10:22:14 --> Language Class Initialized
INFO - 2020-09-13 10:22:14 --> Config Class Initialized
INFO - 2020-09-13 10:22:14 --> Loader Class Initialized
INFO - 2020-09-13 10:22:14 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:14 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:14 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:14 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:14 --> Upload Class Initialized
INFO - 2020-09-13 10:22:14 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:14 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:14 --> Total execution time: 0.0488
INFO - 2020-09-13 10:22:19 --> Config Class Initialized
INFO - 2020-09-13 10:22:19 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:19 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:19 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:19 --> URI Class Initialized
INFO - 2020-09-13 10:22:19 --> Router Class Initialized
INFO - 2020-09-13 10:22:19 --> Output Class Initialized
INFO - 2020-09-13 10:22:19 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:19 --> Input Class Initialized
INFO - 2020-09-13 10:22:19 --> Language Class Initialized
INFO - 2020-09-13 10:22:19 --> Language Class Initialized
INFO - 2020-09-13 10:22:19 --> Config Class Initialized
INFO - 2020-09-13 10:22:19 --> Loader Class Initialized
INFO - 2020-09-13 10:22:19 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:19 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:19 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:19 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:19 --> Upload Class Initialized
INFO - 2020-09-13 10:22:19 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:19 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:19 --> Total execution time: 0.0491
INFO - 2020-09-13 10:22:20 --> Config Class Initialized
INFO - 2020-09-13 10:22:20 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:20 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:20 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:20 --> URI Class Initialized
INFO - 2020-09-13 10:22:20 --> Router Class Initialized
INFO - 2020-09-13 10:22:20 --> Output Class Initialized
INFO - 2020-09-13 10:22:20 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:20 --> Input Class Initialized
INFO - 2020-09-13 10:22:20 --> Language Class Initialized
INFO - 2020-09-13 10:22:20 --> Language Class Initialized
INFO - 2020-09-13 10:22:20 --> Config Class Initialized
INFO - 2020-09-13 10:22:20 --> Loader Class Initialized
INFO - 2020-09-13 10:22:20 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:20 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:20 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:20 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:20 --> Upload Class Initialized
INFO - 2020-09-13 10:22:20 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:20 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:20 --> Total execution time: 0.0509
INFO - 2020-09-13 10:22:22 --> Config Class Initialized
INFO - 2020-09-13 10:22:22 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:22 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:22 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:22 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:22 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:22 --> Router Class Initialized
INFO - 2020-09-13 10:22:22 --> Output Class Initialized
INFO - 2020-09-13 10:22:22 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:22 --> Input Class Initialized
INFO - 2020-09-13 10:22:22 --> Language Class Initialized
INFO - 2020-09-13 10:22:22 --> Language Class Initialized
INFO - 2020-09-13 10:22:22 --> Config Class Initialized
INFO - 2020-09-13 10:22:22 --> Loader Class Initialized
INFO - 2020-09-13 10:22:22 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:22 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:22 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:22 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:22 --> Upload Class Initialized
INFO - 2020-09-13 10:22:22 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:22 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:22 --> Total execution time: 0.0492
INFO - 2020-09-13 10:22:23 --> Config Class Initialized
INFO - 2020-09-13 10:22:23 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:23 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:23 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:23 --> URI Class Initialized
INFO - 2020-09-13 10:22:23 --> Router Class Initialized
INFO - 2020-09-13 10:22:23 --> Output Class Initialized
INFO - 2020-09-13 10:22:23 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:23 --> Input Class Initialized
INFO - 2020-09-13 10:22:23 --> Language Class Initialized
INFO - 2020-09-13 10:22:23 --> Language Class Initialized
INFO - 2020-09-13 10:22:23 --> Config Class Initialized
INFO - 2020-09-13 10:22:23 --> Loader Class Initialized
INFO - 2020-09-13 10:22:23 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:23 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:23 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:23 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:23 --> Upload Class Initialized
INFO - 2020-09-13 10:22:23 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:23 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:23 --> Total execution time: 0.0527
INFO - 2020-09-13 10:22:28 --> Config Class Initialized
INFO - 2020-09-13 10:22:28 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:28 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:28 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:28 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:28 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:28 --> Router Class Initialized
INFO - 2020-09-13 10:22:28 --> Output Class Initialized
INFO - 2020-09-13 10:22:28 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:28 --> Input Class Initialized
INFO - 2020-09-13 10:22:28 --> Language Class Initialized
INFO - 2020-09-13 10:22:28 --> Language Class Initialized
INFO - 2020-09-13 10:22:28 --> Config Class Initialized
INFO - 2020-09-13 10:22:28 --> Loader Class Initialized
INFO - 2020-09-13 10:22:28 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:28 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:28 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:28 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:28 --> Upload Class Initialized
INFO - 2020-09-13 10:22:28 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:28 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:28 --> Total execution time: 0.0463
INFO - 2020-09-13 10:22:36 --> Config Class Initialized
INFO - 2020-09-13 10:22:36 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:36 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:36 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:36 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:36 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:36 --> Router Class Initialized
INFO - 2020-09-13 10:22:36 --> Output Class Initialized
INFO - 2020-09-13 10:22:36 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:36 --> Input Class Initialized
INFO - 2020-09-13 10:22:36 --> Language Class Initialized
INFO - 2020-09-13 10:22:36 --> Language Class Initialized
INFO - 2020-09-13 10:22:36 --> Config Class Initialized
INFO - 2020-09-13 10:22:36 --> Loader Class Initialized
INFO - 2020-09-13 10:22:36 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:36 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:36 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:36 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:36 --> Upload Class Initialized
INFO - 2020-09-13 10:22:36 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:36 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:36 --> Total execution time: 0.0497
INFO - 2020-09-13 10:22:40 --> Config Class Initialized
INFO - 2020-09-13 10:22:40 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:40 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:40 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:40 --> URI Class Initialized
INFO - 2020-09-13 10:22:40 --> Router Class Initialized
INFO - 2020-09-13 10:22:40 --> Output Class Initialized
INFO - 2020-09-13 10:22:40 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:40 --> Input Class Initialized
INFO - 2020-09-13 10:22:40 --> Language Class Initialized
INFO - 2020-09-13 10:22:40 --> Language Class Initialized
INFO - 2020-09-13 10:22:40 --> Config Class Initialized
INFO - 2020-09-13 10:22:40 --> Loader Class Initialized
INFO - 2020-09-13 10:22:40 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:40 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:40 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:40 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:40 --> Upload Class Initialized
INFO - 2020-09-13 10:22:40 --> Controller Class Initialized
ERROR - 2020-09-13 10:22:40 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:22:44 --> Config Class Initialized
INFO - 2020-09-13 10:22:44 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:44 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:44 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:44 --> URI Class Initialized
INFO - 2020-09-13 10:22:44 --> Router Class Initialized
INFO - 2020-09-13 10:22:44 --> Output Class Initialized
INFO - 2020-09-13 10:22:44 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:44 --> Input Class Initialized
INFO - 2020-09-13 10:22:44 --> Language Class Initialized
INFO - 2020-09-13 10:22:44 --> Language Class Initialized
INFO - 2020-09-13 10:22:44 --> Config Class Initialized
INFO - 2020-09-13 10:22:44 --> Loader Class Initialized
INFO - 2020-09-13 10:22:44 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:44 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:44 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:44 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:44 --> Upload Class Initialized
INFO - 2020-09-13 10:22:44 --> Controller Class Initialized
ERROR - 2020-09-13 10:22:44 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:22:47 --> Config Class Initialized
INFO - 2020-09-13 10:22:47 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:47 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:47 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:47 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:47 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:47 --> Router Class Initialized
INFO - 2020-09-13 10:22:47 --> Output Class Initialized
INFO - 2020-09-13 10:22:47 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:47 --> Input Class Initialized
INFO - 2020-09-13 10:22:47 --> Language Class Initialized
INFO - 2020-09-13 10:22:47 --> Language Class Initialized
INFO - 2020-09-13 10:22:47 --> Config Class Initialized
INFO - 2020-09-13 10:22:47 --> Loader Class Initialized
INFO - 2020-09-13 10:22:47 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:47 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:47 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:47 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:47 --> Upload Class Initialized
INFO - 2020-09-13 10:22:47 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:47 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:47 --> Total execution time: 0.0448
INFO - 2020-09-13 10:22:51 --> Config Class Initialized
INFO - 2020-09-13 10:22:51 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:51 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:51 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:51 --> URI Class Initialized
INFO - 2020-09-13 10:22:51 --> Router Class Initialized
INFO - 2020-09-13 10:22:51 --> Output Class Initialized
INFO - 2020-09-13 10:22:51 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:51 --> Input Class Initialized
INFO - 2020-09-13 10:22:51 --> Language Class Initialized
INFO - 2020-09-13 10:22:51 --> Language Class Initialized
INFO - 2020-09-13 10:22:51 --> Config Class Initialized
INFO - 2020-09-13 10:22:51 --> Loader Class Initialized
INFO - 2020-09-13 10:22:51 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:51 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:51 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:51 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:51 --> Upload Class Initialized
INFO - 2020-09-13 10:22:51 --> Controller Class Initialized
ERROR - 2020-09-13 10:22:51 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:22:53 --> Config Class Initialized
INFO - 2020-09-13 10:22:53 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:22:53 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:22:53 --> Utf8 Class Initialized
INFO - 2020-09-13 10:22:53 --> URI Class Initialized
DEBUG - 2020-09-13 10:22:53 --> No URI present. Default controller set.
INFO - 2020-09-13 10:22:53 --> Router Class Initialized
INFO - 2020-09-13 10:22:53 --> Output Class Initialized
INFO - 2020-09-13 10:22:53 --> Security Class Initialized
DEBUG - 2020-09-13 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:22:53 --> Input Class Initialized
INFO - 2020-09-13 10:22:53 --> Language Class Initialized
INFO - 2020-09-13 10:22:53 --> Language Class Initialized
INFO - 2020-09-13 10:22:53 --> Config Class Initialized
INFO - 2020-09-13 10:22:53 --> Loader Class Initialized
INFO - 2020-09-13 10:22:53 --> Helper loaded: url_helper
INFO - 2020-09-13 10:22:53 --> Helper loaded: form_helper
INFO - 2020-09-13 10:22:53 --> Helper loaded: file_helper
INFO - 2020-09-13 10:22:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:22:53 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:22:53 --> Upload Class Initialized
INFO - 2020-09-13 10:22:53 --> Controller Class Initialized
DEBUG - 2020-09-13 10:22:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:22:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:22:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:22:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:22:53 --> Final output sent to browser
DEBUG - 2020-09-13 10:22:53 --> Total execution time: 0.0450
INFO - 2020-09-13 10:24:36 --> Config Class Initialized
INFO - 2020-09-13 10:24:36 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:24:36 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:24:36 --> Utf8 Class Initialized
INFO - 2020-09-13 10:24:36 --> URI Class Initialized
DEBUG - 2020-09-13 10:24:36 --> No URI present. Default controller set.
INFO - 2020-09-13 10:24:36 --> Router Class Initialized
INFO - 2020-09-13 10:24:36 --> Output Class Initialized
INFO - 2020-09-13 10:24:36 --> Security Class Initialized
DEBUG - 2020-09-13 10:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:24:36 --> Input Class Initialized
INFO - 2020-09-13 10:24:36 --> Language Class Initialized
INFO - 2020-09-13 10:24:36 --> Language Class Initialized
INFO - 2020-09-13 10:24:36 --> Config Class Initialized
INFO - 2020-09-13 10:24:36 --> Loader Class Initialized
INFO - 2020-09-13 10:24:36 --> Helper loaded: url_helper
INFO - 2020-09-13 10:24:36 --> Helper loaded: form_helper
INFO - 2020-09-13 10:24:36 --> Helper loaded: file_helper
INFO - 2020-09-13 10:24:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:24:36 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:24:36 --> Upload Class Initialized
INFO - 2020-09-13 10:24:36 --> Controller Class Initialized
DEBUG - 2020-09-13 10:24:36 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:24:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:24:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:24:36 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:24:36 --> Final output sent to browser
DEBUG - 2020-09-13 10:24:36 --> Total execution time: 0.0378
INFO - 2020-09-13 10:24:43 --> Config Class Initialized
INFO - 2020-09-13 10:24:43 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:24:43 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:24:43 --> Utf8 Class Initialized
INFO - 2020-09-13 10:24:43 --> URI Class Initialized
INFO - 2020-09-13 10:24:43 --> Router Class Initialized
INFO - 2020-09-13 10:24:43 --> Output Class Initialized
INFO - 2020-09-13 10:24:43 --> Security Class Initialized
DEBUG - 2020-09-13 10:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:24:43 --> Input Class Initialized
INFO - 2020-09-13 10:24:43 --> Language Class Initialized
INFO - 2020-09-13 10:24:43 --> Language Class Initialized
INFO - 2020-09-13 10:24:43 --> Config Class Initialized
INFO - 2020-09-13 10:24:43 --> Loader Class Initialized
INFO - 2020-09-13 10:24:43 --> Helper loaded: url_helper
INFO - 2020-09-13 10:24:43 --> Helper loaded: form_helper
INFO - 2020-09-13 10:24:43 --> Helper loaded: file_helper
INFO - 2020-09-13 10:24:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:24:43 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:24:43 --> Upload Class Initialized
INFO - 2020-09-13 10:24:43 --> Controller Class Initialized
ERROR - 2020-09-13 10:24:43 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:24:48 --> Config Class Initialized
INFO - 2020-09-13 10:24:48 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:24:48 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:24:48 --> Utf8 Class Initialized
INFO - 2020-09-13 10:24:48 --> URI Class Initialized
INFO - 2020-09-13 10:24:48 --> Router Class Initialized
INFO - 2020-09-13 10:24:48 --> Output Class Initialized
INFO - 2020-09-13 10:24:48 --> Security Class Initialized
DEBUG - 2020-09-13 10:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:24:48 --> Input Class Initialized
INFO - 2020-09-13 10:24:48 --> Language Class Initialized
INFO - 2020-09-13 10:24:48 --> Language Class Initialized
INFO - 2020-09-13 10:24:48 --> Config Class Initialized
INFO - 2020-09-13 10:24:48 --> Loader Class Initialized
INFO - 2020-09-13 10:24:48 --> Helper loaded: url_helper
INFO - 2020-09-13 10:24:48 --> Helper loaded: form_helper
INFO - 2020-09-13 10:24:48 --> Helper loaded: file_helper
INFO - 2020-09-13 10:24:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:24:48 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:24:48 --> Upload Class Initialized
INFO - 2020-09-13 10:24:48 --> Controller Class Initialized
ERROR - 2020-09-13 10:24:48 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:24:52 --> Config Class Initialized
INFO - 2020-09-13 10:24:52 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:24:52 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:24:52 --> Utf8 Class Initialized
INFO - 2020-09-13 10:24:52 --> URI Class Initialized
DEBUG - 2020-09-13 10:24:52 --> No URI present. Default controller set.
INFO - 2020-09-13 10:24:52 --> Router Class Initialized
INFO - 2020-09-13 10:24:52 --> Output Class Initialized
INFO - 2020-09-13 10:24:52 --> Security Class Initialized
DEBUG - 2020-09-13 10:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:24:52 --> Input Class Initialized
INFO - 2020-09-13 10:24:52 --> Language Class Initialized
INFO - 2020-09-13 10:24:52 --> Language Class Initialized
INFO - 2020-09-13 10:24:52 --> Config Class Initialized
INFO - 2020-09-13 10:24:52 --> Loader Class Initialized
INFO - 2020-09-13 10:24:52 --> Helper loaded: url_helper
INFO - 2020-09-13 10:24:52 --> Helper loaded: form_helper
INFO - 2020-09-13 10:24:52 --> Helper loaded: file_helper
INFO - 2020-09-13 10:24:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:24:52 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:24:52 --> Upload Class Initialized
INFO - 2020-09-13 10:24:52 --> Controller Class Initialized
DEBUG - 2020-09-13 10:24:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:24:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:24:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:24:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:24:52 --> Final output sent to browser
DEBUG - 2020-09-13 10:24:52 --> Total execution time: 0.0571
INFO - 2020-09-13 10:25:30 --> Config Class Initialized
INFO - 2020-09-13 10:25:30 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:25:30 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:25:30 --> Utf8 Class Initialized
INFO - 2020-09-13 10:25:30 --> URI Class Initialized
DEBUG - 2020-09-13 10:25:30 --> No URI present. Default controller set.
INFO - 2020-09-13 10:25:30 --> Router Class Initialized
INFO - 2020-09-13 10:25:30 --> Output Class Initialized
INFO - 2020-09-13 10:25:30 --> Security Class Initialized
DEBUG - 2020-09-13 10:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:25:30 --> Input Class Initialized
INFO - 2020-09-13 10:25:30 --> Language Class Initialized
INFO - 2020-09-13 10:25:30 --> Language Class Initialized
INFO - 2020-09-13 10:25:30 --> Config Class Initialized
INFO - 2020-09-13 10:25:30 --> Loader Class Initialized
INFO - 2020-09-13 10:25:30 --> Helper loaded: url_helper
INFO - 2020-09-13 10:25:30 --> Helper loaded: form_helper
INFO - 2020-09-13 10:25:30 --> Helper loaded: file_helper
INFO - 2020-09-13 10:25:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:25:31 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:25:31 --> Upload Class Initialized
INFO - 2020-09-13 10:25:31 --> Controller Class Initialized
DEBUG - 2020-09-13 10:25:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:25:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:25:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:25:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:25:31 --> Final output sent to browser
DEBUG - 2020-09-13 10:25:31 --> Total execution time: 0.0472
INFO - 2020-09-13 10:25:38 --> Config Class Initialized
INFO - 2020-09-13 10:25:38 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:25:38 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:25:38 --> Utf8 Class Initialized
INFO - 2020-09-13 10:25:38 --> URI Class Initialized
INFO - 2020-09-13 10:25:38 --> Router Class Initialized
INFO - 2020-09-13 10:25:38 --> Output Class Initialized
INFO - 2020-09-13 10:25:38 --> Security Class Initialized
DEBUG - 2020-09-13 10:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:25:38 --> Input Class Initialized
INFO - 2020-09-13 10:25:38 --> Language Class Initialized
INFO - 2020-09-13 10:25:38 --> Language Class Initialized
INFO - 2020-09-13 10:25:38 --> Config Class Initialized
INFO - 2020-09-13 10:25:38 --> Loader Class Initialized
INFO - 2020-09-13 10:25:38 --> Helper loaded: url_helper
INFO - 2020-09-13 10:25:38 --> Helper loaded: form_helper
INFO - 2020-09-13 10:25:38 --> Helper loaded: file_helper
INFO - 2020-09-13 10:25:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:25:38 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:25:38 --> Upload Class Initialized
INFO - 2020-09-13 10:25:38 --> Controller Class Initialized
ERROR - 2020-09-13 10:25:38 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:26:23 --> Config Class Initialized
INFO - 2020-09-13 10:26:23 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:26:23 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:26:23 --> Utf8 Class Initialized
INFO - 2020-09-13 10:26:23 --> URI Class Initialized
DEBUG - 2020-09-13 10:26:23 --> No URI present. Default controller set.
INFO - 2020-09-13 10:26:23 --> Router Class Initialized
INFO - 2020-09-13 10:26:23 --> Output Class Initialized
INFO - 2020-09-13 10:26:23 --> Security Class Initialized
DEBUG - 2020-09-13 10:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:26:23 --> Input Class Initialized
INFO - 2020-09-13 10:26:23 --> Language Class Initialized
INFO - 2020-09-13 10:26:23 --> Language Class Initialized
INFO - 2020-09-13 10:26:23 --> Config Class Initialized
INFO - 2020-09-13 10:26:23 --> Loader Class Initialized
INFO - 2020-09-13 10:26:23 --> Helper loaded: url_helper
INFO - 2020-09-13 10:26:23 --> Helper loaded: form_helper
INFO - 2020-09-13 10:26:23 --> Helper loaded: file_helper
INFO - 2020-09-13 10:26:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:26:23 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:26:23 --> Upload Class Initialized
INFO - 2020-09-13 10:26:23 --> Controller Class Initialized
DEBUG - 2020-09-13 10:26:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:26:23 --> Final output sent to browser
DEBUG - 2020-09-13 10:26:23 --> Total execution time: 0.0555
INFO - 2020-09-13 10:26:31 --> Config Class Initialized
INFO - 2020-09-13 10:26:31 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:26:31 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:26:31 --> Utf8 Class Initialized
INFO - 2020-09-13 10:26:31 --> URI Class Initialized
INFO - 2020-09-13 10:26:31 --> Router Class Initialized
INFO - 2020-09-13 10:26:31 --> Output Class Initialized
INFO - 2020-09-13 10:26:31 --> Security Class Initialized
DEBUG - 2020-09-13 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:26:31 --> Input Class Initialized
INFO - 2020-09-13 10:26:31 --> Language Class Initialized
INFO - 2020-09-13 10:26:31 --> Language Class Initialized
INFO - 2020-09-13 10:26:31 --> Config Class Initialized
INFO - 2020-09-13 10:26:31 --> Loader Class Initialized
INFO - 2020-09-13 10:26:31 --> Helper loaded: url_helper
INFO - 2020-09-13 10:26:31 --> Helper loaded: form_helper
INFO - 2020-09-13 10:26:31 --> Helper loaded: file_helper
INFO - 2020-09-13 10:26:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:26:31 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:26:31 --> Upload Class Initialized
INFO - 2020-09-13 10:26:31 --> Controller Class Initialized
ERROR - 2020-09-13 10:26:31 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:34:25 --> Config Class Initialized
INFO - 2020-09-13 10:34:25 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:34:25 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:34:25 --> Utf8 Class Initialized
INFO - 2020-09-13 10:34:25 --> URI Class Initialized
DEBUG - 2020-09-13 10:34:25 --> No URI present. Default controller set.
INFO - 2020-09-13 10:34:25 --> Router Class Initialized
INFO - 2020-09-13 10:34:25 --> Output Class Initialized
INFO - 2020-09-13 10:34:25 --> Security Class Initialized
DEBUG - 2020-09-13 10:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:34:25 --> Input Class Initialized
INFO - 2020-09-13 10:34:25 --> Language Class Initialized
INFO - 2020-09-13 10:34:25 --> Language Class Initialized
INFO - 2020-09-13 10:34:25 --> Config Class Initialized
INFO - 2020-09-13 10:34:25 --> Loader Class Initialized
INFO - 2020-09-13 10:34:25 --> Helper loaded: url_helper
INFO - 2020-09-13 10:34:25 --> Helper loaded: form_helper
INFO - 2020-09-13 10:34:25 --> Helper loaded: file_helper
INFO - 2020-09-13 10:34:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:34:25 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:34:25 --> Upload Class Initialized
INFO - 2020-09-13 10:34:25 --> Controller Class Initialized
DEBUG - 2020-09-13 10:34:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:34:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:34:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:34:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:34:25 --> Final output sent to browser
DEBUG - 2020-09-13 10:34:25 --> Total execution time: 0.0411
INFO - 2020-09-13 10:34:26 --> Config Class Initialized
INFO - 2020-09-13 10:34:26 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:34:26 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:34:26 --> Utf8 Class Initialized
INFO - 2020-09-13 10:34:26 --> URI Class Initialized
INFO - 2020-09-13 10:34:26 --> Router Class Initialized
INFO - 2020-09-13 10:34:26 --> Output Class Initialized
INFO - 2020-09-13 10:34:26 --> Security Class Initialized
DEBUG - 2020-09-13 10:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:34:26 --> Input Class Initialized
INFO - 2020-09-13 10:34:26 --> Language Class Initialized
INFO - 2020-09-13 10:34:26 --> Language Class Initialized
INFO - 2020-09-13 10:34:26 --> Config Class Initialized
INFO - 2020-09-13 10:34:26 --> Loader Class Initialized
INFO - 2020-09-13 10:34:26 --> Helper loaded: url_helper
INFO - 2020-09-13 10:34:26 --> Helper loaded: form_helper
INFO - 2020-09-13 10:34:26 --> Helper loaded: file_helper
INFO - 2020-09-13 10:34:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:34:26 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:34:26 --> Upload Class Initialized
INFO - 2020-09-13 10:34:26 --> Controller Class Initialized
ERROR - 2020-09-13 10:34:26 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:34:33 --> Config Class Initialized
INFO - 2020-09-13 10:34:33 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:34:33 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:34:33 --> Utf8 Class Initialized
INFO - 2020-09-13 10:34:33 --> URI Class Initialized
INFO - 2020-09-13 10:34:33 --> Router Class Initialized
INFO - 2020-09-13 10:34:33 --> Output Class Initialized
INFO - 2020-09-13 10:34:33 --> Security Class Initialized
DEBUG - 2020-09-13 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:34:33 --> Input Class Initialized
INFO - 2020-09-13 10:34:33 --> Language Class Initialized
INFO - 2020-09-13 10:34:33 --> Language Class Initialized
INFO - 2020-09-13 10:34:33 --> Config Class Initialized
INFO - 2020-09-13 10:34:33 --> Loader Class Initialized
INFO - 2020-09-13 10:34:33 --> Helper loaded: url_helper
INFO - 2020-09-13 10:34:33 --> Helper loaded: form_helper
INFO - 2020-09-13 10:34:33 --> Helper loaded: file_helper
INFO - 2020-09-13 10:34:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:34:33 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:34:33 --> Upload Class Initialized
INFO - 2020-09-13 10:34:33 --> Controller Class Initialized
ERROR - 2020-09-13 10:34:33 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:34:37 --> Config Class Initialized
INFO - 2020-09-13 10:34:37 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:34:37 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:34:37 --> Utf8 Class Initialized
INFO - 2020-09-13 10:34:37 --> URI Class Initialized
DEBUG - 2020-09-13 10:34:37 --> No URI present. Default controller set.
INFO - 2020-09-13 10:34:37 --> Router Class Initialized
INFO - 2020-09-13 10:34:37 --> Output Class Initialized
INFO - 2020-09-13 10:34:37 --> Security Class Initialized
DEBUG - 2020-09-13 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:34:37 --> Input Class Initialized
INFO - 2020-09-13 10:34:37 --> Language Class Initialized
INFO - 2020-09-13 10:34:37 --> Language Class Initialized
INFO - 2020-09-13 10:34:37 --> Config Class Initialized
INFO - 2020-09-13 10:34:37 --> Loader Class Initialized
INFO - 2020-09-13 10:34:37 --> Helper loaded: url_helper
INFO - 2020-09-13 10:34:37 --> Helper loaded: form_helper
INFO - 2020-09-13 10:34:37 --> Helper loaded: file_helper
INFO - 2020-09-13 10:34:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:34:37 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:34:37 --> Upload Class Initialized
INFO - 2020-09-13 10:34:37 --> Controller Class Initialized
DEBUG - 2020-09-13 10:34:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:34:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:34:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:34:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:34:37 --> Final output sent to browser
DEBUG - 2020-09-13 10:34:37 --> Total execution time: 0.0508
INFO - 2020-09-13 10:36:47 --> Config Class Initialized
INFO - 2020-09-13 10:36:47 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:36:47 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:36:47 --> Utf8 Class Initialized
INFO - 2020-09-13 10:36:47 --> URI Class Initialized
DEBUG - 2020-09-13 10:36:47 --> No URI present. Default controller set.
INFO - 2020-09-13 10:36:47 --> Router Class Initialized
INFO - 2020-09-13 10:36:47 --> Output Class Initialized
INFO - 2020-09-13 10:36:47 --> Security Class Initialized
DEBUG - 2020-09-13 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:36:47 --> Input Class Initialized
INFO - 2020-09-13 10:36:47 --> Language Class Initialized
INFO - 2020-09-13 10:36:47 --> Language Class Initialized
INFO - 2020-09-13 10:36:47 --> Config Class Initialized
INFO - 2020-09-13 10:36:47 --> Loader Class Initialized
INFO - 2020-09-13 10:36:47 --> Helper loaded: url_helper
INFO - 2020-09-13 10:36:47 --> Helper loaded: form_helper
INFO - 2020-09-13 10:36:47 --> Helper loaded: file_helper
INFO - 2020-09-13 10:36:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:36:47 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:36:47 --> Upload Class Initialized
INFO - 2020-09-13 10:36:47 --> Controller Class Initialized
DEBUG - 2020-09-13 10:36:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:36:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:36:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:36:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:36:47 --> Final output sent to browser
DEBUG - 2020-09-13 10:36:47 --> Total execution time: 0.0630
INFO - 2020-09-13 10:36:49 --> Config Class Initialized
INFO - 2020-09-13 10:36:49 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:36:49 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:36:49 --> Utf8 Class Initialized
INFO - 2020-09-13 10:36:49 --> URI Class Initialized
INFO - 2020-09-13 10:36:49 --> Router Class Initialized
INFO - 2020-09-13 10:36:49 --> Output Class Initialized
INFO - 2020-09-13 10:36:49 --> Security Class Initialized
DEBUG - 2020-09-13 10:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:36:49 --> Input Class Initialized
INFO - 2020-09-13 10:36:49 --> Language Class Initialized
INFO - 2020-09-13 10:36:49 --> Language Class Initialized
INFO - 2020-09-13 10:36:49 --> Config Class Initialized
INFO - 2020-09-13 10:36:49 --> Loader Class Initialized
INFO - 2020-09-13 10:36:49 --> Helper loaded: url_helper
INFO - 2020-09-13 10:36:49 --> Helper loaded: form_helper
INFO - 2020-09-13 10:36:49 --> Helper loaded: file_helper
INFO - 2020-09-13 10:36:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:36:49 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:36:49 --> Upload Class Initialized
INFO - 2020-09-13 10:36:49 --> Controller Class Initialized
ERROR - 2020-09-13 10:36:49 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:37:50 --> Config Class Initialized
INFO - 2020-09-13 10:37:50 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:37:50 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:37:50 --> Utf8 Class Initialized
INFO - 2020-09-13 10:37:50 --> URI Class Initialized
DEBUG - 2020-09-13 10:37:50 --> No URI present. Default controller set.
INFO - 2020-09-13 10:37:50 --> Router Class Initialized
INFO - 2020-09-13 10:37:50 --> Output Class Initialized
INFO - 2020-09-13 10:37:50 --> Security Class Initialized
DEBUG - 2020-09-13 10:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:37:50 --> Input Class Initialized
INFO - 2020-09-13 10:37:50 --> Language Class Initialized
INFO - 2020-09-13 10:37:50 --> Language Class Initialized
INFO - 2020-09-13 10:37:50 --> Config Class Initialized
INFO - 2020-09-13 10:37:50 --> Loader Class Initialized
INFO - 2020-09-13 10:37:50 --> Helper loaded: url_helper
INFO - 2020-09-13 10:37:50 --> Helper loaded: form_helper
INFO - 2020-09-13 10:37:50 --> Helper loaded: file_helper
INFO - 2020-09-13 10:37:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:37:50 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:37:50 --> Upload Class Initialized
INFO - 2020-09-13 10:37:50 --> Controller Class Initialized
DEBUG - 2020-09-13 10:37:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:37:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:37:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:37:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:37:50 --> Final output sent to browser
DEBUG - 2020-09-13 10:37:50 --> Total execution time: 0.0601
INFO - 2020-09-13 10:37:51 --> Config Class Initialized
INFO - 2020-09-13 10:37:51 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:37:51 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:37:51 --> Utf8 Class Initialized
INFO - 2020-09-13 10:37:51 --> URI Class Initialized
INFO - 2020-09-13 10:37:51 --> Router Class Initialized
INFO - 2020-09-13 10:37:51 --> Output Class Initialized
INFO - 2020-09-13 10:37:51 --> Security Class Initialized
DEBUG - 2020-09-13 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:37:51 --> Input Class Initialized
INFO - 2020-09-13 10:37:51 --> Language Class Initialized
INFO - 2020-09-13 10:37:51 --> Language Class Initialized
INFO - 2020-09-13 10:37:51 --> Config Class Initialized
INFO - 2020-09-13 10:37:51 --> Loader Class Initialized
INFO - 2020-09-13 10:37:51 --> Helper loaded: url_helper
INFO - 2020-09-13 10:37:51 --> Helper loaded: form_helper
INFO - 2020-09-13 10:37:51 --> Helper loaded: file_helper
INFO - 2020-09-13 10:37:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:37:51 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:37:51 --> Upload Class Initialized
INFO - 2020-09-13 10:37:51 --> Controller Class Initialized
ERROR - 2020-09-13 10:37:51 --> 404 Page Not Found: /index
INFO - 2020-09-13 10:37:53 --> Config Class Initialized
INFO - 2020-09-13 10:37:53 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:37:53 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:37:53 --> Utf8 Class Initialized
INFO - 2020-09-13 10:37:53 --> URI Class Initialized
DEBUG - 2020-09-13 10:37:53 --> No URI present. Default controller set.
INFO - 2020-09-13 10:37:53 --> Router Class Initialized
INFO - 2020-09-13 10:37:53 --> Output Class Initialized
INFO - 2020-09-13 10:37:53 --> Security Class Initialized
DEBUG - 2020-09-13 10:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:37:53 --> Input Class Initialized
INFO - 2020-09-13 10:37:53 --> Language Class Initialized
INFO - 2020-09-13 10:37:53 --> Language Class Initialized
INFO - 2020-09-13 10:37:53 --> Config Class Initialized
INFO - 2020-09-13 10:37:53 --> Loader Class Initialized
INFO - 2020-09-13 10:37:53 --> Helper loaded: url_helper
INFO - 2020-09-13 10:37:53 --> Helper loaded: form_helper
INFO - 2020-09-13 10:37:53 --> Helper loaded: file_helper
INFO - 2020-09-13 10:37:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:37:53 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:37:53 --> Upload Class Initialized
INFO - 2020-09-13 10:37:53 --> Controller Class Initialized
DEBUG - 2020-09-13 10:37:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:37:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:37:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:37:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:37:53 --> Final output sent to browser
DEBUG - 2020-09-13 10:37:53 --> Total execution time: 0.0517
INFO - 2020-09-13 10:48:14 --> Config Class Initialized
INFO - 2020-09-13 10:48:14 --> Hooks Class Initialized
DEBUG - 2020-09-13 10:48:14 --> UTF-8 Support Enabled
INFO - 2020-09-13 10:48:14 --> Utf8 Class Initialized
INFO - 2020-09-13 10:48:14 --> URI Class Initialized
DEBUG - 2020-09-13 10:48:14 --> No URI present. Default controller set.
INFO - 2020-09-13 10:48:14 --> Router Class Initialized
INFO - 2020-09-13 10:48:14 --> Output Class Initialized
INFO - 2020-09-13 10:48:14 --> Security Class Initialized
DEBUG - 2020-09-13 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 10:48:14 --> Input Class Initialized
INFO - 2020-09-13 10:48:14 --> Language Class Initialized
INFO - 2020-09-13 10:48:14 --> Language Class Initialized
INFO - 2020-09-13 10:48:14 --> Config Class Initialized
INFO - 2020-09-13 10:48:14 --> Loader Class Initialized
INFO - 2020-09-13 10:48:14 --> Helper loaded: url_helper
INFO - 2020-09-13 10:48:14 --> Helper loaded: form_helper
INFO - 2020-09-13 10:48:14 --> Helper loaded: file_helper
INFO - 2020-09-13 10:48:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 10:48:14 --> Database Driver Class Initialized
DEBUG - 2020-09-13 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 10:48:14 --> Upload Class Initialized
INFO - 2020-09-13 10:48:14 --> Controller Class Initialized
DEBUG - 2020-09-13 10:48:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 10:48:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 10:48:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 10:48:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 10:48:14 --> Final output sent to browser
DEBUG - 2020-09-13 10:48:14 --> Total execution time: 0.0491
INFO - 2020-09-13 11:13:28 --> Config Class Initialized
INFO - 2020-09-13 11:13:28 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:13:28 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:13:28 --> Utf8 Class Initialized
INFO - 2020-09-13 11:13:28 --> URI Class Initialized
DEBUG - 2020-09-13 11:13:28 --> No URI present. Default controller set.
INFO - 2020-09-13 11:13:28 --> Router Class Initialized
INFO - 2020-09-13 11:13:28 --> Output Class Initialized
INFO - 2020-09-13 11:13:28 --> Security Class Initialized
DEBUG - 2020-09-13 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:13:28 --> Input Class Initialized
INFO - 2020-09-13 11:13:28 --> Language Class Initialized
INFO - 2020-09-13 11:13:28 --> Language Class Initialized
INFO - 2020-09-13 11:13:28 --> Config Class Initialized
INFO - 2020-09-13 11:13:28 --> Loader Class Initialized
INFO - 2020-09-13 11:13:28 --> Helper loaded: url_helper
INFO - 2020-09-13 11:13:28 --> Helper loaded: form_helper
INFO - 2020-09-13 11:13:28 --> Helper loaded: file_helper
INFO - 2020-09-13 11:13:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:13:28 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:13:28 --> Upload Class Initialized
INFO - 2020-09-13 11:13:28 --> Controller Class Initialized
DEBUG - 2020-09-13 11:13:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 11:13:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 11:13:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 11:13:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 11:13:28 --> Final output sent to browser
DEBUG - 2020-09-13 11:13:28 --> Total execution time: 0.0638
INFO - 2020-09-13 11:31:08 --> Config Class Initialized
INFO - 2020-09-13 11:31:08 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:31:08 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:31:08 --> Utf8 Class Initialized
INFO - 2020-09-13 11:31:08 --> URI Class Initialized
DEBUG - 2020-09-13 11:31:08 --> No URI present. Default controller set.
INFO - 2020-09-13 11:31:08 --> Router Class Initialized
INFO - 2020-09-13 11:31:08 --> Output Class Initialized
INFO - 2020-09-13 11:31:08 --> Security Class Initialized
DEBUG - 2020-09-13 11:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:31:08 --> Input Class Initialized
INFO - 2020-09-13 11:31:08 --> Language Class Initialized
INFO - 2020-09-13 11:31:08 --> Language Class Initialized
INFO - 2020-09-13 11:31:08 --> Config Class Initialized
INFO - 2020-09-13 11:31:08 --> Loader Class Initialized
INFO - 2020-09-13 11:31:08 --> Helper loaded: url_helper
INFO - 2020-09-13 11:31:08 --> Helper loaded: form_helper
INFO - 2020-09-13 11:31:08 --> Helper loaded: file_helper
INFO - 2020-09-13 11:31:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:31:08 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:31:08 --> Upload Class Initialized
INFO - 2020-09-13 11:31:08 --> Controller Class Initialized
DEBUG - 2020-09-13 11:31:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 11:31:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 11:31:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 11:31:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 11:31:08 --> Final output sent to browser
DEBUG - 2020-09-13 11:31:08 --> Total execution time: 0.0476
INFO - 2020-09-13 11:31:09 --> Config Class Initialized
INFO - 2020-09-13 11:31:09 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:31:09 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:31:09 --> Utf8 Class Initialized
INFO - 2020-09-13 11:31:09 --> URI Class Initialized
INFO - 2020-09-13 11:31:09 --> Router Class Initialized
INFO - 2020-09-13 11:31:09 --> Output Class Initialized
INFO - 2020-09-13 11:31:09 --> Security Class Initialized
DEBUG - 2020-09-13 11:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:31:09 --> Input Class Initialized
INFO - 2020-09-13 11:31:09 --> Language Class Initialized
INFO - 2020-09-13 11:31:09 --> Language Class Initialized
INFO - 2020-09-13 11:31:09 --> Config Class Initialized
INFO - 2020-09-13 11:31:09 --> Loader Class Initialized
INFO - 2020-09-13 11:31:09 --> Helper loaded: url_helper
INFO - 2020-09-13 11:31:09 --> Helper loaded: form_helper
INFO - 2020-09-13 11:31:09 --> Helper loaded: file_helper
INFO - 2020-09-13 11:31:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:31:09 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:31:09 --> Upload Class Initialized
INFO - 2020-09-13 11:31:09 --> Controller Class Initialized
ERROR - 2020-09-13 11:31:09 --> 404 Page Not Found: /index
INFO - 2020-09-13 11:38:37 --> Config Class Initialized
INFO - 2020-09-13 11:38:37 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:38:37 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:38:37 --> Utf8 Class Initialized
INFO - 2020-09-13 11:38:37 --> URI Class Initialized
INFO - 2020-09-13 11:38:37 --> Router Class Initialized
INFO - 2020-09-13 11:38:37 --> Output Class Initialized
INFO - 2020-09-13 11:38:37 --> Security Class Initialized
DEBUG - 2020-09-13 11:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:38:37 --> Input Class Initialized
INFO - 2020-09-13 11:38:37 --> Language Class Initialized
INFO - 2020-09-13 11:38:37 --> Language Class Initialized
INFO - 2020-09-13 11:38:37 --> Config Class Initialized
INFO - 2020-09-13 11:38:37 --> Loader Class Initialized
INFO - 2020-09-13 11:38:37 --> Helper loaded: url_helper
INFO - 2020-09-13 11:38:37 --> Helper loaded: form_helper
INFO - 2020-09-13 11:38:37 --> Helper loaded: file_helper
INFO - 2020-09-13 11:38:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:38:37 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:38:37 --> Upload Class Initialized
INFO - 2020-09-13 11:38:37 --> Controller Class Initialized
ERROR - 2020-09-13 11:38:37 --> 404 Page Not Found: /index
INFO - 2020-09-13 11:38:51 --> Config Class Initialized
INFO - 2020-09-13 11:38:51 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:38:51 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:38:51 --> Utf8 Class Initialized
INFO - 2020-09-13 11:38:51 --> URI Class Initialized
INFO - 2020-09-13 11:38:51 --> Router Class Initialized
INFO - 2020-09-13 11:38:51 --> Output Class Initialized
INFO - 2020-09-13 11:38:51 --> Security Class Initialized
DEBUG - 2020-09-13 11:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:38:51 --> Input Class Initialized
INFO - 2020-09-13 11:38:51 --> Language Class Initialized
INFO - 2020-09-13 11:38:51 --> Language Class Initialized
INFO - 2020-09-13 11:38:51 --> Config Class Initialized
INFO - 2020-09-13 11:38:51 --> Loader Class Initialized
INFO - 2020-09-13 11:38:51 --> Helper loaded: url_helper
INFO - 2020-09-13 11:38:51 --> Helper loaded: form_helper
INFO - 2020-09-13 11:38:51 --> Helper loaded: file_helper
INFO - 2020-09-13 11:38:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:38:51 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:38:51 --> Upload Class Initialized
INFO - 2020-09-13 11:38:51 --> Controller Class Initialized
ERROR - 2020-09-13 11:38:51 --> 404 Page Not Found: /index
INFO - 2020-09-13 11:39:06 --> Config Class Initialized
INFO - 2020-09-13 11:39:06 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:39:06 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:39:06 --> Utf8 Class Initialized
INFO - 2020-09-13 11:39:06 --> URI Class Initialized
DEBUG - 2020-09-13 11:39:06 --> No URI present. Default controller set.
INFO - 2020-09-13 11:39:06 --> Router Class Initialized
INFO - 2020-09-13 11:39:06 --> Output Class Initialized
INFO - 2020-09-13 11:39:06 --> Security Class Initialized
DEBUG - 2020-09-13 11:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:39:06 --> Input Class Initialized
INFO - 2020-09-13 11:39:06 --> Language Class Initialized
INFO - 2020-09-13 11:39:06 --> Language Class Initialized
INFO - 2020-09-13 11:39:06 --> Config Class Initialized
INFO - 2020-09-13 11:39:06 --> Loader Class Initialized
INFO - 2020-09-13 11:39:06 --> Helper loaded: url_helper
INFO - 2020-09-13 11:39:06 --> Helper loaded: form_helper
INFO - 2020-09-13 11:39:06 --> Helper loaded: file_helper
INFO - 2020-09-13 11:39:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:39:06 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:39:06 --> Upload Class Initialized
INFO - 2020-09-13 11:39:06 --> Controller Class Initialized
DEBUG - 2020-09-13 11:39:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 11:39:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 11:39:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 11:39:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 11:39:06 --> Final output sent to browser
DEBUG - 2020-09-13 11:39:06 --> Total execution time: 0.0365
INFO - 2020-09-13 11:53:16 --> Config Class Initialized
INFO - 2020-09-13 11:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:53:16 --> Utf8 Class Initialized
INFO - 2020-09-13 11:53:16 --> URI Class Initialized
INFO - 2020-09-13 11:53:16 --> Router Class Initialized
INFO - 2020-09-13 11:53:16 --> Output Class Initialized
INFO - 2020-09-13 11:53:16 --> Security Class Initialized
DEBUG - 2020-09-13 11:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:53:16 --> Input Class Initialized
INFO - 2020-09-13 11:53:16 --> Language Class Initialized
INFO - 2020-09-13 11:53:16 --> Language Class Initialized
INFO - 2020-09-13 11:53:16 --> Config Class Initialized
INFO - 2020-09-13 11:53:16 --> Loader Class Initialized
INFO - 2020-09-13 11:53:16 --> Helper loaded: url_helper
INFO - 2020-09-13 11:53:16 --> Helper loaded: form_helper
INFO - 2020-09-13 11:53:16 --> Helper loaded: file_helper
INFO - 2020-09-13 11:53:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:53:16 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:53:16 --> Upload Class Initialized
INFO - 2020-09-13 11:53:16 --> Controller Class Initialized
DEBUG - 2020-09-13 11:53:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 11:53:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-13 11:53:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 11:53:16 --> Final output sent to browser
DEBUG - 2020-09-13 11:53:16 --> Total execution time: 0.0422
INFO - 2020-09-13 11:53:16 --> Config Class Initialized
INFO - 2020-09-13 11:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:53:16 --> Utf8 Class Initialized
INFO - 2020-09-13 11:53:16 --> URI Class Initialized
INFO - 2020-09-13 11:53:16 --> Router Class Initialized
INFO - 2020-09-13 11:53:16 --> Output Class Initialized
INFO - 2020-09-13 11:53:16 --> Security Class Initialized
DEBUG - 2020-09-13 11:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:53:16 --> Input Class Initialized
INFO - 2020-09-13 11:53:16 --> Language Class Initialized
INFO - 2020-09-13 11:53:16 --> Language Class Initialized
INFO - 2020-09-13 11:53:16 --> Config Class Initialized
INFO - 2020-09-13 11:53:16 --> Loader Class Initialized
INFO - 2020-09-13 11:53:16 --> Helper loaded: url_helper
INFO - 2020-09-13 11:53:16 --> Helper loaded: form_helper
INFO - 2020-09-13 11:53:16 --> Helper loaded: file_helper
INFO - 2020-09-13 11:53:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:53:16 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:53:16 --> Upload Class Initialized
INFO - 2020-09-13 11:53:16 --> Controller Class Initialized
DEBUG - 2020-09-13 11:53:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 11:53:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-13 11:53:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 11:53:16 --> Final output sent to browser
DEBUG - 2020-09-13 11:53:16 --> Total execution time: 0.0355
INFO - 2020-09-13 11:53:18 --> Config Class Initialized
INFO - 2020-09-13 11:53:18 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:53:18 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:53:18 --> Utf8 Class Initialized
INFO - 2020-09-13 11:53:18 --> URI Class Initialized
INFO - 2020-09-13 11:53:18 --> Router Class Initialized
INFO - 2020-09-13 11:53:18 --> Output Class Initialized
INFO - 2020-09-13 11:53:18 --> Security Class Initialized
DEBUG - 2020-09-13 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:53:18 --> Input Class Initialized
INFO - 2020-09-13 11:53:18 --> Language Class Initialized
INFO - 2020-09-13 11:53:18 --> Language Class Initialized
INFO - 2020-09-13 11:53:18 --> Config Class Initialized
INFO - 2020-09-13 11:53:18 --> Loader Class Initialized
INFO - 2020-09-13 11:53:18 --> Helper loaded: url_helper
INFO - 2020-09-13 11:53:18 --> Helper loaded: form_helper
INFO - 2020-09-13 11:53:18 --> Helper loaded: file_helper
INFO - 2020-09-13 11:53:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:53:18 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:53:18 --> Upload Class Initialized
INFO - 2020-09-13 11:53:18 --> Controller Class Initialized
DEBUG - 2020-09-13 11:53:18 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 11:53:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-13 11:53:18 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 11:53:18 --> Final output sent to browser
DEBUG - 2020-09-13 11:53:18 --> Total execution time: 0.0423
INFO - 2020-09-13 11:53:25 --> Config Class Initialized
INFO - 2020-09-13 11:53:25 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:53:25 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:53:25 --> Utf8 Class Initialized
INFO - 2020-09-13 11:53:25 --> URI Class Initialized
INFO - 2020-09-13 11:53:25 --> Router Class Initialized
INFO - 2020-09-13 11:53:25 --> Output Class Initialized
INFO - 2020-09-13 11:53:25 --> Security Class Initialized
DEBUG - 2020-09-13 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:53:25 --> Input Class Initialized
INFO - 2020-09-13 11:53:25 --> Language Class Initialized
INFO - 2020-09-13 11:53:25 --> Language Class Initialized
INFO - 2020-09-13 11:53:25 --> Config Class Initialized
INFO - 2020-09-13 11:53:25 --> Loader Class Initialized
INFO - 2020-09-13 11:53:25 --> Helper loaded: url_helper
INFO - 2020-09-13 11:53:25 --> Helper loaded: form_helper
INFO - 2020-09-13 11:53:25 --> Helper loaded: file_helper
INFO - 2020-09-13 11:53:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:53:25 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:53:25 --> Upload Class Initialized
INFO - 2020-09-13 11:53:26 --> Controller Class Initialized
ERROR - 2020-09-13 11:53:26 --> 404 Page Not Found: /index
INFO - 2020-09-13 11:53:26 --> Config Class Initialized
INFO - 2020-09-13 11:53:26 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:53:26 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:53:26 --> Utf8 Class Initialized
INFO - 2020-09-13 11:53:26 --> URI Class Initialized
INFO - 2020-09-13 11:53:26 --> Router Class Initialized
INFO - 2020-09-13 11:53:26 --> Output Class Initialized
INFO - 2020-09-13 11:53:26 --> Security Class Initialized
DEBUG - 2020-09-13 11:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:53:26 --> Input Class Initialized
INFO - 2020-09-13 11:53:26 --> Language Class Initialized
INFO - 2020-09-13 11:53:26 --> Language Class Initialized
INFO - 2020-09-13 11:53:26 --> Config Class Initialized
INFO - 2020-09-13 11:53:26 --> Loader Class Initialized
INFO - 2020-09-13 11:53:26 --> Helper loaded: url_helper
INFO - 2020-09-13 11:53:26 --> Helper loaded: form_helper
INFO - 2020-09-13 11:53:26 --> Helper loaded: file_helper
INFO - 2020-09-13 11:53:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:53:26 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:53:26 --> Upload Class Initialized
INFO - 2020-09-13 11:53:26 --> Controller Class Initialized
ERROR - 2020-09-13 11:53:26 --> 404 Page Not Found: /index
INFO - 2020-09-13 11:53:26 --> Config Class Initialized
INFO - 2020-09-13 11:53:26 --> Hooks Class Initialized
DEBUG - 2020-09-13 11:53:26 --> UTF-8 Support Enabled
INFO - 2020-09-13 11:53:26 --> Utf8 Class Initialized
INFO - 2020-09-13 11:53:26 --> URI Class Initialized
INFO - 2020-09-13 11:53:26 --> Router Class Initialized
INFO - 2020-09-13 11:53:26 --> Output Class Initialized
INFO - 2020-09-13 11:53:26 --> Security Class Initialized
DEBUG - 2020-09-13 11:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 11:53:26 --> Input Class Initialized
INFO - 2020-09-13 11:53:26 --> Language Class Initialized
INFO - 2020-09-13 11:53:26 --> Language Class Initialized
INFO - 2020-09-13 11:53:26 --> Config Class Initialized
INFO - 2020-09-13 11:53:26 --> Loader Class Initialized
INFO - 2020-09-13 11:53:26 --> Helper loaded: url_helper
INFO - 2020-09-13 11:53:26 --> Helper loaded: form_helper
INFO - 2020-09-13 11:53:26 --> Helper loaded: file_helper
INFO - 2020-09-13 11:53:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 11:53:26 --> Database Driver Class Initialized
DEBUG - 2020-09-13 11:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 11:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 11:53:26 --> Upload Class Initialized
INFO - 2020-09-13 11:53:26 --> Controller Class Initialized
ERROR - 2020-09-13 11:53:26 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:07:35 --> Config Class Initialized
INFO - 2020-09-13 12:07:35 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:07:35 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:07:35 --> Utf8 Class Initialized
INFO - 2020-09-13 12:07:35 --> URI Class Initialized
DEBUG - 2020-09-13 12:07:35 --> No URI present. Default controller set.
INFO - 2020-09-13 12:07:35 --> Router Class Initialized
INFO - 2020-09-13 12:07:35 --> Output Class Initialized
INFO - 2020-09-13 12:07:35 --> Security Class Initialized
DEBUG - 2020-09-13 12:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:07:35 --> Input Class Initialized
INFO - 2020-09-13 12:07:35 --> Language Class Initialized
INFO - 2020-09-13 12:07:35 --> Language Class Initialized
INFO - 2020-09-13 12:07:35 --> Config Class Initialized
INFO - 2020-09-13 12:07:35 --> Loader Class Initialized
INFO - 2020-09-13 12:07:35 --> Helper loaded: url_helper
INFO - 2020-09-13 12:07:35 --> Helper loaded: form_helper
INFO - 2020-09-13 12:07:35 --> Helper loaded: file_helper
INFO - 2020-09-13 12:07:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:07:35 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:07:35 --> Upload Class Initialized
INFO - 2020-09-13 12:07:35 --> Controller Class Initialized
DEBUG - 2020-09-13 12:07:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:07:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:07:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:07:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:07:35 --> Final output sent to browser
DEBUG - 2020-09-13 12:07:35 --> Total execution time: 0.0522
INFO - 2020-09-13 12:07:43 --> Config Class Initialized
INFO - 2020-09-13 12:07:43 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:07:43 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:07:43 --> Utf8 Class Initialized
INFO - 2020-09-13 12:07:43 --> URI Class Initialized
INFO - 2020-09-13 12:07:43 --> Router Class Initialized
INFO - 2020-09-13 12:07:43 --> Output Class Initialized
INFO - 2020-09-13 12:07:43 --> Security Class Initialized
DEBUG - 2020-09-13 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:07:43 --> Input Class Initialized
INFO - 2020-09-13 12:07:43 --> Language Class Initialized
INFO - 2020-09-13 12:07:43 --> Language Class Initialized
INFO - 2020-09-13 12:07:43 --> Config Class Initialized
INFO - 2020-09-13 12:07:43 --> Loader Class Initialized
INFO - 2020-09-13 12:07:43 --> Helper loaded: url_helper
INFO - 2020-09-13 12:07:43 --> Helper loaded: form_helper
INFO - 2020-09-13 12:07:43 --> Helper loaded: file_helper
INFO - 2020-09-13 12:07:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:07:43 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:07:43 --> Upload Class Initialized
INFO - 2020-09-13 12:07:43 --> Controller Class Initialized
ERROR - 2020-09-13 12:07:43 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:07:44 --> Config Class Initialized
INFO - 2020-09-13 12:07:44 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:07:44 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:07:44 --> Utf8 Class Initialized
INFO - 2020-09-13 12:07:44 --> URI Class Initialized
INFO - 2020-09-13 12:07:44 --> Router Class Initialized
INFO - 2020-09-13 12:07:44 --> Output Class Initialized
INFO - 2020-09-13 12:07:44 --> Security Class Initialized
DEBUG - 2020-09-13 12:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:07:44 --> Input Class Initialized
INFO - 2020-09-13 12:07:44 --> Language Class Initialized
INFO - 2020-09-13 12:07:44 --> Language Class Initialized
INFO - 2020-09-13 12:07:44 --> Config Class Initialized
INFO - 2020-09-13 12:07:44 --> Loader Class Initialized
INFO - 2020-09-13 12:07:44 --> Helper loaded: url_helper
INFO - 2020-09-13 12:07:44 --> Helper loaded: form_helper
INFO - 2020-09-13 12:07:44 --> Helper loaded: file_helper
INFO - 2020-09-13 12:07:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:07:44 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:07:44 --> Upload Class Initialized
INFO - 2020-09-13 12:07:44 --> Controller Class Initialized
ERROR - 2020-09-13 12:07:44 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:09:38 --> Config Class Initialized
INFO - 2020-09-13 12:09:38 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:09:38 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:09:38 --> Utf8 Class Initialized
INFO - 2020-09-13 12:09:38 --> URI Class Initialized
DEBUG - 2020-09-13 12:09:38 --> No URI present. Default controller set.
INFO - 2020-09-13 12:09:38 --> Router Class Initialized
INFO - 2020-09-13 12:09:38 --> Output Class Initialized
INFO - 2020-09-13 12:09:38 --> Security Class Initialized
DEBUG - 2020-09-13 12:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:09:38 --> Input Class Initialized
INFO - 2020-09-13 12:09:38 --> Language Class Initialized
INFO - 2020-09-13 12:09:38 --> Language Class Initialized
INFO - 2020-09-13 12:09:38 --> Config Class Initialized
INFO - 2020-09-13 12:09:38 --> Loader Class Initialized
INFO - 2020-09-13 12:09:38 --> Helper loaded: url_helper
INFO - 2020-09-13 12:09:38 --> Helper loaded: form_helper
INFO - 2020-09-13 12:09:38 --> Helper loaded: file_helper
INFO - 2020-09-13 12:09:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:09:38 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:09:38 --> Upload Class Initialized
INFO - 2020-09-13 12:09:38 --> Controller Class Initialized
DEBUG - 2020-09-13 12:09:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:09:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:09:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:09:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:09:38 --> Final output sent to browser
DEBUG - 2020-09-13 12:09:38 --> Total execution time: 0.0532
INFO - 2020-09-13 12:09:52 --> Config Class Initialized
INFO - 2020-09-13 12:09:52 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:09:52 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:09:52 --> Utf8 Class Initialized
INFO - 2020-09-13 12:09:52 --> URI Class Initialized
INFO - 2020-09-13 12:09:52 --> Router Class Initialized
INFO - 2020-09-13 12:09:52 --> Output Class Initialized
INFO - 2020-09-13 12:09:52 --> Security Class Initialized
DEBUG - 2020-09-13 12:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:09:52 --> Input Class Initialized
INFO - 2020-09-13 12:09:52 --> Language Class Initialized
INFO - 2020-09-13 12:09:52 --> Language Class Initialized
INFO - 2020-09-13 12:09:52 --> Config Class Initialized
INFO - 2020-09-13 12:09:52 --> Loader Class Initialized
INFO - 2020-09-13 12:09:52 --> Helper loaded: url_helper
INFO - 2020-09-13 12:09:52 --> Helper loaded: form_helper
INFO - 2020-09-13 12:09:52 --> Helper loaded: file_helper
INFO - 2020-09-13 12:09:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:09:52 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:09:52 --> Upload Class Initialized
INFO - 2020-09-13 12:09:52 --> Controller Class Initialized
ERROR - 2020-09-13 12:09:52 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:09:59 --> Config Class Initialized
INFO - 2020-09-13 12:09:59 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:09:59 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:09:59 --> Utf8 Class Initialized
INFO - 2020-09-13 12:09:59 --> URI Class Initialized
INFO - 2020-09-13 12:09:59 --> Router Class Initialized
INFO - 2020-09-13 12:09:59 --> Output Class Initialized
INFO - 2020-09-13 12:09:59 --> Security Class Initialized
DEBUG - 2020-09-13 12:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:09:59 --> Input Class Initialized
INFO - 2020-09-13 12:09:59 --> Language Class Initialized
INFO - 2020-09-13 12:09:59 --> Language Class Initialized
INFO - 2020-09-13 12:09:59 --> Config Class Initialized
INFO - 2020-09-13 12:09:59 --> Loader Class Initialized
INFO - 2020-09-13 12:09:59 --> Helper loaded: url_helper
INFO - 2020-09-13 12:09:59 --> Helper loaded: form_helper
INFO - 2020-09-13 12:09:59 --> Helper loaded: file_helper
INFO - 2020-09-13 12:09:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:09:59 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:09:59 --> Upload Class Initialized
INFO - 2020-09-13 12:09:59 --> Controller Class Initialized
ERROR - 2020-09-13 12:09:59 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:10:10 --> Config Class Initialized
INFO - 2020-09-13 12:10:10 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:10:10 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:10:10 --> Utf8 Class Initialized
INFO - 2020-09-13 12:10:10 --> URI Class Initialized
DEBUG - 2020-09-13 12:10:10 --> No URI present. Default controller set.
INFO - 2020-09-13 12:10:10 --> Router Class Initialized
INFO - 2020-09-13 12:10:10 --> Output Class Initialized
INFO - 2020-09-13 12:10:10 --> Security Class Initialized
DEBUG - 2020-09-13 12:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:10:10 --> Input Class Initialized
INFO - 2020-09-13 12:10:10 --> Language Class Initialized
INFO - 2020-09-13 12:10:10 --> Language Class Initialized
INFO - 2020-09-13 12:10:10 --> Config Class Initialized
INFO - 2020-09-13 12:10:10 --> Loader Class Initialized
INFO - 2020-09-13 12:10:10 --> Helper loaded: url_helper
INFO - 2020-09-13 12:10:10 --> Helper loaded: form_helper
INFO - 2020-09-13 12:10:10 --> Helper loaded: file_helper
INFO - 2020-09-13 12:10:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:10:10 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:10:10 --> Upload Class Initialized
INFO - 2020-09-13 12:10:10 --> Controller Class Initialized
DEBUG - 2020-09-13 12:10:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:10:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:10:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:10:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:10:10 --> Final output sent to browser
DEBUG - 2020-09-13 12:10:10 --> Total execution time: 0.0652
INFO - 2020-09-13 12:10:28 --> Config Class Initialized
INFO - 2020-09-13 12:10:28 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:10:28 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:10:28 --> Utf8 Class Initialized
INFO - 2020-09-13 12:10:28 --> URI Class Initialized
INFO - 2020-09-13 12:10:28 --> Router Class Initialized
INFO - 2020-09-13 12:10:28 --> Output Class Initialized
INFO - 2020-09-13 12:10:28 --> Security Class Initialized
DEBUG - 2020-09-13 12:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:10:28 --> Input Class Initialized
INFO - 2020-09-13 12:10:28 --> Language Class Initialized
INFO - 2020-09-13 12:10:28 --> Language Class Initialized
INFO - 2020-09-13 12:10:28 --> Config Class Initialized
INFO - 2020-09-13 12:10:28 --> Loader Class Initialized
INFO - 2020-09-13 12:10:28 --> Helper loaded: url_helper
INFO - 2020-09-13 12:10:28 --> Helper loaded: form_helper
INFO - 2020-09-13 12:10:28 --> Helper loaded: file_helper
INFO - 2020-09-13 12:10:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:10:28 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:10:28 --> Upload Class Initialized
INFO - 2020-09-13 12:10:28 --> Controller Class Initialized
ERROR - 2020-09-13 12:10:28 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:16:16 --> Config Class Initialized
INFO - 2020-09-13 12:16:16 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:16:16 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:16:16 --> Utf8 Class Initialized
INFO - 2020-09-13 12:16:16 --> URI Class Initialized
DEBUG - 2020-09-13 12:16:16 --> No URI present. Default controller set.
INFO - 2020-09-13 12:16:16 --> Router Class Initialized
INFO - 2020-09-13 12:16:16 --> Output Class Initialized
INFO - 2020-09-13 12:16:16 --> Security Class Initialized
DEBUG - 2020-09-13 12:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:16:16 --> Input Class Initialized
INFO - 2020-09-13 12:16:16 --> Language Class Initialized
INFO - 2020-09-13 12:16:16 --> Language Class Initialized
INFO - 2020-09-13 12:16:16 --> Config Class Initialized
INFO - 2020-09-13 12:16:16 --> Loader Class Initialized
INFO - 2020-09-13 12:16:16 --> Helper loaded: url_helper
INFO - 2020-09-13 12:16:16 --> Helper loaded: form_helper
INFO - 2020-09-13 12:16:16 --> Helper loaded: file_helper
INFO - 2020-09-13 12:16:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:16:16 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:16:16 --> Upload Class Initialized
INFO - 2020-09-13 12:16:16 --> Controller Class Initialized
DEBUG - 2020-09-13 12:16:16 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:16:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:16:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:16:16 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:16:16 --> Final output sent to browser
DEBUG - 2020-09-13 12:16:16 --> Total execution time: 0.0560
INFO - 2020-09-13 12:16:25 --> Config Class Initialized
INFO - 2020-09-13 12:16:25 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:16:25 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:16:25 --> Utf8 Class Initialized
INFO - 2020-09-13 12:16:25 --> URI Class Initialized
INFO - 2020-09-13 12:16:25 --> Router Class Initialized
INFO - 2020-09-13 12:16:25 --> Output Class Initialized
INFO - 2020-09-13 12:16:25 --> Security Class Initialized
DEBUG - 2020-09-13 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:16:25 --> Input Class Initialized
INFO - 2020-09-13 12:16:25 --> Language Class Initialized
INFO - 2020-09-13 12:16:25 --> Language Class Initialized
INFO - 2020-09-13 12:16:25 --> Config Class Initialized
INFO - 2020-09-13 12:16:25 --> Loader Class Initialized
INFO - 2020-09-13 12:16:25 --> Helper loaded: url_helper
INFO - 2020-09-13 12:16:25 --> Helper loaded: form_helper
INFO - 2020-09-13 12:16:25 --> Helper loaded: file_helper
INFO - 2020-09-13 12:16:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:16:25 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:16:25 --> Upload Class Initialized
INFO - 2020-09-13 12:16:25 --> Controller Class Initialized
ERROR - 2020-09-13 12:16:25 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:17:35 --> Config Class Initialized
INFO - 2020-09-13 12:17:35 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:17:35 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:17:35 --> Utf8 Class Initialized
INFO - 2020-09-13 12:17:35 --> URI Class Initialized
DEBUG - 2020-09-13 12:17:35 --> No URI present. Default controller set.
INFO - 2020-09-13 12:17:35 --> Router Class Initialized
INFO - 2020-09-13 12:17:35 --> Output Class Initialized
INFO - 2020-09-13 12:17:35 --> Security Class Initialized
DEBUG - 2020-09-13 12:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:17:35 --> Input Class Initialized
INFO - 2020-09-13 12:17:35 --> Language Class Initialized
INFO - 2020-09-13 12:17:35 --> Language Class Initialized
INFO - 2020-09-13 12:17:35 --> Config Class Initialized
INFO - 2020-09-13 12:17:35 --> Loader Class Initialized
INFO - 2020-09-13 12:17:35 --> Helper loaded: url_helper
INFO - 2020-09-13 12:17:35 --> Helper loaded: form_helper
INFO - 2020-09-13 12:17:35 --> Helper loaded: file_helper
INFO - 2020-09-13 12:17:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:17:35 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:17:35 --> Upload Class Initialized
INFO - 2020-09-13 12:17:35 --> Controller Class Initialized
DEBUG - 2020-09-13 12:17:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:17:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:17:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:17:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:17:35 --> Final output sent to browser
DEBUG - 2020-09-13 12:17:35 --> Total execution time: 0.0583
INFO - 2020-09-13 12:17:37 --> Config Class Initialized
INFO - 2020-09-13 12:17:37 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:17:37 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:17:37 --> Utf8 Class Initialized
INFO - 2020-09-13 12:17:37 --> URI Class Initialized
DEBUG - 2020-09-13 12:17:37 --> No URI present. Default controller set.
INFO - 2020-09-13 12:17:37 --> Router Class Initialized
INFO - 2020-09-13 12:17:37 --> Output Class Initialized
INFO - 2020-09-13 12:17:37 --> Security Class Initialized
DEBUG - 2020-09-13 12:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:17:37 --> Input Class Initialized
INFO - 2020-09-13 12:17:37 --> Language Class Initialized
INFO - 2020-09-13 12:17:37 --> Language Class Initialized
INFO - 2020-09-13 12:17:37 --> Config Class Initialized
INFO - 2020-09-13 12:17:37 --> Loader Class Initialized
INFO - 2020-09-13 12:17:37 --> Helper loaded: url_helper
INFO - 2020-09-13 12:17:37 --> Helper loaded: form_helper
INFO - 2020-09-13 12:17:37 --> Helper loaded: file_helper
INFO - 2020-09-13 12:17:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:17:37 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:17:37 --> Upload Class Initialized
INFO - 2020-09-13 12:17:37 --> Controller Class Initialized
DEBUG - 2020-09-13 12:17:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:17:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:17:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:17:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:17:37 --> Final output sent to browser
DEBUG - 2020-09-13 12:17:37 --> Total execution time: 0.0529
INFO - 2020-09-13 12:17:39 --> Config Class Initialized
INFO - 2020-09-13 12:17:39 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:17:39 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:17:39 --> Utf8 Class Initialized
INFO - 2020-09-13 12:17:39 --> URI Class Initialized
INFO - 2020-09-13 12:17:39 --> Router Class Initialized
INFO - 2020-09-13 12:17:39 --> Output Class Initialized
INFO - 2020-09-13 12:17:39 --> Security Class Initialized
DEBUG - 2020-09-13 12:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:17:39 --> Input Class Initialized
INFO - 2020-09-13 12:17:39 --> Language Class Initialized
INFO - 2020-09-13 12:17:39 --> Language Class Initialized
INFO - 2020-09-13 12:17:39 --> Config Class Initialized
INFO - 2020-09-13 12:17:39 --> Loader Class Initialized
INFO - 2020-09-13 12:17:39 --> Helper loaded: url_helper
INFO - 2020-09-13 12:17:39 --> Helper loaded: form_helper
INFO - 2020-09-13 12:17:39 --> Helper loaded: file_helper
INFO - 2020-09-13 12:17:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:17:39 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:17:39 --> Upload Class Initialized
INFO - 2020-09-13 12:17:39 --> Controller Class Initialized
ERROR - 2020-09-13 12:17:39 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:23:40 --> Config Class Initialized
INFO - 2020-09-13 12:23:40 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:23:40 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:23:40 --> Utf8 Class Initialized
INFO - 2020-09-13 12:23:40 --> URI Class Initialized
DEBUG - 2020-09-13 12:23:40 --> No URI present. Default controller set.
INFO - 2020-09-13 12:23:40 --> Router Class Initialized
INFO - 2020-09-13 12:23:40 --> Output Class Initialized
INFO - 2020-09-13 12:23:40 --> Security Class Initialized
DEBUG - 2020-09-13 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:23:40 --> Input Class Initialized
INFO - 2020-09-13 12:23:40 --> Language Class Initialized
INFO - 2020-09-13 12:23:40 --> Language Class Initialized
INFO - 2020-09-13 12:23:40 --> Config Class Initialized
INFO - 2020-09-13 12:23:40 --> Loader Class Initialized
INFO - 2020-09-13 12:23:40 --> Helper loaded: url_helper
INFO - 2020-09-13 12:23:40 --> Helper loaded: form_helper
INFO - 2020-09-13 12:23:40 --> Helper loaded: file_helper
INFO - 2020-09-13 12:23:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:23:40 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:23:40 --> Upload Class Initialized
INFO - 2020-09-13 12:23:40 --> Controller Class Initialized
DEBUG - 2020-09-13 12:23:40 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:23:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:23:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:23:40 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:23:40 --> Final output sent to browser
DEBUG - 2020-09-13 12:23:40 --> Total execution time: 0.0691
INFO - 2020-09-13 12:28:21 --> Config Class Initialized
INFO - 2020-09-13 12:28:21 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:28:21 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:28:21 --> Utf8 Class Initialized
INFO - 2020-09-13 12:28:21 --> URI Class Initialized
INFO - 2020-09-13 12:28:21 --> Router Class Initialized
INFO - 2020-09-13 12:28:21 --> Output Class Initialized
INFO - 2020-09-13 12:28:21 --> Security Class Initialized
DEBUG - 2020-09-13 12:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:28:21 --> Input Class Initialized
INFO - 2020-09-13 12:28:21 --> Language Class Initialized
INFO - 2020-09-13 12:28:21 --> Language Class Initialized
INFO - 2020-09-13 12:28:21 --> Config Class Initialized
INFO - 2020-09-13 12:28:21 --> Loader Class Initialized
INFO - 2020-09-13 12:28:21 --> Helper loaded: url_helper
INFO - 2020-09-13 12:28:21 --> Helper loaded: form_helper
INFO - 2020-09-13 12:28:21 --> Helper loaded: file_helper
INFO - 2020-09-13 12:28:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:28:21 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:28:21 --> Upload Class Initialized
INFO - 2020-09-13 12:28:21 --> Controller Class Initialized
ERROR - 2020-09-13 12:28:21 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:30:02 --> Config Class Initialized
INFO - 2020-09-13 12:30:02 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:30:02 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:30:02 --> Utf8 Class Initialized
INFO - 2020-09-13 12:30:02 --> URI Class Initialized
INFO - 2020-09-13 12:30:02 --> Router Class Initialized
INFO - 2020-09-13 12:30:02 --> Output Class Initialized
INFO - 2020-09-13 12:30:02 --> Security Class Initialized
DEBUG - 2020-09-13 12:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:30:02 --> Input Class Initialized
INFO - 2020-09-13 12:30:02 --> Language Class Initialized
INFO - 2020-09-13 12:30:02 --> Language Class Initialized
INFO - 2020-09-13 12:30:02 --> Config Class Initialized
INFO - 2020-09-13 12:30:02 --> Loader Class Initialized
INFO - 2020-09-13 12:30:02 --> Helper loaded: url_helper
INFO - 2020-09-13 12:30:02 --> Helper loaded: form_helper
INFO - 2020-09-13 12:30:02 --> Helper loaded: file_helper
INFO - 2020-09-13 12:30:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:30:02 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:30:02 --> Upload Class Initialized
INFO - 2020-09-13 12:30:02 --> Controller Class Initialized
ERROR - 2020-09-13 12:30:02 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:51:24 --> Config Class Initialized
INFO - 2020-09-13 12:51:24 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:51:24 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:51:24 --> Utf8 Class Initialized
INFO - 2020-09-13 12:51:24 --> URI Class Initialized
DEBUG - 2020-09-13 12:51:24 --> No URI present. Default controller set.
INFO - 2020-09-13 12:51:24 --> Router Class Initialized
INFO - 2020-09-13 12:51:24 --> Output Class Initialized
INFO - 2020-09-13 12:51:24 --> Security Class Initialized
DEBUG - 2020-09-13 12:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:51:24 --> Input Class Initialized
INFO - 2020-09-13 12:51:24 --> Language Class Initialized
INFO - 2020-09-13 12:51:24 --> Language Class Initialized
INFO - 2020-09-13 12:51:24 --> Config Class Initialized
INFO - 2020-09-13 12:51:24 --> Loader Class Initialized
INFO - 2020-09-13 12:51:24 --> Helper loaded: url_helper
INFO - 2020-09-13 12:51:24 --> Helper loaded: form_helper
INFO - 2020-09-13 12:51:24 --> Helper loaded: file_helper
INFO - 2020-09-13 12:51:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:51:24 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:51:24 --> Upload Class Initialized
INFO - 2020-09-13 12:51:24 --> Controller Class Initialized
DEBUG - 2020-09-13 12:51:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:51:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:51:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:51:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:51:24 --> Final output sent to browser
DEBUG - 2020-09-13 12:51:24 --> Total execution time: 0.0622
INFO - 2020-09-13 12:51:34 --> Config Class Initialized
INFO - 2020-09-13 12:51:34 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:51:34 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:51:34 --> Utf8 Class Initialized
INFO - 2020-09-13 12:51:34 --> URI Class Initialized
INFO - 2020-09-13 12:51:34 --> Router Class Initialized
INFO - 2020-09-13 12:51:34 --> Output Class Initialized
INFO - 2020-09-13 12:51:34 --> Security Class Initialized
DEBUG - 2020-09-13 12:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:51:34 --> Input Class Initialized
INFO - 2020-09-13 12:51:34 --> Language Class Initialized
INFO - 2020-09-13 12:51:34 --> Language Class Initialized
INFO - 2020-09-13 12:51:34 --> Config Class Initialized
INFO - 2020-09-13 12:51:34 --> Loader Class Initialized
INFO - 2020-09-13 12:51:34 --> Helper loaded: url_helper
INFO - 2020-09-13 12:51:34 --> Helper loaded: form_helper
INFO - 2020-09-13 12:51:34 --> Helper loaded: file_helper
INFO - 2020-09-13 12:51:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:51:34 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:51:34 --> Upload Class Initialized
INFO - 2020-09-13 12:51:34 --> Controller Class Initialized
ERROR - 2020-09-13 12:51:34 --> 404 Page Not Found: /index
INFO - 2020-09-13 12:52:47 --> Config Class Initialized
INFO - 2020-09-13 12:52:47 --> Hooks Class Initialized
DEBUG - 2020-09-13 12:52:47 --> UTF-8 Support Enabled
INFO - 2020-09-13 12:52:47 --> Utf8 Class Initialized
INFO - 2020-09-13 12:52:47 --> URI Class Initialized
DEBUG - 2020-09-13 12:52:47 --> No URI present. Default controller set.
INFO - 2020-09-13 12:52:47 --> Router Class Initialized
INFO - 2020-09-13 12:52:47 --> Output Class Initialized
INFO - 2020-09-13 12:52:47 --> Security Class Initialized
DEBUG - 2020-09-13 12:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 12:52:47 --> Input Class Initialized
INFO - 2020-09-13 12:52:47 --> Language Class Initialized
INFO - 2020-09-13 12:52:47 --> Language Class Initialized
INFO - 2020-09-13 12:52:47 --> Config Class Initialized
INFO - 2020-09-13 12:52:47 --> Loader Class Initialized
INFO - 2020-09-13 12:52:47 --> Helper loaded: url_helper
INFO - 2020-09-13 12:52:47 --> Helper loaded: form_helper
INFO - 2020-09-13 12:52:47 --> Helper loaded: file_helper
INFO - 2020-09-13 12:52:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 12:52:47 --> Database Driver Class Initialized
DEBUG - 2020-09-13 12:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 12:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 12:52:47 --> Upload Class Initialized
INFO - 2020-09-13 12:52:47 --> Controller Class Initialized
DEBUG - 2020-09-13 12:52:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 12:52:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 12:52:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 12:52:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 12:52:47 --> Final output sent to browser
DEBUG - 2020-09-13 12:52:47 --> Total execution time: 0.0428
INFO - 2020-09-13 13:06:34 --> Config Class Initialized
INFO - 2020-09-13 13:06:34 --> Hooks Class Initialized
DEBUG - 2020-09-13 13:06:34 --> UTF-8 Support Enabled
INFO - 2020-09-13 13:06:34 --> Utf8 Class Initialized
INFO - 2020-09-13 13:06:34 --> URI Class Initialized
DEBUG - 2020-09-13 13:06:34 --> No URI present. Default controller set.
INFO - 2020-09-13 13:06:34 --> Router Class Initialized
INFO - 2020-09-13 13:06:34 --> Output Class Initialized
INFO - 2020-09-13 13:06:34 --> Security Class Initialized
DEBUG - 2020-09-13 13:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 13:06:34 --> Input Class Initialized
INFO - 2020-09-13 13:06:34 --> Language Class Initialized
INFO - 2020-09-13 13:06:34 --> Language Class Initialized
INFO - 2020-09-13 13:06:34 --> Config Class Initialized
INFO - 2020-09-13 13:06:34 --> Loader Class Initialized
INFO - 2020-09-13 13:06:34 --> Helper loaded: url_helper
INFO - 2020-09-13 13:06:34 --> Helper loaded: form_helper
INFO - 2020-09-13 13:06:34 --> Helper loaded: file_helper
INFO - 2020-09-13 13:06:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 13:06:34 --> Database Driver Class Initialized
DEBUG - 2020-09-13 13:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 13:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 13:06:34 --> Upload Class Initialized
INFO - 2020-09-13 13:06:34 --> Controller Class Initialized
DEBUG - 2020-09-13 13:06:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 13:06:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 13:06:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 13:06:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 13:06:34 --> Final output sent to browser
DEBUG - 2020-09-13 13:06:34 --> Total execution time: 0.0427
INFO - 2020-09-13 13:06:46 --> Config Class Initialized
INFO - 2020-09-13 13:06:46 --> Hooks Class Initialized
DEBUG - 2020-09-13 13:06:46 --> UTF-8 Support Enabled
INFO - 2020-09-13 13:06:46 --> Utf8 Class Initialized
INFO - 2020-09-13 13:06:46 --> URI Class Initialized
INFO - 2020-09-13 13:06:46 --> Router Class Initialized
INFO - 2020-09-13 13:06:46 --> Output Class Initialized
INFO - 2020-09-13 13:06:46 --> Security Class Initialized
DEBUG - 2020-09-13 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 13:06:46 --> Input Class Initialized
INFO - 2020-09-13 13:06:46 --> Language Class Initialized
INFO - 2020-09-13 13:06:46 --> Language Class Initialized
INFO - 2020-09-13 13:06:46 --> Config Class Initialized
INFO - 2020-09-13 13:06:46 --> Loader Class Initialized
INFO - 2020-09-13 13:06:46 --> Helper loaded: url_helper
INFO - 2020-09-13 13:06:46 --> Helper loaded: form_helper
INFO - 2020-09-13 13:06:46 --> Helper loaded: file_helper
INFO - 2020-09-13 13:06:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 13:06:46 --> Database Driver Class Initialized
DEBUG - 2020-09-13 13:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 13:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 13:06:47 --> Upload Class Initialized
INFO - 2020-09-13 13:06:47 --> Controller Class Initialized
ERROR - 2020-09-13 13:06:47 --> 404 Page Not Found: /index
INFO - 2020-09-13 14:20:05 --> Config Class Initialized
INFO - 2020-09-13 14:20:05 --> Hooks Class Initialized
DEBUG - 2020-09-13 14:20:05 --> UTF-8 Support Enabled
INFO - 2020-09-13 14:20:05 --> Utf8 Class Initialized
INFO - 2020-09-13 14:20:05 --> URI Class Initialized
DEBUG - 2020-09-13 14:20:05 --> No URI present. Default controller set.
INFO - 2020-09-13 14:20:05 --> Router Class Initialized
INFO - 2020-09-13 14:20:05 --> Output Class Initialized
INFO - 2020-09-13 14:20:05 --> Security Class Initialized
DEBUG - 2020-09-13 14:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 14:20:05 --> Input Class Initialized
INFO - 2020-09-13 14:20:05 --> Language Class Initialized
INFO - 2020-09-13 14:20:05 --> Language Class Initialized
INFO - 2020-09-13 14:20:05 --> Config Class Initialized
INFO - 2020-09-13 14:20:05 --> Loader Class Initialized
INFO - 2020-09-13 14:20:05 --> Helper loaded: url_helper
INFO - 2020-09-13 14:20:05 --> Helper loaded: form_helper
INFO - 2020-09-13 14:20:05 --> Helper loaded: file_helper
INFO - 2020-09-13 14:20:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 14:20:05 --> Database Driver Class Initialized
DEBUG - 2020-09-13 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 14:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 14:20:05 --> Upload Class Initialized
INFO - 2020-09-13 14:20:05 --> Controller Class Initialized
DEBUG - 2020-09-13 14:20:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 14:20:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 14:20:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 14:20:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 14:20:05 --> Final output sent to browser
DEBUG - 2020-09-13 14:20:05 --> Total execution time: 0.0604
INFO - 2020-09-13 14:20:06 --> Config Class Initialized
INFO - 2020-09-13 14:20:06 --> Hooks Class Initialized
DEBUG - 2020-09-13 14:20:06 --> UTF-8 Support Enabled
INFO - 2020-09-13 14:20:06 --> Utf8 Class Initialized
INFO - 2020-09-13 14:20:06 --> URI Class Initialized
INFO - 2020-09-13 14:20:06 --> Router Class Initialized
INFO - 2020-09-13 14:20:06 --> Output Class Initialized
INFO - 2020-09-13 14:20:06 --> Security Class Initialized
DEBUG - 2020-09-13 14:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 14:20:06 --> Input Class Initialized
INFO - 2020-09-13 14:20:06 --> Language Class Initialized
INFO - 2020-09-13 14:20:06 --> Language Class Initialized
INFO - 2020-09-13 14:20:06 --> Config Class Initialized
INFO - 2020-09-13 14:20:06 --> Loader Class Initialized
INFO - 2020-09-13 14:20:06 --> Helper loaded: url_helper
INFO - 2020-09-13 14:20:06 --> Helper loaded: form_helper
INFO - 2020-09-13 14:20:06 --> Helper loaded: file_helper
INFO - 2020-09-13 14:20:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 14:20:06 --> Database Driver Class Initialized
DEBUG - 2020-09-13 14:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 14:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 14:20:06 --> Upload Class Initialized
INFO - 2020-09-13 14:20:06 --> Controller Class Initialized
ERROR - 2020-09-13 14:20:06 --> 404 Page Not Found: /index
INFO - 2020-09-13 14:23:42 --> Config Class Initialized
INFO - 2020-09-13 14:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-13 14:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-13 14:23:42 --> Utf8 Class Initialized
INFO - 2020-09-13 14:23:42 --> URI Class Initialized
DEBUG - 2020-09-13 14:23:42 --> No URI present. Default controller set.
INFO - 2020-09-13 14:23:42 --> Router Class Initialized
INFO - 2020-09-13 14:23:42 --> Output Class Initialized
INFO - 2020-09-13 14:23:42 --> Security Class Initialized
DEBUG - 2020-09-13 14:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 14:23:42 --> Input Class Initialized
INFO - 2020-09-13 14:23:42 --> Language Class Initialized
INFO - 2020-09-13 14:23:42 --> Language Class Initialized
INFO - 2020-09-13 14:23:42 --> Config Class Initialized
INFO - 2020-09-13 14:23:42 --> Loader Class Initialized
INFO - 2020-09-13 14:23:42 --> Helper loaded: url_helper
INFO - 2020-09-13 14:23:42 --> Helper loaded: form_helper
INFO - 2020-09-13 14:23:42 --> Helper loaded: file_helper
INFO - 2020-09-13 14:23:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 14:23:42 --> Database Driver Class Initialized
DEBUG - 2020-09-13 14:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 14:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 14:23:42 --> Upload Class Initialized
INFO - 2020-09-13 14:23:42 --> Controller Class Initialized
DEBUG - 2020-09-13 14:23:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 14:23:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 14:23:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 14:23:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 14:23:42 --> Final output sent to browser
DEBUG - 2020-09-13 14:23:42 --> Total execution time: 0.0613
INFO - 2020-09-13 14:23:54 --> Config Class Initialized
INFO - 2020-09-13 14:23:54 --> Hooks Class Initialized
DEBUG - 2020-09-13 14:23:54 --> UTF-8 Support Enabled
INFO - 2020-09-13 14:23:54 --> Utf8 Class Initialized
INFO - 2020-09-13 14:23:54 --> URI Class Initialized
INFO - 2020-09-13 14:23:54 --> Router Class Initialized
INFO - 2020-09-13 14:23:54 --> Output Class Initialized
INFO - 2020-09-13 14:23:54 --> Security Class Initialized
DEBUG - 2020-09-13 14:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 14:23:54 --> Input Class Initialized
INFO - 2020-09-13 14:23:54 --> Language Class Initialized
INFO - 2020-09-13 14:23:54 --> Language Class Initialized
INFO - 2020-09-13 14:23:54 --> Config Class Initialized
INFO - 2020-09-13 14:23:54 --> Loader Class Initialized
INFO - 2020-09-13 14:23:54 --> Helper loaded: url_helper
INFO - 2020-09-13 14:23:54 --> Helper loaded: form_helper
INFO - 2020-09-13 14:23:54 --> Helper loaded: file_helper
INFO - 2020-09-13 14:23:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 14:23:54 --> Database Driver Class Initialized
DEBUG - 2020-09-13 14:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 14:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 14:23:54 --> Upload Class Initialized
INFO - 2020-09-13 14:23:54 --> Controller Class Initialized
ERROR - 2020-09-13 14:23:54 --> 404 Page Not Found: /index
INFO - 2020-09-13 14:23:55 --> Config Class Initialized
INFO - 2020-09-13 14:23:55 --> Hooks Class Initialized
DEBUG - 2020-09-13 14:23:55 --> UTF-8 Support Enabled
INFO - 2020-09-13 14:23:55 --> Utf8 Class Initialized
INFO - 2020-09-13 14:23:55 --> URI Class Initialized
DEBUG - 2020-09-13 14:23:55 --> No URI present. Default controller set.
INFO - 2020-09-13 14:23:55 --> Router Class Initialized
INFO - 2020-09-13 14:23:55 --> Output Class Initialized
INFO - 2020-09-13 14:23:55 --> Security Class Initialized
DEBUG - 2020-09-13 14:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-13 14:23:55 --> Input Class Initialized
INFO - 2020-09-13 14:23:55 --> Language Class Initialized
INFO - 2020-09-13 14:23:55 --> Language Class Initialized
INFO - 2020-09-13 14:23:55 --> Config Class Initialized
INFO - 2020-09-13 14:23:55 --> Loader Class Initialized
INFO - 2020-09-13 14:23:55 --> Helper loaded: url_helper
INFO - 2020-09-13 14:23:55 --> Helper loaded: form_helper
INFO - 2020-09-13 14:23:55 --> Helper loaded: file_helper
INFO - 2020-09-13 14:23:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-13 14:23:55 --> Database Driver Class Initialized
DEBUG - 2020-09-13 14:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-13 14:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-13 14:23:55 --> Upload Class Initialized
INFO - 2020-09-13 14:23:55 --> Controller Class Initialized
DEBUG - 2020-09-13 14:23:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-13 14:23:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-13 14:23:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-13 14:23:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-13 14:23:55 --> Final output sent to browser
DEBUG - 2020-09-13 14:23:55 --> Total execution time: 0.0488
