<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-20 14:20:19 --> Config Class Initialized
INFO - 2020-09-20 14:20:19 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:20:19 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:20:19 --> Utf8 Class Initialized
INFO - 2020-09-20 14:20:19 --> URI Class Initialized
DEBUG - 2020-09-20 14:20:19 --> No URI present. Default controller set.
INFO - 2020-09-20 14:20:19 --> Router Class Initialized
INFO - 2020-09-20 14:20:19 --> Output Class Initialized
INFO - 2020-09-20 14:20:19 --> Security Class Initialized
DEBUG - 2020-09-20 14:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:20:19 --> Input Class Initialized
INFO - 2020-09-20 14:20:19 --> Language Class Initialized
INFO - 2020-09-20 14:20:19 --> Language Class Initialized
INFO - 2020-09-20 14:20:19 --> Config Class Initialized
INFO - 2020-09-20 14:20:19 --> Loader Class Initialized
INFO - 2020-09-20 14:20:19 --> Helper loaded: url_helper
INFO - 2020-09-20 14:20:19 --> Helper loaded: form_helper
INFO - 2020-09-20 14:20:19 --> Helper loaded: file_helper
INFO - 2020-09-20 14:20:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 14:20:19 --> Database Driver Class Initialized
DEBUG - 2020-09-20 14:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 14:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:20:19 --> Upload Class Initialized
INFO - 2020-09-20 14:20:19 --> Controller Class Initialized
DEBUG - 2020-09-20 14:20:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 14:20:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 14:20:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 14:20:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 14:20:19 --> Final output sent to browser
DEBUG - 2020-09-20 14:20:19 --> Total execution time: 0.0599
INFO - 2020-09-20 14:21:04 --> Config Class Initialized
INFO - 2020-09-20 14:21:04 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:21:04 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:21:04 --> Utf8 Class Initialized
INFO - 2020-09-20 14:21:04 --> URI Class Initialized
INFO - 2020-09-20 14:21:04 --> Router Class Initialized
INFO - 2020-09-20 14:21:04 --> Output Class Initialized
INFO - 2020-09-20 14:21:04 --> Security Class Initialized
DEBUG - 2020-09-20 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:21:04 --> Input Class Initialized
INFO - 2020-09-20 14:21:04 --> Language Class Initialized
INFO - 2020-09-20 14:21:04 --> Language Class Initialized
INFO - 2020-09-20 14:21:04 --> Config Class Initialized
INFO - 2020-09-20 14:21:04 --> Loader Class Initialized
INFO - 2020-09-20 14:21:04 --> Helper loaded: url_helper
INFO - 2020-09-20 14:21:04 --> Helper loaded: form_helper
INFO - 2020-09-20 14:21:04 --> Helper loaded: file_helper
INFO - 2020-09-20 14:21:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 14:21:04 --> Database Driver Class Initialized
DEBUG - 2020-09-20 14:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 14:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:21:04 --> Upload Class Initialized
INFO - 2020-09-20 14:21:04 --> Controller Class Initialized
ERROR - 2020-09-20 14:21:04 --> 404 Page Not Found: /index
INFO - 2020-09-20 14:40:53 --> Config Class Initialized
INFO - 2020-09-20 14:40:53 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:40:53 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:40:53 --> Utf8 Class Initialized
INFO - 2020-09-20 14:40:53 --> URI Class Initialized
DEBUG - 2020-09-20 14:40:53 --> No URI present. Default controller set.
INFO - 2020-09-20 14:40:53 --> Router Class Initialized
INFO - 2020-09-20 14:40:53 --> Output Class Initialized
INFO - 2020-09-20 14:40:53 --> Security Class Initialized
DEBUG - 2020-09-20 14:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:40:53 --> Input Class Initialized
INFO - 2020-09-20 14:40:53 --> Language Class Initialized
INFO - 2020-09-20 14:40:53 --> Language Class Initialized
INFO - 2020-09-20 14:40:53 --> Config Class Initialized
INFO - 2020-09-20 14:40:53 --> Loader Class Initialized
INFO - 2020-09-20 14:40:53 --> Helper loaded: url_helper
INFO - 2020-09-20 14:40:53 --> Helper loaded: form_helper
INFO - 2020-09-20 14:40:53 --> Helper loaded: file_helper
INFO - 2020-09-20 14:40:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 14:40:53 --> Database Driver Class Initialized
DEBUG - 2020-09-20 14:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 14:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:40:53 --> Upload Class Initialized
INFO - 2020-09-20 14:40:53 --> Controller Class Initialized
DEBUG - 2020-09-20 14:40:53 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 14:40:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 14:40:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 14:40:53 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 14:40:53 --> Final output sent to browser
DEBUG - 2020-09-20 14:40:53 --> Total execution time: 0.0399
INFO - 2020-09-20 14:40:54 --> Config Class Initialized
INFO - 2020-09-20 14:40:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:40:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:40:54 --> Utf8 Class Initialized
INFO - 2020-09-20 14:40:54 --> URI Class Initialized
DEBUG - 2020-09-20 14:40:54 --> No URI present. Default controller set.
INFO - 2020-09-20 14:40:54 --> Router Class Initialized
INFO - 2020-09-20 14:40:54 --> Output Class Initialized
INFO - 2020-09-20 14:40:54 --> Security Class Initialized
DEBUG - 2020-09-20 14:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:40:54 --> Input Class Initialized
INFO - 2020-09-20 14:40:54 --> Language Class Initialized
INFO - 2020-09-20 14:40:54 --> Language Class Initialized
INFO - 2020-09-20 14:40:54 --> Config Class Initialized
INFO - 2020-09-20 14:40:54 --> Loader Class Initialized
INFO - 2020-09-20 14:40:54 --> Helper loaded: url_helper
INFO - 2020-09-20 14:40:54 --> Helper loaded: form_helper
INFO - 2020-09-20 14:40:54 --> Helper loaded: file_helper
INFO - 2020-09-20 14:40:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 14:40:54 --> Database Driver Class Initialized
DEBUG - 2020-09-20 14:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 14:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:40:54 --> Upload Class Initialized
INFO - 2020-09-20 14:40:54 --> Controller Class Initialized
DEBUG - 2020-09-20 14:40:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 14:40:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 14:40:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 14:40:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 14:40:54 --> Final output sent to browser
DEBUG - 2020-09-20 14:40:54 --> Total execution time: 0.0487
INFO - 2020-09-20 14:41:54 --> Config Class Initialized
INFO - 2020-09-20 14:41:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:41:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:41:54 --> Utf8 Class Initialized
INFO - 2020-09-20 14:41:54 --> URI Class Initialized
INFO - 2020-09-20 14:41:54 --> Router Class Initialized
INFO - 2020-09-20 14:41:54 --> Output Class Initialized
INFO - 2020-09-20 14:41:54 --> Security Class Initialized
DEBUG - 2020-09-20 14:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:41:54 --> Input Class Initialized
INFO - 2020-09-20 14:41:54 --> Language Class Initialized
INFO - 2020-09-20 14:41:54 --> Language Class Initialized
INFO - 2020-09-20 14:41:54 --> Config Class Initialized
INFO - 2020-09-20 14:41:54 --> Loader Class Initialized
INFO - 2020-09-20 14:41:54 --> Helper loaded: url_helper
INFO - 2020-09-20 14:41:54 --> Helper loaded: form_helper
INFO - 2020-09-20 14:41:54 --> Helper loaded: file_helper
INFO - 2020-09-20 14:41:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 14:41:54 --> Database Driver Class Initialized
DEBUG - 2020-09-20 14:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 14:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:41:54 --> Upload Class Initialized
INFO - 2020-09-20 14:41:54 --> Controller Class Initialized
ERROR - 2020-09-20 14:41:54 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:03:03 --> Config Class Initialized
INFO - 2020-09-20 15:03:03 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:03:03 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:03:03 --> Utf8 Class Initialized
INFO - 2020-09-20 15:03:03 --> URI Class Initialized
INFO - 2020-09-20 15:03:03 --> Router Class Initialized
INFO - 2020-09-20 15:03:03 --> Output Class Initialized
INFO - 2020-09-20 15:03:03 --> Security Class Initialized
DEBUG - 2020-09-20 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:03:03 --> Input Class Initialized
INFO - 2020-09-20 15:03:03 --> Language Class Initialized
INFO - 2020-09-20 15:03:03 --> Language Class Initialized
INFO - 2020-09-20 15:03:03 --> Config Class Initialized
INFO - 2020-09-20 15:03:03 --> Loader Class Initialized
INFO - 2020-09-20 15:03:03 --> Helper loaded: url_helper
INFO - 2020-09-20 15:03:03 --> Helper loaded: form_helper
INFO - 2020-09-20 15:03:03 --> Helper loaded: file_helper
INFO - 2020-09-20 15:03:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:03:03 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:03:03 --> Upload Class Initialized
INFO - 2020-09-20 15:03:03 --> Controller Class Initialized
ERROR - 2020-09-20 15:03:03 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:11:23 --> Config Class Initialized
INFO - 2020-09-20 15:11:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:11:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:11:23 --> Utf8 Class Initialized
INFO - 2020-09-20 15:11:23 --> URI Class Initialized
DEBUG - 2020-09-20 15:11:23 --> No URI present. Default controller set.
INFO - 2020-09-20 15:11:23 --> Router Class Initialized
INFO - 2020-09-20 15:11:23 --> Output Class Initialized
INFO - 2020-09-20 15:11:23 --> Security Class Initialized
DEBUG - 2020-09-20 15:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:11:23 --> Input Class Initialized
INFO - 2020-09-20 15:11:23 --> Language Class Initialized
INFO - 2020-09-20 15:11:23 --> Language Class Initialized
INFO - 2020-09-20 15:11:23 --> Config Class Initialized
INFO - 2020-09-20 15:11:23 --> Loader Class Initialized
INFO - 2020-09-20 15:11:23 --> Helper loaded: url_helper
INFO - 2020-09-20 15:11:23 --> Helper loaded: form_helper
INFO - 2020-09-20 15:11:23 --> Helper loaded: file_helper
INFO - 2020-09-20 15:11:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:11:23 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:11:23 --> Upload Class Initialized
INFO - 2020-09-20 15:11:23 --> Controller Class Initialized
DEBUG - 2020-09-20 15:11:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:11:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:11:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:11:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:11:23 --> Final output sent to browser
DEBUG - 2020-09-20 15:11:23 --> Total execution time: 0.0591
INFO - 2020-09-20 15:11:27 --> Config Class Initialized
INFO - 2020-09-20 15:11:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:11:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:11:27 --> Utf8 Class Initialized
INFO - 2020-09-20 15:11:27 --> URI Class Initialized
INFO - 2020-09-20 15:11:27 --> Router Class Initialized
INFO - 2020-09-20 15:11:27 --> Output Class Initialized
INFO - 2020-09-20 15:11:27 --> Security Class Initialized
DEBUG - 2020-09-20 15:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:11:27 --> Input Class Initialized
INFO - 2020-09-20 15:11:27 --> Language Class Initialized
INFO - 2020-09-20 15:11:27 --> Language Class Initialized
INFO - 2020-09-20 15:11:27 --> Config Class Initialized
INFO - 2020-09-20 15:11:27 --> Loader Class Initialized
INFO - 2020-09-20 15:11:27 --> Helper loaded: url_helper
INFO - 2020-09-20 15:11:27 --> Helper loaded: form_helper
INFO - 2020-09-20 15:11:27 --> Helper loaded: file_helper
INFO - 2020-09-20 15:11:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:11:27 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:11:27 --> Upload Class Initialized
INFO - 2020-09-20 15:11:27 --> Controller Class Initialized
ERROR - 2020-09-20 15:11:27 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:12:01 --> Config Class Initialized
INFO - 2020-09-20 15:12:01 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:12:01 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:12:01 --> Utf8 Class Initialized
INFO - 2020-09-20 15:12:01 --> URI Class Initialized
DEBUG - 2020-09-20 15:12:01 --> No URI present. Default controller set.
INFO - 2020-09-20 15:12:01 --> Router Class Initialized
INFO - 2020-09-20 15:12:01 --> Output Class Initialized
INFO - 2020-09-20 15:12:01 --> Security Class Initialized
DEBUG - 2020-09-20 15:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:12:01 --> Input Class Initialized
INFO - 2020-09-20 15:12:01 --> Language Class Initialized
INFO - 2020-09-20 15:12:01 --> Language Class Initialized
INFO - 2020-09-20 15:12:01 --> Config Class Initialized
INFO - 2020-09-20 15:12:01 --> Loader Class Initialized
INFO - 2020-09-20 15:12:01 --> Helper loaded: url_helper
INFO - 2020-09-20 15:12:01 --> Helper loaded: form_helper
INFO - 2020-09-20 15:12:01 --> Helper loaded: file_helper
INFO - 2020-09-20 15:12:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:12:01 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:12:01 --> Upload Class Initialized
INFO - 2020-09-20 15:12:01 --> Controller Class Initialized
DEBUG - 2020-09-20 15:12:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:12:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:12:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:12:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:12:01 --> Final output sent to browser
DEBUG - 2020-09-20 15:12:01 --> Total execution time: 0.0517
INFO - 2020-09-20 15:12:18 --> Config Class Initialized
INFO - 2020-09-20 15:12:18 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:12:18 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:12:18 --> Utf8 Class Initialized
INFO - 2020-09-20 15:12:18 --> URI Class Initialized
INFO - 2020-09-20 15:12:18 --> Router Class Initialized
INFO - 2020-09-20 15:12:18 --> Output Class Initialized
INFO - 2020-09-20 15:12:18 --> Security Class Initialized
DEBUG - 2020-09-20 15:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:12:18 --> Input Class Initialized
INFO - 2020-09-20 15:12:18 --> Language Class Initialized
INFO - 2020-09-20 15:12:18 --> Language Class Initialized
INFO - 2020-09-20 15:12:18 --> Config Class Initialized
INFO - 2020-09-20 15:12:18 --> Loader Class Initialized
INFO - 2020-09-20 15:12:18 --> Helper loaded: url_helper
INFO - 2020-09-20 15:12:18 --> Helper loaded: form_helper
INFO - 2020-09-20 15:12:18 --> Helper loaded: file_helper
INFO - 2020-09-20 15:12:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:12:18 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:12:18 --> Upload Class Initialized
INFO - 2020-09-20 15:12:18 --> Controller Class Initialized
ERROR - 2020-09-20 15:12:18 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:26:23 --> Config Class Initialized
INFO - 2020-09-20 15:26:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:26:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:26:23 --> Utf8 Class Initialized
INFO - 2020-09-20 15:26:23 --> URI Class Initialized
INFO - 2020-09-20 15:26:23 --> Router Class Initialized
INFO - 2020-09-20 15:26:23 --> Output Class Initialized
INFO - 2020-09-20 15:26:23 --> Security Class Initialized
DEBUG - 2020-09-20 15:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:26:23 --> Input Class Initialized
INFO - 2020-09-20 15:26:23 --> Language Class Initialized
INFO - 2020-09-20 15:26:23 --> Language Class Initialized
INFO - 2020-09-20 15:26:23 --> Config Class Initialized
INFO - 2020-09-20 15:26:23 --> Loader Class Initialized
INFO - 2020-09-20 15:26:23 --> Helper loaded: url_helper
INFO - 2020-09-20 15:26:23 --> Helper loaded: form_helper
INFO - 2020-09-20 15:26:23 --> Helper loaded: file_helper
INFO - 2020-09-20 15:26:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:26:23 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:26:23 --> Upload Class Initialized
INFO - 2020-09-20 15:26:23 --> Controller Class Initialized
ERROR - 2020-09-20 15:26:23 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:26:23 --> Config Class Initialized
INFO - 2020-09-20 15:26:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:26:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:26:23 --> Utf8 Class Initialized
INFO - 2020-09-20 15:26:23 --> URI Class Initialized
DEBUG - 2020-09-20 15:26:23 --> No URI present. Default controller set.
INFO - 2020-09-20 15:26:23 --> Router Class Initialized
INFO - 2020-09-20 15:26:23 --> Output Class Initialized
INFO - 2020-09-20 15:26:23 --> Security Class Initialized
DEBUG - 2020-09-20 15:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:26:23 --> Input Class Initialized
INFO - 2020-09-20 15:26:23 --> Language Class Initialized
INFO - 2020-09-20 15:26:23 --> Language Class Initialized
INFO - 2020-09-20 15:26:23 --> Config Class Initialized
INFO - 2020-09-20 15:26:23 --> Loader Class Initialized
INFO - 2020-09-20 15:26:23 --> Helper loaded: url_helper
INFO - 2020-09-20 15:26:23 --> Helper loaded: form_helper
INFO - 2020-09-20 15:26:23 --> Helper loaded: file_helper
INFO - 2020-09-20 15:26:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:26:23 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:26:23 --> Upload Class Initialized
INFO - 2020-09-20 15:26:23 --> Controller Class Initialized
DEBUG - 2020-09-20 15:26:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:26:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:26:23 --> Final output sent to browser
DEBUG - 2020-09-20 15:26:23 --> Total execution time: 0.0571
INFO - 2020-09-20 15:48:49 --> Config Class Initialized
INFO - 2020-09-20 15:48:49 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:48:49 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:48:49 --> Utf8 Class Initialized
INFO - 2020-09-20 15:48:49 --> URI Class Initialized
DEBUG - 2020-09-20 15:48:49 --> No URI present. Default controller set.
INFO - 2020-09-20 15:48:49 --> Router Class Initialized
INFO - 2020-09-20 15:48:49 --> Output Class Initialized
INFO - 2020-09-20 15:48:49 --> Security Class Initialized
DEBUG - 2020-09-20 15:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:48:49 --> Input Class Initialized
INFO - 2020-09-20 15:48:49 --> Language Class Initialized
INFO - 2020-09-20 15:48:49 --> Language Class Initialized
INFO - 2020-09-20 15:48:49 --> Config Class Initialized
INFO - 2020-09-20 15:48:49 --> Loader Class Initialized
INFO - 2020-09-20 15:48:49 --> Helper loaded: url_helper
INFO - 2020-09-20 15:48:49 --> Helper loaded: form_helper
INFO - 2020-09-20 15:48:49 --> Helper loaded: file_helper
INFO - 2020-09-20 15:48:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:48:49 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:48:49 --> Upload Class Initialized
INFO - 2020-09-20 15:48:49 --> Controller Class Initialized
DEBUG - 2020-09-20 15:48:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:48:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:48:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:48:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:48:49 --> Final output sent to browser
DEBUG - 2020-09-20 15:48:49 --> Total execution time: 0.0408
INFO - 2020-09-20 15:48:50 --> Config Class Initialized
INFO - 2020-09-20 15:48:50 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:48:50 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:48:50 --> Utf8 Class Initialized
INFO - 2020-09-20 15:48:50 --> URI Class Initialized
DEBUG - 2020-09-20 15:48:50 --> No URI present. Default controller set.
INFO - 2020-09-20 15:48:50 --> Router Class Initialized
INFO - 2020-09-20 15:48:50 --> Output Class Initialized
INFO - 2020-09-20 15:48:50 --> Security Class Initialized
DEBUG - 2020-09-20 15:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:48:50 --> Input Class Initialized
INFO - 2020-09-20 15:48:50 --> Language Class Initialized
INFO - 2020-09-20 15:48:50 --> Language Class Initialized
INFO - 2020-09-20 15:48:50 --> Config Class Initialized
INFO - 2020-09-20 15:48:50 --> Loader Class Initialized
INFO - 2020-09-20 15:48:50 --> Helper loaded: url_helper
INFO - 2020-09-20 15:48:50 --> Helper loaded: form_helper
INFO - 2020-09-20 15:48:50 --> Helper loaded: file_helper
INFO - 2020-09-20 15:48:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:48:50 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:48:50 --> Upload Class Initialized
INFO - 2020-09-20 15:48:50 --> Controller Class Initialized
DEBUG - 2020-09-20 15:48:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:48:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:48:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:48:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:48:50 --> Final output sent to browser
DEBUG - 2020-09-20 15:48:50 --> Total execution time: 0.0387
INFO - 2020-09-20 15:48:56 --> Config Class Initialized
INFO - 2020-09-20 15:48:56 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:48:56 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:48:56 --> Utf8 Class Initialized
INFO - 2020-09-20 15:48:56 --> URI Class Initialized
INFO - 2020-09-20 15:48:56 --> Router Class Initialized
INFO - 2020-09-20 15:48:56 --> Output Class Initialized
INFO - 2020-09-20 15:48:56 --> Security Class Initialized
DEBUG - 2020-09-20 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:48:56 --> Input Class Initialized
INFO - 2020-09-20 15:48:56 --> Language Class Initialized
INFO - 2020-09-20 15:48:56 --> Language Class Initialized
INFO - 2020-09-20 15:48:56 --> Config Class Initialized
INFO - 2020-09-20 15:48:56 --> Loader Class Initialized
INFO - 2020-09-20 15:48:56 --> Helper loaded: url_helper
INFO - 2020-09-20 15:48:56 --> Helper loaded: form_helper
INFO - 2020-09-20 15:48:56 --> Helper loaded: file_helper
INFO - 2020-09-20 15:48:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:48:56 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:48:56 --> Upload Class Initialized
INFO - 2020-09-20 15:48:56 --> Controller Class Initialized
ERROR - 2020-09-20 15:48:56 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:48:57 --> Config Class Initialized
INFO - 2020-09-20 15:48:57 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:48:57 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:48:57 --> Utf8 Class Initialized
INFO - 2020-09-20 15:48:57 --> URI Class Initialized
INFO - 2020-09-20 15:48:57 --> Router Class Initialized
INFO - 2020-09-20 15:48:57 --> Output Class Initialized
INFO - 2020-09-20 15:48:57 --> Security Class Initialized
DEBUG - 2020-09-20 15:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:48:57 --> Input Class Initialized
INFO - 2020-09-20 15:48:57 --> Language Class Initialized
INFO - 2020-09-20 15:48:57 --> Language Class Initialized
INFO - 2020-09-20 15:48:57 --> Config Class Initialized
INFO - 2020-09-20 15:48:57 --> Loader Class Initialized
INFO - 2020-09-20 15:48:57 --> Helper loaded: url_helper
INFO - 2020-09-20 15:48:57 --> Helper loaded: form_helper
INFO - 2020-09-20 15:48:57 --> Helper loaded: file_helper
INFO - 2020-09-20 15:48:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:48:57 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:48:57 --> Upload Class Initialized
INFO - 2020-09-20 15:48:57 --> Controller Class Initialized
ERROR - 2020-09-20 15:48:57 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:48:59 --> Config Class Initialized
INFO - 2020-09-20 15:48:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:48:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:48:59 --> Utf8 Class Initialized
INFO - 2020-09-20 15:48:59 --> URI Class Initialized
DEBUG - 2020-09-20 15:48:59 --> No URI present. Default controller set.
INFO - 2020-09-20 15:48:59 --> Router Class Initialized
INFO - 2020-09-20 15:48:59 --> Output Class Initialized
INFO - 2020-09-20 15:48:59 --> Security Class Initialized
DEBUG - 2020-09-20 15:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:48:59 --> Input Class Initialized
INFO - 2020-09-20 15:48:59 --> Language Class Initialized
INFO - 2020-09-20 15:48:59 --> Language Class Initialized
INFO - 2020-09-20 15:48:59 --> Config Class Initialized
INFO - 2020-09-20 15:48:59 --> Loader Class Initialized
INFO - 2020-09-20 15:48:59 --> Helper loaded: url_helper
INFO - 2020-09-20 15:48:59 --> Helper loaded: form_helper
INFO - 2020-09-20 15:48:59 --> Helper loaded: file_helper
INFO - 2020-09-20 15:48:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:48:59 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:48:59 --> Upload Class Initialized
INFO - 2020-09-20 15:48:59 --> Controller Class Initialized
DEBUG - 2020-09-20 15:48:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:48:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:48:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:48:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:48:59 --> Final output sent to browser
DEBUG - 2020-09-20 15:48:59 --> Total execution time: 0.0431
INFO - 2020-09-20 15:49:03 --> Config Class Initialized
INFO - 2020-09-20 15:49:03 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:49:03 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:49:03 --> Utf8 Class Initialized
INFO - 2020-09-20 15:49:03 --> URI Class Initialized
INFO - 2020-09-20 15:49:03 --> Router Class Initialized
INFO - 2020-09-20 15:49:03 --> Output Class Initialized
INFO - 2020-09-20 15:49:03 --> Security Class Initialized
DEBUG - 2020-09-20 15:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:49:03 --> Input Class Initialized
INFO - 2020-09-20 15:49:03 --> Language Class Initialized
INFO - 2020-09-20 15:49:03 --> Language Class Initialized
INFO - 2020-09-20 15:49:03 --> Config Class Initialized
INFO - 2020-09-20 15:49:03 --> Loader Class Initialized
INFO - 2020-09-20 15:49:03 --> Helper loaded: url_helper
INFO - 2020-09-20 15:49:03 --> Helper loaded: form_helper
INFO - 2020-09-20 15:49:03 --> Helper loaded: file_helper
INFO - 2020-09-20 15:49:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:49:03 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:49:03 --> Upload Class Initialized
INFO - 2020-09-20 15:49:03 --> Controller Class Initialized
ERROR - 2020-09-20 15:49:03 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:49:05 --> Config Class Initialized
INFO - 2020-09-20 15:49:05 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:49:05 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:49:05 --> Utf8 Class Initialized
INFO - 2020-09-20 15:49:05 --> URI Class Initialized
DEBUG - 2020-09-20 15:49:05 --> No URI present. Default controller set.
INFO - 2020-09-20 15:49:05 --> Router Class Initialized
INFO - 2020-09-20 15:49:05 --> Output Class Initialized
INFO - 2020-09-20 15:49:05 --> Security Class Initialized
DEBUG - 2020-09-20 15:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:49:05 --> Input Class Initialized
INFO - 2020-09-20 15:49:05 --> Language Class Initialized
INFO - 2020-09-20 15:49:05 --> Language Class Initialized
INFO - 2020-09-20 15:49:05 --> Config Class Initialized
INFO - 2020-09-20 15:49:05 --> Loader Class Initialized
INFO - 2020-09-20 15:49:05 --> Helper loaded: url_helper
INFO - 2020-09-20 15:49:05 --> Helper loaded: form_helper
INFO - 2020-09-20 15:49:05 --> Helper loaded: file_helper
INFO - 2020-09-20 15:49:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:49:05 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:49:05 --> Upload Class Initialized
INFO - 2020-09-20 15:49:05 --> Controller Class Initialized
DEBUG - 2020-09-20 15:49:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:49:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:49:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:49:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:49:05 --> Final output sent to browser
DEBUG - 2020-09-20 15:49:05 --> Total execution time: 0.0547
INFO - 2020-09-20 15:49:07 --> Config Class Initialized
INFO - 2020-09-20 15:49:07 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:49:07 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:49:07 --> Utf8 Class Initialized
INFO - 2020-09-20 15:49:07 --> URI Class Initialized
INFO - 2020-09-20 15:49:07 --> Router Class Initialized
INFO - 2020-09-20 15:49:07 --> Output Class Initialized
INFO - 2020-09-20 15:49:07 --> Security Class Initialized
DEBUG - 2020-09-20 15:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:49:07 --> Input Class Initialized
INFO - 2020-09-20 15:49:07 --> Language Class Initialized
INFO - 2020-09-20 15:49:07 --> Language Class Initialized
INFO - 2020-09-20 15:49:07 --> Config Class Initialized
INFO - 2020-09-20 15:49:07 --> Loader Class Initialized
INFO - 2020-09-20 15:49:07 --> Helper loaded: url_helper
INFO - 2020-09-20 15:49:07 --> Helper loaded: form_helper
INFO - 2020-09-20 15:49:07 --> Helper loaded: file_helper
INFO - 2020-09-20 15:49:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:49:07 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:49:07 --> Upload Class Initialized
INFO - 2020-09-20 15:49:07 --> Controller Class Initialized
ERROR - 2020-09-20 15:49:07 --> 404 Page Not Found: /index
INFO - 2020-09-20 15:49:09 --> Config Class Initialized
INFO - 2020-09-20 15:49:09 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:49:09 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:49:09 --> Utf8 Class Initialized
INFO - 2020-09-20 15:49:09 --> URI Class Initialized
DEBUG - 2020-09-20 15:49:09 --> No URI present. Default controller set.
INFO - 2020-09-20 15:49:09 --> Router Class Initialized
INFO - 2020-09-20 15:49:09 --> Output Class Initialized
INFO - 2020-09-20 15:49:09 --> Security Class Initialized
DEBUG - 2020-09-20 15:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:49:09 --> Input Class Initialized
INFO - 2020-09-20 15:49:09 --> Language Class Initialized
INFO - 2020-09-20 15:49:09 --> Language Class Initialized
INFO - 2020-09-20 15:49:09 --> Config Class Initialized
INFO - 2020-09-20 15:49:09 --> Loader Class Initialized
INFO - 2020-09-20 15:49:09 --> Helper loaded: url_helper
INFO - 2020-09-20 15:49:09 --> Helper loaded: form_helper
INFO - 2020-09-20 15:49:09 --> Helper loaded: file_helper
INFO - 2020-09-20 15:49:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 15:49:09 --> Database Driver Class Initialized
DEBUG - 2020-09-20 15:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 15:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:49:09 --> Upload Class Initialized
INFO - 2020-09-20 15:49:09 --> Controller Class Initialized
DEBUG - 2020-09-20 15:49:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 15:49:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 15:49:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 15:49:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 15:49:09 --> Final output sent to browser
DEBUG - 2020-09-20 15:49:09 --> Total execution time: 0.0473
INFO - 2020-09-20 16:02:08 --> Config Class Initialized
INFO - 2020-09-20 16:02:08 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:02:08 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:02:08 --> Utf8 Class Initialized
INFO - 2020-09-20 16:02:08 --> URI Class Initialized
DEBUG - 2020-09-20 16:02:08 --> No URI present. Default controller set.
INFO - 2020-09-20 16:02:08 --> Router Class Initialized
INFO - 2020-09-20 16:02:08 --> Output Class Initialized
INFO - 2020-09-20 16:02:08 --> Security Class Initialized
DEBUG - 2020-09-20 16:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:02:08 --> Input Class Initialized
INFO - 2020-09-20 16:02:08 --> Language Class Initialized
INFO - 2020-09-20 16:02:08 --> Language Class Initialized
INFO - 2020-09-20 16:02:08 --> Config Class Initialized
INFO - 2020-09-20 16:02:08 --> Loader Class Initialized
INFO - 2020-09-20 16:02:08 --> Helper loaded: url_helper
INFO - 2020-09-20 16:02:08 --> Helper loaded: form_helper
INFO - 2020-09-20 16:02:08 --> Helper loaded: file_helper
INFO - 2020-09-20 16:02:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:02:08 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:02:08 --> Upload Class Initialized
INFO - 2020-09-20 16:02:08 --> Controller Class Initialized
DEBUG - 2020-09-20 16:02:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 16:02:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 16:02:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 16:02:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 16:02:08 --> Final output sent to browser
DEBUG - 2020-09-20 16:02:08 --> Total execution time: 0.0524
INFO - 2020-09-20 16:02:20 --> Config Class Initialized
INFO - 2020-09-20 16:02:20 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:02:20 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:02:20 --> Utf8 Class Initialized
INFO - 2020-09-20 16:02:20 --> URI Class Initialized
INFO - 2020-09-20 16:02:20 --> Router Class Initialized
INFO - 2020-09-20 16:02:20 --> Output Class Initialized
INFO - 2020-09-20 16:02:20 --> Security Class Initialized
DEBUG - 2020-09-20 16:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:02:20 --> Input Class Initialized
INFO - 2020-09-20 16:02:20 --> Language Class Initialized
INFO - 2020-09-20 16:02:20 --> Language Class Initialized
INFO - 2020-09-20 16:02:20 --> Config Class Initialized
INFO - 2020-09-20 16:02:20 --> Loader Class Initialized
INFO - 2020-09-20 16:02:20 --> Helper loaded: url_helper
INFO - 2020-09-20 16:02:20 --> Helper loaded: form_helper
INFO - 2020-09-20 16:02:20 --> Helper loaded: file_helper
INFO - 2020-09-20 16:02:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:02:20 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:02:20 --> Upload Class Initialized
INFO - 2020-09-20 16:02:20 --> Controller Class Initialized
ERROR - 2020-09-20 16:02:20 --> 404 Page Not Found: /index
INFO - 2020-09-20 16:02:50 --> Config Class Initialized
INFO - 2020-09-20 16:02:50 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:02:50 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:02:50 --> Utf8 Class Initialized
INFO - 2020-09-20 16:02:50 --> URI Class Initialized
DEBUG - 2020-09-20 16:02:50 --> No URI present. Default controller set.
INFO - 2020-09-20 16:02:50 --> Router Class Initialized
INFO - 2020-09-20 16:02:50 --> Output Class Initialized
INFO - 2020-09-20 16:02:50 --> Security Class Initialized
DEBUG - 2020-09-20 16:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:02:50 --> Input Class Initialized
INFO - 2020-09-20 16:02:50 --> Language Class Initialized
INFO - 2020-09-20 16:02:50 --> Language Class Initialized
INFO - 2020-09-20 16:02:50 --> Config Class Initialized
INFO - 2020-09-20 16:02:50 --> Loader Class Initialized
INFO - 2020-09-20 16:02:50 --> Helper loaded: url_helper
INFO - 2020-09-20 16:02:50 --> Helper loaded: form_helper
INFO - 2020-09-20 16:02:50 --> Helper loaded: file_helper
INFO - 2020-09-20 16:02:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:02:50 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:02:50 --> Upload Class Initialized
INFO - 2020-09-20 16:02:50 --> Controller Class Initialized
DEBUG - 2020-09-20 16:02:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 16:02:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 16:02:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 16:02:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 16:02:50 --> Final output sent to browser
DEBUG - 2020-09-20 16:02:50 --> Total execution time: 0.0467
INFO - 2020-09-20 16:03:03 --> Config Class Initialized
INFO - 2020-09-20 16:03:03 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:03:03 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:03:03 --> Utf8 Class Initialized
INFO - 2020-09-20 16:03:03 --> URI Class Initialized
DEBUG - 2020-09-20 16:03:03 --> No URI present. Default controller set.
INFO - 2020-09-20 16:03:03 --> Router Class Initialized
INFO - 2020-09-20 16:03:03 --> Output Class Initialized
INFO - 2020-09-20 16:03:03 --> Security Class Initialized
DEBUG - 2020-09-20 16:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:03:03 --> Input Class Initialized
INFO - 2020-09-20 16:03:03 --> Language Class Initialized
INFO - 2020-09-20 16:03:03 --> Language Class Initialized
INFO - 2020-09-20 16:03:03 --> Config Class Initialized
INFO - 2020-09-20 16:03:03 --> Loader Class Initialized
INFO - 2020-09-20 16:03:03 --> Helper loaded: url_helper
INFO - 2020-09-20 16:03:03 --> Helper loaded: form_helper
INFO - 2020-09-20 16:03:03 --> Helper loaded: file_helper
INFO - 2020-09-20 16:03:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:03:03 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:03:03 --> Upload Class Initialized
INFO - 2020-09-20 16:03:03 --> Controller Class Initialized
DEBUG - 2020-09-20 16:03:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 16:03:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 16:03:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 16:03:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 16:03:03 --> Final output sent to browser
DEBUG - 2020-09-20 16:03:03 --> Total execution time: 0.0554
INFO - 2020-09-20 16:03:59 --> Config Class Initialized
INFO - 2020-09-20 16:03:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:03:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:03:59 --> Utf8 Class Initialized
INFO - 2020-09-20 16:03:59 --> URI Class Initialized
DEBUG - 2020-09-20 16:03:59 --> No URI present. Default controller set.
INFO - 2020-09-20 16:03:59 --> Router Class Initialized
INFO - 2020-09-20 16:03:59 --> Output Class Initialized
INFO - 2020-09-20 16:03:59 --> Security Class Initialized
DEBUG - 2020-09-20 16:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:03:59 --> Input Class Initialized
INFO - 2020-09-20 16:03:59 --> Language Class Initialized
INFO - 2020-09-20 16:03:59 --> Language Class Initialized
INFO - 2020-09-20 16:03:59 --> Config Class Initialized
INFO - 2020-09-20 16:03:59 --> Loader Class Initialized
INFO - 2020-09-20 16:03:59 --> Helper loaded: url_helper
INFO - 2020-09-20 16:03:59 --> Helper loaded: form_helper
INFO - 2020-09-20 16:03:59 --> Helper loaded: file_helper
INFO - 2020-09-20 16:03:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:03:59 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:03:59 --> Upload Class Initialized
INFO - 2020-09-20 16:03:59 --> Controller Class Initialized
DEBUG - 2020-09-20 16:03:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 16:03:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 16:03:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 16:03:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 16:03:59 --> Final output sent to browser
DEBUG - 2020-09-20 16:03:59 --> Total execution time: 0.0423
INFO - 2020-09-20 16:04:06 --> Config Class Initialized
INFO - 2020-09-20 16:04:06 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:04:06 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:04:06 --> Utf8 Class Initialized
INFO - 2020-09-20 16:04:06 --> URI Class Initialized
INFO - 2020-09-20 16:04:06 --> Router Class Initialized
INFO - 2020-09-20 16:04:06 --> Output Class Initialized
INFO - 2020-09-20 16:04:06 --> Security Class Initialized
DEBUG - 2020-09-20 16:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:04:06 --> Input Class Initialized
INFO - 2020-09-20 16:04:06 --> Language Class Initialized
INFO - 2020-09-20 16:04:06 --> Language Class Initialized
INFO - 2020-09-20 16:04:06 --> Config Class Initialized
INFO - 2020-09-20 16:04:06 --> Loader Class Initialized
INFO - 2020-09-20 16:04:06 --> Helper loaded: url_helper
INFO - 2020-09-20 16:04:06 --> Helper loaded: form_helper
INFO - 2020-09-20 16:04:06 --> Helper loaded: file_helper
INFO - 2020-09-20 16:04:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:04:06 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:04:06 --> Upload Class Initialized
INFO - 2020-09-20 16:04:06 --> Controller Class Initialized
ERROR - 2020-09-20 16:04:06 --> 404 Page Not Found: /index
INFO - 2020-09-20 16:57:17 --> Config Class Initialized
INFO - 2020-09-20 16:57:17 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:57:17 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:57:17 --> Utf8 Class Initialized
INFO - 2020-09-20 16:57:17 --> URI Class Initialized
DEBUG - 2020-09-20 16:57:17 --> No URI present. Default controller set.
INFO - 2020-09-20 16:57:17 --> Router Class Initialized
INFO - 2020-09-20 16:57:17 --> Output Class Initialized
INFO - 2020-09-20 16:57:17 --> Security Class Initialized
DEBUG - 2020-09-20 16:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:57:17 --> Input Class Initialized
INFO - 2020-09-20 16:57:17 --> Language Class Initialized
INFO - 2020-09-20 16:57:17 --> Language Class Initialized
INFO - 2020-09-20 16:57:17 --> Config Class Initialized
INFO - 2020-09-20 16:57:17 --> Loader Class Initialized
INFO - 2020-09-20 16:57:17 --> Helper loaded: url_helper
INFO - 2020-09-20 16:57:17 --> Helper loaded: form_helper
INFO - 2020-09-20 16:57:17 --> Helper loaded: file_helper
INFO - 2020-09-20 16:57:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:57:17 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:57:17 --> Upload Class Initialized
INFO - 2020-09-20 16:57:17 --> Controller Class Initialized
DEBUG - 2020-09-20 16:57:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 16:57:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 16:57:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 16:57:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 16:57:17 --> Final output sent to browser
DEBUG - 2020-09-20 16:57:17 --> Total execution time: 0.0379
INFO - 2020-09-20 16:57:31 --> Config Class Initialized
INFO - 2020-09-20 16:57:31 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:57:31 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:57:31 --> Utf8 Class Initialized
INFO - 2020-09-20 16:57:31 --> URI Class Initialized
INFO - 2020-09-20 16:57:31 --> Router Class Initialized
INFO - 2020-09-20 16:57:31 --> Output Class Initialized
INFO - 2020-09-20 16:57:31 --> Security Class Initialized
DEBUG - 2020-09-20 16:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:57:31 --> Input Class Initialized
INFO - 2020-09-20 16:57:31 --> Language Class Initialized
INFO - 2020-09-20 16:57:31 --> Language Class Initialized
INFO - 2020-09-20 16:57:31 --> Config Class Initialized
INFO - 2020-09-20 16:57:31 --> Loader Class Initialized
INFO - 2020-09-20 16:57:31 --> Helper loaded: url_helper
INFO - 2020-09-20 16:57:31 --> Helper loaded: form_helper
INFO - 2020-09-20 16:57:31 --> Helper loaded: file_helper
INFO - 2020-09-20 16:57:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:57:31 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:57:31 --> Upload Class Initialized
INFO - 2020-09-20 16:57:31 --> Controller Class Initialized
ERROR - 2020-09-20 16:57:31 --> 404 Page Not Found: /index
INFO - 2020-09-20 16:57:45 --> Config Class Initialized
INFO - 2020-09-20 16:57:45 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:57:45 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:57:45 --> Utf8 Class Initialized
INFO - 2020-09-20 16:57:45 --> URI Class Initialized
DEBUG - 2020-09-20 16:57:45 --> No URI present. Default controller set.
INFO - 2020-09-20 16:57:45 --> Router Class Initialized
INFO - 2020-09-20 16:57:45 --> Output Class Initialized
INFO - 2020-09-20 16:57:45 --> Security Class Initialized
DEBUG - 2020-09-20 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:57:45 --> Input Class Initialized
INFO - 2020-09-20 16:57:45 --> Language Class Initialized
INFO - 2020-09-20 16:57:45 --> Language Class Initialized
INFO - 2020-09-20 16:57:45 --> Config Class Initialized
INFO - 2020-09-20 16:57:45 --> Loader Class Initialized
INFO - 2020-09-20 16:57:45 --> Helper loaded: url_helper
INFO - 2020-09-20 16:57:45 --> Helper loaded: form_helper
INFO - 2020-09-20 16:57:45 --> Helper loaded: file_helper
INFO - 2020-09-20 16:57:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 16:57:45 --> Database Driver Class Initialized
DEBUG - 2020-09-20 16:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 16:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:57:45 --> Upload Class Initialized
INFO - 2020-09-20 16:57:45 --> Controller Class Initialized
DEBUG - 2020-09-20 16:57:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 16:57:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 16:57:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 16:57:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 16:57:45 --> Final output sent to browser
DEBUG - 2020-09-20 16:57:45 --> Total execution time: 0.0539
INFO - 2020-09-20 17:11:28 --> Config Class Initialized
INFO - 2020-09-20 17:11:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:11:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:11:28 --> Utf8 Class Initialized
INFO - 2020-09-20 17:11:28 --> URI Class Initialized
DEBUG - 2020-09-20 17:11:28 --> No URI present. Default controller set.
INFO - 2020-09-20 17:11:28 --> Router Class Initialized
INFO - 2020-09-20 17:11:28 --> Output Class Initialized
INFO - 2020-09-20 17:11:28 --> Security Class Initialized
DEBUG - 2020-09-20 17:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:11:28 --> Input Class Initialized
INFO - 2020-09-20 17:11:28 --> Language Class Initialized
INFO - 2020-09-20 17:11:28 --> Language Class Initialized
INFO - 2020-09-20 17:11:28 --> Config Class Initialized
INFO - 2020-09-20 17:11:28 --> Loader Class Initialized
INFO - 2020-09-20 17:11:28 --> Helper loaded: url_helper
INFO - 2020-09-20 17:11:28 --> Helper loaded: form_helper
INFO - 2020-09-20 17:11:29 --> Helper loaded: file_helper
INFO - 2020-09-20 17:11:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:11:29 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:11:29 --> Upload Class Initialized
INFO - 2020-09-20 17:11:29 --> Controller Class Initialized
DEBUG - 2020-09-20 17:11:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 17:11:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 17:11:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 17:11:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 17:11:29 --> Final output sent to browser
DEBUG - 2020-09-20 17:11:29 --> Total execution time: 0.0564
INFO - 2020-09-20 17:12:27 --> Config Class Initialized
INFO - 2020-09-20 17:12:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:12:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:12:27 --> Utf8 Class Initialized
INFO - 2020-09-20 17:12:27 --> URI Class Initialized
INFO - 2020-09-20 17:12:27 --> Router Class Initialized
INFO - 2020-09-20 17:12:27 --> Output Class Initialized
INFO - 2020-09-20 17:12:27 --> Security Class Initialized
DEBUG - 2020-09-20 17:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:12:27 --> Input Class Initialized
INFO - 2020-09-20 17:12:27 --> Language Class Initialized
INFO - 2020-09-20 17:12:27 --> Language Class Initialized
INFO - 2020-09-20 17:12:27 --> Config Class Initialized
INFO - 2020-09-20 17:12:27 --> Loader Class Initialized
INFO - 2020-09-20 17:12:27 --> Helper loaded: url_helper
INFO - 2020-09-20 17:12:27 --> Helper loaded: form_helper
INFO - 2020-09-20 17:12:27 --> Helper loaded: file_helper
INFO - 2020-09-20 17:12:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:12:27 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:12:27 --> Upload Class Initialized
INFO - 2020-09-20 17:12:27 --> Controller Class Initialized
ERROR - 2020-09-20 17:12:27 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:12:37 --> Config Class Initialized
INFO - 2020-09-20 17:12:37 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:12:37 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:12:37 --> Utf8 Class Initialized
INFO - 2020-09-20 17:12:37 --> URI Class Initialized
INFO - 2020-09-20 17:12:37 --> Router Class Initialized
INFO - 2020-09-20 17:12:37 --> Output Class Initialized
INFO - 2020-09-20 17:12:37 --> Security Class Initialized
DEBUG - 2020-09-20 17:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:12:37 --> Input Class Initialized
INFO - 2020-09-20 17:12:37 --> Language Class Initialized
INFO - 2020-09-20 17:12:37 --> Language Class Initialized
INFO - 2020-09-20 17:12:37 --> Config Class Initialized
INFO - 2020-09-20 17:12:37 --> Loader Class Initialized
INFO - 2020-09-20 17:12:37 --> Helper loaded: url_helper
INFO - 2020-09-20 17:12:37 --> Helper loaded: form_helper
INFO - 2020-09-20 17:12:37 --> Helper loaded: file_helper
INFO - 2020-09-20 17:12:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:12:37 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:12:37 --> Upload Class Initialized
INFO - 2020-09-20 17:12:37 --> Controller Class Initialized
ERROR - 2020-09-20 17:12:37 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:12:42 --> Config Class Initialized
INFO - 2020-09-20 17:12:42 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:12:42 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:12:42 --> Utf8 Class Initialized
INFO - 2020-09-20 17:12:42 --> URI Class Initialized
DEBUG - 2020-09-20 17:12:42 --> No URI present. Default controller set.
INFO - 2020-09-20 17:12:42 --> Router Class Initialized
INFO - 2020-09-20 17:12:42 --> Output Class Initialized
INFO - 2020-09-20 17:12:42 --> Security Class Initialized
DEBUG - 2020-09-20 17:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:12:42 --> Input Class Initialized
INFO - 2020-09-20 17:12:42 --> Language Class Initialized
INFO - 2020-09-20 17:12:42 --> Language Class Initialized
INFO - 2020-09-20 17:12:42 --> Config Class Initialized
INFO - 2020-09-20 17:12:42 --> Loader Class Initialized
INFO - 2020-09-20 17:12:42 --> Helper loaded: url_helper
INFO - 2020-09-20 17:12:42 --> Helper loaded: form_helper
INFO - 2020-09-20 17:12:42 --> Helper loaded: file_helper
INFO - 2020-09-20 17:12:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:12:42 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:12:42 --> Upload Class Initialized
INFO - 2020-09-20 17:12:42 --> Controller Class Initialized
DEBUG - 2020-09-20 17:12:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 17:12:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 17:12:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 17:12:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 17:12:42 --> Final output sent to browser
DEBUG - 2020-09-20 17:12:42 --> Total execution time: 0.0459
INFO - 2020-09-20 17:12:46 --> Config Class Initialized
INFO - 2020-09-20 17:12:46 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:12:46 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:12:46 --> Utf8 Class Initialized
INFO - 2020-09-20 17:12:46 --> URI Class Initialized
INFO - 2020-09-20 17:12:46 --> Router Class Initialized
INFO - 2020-09-20 17:12:46 --> Output Class Initialized
INFO - 2020-09-20 17:12:46 --> Security Class Initialized
DEBUG - 2020-09-20 17:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:12:46 --> Input Class Initialized
INFO - 2020-09-20 17:12:46 --> Language Class Initialized
INFO - 2020-09-20 17:12:46 --> Language Class Initialized
INFO - 2020-09-20 17:12:46 --> Config Class Initialized
INFO - 2020-09-20 17:12:46 --> Loader Class Initialized
INFO - 2020-09-20 17:12:46 --> Helper loaded: url_helper
INFO - 2020-09-20 17:12:46 --> Helper loaded: form_helper
INFO - 2020-09-20 17:12:46 --> Helper loaded: file_helper
INFO - 2020-09-20 17:12:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:12:46 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:12:46 --> Upload Class Initialized
INFO - 2020-09-20 17:12:46 --> Controller Class Initialized
ERROR - 2020-09-20 17:12:46 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:15:34 --> Config Class Initialized
INFO - 2020-09-20 17:15:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:15:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:15:34 --> Utf8 Class Initialized
INFO - 2020-09-20 17:15:34 --> URI Class Initialized
INFO - 2020-09-20 17:15:34 --> Router Class Initialized
INFO - 2020-09-20 17:15:34 --> Output Class Initialized
INFO - 2020-09-20 17:15:34 --> Security Class Initialized
DEBUG - 2020-09-20 17:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:15:34 --> Input Class Initialized
INFO - 2020-09-20 17:15:34 --> Language Class Initialized
INFO - 2020-09-20 17:15:34 --> Language Class Initialized
INFO - 2020-09-20 17:15:34 --> Config Class Initialized
INFO - 2020-09-20 17:15:34 --> Loader Class Initialized
INFO - 2020-09-20 17:15:34 --> Helper loaded: url_helper
INFO - 2020-09-20 17:15:34 --> Helper loaded: form_helper
INFO - 2020-09-20 17:15:34 --> Helper loaded: file_helper
INFO - 2020-09-20 17:15:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:15:34 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:15:34 --> Upload Class Initialized
INFO - 2020-09-20 17:15:35 --> Controller Class Initialized
ERROR - 2020-09-20 17:15:35 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:25:27 --> Config Class Initialized
INFO - 2020-09-20 17:25:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:27 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:27 --> URI Class Initialized
DEBUG - 2020-09-20 17:25:27 --> No URI present. Default controller set.
INFO - 2020-09-20 17:25:27 --> Router Class Initialized
INFO - 2020-09-20 17:25:27 --> Output Class Initialized
INFO - 2020-09-20 17:25:27 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:27 --> Input Class Initialized
INFO - 2020-09-20 17:25:27 --> Language Class Initialized
INFO - 2020-09-20 17:25:27 --> Language Class Initialized
INFO - 2020-09-20 17:25:27 --> Config Class Initialized
INFO - 2020-09-20 17:25:27 --> Loader Class Initialized
INFO - 2020-09-20 17:25:27 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:27 --> Helper loaded: form_helper
INFO - 2020-09-20 17:25:27 --> Helper loaded: file_helper
INFO - 2020-09-20 17:25:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:25:27 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:27 --> Upload Class Initialized
INFO - 2020-09-20 17:25:27 --> Controller Class Initialized
DEBUG - 2020-09-20 17:25:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 17:25:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 17:25:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 17:25:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 17:25:27 --> Final output sent to browser
DEBUG - 2020-09-20 17:25:27 --> Total execution time: 0.0643
INFO - 2020-09-20 17:25:38 --> Config Class Initialized
INFO - 2020-09-20 17:25:38 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:38 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:38 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:38 --> URI Class Initialized
INFO - 2020-09-20 17:25:38 --> Router Class Initialized
INFO - 2020-09-20 17:25:38 --> Output Class Initialized
INFO - 2020-09-20 17:25:38 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:38 --> Input Class Initialized
INFO - 2020-09-20 17:25:38 --> Language Class Initialized
INFO - 2020-09-20 17:25:39 --> Language Class Initialized
INFO - 2020-09-20 17:25:39 --> Config Class Initialized
INFO - 2020-09-20 17:25:39 --> Loader Class Initialized
INFO - 2020-09-20 17:25:39 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:39 --> Helper loaded: form_helper
INFO - 2020-09-20 17:25:39 --> Helper loaded: file_helper
INFO - 2020-09-20 17:25:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:25:39 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:39 --> Upload Class Initialized
INFO - 2020-09-20 17:25:39 --> Controller Class Initialized
ERROR - 2020-09-20 17:25:39 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:25:44 --> Config Class Initialized
INFO - 2020-09-20 17:25:44 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:44 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:44 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:44 --> URI Class Initialized
INFO - 2020-09-20 17:25:44 --> Router Class Initialized
INFO - 2020-09-20 17:25:44 --> Output Class Initialized
INFO - 2020-09-20 17:25:44 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:44 --> Input Class Initialized
INFO - 2020-09-20 17:25:44 --> Language Class Initialized
INFO - 2020-09-20 17:25:44 --> Language Class Initialized
INFO - 2020-09-20 17:25:44 --> Config Class Initialized
INFO - 2020-09-20 17:25:44 --> Loader Class Initialized
INFO - 2020-09-20 17:25:44 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:44 --> Helper loaded: form_helper
INFO - 2020-09-20 17:25:44 --> Helper loaded: file_helper
INFO - 2020-09-20 17:25:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:25:44 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:44 --> Upload Class Initialized
INFO - 2020-09-20 17:25:44 --> Controller Class Initialized
ERROR - 2020-09-20 17:25:44 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:25:45 --> Config Class Initialized
INFO - 2020-09-20 17:25:45 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:45 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:45 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:45 --> URI Class Initialized
INFO - 2020-09-20 17:25:45 --> Router Class Initialized
INFO - 2020-09-20 17:25:45 --> Output Class Initialized
INFO - 2020-09-20 17:25:45 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:45 --> Input Class Initialized
INFO - 2020-09-20 17:25:45 --> Language Class Initialized
INFO - 2020-09-20 17:25:45 --> Language Class Initialized
INFO - 2020-09-20 17:25:45 --> Config Class Initialized
INFO - 2020-09-20 17:25:45 --> Loader Class Initialized
INFO - 2020-09-20 17:25:45 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:45 --> Helper loaded: form_helper
INFO - 2020-09-20 17:25:45 --> Helper loaded: file_helper
INFO - 2020-09-20 17:25:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:25:45 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:45 --> Upload Class Initialized
INFO - 2020-09-20 17:25:45 --> Controller Class Initialized
ERROR - 2020-09-20 17:25:45 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:25:56 --> Config Class Initialized
INFO - 2020-09-20 17:25:56 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:56 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:56 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:56 --> URI Class Initialized
DEBUG - 2020-09-20 17:25:56 --> No URI present. Default controller set.
INFO - 2020-09-20 17:25:56 --> Router Class Initialized
INFO - 2020-09-20 17:25:56 --> Output Class Initialized
INFO - 2020-09-20 17:25:56 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:56 --> Input Class Initialized
INFO - 2020-09-20 17:25:56 --> Language Class Initialized
INFO - 2020-09-20 17:25:56 --> Language Class Initialized
INFO - 2020-09-20 17:25:56 --> Config Class Initialized
INFO - 2020-09-20 17:25:56 --> Loader Class Initialized
INFO - 2020-09-20 17:25:56 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:56 --> Helper loaded: form_helper
INFO - 2020-09-20 17:25:56 --> Helper loaded: file_helper
INFO - 2020-09-20 17:25:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:25:56 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:56 --> Upload Class Initialized
INFO - 2020-09-20 17:25:56 --> Controller Class Initialized
DEBUG - 2020-09-20 17:25:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 17:25:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 17:25:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 17:25:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 17:25:56 --> Final output sent to browser
DEBUG - 2020-09-20 17:25:56 --> Total execution time: 0.0556
INFO - 2020-09-20 17:26:04 --> Config Class Initialized
INFO - 2020-09-20 17:26:04 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:26:04 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:26:04 --> Utf8 Class Initialized
INFO - 2020-09-20 17:26:04 --> URI Class Initialized
INFO - 2020-09-20 17:26:04 --> Router Class Initialized
INFO - 2020-09-20 17:26:04 --> Output Class Initialized
INFO - 2020-09-20 17:26:04 --> Security Class Initialized
DEBUG - 2020-09-20 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:26:04 --> Input Class Initialized
INFO - 2020-09-20 17:26:04 --> Language Class Initialized
INFO - 2020-09-20 17:26:04 --> Language Class Initialized
INFO - 2020-09-20 17:26:04 --> Config Class Initialized
INFO - 2020-09-20 17:26:04 --> Loader Class Initialized
INFO - 2020-09-20 17:26:04 --> Helper loaded: url_helper
INFO - 2020-09-20 17:26:04 --> Helper loaded: form_helper
INFO - 2020-09-20 17:26:04 --> Helper loaded: file_helper
INFO - 2020-09-20 17:26:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:26:04 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:26:04 --> Upload Class Initialized
INFO - 2020-09-20 17:26:04 --> Controller Class Initialized
ERROR - 2020-09-20 17:26:04 --> 404 Page Not Found: /index
INFO - 2020-09-20 17:26:13 --> Config Class Initialized
INFO - 2020-09-20 17:26:13 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:26:13 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:26:13 --> Utf8 Class Initialized
INFO - 2020-09-20 17:26:13 --> URI Class Initialized
DEBUG - 2020-09-20 17:26:13 --> No URI present. Default controller set.
INFO - 2020-09-20 17:26:13 --> Router Class Initialized
INFO - 2020-09-20 17:26:13 --> Output Class Initialized
INFO - 2020-09-20 17:26:13 --> Security Class Initialized
DEBUG - 2020-09-20 17:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:26:13 --> Input Class Initialized
INFO - 2020-09-20 17:26:13 --> Language Class Initialized
INFO - 2020-09-20 17:26:13 --> Language Class Initialized
INFO - 2020-09-20 17:26:13 --> Config Class Initialized
INFO - 2020-09-20 17:26:13 --> Loader Class Initialized
INFO - 2020-09-20 17:26:13 --> Helper loaded: url_helper
INFO - 2020-09-20 17:26:13 --> Helper loaded: form_helper
INFO - 2020-09-20 17:26:13 --> Helper loaded: file_helper
INFO - 2020-09-20 17:26:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:26:13 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:26:13 --> Upload Class Initialized
INFO - 2020-09-20 17:26:13 --> Controller Class Initialized
DEBUG - 2020-09-20 17:26:13 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 17:26:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 17:26:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 17:26:13 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 17:26:13 --> Final output sent to browser
DEBUG - 2020-09-20 17:26:13 --> Total execution time: 0.0577
INFO - 2020-09-20 17:46:57 --> Config Class Initialized
INFO - 2020-09-20 17:46:57 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:46:57 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:46:57 --> Utf8 Class Initialized
INFO - 2020-09-20 17:46:57 --> URI Class Initialized
INFO - 2020-09-20 17:46:57 --> Router Class Initialized
INFO - 2020-09-20 17:46:57 --> Output Class Initialized
INFO - 2020-09-20 17:46:57 --> Security Class Initialized
DEBUG - 2020-09-20 17:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:46:57 --> Input Class Initialized
INFO - 2020-09-20 17:46:57 --> Language Class Initialized
INFO - 2020-09-20 17:46:57 --> Language Class Initialized
INFO - 2020-09-20 17:46:57 --> Config Class Initialized
INFO - 2020-09-20 17:46:57 --> Loader Class Initialized
INFO - 2020-09-20 17:46:57 --> Helper loaded: url_helper
INFO - 2020-09-20 17:46:57 --> Helper loaded: form_helper
INFO - 2020-09-20 17:46:57 --> Helper loaded: file_helper
INFO - 2020-09-20 17:46:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 17:46:57 --> Database Driver Class Initialized
DEBUG - 2020-09-20 17:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 17:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:46:57 --> Upload Class Initialized
INFO - 2020-09-20 17:46:57 --> Controller Class Initialized
ERROR - 2020-09-20 17:46:57 --> 404 Page Not Found: /index
INFO - 2020-09-20 18:27:07 --> Config Class Initialized
INFO - 2020-09-20 18:27:07 --> Hooks Class Initialized
DEBUG - 2020-09-20 18:27:07 --> UTF-8 Support Enabled
INFO - 2020-09-20 18:27:07 --> Utf8 Class Initialized
INFO - 2020-09-20 18:27:07 --> URI Class Initialized
INFO - 2020-09-20 18:27:07 --> Router Class Initialized
INFO - 2020-09-20 18:27:07 --> Output Class Initialized
INFO - 2020-09-20 18:27:07 --> Security Class Initialized
DEBUG - 2020-09-20 18:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 18:27:07 --> Input Class Initialized
INFO - 2020-09-20 18:27:07 --> Language Class Initialized
INFO - 2020-09-20 18:27:07 --> Language Class Initialized
INFO - 2020-09-20 18:27:07 --> Config Class Initialized
INFO - 2020-09-20 18:27:07 --> Loader Class Initialized
INFO - 2020-09-20 18:27:07 --> Helper loaded: url_helper
INFO - 2020-09-20 18:27:07 --> Helper loaded: form_helper
INFO - 2020-09-20 18:27:07 --> Helper loaded: file_helper
INFO - 2020-09-20 18:27:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 18:27:07 --> Database Driver Class Initialized
DEBUG - 2020-09-20 18:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 18:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 18:27:07 --> Upload Class Initialized
INFO - 2020-09-20 18:27:07 --> Controller Class Initialized
ERROR - 2020-09-20 18:27:07 --> 404 Page Not Found: /index
INFO - 2020-09-20 18:33:12 --> Config Class Initialized
INFO - 2020-09-20 18:33:12 --> Hooks Class Initialized
DEBUG - 2020-09-20 18:33:12 --> UTF-8 Support Enabled
INFO - 2020-09-20 18:33:12 --> Utf8 Class Initialized
INFO - 2020-09-20 18:33:12 --> URI Class Initialized
DEBUG - 2020-09-20 18:33:12 --> No URI present. Default controller set.
INFO - 2020-09-20 18:33:12 --> Router Class Initialized
INFO - 2020-09-20 18:33:12 --> Output Class Initialized
INFO - 2020-09-20 18:33:12 --> Security Class Initialized
DEBUG - 2020-09-20 18:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 18:33:12 --> Input Class Initialized
INFO - 2020-09-20 18:33:12 --> Language Class Initialized
INFO - 2020-09-20 18:33:12 --> Language Class Initialized
INFO - 2020-09-20 18:33:12 --> Config Class Initialized
INFO - 2020-09-20 18:33:12 --> Loader Class Initialized
INFO - 2020-09-20 18:33:12 --> Helper loaded: url_helper
INFO - 2020-09-20 18:33:12 --> Helper loaded: form_helper
INFO - 2020-09-20 18:33:12 --> Helper loaded: file_helper
INFO - 2020-09-20 18:33:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 18:33:12 --> Database Driver Class Initialized
DEBUG - 2020-09-20 18:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 18:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 18:33:12 --> Upload Class Initialized
INFO - 2020-09-20 18:33:12 --> Controller Class Initialized
DEBUG - 2020-09-20 18:33:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 18:33:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 18:33:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 18:33:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 18:33:12 --> Final output sent to browser
DEBUG - 2020-09-20 18:33:12 --> Total execution time: 0.0583
INFO - 2020-09-20 19:02:10 --> Config Class Initialized
INFO - 2020-09-20 19:02:10 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:02:10 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:02:10 --> Utf8 Class Initialized
INFO - 2020-09-20 19:02:10 --> URI Class Initialized
INFO - 2020-09-20 19:02:10 --> Router Class Initialized
INFO - 2020-09-20 19:02:10 --> Output Class Initialized
INFO - 2020-09-20 19:02:10 --> Security Class Initialized
DEBUG - 2020-09-20 19:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:02:10 --> Input Class Initialized
INFO - 2020-09-20 19:02:10 --> Language Class Initialized
INFO - 2020-09-20 19:02:10 --> Language Class Initialized
INFO - 2020-09-20 19:02:10 --> Config Class Initialized
INFO - 2020-09-20 19:02:10 --> Loader Class Initialized
INFO - 2020-09-20 19:02:10 --> Helper loaded: url_helper
INFO - 2020-09-20 19:02:10 --> Helper loaded: form_helper
INFO - 2020-09-20 19:02:10 --> Helper loaded: file_helper
INFO - 2020-09-20 19:02:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:02:10 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:02:10 --> Upload Class Initialized
INFO - 2020-09-20 19:02:10 --> Controller Class Initialized
ERROR - 2020-09-20 19:02:10 --> 404 Page Not Found: /index
INFO - 2020-09-20 19:02:11 --> Config Class Initialized
INFO - 2020-09-20 19:02:11 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:02:11 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:02:11 --> Utf8 Class Initialized
INFO - 2020-09-20 19:02:11 --> URI Class Initialized
DEBUG - 2020-09-20 19:02:11 --> No URI present. Default controller set.
INFO - 2020-09-20 19:02:11 --> Router Class Initialized
INFO - 2020-09-20 19:02:11 --> Output Class Initialized
INFO - 2020-09-20 19:02:11 --> Security Class Initialized
DEBUG - 2020-09-20 19:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:02:11 --> Input Class Initialized
INFO - 2020-09-20 19:02:11 --> Language Class Initialized
INFO - 2020-09-20 19:02:11 --> Language Class Initialized
INFO - 2020-09-20 19:02:11 --> Config Class Initialized
INFO - 2020-09-20 19:02:11 --> Loader Class Initialized
INFO - 2020-09-20 19:02:11 --> Helper loaded: url_helper
INFO - 2020-09-20 19:02:11 --> Helper loaded: form_helper
INFO - 2020-09-20 19:02:11 --> Helper loaded: file_helper
INFO - 2020-09-20 19:02:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:02:11 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:02:11 --> Upload Class Initialized
INFO - 2020-09-20 19:02:11 --> Controller Class Initialized
DEBUG - 2020-09-20 19:02:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 19:02:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 19:02:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 19:02:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 19:02:11 --> Final output sent to browser
DEBUG - 2020-09-20 19:02:11 --> Total execution time: 0.0517
INFO - 2020-09-20 19:38:12 --> Config Class Initialized
INFO - 2020-09-20 19:38:12 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:38:12 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:38:12 --> Utf8 Class Initialized
INFO - 2020-09-20 19:38:12 --> URI Class Initialized
DEBUG - 2020-09-20 19:38:12 --> No URI present. Default controller set.
INFO - 2020-09-20 19:38:12 --> Router Class Initialized
INFO - 2020-09-20 19:38:12 --> Output Class Initialized
INFO - 2020-09-20 19:38:12 --> Security Class Initialized
DEBUG - 2020-09-20 19:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:38:12 --> Input Class Initialized
INFO - 2020-09-20 19:38:12 --> Language Class Initialized
INFO - 2020-09-20 19:38:12 --> Language Class Initialized
INFO - 2020-09-20 19:38:12 --> Config Class Initialized
INFO - 2020-09-20 19:38:12 --> Loader Class Initialized
INFO - 2020-09-20 19:38:12 --> Helper loaded: url_helper
INFO - 2020-09-20 19:38:12 --> Helper loaded: form_helper
INFO - 2020-09-20 19:38:12 --> Helper loaded: file_helper
INFO - 2020-09-20 19:38:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:38:12 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:38:12 --> Upload Class Initialized
INFO - 2020-09-20 19:38:12 --> Controller Class Initialized
DEBUG - 2020-09-20 19:38:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 19:38:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 19:38:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 19:38:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 19:38:12 --> Final output sent to browser
DEBUG - 2020-09-20 19:38:12 --> Total execution time: 0.0508
INFO - 2020-09-20 19:38:17 --> Config Class Initialized
INFO - 2020-09-20 19:38:17 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:38:17 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:38:17 --> Utf8 Class Initialized
INFO - 2020-09-20 19:38:17 --> URI Class Initialized
INFO - 2020-09-20 19:38:17 --> Router Class Initialized
INFO - 2020-09-20 19:38:17 --> Output Class Initialized
INFO - 2020-09-20 19:38:17 --> Security Class Initialized
DEBUG - 2020-09-20 19:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:38:17 --> Input Class Initialized
INFO - 2020-09-20 19:38:17 --> Language Class Initialized
INFO - 2020-09-20 19:38:17 --> Language Class Initialized
INFO - 2020-09-20 19:38:17 --> Config Class Initialized
INFO - 2020-09-20 19:38:17 --> Loader Class Initialized
INFO - 2020-09-20 19:38:17 --> Helper loaded: url_helper
INFO - 2020-09-20 19:38:17 --> Helper loaded: form_helper
INFO - 2020-09-20 19:38:17 --> Helper loaded: file_helper
INFO - 2020-09-20 19:38:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:38:17 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:38:17 --> Upload Class Initialized
INFO - 2020-09-20 19:38:17 --> Controller Class Initialized
ERROR - 2020-09-20 19:38:17 --> 404 Page Not Found: /index
INFO - 2020-09-20 19:47:33 --> Config Class Initialized
INFO - 2020-09-20 19:47:33 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:47:33 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:47:33 --> Utf8 Class Initialized
INFO - 2020-09-20 19:47:33 --> URI Class Initialized
DEBUG - 2020-09-20 19:47:33 --> No URI present. Default controller set.
INFO - 2020-09-20 19:47:33 --> Router Class Initialized
INFO - 2020-09-20 19:47:33 --> Output Class Initialized
INFO - 2020-09-20 19:47:33 --> Security Class Initialized
DEBUG - 2020-09-20 19:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:47:33 --> Input Class Initialized
INFO - 2020-09-20 19:47:33 --> Language Class Initialized
INFO - 2020-09-20 19:47:33 --> Language Class Initialized
INFO - 2020-09-20 19:47:33 --> Config Class Initialized
INFO - 2020-09-20 19:47:33 --> Loader Class Initialized
INFO - 2020-09-20 19:47:33 --> Helper loaded: url_helper
INFO - 2020-09-20 19:47:33 --> Helper loaded: form_helper
INFO - 2020-09-20 19:47:33 --> Helper loaded: file_helper
INFO - 2020-09-20 19:47:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:47:33 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:47:33 --> Upload Class Initialized
INFO - 2020-09-20 19:47:33 --> Controller Class Initialized
DEBUG - 2020-09-20 19:47:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 19:47:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 19:47:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 19:47:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 19:47:33 --> Final output sent to browser
DEBUG - 2020-09-20 19:47:33 --> Total execution time: 0.0603
INFO - 2020-09-20 19:47:46 --> Config Class Initialized
INFO - 2020-09-20 19:47:46 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:47:46 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:47:46 --> Utf8 Class Initialized
INFO - 2020-09-20 19:47:46 --> URI Class Initialized
INFO - 2020-09-20 19:47:46 --> Router Class Initialized
INFO - 2020-09-20 19:47:46 --> Output Class Initialized
INFO - 2020-09-20 19:47:46 --> Security Class Initialized
DEBUG - 2020-09-20 19:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:47:46 --> Input Class Initialized
INFO - 2020-09-20 19:47:46 --> Language Class Initialized
INFO - 2020-09-20 19:47:46 --> Language Class Initialized
INFO - 2020-09-20 19:47:46 --> Config Class Initialized
INFO - 2020-09-20 19:47:46 --> Loader Class Initialized
INFO - 2020-09-20 19:47:46 --> Helper loaded: url_helper
INFO - 2020-09-20 19:47:46 --> Helper loaded: form_helper
INFO - 2020-09-20 19:47:46 --> Helper loaded: file_helper
INFO - 2020-09-20 19:47:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:47:46 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:47:46 --> Upload Class Initialized
INFO - 2020-09-20 19:47:46 --> Controller Class Initialized
ERROR - 2020-09-20 19:47:46 --> 404 Page Not Found: /index
INFO - 2020-09-20 19:47:55 --> Config Class Initialized
INFO - 2020-09-20 19:47:55 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:47:55 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:47:55 --> Utf8 Class Initialized
INFO - 2020-09-20 19:47:55 --> URI Class Initialized
INFO - 2020-09-20 19:47:55 --> Router Class Initialized
INFO - 2020-09-20 19:47:55 --> Output Class Initialized
INFO - 2020-09-20 19:47:55 --> Security Class Initialized
DEBUG - 2020-09-20 19:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:47:55 --> Input Class Initialized
INFO - 2020-09-20 19:47:55 --> Language Class Initialized
INFO - 2020-09-20 19:47:55 --> Language Class Initialized
INFO - 2020-09-20 19:47:55 --> Config Class Initialized
INFO - 2020-09-20 19:47:55 --> Loader Class Initialized
INFO - 2020-09-20 19:47:55 --> Helper loaded: url_helper
INFO - 2020-09-20 19:47:55 --> Helper loaded: form_helper
INFO - 2020-09-20 19:47:55 --> Helper loaded: file_helper
INFO - 2020-09-20 19:47:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:47:55 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:47:55 --> Upload Class Initialized
INFO - 2020-09-20 19:47:55 --> Controller Class Initialized
ERROR - 2020-09-20 19:47:55 --> 404 Page Not Found: /index
INFO - 2020-09-20 19:47:59 --> Config Class Initialized
INFO - 2020-09-20 19:47:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:47:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:47:59 --> Utf8 Class Initialized
INFO - 2020-09-20 19:47:59 --> URI Class Initialized
DEBUG - 2020-09-20 19:47:59 --> No URI present. Default controller set.
INFO - 2020-09-20 19:47:59 --> Router Class Initialized
INFO - 2020-09-20 19:47:59 --> Output Class Initialized
INFO - 2020-09-20 19:47:59 --> Security Class Initialized
DEBUG - 2020-09-20 19:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:47:59 --> Input Class Initialized
INFO - 2020-09-20 19:47:59 --> Language Class Initialized
INFO - 2020-09-20 19:47:59 --> Language Class Initialized
INFO - 2020-09-20 19:47:59 --> Config Class Initialized
INFO - 2020-09-20 19:47:59 --> Loader Class Initialized
INFO - 2020-09-20 19:47:59 --> Helper loaded: url_helper
INFO - 2020-09-20 19:47:59 --> Helper loaded: form_helper
INFO - 2020-09-20 19:47:59 --> Helper loaded: file_helper
INFO - 2020-09-20 19:47:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:47:59 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:47:59 --> Upload Class Initialized
INFO - 2020-09-20 19:47:59 --> Controller Class Initialized
DEBUG - 2020-09-20 19:47:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 19:47:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 19:47:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 19:47:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 19:47:59 --> Final output sent to browser
DEBUG - 2020-09-20 19:47:59 --> Total execution time: 0.0507
INFO - 2020-09-20 19:53:07 --> Config Class Initialized
INFO - 2020-09-20 19:53:07 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:53:07 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:53:07 --> Utf8 Class Initialized
INFO - 2020-09-20 19:53:07 --> URI Class Initialized
INFO - 2020-09-20 19:53:07 --> Router Class Initialized
INFO - 2020-09-20 19:53:07 --> Output Class Initialized
INFO - 2020-09-20 19:53:07 --> Security Class Initialized
DEBUG - 2020-09-20 19:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:53:07 --> Input Class Initialized
INFO - 2020-09-20 19:53:07 --> Language Class Initialized
INFO - 2020-09-20 19:53:07 --> Language Class Initialized
INFO - 2020-09-20 19:53:07 --> Config Class Initialized
INFO - 2020-09-20 19:53:07 --> Loader Class Initialized
INFO - 2020-09-20 19:53:07 --> Helper loaded: url_helper
INFO - 2020-09-20 19:53:07 --> Helper loaded: form_helper
INFO - 2020-09-20 19:53:07 --> Helper loaded: file_helper
INFO - 2020-09-20 19:53:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:53:07 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:53:07 --> Upload Class Initialized
INFO - 2020-09-20 19:53:07 --> Controller Class Initialized
ERROR - 2020-09-20 19:53:07 --> 404 Page Not Found: /index
INFO - 2020-09-20 19:53:11 --> Config Class Initialized
INFO - 2020-09-20 19:53:11 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:53:11 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:53:11 --> Utf8 Class Initialized
INFO - 2020-09-20 19:53:11 --> URI Class Initialized
INFO - 2020-09-20 19:53:11 --> Router Class Initialized
INFO - 2020-09-20 19:53:11 --> Output Class Initialized
INFO - 2020-09-20 19:53:11 --> Security Class Initialized
DEBUG - 2020-09-20 19:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:53:11 --> Input Class Initialized
INFO - 2020-09-20 19:53:11 --> Language Class Initialized
INFO - 2020-09-20 19:53:11 --> Language Class Initialized
INFO - 2020-09-20 19:53:11 --> Config Class Initialized
INFO - 2020-09-20 19:53:11 --> Loader Class Initialized
INFO - 2020-09-20 19:53:11 --> Helper loaded: url_helper
INFO - 2020-09-20 19:53:11 --> Helper loaded: form_helper
INFO - 2020-09-20 19:53:11 --> Helper loaded: file_helper
INFO - 2020-09-20 19:53:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:53:11 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:53:11 --> Upload Class Initialized
INFO - 2020-09-20 19:53:11 --> Controller Class Initialized
ERROR - 2020-09-20 19:53:11 --> 404 Page Not Found: /index
INFO - 2020-09-20 19:53:15 --> Config Class Initialized
INFO - 2020-09-20 19:53:15 --> Hooks Class Initialized
DEBUG - 2020-09-20 19:53:15 --> UTF-8 Support Enabled
INFO - 2020-09-20 19:53:15 --> Utf8 Class Initialized
INFO - 2020-09-20 19:53:15 --> URI Class Initialized
INFO - 2020-09-20 19:53:15 --> Router Class Initialized
INFO - 2020-09-20 19:53:15 --> Output Class Initialized
INFO - 2020-09-20 19:53:15 --> Security Class Initialized
DEBUG - 2020-09-20 19:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 19:53:15 --> Input Class Initialized
INFO - 2020-09-20 19:53:15 --> Language Class Initialized
INFO - 2020-09-20 19:53:15 --> Language Class Initialized
INFO - 2020-09-20 19:53:15 --> Config Class Initialized
INFO - 2020-09-20 19:53:15 --> Loader Class Initialized
INFO - 2020-09-20 19:53:15 --> Helper loaded: url_helper
INFO - 2020-09-20 19:53:15 --> Helper loaded: form_helper
INFO - 2020-09-20 19:53:15 --> Helper loaded: file_helper
INFO - 2020-09-20 19:53:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 19:53:15 --> Database Driver Class Initialized
DEBUG - 2020-09-20 19:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 19:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 19:53:15 --> Upload Class Initialized
INFO - 2020-09-20 19:53:15 --> Controller Class Initialized
ERROR - 2020-09-20 19:53:15 --> 404 Page Not Found: /index
INFO - 2020-09-20 20:03:35 --> Config Class Initialized
INFO - 2020-09-20 20:03:35 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:03:35 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:03:35 --> Utf8 Class Initialized
INFO - 2020-09-20 20:03:35 --> URI Class Initialized
INFO - 2020-09-20 20:03:35 --> Router Class Initialized
INFO - 2020-09-20 20:03:35 --> Output Class Initialized
INFO - 2020-09-20 20:03:35 --> Security Class Initialized
DEBUG - 2020-09-20 20:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:03:35 --> Input Class Initialized
INFO - 2020-09-20 20:03:35 --> Language Class Initialized
INFO - 2020-09-20 20:03:35 --> Language Class Initialized
INFO - 2020-09-20 20:03:35 --> Config Class Initialized
INFO - 2020-09-20 20:03:35 --> Loader Class Initialized
INFO - 2020-09-20 20:03:35 --> Helper loaded: url_helper
INFO - 2020-09-20 20:03:35 --> Helper loaded: form_helper
INFO - 2020-09-20 20:03:35 --> Helper loaded: file_helper
INFO - 2020-09-20 20:03:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:03:35 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:03:35 --> Upload Class Initialized
INFO - 2020-09-20 20:03:35 --> Controller Class Initialized
ERROR - 2020-09-20 20:03:35 --> 404 Page Not Found: /index
INFO - 2020-09-20 20:03:35 --> Config Class Initialized
INFO - 2020-09-20 20:03:35 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:03:35 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:03:35 --> Utf8 Class Initialized
INFO - 2020-09-20 20:03:35 --> URI Class Initialized
INFO - 2020-09-20 20:03:35 --> Router Class Initialized
INFO - 2020-09-20 20:03:35 --> Output Class Initialized
INFO - 2020-09-20 20:03:35 --> Security Class Initialized
DEBUG - 2020-09-20 20:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:03:35 --> Input Class Initialized
INFO - 2020-09-20 20:03:35 --> Language Class Initialized
INFO - 2020-09-20 20:03:35 --> Language Class Initialized
INFO - 2020-09-20 20:03:35 --> Config Class Initialized
INFO - 2020-09-20 20:03:35 --> Loader Class Initialized
INFO - 2020-09-20 20:03:35 --> Helper loaded: url_helper
INFO - 2020-09-20 20:03:35 --> Helper loaded: form_helper
INFO - 2020-09-20 20:03:35 --> Helper loaded: file_helper
INFO - 2020-09-20 20:03:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:03:35 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:03:35 --> Upload Class Initialized
INFO - 2020-09-20 20:03:35 --> Controller Class Initialized
ERROR - 2020-09-20 20:03:35 --> 404 Page Not Found: /index
INFO - 2020-09-20 20:17:44 --> Config Class Initialized
INFO - 2020-09-20 20:17:44 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:17:44 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:17:44 --> Utf8 Class Initialized
INFO - 2020-09-20 20:17:44 --> URI Class Initialized
DEBUG - 2020-09-20 20:17:44 --> No URI present. Default controller set.
INFO - 2020-09-20 20:17:44 --> Router Class Initialized
INFO - 2020-09-20 20:17:44 --> Output Class Initialized
INFO - 2020-09-20 20:17:44 --> Security Class Initialized
DEBUG - 2020-09-20 20:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:17:44 --> Input Class Initialized
INFO - 2020-09-20 20:17:44 --> Language Class Initialized
INFO - 2020-09-20 20:17:44 --> Language Class Initialized
INFO - 2020-09-20 20:17:44 --> Config Class Initialized
INFO - 2020-09-20 20:17:44 --> Loader Class Initialized
INFO - 2020-09-20 20:17:44 --> Helper loaded: url_helper
INFO - 2020-09-20 20:17:44 --> Helper loaded: form_helper
INFO - 2020-09-20 20:17:44 --> Helper loaded: file_helper
INFO - 2020-09-20 20:17:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:17:44 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:17:44 --> Upload Class Initialized
INFO - 2020-09-20 20:17:44 --> Controller Class Initialized
DEBUG - 2020-09-20 20:17:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 20:17:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 20:17:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 20:17:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 20:17:44 --> Final output sent to browser
DEBUG - 2020-09-20 20:17:44 --> Total execution time: 0.0592
INFO - 2020-09-20 20:26:47 --> Config Class Initialized
INFO - 2020-09-20 20:26:47 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:26:47 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:26:47 --> Utf8 Class Initialized
INFO - 2020-09-20 20:26:47 --> URI Class Initialized
DEBUG - 2020-09-20 20:26:47 --> No URI present. Default controller set.
INFO - 2020-09-20 20:26:47 --> Router Class Initialized
INFO - 2020-09-20 20:26:47 --> Output Class Initialized
INFO - 2020-09-20 20:26:47 --> Security Class Initialized
DEBUG - 2020-09-20 20:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:26:47 --> Input Class Initialized
INFO - 2020-09-20 20:26:47 --> Language Class Initialized
INFO - 2020-09-20 20:26:47 --> Language Class Initialized
INFO - 2020-09-20 20:26:47 --> Config Class Initialized
INFO - 2020-09-20 20:26:47 --> Loader Class Initialized
INFO - 2020-09-20 20:26:47 --> Helper loaded: url_helper
INFO - 2020-09-20 20:26:47 --> Helper loaded: form_helper
INFO - 2020-09-20 20:26:47 --> Helper loaded: file_helper
INFO - 2020-09-20 20:26:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:26:47 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:26:47 --> Upload Class Initialized
INFO - 2020-09-20 20:26:47 --> Controller Class Initialized
DEBUG - 2020-09-20 20:26:47 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 20:26:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 20:26:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 20:26:47 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 20:26:47 --> Final output sent to browser
DEBUG - 2020-09-20 20:26:47 --> Total execution time: 0.0521
INFO - 2020-09-20 20:26:53 --> Config Class Initialized
INFO - 2020-09-20 20:26:53 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:26:53 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:26:53 --> Utf8 Class Initialized
INFO - 2020-09-20 20:26:53 --> URI Class Initialized
INFO - 2020-09-20 20:26:53 --> Router Class Initialized
INFO - 2020-09-20 20:26:53 --> Output Class Initialized
INFO - 2020-09-20 20:26:53 --> Security Class Initialized
DEBUG - 2020-09-20 20:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:26:53 --> Input Class Initialized
INFO - 2020-09-20 20:26:53 --> Language Class Initialized
INFO - 2020-09-20 20:26:53 --> Language Class Initialized
INFO - 2020-09-20 20:26:53 --> Config Class Initialized
INFO - 2020-09-20 20:26:53 --> Loader Class Initialized
INFO - 2020-09-20 20:26:53 --> Helper loaded: url_helper
INFO - 2020-09-20 20:26:53 --> Helper loaded: form_helper
INFO - 2020-09-20 20:26:53 --> Helper loaded: file_helper
INFO - 2020-09-20 20:26:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:26:53 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:26:53 --> Upload Class Initialized
INFO - 2020-09-20 20:26:53 --> Controller Class Initialized
ERROR - 2020-09-20 20:26:53 --> 404 Page Not Found: /index
INFO - 2020-09-20 20:27:43 --> Config Class Initialized
INFO - 2020-09-20 20:27:43 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:27:43 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:27:43 --> Utf8 Class Initialized
INFO - 2020-09-20 20:27:43 --> URI Class Initialized
INFO - 2020-09-20 20:27:43 --> Router Class Initialized
INFO - 2020-09-20 20:27:43 --> Output Class Initialized
INFO - 2020-09-20 20:27:43 --> Security Class Initialized
DEBUG - 2020-09-20 20:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:27:43 --> Input Class Initialized
INFO - 2020-09-20 20:27:43 --> Language Class Initialized
INFO - 2020-09-20 20:27:43 --> Language Class Initialized
INFO - 2020-09-20 20:27:43 --> Config Class Initialized
INFO - 2020-09-20 20:27:43 --> Loader Class Initialized
INFO - 2020-09-20 20:27:43 --> Helper loaded: url_helper
INFO - 2020-09-20 20:27:43 --> Helper loaded: form_helper
INFO - 2020-09-20 20:27:43 --> Helper loaded: file_helper
INFO - 2020-09-20 20:27:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:27:43 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:27:43 --> Upload Class Initialized
INFO - 2020-09-20 20:27:43 --> Controller Class Initialized
ERROR - 2020-09-20 20:27:43 --> 404 Page Not Found: /index
INFO - 2020-09-20 20:38:54 --> Config Class Initialized
INFO - 2020-09-20 20:38:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:38:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:38:54 --> Utf8 Class Initialized
INFO - 2020-09-20 20:38:54 --> URI Class Initialized
DEBUG - 2020-09-20 20:38:54 --> No URI present. Default controller set.
INFO - 2020-09-20 20:38:54 --> Router Class Initialized
INFO - 2020-09-20 20:38:54 --> Output Class Initialized
INFO - 2020-09-20 20:38:54 --> Security Class Initialized
DEBUG - 2020-09-20 20:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:38:54 --> Input Class Initialized
INFO - 2020-09-20 20:38:54 --> Language Class Initialized
INFO - 2020-09-20 20:38:54 --> Language Class Initialized
INFO - 2020-09-20 20:38:54 --> Config Class Initialized
INFO - 2020-09-20 20:38:54 --> Loader Class Initialized
INFO - 2020-09-20 20:38:54 --> Helper loaded: url_helper
INFO - 2020-09-20 20:38:54 --> Helper loaded: form_helper
INFO - 2020-09-20 20:38:54 --> Helper loaded: file_helper
INFO - 2020-09-20 20:38:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:38:54 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:38:54 --> Upload Class Initialized
INFO - 2020-09-20 20:38:54 --> Controller Class Initialized
DEBUG - 2020-09-20 20:38:54 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 20:38:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 20:38:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 20:38:54 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 20:38:54 --> Final output sent to browser
DEBUG - 2020-09-20 20:38:54 --> Total execution time: 0.0394
INFO - 2020-09-20 20:51:11 --> Config Class Initialized
INFO - 2020-09-20 20:51:11 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:51:11 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:51:11 --> Utf8 Class Initialized
INFO - 2020-09-20 20:51:11 --> URI Class Initialized
DEBUG - 2020-09-20 20:51:11 --> No URI present. Default controller set.
INFO - 2020-09-20 20:51:11 --> Router Class Initialized
INFO - 2020-09-20 20:51:11 --> Output Class Initialized
INFO - 2020-09-20 20:51:11 --> Security Class Initialized
DEBUG - 2020-09-20 20:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:51:11 --> Input Class Initialized
INFO - 2020-09-20 20:51:11 --> Language Class Initialized
INFO - 2020-09-20 20:51:11 --> Language Class Initialized
INFO - 2020-09-20 20:51:11 --> Config Class Initialized
INFO - 2020-09-20 20:51:11 --> Loader Class Initialized
INFO - 2020-09-20 20:51:11 --> Helper loaded: url_helper
INFO - 2020-09-20 20:51:11 --> Helper loaded: form_helper
INFO - 2020-09-20 20:51:11 --> Helper loaded: file_helper
INFO - 2020-09-20 20:51:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:51:11 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:51:11 --> Upload Class Initialized
INFO - 2020-09-20 20:51:11 --> Controller Class Initialized
DEBUG - 2020-09-20 20:51:11 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 20:51:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 20:51:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 20:51:11 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 20:51:11 --> Final output sent to browser
DEBUG - 2020-09-20 20:51:11 --> Total execution time: 0.0517
INFO - 2020-09-20 20:51:23 --> Config Class Initialized
INFO - 2020-09-20 20:51:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:51:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:51:23 --> Utf8 Class Initialized
INFO - 2020-09-20 20:51:23 --> URI Class Initialized
INFO - 2020-09-20 20:51:23 --> Router Class Initialized
INFO - 2020-09-20 20:51:23 --> Output Class Initialized
INFO - 2020-09-20 20:51:23 --> Security Class Initialized
DEBUG - 2020-09-20 20:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:51:23 --> Input Class Initialized
INFO - 2020-09-20 20:51:23 --> Language Class Initialized
INFO - 2020-09-20 20:51:23 --> Language Class Initialized
INFO - 2020-09-20 20:51:23 --> Config Class Initialized
INFO - 2020-09-20 20:51:23 --> Loader Class Initialized
INFO - 2020-09-20 20:51:23 --> Helper loaded: url_helper
INFO - 2020-09-20 20:51:23 --> Helper loaded: form_helper
INFO - 2020-09-20 20:51:23 --> Helper loaded: file_helper
INFO - 2020-09-20 20:51:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:51:23 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:51:24 --> Upload Class Initialized
INFO - 2020-09-20 20:51:24 --> Controller Class Initialized
ERROR - 2020-09-20 20:51:24 --> 404 Page Not Found: /index
INFO - 2020-09-20 20:56:52 --> Config Class Initialized
INFO - 2020-09-20 20:56:52 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:56:52 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:56:52 --> Utf8 Class Initialized
INFO - 2020-09-20 20:56:52 --> URI Class Initialized
DEBUG - 2020-09-20 20:56:52 --> No URI present. Default controller set.
INFO - 2020-09-20 20:56:52 --> Router Class Initialized
INFO - 2020-09-20 20:56:52 --> Output Class Initialized
INFO - 2020-09-20 20:56:52 --> Security Class Initialized
DEBUG - 2020-09-20 20:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:56:52 --> Input Class Initialized
INFO - 2020-09-20 20:56:52 --> Language Class Initialized
INFO - 2020-09-20 20:56:52 --> Language Class Initialized
INFO - 2020-09-20 20:56:52 --> Config Class Initialized
INFO - 2020-09-20 20:56:52 --> Loader Class Initialized
INFO - 2020-09-20 20:56:52 --> Helper loaded: url_helper
INFO - 2020-09-20 20:56:52 --> Helper loaded: form_helper
INFO - 2020-09-20 20:56:52 --> Helper loaded: file_helper
INFO - 2020-09-20 20:56:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:56:52 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:56:52 --> Upload Class Initialized
INFO - 2020-09-20 20:56:52 --> Controller Class Initialized
DEBUG - 2020-09-20 20:56:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 20:56:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 20:56:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 20:56:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 20:56:52 --> Final output sent to browser
DEBUG - 2020-09-20 20:56:52 --> Total execution time: 0.0568
INFO - 2020-09-20 20:57:42 --> Config Class Initialized
INFO - 2020-09-20 20:57:42 --> Hooks Class Initialized
DEBUG - 2020-09-20 20:57:42 --> UTF-8 Support Enabled
INFO - 2020-09-20 20:57:42 --> Utf8 Class Initialized
INFO - 2020-09-20 20:57:42 --> URI Class Initialized
INFO - 2020-09-20 20:57:42 --> Router Class Initialized
INFO - 2020-09-20 20:57:42 --> Output Class Initialized
INFO - 2020-09-20 20:57:42 --> Security Class Initialized
DEBUG - 2020-09-20 20:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 20:57:42 --> Input Class Initialized
INFO - 2020-09-20 20:57:42 --> Language Class Initialized
INFO - 2020-09-20 20:57:42 --> Language Class Initialized
INFO - 2020-09-20 20:57:42 --> Config Class Initialized
INFO - 2020-09-20 20:57:42 --> Loader Class Initialized
INFO - 2020-09-20 20:57:42 --> Helper loaded: url_helper
INFO - 2020-09-20 20:57:42 --> Helper loaded: form_helper
INFO - 2020-09-20 20:57:42 --> Helper loaded: file_helper
INFO - 2020-09-20 20:57:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 20:57:42 --> Database Driver Class Initialized
DEBUG - 2020-09-20 20:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 20:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 20:57:42 --> Upload Class Initialized
INFO - 2020-09-20 20:57:42 --> Controller Class Initialized
ERROR - 2020-09-20 20:57:42 --> 404 Page Not Found: /index
INFO - 2020-09-20 21:04:41 --> Config Class Initialized
INFO - 2020-09-20 21:04:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 21:04:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 21:04:41 --> Utf8 Class Initialized
INFO - 2020-09-20 21:04:41 --> URI Class Initialized
DEBUG - 2020-09-20 21:04:41 --> No URI present. Default controller set.
INFO - 2020-09-20 21:04:41 --> Router Class Initialized
INFO - 2020-09-20 21:04:41 --> Output Class Initialized
INFO - 2020-09-20 21:04:41 --> Security Class Initialized
DEBUG - 2020-09-20 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 21:04:41 --> Input Class Initialized
INFO - 2020-09-20 21:04:41 --> Language Class Initialized
INFO - 2020-09-20 21:04:41 --> Language Class Initialized
INFO - 2020-09-20 21:04:41 --> Config Class Initialized
INFO - 2020-09-20 21:04:41 --> Loader Class Initialized
INFO - 2020-09-20 21:04:41 --> Helper loaded: url_helper
INFO - 2020-09-20 21:04:41 --> Helper loaded: form_helper
INFO - 2020-09-20 21:04:41 --> Helper loaded: file_helper
INFO - 2020-09-20 21:04:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 21:04:41 --> Database Driver Class Initialized
DEBUG - 2020-09-20 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 21:04:41 --> Upload Class Initialized
INFO - 2020-09-20 21:04:41 --> Controller Class Initialized
DEBUG - 2020-09-20 21:04:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 21:04:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 21:04:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 21:04:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 21:04:41 --> Final output sent to browser
DEBUG - 2020-09-20 21:04:41 --> Total execution time: 0.0495
INFO - 2020-09-20 21:04:45 --> Config Class Initialized
INFO - 2020-09-20 21:04:45 --> Hooks Class Initialized
DEBUG - 2020-09-20 21:04:45 --> UTF-8 Support Enabled
INFO - 2020-09-20 21:04:45 --> Utf8 Class Initialized
INFO - 2020-09-20 21:04:45 --> URI Class Initialized
INFO - 2020-09-20 21:04:45 --> Router Class Initialized
INFO - 2020-09-20 21:04:45 --> Output Class Initialized
INFO - 2020-09-20 21:04:45 --> Security Class Initialized
DEBUG - 2020-09-20 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 21:04:45 --> Input Class Initialized
INFO - 2020-09-20 21:04:45 --> Language Class Initialized
INFO - 2020-09-20 21:04:45 --> Language Class Initialized
INFO - 2020-09-20 21:04:45 --> Config Class Initialized
INFO - 2020-09-20 21:04:45 --> Loader Class Initialized
INFO - 2020-09-20 21:04:45 --> Helper loaded: url_helper
INFO - 2020-09-20 21:04:45 --> Helper loaded: form_helper
INFO - 2020-09-20 21:04:45 --> Helper loaded: file_helper
INFO - 2020-09-20 21:04:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 21:04:45 --> Database Driver Class Initialized
DEBUG - 2020-09-20 21:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 21:04:45 --> Upload Class Initialized
INFO - 2020-09-20 21:04:45 --> Controller Class Initialized
ERROR - 2020-09-20 21:04:45 --> 404 Page Not Found: /index
INFO - 2020-09-20 21:28:54 --> Config Class Initialized
INFO - 2020-09-20 21:28:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 21:28:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 21:28:54 --> Utf8 Class Initialized
INFO - 2020-09-20 21:28:54 --> URI Class Initialized
INFO - 2020-09-20 21:28:54 --> Router Class Initialized
INFO - 2020-09-20 21:28:54 --> Output Class Initialized
INFO - 2020-09-20 21:28:54 --> Security Class Initialized
DEBUG - 2020-09-20 21:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 21:28:54 --> Input Class Initialized
INFO - 2020-09-20 21:28:54 --> Language Class Initialized
INFO - 2020-09-20 21:28:54 --> Language Class Initialized
INFO - 2020-09-20 21:28:54 --> Config Class Initialized
INFO - 2020-09-20 21:28:54 --> Loader Class Initialized
INFO - 2020-09-20 21:28:54 --> Helper loaded: url_helper
INFO - 2020-09-20 21:28:54 --> Helper loaded: form_helper
INFO - 2020-09-20 21:28:54 --> Helper loaded: file_helper
INFO - 2020-09-20 21:28:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 21:28:54 --> Database Driver Class Initialized
DEBUG - 2020-09-20 21:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 21:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 21:28:54 --> Upload Class Initialized
INFO - 2020-09-20 21:28:54 --> Controller Class Initialized
ERROR - 2020-09-20 21:28:54 --> 404 Page Not Found: /index
INFO - 2020-09-20 21:41:17 --> Config Class Initialized
INFO - 2020-09-20 21:41:17 --> Hooks Class Initialized
DEBUG - 2020-09-20 21:41:17 --> UTF-8 Support Enabled
INFO - 2020-09-20 21:41:17 --> Utf8 Class Initialized
INFO - 2020-09-20 21:41:17 --> URI Class Initialized
INFO - 2020-09-20 21:41:17 --> Router Class Initialized
INFO - 2020-09-20 21:41:17 --> Output Class Initialized
INFO - 2020-09-20 21:41:17 --> Security Class Initialized
DEBUG - 2020-09-20 21:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 21:41:17 --> Input Class Initialized
INFO - 2020-09-20 21:41:17 --> Language Class Initialized
INFO - 2020-09-20 21:41:17 --> Language Class Initialized
INFO - 2020-09-20 21:41:17 --> Config Class Initialized
INFO - 2020-09-20 21:41:17 --> Loader Class Initialized
INFO - 2020-09-20 21:41:17 --> Helper loaded: url_helper
INFO - 2020-09-20 21:41:17 --> Helper loaded: form_helper
INFO - 2020-09-20 21:41:17 --> Helper loaded: file_helper
INFO - 2020-09-20 21:41:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 21:41:17 --> Database Driver Class Initialized
DEBUG - 2020-09-20 21:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 21:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 21:41:17 --> Upload Class Initialized
INFO - 2020-09-20 21:41:17 --> Controller Class Initialized
DEBUG - 2020-09-20 21:41:17 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 21:41:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/points_system.php
DEBUG - 2020-09-20 21:41:17 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 21:41:17 --> Final output sent to browser
DEBUG - 2020-09-20 21:41:17 --> Total execution time: 0.0429
INFO - 2020-09-20 21:41:26 --> Config Class Initialized
INFO - 2020-09-20 21:41:26 --> Hooks Class Initialized
DEBUG - 2020-09-20 21:41:26 --> UTF-8 Support Enabled
INFO - 2020-09-20 21:41:26 --> Utf8 Class Initialized
INFO - 2020-09-20 21:41:26 --> URI Class Initialized
INFO - 2020-09-20 21:41:26 --> Router Class Initialized
INFO - 2020-09-20 21:41:26 --> Output Class Initialized
INFO - 2020-09-20 21:41:26 --> Security Class Initialized
DEBUG - 2020-09-20 21:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 21:41:26 --> Input Class Initialized
INFO - 2020-09-20 21:41:26 --> Language Class Initialized
INFO - 2020-09-20 21:41:26 --> Language Class Initialized
INFO - 2020-09-20 21:41:26 --> Config Class Initialized
INFO - 2020-09-20 21:41:26 --> Loader Class Initialized
INFO - 2020-09-20 21:41:26 --> Helper loaded: url_helper
INFO - 2020-09-20 21:41:27 --> Helper loaded: form_helper
INFO - 2020-09-20 21:41:27 --> Helper loaded: file_helper
INFO - 2020-09-20 21:41:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 21:41:27 --> Database Driver Class Initialized
DEBUG - 2020-09-20 21:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 21:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 21:41:27 --> Upload Class Initialized
INFO - 2020-09-20 21:41:27 --> Controller Class Initialized
ERROR - 2020-09-20 21:41:27 --> 404 Page Not Found: /index
INFO - 2020-09-20 21:51:17 --> Config Class Initialized
INFO - 2020-09-20 21:51:17 --> Hooks Class Initialized
DEBUG - 2020-09-20 21:51:17 --> UTF-8 Support Enabled
INFO - 2020-09-20 21:51:17 --> Utf8 Class Initialized
INFO - 2020-09-20 21:51:17 --> URI Class Initialized
INFO - 2020-09-20 21:51:17 --> Router Class Initialized
INFO - 2020-09-20 21:51:17 --> Output Class Initialized
INFO - 2020-09-20 21:51:17 --> Security Class Initialized
DEBUG - 2020-09-20 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 21:51:17 --> Input Class Initialized
INFO - 2020-09-20 21:51:17 --> Language Class Initialized
INFO - 2020-09-20 21:51:17 --> Language Class Initialized
INFO - 2020-09-20 21:51:17 --> Config Class Initialized
INFO - 2020-09-20 21:51:17 --> Loader Class Initialized
INFO - 2020-09-20 21:51:17 --> Helper loaded: url_helper
INFO - 2020-09-20 21:51:17 --> Helper loaded: form_helper
INFO - 2020-09-20 21:51:17 --> Helper loaded: file_helper
INFO - 2020-09-20 21:51:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 21:51:17 --> Database Driver Class Initialized
DEBUG - 2020-09-20 21:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 21:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 21:51:17 --> Upload Class Initialized
INFO - 2020-09-20 21:51:17 --> Controller Class Initialized
ERROR - 2020-09-20 21:51:17 --> 404 Page Not Found: /index
INFO - 2020-09-20 22:30:38 --> Config Class Initialized
INFO - 2020-09-20 22:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-20 22:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-20 22:30:38 --> Utf8 Class Initialized
INFO - 2020-09-20 22:30:38 --> URI Class Initialized
DEBUG - 2020-09-20 22:30:38 --> No URI present. Default controller set.
INFO - 2020-09-20 22:30:38 --> Router Class Initialized
INFO - 2020-09-20 22:30:38 --> Output Class Initialized
INFO - 2020-09-20 22:30:38 --> Security Class Initialized
DEBUG - 2020-09-20 22:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 22:30:38 --> Input Class Initialized
INFO - 2020-09-20 22:30:38 --> Language Class Initialized
INFO - 2020-09-20 22:30:38 --> Language Class Initialized
INFO - 2020-09-20 22:30:38 --> Config Class Initialized
INFO - 2020-09-20 22:30:38 --> Loader Class Initialized
INFO - 2020-09-20 22:30:38 --> Helper loaded: url_helper
INFO - 2020-09-20 22:30:38 --> Helper loaded: form_helper
INFO - 2020-09-20 22:30:38 --> Helper loaded: file_helper
INFO - 2020-09-20 22:30:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 22:30:38 --> Database Driver Class Initialized
DEBUG - 2020-09-20 22:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 22:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 22:30:38 --> Upload Class Initialized
INFO - 2020-09-20 22:30:38 --> Controller Class Initialized
DEBUG - 2020-09-20 22:30:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 22:30:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 22:30:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 22:30:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 22:30:38 --> Final output sent to browser
DEBUG - 2020-09-20 22:30:38 --> Total execution time: 0.0476
INFO - 2020-09-20 22:43:08 --> Config Class Initialized
INFO - 2020-09-20 22:43:08 --> Hooks Class Initialized
DEBUG - 2020-09-20 22:43:08 --> UTF-8 Support Enabled
INFO - 2020-09-20 22:43:08 --> Utf8 Class Initialized
INFO - 2020-09-20 22:43:08 --> URI Class Initialized
DEBUG - 2020-09-20 22:43:09 --> No URI present. Default controller set.
INFO - 2020-09-20 22:43:09 --> Router Class Initialized
INFO - 2020-09-20 22:43:09 --> Output Class Initialized
INFO - 2020-09-20 22:43:09 --> Security Class Initialized
DEBUG - 2020-09-20 22:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 22:43:09 --> Input Class Initialized
INFO - 2020-09-20 22:43:09 --> Language Class Initialized
INFO - 2020-09-20 22:43:09 --> Language Class Initialized
INFO - 2020-09-20 22:43:09 --> Config Class Initialized
INFO - 2020-09-20 22:43:09 --> Loader Class Initialized
INFO - 2020-09-20 22:43:09 --> Helper loaded: url_helper
INFO - 2020-09-20 22:43:09 --> Helper loaded: form_helper
INFO - 2020-09-20 22:43:09 --> Helper loaded: file_helper
INFO - 2020-09-20 22:43:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 22:43:09 --> Database Driver Class Initialized
DEBUG - 2020-09-20 22:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 22:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 22:43:09 --> Upload Class Initialized
INFO - 2020-09-20 22:43:09 --> Controller Class Initialized
DEBUG - 2020-09-20 22:43:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 22:43:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 22:43:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 22:43:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 22:43:09 --> Final output sent to browser
DEBUG - 2020-09-20 22:43:09 --> Total execution time: 0.0519
INFO - 2020-09-20 23:34:46 --> Config Class Initialized
INFO - 2020-09-20 23:34:46 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:46 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:46 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:46 --> URI Class Initialized
INFO - 2020-09-20 23:34:46 --> Router Class Initialized
INFO - 2020-09-20 23:34:46 --> Output Class Initialized
INFO - 2020-09-20 23:34:46 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:46 --> Input Class Initialized
INFO - 2020-09-20 23:34:46 --> Language Class Initialized
INFO - 2020-09-20 23:34:46 --> Language Class Initialized
INFO - 2020-09-20 23:34:46 --> Config Class Initialized
INFO - 2020-09-20 23:34:46 --> Loader Class Initialized
INFO - 2020-09-20 23:34:46 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:46 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:46 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:46 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:46 --> Upload Class Initialized
INFO - 2020-09-20 23:34:46 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:46 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:34:48 --> Config Class Initialized
INFO - 2020-09-20 23:34:48 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:48 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:48 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:48 --> URI Class Initialized
INFO - 2020-09-20 23:34:48 --> Router Class Initialized
INFO - 2020-09-20 23:34:48 --> Output Class Initialized
INFO - 2020-09-20 23:34:48 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:48 --> Input Class Initialized
INFO - 2020-09-20 23:34:48 --> Language Class Initialized
INFO - 2020-09-20 23:34:48 --> Language Class Initialized
INFO - 2020-09-20 23:34:48 --> Config Class Initialized
INFO - 2020-09-20 23:34:48 --> Loader Class Initialized
INFO - 2020-09-20 23:34:48 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:48 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:48 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:48 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:48 --> Upload Class Initialized
INFO - 2020-09-20 23:34:48 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:48 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:34:50 --> Config Class Initialized
INFO - 2020-09-20 23:34:50 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:50 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:50 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:50 --> URI Class Initialized
INFO - 2020-09-20 23:34:50 --> Router Class Initialized
INFO - 2020-09-20 23:34:50 --> Output Class Initialized
INFO - 2020-09-20 23:34:50 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:50 --> Input Class Initialized
INFO - 2020-09-20 23:34:50 --> Language Class Initialized
INFO - 2020-09-20 23:34:50 --> Language Class Initialized
INFO - 2020-09-20 23:34:50 --> Config Class Initialized
INFO - 2020-09-20 23:34:50 --> Loader Class Initialized
INFO - 2020-09-20 23:34:50 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:50 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:50 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:50 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:50 --> Upload Class Initialized
INFO - 2020-09-20 23:34:50 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:50 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:34:52 --> Config Class Initialized
INFO - 2020-09-20 23:34:52 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:52 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:52 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:52 --> URI Class Initialized
INFO - 2020-09-20 23:34:52 --> Router Class Initialized
INFO - 2020-09-20 23:34:52 --> Output Class Initialized
INFO - 2020-09-20 23:34:52 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:52 --> Input Class Initialized
INFO - 2020-09-20 23:34:52 --> Language Class Initialized
INFO - 2020-09-20 23:34:52 --> Language Class Initialized
INFO - 2020-09-20 23:34:52 --> Config Class Initialized
INFO - 2020-09-20 23:34:52 --> Loader Class Initialized
INFO - 2020-09-20 23:34:52 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:52 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:52 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:52 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:52 --> Upload Class Initialized
INFO - 2020-09-20 23:34:52 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:52 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:34:54 --> Config Class Initialized
INFO - 2020-09-20 23:34:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:54 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:54 --> URI Class Initialized
INFO - 2020-09-20 23:34:54 --> Router Class Initialized
INFO - 2020-09-20 23:34:54 --> Output Class Initialized
INFO - 2020-09-20 23:34:54 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:54 --> Input Class Initialized
INFO - 2020-09-20 23:34:54 --> Language Class Initialized
INFO - 2020-09-20 23:34:54 --> Language Class Initialized
INFO - 2020-09-20 23:34:54 --> Config Class Initialized
INFO - 2020-09-20 23:34:54 --> Loader Class Initialized
INFO - 2020-09-20 23:34:54 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:54 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:54 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:54 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:54 --> Upload Class Initialized
INFO - 2020-09-20 23:34:54 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:54 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:34:56 --> Config Class Initialized
INFO - 2020-09-20 23:34:56 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:56 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:56 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:56 --> URI Class Initialized
INFO - 2020-09-20 23:34:56 --> Router Class Initialized
INFO - 2020-09-20 23:34:56 --> Output Class Initialized
INFO - 2020-09-20 23:34:56 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:56 --> Input Class Initialized
INFO - 2020-09-20 23:34:56 --> Language Class Initialized
INFO - 2020-09-20 23:34:56 --> Language Class Initialized
INFO - 2020-09-20 23:34:56 --> Config Class Initialized
INFO - 2020-09-20 23:34:56 --> Loader Class Initialized
INFO - 2020-09-20 23:34:56 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:56 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:56 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:56 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:56 --> Upload Class Initialized
INFO - 2020-09-20 23:34:56 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:56 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:34:58 --> Config Class Initialized
INFO - 2020-09-20 23:34:58 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:34:58 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:34:58 --> Utf8 Class Initialized
INFO - 2020-09-20 23:34:58 --> URI Class Initialized
INFO - 2020-09-20 23:34:58 --> Router Class Initialized
INFO - 2020-09-20 23:34:58 --> Output Class Initialized
INFO - 2020-09-20 23:34:58 --> Security Class Initialized
DEBUG - 2020-09-20 23:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:34:58 --> Input Class Initialized
INFO - 2020-09-20 23:34:58 --> Language Class Initialized
INFO - 2020-09-20 23:34:58 --> Language Class Initialized
INFO - 2020-09-20 23:34:58 --> Config Class Initialized
INFO - 2020-09-20 23:34:58 --> Loader Class Initialized
INFO - 2020-09-20 23:34:58 --> Helper loaded: url_helper
INFO - 2020-09-20 23:34:58 --> Helper loaded: form_helper
INFO - 2020-09-20 23:34:58 --> Helper loaded: file_helper
INFO - 2020-09-20 23:34:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:34:58 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:34:58 --> Upload Class Initialized
INFO - 2020-09-20 23:34:58 --> Controller Class Initialized
ERROR - 2020-09-20 23:34:58 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:00 --> Config Class Initialized
INFO - 2020-09-20 23:35:00 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:00 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:00 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:00 --> URI Class Initialized
INFO - 2020-09-20 23:35:00 --> Router Class Initialized
INFO - 2020-09-20 23:35:00 --> Output Class Initialized
INFO - 2020-09-20 23:35:00 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:00 --> Input Class Initialized
INFO - 2020-09-20 23:35:00 --> Language Class Initialized
INFO - 2020-09-20 23:35:00 --> Language Class Initialized
INFO - 2020-09-20 23:35:00 --> Config Class Initialized
INFO - 2020-09-20 23:35:00 --> Loader Class Initialized
INFO - 2020-09-20 23:35:00 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:00 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:00 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:00 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:00 --> Upload Class Initialized
INFO - 2020-09-20 23:35:00 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:00 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:02 --> Config Class Initialized
INFO - 2020-09-20 23:35:02 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:02 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:02 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:02 --> URI Class Initialized
INFO - 2020-09-20 23:35:02 --> Router Class Initialized
INFO - 2020-09-20 23:35:02 --> Output Class Initialized
INFO - 2020-09-20 23:35:02 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:02 --> Input Class Initialized
INFO - 2020-09-20 23:35:02 --> Language Class Initialized
INFO - 2020-09-20 23:35:02 --> Language Class Initialized
INFO - 2020-09-20 23:35:02 --> Config Class Initialized
INFO - 2020-09-20 23:35:02 --> Loader Class Initialized
INFO - 2020-09-20 23:35:02 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:02 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:02 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:02 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:02 --> Upload Class Initialized
INFO - 2020-09-20 23:35:02 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:02 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:13 --> Config Class Initialized
INFO - 2020-09-20 23:35:13 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:13 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:13 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:13 --> URI Class Initialized
INFO - 2020-09-20 23:35:13 --> Router Class Initialized
INFO - 2020-09-20 23:35:13 --> Output Class Initialized
INFO - 2020-09-20 23:35:13 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:13 --> Input Class Initialized
INFO - 2020-09-20 23:35:13 --> Language Class Initialized
INFO - 2020-09-20 23:35:13 --> Language Class Initialized
INFO - 2020-09-20 23:35:13 --> Config Class Initialized
INFO - 2020-09-20 23:35:13 --> Loader Class Initialized
INFO - 2020-09-20 23:35:13 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:13 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:13 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:13 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:13 --> Upload Class Initialized
INFO - 2020-09-20 23:35:13 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:13 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:16 --> Config Class Initialized
INFO - 2020-09-20 23:35:16 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:16 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:16 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:16 --> URI Class Initialized
INFO - 2020-09-20 23:35:16 --> Router Class Initialized
INFO - 2020-09-20 23:35:16 --> Output Class Initialized
INFO - 2020-09-20 23:35:16 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:16 --> Input Class Initialized
INFO - 2020-09-20 23:35:16 --> Language Class Initialized
INFO - 2020-09-20 23:35:16 --> Language Class Initialized
INFO - 2020-09-20 23:35:16 --> Config Class Initialized
INFO - 2020-09-20 23:35:16 --> Loader Class Initialized
INFO - 2020-09-20 23:35:16 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:16 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:16 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:16 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:16 --> Upload Class Initialized
INFO - 2020-09-20 23:35:16 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:16 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:18 --> Config Class Initialized
INFO - 2020-09-20 23:35:18 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:18 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:18 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:18 --> URI Class Initialized
INFO - 2020-09-20 23:35:18 --> Router Class Initialized
INFO - 2020-09-20 23:35:18 --> Output Class Initialized
INFO - 2020-09-20 23:35:18 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:18 --> Input Class Initialized
INFO - 2020-09-20 23:35:18 --> Language Class Initialized
INFO - 2020-09-20 23:35:18 --> Language Class Initialized
INFO - 2020-09-20 23:35:18 --> Config Class Initialized
INFO - 2020-09-20 23:35:18 --> Loader Class Initialized
INFO - 2020-09-20 23:35:18 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:18 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:18 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:18 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:18 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:18 --> Upload Class Initialized
INFO - 2020-09-20 23:35:18 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:18 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:22 --> Config Class Initialized
INFO - 2020-09-20 23:35:22 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:22 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:22 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:22 --> URI Class Initialized
INFO - 2020-09-20 23:35:22 --> Router Class Initialized
INFO - 2020-09-20 23:35:22 --> Output Class Initialized
INFO - 2020-09-20 23:35:22 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:22 --> Input Class Initialized
INFO - 2020-09-20 23:35:22 --> Language Class Initialized
INFO - 2020-09-20 23:35:22 --> Language Class Initialized
INFO - 2020-09-20 23:35:22 --> Config Class Initialized
INFO - 2020-09-20 23:35:22 --> Loader Class Initialized
INFO - 2020-09-20 23:35:22 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:22 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:22 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:22 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:22 --> Upload Class Initialized
INFO - 2020-09-20 23:35:22 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:22 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:34 --> Config Class Initialized
INFO - 2020-09-20 23:35:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:34 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:34 --> URI Class Initialized
INFO - 2020-09-20 23:35:34 --> Router Class Initialized
INFO - 2020-09-20 23:35:34 --> Output Class Initialized
INFO - 2020-09-20 23:35:34 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:34 --> Input Class Initialized
INFO - 2020-09-20 23:35:34 --> Language Class Initialized
INFO - 2020-09-20 23:35:34 --> Language Class Initialized
INFO - 2020-09-20 23:35:34 --> Config Class Initialized
INFO - 2020-09-20 23:35:34 --> Loader Class Initialized
INFO - 2020-09-20 23:35:34 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:34 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:34 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:34 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:34 --> Upload Class Initialized
INFO - 2020-09-20 23:35:34 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:34 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:36 --> Config Class Initialized
INFO - 2020-09-20 23:35:36 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:36 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:36 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:36 --> URI Class Initialized
INFO - 2020-09-20 23:35:36 --> Router Class Initialized
INFO - 2020-09-20 23:35:36 --> Output Class Initialized
INFO - 2020-09-20 23:35:36 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:36 --> Input Class Initialized
INFO - 2020-09-20 23:35:36 --> Language Class Initialized
INFO - 2020-09-20 23:35:36 --> Language Class Initialized
INFO - 2020-09-20 23:35:36 --> Config Class Initialized
INFO - 2020-09-20 23:35:36 --> Loader Class Initialized
INFO - 2020-09-20 23:35:36 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:36 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:36 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:36 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:36 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:36 --> Upload Class Initialized
INFO - 2020-09-20 23:35:36 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:36 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:38 --> Config Class Initialized
INFO - 2020-09-20 23:35:38 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:38 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:38 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:38 --> URI Class Initialized
INFO - 2020-09-20 23:35:38 --> Router Class Initialized
INFO - 2020-09-20 23:35:38 --> Output Class Initialized
INFO - 2020-09-20 23:35:38 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:38 --> Input Class Initialized
INFO - 2020-09-20 23:35:38 --> Language Class Initialized
INFO - 2020-09-20 23:35:38 --> Language Class Initialized
INFO - 2020-09-20 23:35:38 --> Config Class Initialized
INFO - 2020-09-20 23:35:38 --> Loader Class Initialized
INFO - 2020-09-20 23:35:38 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:38 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:38 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:38 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:38 --> Upload Class Initialized
INFO - 2020-09-20 23:35:38 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:38 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:40 --> Config Class Initialized
INFO - 2020-09-20 23:35:40 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:40 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:40 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:40 --> URI Class Initialized
INFO - 2020-09-20 23:35:40 --> Router Class Initialized
INFO - 2020-09-20 23:35:40 --> Output Class Initialized
INFO - 2020-09-20 23:35:40 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:40 --> Input Class Initialized
INFO - 2020-09-20 23:35:40 --> Language Class Initialized
INFO - 2020-09-20 23:35:40 --> Language Class Initialized
INFO - 2020-09-20 23:35:40 --> Config Class Initialized
INFO - 2020-09-20 23:35:40 --> Loader Class Initialized
INFO - 2020-09-20 23:35:40 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:40 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:40 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:40 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:40 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:40 --> Upload Class Initialized
INFO - 2020-09-20 23:35:40 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:40 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:46 --> Config Class Initialized
INFO - 2020-09-20 23:35:46 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:46 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:46 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:46 --> URI Class Initialized
INFO - 2020-09-20 23:35:46 --> Router Class Initialized
INFO - 2020-09-20 23:35:46 --> Output Class Initialized
INFO - 2020-09-20 23:35:46 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:46 --> Input Class Initialized
INFO - 2020-09-20 23:35:46 --> Language Class Initialized
INFO - 2020-09-20 23:35:46 --> Language Class Initialized
INFO - 2020-09-20 23:35:46 --> Config Class Initialized
INFO - 2020-09-20 23:35:46 --> Loader Class Initialized
INFO - 2020-09-20 23:35:46 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:46 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:46 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:46 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:46 --> Upload Class Initialized
INFO - 2020-09-20 23:35:46 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:46 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:49 --> Config Class Initialized
INFO - 2020-09-20 23:35:49 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:49 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:49 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:49 --> URI Class Initialized
INFO - 2020-09-20 23:35:49 --> Router Class Initialized
INFO - 2020-09-20 23:35:49 --> Output Class Initialized
INFO - 2020-09-20 23:35:49 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:49 --> Input Class Initialized
INFO - 2020-09-20 23:35:49 --> Language Class Initialized
INFO - 2020-09-20 23:35:49 --> Language Class Initialized
INFO - 2020-09-20 23:35:49 --> Config Class Initialized
INFO - 2020-09-20 23:35:49 --> Loader Class Initialized
INFO - 2020-09-20 23:35:49 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:49 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:49 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:49 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:49 --> Upload Class Initialized
INFO - 2020-09-20 23:35:49 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:49 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:35:55 --> Config Class Initialized
INFO - 2020-09-20 23:35:55 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:35:55 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:35:55 --> Utf8 Class Initialized
INFO - 2020-09-20 23:35:55 --> URI Class Initialized
INFO - 2020-09-20 23:35:55 --> Router Class Initialized
INFO - 2020-09-20 23:35:55 --> Output Class Initialized
INFO - 2020-09-20 23:35:55 --> Security Class Initialized
DEBUG - 2020-09-20 23:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:35:55 --> Input Class Initialized
INFO - 2020-09-20 23:35:55 --> Language Class Initialized
INFO - 2020-09-20 23:35:55 --> Language Class Initialized
INFO - 2020-09-20 23:35:55 --> Config Class Initialized
INFO - 2020-09-20 23:35:55 --> Loader Class Initialized
INFO - 2020-09-20 23:35:55 --> Helper loaded: url_helper
INFO - 2020-09-20 23:35:55 --> Helper loaded: form_helper
INFO - 2020-09-20 23:35:55 --> Helper loaded: file_helper
INFO - 2020-09-20 23:35:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:35:55 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:35:55 --> Upload Class Initialized
INFO - 2020-09-20 23:35:55 --> Controller Class Initialized
ERROR - 2020-09-20 23:35:55 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:36:01 --> Config Class Initialized
INFO - 2020-09-20 23:36:01 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:36:01 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:36:01 --> Utf8 Class Initialized
INFO - 2020-09-20 23:36:01 --> URI Class Initialized
INFO - 2020-09-20 23:36:01 --> Router Class Initialized
INFO - 2020-09-20 23:36:01 --> Output Class Initialized
INFO - 2020-09-20 23:36:01 --> Security Class Initialized
DEBUG - 2020-09-20 23:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:36:01 --> Input Class Initialized
INFO - 2020-09-20 23:36:01 --> Language Class Initialized
INFO - 2020-09-20 23:36:01 --> Language Class Initialized
INFO - 2020-09-20 23:36:01 --> Config Class Initialized
INFO - 2020-09-20 23:36:01 --> Loader Class Initialized
INFO - 2020-09-20 23:36:01 --> Helper loaded: url_helper
INFO - 2020-09-20 23:36:01 --> Helper loaded: form_helper
INFO - 2020-09-20 23:36:01 --> Helper loaded: file_helper
INFO - 2020-09-20 23:36:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:36:01 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:36:01 --> Upload Class Initialized
INFO - 2020-09-20 23:36:01 --> Controller Class Initialized
ERROR - 2020-09-20 23:36:01 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:43:28 --> Config Class Initialized
INFO - 2020-09-20 23:43:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:43:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:43:28 --> Utf8 Class Initialized
INFO - 2020-09-20 23:43:28 --> URI Class Initialized
DEBUG - 2020-09-20 23:43:28 --> No URI present. Default controller set.
INFO - 2020-09-20 23:43:28 --> Router Class Initialized
INFO - 2020-09-20 23:43:28 --> Output Class Initialized
INFO - 2020-09-20 23:43:28 --> Security Class Initialized
DEBUG - 2020-09-20 23:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:43:28 --> Input Class Initialized
INFO - 2020-09-20 23:43:28 --> Language Class Initialized
INFO - 2020-09-20 23:43:28 --> Language Class Initialized
INFO - 2020-09-20 23:43:28 --> Config Class Initialized
INFO - 2020-09-20 23:43:28 --> Loader Class Initialized
INFO - 2020-09-20 23:43:28 --> Helper loaded: url_helper
INFO - 2020-09-20 23:43:28 --> Helper loaded: form_helper
INFO - 2020-09-20 23:43:28 --> Helper loaded: file_helper
INFO - 2020-09-20 23:43:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:43:28 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:43:28 --> Upload Class Initialized
INFO - 2020-09-20 23:43:28 --> Controller Class Initialized
DEBUG - 2020-09-20 23:43:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-20 23:43:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-20 23:43:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-20 23:43:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-20 23:43:28 --> Final output sent to browser
DEBUG - 2020-09-20 23:43:28 --> Total execution time: 0.0705
INFO - 2020-09-20 23:59:15 --> Config Class Initialized
INFO - 2020-09-20 23:59:15 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:59:15 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:59:15 --> Utf8 Class Initialized
INFO - 2020-09-20 23:59:15 --> URI Class Initialized
INFO - 2020-09-20 23:59:15 --> Router Class Initialized
INFO - 2020-09-20 23:59:15 --> Output Class Initialized
INFO - 2020-09-20 23:59:15 --> Security Class Initialized
DEBUG - 2020-09-20 23:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:59:15 --> Input Class Initialized
INFO - 2020-09-20 23:59:15 --> Language Class Initialized
INFO - 2020-09-20 23:59:15 --> Language Class Initialized
INFO - 2020-09-20 23:59:15 --> Config Class Initialized
INFO - 2020-09-20 23:59:15 --> Loader Class Initialized
INFO - 2020-09-20 23:59:15 --> Helper loaded: url_helper
INFO - 2020-09-20 23:59:15 --> Helper loaded: form_helper
INFO - 2020-09-20 23:59:15 --> Helper loaded: file_helper
INFO - 2020-09-20 23:59:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:59:15 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:59:15 --> Upload Class Initialized
INFO - 2020-09-20 23:59:15 --> Controller Class Initialized
ERROR - 2020-09-20 23:59:15 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:59:51 --> Config Class Initialized
INFO - 2020-09-20 23:59:51 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:59:51 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:59:51 --> Utf8 Class Initialized
INFO - 2020-09-20 23:59:51 --> URI Class Initialized
INFO - 2020-09-20 23:59:51 --> Router Class Initialized
INFO - 2020-09-20 23:59:51 --> Output Class Initialized
INFO - 2020-09-20 23:59:51 --> Security Class Initialized
DEBUG - 2020-09-20 23:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:59:51 --> Input Class Initialized
INFO - 2020-09-20 23:59:51 --> Language Class Initialized
INFO - 2020-09-20 23:59:51 --> Language Class Initialized
INFO - 2020-09-20 23:59:51 --> Config Class Initialized
INFO - 2020-09-20 23:59:51 --> Loader Class Initialized
INFO - 2020-09-20 23:59:51 --> Helper loaded: url_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: form_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: file_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:59:51 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:59:51 --> Upload Class Initialized
INFO - 2020-09-20 23:59:51 --> Controller Class Initialized
ERROR - 2020-09-20 23:59:51 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:59:51 --> Config Class Initialized
INFO - 2020-09-20 23:59:51 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:59:51 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:59:51 --> Utf8 Class Initialized
INFO - 2020-09-20 23:59:51 --> URI Class Initialized
INFO - 2020-09-20 23:59:51 --> Router Class Initialized
INFO - 2020-09-20 23:59:51 --> Output Class Initialized
INFO - 2020-09-20 23:59:51 --> Security Class Initialized
DEBUG - 2020-09-20 23:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:59:51 --> Input Class Initialized
INFO - 2020-09-20 23:59:51 --> Language Class Initialized
INFO - 2020-09-20 23:59:51 --> Language Class Initialized
INFO - 2020-09-20 23:59:51 --> Config Class Initialized
INFO - 2020-09-20 23:59:51 --> Loader Class Initialized
INFO - 2020-09-20 23:59:51 --> Helper loaded: url_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: form_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: file_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:59:51 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:59:51 --> Upload Class Initialized
INFO - 2020-09-20 23:59:51 --> Controller Class Initialized
ERROR - 2020-09-20 23:59:51 --> 404 Page Not Found: /index
INFO - 2020-09-20 23:59:51 --> Config Class Initialized
INFO - 2020-09-20 23:59:51 --> Hooks Class Initialized
DEBUG - 2020-09-20 23:59:51 --> UTF-8 Support Enabled
INFO - 2020-09-20 23:59:51 --> Utf8 Class Initialized
INFO - 2020-09-20 23:59:51 --> URI Class Initialized
INFO - 2020-09-20 23:59:51 --> Router Class Initialized
INFO - 2020-09-20 23:59:51 --> Output Class Initialized
INFO - 2020-09-20 23:59:51 --> Security Class Initialized
DEBUG - 2020-09-20 23:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 23:59:51 --> Input Class Initialized
INFO - 2020-09-20 23:59:51 --> Language Class Initialized
INFO - 2020-09-20 23:59:51 --> Language Class Initialized
INFO - 2020-09-20 23:59:51 --> Config Class Initialized
INFO - 2020-09-20 23:59:51 --> Loader Class Initialized
INFO - 2020-09-20 23:59:51 --> Helper loaded: url_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: form_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: file_helper
INFO - 2020-09-20 23:59:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-20 23:59:51 --> Database Driver Class Initialized
DEBUG - 2020-09-20 23:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-20 23:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 23:59:51 --> Upload Class Initialized
INFO - 2020-09-20 23:59:51 --> Controller Class Initialized
ERROR - 2020-09-20 23:59:51 --> 404 Page Not Found: /index
