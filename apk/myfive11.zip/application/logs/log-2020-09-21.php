<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-21 00:10:03 --> Config Class Initialized
INFO - 2020-09-21 00:10:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 00:10:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 00:10:03 --> Utf8 Class Initialized
INFO - 2020-09-21 00:10:03 --> URI Class Initialized
DEBUG - 2020-09-21 00:10:03 --> No URI present. Default controller set.
INFO - 2020-09-21 00:10:03 --> Router Class Initialized
INFO - 2020-09-21 00:10:03 --> Output Class Initialized
INFO - 2020-09-21 00:10:03 --> Security Class Initialized
DEBUG - 2020-09-21 00:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 00:10:03 --> Input Class Initialized
INFO - 2020-09-21 00:10:03 --> Language Class Initialized
INFO - 2020-09-21 00:10:03 --> Language Class Initialized
INFO - 2020-09-21 00:10:03 --> Config Class Initialized
INFO - 2020-09-21 00:10:03 --> Loader Class Initialized
INFO - 2020-09-21 00:10:03 --> Helper loaded: url_helper
INFO - 2020-09-21 00:10:03 --> Helper loaded: form_helper
INFO - 2020-09-21 00:10:03 --> Helper loaded: file_helper
INFO - 2020-09-21 00:10:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 00:10:03 --> Database Driver Class Initialized
DEBUG - 2020-09-21 00:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 00:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 00:10:03 --> Upload Class Initialized
INFO - 2020-09-21 00:10:03 --> Controller Class Initialized
DEBUG - 2020-09-21 00:10:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 00:10:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 00:10:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 00:10:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 00:10:03 --> Final output sent to browser
DEBUG - 2020-09-21 00:10:03 --> Total execution time: 0.0548
INFO - 2020-09-21 00:10:13 --> Config Class Initialized
INFO - 2020-09-21 00:10:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 00:10:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 00:10:13 --> Utf8 Class Initialized
INFO - 2020-09-21 00:10:13 --> URI Class Initialized
INFO - 2020-09-21 00:10:13 --> Router Class Initialized
INFO - 2020-09-21 00:10:13 --> Output Class Initialized
INFO - 2020-09-21 00:10:13 --> Security Class Initialized
DEBUG - 2020-09-21 00:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 00:10:13 --> Input Class Initialized
INFO - 2020-09-21 00:10:13 --> Language Class Initialized
INFO - 2020-09-21 00:10:13 --> Language Class Initialized
INFO - 2020-09-21 00:10:13 --> Config Class Initialized
INFO - 2020-09-21 00:10:13 --> Loader Class Initialized
INFO - 2020-09-21 00:10:13 --> Helper loaded: url_helper
INFO - 2020-09-21 00:10:13 --> Helper loaded: form_helper
INFO - 2020-09-21 00:10:13 --> Helper loaded: file_helper
INFO - 2020-09-21 00:10:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 00:10:13 --> Database Driver Class Initialized
DEBUG - 2020-09-21 00:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 00:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 00:10:13 --> Upload Class Initialized
INFO - 2020-09-21 00:10:13 --> Controller Class Initialized
ERROR - 2020-09-21 00:10:13 --> 404 Page Not Found: /index
INFO - 2020-09-21 00:14:16 --> Config Class Initialized
INFO - 2020-09-21 00:14:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 00:14:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 00:14:16 --> Utf8 Class Initialized
INFO - 2020-09-21 00:14:16 --> URI Class Initialized
INFO - 2020-09-21 00:14:16 --> Router Class Initialized
INFO - 2020-09-21 00:14:16 --> Output Class Initialized
INFO - 2020-09-21 00:14:16 --> Security Class Initialized
DEBUG - 2020-09-21 00:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 00:14:16 --> Input Class Initialized
INFO - 2020-09-21 00:14:16 --> Language Class Initialized
INFO - 2020-09-21 00:14:16 --> Language Class Initialized
INFO - 2020-09-21 00:14:16 --> Config Class Initialized
INFO - 2020-09-21 00:14:16 --> Loader Class Initialized
INFO - 2020-09-21 00:14:16 --> Helper loaded: url_helper
INFO - 2020-09-21 00:14:16 --> Helper loaded: form_helper
INFO - 2020-09-21 00:14:16 --> Helper loaded: file_helper
INFO - 2020-09-21 00:14:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 00:14:16 --> Database Driver Class Initialized
DEBUG - 2020-09-21 00:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 00:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 00:14:16 --> Upload Class Initialized
INFO - 2020-09-21 00:14:16 --> Controller Class Initialized
ERROR - 2020-09-21 00:14:16 --> 404 Page Not Found: /index
INFO - 2020-09-21 00:15:00 --> Config Class Initialized
INFO - 2020-09-21 00:15:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 00:15:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 00:15:00 --> Utf8 Class Initialized
INFO - 2020-09-21 00:15:00 --> URI Class Initialized
DEBUG - 2020-09-21 00:15:00 --> No URI present. Default controller set.
INFO - 2020-09-21 00:15:00 --> Router Class Initialized
INFO - 2020-09-21 00:15:00 --> Output Class Initialized
INFO - 2020-09-21 00:15:00 --> Security Class Initialized
DEBUG - 2020-09-21 00:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 00:15:00 --> Input Class Initialized
INFO - 2020-09-21 00:15:00 --> Language Class Initialized
INFO - 2020-09-21 00:15:00 --> Language Class Initialized
INFO - 2020-09-21 00:15:00 --> Config Class Initialized
INFO - 2020-09-21 00:15:00 --> Loader Class Initialized
INFO - 2020-09-21 00:15:00 --> Helper loaded: url_helper
INFO - 2020-09-21 00:15:00 --> Helper loaded: form_helper
INFO - 2020-09-21 00:15:00 --> Helper loaded: file_helper
INFO - 2020-09-21 00:15:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 00:15:00 --> Database Driver Class Initialized
DEBUG - 2020-09-21 00:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 00:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 00:15:00 --> Upload Class Initialized
INFO - 2020-09-21 00:15:00 --> Controller Class Initialized
DEBUG - 2020-09-21 00:15:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 00:15:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 00:15:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 00:15:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 00:15:00 --> Final output sent to browser
DEBUG - 2020-09-21 00:15:00 --> Total execution time: 0.0487
INFO - 2020-09-21 00:24:04 --> Config Class Initialized
INFO - 2020-09-21 00:24:04 --> Hooks Class Initialized
DEBUG - 2020-09-21 00:24:04 --> UTF-8 Support Enabled
INFO - 2020-09-21 00:24:04 --> Utf8 Class Initialized
INFO - 2020-09-21 00:24:04 --> URI Class Initialized
DEBUG - 2020-09-21 00:24:04 --> No URI present. Default controller set.
INFO - 2020-09-21 00:24:04 --> Router Class Initialized
INFO - 2020-09-21 00:24:05 --> Output Class Initialized
INFO - 2020-09-21 00:24:05 --> Security Class Initialized
DEBUG - 2020-09-21 00:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 00:24:05 --> Input Class Initialized
INFO - 2020-09-21 00:24:05 --> Language Class Initialized
INFO - 2020-09-21 00:24:05 --> Language Class Initialized
INFO - 2020-09-21 00:24:05 --> Config Class Initialized
INFO - 2020-09-21 00:24:05 --> Loader Class Initialized
INFO - 2020-09-21 00:24:05 --> Helper loaded: url_helper
INFO - 2020-09-21 00:24:05 --> Helper loaded: form_helper
INFO - 2020-09-21 00:24:05 --> Helper loaded: file_helper
INFO - 2020-09-21 00:24:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 00:24:05 --> Database Driver Class Initialized
DEBUG - 2020-09-21 00:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 00:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 00:24:05 --> Upload Class Initialized
INFO - 2020-09-21 00:24:05 --> Controller Class Initialized
DEBUG - 2020-09-21 00:24:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 00:24:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 00:24:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 00:24:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 00:24:05 --> Final output sent to browser
DEBUG - 2020-09-21 00:24:05 --> Total execution time: 0.0545
INFO - 2020-09-21 01:54:49 --> Config Class Initialized
INFO - 2020-09-21 01:54:49 --> Hooks Class Initialized
DEBUG - 2020-09-21 01:54:49 --> UTF-8 Support Enabled
INFO - 2020-09-21 01:54:49 --> Utf8 Class Initialized
INFO - 2020-09-21 01:54:49 --> URI Class Initialized
DEBUG - 2020-09-21 01:54:49 --> No URI present. Default controller set.
INFO - 2020-09-21 01:54:49 --> Router Class Initialized
INFO - 2020-09-21 01:54:49 --> Output Class Initialized
INFO - 2020-09-21 01:54:49 --> Security Class Initialized
DEBUG - 2020-09-21 01:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 01:54:49 --> Input Class Initialized
INFO - 2020-09-21 01:54:49 --> Language Class Initialized
INFO - 2020-09-21 01:54:49 --> Language Class Initialized
INFO - 2020-09-21 01:54:49 --> Config Class Initialized
INFO - 2020-09-21 01:54:49 --> Loader Class Initialized
INFO - 2020-09-21 01:54:49 --> Helper loaded: url_helper
INFO - 2020-09-21 01:54:49 --> Helper loaded: form_helper
INFO - 2020-09-21 01:54:49 --> Helper loaded: file_helper
INFO - 2020-09-21 01:54:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 01:54:49 --> Database Driver Class Initialized
DEBUG - 2020-09-21 01:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 01:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 01:54:49 --> Upload Class Initialized
INFO - 2020-09-21 01:54:49 --> Controller Class Initialized
DEBUG - 2020-09-21 01:54:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 01:54:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 01:54:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 01:54:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 01:54:49 --> Final output sent to browser
DEBUG - 2020-09-21 01:54:49 --> Total execution time: 0.0485
INFO - 2020-09-21 03:37:09 --> Config Class Initialized
INFO - 2020-09-21 03:37:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 03:37:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 03:37:09 --> Utf8 Class Initialized
INFO - 2020-09-21 03:37:09 --> URI Class Initialized
DEBUG - 2020-09-21 03:37:09 --> No URI present. Default controller set.
INFO - 2020-09-21 03:37:09 --> Router Class Initialized
INFO - 2020-09-21 03:37:09 --> Output Class Initialized
INFO - 2020-09-21 03:37:09 --> Security Class Initialized
DEBUG - 2020-09-21 03:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 03:37:09 --> Input Class Initialized
INFO - 2020-09-21 03:37:09 --> Language Class Initialized
INFO - 2020-09-21 03:37:09 --> Language Class Initialized
INFO - 2020-09-21 03:37:09 --> Config Class Initialized
INFO - 2020-09-21 03:37:09 --> Loader Class Initialized
INFO - 2020-09-21 03:37:09 --> Helper loaded: url_helper
INFO - 2020-09-21 03:37:09 --> Helper loaded: form_helper
INFO - 2020-09-21 03:37:09 --> Helper loaded: file_helper
INFO - 2020-09-21 03:37:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 03:37:09 --> Database Driver Class Initialized
DEBUG - 2020-09-21 03:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 03:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 03:37:09 --> Upload Class Initialized
INFO - 2020-09-21 03:37:09 --> Controller Class Initialized
DEBUG - 2020-09-21 03:37:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 03:37:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 03:37:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 03:37:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 03:37:09 --> Final output sent to browser
DEBUG - 2020-09-21 03:37:09 --> Total execution time: 0.0591
INFO - 2020-09-21 03:37:11 --> Config Class Initialized
INFO - 2020-09-21 03:37:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 03:37:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 03:37:11 --> Utf8 Class Initialized
INFO - 2020-09-21 03:37:11 --> URI Class Initialized
INFO - 2020-09-21 03:37:11 --> Router Class Initialized
INFO - 2020-09-21 03:37:11 --> Output Class Initialized
INFO - 2020-09-21 03:37:11 --> Security Class Initialized
DEBUG - 2020-09-21 03:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 03:37:11 --> Input Class Initialized
INFO - 2020-09-21 03:37:11 --> Language Class Initialized
INFO - 2020-09-21 03:37:11 --> Language Class Initialized
INFO - 2020-09-21 03:37:11 --> Config Class Initialized
INFO - 2020-09-21 03:37:11 --> Loader Class Initialized
INFO - 2020-09-21 03:37:11 --> Helper loaded: url_helper
INFO - 2020-09-21 03:37:11 --> Helper loaded: form_helper
INFO - 2020-09-21 03:37:11 --> Helper loaded: file_helper
INFO - 2020-09-21 03:37:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 03:37:11 --> Database Driver Class Initialized
DEBUG - 2020-09-21 03:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 03:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 03:37:11 --> Upload Class Initialized
INFO - 2020-09-21 03:37:11 --> Controller Class Initialized
ERROR - 2020-09-21 03:37:11 --> 404 Page Not Found: /index
INFO - 2020-09-21 04:05:30 --> Config Class Initialized
INFO - 2020-09-21 04:05:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 04:05:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 04:05:30 --> Utf8 Class Initialized
INFO - 2020-09-21 04:05:30 --> URI Class Initialized
DEBUG - 2020-09-21 04:05:30 --> No URI present. Default controller set.
INFO - 2020-09-21 04:05:30 --> Router Class Initialized
INFO - 2020-09-21 04:05:30 --> Output Class Initialized
INFO - 2020-09-21 04:05:30 --> Security Class Initialized
DEBUG - 2020-09-21 04:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 04:05:30 --> Input Class Initialized
INFO - 2020-09-21 04:05:30 --> Language Class Initialized
INFO - 2020-09-21 04:05:30 --> Language Class Initialized
INFO - 2020-09-21 04:05:30 --> Config Class Initialized
INFO - 2020-09-21 04:05:30 --> Loader Class Initialized
INFO - 2020-09-21 04:05:30 --> Helper loaded: url_helper
INFO - 2020-09-21 04:05:30 --> Helper loaded: form_helper
INFO - 2020-09-21 04:05:30 --> Helper loaded: file_helper
INFO - 2020-09-21 04:05:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 04:05:30 --> Database Driver Class Initialized
DEBUG - 2020-09-21 04:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 04:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 04:05:30 --> Upload Class Initialized
INFO - 2020-09-21 04:05:30 --> Controller Class Initialized
DEBUG - 2020-09-21 04:05:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 04:05:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 04:05:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 04:05:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 04:05:30 --> Final output sent to browser
DEBUG - 2020-09-21 04:05:30 --> Total execution time: 0.0497
INFO - 2020-09-21 04:26:58 --> Config Class Initialized
INFO - 2020-09-21 04:26:58 --> Hooks Class Initialized
DEBUG - 2020-09-21 04:26:58 --> UTF-8 Support Enabled
INFO - 2020-09-21 04:26:58 --> Utf8 Class Initialized
INFO - 2020-09-21 04:26:58 --> URI Class Initialized
DEBUG - 2020-09-21 04:26:58 --> No URI present. Default controller set.
INFO - 2020-09-21 04:26:58 --> Router Class Initialized
INFO - 2020-09-21 04:26:58 --> Output Class Initialized
INFO - 2020-09-21 04:26:58 --> Security Class Initialized
DEBUG - 2020-09-21 04:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 04:26:58 --> Input Class Initialized
INFO - 2020-09-21 04:26:58 --> Language Class Initialized
INFO - 2020-09-21 04:26:58 --> Language Class Initialized
INFO - 2020-09-21 04:26:58 --> Config Class Initialized
INFO - 2020-09-21 04:26:58 --> Loader Class Initialized
INFO - 2020-09-21 04:26:58 --> Helper loaded: url_helper
INFO - 2020-09-21 04:26:58 --> Helper loaded: form_helper
INFO - 2020-09-21 04:26:58 --> Helper loaded: file_helper
INFO - 2020-09-21 04:26:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 04:26:58 --> Database Driver Class Initialized
DEBUG - 2020-09-21 04:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 04:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 04:26:58 --> Upload Class Initialized
INFO - 2020-09-21 04:26:58 --> Controller Class Initialized
DEBUG - 2020-09-21 04:26:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 04:26:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 04:26:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 04:26:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 04:26:58 --> Final output sent to browser
DEBUG - 2020-09-21 04:26:58 --> Total execution time: 0.0527
INFO - 2020-09-21 04:52:24 --> Config Class Initialized
INFO - 2020-09-21 04:52:24 --> Hooks Class Initialized
DEBUG - 2020-09-21 04:52:24 --> UTF-8 Support Enabled
INFO - 2020-09-21 04:52:24 --> Utf8 Class Initialized
INFO - 2020-09-21 04:52:24 --> URI Class Initialized
DEBUG - 2020-09-21 04:52:24 --> No URI present. Default controller set.
INFO - 2020-09-21 04:52:24 --> Router Class Initialized
INFO - 2020-09-21 04:52:24 --> Output Class Initialized
INFO - 2020-09-21 04:52:24 --> Security Class Initialized
DEBUG - 2020-09-21 04:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 04:52:24 --> Input Class Initialized
INFO - 2020-09-21 04:52:24 --> Language Class Initialized
INFO - 2020-09-21 04:52:24 --> Language Class Initialized
INFO - 2020-09-21 04:52:24 --> Config Class Initialized
INFO - 2020-09-21 04:52:24 --> Loader Class Initialized
INFO - 2020-09-21 04:52:24 --> Helper loaded: url_helper
INFO - 2020-09-21 04:52:24 --> Helper loaded: form_helper
INFO - 2020-09-21 04:52:24 --> Helper loaded: file_helper
INFO - 2020-09-21 04:52:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 04:52:24 --> Database Driver Class Initialized
DEBUG - 2020-09-21 04:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 04:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 04:52:24 --> Upload Class Initialized
INFO - 2020-09-21 04:52:24 --> Controller Class Initialized
DEBUG - 2020-09-21 04:52:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 04:52:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 04:52:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 04:52:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 04:52:24 --> Final output sent to browser
DEBUG - 2020-09-21 04:52:24 --> Total execution time: 0.0428
INFO - 2020-09-21 04:52:24 --> Config Class Initialized
INFO - 2020-09-21 04:52:24 --> Hooks Class Initialized
DEBUG - 2020-09-21 04:52:24 --> UTF-8 Support Enabled
INFO - 2020-09-21 04:52:24 --> Utf8 Class Initialized
INFO - 2020-09-21 04:52:24 --> URI Class Initialized
DEBUG - 2020-09-21 04:52:24 --> No URI present. Default controller set.
INFO - 2020-09-21 04:52:24 --> Router Class Initialized
INFO - 2020-09-21 04:52:24 --> Output Class Initialized
INFO - 2020-09-21 04:52:24 --> Security Class Initialized
DEBUG - 2020-09-21 04:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 04:52:24 --> Input Class Initialized
INFO - 2020-09-21 04:52:24 --> Language Class Initialized
INFO - 2020-09-21 04:52:24 --> Language Class Initialized
INFO - 2020-09-21 04:52:24 --> Config Class Initialized
INFO - 2020-09-21 04:52:24 --> Loader Class Initialized
INFO - 2020-09-21 04:52:24 --> Helper loaded: url_helper
INFO - 2020-09-21 04:52:24 --> Helper loaded: form_helper
INFO - 2020-09-21 04:52:24 --> Helper loaded: file_helper
INFO - 2020-09-21 04:52:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 04:52:24 --> Database Driver Class Initialized
DEBUG - 2020-09-21 04:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 04:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 04:52:24 --> Upload Class Initialized
INFO - 2020-09-21 04:52:24 --> Controller Class Initialized
DEBUG - 2020-09-21 04:52:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 04:52:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 04:52:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 04:52:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 04:52:24 --> Final output sent to browser
DEBUG - 2020-09-21 04:52:24 --> Total execution time: 0.0440
INFO - 2020-09-21 04:55:37 --> Config Class Initialized
INFO - 2020-09-21 04:55:37 --> Hooks Class Initialized
DEBUG - 2020-09-21 04:55:37 --> UTF-8 Support Enabled
INFO - 2020-09-21 04:55:37 --> Utf8 Class Initialized
INFO - 2020-09-21 04:55:37 --> URI Class Initialized
INFO - 2020-09-21 04:55:37 --> Router Class Initialized
INFO - 2020-09-21 04:55:37 --> Output Class Initialized
INFO - 2020-09-21 04:55:37 --> Security Class Initialized
DEBUG - 2020-09-21 04:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 04:55:37 --> Input Class Initialized
INFO - 2020-09-21 04:55:37 --> Language Class Initialized
INFO - 2020-09-21 04:55:37 --> Language Class Initialized
INFO - 2020-09-21 04:55:37 --> Config Class Initialized
INFO - 2020-09-21 04:55:37 --> Loader Class Initialized
INFO - 2020-09-21 04:55:37 --> Helper loaded: url_helper
INFO - 2020-09-21 04:55:37 --> Helper loaded: form_helper
INFO - 2020-09-21 04:55:37 --> Helper loaded: file_helper
INFO - 2020-09-21 04:55:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 04:55:37 --> Database Driver Class Initialized
DEBUG - 2020-09-21 04:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 04:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 04:55:37 --> Upload Class Initialized
INFO - 2020-09-21 04:55:37 --> Controller Class Initialized
ERROR - 2020-09-21 04:55:37 --> 404 Page Not Found: /index
INFO - 2020-09-21 04:55:37 --> Config Class Initialized
INFO - 2020-09-21 04:55:37 --> Hooks Class Initialized
DEBUG - 2020-09-21 04:55:37 --> UTF-8 Support Enabled
INFO - 2020-09-21 04:55:37 --> Utf8 Class Initialized
INFO - 2020-09-21 04:55:37 --> URI Class Initialized
DEBUG - 2020-09-21 04:55:37 --> No URI present. Default controller set.
INFO - 2020-09-21 04:55:37 --> Router Class Initialized
INFO - 2020-09-21 04:55:37 --> Output Class Initialized
INFO - 2020-09-21 04:55:37 --> Security Class Initialized
DEBUG - 2020-09-21 04:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 04:55:37 --> Input Class Initialized
INFO - 2020-09-21 04:55:37 --> Language Class Initialized
INFO - 2020-09-21 04:55:37 --> Language Class Initialized
INFO - 2020-09-21 04:55:37 --> Config Class Initialized
INFO - 2020-09-21 04:55:37 --> Loader Class Initialized
INFO - 2020-09-21 04:55:37 --> Helper loaded: url_helper
INFO - 2020-09-21 04:55:37 --> Helper loaded: form_helper
INFO - 2020-09-21 04:55:37 --> Helper loaded: file_helper
INFO - 2020-09-21 04:55:37 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 04:55:37 --> Database Driver Class Initialized
DEBUG - 2020-09-21 04:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 04:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 04:55:37 --> Upload Class Initialized
INFO - 2020-09-21 04:55:37 --> Controller Class Initialized
DEBUG - 2020-09-21 04:55:37 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 04:55:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 04:55:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 04:55:37 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 04:55:37 --> Final output sent to browser
DEBUG - 2020-09-21 04:55:37 --> Total execution time: 0.0460
INFO - 2020-09-21 05:56:01 --> Config Class Initialized
INFO - 2020-09-21 05:56:01 --> Hooks Class Initialized
DEBUG - 2020-09-21 05:56:01 --> UTF-8 Support Enabled
INFO - 2020-09-21 05:56:01 --> Utf8 Class Initialized
INFO - 2020-09-21 05:56:01 --> URI Class Initialized
INFO - 2020-09-21 05:56:01 --> Router Class Initialized
INFO - 2020-09-21 05:56:01 --> Output Class Initialized
INFO - 2020-09-21 05:56:01 --> Security Class Initialized
DEBUG - 2020-09-21 05:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 05:56:01 --> Input Class Initialized
INFO - 2020-09-21 05:56:01 --> Language Class Initialized
INFO - 2020-09-21 05:56:01 --> Language Class Initialized
INFO - 2020-09-21 05:56:01 --> Config Class Initialized
INFO - 2020-09-21 05:56:01 --> Loader Class Initialized
INFO - 2020-09-21 05:56:01 --> Helper loaded: url_helper
INFO - 2020-09-21 05:56:01 --> Helper loaded: form_helper
INFO - 2020-09-21 05:56:01 --> Helper loaded: file_helper
INFO - 2020-09-21 05:56:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 05:56:01 --> Database Driver Class Initialized
DEBUG - 2020-09-21 05:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 05:56:01 --> Upload Class Initialized
INFO - 2020-09-21 05:56:01 --> Controller Class Initialized
ERROR - 2020-09-21 05:56:01 --> 404 Page Not Found: /index
INFO - 2020-09-21 06:16:21 --> Config Class Initialized
INFO - 2020-09-21 06:16:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 06:16:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 06:16:21 --> Utf8 Class Initialized
INFO - 2020-09-21 06:16:21 --> URI Class Initialized
DEBUG - 2020-09-21 06:16:21 --> No URI present. Default controller set.
INFO - 2020-09-21 06:16:21 --> Router Class Initialized
INFO - 2020-09-21 06:16:21 --> Output Class Initialized
INFO - 2020-09-21 06:16:21 --> Security Class Initialized
DEBUG - 2020-09-21 06:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 06:16:21 --> Input Class Initialized
INFO - 2020-09-21 06:16:21 --> Language Class Initialized
INFO - 2020-09-21 06:16:21 --> Language Class Initialized
INFO - 2020-09-21 06:16:21 --> Config Class Initialized
INFO - 2020-09-21 06:16:21 --> Loader Class Initialized
INFO - 2020-09-21 06:16:21 --> Helper loaded: url_helper
INFO - 2020-09-21 06:16:21 --> Helper loaded: form_helper
INFO - 2020-09-21 06:16:21 --> Helper loaded: file_helper
INFO - 2020-09-21 06:16:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 06:16:21 --> Database Driver Class Initialized
DEBUG - 2020-09-21 06:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 06:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 06:16:21 --> Upload Class Initialized
INFO - 2020-09-21 06:16:21 --> Controller Class Initialized
DEBUG - 2020-09-21 06:16:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 06:16:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 06:16:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 06:16:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 06:16:21 --> Final output sent to browser
DEBUG - 2020-09-21 06:16:21 --> Total execution time: 0.0511
INFO - 2020-09-21 07:22:49 --> Config Class Initialized
INFO - 2020-09-21 07:22:49 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:22:49 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:22:49 --> Utf8 Class Initialized
INFO - 2020-09-21 07:22:49 --> URI Class Initialized
DEBUG - 2020-09-21 07:22:49 --> No URI present. Default controller set.
INFO - 2020-09-21 07:22:49 --> Router Class Initialized
INFO - 2020-09-21 07:22:49 --> Output Class Initialized
INFO - 2020-09-21 07:22:49 --> Security Class Initialized
DEBUG - 2020-09-21 07:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:22:49 --> Input Class Initialized
INFO - 2020-09-21 07:22:49 --> Language Class Initialized
INFO - 2020-09-21 07:22:49 --> Language Class Initialized
INFO - 2020-09-21 07:22:49 --> Config Class Initialized
INFO - 2020-09-21 07:22:49 --> Loader Class Initialized
INFO - 2020-09-21 07:22:49 --> Helper loaded: url_helper
INFO - 2020-09-21 07:22:49 --> Helper loaded: form_helper
INFO - 2020-09-21 07:22:49 --> Helper loaded: file_helper
INFO - 2020-09-21 07:22:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:22:49 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:22:49 --> Upload Class Initialized
INFO - 2020-09-21 07:22:49 --> Controller Class Initialized
DEBUG - 2020-09-21 07:22:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 07:22:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 07:22:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 07:22:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 07:22:49 --> Final output sent to browser
DEBUG - 2020-09-21 07:22:49 --> Total execution time: 0.0586
INFO - 2020-09-21 07:31:51 --> Config Class Initialized
INFO - 2020-09-21 07:31:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:31:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:31:51 --> Utf8 Class Initialized
INFO - 2020-09-21 07:31:51 --> URI Class Initialized
INFO - 2020-09-21 07:31:51 --> Router Class Initialized
INFO - 2020-09-21 07:31:51 --> Output Class Initialized
INFO - 2020-09-21 07:31:51 --> Security Class Initialized
DEBUG - 2020-09-21 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:31:51 --> Input Class Initialized
INFO - 2020-09-21 07:31:51 --> Language Class Initialized
INFO - 2020-09-21 07:31:51 --> Language Class Initialized
INFO - 2020-09-21 07:31:51 --> Config Class Initialized
INFO - 2020-09-21 07:31:51 --> Loader Class Initialized
INFO - 2020-09-21 07:31:51 --> Helper loaded: url_helper
INFO - 2020-09-21 07:31:51 --> Helper loaded: form_helper
INFO - 2020-09-21 07:31:51 --> Helper loaded: file_helper
INFO - 2020-09-21 07:31:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:31:51 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:31:51 --> Upload Class Initialized
INFO - 2020-09-21 07:31:51 --> Controller Class Initialized
ERROR - 2020-09-21 07:31:51 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:31:52 --> Config Class Initialized
INFO - 2020-09-21 07:31:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:31:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:31:52 --> Utf8 Class Initialized
INFO - 2020-09-21 07:31:52 --> URI Class Initialized
INFO - 2020-09-21 07:31:52 --> Router Class Initialized
INFO - 2020-09-21 07:31:52 --> Output Class Initialized
INFO - 2020-09-21 07:31:52 --> Security Class Initialized
DEBUG - 2020-09-21 07:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:31:52 --> Input Class Initialized
INFO - 2020-09-21 07:31:52 --> Language Class Initialized
INFO - 2020-09-21 07:31:52 --> Language Class Initialized
INFO - 2020-09-21 07:31:52 --> Config Class Initialized
INFO - 2020-09-21 07:31:52 --> Loader Class Initialized
INFO - 2020-09-21 07:31:52 --> Helper loaded: url_helper
INFO - 2020-09-21 07:31:52 --> Helper loaded: form_helper
INFO - 2020-09-21 07:31:52 --> Helper loaded: file_helper
INFO - 2020-09-21 07:31:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:31:52 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:31:52 --> Upload Class Initialized
INFO - 2020-09-21 07:31:52 --> Controller Class Initialized
ERROR - 2020-09-21 07:31:52 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:37:44 --> Config Class Initialized
INFO - 2020-09-21 07:37:44 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:37:44 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:37:44 --> Utf8 Class Initialized
INFO - 2020-09-21 07:37:44 --> URI Class Initialized
INFO - 2020-09-21 07:37:44 --> Router Class Initialized
INFO - 2020-09-21 07:37:44 --> Output Class Initialized
INFO - 2020-09-21 07:37:44 --> Security Class Initialized
DEBUG - 2020-09-21 07:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:37:44 --> Input Class Initialized
INFO - 2020-09-21 07:37:44 --> Language Class Initialized
INFO - 2020-09-21 07:37:44 --> Language Class Initialized
INFO - 2020-09-21 07:37:44 --> Config Class Initialized
INFO - 2020-09-21 07:37:44 --> Loader Class Initialized
INFO - 2020-09-21 07:37:44 --> Helper loaded: url_helper
INFO - 2020-09-21 07:37:44 --> Helper loaded: form_helper
INFO - 2020-09-21 07:37:44 --> Helper loaded: file_helper
INFO - 2020-09-21 07:37:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:37:44 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:37:44 --> Upload Class Initialized
INFO - 2020-09-21 07:37:44 --> Controller Class Initialized
ERROR - 2020-09-21 07:37:44 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:16 --> Config Class Initialized
INFO - 2020-09-21 07:40:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:16 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:16 --> URI Class Initialized
INFO - 2020-09-21 07:40:16 --> Router Class Initialized
INFO - 2020-09-21 07:40:16 --> Output Class Initialized
INFO - 2020-09-21 07:40:16 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:16 --> Input Class Initialized
INFO - 2020-09-21 07:40:16 --> Language Class Initialized
INFO - 2020-09-21 07:40:16 --> Language Class Initialized
INFO - 2020-09-21 07:40:16 --> Config Class Initialized
INFO - 2020-09-21 07:40:16 --> Loader Class Initialized
INFO - 2020-09-21 07:40:16 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:16 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:16 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:16 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:16 --> Upload Class Initialized
INFO - 2020-09-21 07:40:16 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:16 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:17 --> Config Class Initialized
INFO - 2020-09-21 07:40:17 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:17 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:17 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:17 --> URI Class Initialized
INFO - 2020-09-21 07:40:17 --> Router Class Initialized
INFO - 2020-09-21 07:40:17 --> Output Class Initialized
INFO - 2020-09-21 07:40:17 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:17 --> Input Class Initialized
INFO - 2020-09-21 07:40:17 --> Language Class Initialized
INFO - 2020-09-21 07:40:17 --> Language Class Initialized
INFO - 2020-09-21 07:40:17 --> Config Class Initialized
INFO - 2020-09-21 07:40:17 --> Loader Class Initialized
INFO - 2020-09-21 07:40:17 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:17 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:17 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:17 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:17 --> Upload Class Initialized
INFO - 2020-09-21 07:40:17 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:17 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:30 --> Config Class Initialized
INFO - 2020-09-21 07:40:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:30 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:30 --> URI Class Initialized
INFO - 2020-09-21 07:40:30 --> Router Class Initialized
INFO - 2020-09-21 07:40:30 --> Output Class Initialized
INFO - 2020-09-21 07:40:30 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:30 --> Input Class Initialized
INFO - 2020-09-21 07:40:30 --> Language Class Initialized
INFO - 2020-09-21 07:40:30 --> Language Class Initialized
INFO - 2020-09-21 07:40:30 --> Config Class Initialized
INFO - 2020-09-21 07:40:30 --> Loader Class Initialized
INFO - 2020-09-21 07:40:30 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:30 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:30 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:30 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:30 --> Upload Class Initialized
INFO - 2020-09-21 07:40:30 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:30 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:31 --> Config Class Initialized
INFO - 2020-09-21 07:40:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:31 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:31 --> URI Class Initialized
INFO - 2020-09-21 07:40:31 --> Router Class Initialized
INFO - 2020-09-21 07:40:31 --> Output Class Initialized
INFO - 2020-09-21 07:40:31 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:31 --> Input Class Initialized
INFO - 2020-09-21 07:40:31 --> Language Class Initialized
INFO - 2020-09-21 07:40:31 --> Language Class Initialized
INFO - 2020-09-21 07:40:31 --> Config Class Initialized
INFO - 2020-09-21 07:40:31 --> Loader Class Initialized
INFO - 2020-09-21 07:40:31 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:31 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:31 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:31 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:31 --> Upload Class Initialized
INFO - 2020-09-21 07:40:31 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:31 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:48 --> Config Class Initialized
INFO - 2020-09-21 07:40:48 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:48 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:48 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:48 --> URI Class Initialized
INFO - 2020-09-21 07:40:48 --> Router Class Initialized
INFO - 2020-09-21 07:40:48 --> Output Class Initialized
INFO - 2020-09-21 07:40:48 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:48 --> Input Class Initialized
INFO - 2020-09-21 07:40:48 --> Language Class Initialized
INFO - 2020-09-21 07:40:48 --> Language Class Initialized
INFO - 2020-09-21 07:40:48 --> Config Class Initialized
INFO - 2020-09-21 07:40:48 --> Loader Class Initialized
INFO - 2020-09-21 07:40:48 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:48 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:48 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:48 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:48 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:48 --> Upload Class Initialized
INFO - 2020-09-21 07:40:48 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:48 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:49 --> Config Class Initialized
INFO - 2020-09-21 07:40:49 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:49 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:49 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:49 --> URI Class Initialized
INFO - 2020-09-21 07:40:49 --> Router Class Initialized
INFO - 2020-09-21 07:40:49 --> Output Class Initialized
INFO - 2020-09-21 07:40:49 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:49 --> Input Class Initialized
INFO - 2020-09-21 07:40:49 --> Language Class Initialized
INFO - 2020-09-21 07:40:49 --> Language Class Initialized
INFO - 2020-09-21 07:40:49 --> Config Class Initialized
INFO - 2020-09-21 07:40:49 --> Loader Class Initialized
INFO - 2020-09-21 07:40:49 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:49 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:49 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:49 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:49 --> Upload Class Initialized
INFO - 2020-09-21 07:40:49 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:49 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:56 --> Config Class Initialized
INFO - 2020-09-21 07:40:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:56 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:56 --> URI Class Initialized
INFO - 2020-09-21 07:40:56 --> Router Class Initialized
INFO - 2020-09-21 07:40:56 --> Output Class Initialized
INFO - 2020-09-21 07:40:56 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:56 --> Input Class Initialized
INFO - 2020-09-21 07:40:56 --> Language Class Initialized
INFO - 2020-09-21 07:40:56 --> Language Class Initialized
INFO - 2020-09-21 07:40:56 --> Config Class Initialized
INFO - 2020-09-21 07:40:56 --> Loader Class Initialized
INFO - 2020-09-21 07:40:56 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:56 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:56 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:56 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:56 --> Upload Class Initialized
INFO - 2020-09-21 07:40:56 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:56 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:40:57 --> Config Class Initialized
INFO - 2020-09-21 07:40:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:40:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:40:57 --> Utf8 Class Initialized
INFO - 2020-09-21 07:40:57 --> URI Class Initialized
INFO - 2020-09-21 07:40:57 --> Router Class Initialized
INFO - 2020-09-21 07:40:57 --> Output Class Initialized
INFO - 2020-09-21 07:40:57 --> Security Class Initialized
DEBUG - 2020-09-21 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:40:57 --> Input Class Initialized
INFO - 2020-09-21 07:40:57 --> Language Class Initialized
INFO - 2020-09-21 07:40:57 --> Language Class Initialized
INFO - 2020-09-21 07:40:57 --> Config Class Initialized
INFO - 2020-09-21 07:40:57 --> Loader Class Initialized
INFO - 2020-09-21 07:40:57 --> Helper loaded: url_helper
INFO - 2020-09-21 07:40:57 --> Helper loaded: form_helper
INFO - 2020-09-21 07:40:57 --> Helper loaded: file_helper
INFO - 2020-09-21 07:40:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:40:57 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:40:57 --> Upload Class Initialized
INFO - 2020-09-21 07:40:57 --> Controller Class Initialized
ERROR - 2020-09-21 07:40:57 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:47:46 --> Config Class Initialized
INFO - 2020-09-21 07:47:46 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:47:46 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:47:46 --> Utf8 Class Initialized
INFO - 2020-09-21 07:47:46 --> URI Class Initialized
INFO - 2020-09-21 07:47:46 --> Router Class Initialized
INFO - 2020-09-21 07:47:46 --> Output Class Initialized
INFO - 2020-09-21 07:47:46 --> Security Class Initialized
DEBUG - 2020-09-21 07:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:47:46 --> Input Class Initialized
INFO - 2020-09-21 07:47:46 --> Language Class Initialized
INFO - 2020-09-21 07:47:46 --> Language Class Initialized
INFO - 2020-09-21 07:47:46 --> Config Class Initialized
INFO - 2020-09-21 07:47:46 --> Loader Class Initialized
INFO - 2020-09-21 07:47:46 --> Helper loaded: url_helper
INFO - 2020-09-21 07:47:46 --> Helper loaded: form_helper
INFO - 2020-09-21 07:47:46 --> Helper loaded: file_helper
INFO - 2020-09-21 07:47:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:47:46 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:47:46 --> Upload Class Initialized
INFO - 2020-09-21 07:47:46 --> Controller Class Initialized
ERROR - 2020-09-21 07:47:46 --> 404 Page Not Found: /index
INFO - 2020-09-21 07:47:47 --> Config Class Initialized
INFO - 2020-09-21 07:47:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:47:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:47:47 --> Utf8 Class Initialized
INFO - 2020-09-21 07:47:47 --> URI Class Initialized
INFO - 2020-09-21 07:47:47 --> Router Class Initialized
INFO - 2020-09-21 07:47:47 --> Output Class Initialized
INFO - 2020-09-21 07:47:47 --> Security Class Initialized
DEBUG - 2020-09-21 07:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:47:47 --> Input Class Initialized
INFO - 2020-09-21 07:47:47 --> Language Class Initialized
INFO - 2020-09-21 07:47:47 --> Language Class Initialized
INFO - 2020-09-21 07:47:47 --> Config Class Initialized
INFO - 2020-09-21 07:47:47 --> Loader Class Initialized
INFO - 2020-09-21 07:47:47 --> Helper loaded: url_helper
INFO - 2020-09-21 07:47:47 --> Helper loaded: form_helper
INFO - 2020-09-21 07:47:47 --> Helper loaded: file_helper
INFO - 2020-09-21 07:47:47 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 07:47:47 --> Database Driver Class Initialized
DEBUG - 2020-09-21 07:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 07:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:47:47 --> Upload Class Initialized
INFO - 2020-09-21 07:47:47 --> Controller Class Initialized
ERROR - 2020-09-21 07:47:47 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:02:49 --> Config Class Initialized
INFO - 2020-09-21 08:02:49 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:02:49 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:02:49 --> Utf8 Class Initialized
INFO - 2020-09-21 08:02:49 --> URI Class Initialized
INFO - 2020-09-21 08:02:49 --> Router Class Initialized
INFO - 2020-09-21 08:02:49 --> Output Class Initialized
INFO - 2020-09-21 08:02:49 --> Security Class Initialized
DEBUG - 2020-09-21 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:02:49 --> Input Class Initialized
INFO - 2020-09-21 08:02:49 --> Language Class Initialized
INFO - 2020-09-21 08:02:49 --> Language Class Initialized
INFO - 2020-09-21 08:02:49 --> Config Class Initialized
INFO - 2020-09-21 08:02:49 --> Loader Class Initialized
INFO - 2020-09-21 08:02:49 --> Helper loaded: url_helper
INFO - 2020-09-21 08:02:49 --> Helper loaded: form_helper
INFO - 2020-09-21 08:02:49 --> Helper loaded: file_helper
INFO - 2020-09-21 08:02:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:02:49 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:02:49 --> Upload Class Initialized
INFO - 2020-09-21 08:02:49 --> Controller Class Initialized
ERROR - 2020-09-21 08:02:49 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:02:50 --> Config Class Initialized
INFO - 2020-09-21 08:02:50 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:02:50 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:02:50 --> Utf8 Class Initialized
INFO - 2020-09-21 08:02:50 --> URI Class Initialized
INFO - 2020-09-21 08:02:50 --> Router Class Initialized
INFO - 2020-09-21 08:02:50 --> Output Class Initialized
INFO - 2020-09-21 08:02:50 --> Security Class Initialized
DEBUG - 2020-09-21 08:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:02:50 --> Input Class Initialized
INFO - 2020-09-21 08:02:50 --> Language Class Initialized
INFO - 2020-09-21 08:02:50 --> Language Class Initialized
INFO - 2020-09-21 08:02:50 --> Config Class Initialized
INFO - 2020-09-21 08:02:50 --> Loader Class Initialized
INFO - 2020-09-21 08:02:50 --> Helper loaded: url_helper
INFO - 2020-09-21 08:02:50 --> Helper loaded: form_helper
INFO - 2020-09-21 08:02:50 --> Helper loaded: file_helper
INFO - 2020-09-21 08:02:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:02:50 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:02:50 --> Upload Class Initialized
INFO - 2020-09-21 08:02:50 --> Controller Class Initialized
ERROR - 2020-09-21 08:02:50 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:03:45 --> Config Class Initialized
INFO - 2020-09-21 08:03:45 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:03:45 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:03:45 --> Utf8 Class Initialized
INFO - 2020-09-21 08:03:45 --> URI Class Initialized
INFO - 2020-09-21 08:03:45 --> Router Class Initialized
INFO - 2020-09-21 08:03:45 --> Output Class Initialized
INFO - 2020-09-21 08:03:45 --> Security Class Initialized
DEBUG - 2020-09-21 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:03:45 --> Input Class Initialized
INFO - 2020-09-21 08:03:45 --> Language Class Initialized
INFO - 2020-09-21 08:03:45 --> Language Class Initialized
INFO - 2020-09-21 08:03:45 --> Config Class Initialized
INFO - 2020-09-21 08:03:45 --> Loader Class Initialized
INFO - 2020-09-21 08:03:45 --> Helper loaded: url_helper
INFO - 2020-09-21 08:03:45 --> Helper loaded: form_helper
INFO - 2020-09-21 08:03:45 --> Helper loaded: file_helper
INFO - 2020-09-21 08:03:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:03:45 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:03:45 --> Upload Class Initialized
INFO - 2020-09-21 08:03:45 --> Controller Class Initialized
ERROR - 2020-09-21 08:03:45 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:03:46 --> Config Class Initialized
INFO - 2020-09-21 08:03:46 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:03:46 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:03:46 --> Utf8 Class Initialized
INFO - 2020-09-21 08:03:46 --> URI Class Initialized
INFO - 2020-09-21 08:03:46 --> Router Class Initialized
INFO - 2020-09-21 08:03:46 --> Output Class Initialized
INFO - 2020-09-21 08:03:46 --> Security Class Initialized
DEBUG - 2020-09-21 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:03:46 --> Input Class Initialized
INFO - 2020-09-21 08:03:46 --> Language Class Initialized
INFO - 2020-09-21 08:03:46 --> Language Class Initialized
INFO - 2020-09-21 08:03:46 --> Config Class Initialized
INFO - 2020-09-21 08:03:46 --> Loader Class Initialized
INFO - 2020-09-21 08:03:46 --> Helper loaded: url_helper
INFO - 2020-09-21 08:03:46 --> Helper loaded: form_helper
INFO - 2020-09-21 08:03:46 --> Helper loaded: file_helper
INFO - 2020-09-21 08:03:46 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:03:46 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:03:46 --> Upload Class Initialized
INFO - 2020-09-21 08:03:46 --> Controller Class Initialized
ERROR - 2020-09-21 08:03:46 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:03:56 --> Config Class Initialized
INFO - 2020-09-21 08:03:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:03:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:03:56 --> Utf8 Class Initialized
INFO - 2020-09-21 08:03:56 --> URI Class Initialized
INFO - 2020-09-21 08:03:56 --> Router Class Initialized
INFO - 2020-09-21 08:03:56 --> Output Class Initialized
INFO - 2020-09-21 08:03:56 --> Security Class Initialized
DEBUG - 2020-09-21 08:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:03:56 --> Input Class Initialized
INFO - 2020-09-21 08:03:56 --> Language Class Initialized
INFO - 2020-09-21 08:03:56 --> Language Class Initialized
INFO - 2020-09-21 08:03:56 --> Config Class Initialized
INFO - 2020-09-21 08:03:56 --> Loader Class Initialized
INFO - 2020-09-21 08:03:56 --> Helper loaded: url_helper
INFO - 2020-09-21 08:03:56 --> Helper loaded: form_helper
INFO - 2020-09-21 08:03:56 --> Helper loaded: file_helper
INFO - 2020-09-21 08:03:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:03:56 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:03:56 --> Upload Class Initialized
INFO - 2020-09-21 08:03:56 --> Controller Class Initialized
ERROR - 2020-09-21 08:03:56 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:05:25 --> Config Class Initialized
INFO - 2020-09-21 08:05:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:05:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:05:25 --> Utf8 Class Initialized
INFO - 2020-09-21 08:05:25 --> URI Class Initialized
INFO - 2020-09-21 08:05:25 --> Router Class Initialized
INFO - 2020-09-21 08:05:25 --> Output Class Initialized
INFO - 2020-09-21 08:05:25 --> Security Class Initialized
DEBUG - 2020-09-21 08:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:05:25 --> Input Class Initialized
INFO - 2020-09-21 08:05:25 --> Language Class Initialized
INFO - 2020-09-21 08:05:25 --> Language Class Initialized
INFO - 2020-09-21 08:05:25 --> Config Class Initialized
INFO - 2020-09-21 08:05:25 --> Loader Class Initialized
INFO - 2020-09-21 08:05:25 --> Helper loaded: url_helper
INFO - 2020-09-21 08:05:25 --> Helper loaded: form_helper
INFO - 2020-09-21 08:05:25 --> Helper loaded: file_helper
INFO - 2020-09-21 08:05:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:05:25 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:05:25 --> Upload Class Initialized
INFO - 2020-09-21 08:05:25 --> Controller Class Initialized
ERROR - 2020-09-21 08:05:25 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:05:27 --> Config Class Initialized
INFO - 2020-09-21 08:05:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:05:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:05:27 --> Utf8 Class Initialized
INFO - 2020-09-21 08:05:27 --> URI Class Initialized
INFO - 2020-09-21 08:05:27 --> Router Class Initialized
INFO - 2020-09-21 08:05:27 --> Output Class Initialized
INFO - 2020-09-21 08:05:27 --> Security Class Initialized
DEBUG - 2020-09-21 08:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:05:27 --> Input Class Initialized
INFO - 2020-09-21 08:05:27 --> Language Class Initialized
INFO - 2020-09-21 08:05:27 --> Language Class Initialized
INFO - 2020-09-21 08:05:27 --> Config Class Initialized
INFO - 2020-09-21 08:05:27 --> Loader Class Initialized
INFO - 2020-09-21 08:05:27 --> Helper loaded: url_helper
INFO - 2020-09-21 08:05:27 --> Helper loaded: form_helper
INFO - 2020-09-21 08:05:27 --> Helper loaded: file_helper
INFO - 2020-09-21 08:05:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:05:27 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:05:27 --> Upload Class Initialized
INFO - 2020-09-21 08:05:27 --> Controller Class Initialized
ERROR - 2020-09-21 08:05:27 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:09:04 --> Config Class Initialized
INFO - 2020-09-21 08:09:04 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:09:04 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:09:04 --> Utf8 Class Initialized
INFO - 2020-09-21 08:09:04 --> URI Class Initialized
DEBUG - 2020-09-21 08:09:04 --> No URI present. Default controller set.
INFO - 2020-09-21 08:09:04 --> Router Class Initialized
INFO - 2020-09-21 08:09:04 --> Output Class Initialized
INFO - 2020-09-21 08:09:04 --> Security Class Initialized
DEBUG - 2020-09-21 08:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:09:04 --> Input Class Initialized
INFO - 2020-09-21 08:09:04 --> Language Class Initialized
INFO - 2020-09-21 08:09:04 --> Language Class Initialized
INFO - 2020-09-21 08:09:04 --> Config Class Initialized
INFO - 2020-09-21 08:09:04 --> Loader Class Initialized
INFO - 2020-09-21 08:09:04 --> Helper loaded: url_helper
INFO - 2020-09-21 08:09:04 --> Helper loaded: form_helper
INFO - 2020-09-21 08:09:04 --> Helper loaded: file_helper
INFO - 2020-09-21 08:09:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:09:04 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:09:04 --> Upload Class Initialized
INFO - 2020-09-21 08:09:04 --> Controller Class Initialized
DEBUG - 2020-09-21 08:09:04 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 08:09:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 08:09:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 08:09:04 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 08:09:04 --> Final output sent to browser
DEBUG - 2020-09-21 08:09:04 --> Total execution time: 0.0448
INFO - 2020-09-21 08:09:16 --> Config Class Initialized
INFO - 2020-09-21 08:09:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:09:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:09:16 --> Utf8 Class Initialized
INFO - 2020-09-21 08:09:16 --> URI Class Initialized
INFO - 2020-09-21 08:09:16 --> Router Class Initialized
INFO - 2020-09-21 08:09:16 --> Output Class Initialized
INFO - 2020-09-21 08:09:16 --> Security Class Initialized
DEBUG - 2020-09-21 08:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:09:16 --> Input Class Initialized
INFO - 2020-09-21 08:09:16 --> Language Class Initialized
INFO - 2020-09-21 08:09:16 --> Language Class Initialized
INFO - 2020-09-21 08:09:16 --> Config Class Initialized
INFO - 2020-09-21 08:09:16 --> Loader Class Initialized
INFO - 2020-09-21 08:09:16 --> Helper loaded: url_helper
INFO - 2020-09-21 08:09:16 --> Helper loaded: form_helper
INFO - 2020-09-21 08:09:16 --> Helper loaded: file_helper
INFO - 2020-09-21 08:09:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:09:16 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:09:16 --> Upload Class Initialized
INFO - 2020-09-21 08:09:16 --> Controller Class Initialized
ERROR - 2020-09-21 08:09:16 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:09:20 --> Config Class Initialized
INFO - 2020-09-21 08:09:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:09:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:09:20 --> Utf8 Class Initialized
INFO - 2020-09-21 08:09:20 --> URI Class Initialized
INFO - 2020-09-21 08:09:20 --> Router Class Initialized
INFO - 2020-09-21 08:09:20 --> Output Class Initialized
INFO - 2020-09-21 08:09:20 --> Security Class Initialized
DEBUG - 2020-09-21 08:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:09:20 --> Input Class Initialized
INFO - 2020-09-21 08:09:20 --> Language Class Initialized
INFO - 2020-09-21 08:09:20 --> Language Class Initialized
INFO - 2020-09-21 08:09:20 --> Config Class Initialized
INFO - 2020-09-21 08:09:20 --> Loader Class Initialized
INFO - 2020-09-21 08:09:20 --> Helper loaded: url_helper
INFO - 2020-09-21 08:09:20 --> Helper loaded: form_helper
INFO - 2020-09-21 08:09:20 --> Helper loaded: file_helper
INFO - 2020-09-21 08:09:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:09:20 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:09:20 --> Upload Class Initialized
INFO - 2020-09-21 08:09:20 --> Controller Class Initialized
ERROR - 2020-09-21 08:09:20 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:09:24 --> Config Class Initialized
INFO - 2020-09-21 08:09:24 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:09:24 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:09:24 --> Utf8 Class Initialized
INFO - 2020-09-21 08:09:24 --> URI Class Initialized
DEBUG - 2020-09-21 08:09:24 --> No URI present. Default controller set.
INFO - 2020-09-21 08:09:24 --> Router Class Initialized
INFO - 2020-09-21 08:09:24 --> Output Class Initialized
INFO - 2020-09-21 08:09:24 --> Security Class Initialized
DEBUG - 2020-09-21 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:09:24 --> Input Class Initialized
INFO - 2020-09-21 08:09:24 --> Language Class Initialized
INFO - 2020-09-21 08:09:24 --> Language Class Initialized
INFO - 2020-09-21 08:09:24 --> Config Class Initialized
INFO - 2020-09-21 08:09:24 --> Loader Class Initialized
INFO - 2020-09-21 08:09:24 --> Helper loaded: url_helper
INFO - 2020-09-21 08:09:24 --> Helper loaded: form_helper
INFO - 2020-09-21 08:09:24 --> Helper loaded: file_helper
INFO - 2020-09-21 08:09:24 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:09:24 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:09:24 --> Upload Class Initialized
INFO - 2020-09-21 08:09:24 --> Controller Class Initialized
DEBUG - 2020-09-21 08:09:24 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 08:09:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 08:09:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 08:09:24 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 08:09:24 --> Final output sent to browser
DEBUG - 2020-09-21 08:09:24 --> Total execution time: 0.0551
INFO - 2020-09-21 08:09:43 --> Config Class Initialized
INFO - 2020-09-21 08:09:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:09:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:09:43 --> Utf8 Class Initialized
INFO - 2020-09-21 08:09:43 --> URI Class Initialized
INFO - 2020-09-21 08:09:43 --> Router Class Initialized
INFO - 2020-09-21 08:09:43 --> Output Class Initialized
INFO - 2020-09-21 08:09:43 --> Security Class Initialized
DEBUG - 2020-09-21 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:09:43 --> Input Class Initialized
INFO - 2020-09-21 08:09:43 --> Language Class Initialized
INFO - 2020-09-21 08:09:43 --> Language Class Initialized
INFO - 2020-09-21 08:09:43 --> Config Class Initialized
INFO - 2020-09-21 08:09:43 --> Loader Class Initialized
INFO - 2020-09-21 08:09:43 --> Helper loaded: url_helper
INFO - 2020-09-21 08:09:43 --> Helper loaded: form_helper
INFO - 2020-09-21 08:09:43 --> Helper loaded: file_helper
INFO - 2020-09-21 08:09:43 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:09:43 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:09:43 --> Upload Class Initialized
INFO - 2020-09-21 08:09:43 --> Controller Class Initialized
ERROR - 2020-09-21 08:09:43 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:09:45 --> Config Class Initialized
INFO - 2020-09-21 08:09:45 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:09:45 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:09:45 --> Utf8 Class Initialized
INFO - 2020-09-21 08:09:45 --> URI Class Initialized
DEBUG - 2020-09-21 08:09:45 --> No URI present. Default controller set.
INFO - 2020-09-21 08:09:45 --> Router Class Initialized
INFO - 2020-09-21 08:09:45 --> Output Class Initialized
INFO - 2020-09-21 08:09:45 --> Security Class Initialized
DEBUG - 2020-09-21 08:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:09:45 --> Input Class Initialized
INFO - 2020-09-21 08:09:45 --> Language Class Initialized
INFO - 2020-09-21 08:09:45 --> Language Class Initialized
INFO - 2020-09-21 08:09:45 --> Config Class Initialized
INFO - 2020-09-21 08:09:45 --> Loader Class Initialized
INFO - 2020-09-21 08:09:45 --> Helper loaded: url_helper
INFO - 2020-09-21 08:09:45 --> Helper loaded: form_helper
INFO - 2020-09-21 08:09:45 --> Helper loaded: file_helper
INFO - 2020-09-21 08:09:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:09:45 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:09:45 --> Upload Class Initialized
INFO - 2020-09-21 08:09:45 --> Controller Class Initialized
DEBUG - 2020-09-21 08:09:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 08:09:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 08:09:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 08:09:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 08:09:45 --> Final output sent to browser
DEBUG - 2020-09-21 08:09:45 --> Total execution time: 0.0473
INFO - 2020-09-21 08:17:56 --> Config Class Initialized
INFO - 2020-09-21 08:17:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:17:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:17:56 --> Utf8 Class Initialized
INFO - 2020-09-21 08:17:56 --> URI Class Initialized
DEBUG - 2020-09-21 08:17:56 --> No URI present. Default controller set.
INFO - 2020-09-21 08:17:56 --> Router Class Initialized
INFO - 2020-09-21 08:17:56 --> Output Class Initialized
INFO - 2020-09-21 08:17:56 --> Security Class Initialized
DEBUG - 2020-09-21 08:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:17:56 --> Input Class Initialized
INFO - 2020-09-21 08:17:56 --> Language Class Initialized
INFO - 2020-09-21 08:17:56 --> Language Class Initialized
INFO - 2020-09-21 08:17:56 --> Config Class Initialized
INFO - 2020-09-21 08:17:56 --> Loader Class Initialized
INFO - 2020-09-21 08:17:56 --> Helper loaded: url_helper
INFO - 2020-09-21 08:17:56 --> Helper loaded: form_helper
INFO - 2020-09-21 08:17:56 --> Helper loaded: file_helper
INFO - 2020-09-21 08:17:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:17:56 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:17:56 --> Upload Class Initialized
INFO - 2020-09-21 08:17:57 --> Controller Class Initialized
DEBUG - 2020-09-21 08:17:57 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 08:17:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 08:17:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 08:17:57 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 08:17:57 --> Final output sent to browser
DEBUG - 2020-09-21 08:17:57 --> Total execution time: 0.0705
INFO - 2020-09-21 08:17:58 --> Config Class Initialized
INFO - 2020-09-21 08:17:58 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:17:58 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:17:58 --> Utf8 Class Initialized
INFO - 2020-09-21 08:17:58 --> URI Class Initialized
INFO - 2020-09-21 08:17:58 --> Router Class Initialized
INFO - 2020-09-21 08:17:58 --> Output Class Initialized
INFO - 2020-09-21 08:17:58 --> Security Class Initialized
DEBUG - 2020-09-21 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:17:58 --> Input Class Initialized
INFO - 2020-09-21 08:17:58 --> Language Class Initialized
INFO - 2020-09-21 08:17:58 --> Language Class Initialized
INFO - 2020-09-21 08:17:58 --> Config Class Initialized
INFO - 2020-09-21 08:17:58 --> Loader Class Initialized
INFO - 2020-09-21 08:17:58 --> Helper loaded: url_helper
INFO - 2020-09-21 08:17:58 --> Helper loaded: form_helper
INFO - 2020-09-21 08:17:58 --> Helper loaded: file_helper
INFO - 2020-09-21 08:17:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:17:58 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:17:58 --> Upload Class Initialized
INFO - 2020-09-21 08:17:58 --> Controller Class Initialized
ERROR - 2020-09-21 08:17:58 --> 404 Page Not Found: /index
INFO - 2020-09-21 08:54:39 --> Config Class Initialized
INFO - 2020-09-21 08:54:39 --> Hooks Class Initialized
DEBUG - 2020-09-21 08:54:39 --> UTF-8 Support Enabled
INFO - 2020-09-21 08:54:39 --> Utf8 Class Initialized
INFO - 2020-09-21 08:54:39 --> URI Class Initialized
DEBUG - 2020-09-21 08:54:39 --> No URI present. Default controller set.
INFO - 2020-09-21 08:54:39 --> Router Class Initialized
INFO - 2020-09-21 08:54:39 --> Output Class Initialized
INFO - 2020-09-21 08:54:39 --> Security Class Initialized
DEBUG - 2020-09-21 08:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 08:54:39 --> Input Class Initialized
INFO - 2020-09-21 08:54:39 --> Language Class Initialized
INFO - 2020-09-21 08:54:39 --> Language Class Initialized
INFO - 2020-09-21 08:54:39 --> Config Class Initialized
INFO - 2020-09-21 08:54:39 --> Loader Class Initialized
INFO - 2020-09-21 08:54:39 --> Helper loaded: url_helper
INFO - 2020-09-21 08:54:39 --> Helper loaded: form_helper
INFO - 2020-09-21 08:54:39 --> Helper loaded: file_helper
INFO - 2020-09-21 08:54:39 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 08:54:39 --> Database Driver Class Initialized
DEBUG - 2020-09-21 08:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 08:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 08:54:39 --> Upload Class Initialized
INFO - 2020-09-21 08:54:39 --> Controller Class Initialized
DEBUG - 2020-09-21 08:54:39 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 08:54:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 08:54:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 08:54:39 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 08:54:39 --> Final output sent to browser
DEBUG - 2020-09-21 08:54:39 --> Total execution time: 0.0521
INFO - 2020-09-21 09:32:45 --> Config Class Initialized
INFO - 2020-09-21 09:32:45 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:32:45 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:32:45 --> Utf8 Class Initialized
INFO - 2020-09-21 09:32:45 --> URI Class Initialized
DEBUG - 2020-09-21 09:32:45 --> No URI present. Default controller set.
INFO - 2020-09-21 09:32:45 --> Router Class Initialized
INFO - 2020-09-21 09:32:45 --> Output Class Initialized
INFO - 2020-09-21 09:32:45 --> Security Class Initialized
DEBUG - 2020-09-21 09:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:32:45 --> Input Class Initialized
INFO - 2020-09-21 09:32:45 --> Language Class Initialized
INFO - 2020-09-21 09:32:45 --> Language Class Initialized
INFO - 2020-09-21 09:32:45 --> Config Class Initialized
INFO - 2020-09-21 09:32:45 --> Loader Class Initialized
INFO - 2020-09-21 09:32:45 --> Helper loaded: url_helper
INFO - 2020-09-21 09:32:45 --> Helper loaded: form_helper
INFO - 2020-09-21 09:32:45 --> Helper loaded: file_helper
INFO - 2020-09-21 09:32:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:32:45 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:32:45 --> Upload Class Initialized
INFO - 2020-09-21 09:32:45 --> Controller Class Initialized
DEBUG - 2020-09-21 09:32:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:32:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:32:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:32:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:32:45 --> Final output sent to browser
DEBUG - 2020-09-21 09:32:45 --> Total execution time: 0.0510
INFO - 2020-09-21 09:35:15 --> Config Class Initialized
INFO - 2020-09-21 09:35:15 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:35:15 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:35:15 --> Utf8 Class Initialized
INFO - 2020-09-21 09:35:15 --> URI Class Initialized
DEBUG - 2020-09-21 09:35:15 --> No URI present. Default controller set.
INFO - 2020-09-21 09:35:15 --> Router Class Initialized
INFO - 2020-09-21 09:35:15 --> Output Class Initialized
INFO - 2020-09-21 09:35:15 --> Security Class Initialized
DEBUG - 2020-09-21 09:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:35:15 --> Input Class Initialized
INFO - 2020-09-21 09:35:15 --> Language Class Initialized
INFO - 2020-09-21 09:35:15 --> Language Class Initialized
INFO - 2020-09-21 09:35:15 --> Config Class Initialized
INFO - 2020-09-21 09:35:15 --> Loader Class Initialized
INFO - 2020-09-21 09:35:15 --> Helper loaded: url_helper
INFO - 2020-09-21 09:35:15 --> Helper loaded: form_helper
INFO - 2020-09-21 09:35:15 --> Helper loaded: file_helper
INFO - 2020-09-21 09:35:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:35:15 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:35:15 --> Upload Class Initialized
INFO - 2020-09-21 09:35:15 --> Controller Class Initialized
DEBUG - 2020-09-21 09:35:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:35:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:35:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:35:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:35:15 --> Final output sent to browser
DEBUG - 2020-09-21 09:35:15 --> Total execution time: 0.0616
INFO - 2020-09-21 09:48:31 --> Config Class Initialized
INFO - 2020-09-21 09:48:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:48:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:48:31 --> Utf8 Class Initialized
INFO - 2020-09-21 09:48:31 --> URI Class Initialized
DEBUG - 2020-09-21 09:48:31 --> No URI present. Default controller set.
INFO - 2020-09-21 09:48:31 --> Router Class Initialized
INFO - 2020-09-21 09:48:31 --> Output Class Initialized
INFO - 2020-09-21 09:48:31 --> Security Class Initialized
DEBUG - 2020-09-21 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:48:31 --> Input Class Initialized
INFO - 2020-09-21 09:48:31 --> Language Class Initialized
INFO - 2020-09-21 09:48:31 --> Language Class Initialized
INFO - 2020-09-21 09:48:31 --> Config Class Initialized
INFO - 2020-09-21 09:48:31 --> Loader Class Initialized
INFO - 2020-09-21 09:48:31 --> Helper loaded: url_helper
INFO - 2020-09-21 09:48:31 --> Helper loaded: form_helper
INFO - 2020-09-21 09:48:31 --> Helper loaded: file_helper
INFO - 2020-09-21 09:48:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:48:31 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:48:31 --> Upload Class Initialized
INFO - 2020-09-21 09:48:31 --> Controller Class Initialized
DEBUG - 2020-09-21 09:48:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:48:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:48:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:48:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:48:31 --> Final output sent to browser
DEBUG - 2020-09-21 09:48:31 --> Total execution time: 0.0598
INFO - 2020-09-21 09:52:42 --> Config Class Initialized
INFO - 2020-09-21 09:52:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:52:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:52:42 --> Utf8 Class Initialized
INFO - 2020-09-21 09:52:42 --> URI Class Initialized
DEBUG - 2020-09-21 09:52:42 --> No URI present. Default controller set.
INFO - 2020-09-21 09:52:42 --> Router Class Initialized
INFO - 2020-09-21 09:52:42 --> Output Class Initialized
INFO - 2020-09-21 09:52:42 --> Security Class Initialized
DEBUG - 2020-09-21 09:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:52:42 --> Input Class Initialized
INFO - 2020-09-21 09:52:42 --> Language Class Initialized
INFO - 2020-09-21 09:52:42 --> Language Class Initialized
INFO - 2020-09-21 09:52:42 --> Config Class Initialized
INFO - 2020-09-21 09:52:42 --> Loader Class Initialized
INFO - 2020-09-21 09:52:42 --> Helper loaded: url_helper
INFO - 2020-09-21 09:52:42 --> Helper loaded: form_helper
INFO - 2020-09-21 09:52:42 --> Helper loaded: file_helper
INFO - 2020-09-21 09:52:42 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:52:42 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:52:42 --> Upload Class Initialized
INFO - 2020-09-21 09:52:42 --> Controller Class Initialized
DEBUG - 2020-09-21 09:52:42 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:52:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:52:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:52:42 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:52:42 --> Final output sent to browser
DEBUG - 2020-09-21 09:52:42 --> Total execution time: 0.0443
INFO - 2020-09-21 09:55:06 --> Config Class Initialized
INFO - 2020-09-21 09:55:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:55:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:55:06 --> Utf8 Class Initialized
INFO - 2020-09-21 09:55:06 --> URI Class Initialized
DEBUG - 2020-09-21 09:55:06 --> No URI present. Default controller set.
INFO - 2020-09-21 09:55:06 --> Router Class Initialized
INFO - 2020-09-21 09:55:06 --> Output Class Initialized
INFO - 2020-09-21 09:55:06 --> Security Class Initialized
DEBUG - 2020-09-21 09:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:55:06 --> Input Class Initialized
INFO - 2020-09-21 09:55:06 --> Language Class Initialized
INFO - 2020-09-21 09:55:06 --> Language Class Initialized
INFO - 2020-09-21 09:55:06 --> Config Class Initialized
INFO - 2020-09-21 09:55:06 --> Loader Class Initialized
INFO - 2020-09-21 09:55:06 --> Helper loaded: url_helper
INFO - 2020-09-21 09:55:06 --> Helper loaded: form_helper
INFO - 2020-09-21 09:55:06 --> Helper loaded: file_helper
INFO - 2020-09-21 09:55:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:55:06 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:55:06 --> Upload Class Initialized
INFO - 2020-09-21 09:55:06 --> Controller Class Initialized
DEBUG - 2020-09-21 09:55:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:55:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:55:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:55:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:55:06 --> Final output sent to browser
DEBUG - 2020-09-21 09:55:06 --> Total execution time: 0.0511
INFO - 2020-09-21 09:55:25 --> Config Class Initialized
INFO - 2020-09-21 09:55:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:55:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:55:25 --> Utf8 Class Initialized
INFO - 2020-09-21 09:55:25 --> URI Class Initialized
DEBUG - 2020-09-21 09:55:25 --> No URI present. Default controller set.
INFO - 2020-09-21 09:55:25 --> Router Class Initialized
INFO - 2020-09-21 09:55:25 --> Output Class Initialized
INFO - 2020-09-21 09:55:25 --> Security Class Initialized
DEBUG - 2020-09-21 09:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:55:25 --> Input Class Initialized
INFO - 2020-09-21 09:55:25 --> Language Class Initialized
INFO - 2020-09-21 09:55:25 --> Language Class Initialized
INFO - 2020-09-21 09:55:25 --> Config Class Initialized
INFO - 2020-09-21 09:55:25 --> Loader Class Initialized
INFO - 2020-09-21 09:55:25 --> Helper loaded: url_helper
INFO - 2020-09-21 09:55:25 --> Helper loaded: form_helper
INFO - 2020-09-21 09:55:25 --> Helper loaded: file_helper
INFO - 2020-09-21 09:55:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:55:25 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:55:25 --> Upload Class Initialized
INFO - 2020-09-21 09:55:25 --> Controller Class Initialized
DEBUG - 2020-09-21 09:55:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:55:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:55:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:55:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:55:25 --> Final output sent to browser
DEBUG - 2020-09-21 09:55:25 --> Total execution time: 0.0554
INFO - 2020-09-21 09:56:05 --> Config Class Initialized
INFO - 2020-09-21 09:56:05 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:56:05 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:56:05 --> Utf8 Class Initialized
INFO - 2020-09-21 09:56:05 --> URI Class Initialized
DEBUG - 2020-09-21 09:56:05 --> No URI present. Default controller set.
INFO - 2020-09-21 09:56:05 --> Router Class Initialized
INFO - 2020-09-21 09:56:05 --> Output Class Initialized
INFO - 2020-09-21 09:56:05 --> Security Class Initialized
DEBUG - 2020-09-21 09:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:56:05 --> Input Class Initialized
INFO - 2020-09-21 09:56:05 --> Language Class Initialized
INFO - 2020-09-21 09:56:05 --> Language Class Initialized
INFO - 2020-09-21 09:56:05 --> Config Class Initialized
INFO - 2020-09-21 09:56:05 --> Loader Class Initialized
INFO - 2020-09-21 09:56:05 --> Helper loaded: url_helper
INFO - 2020-09-21 09:56:05 --> Helper loaded: form_helper
INFO - 2020-09-21 09:56:05 --> Helper loaded: file_helper
INFO - 2020-09-21 09:56:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:56:05 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:56:05 --> Upload Class Initialized
INFO - 2020-09-21 09:56:05 --> Controller Class Initialized
DEBUG - 2020-09-21 09:56:05 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:56:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:56:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:56:05 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:56:05 --> Final output sent to browser
DEBUG - 2020-09-21 09:56:05 --> Total execution time: 0.0409
INFO - 2020-09-21 09:56:09 --> Config Class Initialized
INFO - 2020-09-21 09:56:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:56:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:56:09 --> Utf8 Class Initialized
INFO - 2020-09-21 09:56:09 --> URI Class Initialized
DEBUG - 2020-09-21 09:56:09 --> No URI present. Default controller set.
INFO - 2020-09-21 09:56:09 --> Router Class Initialized
INFO - 2020-09-21 09:56:09 --> Output Class Initialized
INFO - 2020-09-21 09:56:09 --> Security Class Initialized
DEBUG - 2020-09-21 09:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:56:09 --> Input Class Initialized
INFO - 2020-09-21 09:56:09 --> Language Class Initialized
INFO - 2020-09-21 09:56:09 --> Language Class Initialized
INFO - 2020-09-21 09:56:09 --> Config Class Initialized
INFO - 2020-09-21 09:56:09 --> Loader Class Initialized
INFO - 2020-09-21 09:56:09 --> Helper loaded: url_helper
INFO - 2020-09-21 09:56:09 --> Helper loaded: form_helper
INFO - 2020-09-21 09:56:09 --> Helper loaded: file_helper
INFO - 2020-09-21 09:56:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:56:09 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:56:09 --> Upload Class Initialized
INFO - 2020-09-21 09:56:09 --> Controller Class Initialized
DEBUG - 2020-09-21 09:56:09 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:56:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:56:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:56:09 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:56:09 --> Final output sent to browser
DEBUG - 2020-09-21 09:56:09 --> Total execution time: 0.0500
INFO - 2020-09-21 09:56:27 --> Config Class Initialized
INFO - 2020-09-21 09:56:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:56:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:56:27 --> Utf8 Class Initialized
INFO - 2020-09-21 09:56:27 --> URI Class Initialized
DEBUG - 2020-09-21 09:56:27 --> No URI present. Default controller set.
INFO - 2020-09-21 09:56:27 --> Router Class Initialized
INFO - 2020-09-21 09:56:27 --> Output Class Initialized
INFO - 2020-09-21 09:56:27 --> Security Class Initialized
DEBUG - 2020-09-21 09:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:56:27 --> Input Class Initialized
INFO - 2020-09-21 09:56:27 --> Language Class Initialized
INFO - 2020-09-21 09:56:27 --> Language Class Initialized
INFO - 2020-09-21 09:56:27 --> Config Class Initialized
INFO - 2020-09-21 09:56:27 --> Loader Class Initialized
INFO - 2020-09-21 09:56:27 --> Helper loaded: url_helper
INFO - 2020-09-21 09:56:27 --> Helper loaded: form_helper
INFO - 2020-09-21 09:56:27 --> Helper loaded: file_helper
INFO - 2020-09-21 09:56:27 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:56:27 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:56:27 --> Upload Class Initialized
INFO - 2020-09-21 09:56:27 --> Controller Class Initialized
DEBUG - 2020-09-21 09:56:27 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:56:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:56:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:56:27 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:56:27 --> Final output sent to browser
DEBUG - 2020-09-21 09:56:27 --> Total execution time: 0.0441
INFO - 2020-09-21 09:56:32 --> Config Class Initialized
INFO - 2020-09-21 09:56:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:56:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:56:32 --> Utf8 Class Initialized
INFO - 2020-09-21 09:56:32 --> URI Class Initialized
DEBUG - 2020-09-21 09:56:32 --> No URI present. Default controller set.
INFO - 2020-09-21 09:56:32 --> Router Class Initialized
INFO - 2020-09-21 09:56:32 --> Output Class Initialized
INFO - 2020-09-21 09:56:32 --> Security Class Initialized
DEBUG - 2020-09-21 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:56:32 --> Input Class Initialized
INFO - 2020-09-21 09:56:32 --> Language Class Initialized
INFO - 2020-09-21 09:56:32 --> Language Class Initialized
INFO - 2020-09-21 09:56:32 --> Config Class Initialized
INFO - 2020-09-21 09:56:32 --> Loader Class Initialized
INFO - 2020-09-21 09:56:32 --> Helper loaded: url_helper
INFO - 2020-09-21 09:56:32 --> Helper loaded: form_helper
INFO - 2020-09-21 09:56:32 --> Helper loaded: file_helper
INFO - 2020-09-21 09:56:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:56:32 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:56:32 --> Upload Class Initialized
INFO - 2020-09-21 09:56:32 --> Controller Class Initialized
DEBUG - 2020-09-21 09:56:32 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:56:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:56:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:56:32 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:56:32 --> Final output sent to browser
DEBUG - 2020-09-21 09:56:32 --> Total execution time: 0.0387
INFO - 2020-09-21 09:57:05 --> Config Class Initialized
INFO - 2020-09-21 09:57:05 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:05 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:05 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:05 --> URI Class Initialized
INFO - 2020-09-21 09:57:05 --> Router Class Initialized
INFO - 2020-09-21 09:57:05 --> Output Class Initialized
INFO - 2020-09-21 09:57:05 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:05 --> Input Class Initialized
INFO - 2020-09-21 09:57:05 --> Language Class Initialized
INFO - 2020-09-21 09:57:05 --> Language Class Initialized
INFO - 2020-09-21 09:57:05 --> Config Class Initialized
INFO - 2020-09-21 09:57:05 --> Loader Class Initialized
INFO - 2020-09-21 09:57:05 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:05 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:05 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:05 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:05 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:05 --> Upload Class Initialized
INFO - 2020-09-21 09:57:05 --> Controller Class Initialized
ERROR - 2020-09-21 09:57:05 --> 404 Page Not Found: /index
INFO - 2020-09-21 09:57:13 --> Config Class Initialized
INFO - 2020-09-21 09:57:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:13 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:13 --> URI Class Initialized
INFO - 2020-09-21 09:57:13 --> Router Class Initialized
INFO - 2020-09-21 09:57:13 --> Output Class Initialized
INFO - 2020-09-21 09:57:13 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:13 --> Input Class Initialized
INFO - 2020-09-21 09:57:13 --> Language Class Initialized
INFO - 2020-09-21 09:57:13 --> Language Class Initialized
INFO - 2020-09-21 09:57:13 --> Config Class Initialized
INFO - 2020-09-21 09:57:13 --> Loader Class Initialized
INFO - 2020-09-21 09:57:13 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:13 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:13 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:13 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:13 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:13 --> Upload Class Initialized
INFO - 2020-09-21 09:57:13 --> Controller Class Initialized
ERROR - 2020-09-21 09:57:13 --> 404 Page Not Found: /index
INFO - 2020-09-21 09:57:14 --> Config Class Initialized
INFO - 2020-09-21 09:57:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:14 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:14 --> URI Class Initialized
DEBUG - 2020-09-21 09:57:14 --> No URI present. Default controller set.
INFO - 2020-09-21 09:57:14 --> Router Class Initialized
INFO - 2020-09-21 09:57:14 --> Output Class Initialized
INFO - 2020-09-21 09:57:14 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:14 --> Input Class Initialized
INFO - 2020-09-21 09:57:14 --> Language Class Initialized
INFO - 2020-09-21 09:57:14 --> Language Class Initialized
INFO - 2020-09-21 09:57:14 --> Config Class Initialized
INFO - 2020-09-21 09:57:14 --> Loader Class Initialized
INFO - 2020-09-21 09:57:14 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:14 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:14 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:14 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:14 --> Upload Class Initialized
INFO - 2020-09-21 09:57:14 --> Controller Class Initialized
DEBUG - 2020-09-21 09:57:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:57:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:57:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:57:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:57:14 --> Final output sent to browser
DEBUG - 2020-09-21 09:57:14 --> Total execution time: 0.0452
INFO - 2020-09-21 09:57:19 --> Config Class Initialized
INFO - 2020-09-21 09:57:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:19 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:19 --> URI Class Initialized
INFO - 2020-09-21 09:57:19 --> Router Class Initialized
INFO - 2020-09-21 09:57:19 --> Output Class Initialized
INFO - 2020-09-21 09:57:19 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:19 --> Input Class Initialized
INFO - 2020-09-21 09:57:19 --> Language Class Initialized
INFO - 2020-09-21 09:57:19 --> Language Class Initialized
INFO - 2020-09-21 09:57:19 --> Config Class Initialized
INFO - 2020-09-21 09:57:19 --> Loader Class Initialized
INFO - 2020-09-21 09:57:19 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:19 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:19 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:19 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:19 --> Upload Class Initialized
INFO - 2020-09-21 09:57:19 --> Controller Class Initialized
ERROR - 2020-09-21 09:57:19 --> 404 Page Not Found: /index
INFO - 2020-09-21 09:57:21 --> Config Class Initialized
INFO - 2020-09-21 09:57:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:21 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:21 --> URI Class Initialized
DEBUG - 2020-09-21 09:57:21 --> No URI present. Default controller set.
INFO - 2020-09-21 09:57:21 --> Router Class Initialized
INFO - 2020-09-21 09:57:21 --> Output Class Initialized
INFO - 2020-09-21 09:57:21 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:21 --> Input Class Initialized
INFO - 2020-09-21 09:57:21 --> Language Class Initialized
INFO - 2020-09-21 09:57:21 --> Language Class Initialized
INFO - 2020-09-21 09:57:21 --> Config Class Initialized
INFO - 2020-09-21 09:57:21 --> Loader Class Initialized
INFO - 2020-09-21 09:57:21 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:21 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:21 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:21 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:21 --> Upload Class Initialized
INFO - 2020-09-21 09:57:21 --> Controller Class Initialized
DEBUG - 2020-09-21 09:57:21 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:57:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:57:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:57:21 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:57:21 --> Final output sent to browser
DEBUG - 2020-09-21 09:57:21 --> Total execution time: 0.0359
INFO - 2020-09-21 09:57:30 --> Config Class Initialized
INFO - 2020-09-21 09:57:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:30 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:30 --> URI Class Initialized
DEBUG - 2020-09-21 09:57:30 --> No URI present. Default controller set.
INFO - 2020-09-21 09:57:30 --> Router Class Initialized
INFO - 2020-09-21 09:57:30 --> Output Class Initialized
INFO - 2020-09-21 09:57:30 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:30 --> Input Class Initialized
INFO - 2020-09-21 09:57:30 --> Language Class Initialized
INFO - 2020-09-21 09:57:30 --> Language Class Initialized
INFO - 2020-09-21 09:57:30 --> Config Class Initialized
INFO - 2020-09-21 09:57:30 --> Loader Class Initialized
INFO - 2020-09-21 09:57:30 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:30 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:30 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:30 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:30 --> Upload Class Initialized
INFO - 2020-09-21 09:57:30 --> Controller Class Initialized
DEBUG - 2020-09-21 09:57:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:57:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:57:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:57:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:57:30 --> Final output sent to browser
DEBUG - 2020-09-21 09:57:30 --> Total execution time: 0.0489
INFO - 2020-09-21 09:57:38 --> Config Class Initialized
INFO - 2020-09-21 09:57:38 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:57:38 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:57:38 --> Utf8 Class Initialized
INFO - 2020-09-21 09:57:38 --> URI Class Initialized
DEBUG - 2020-09-21 09:57:38 --> No URI present. Default controller set.
INFO - 2020-09-21 09:57:38 --> Router Class Initialized
INFO - 2020-09-21 09:57:38 --> Output Class Initialized
INFO - 2020-09-21 09:57:38 --> Security Class Initialized
DEBUG - 2020-09-21 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:57:38 --> Input Class Initialized
INFO - 2020-09-21 09:57:38 --> Language Class Initialized
INFO - 2020-09-21 09:57:38 --> Language Class Initialized
INFO - 2020-09-21 09:57:38 --> Config Class Initialized
INFO - 2020-09-21 09:57:38 --> Loader Class Initialized
INFO - 2020-09-21 09:57:38 --> Helper loaded: url_helper
INFO - 2020-09-21 09:57:38 --> Helper loaded: form_helper
INFO - 2020-09-21 09:57:38 --> Helper loaded: file_helper
INFO - 2020-09-21 09:57:38 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:57:38 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:57:38 --> Upload Class Initialized
INFO - 2020-09-21 09:57:38 --> Controller Class Initialized
DEBUG - 2020-09-21 09:57:38 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:57:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:57:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:57:38 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:57:38 --> Final output sent to browser
DEBUG - 2020-09-21 09:57:38 --> Total execution time: 0.0468
INFO - 2020-09-21 09:58:02 --> Config Class Initialized
INFO - 2020-09-21 09:58:02 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:58:02 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:58:02 --> Utf8 Class Initialized
INFO - 2020-09-21 09:58:02 --> URI Class Initialized
INFO - 2020-09-21 09:58:02 --> Router Class Initialized
INFO - 2020-09-21 09:58:02 --> Output Class Initialized
INFO - 2020-09-21 09:58:02 --> Security Class Initialized
DEBUG - 2020-09-21 09:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:58:02 --> Input Class Initialized
INFO - 2020-09-21 09:58:02 --> Language Class Initialized
INFO - 2020-09-21 09:58:02 --> Language Class Initialized
INFO - 2020-09-21 09:58:02 --> Config Class Initialized
INFO - 2020-09-21 09:58:02 --> Loader Class Initialized
INFO - 2020-09-21 09:58:02 --> Helper loaded: url_helper
INFO - 2020-09-21 09:58:02 --> Helper loaded: form_helper
INFO - 2020-09-21 09:58:02 --> Helper loaded: file_helper
INFO - 2020-09-21 09:58:02 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:58:02 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:58:02 --> Upload Class Initialized
INFO - 2020-09-21 09:58:02 --> Controller Class Initialized
ERROR - 2020-09-21 09:58:02 --> 404 Page Not Found: /index
INFO - 2020-09-21 09:58:10 --> Config Class Initialized
INFO - 2020-09-21 09:58:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:58:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:58:10 --> Utf8 Class Initialized
INFO - 2020-09-21 09:58:10 --> URI Class Initialized
DEBUG - 2020-09-21 09:58:10 --> No URI present. Default controller set.
INFO - 2020-09-21 09:58:10 --> Router Class Initialized
INFO - 2020-09-21 09:58:10 --> Output Class Initialized
INFO - 2020-09-21 09:58:10 --> Security Class Initialized
DEBUG - 2020-09-21 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:58:10 --> Input Class Initialized
INFO - 2020-09-21 09:58:10 --> Language Class Initialized
INFO - 2020-09-21 09:58:10 --> Language Class Initialized
INFO - 2020-09-21 09:58:10 --> Config Class Initialized
INFO - 2020-09-21 09:58:10 --> Loader Class Initialized
INFO - 2020-09-21 09:58:10 --> Helper loaded: url_helper
INFO - 2020-09-21 09:58:10 --> Helper loaded: form_helper
INFO - 2020-09-21 09:58:10 --> Helper loaded: file_helper
INFO - 2020-09-21 09:58:10 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:58:10 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:58:10 --> Upload Class Initialized
INFO - 2020-09-21 09:58:10 --> Controller Class Initialized
DEBUG - 2020-09-21 09:58:10 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:58:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:58:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:58:10 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:58:10 --> Final output sent to browser
DEBUG - 2020-09-21 09:58:10 --> Total execution time: 0.0488
INFO - 2020-09-21 09:58:52 --> Config Class Initialized
INFO - 2020-09-21 09:58:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 09:58:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 09:58:52 --> Utf8 Class Initialized
INFO - 2020-09-21 09:58:52 --> URI Class Initialized
DEBUG - 2020-09-21 09:58:52 --> No URI present. Default controller set.
INFO - 2020-09-21 09:58:52 --> Router Class Initialized
INFO - 2020-09-21 09:58:52 --> Output Class Initialized
INFO - 2020-09-21 09:58:52 --> Security Class Initialized
DEBUG - 2020-09-21 09:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 09:58:52 --> Input Class Initialized
INFO - 2020-09-21 09:58:52 --> Language Class Initialized
INFO - 2020-09-21 09:58:52 --> Language Class Initialized
INFO - 2020-09-21 09:58:52 --> Config Class Initialized
INFO - 2020-09-21 09:58:52 --> Loader Class Initialized
INFO - 2020-09-21 09:58:52 --> Helper loaded: url_helper
INFO - 2020-09-21 09:58:52 --> Helper loaded: form_helper
INFO - 2020-09-21 09:58:52 --> Helper loaded: file_helper
INFO - 2020-09-21 09:58:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 09:58:52 --> Database Driver Class Initialized
DEBUG - 2020-09-21 09:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 09:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 09:58:52 --> Upload Class Initialized
INFO - 2020-09-21 09:58:52 --> Controller Class Initialized
DEBUG - 2020-09-21 09:58:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 09:58:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 09:58:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 09:58:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 09:58:52 --> Final output sent to browser
DEBUG - 2020-09-21 09:58:52 --> Total execution time: 0.0513
INFO - 2020-09-21 10:00:15 --> Config Class Initialized
INFO - 2020-09-21 10:00:15 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:00:15 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:00:15 --> Utf8 Class Initialized
INFO - 2020-09-21 10:00:15 --> URI Class Initialized
DEBUG - 2020-09-21 10:00:15 --> No URI present. Default controller set.
INFO - 2020-09-21 10:00:15 --> Router Class Initialized
INFO - 2020-09-21 10:00:15 --> Output Class Initialized
INFO - 2020-09-21 10:00:15 --> Security Class Initialized
DEBUG - 2020-09-21 10:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:00:15 --> Input Class Initialized
INFO - 2020-09-21 10:00:15 --> Language Class Initialized
INFO - 2020-09-21 10:00:15 --> Language Class Initialized
INFO - 2020-09-21 10:00:15 --> Config Class Initialized
INFO - 2020-09-21 10:00:15 --> Loader Class Initialized
INFO - 2020-09-21 10:00:15 --> Helper loaded: url_helper
INFO - 2020-09-21 10:00:15 --> Helper loaded: form_helper
INFO - 2020-09-21 10:00:15 --> Helper loaded: file_helper
INFO - 2020-09-21 10:00:15 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:00:15 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:00:15 --> Upload Class Initialized
INFO - 2020-09-21 10:00:15 --> Controller Class Initialized
DEBUG - 2020-09-21 10:00:15 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:00:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:00:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:00:15 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:00:15 --> Final output sent to browser
DEBUG - 2020-09-21 10:00:15 --> Total execution time: 0.0524
INFO - 2020-09-21 10:07:26 --> Config Class Initialized
INFO - 2020-09-21 10:07:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:07:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:07:26 --> Utf8 Class Initialized
INFO - 2020-09-21 10:07:26 --> URI Class Initialized
DEBUG - 2020-09-21 10:07:26 --> No URI present. Default controller set.
INFO - 2020-09-21 10:07:26 --> Router Class Initialized
INFO - 2020-09-21 10:07:26 --> Output Class Initialized
INFO - 2020-09-21 10:07:26 --> Security Class Initialized
DEBUG - 2020-09-21 10:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:07:26 --> Input Class Initialized
INFO - 2020-09-21 10:07:26 --> Language Class Initialized
INFO - 2020-09-21 10:07:26 --> Language Class Initialized
INFO - 2020-09-21 10:07:26 --> Config Class Initialized
INFO - 2020-09-21 10:07:26 --> Loader Class Initialized
INFO - 2020-09-21 10:07:26 --> Helper loaded: url_helper
INFO - 2020-09-21 10:07:26 --> Helper loaded: form_helper
INFO - 2020-09-21 10:07:26 --> Helper loaded: file_helper
INFO - 2020-09-21 10:07:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:07:26 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:07:26 --> Upload Class Initialized
INFO - 2020-09-21 10:07:26 --> Controller Class Initialized
DEBUG - 2020-09-21 10:07:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:07:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:07:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:07:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:07:26 --> Final output sent to browser
DEBUG - 2020-09-21 10:07:26 --> Total execution time: 0.0475
INFO - 2020-09-21 10:07:53 --> Config Class Initialized
INFO - 2020-09-21 10:07:53 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:07:53 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:07:53 --> Utf8 Class Initialized
INFO - 2020-09-21 10:07:53 --> URI Class Initialized
INFO - 2020-09-21 10:07:53 --> Router Class Initialized
INFO - 2020-09-21 10:07:53 --> Output Class Initialized
INFO - 2020-09-21 10:07:53 --> Security Class Initialized
DEBUG - 2020-09-21 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:07:53 --> Input Class Initialized
INFO - 2020-09-21 10:07:53 --> Language Class Initialized
INFO - 2020-09-21 10:07:53 --> Language Class Initialized
INFO - 2020-09-21 10:07:53 --> Config Class Initialized
INFO - 2020-09-21 10:07:53 --> Loader Class Initialized
INFO - 2020-09-21 10:07:53 --> Helper loaded: url_helper
INFO - 2020-09-21 10:07:53 --> Helper loaded: form_helper
INFO - 2020-09-21 10:07:53 --> Helper loaded: file_helper
INFO - 2020-09-21 10:07:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:07:53 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:07:53 --> Upload Class Initialized
INFO - 2020-09-21 10:07:53 --> Controller Class Initialized
ERROR - 2020-09-21 10:07:53 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:07:55 --> Config Class Initialized
INFO - 2020-09-21 10:07:55 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:07:55 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:07:55 --> Utf8 Class Initialized
INFO - 2020-09-21 10:07:55 --> URI Class Initialized
INFO - 2020-09-21 10:07:55 --> Router Class Initialized
INFO - 2020-09-21 10:07:55 --> Output Class Initialized
INFO - 2020-09-21 10:07:55 --> Security Class Initialized
DEBUG - 2020-09-21 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:07:55 --> Input Class Initialized
INFO - 2020-09-21 10:07:55 --> Language Class Initialized
INFO - 2020-09-21 10:07:55 --> Language Class Initialized
INFO - 2020-09-21 10:07:55 --> Config Class Initialized
INFO - 2020-09-21 10:07:55 --> Loader Class Initialized
INFO - 2020-09-21 10:07:55 --> Helper loaded: url_helper
INFO - 2020-09-21 10:07:55 --> Helper loaded: form_helper
INFO - 2020-09-21 10:07:55 --> Helper loaded: file_helper
INFO - 2020-09-21 10:07:55 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:07:55 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:07:55 --> Upload Class Initialized
INFO - 2020-09-21 10:07:55 --> Controller Class Initialized
ERROR - 2020-09-21 10:07:55 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:07:59 --> Config Class Initialized
INFO - 2020-09-21 10:07:59 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:07:59 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:07:59 --> Utf8 Class Initialized
INFO - 2020-09-21 10:07:59 --> URI Class Initialized
DEBUG - 2020-09-21 10:07:59 --> No URI present. Default controller set.
INFO - 2020-09-21 10:07:59 --> Router Class Initialized
INFO - 2020-09-21 10:07:59 --> Output Class Initialized
INFO - 2020-09-21 10:07:59 --> Security Class Initialized
DEBUG - 2020-09-21 10:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:07:59 --> Input Class Initialized
INFO - 2020-09-21 10:07:59 --> Language Class Initialized
INFO - 2020-09-21 10:07:59 --> Language Class Initialized
INFO - 2020-09-21 10:07:59 --> Config Class Initialized
INFO - 2020-09-21 10:07:59 --> Loader Class Initialized
INFO - 2020-09-21 10:07:59 --> Helper loaded: url_helper
INFO - 2020-09-21 10:07:59 --> Helper loaded: form_helper
INFO - 2020-09-21 10:07:59 --> Helper loaded: file_helper
INFO - 2020-09-21 10:07:59 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:07:59 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:07:59 --> Upload Class Initialized
INFO - 2020-09-21 10:07:59 --> Controller Class Initialized
DEBUG - 2020-09-21 10:07:59 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:07:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:07:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:07:59 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:07:59 --> Final output sent to browser
DEBUG - 2020-09-21 10:07:59 --> Total execution time: 0.0490
INFO - 2020-09-21 10:08:09 --> Config Class Initialized
INFO - 2020-09-21 10:08:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:08:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:08:09 --> Utf8 Class Initialized
INFO - 2020-09-21 10:08:09 --> URI Class Initialized
INFO - 2020-09-21 10:08:09 --> Router Class Initialized
INFO - 2020-09-21 10:08:09 --> Output Class Initialized
INFO - 2020-09-21 10:08:09 --> Security Class Initialized
DEBUG - 2020-09-21 10:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:08:09 --> Input Class Initialized
INFO - 2020-09-21 10:08:09 --> Language Class Initialized
INFO - 2020-09-21 10:08:09 --> Language Class Initialized
INFO - 2020-09-21 10:08:09 --> Config Class Initialized
INFO - 2020-09-21 10:08:09 --> Loader Class Initialized
INFO - 2020-09-21 10:08:09 --> Helper loaded: url_helper
INFO - 2020-09-21 10:08:09 --> Helper loaded: form_helper
INFO - 2020-09-21 10:08:09 --> Helper loaded: file_helper
INFO - 2020-09-21 10:08:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:08:09 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:08:09 --> Upload Class Initialized
INFO - 2020-09-21 10:08:09 --> Controller Class Initialized
ERROR - 2020-09-21 10:08:09 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:08:12 --> Config Class Initialized
INFO - 2020-09-21 10:08:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:08:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:08:12 --> Utf8 Class Initialized
INFO - 2020-09-21 10:08:12 --> URI Class Initialized
DEBUG - 2020-09-21 10:08:12 --> No URI present. Default controller set.
INFO - 2020-09-21 10:08:12 --> Router Class Initialized
INFO - 2020-09-21 10:08:12 --> Output Class Initialized
INFO - 2020-09-21 10:08:12 --> Security Class Initialized
DEBUG - 2020-09-21 10:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:08:12 --> Input Class Initialized
INFO - 2020-09-21 10:08:12 --> Language Class Initialized
INFO - 2020-09-21 10:08:12 --> Language Class Initialized
INFO - 2020-09-21 10:08:12 --> Config Class Initialized
INFO - 2020-09-21 10:08:12 --> Loader Class Initialized
INFO - 2020-09-21 10:08:12 --> Helper loaded: url_helper
INFO - 2020-09-21 10:08:12 --> Helper loaded: form_helper
INFO - 2020-09-21 10:08:12 --> Helper loaded: file_helper
INFO - 2020-09-21 10:08:12 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:08:12 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:08:12 --> Upload Class Initialized
INFO - 2020-09-21 10:08:12 --> Controller Class Initialized
DEBUG - 2020-09-21 10:08:12 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:08:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:08:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:08:12 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:08:12 --> Final output sent to browser
DEBUG - 2020-09-21 10:08:12 --> Total execution time: 0.0483
INFO - 2020-09-21 10:20:16 --> Config Class Initialized
INFO - 2020-09-21 10:20:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:20:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:20:16 --> Utf8 Class Initialized
INFO - 2020-09-21 10:20:16 --> URI Class Initialized
INFO - 2020-09-21 10:20:16 --> Router Class Initialized
INFO - 2020-09-21 10:20:16 --> Output Class Initialized
INFO - 2020-09-21 10:20:16 --> Security Class Initialized
DEBUG - 2020-09-21 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:20:16 --> Input Class Initialized
INFO - 2020-09-21 10:20:16 --> Language Class Initialized
INFO - 2020-09-21 10:20:16 --> Language Class Initialized
INFO - 2020-09-21 10:20:16 --> Config Class Initialized
INFO - 2020-09-21 10:20:16 --> Loader Class Initialized
INFO - 2020-09-21 10:20:16 --> Helper loaded: url_helper
INFO - 2020-09-21 10:20:16 --> Helper loaded: form_helper
INFO - 2020-09-21 10:20:16 --> Helper loaded: file_helper
INFO - 2020-09-21 10:20:16 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:20:16 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:20:16 --> Upload Class Initialized
INFO - 2020-09-21 10:20:16 --> Controller Class Initialized
ERROR - 2020-09-21 10:20:16 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:20:20 --> Config Class Initialized
INFO - 2020-09-21 10:20:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:20:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:20:20 --> Utf8 Class Initialized
INFO - 2020-09-21 10:20:20 --> URI Class Initialized
INFO - 2020-09-21 10:20:20 --> Router Class Initialized
INFO - 2020-09-21 10:20:20 --> Output Class Initialized
INFO - 2020-09-21 10:20:20 --> Security Class Initialized
DEBUG - 2020-09-21 10:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:20:20 --> Input Class Initialized
INFO - 2020-09-21 10:20:20 --> Language Class Initialized
INFO - 2020-09-21 10:20:20 --> Language Class Initialized
INFO - 2020-09-21 10:20:20 --> Config Class Initialized
INFO - 2020-09-21 10:20:20 --> Loader Class Initialized
INFO - 2020-09-21 10:20:20 --> Helper loaded: url_helper
INFO - 2020-09-21 10:20:20 --> Helper loaded: form_helper
INFO - 2020-09-21 10:20:20 --> Helper loaded: file_helper
INFO - 2020-09-21 10:20:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:20:20 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:20:20 --> Upload Class Initialized
INFO - 2020-09-21 10:20:20 --> Controller Class Initialized
ERROR - 2020-09-21 10:20:20 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:20:22 --> Config Class Initialized
INFO - 2020-09-21 10:20:22 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:20:22 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:20:22 --> Utf8 Class Initialized
INFO - 2020-09-21 10:20:22 --> URI Class Initialized
DEBUG - 2020-09-21 10:20:22 --> No URI present. Default controller set.
INFO - 2020-09-21 10:20:22 --> Router Class Initialized
INFO - 2020-09-21 10:20:22 --> Output Class Initialized
INFO - 2020-09-21 10:20:22 --> Security Class Initialized
DEBUG - 2020-09-21 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:20:22 --> Input Class Initialized
INFO - 2020-09-21 10:20:22 --> Language Class Initialized
INFO - 2020-09-21 10:20:22 --> Language Class Initialized
INFO - 2020-09-21 10:20:22 --> Config Class Initialized
INFO - 2020-09-21 10:20:22 --> Loader Class Initialized
INFO - 2020-09-21 10:20:22 --> Helper loaded: url_helper
INFO - 2020-09-21 10:20:22 --> Helper loaded: form_helper
INFO - 2020-09-21 10:20:22 --> Helper loaded: file_helper
INFO - 2020-09-21 10:20:22 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:20:22 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:20:22 --> Upload Class Initialized
INFO - 2020-09-21 10:20:22 --> Controller Class Initialized
DEBUG - 2020-09-21 10:20:22 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:20:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:20:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:20:22 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:20:22 --> Final output sent to browser
DEBUG - 2020-09-21 10:20:22 --> Total execution time: 0.0505
INFO - 2020-09-21 10:20:45 --> Config Class Initialized
INFO - 2020-09-21 10:20:45 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:20:45 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:20:45 --> Utf8 Class Initialized
INFO - 2020-09-21 10:20:45 --> URI Class Initialized
DEBUG - 2020-09-21 10:20:45 --> No URI present. Default controller set.
INFO - 2020-09-21 10:20:45 --> Router Class Initialized
INFO - 2020-09-21 10:20:45 --> Output Class Initialized
INFO - 2020-09-21 10:20:45 --> Security Class Initialized
DEBUG - 2020-09-21 10:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:20:45 --> Input Class Initialized
INFO - 2020-09-21 10:20:45 --> Language Class Initialized
INFO - 2020-09-21 10:20:45 --> Language Class Initialized
INFO - 2020-09-21 10:20:45 --> Config Class Initialized
INFO - 2020-09-21 10:20:45 --> Loader Class Initialized
INFO - 2020-09-21 10:20:45 --> Helper loaded: url_helper
INFO - 2020-09-21 10:20:45 --> Helper loaded: form_helper
INFO - 2020-09-21 10:20:45 --> Helper loaded: file_helper
INFO - 2020-09-21 10:20:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:20:45 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:20:45 --> Upload Class Initialized
INFO - 2020-09-21 10:20:45 --> Controller Class Initialized
DEBUG - 2020-09-21 10:20:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:20:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:20:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:20:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:20:45 --> Final output sent to browser
DEBUG - 2020-09-21 10:20:45 --> Total execution time: 0.0506
INFO - 2020-09-21 10:20:53 --> Config Class Initialized
INFO - 2020-09-21 10:20:53 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:20:53 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:20:53 --> Utf8 Class Initialized
INFO - 2020-09-21 10:20:53 --> URI Class Initialized
INFO - 2020-09-21 10:20:53 --> Router Class Initialized
INFO - 2020-09-21 10:20:53 --> Output Class Initialized
INFO - 2020-09-21 10:20:53 --> Security Class Initialized
DEBUG - 2020-09-21 10:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:20:53 --> Input Class Initialized
INFO - 2020-09-21 10:20:53 --> Language Class Initialized
INFO - 2020-09-21 10:20:53 --> Language Class Initialized
INFO - 2020-09-21 10:20:53 --> Config Class Initialized
INFO - 2020-09-21 10:20:53 --> Loader Class Initialized
INFO - 2020-09-21 10:20:53 --> Helper loaded: url_helper
INFO - 2020-09-21 10:20:53 --> Helper loaded: form_helper
INFO - 2020-09-21 10:20:53 --> Helper loaded: file_helper
INFO - 2020-09-21 10:20:53 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:20:53 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:20:53 --> Upload Class Initialized
INFO - 2020-09-21 10:20:53 --> Controller Class Initialized
ERROR - 2020-09-21 10:20:53 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:21:01 --> Config Class Initialized
INFO - 2020-09-21 10:21:01 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:21:01 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:21:01 --> Utf8 Class Initialized
INFO - 2020-09-21 10:21:01 --> URI Class Initialized
INFO - 2020-09-21 10:21:01 --> Router Class Initialized
INFO - 2020-09-21 10:21:01 --> Output Class Initialized
INFO - 2020-09-21 10:21:01 --> Security Class Initialized
DEBUG - 2020-09-21 10:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:21:01 --> Input Class Initialized
INFO - 2020-09-21 10:21:01 --> Language Class Initialized
INFO - 2020-09-21 10:21:01 --> Language Class Initialized
INFO - 2020-09-21 10:21:01 --> Config Class Initialized
INFO - 2020-09-21 10:21:01 --> Loader Class Initialized
INFO - 2020-09-21 10:21:01 --> Helper loaded: url_helper
INFO - 2020-09-21 10:21:01 --> Helper loaded: form_helper
INFO - 2020-09-21 10:21:01 --> Helper loaded: file_helper
INFO - 2020-09-21 10:21:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:21:01 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:21:01 --> Upload Class Initialized
INFO - 2020-09-21 10:21:01 --> Controller Class Initialized
ERROR - 2020-09-21 10:21:01 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:21:03 --> Config Class Initialized
INFO - 2020-09-21 10:21:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:21:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:21:03 --> Utf8 Class Initialized
INFO - 2020-09-21 10:21:03 --> URI Class Initialized
DEBUG - 2020-09-21 10:21:03 --> No URI present. Default controller set.
INFO - 2020-09-21 10:21:03 --> Router Class Initialized
INFO - 2020-09-21 10:21:03 --> Output Class Initialized
INFO - 2020-09-21 10:21:03 --> Security Class Initialized
DEBUG - 2020-09-21 10:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:21:03 --> Input Class Initialized
INFO - 2020-09-21 10:21:03 --> Language Class Initialized
INFO - 2020-09-21 10:21:03 --> Language Class Initialized
INFO - 2020-09-21 10:21:03 --> Config Class Initialized
INFO - 2020-09-21 10:21:03 --> Loader Class Initialized
INFO - 2020-09-21 10:21:03 --> Helper loaded: url_helper
INFO - 2020-09-21 10:21:03 --> Helper loaded: form_helper
INFO - 2020-09-21 10:21:03 --> Helper loaded: file_helper
INFO - 2020-09-21 10:21:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:21:03 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:21:03 --> Upload Class Initialized
INFO - 2020-09-21 10:21:03 --> Controller Class Initialized
DEBUG - 2020-09-21 10:21:03 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:21:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:21:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:21:03 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:21:03 --> Final output sent to browser
DEBUG - 2020-09-21 10:21:03 --> Total execution time: 0.0513
INFO - 2020-09-21 10:21:08 --> Config Class Initialized
INFO - 2020-09-21 10:21:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:21:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:21:08 --> Utf8 Class Initialized
INFO - 2020-09-21 10:21:08 --> URI Class Initialized
DEBUG - 2020-09-21 10:21:08 --> No URI present. Default controller set.
INFO - 2020-09-21 10:21:08 --> Router Class Initialized
INFO - 2020-09-21 10:21:08 --> Output Class Initialized
INFO - 2020-09-21 10:21:08 --> Security Class Initialized
DEBUG - 2020-09-21 10:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:21:08 --> Input Class Initialized
INFO - 2020-09-21 10:21:08 --> Language Class Initialized
INFO - 2020-09-21 10:21:08 --> Language Class Initialized
INFO - 2020-09-21 10:21:08 --> Config Class Initialized
INFO - 2020-09-21 10:21:08 --> Loader Class Initialized
INFO - 2020-09-21 10:21:08 --> Helper loaded: url_helper
INFO - 2020-09-21 10:21:08 --> Helper loaded: form_helper
INFO - 2020-09-21 10:21:08 --> Helper loaded: file_helper
INFO - 2020-09-21 10:21:08 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:21:08 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:21:08 --> Upload Class Initialized
INFO - 2020-09-21 10:21:08 --> Controller Class Initialized
DEBUG - 2020-09-21 10:21:08 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:21:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:21:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:21:08 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:21:08 --> Final output sent to browser
DEBUG - 2020-09-21 10:21:08 --> Total execution time: 0.0630
INFO - 2020-09-21 10:21:17 --> Config Class Initialized
INFO - 2020-09-21 10:21:17 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:21:17 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:21:17 --> Utf8 Class Initialized
INFO - 2020-09-21 10:21:17 --> URI Class Initialized
INFO - 2020-09-21 10:21:17 --> Router Class Initialized
INFO - 2020-09-21 10:21:17 --> Output Class Initialized
INFO - 2020-09-21 10:21:17 --> Security Class Initialized
DEBUG - 2020-09-21 10:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:21:17 --> Input Class Initialized
INFO - 2020-09-21 10:21:17 --> Language Class Initialized
INFO - 2020-09-21 10:21:17 --> Language Class Initialized
INFO - 2020-09-21 10:21:17 --> Config Class Initialized
INFO - 2020-09-21 10:21:17 --> Loader Class Initialized
INFO - 2020-09-21 10:21:17 --> Helper loaded: url_helper
INFO - 2020-09-21 10:21:17 --> Helper loaded: form_helper
INFO - 2020-09-21 10:21:17 --> Helper loaded: file_helper
INFO - 2020-09-21 10:21:17 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:21:17 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:21:17 --> Upload Class Initialized
INFO - 2020-09-21 10:21:17 --> Controller Class Initialized
ERROR - 2020-09-21 10:21:17 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:21:29 --> Config Class Initialized
INFO - 2020-09-21 10:21:29 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:21:29 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:21:29 --> Utf8 Class Initialized
INFO - 2020-09-21 10:21:29 --> URI Class Initialized
DEBUG - 2020-09-21 10:21:29 --> No URI present. Default controller set.
INFO - 2020-09-21 10:21:29 --> Router Class Initialized
INFO - 2020-09-21 10:21:29 --> Output Class Initialized
INFO - 2020-09-21 10:21:29 --> Security Class Initialized
DEBUG - 2020-09-21 10:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:21:29 --> Input Class Initialized
INFO - 2020-09-21 10:21:29 --> Language Class Initialized
INFO - 2020-09-21 10:21:29 --> Language Class Initialized
INFO - 2020-09-21 10:21:29 --> Config Class Initialized
INFO - 2020-09-21 10:21:29 --> Loader Class Initialized
INFO - 2020-09-21 10:21:29 --> Helper loaded: url_helper
INFO - 2020-09-21 10:21:29 --> Helper loaded: form_helper
INFO - 2020-09-21 10:21:29 --> Helper loaded: file_helper
INFO - 2020-09-21 10:21:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:21:29 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:21:29 --> Upload Class Initialized
INFO - 2020-09-21 10:21:29 --> Controller Class Initialized
DEBUG - 2020-09-21 10:21:29 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:21:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:21:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:21:29 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:21:29 --> Final output sent to browser
DEBUG - 2020-09-21 10:21:29 --> Total execution time: 0.0380
INFO - 2020-09-21 10:34:35 --> Config Class Initialized
INFO - 2020-09-21 10:34:35 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:34:35 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:34:35 --> Utf8 Class Initialized
INFO - 2020-09-21 10:34:35 --> URI Class Initialized
DEBUG - 2020-09-21 10:34:35 --> No URI present. Default controller set.
INFO - 2020-09-21 10:34:35 --> Router Class Initialized
INFO - 2020-09-21 10:34:35 --> Output Class Initialized
INFO - 2020-09-21 10:34:35 --> Security Class Initialized
DEBUG - 2020-09-21 10:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:34:35 --> Input Class Initialized
INFO - 2020-09-21 10:34:35 --> Language Class Initialized
INFO - 2020-09-21 10:34:35 --> Language Class Initialized
INFO - 2020-09-21 10:34:35 --> Config Class Initialized
INFO - 2020-09-21 10:34:35 --> Loader Class Initialized
INFO - 2020-09-21 10:34:35 --> Helper loaded: url_helper
INFO - 2020-09-21 10:34:35 --> Helper loaded: form_helper
INFO - 2020-09-21 10:34:35 --> Helper loaded: file_helper
INFO - 2020-09-21 10:34:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:34:35 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:34:35 --> Upload Class Initialized
INFO - 2020-09-21 10:34:35 --> Controller Class Initialized
DEBUG - 2020-09-21 10:34:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:34:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:34:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:34:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:34:35 --> Final output sent to browser
DEBUG - 2020-09-21 10:34:35 --> Total execution time: 0.0514
INFO - 2020-09-21 10:39:29 --> Config Class Initialized
INFO - 2020-09-21 10:39:29 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:39:29 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:39:29 --> Utf8 Class Initialized
INFO - 2020-09-21 10:39:29 --> URI Class Initialized
INFO - 2020-09-21 10:39:29 --> Router Class Initialized
INFO - 2020-09-21 10:39:29 --> Output Class Initialized
INFO - 2020-09-21 10:39:29 --> Security Class Initialized
DEBUG - 2020-09-21 10:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:39:29 --> Input Class Initialized
INFO - 2020-09-21 10:39:29 --> Language Class Initialized
INFO - 2020-09-21 10:39:29 --> Language Class Initialized
INFO - 2020-09-21 10:39:29 --> Config Class Initialized
INFO - 2020-09-21 10:39:29 --> Loader Class Initialized
INFO - 2020-09-21 10:39:29 --> Helper loaded: url_helper
INFO - 2020-09-21 10:39:29 --> Helper loaded: form_helper
INFO - 2020-09-21 10:39:29 --> Helper loaded: file_helper
INFO - 2020-09-21 10:39:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:39:29 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:39:29 --> Upload Class Initialized
INFO - 2020-09-21 10:39:29 --> Controller Class Initialized
ERROR - 2020-09-21 10:39:29 --> 404 Page Not Found: /index
INFO - 2020-09-21 10:39:30 --> Config Class Initialized
INFO - 2020-09-21 10:39:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:39:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:39:30 --> Utf8 Class Initialized
INFO - 2020-09-21 10:39:30 --> URI Class Initialized
DEBUG - 2020-09-21 10:39:30 --> No URI present. Default controller set.
INFO - 2020-09-21 10:39:30 --> Router Class Initialized
INFO - 2020-09-21 10:39:30 --> Output Class Initialized
INFO - 2020-09-21 10:39:30 --> Security Class Initialized
DEBUG - 2020-09-21 10:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:39:30 --> Input Class Initialized
INFO - 2020-09-21 10:39:30 --> Language Class Initialized
INFO - 2020-09-21 10:39:30 --> Language Class Initialized
INFO - 2020-09-21 10:39:30 --> Config Class Initialized
INFO - 2020-09-21 10:39:30 --> Loader Class Initialized
INFO - 2020-09-21 10:39:30 --> Helper loaded: url_helper
INFO - 2020-09-21 10:39:30 --> Helper loaded: form_helper
INFO - 2020-09-21 10:39:30 --> Helper loaded: file_helper
INFO - 2020-09-21 10:39:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:39:30 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:39:30 --> Upload Class Initialized
INFO - 2020-09-21 10:39:30 --> Controller Class Initialized
DEBUG - 2020-09-21 10:39:30 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:39:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:39:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:39:30 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:39:30 --> Final output sent to browser
DEBUG - 2020-09-21 10:39:30 --> Total execution time: 0.0459
INFO - 2020-09-21 10:43:54 --> Config Class Initialized
INFO - 2020-09-21 10:43:54 --> Hooks Class Initialized
DEBUG - 2020-09-21 10:43:54 --> UTF-8 Support Enabled
INFO - 2020-09-21 10:43:54 --> Utf8 Class Initialized
INFO - 2020-09-21 10:43:54 --> URI Class Initialized
DEBUG - 2020-09-21 10:43:54 --> No URI present. Default controller set.
INFO - 2020-09-21 10:43:54 --> Router Class Initialized
INFO - 2020-09-21 10:43:54 --> Output Class Initialized
INFO - 2020-09-21 10:43:54 --> Security Class Initialized
DEBUG - 2020-09-21 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 10:43:54 --> Input Class Initialized
INFO - 2020-09-21 10:43:54 --> Language Class Initialized
INFO - 2020-09-21 10:43:54 --> Language Class Initialized
INFO - 2020-09-21 10:43:54 --> Config Class Initialized
INFO - 2020-09-21 10:43:54 --> Loader Class Initialized
INFO - 2020-09-21 10:43:54 --> Helper loaded: url_helper
INFO - 2020-09-21 10:43:54 --> Helper loaded: form_helper
INFO - 2020-09-21 10:43:54 --> Helper loaded: file_helper
INFO - 2020-09-21 10:43:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 10:43:54 --> Database Driver Class Initialized
DEBUG - 2020-09-21 10:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 10:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 10:43:54 --> Upload Class Initialized
INFO - 2020-09-21 10:43:55 --> Controller Class Initialized
DEBUG - 2020-09-21 10:43:55 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 10:43:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 10:43:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 10:43:55 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 10:43:55 --> Final output sent to browser
DEBUG - 2020-09-21 10:43:55 --> Total execution time: 0.0549
INFO - 2020-09-21 11:08:54 --> Config Class Initialized
INFO - 2020-09-21 11:08:54 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:08:54 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:08:54 --> Utf8 Class Initialized
INFO - 2020-09-21 11:08:54 --> URI Class Initialized
INFO - 2020-09-21 11:08:54 --> Router Class Initialized
INFO - 2020-09-21 11:08:54 --> Output Class Initialized
INFO - 2020-09-21 11:08:54 --> Security Class Initialized
DEBUG - 2020-09-21 11:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:08:54 --> Input Class Initialized
INFO - 2020-09-21 11:08:54 --> Language Class Initialized
INFO - 2020-09-21 11:08:54 --> Language Class Initialized
INFO - 2020-09-21 11:08:54 --> Config Class Initialized
INFO - 2020-09-21 11:08:54 --> Loader Class Initialized
INFO - 2020-09-21 11:08:54 --> Helper loaded: url_helper
INFO - 2020-09-21 11:08:54 --> Helper loaded: form_helper
INFO - 2020-09-21 11:08:54 --> Helper loaded: file_helper
INFO - 2020-09-21 11:08:54 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 11:08:54 --> Database Driver Class Initialized
DEBUG - 2020-09-21 11:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 11:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:08:54 --> Upload Class Initialized
INFO - 2020-09-21 11:08:54 --> Controller Class Initialized
ERROR - 2020-09-21 11:08:54 --> 404 Page Not Found: /index
INFO - 2020-09-21 11:10:34 --> Config Class Initialized
INFO - 2020-09-21 11:10:34 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:10:34 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:10:34 --> Utf8 Class Initialized
INFO - 2020-09-21 11:10:34 --> URI Class Initialized
DEBUG - 2020-09-21 11:10:34 --> No URI present. Default controller set.
INFO - 2020-09-21 11:10:34 --> Router Class Initialized
INFO - 2020-09-21 11:10:34 --> Output Class Initialized
INFO - 2020-09-21 11:10:34 --> Security Class Initialized
DEBUG - 2020-09-21 11:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:10:34 --> Input Class Initialized
INFO - 2020-09-21 11:10:34 --> Language Class Initialized
INFO - 2020-09-21 11:10:34 --> Language Class Initialized
INFO - 2020-09-21 11:10:34 --> Config Class Initialized
INFO - 2020-09-21 11:10:34 --> Loader Class Initialized
INFO - 2020-09-21 11:10:34 --> Helper loaded: url_helper
INFO - 2020-09-21 11:10:34 --> Helper loaded: form_helper
INFO - 2020-09-21 11:10:34 --> Helper loaded: file_helper
INFO - 2020-09-21 11:10:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 11:10:34 --> Database Driver Class Initialized
DEBUG - 2020-09-21 11:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 11:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:10:34 --> Upload Class Initialized
INFO - 2020-09-21 11:10:34 --> Controller Class Initialized
DEBUG - 2020-09-21 11:10:34 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 11:10:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 11:10:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 11:10:34 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 11:10:34 --> Final output sent to browser
DEBUG - 2020-09-21 11:10:34 --> Total execution time: 0.0605
INFO - 2020-09-21 11:19:25 --> Config Class Initialized
INFO - 2020-09-21 11:19:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:19:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:19:25 --> Utf8 Class Initialized
INFO - 2020-09-21 11:19:25 --> URI Class Initialized
DEBUG - 2020-09-21 11:19:25 --> No URI present. Default controller set.
INFO - 2020-09-21 11:19:25 --> Router Class Initialized
INFO - 2020-09-21 11:19:25 --> Output Class Initialized
INFO - 2020-09-21 11:19:25 --> Security Class Initialized
DEBUG - 2020-09-21 11:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:19:25 --> Input Class Initialized
INFO - 2020-09-21 11:19:25 --> Language Class Initialized
INFO - 2020-09-21 11:19:25 --> Language Class Initialized
INFO - 2020-09-21 11:19:25 --> Config Class Initialized
INFO - 2020-09-21 11:19:25 --> Loader Class Initialized
INFO - 2020-09-21 11:19:25 --> Helper loaded: url_helper
INFO - 2020-09-21 11:19:25 --> Helper loaded: form_helper
INFO - 2020-09-21 11:19:25 --> Helper loaded: file_helper
INFO - 2020-09-21 11:19:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 11:19:25 --> Database Driver Class Initialized
DEBUG - 2020-09-21 11:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 11:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:19:25 --> Upload Class Initialized
INFO - 2020-09-21 11:19:25 --> Controller Class Initialized
DEBUG - 2020-09-21 11:19:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 11:19:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 11:19:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 11:19:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 11:19:25 --> Final output sent to browser
DEBUG - 2020-09-21 11:19:25 --> Total execution time: 0.0501
INFO - 2020-09-21 11:19:56 --> Config Class Initialized
INFO - 2020-09-21 11:19:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:19:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:19:56 --> Utf8 Class Initialized
INFO - 2020-09-21 11:19:56 --> URI Class Initialized
DEBUG - 2020-09-21 11:19:56 --> No URI present. Default controller set.
INFO - 2020-09-21 11:19:56 --> Router Class Initialized
INFO - 2020-09-21 11:19:56 --> Output Class Initialized
INFO - 2020-09-21 11:19:56 --> Security Class Initialized
DEBUG - 2020-09-21 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:19:56 --> Input Class Initialized
INFO - 2020-09-21 11:19:56 --> Language Class Initialized
INFO - 2020-09-21 11:19:56 --> Language Class Initialized
INFO - 2020-09-21 11:19:56 --> Config Class Initialized
INFO - 2020-09-21 11:19:56 --> Loader Class Initialized
INFO - 2020-09-21 11:19:56 --> Helper loaded: url_helper
INFO - 2020-09-21 11:19:56 --> Helper loaded: form_helper
INFO - 2020-09-21 11:19:56 --> Helper loaded: file_helper
INFO - 2020-09-21 11:19:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 11:19:56 --> Database Driver Class Initialized
DEBUG - 2020-09-21 11:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:19:56 --> Upload Class Initialized
INFO - 2020-09-21 11:19:56 --> Controller Class Initialized
DEBUG - 2020-09-21 11:19:56 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 11:19:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 11:19:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 11:19:56 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 11:19:56 --> Final output sent to browser
DEBUG - 2020-09-21 11:19:56 --> Total execution time: 0.0483
INFO - 2020-09-21 11:49:35 --> Config Class Initialized
INFO - 2020-09-21 11:49:35 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:49:35 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:49:35 --> Utf8 Class Initialized
INFO - 2020-09-21 11:49:35 --> URI Class Initialized
DEBUG - 2020-09-21 11:49:35 --> No URI present. Default controller set.
INFO - 2020-09-21 11:49:35 --> Router Class Initialized
INFO - 2020-09-21 11:49:35 --> Output Class Initialized
INFO - 2020-09-21 11:49:35 --> Security Class Initialized
DEBUG - 2020-09-21 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:49:35 --> Input Class Initialized
INFO - 2020-09-21 11:49:35 --> Language Class Initialized
INFO - 2020-09-21 11:49:35 --> Language Class Initialized
INFO - 2020-09-21 11:49:35 --> Config Class Initialized
INFO - 2020-09-21 11:49:35 --> Loader Class Initialized
INFO - 2020-09-21 11:49:35 --> Helper loaded: url_helper
INFO - 2020-09-21 11:49:35 --> Helper loaded: form_helper
INFO - 2020-09-21 11:49:35 --> Helper loaded: file_helper
INFO - 2020-09-21 11:49:35 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 11:49:35 --> Database Driver Class Initialized
DEBUG - 2020-09-21 11:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 11:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:49:35 --> Upload Class Initialized
INFO - 2020-09-21 11:49:35 --> Controller Class Initialized
DEBUG - 2020-09-21 11:49:35 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 11:49:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 11:49:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 11:49:35 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 11:49:35 --> Final output sent to browser
DEBUG - 2020-09-21 11:49:35 --> Total execution time: 0.0536
INFO - 2020-09-21 12:21:19 --> Config Class Initialized
INFO - 2020-09-21 12:21:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:21:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:21:19 --> Utf8 Class Initialized
INFO - 2020-09-21 12:21:19 --> URI Class Initialized
DEBUG - 2020-09-21 12:21:19 --> No URI present. Default controller set.
INFO - 2020-09-21 12:21:19 --> Router Class Initialized
INFO - 2020-09-21 12:21:19 --> Output Class Initialized
INFO - 2020-09-21 12:21:19 --> Security Class Initialized
DEBUG - 2020-09-21 12:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:21:19 --> Input Class Initialized
INFO - 2020-09-21 12:21:19 --> Language Class Initialized
INFO - 2020-09-21 12:21:19 --> Language Class Initialized
INFO - 2020-09-21 12:21:19 --> Config Class Initialized
INFO - 2020-09-21 12:21:19 --> Loader Class Initialized
INFO - 2020-09-21 12:21:19 --> Helper loaded: url_helper
INFO - 2020-09-21 12:21:19 --> Helper loaded: form_helper
INFO - 2020-09-21 12:21:19 --> Helper loaded: file_helper
INFO - 2020-09-21 12:21:19 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 12:21:19 --> Database Driver Class Initialized
DEBUG - 2020-09-21 12:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 12:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:21:19 --> Upload Class Initialized
INFO - 2020-09-21 12:21:19 --> Controller Class Initialized
DEBUG - 2020-09-21 12:21:19 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 12:21:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 12:21:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 12:21:19 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 12:21:19 --> Final output sent to browser
DEBUG - 2020-09-21 12:21:19 --> Total execution time: 0.0498
INFO - 2020-09-21 12:21:21 --> Config Class Initialized
INFO - 2020-09-21 12:21:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:21:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:21:21 --> Utf8 Class Initialized
INFO - 2020-09-21 12:21:21 --> URI Class Initialized
INFO - 2020-09-21 12:21:21 --> Router Class Initialized
INFO - 2020-09-21 12:21:21 --> Output Class Initialized
INFO - 2020-09-21 12:21:21 --> Security Class Initialized
DEBUG - 2020-09-21 12:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:21:21 --> Input Class Initialized
INFO - 2020-09-21 12:21:21 --> Language Class Initialized
INFO - 2020-09-21 12:21:21 --> Language Class Initialized
INFO - 2020-09-21 12:21:21 --> Config Class Initialized
INFO - 2020-09-21 12:21:21 --> Loader Class Initialized
INFO - 2020-09-21 12:21:21 --> Helper loaded: url_helper
INFO - 2020-09-21 12:21:21 --> Helper loaded: form_helper
INFO - 2020-09-21 12:21:21 --> Helper loaded: file_helper
INFO - 2020-09-21 12:21:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 12:21:21 --> Database Driver Class Initialized
DEBUG - 2020-09-21 12:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 12:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:21:21 --> Upload Class Initialized
INFO - 2020-09-21 12:21:21 --> Controller Class Initialized
ERROR - 2020-09-21 12:21:21 --> 404 Page Not Found: /index
INFO - 2020-09-21 12:21:26 --> Config Class Initialized
INFO - 2020-09-21 12:21:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:21:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:21:26 --> Utf8 Class Initialized
INFO - 2020-09-21 12:21:26 --> URI Class Initialized
INFO - 2020-09-21 12:21:26 --> Router Class Initialized
INFO - 2020-09-21 12:21:26 --> Output Class Initialized
INFO - 2020-09-21 12:21:26 --> Security Class Initialized
DEBUG - 2020-09-21 12:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:21:26 --> Input Class Initialized
INFO - 2020-09-21 12:21:26 --> Language Class Initialized
INFO - 2020-09-21 12:21:26 --> Language Class Initialized
INFO - 2020-09-21 12:21:26 --> Config Class Initialized
INFO - 2020-09-21 12:21:26 --> Loader Class Initialized
INFO - 2020-09-21 12:21:26 --> Helper loaded: url_helper
INFO - 2020-09-21 12:21:26 --> Helper loaded: form_helper
INFO - 2020-09-21 12:21:26 --> Helper loaded: file_helper
INFO - 2020-09-21 12:21:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 12:21:26 --> Database Driver Class Initialized
DEBUG - 2020-09-21 12:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 12:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:21:26 --> Upload Class Initialized
INFO - 2020-09-21 12:21:26 --> Controller Class Initialized
ERROR - 2020-09-21 12:21:26 --> 404 Page Not Found: /index
INFO - 2020-09-21 12:21:28 --> Config Class Initialized
INFO - 2020-09-21 12:21:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:21:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:21:28 --> Utf8 Class Initialized
INFO - 2020-09-21 12:21:28 --> URI Class Initialized
DEBUG - 2020-09-21 12:21:28 --> No URI present. Default controller set.
INFO - 2020-09-21 12:21:28 --> Router Class Initialized
INFO - 2020-09-21 12:21:28 --> Output Class Initialized
INFO - 2020-09-21 12:21:28 --> Security Class Initialized
DEBUG - 2020-09-21 12:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:21:28 --> Input Class Initialized
INFO - 2020-09-21 12:21:28 --> Language Class Initialized
INFO - 2020-09-21 12:21:28 --> Language Class Initialized
INFO - 2020-09-21 12:21:28 --> Config Class Initialized
INFO - 2020-09-21 12:21:28 --> Loader Class Initialized
INFO - 2020-09-21 12:21:28 --> Helper loaded: url_helper
INFO - 2020-09-21 12:21:28 --> Helper loaded: form_helper
INFO - 2020-09-21 12:21:28 --> Helper loaded: file_helper
INFO - 2020-09-21 12:21:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 12:21:28 --> Database Driver Class Initialized
DEBUG - 2020-09-21 12:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 12:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:21:28 --> Upload Class Initialized
INFO - 2020-09-21 12:21:28 --> Controller Class Initialized
DEBUG - 2020-09-21 12:21:28 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 12:21:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 12:21:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 12:21:28 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 12:21:28 --> Final output sent to browser
DEBUG - 2020-09-21 12:21:28 --> Total execution time: 0.0376
INFO - 2020-09-21 13:00:49 --> Config Class Initialized
INFO - 2020-09-21 13:00:49 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:00:49 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:00:49 --> Utf8 Class Initialized
INFO - 2020-09-21 13:00:49 --> URI Class Initialized
DEBUG - 2020-09-21 13:00:49 --> No URI present. Default controller set.
INFO - 2020-09-21 13:00:49 --> Router Class Initialized
INFO - 2020-09-21 13:00:49 --> Output Class Initialized
INFO - 2020-09-21 13:00:49 --> Security Class Initialized
DEBUG - 2020-09-21 13:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:00:49 --> Input Class Initialized
INFO - 2020-09-21 13:00:49 --> Language Class Initialized
INFO - 2020-09-21 13:00:49 --> Language Class Initialized
INFO - 2020-09-21 13:00:49 --> Config Class Initialized
INFO - 2020-09-21 13:00:49 --> Loader Class Initialized
INFO - 2020-09-21 13:00:49 --> Helper loaded: url_helper
INFO - 2020-09-21 13:00:49 --> Helper loaded: form_helper
INFO - 2020-09-21 13:00:49 --> Helper loaded: file_helper
INFO - 2020-09-21 13:00:49 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:00:49 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:00:49 --> Upload Class Initialized
INFO - 2020-09-21 13:00:49 --> Controller Class Initialized
DEBUG - 2020-09-21 13:00:49 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 13:00:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 13:00:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 13:00:49 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 13:00:49 --> Final output sent to browser
DEBUG - 2020-09-21 13:00:49 --> Total execution time: 0.0469
INFO - 2020-09-21 13:00:50 --> Config Class Initialized
INFO - 2020-09-21 13:00:50 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:00:50 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:00:50 --> Utf8 Class Initialized
INFO - 2020-09-21 13:00:50 --> URI Class Initialized
INFO - 2020-09-21 13:00:50 --> Router Class Initialized
INFO - 2020-09-21 13:00:50 --> Output Class Initialized
INFO - 2020-09-21 13:00:50 --> Security Class Initialized
DEBUG - 2020-09-21 13:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:00:50 --> Input Class Initialized
INFO - 2020-09-21 13:00:50 --> Language Class Initialized
INFO - 2020-09-21 13:00:50 --> Language Class Initialized
INFO - 2020-09-21 13:00:50 --> Config Class Initialized
INFO - 2020-09-21 13:00:50 --> Loader Class Initialized
INFO - 2020-09-21 13:00:50 --> Helper loaded: url_helper
INFO - 2020-09-21 13:00:50 --> Helper loaded: form_helper
INFO - 2020-09-21 13:00:50 --> Helper loaded: file_helper
INFO - 2020-09-21 13:00:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:00:50 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:00:50 --> Upload Class Initialized
INFO - 2020-09-21 13:00:50 --> Controller Class Initialized
ERROR - 2020-09-21 13:00:50 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:09:25 --> Config Class Initialized
INFO - 2020-09-21 13:09:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:09:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:09:25 --> Utf8 Class Initialized
INFO - 2020-09-21 13:09:25 --> URI Class Initialized
INFO - 2020-09-21 13:09:25 --> Router Class Initialized
INFO - 2020-09-21 13:09:25 --> Output Class Initialized
INFO - 2020-09-21 13:09:25 --> Security Class Initialized
DEBUG - 2020-09-21 13:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:09:25 --> Input Class Initialized
INFO - 2020-09-21 13:09:25 --> Language Class Initialized
INFO - 2020-09-21 13:09:25 --> Language Class Initialized
INFO - 2020-09-21 13:09:25 --> Config Class Initialized
INFO - 2020-09-21 13:09:25 --> Loader Class Initialized
INFO - 2020-09-21 13:09:25 --> Helper loaded: url_helper
INFO - 2020-09-21 13:09:25 --> Helper loaded: form_helper
INFO - 2020-09-21 13:09:25 --> Helper loaded: file_helper
INFO - 2020-09-21 13:09:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:09:25 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:09:25 --> Upload Class Initialized
INFO - 2020-09-21 13:09:25 --> Controller Class Initialized
ERROR - 2020-09-21 13:09:25 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:09:30 --> Config Class Initialized
INFO - 2020-09-21 13:09:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:09:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:09:30 --> Utf8 Class Initialized
INFO - 2020-09-21 13:09:30 --> URI Class Initialized
INFO - 2020-09-21 13:09:30 --> Router Class Initialized
INFO - 2020-09-21 13:09:30 --> Output Class Initialized
INFO - 2020-09-21 13:09:30 --> Security Class Initialized
DEBUG - 2020-09-21 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:09:30 --> Input Class Initialized
INFO - 2020-09-21 13:09:30 --> Language Class Initialized
INFO - 2020-09-21 13:09:30 --> Language Class Initialized
INFO - 2020-09-21 13:09:30 --> Config Class Initialized
INFO - 2020-09-21 13:09:30 --> Loader Class Initialized
INFO - 2020-09-21 13:09:30 --> Helper loaded: url_helper
INFO - 2020-09-21 13:09:30 --> Helper loaded: form_helper
INFO - 2020-09-21 13:09:30 --> Helper loaded: file_helper
INFO - 2020-09-21 13:09:30 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:09:30 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:09:30 --> Upload Class Initialized
INFO - 2020-09-21 13:09:30 --> Controller Class Initialized
ERROR - 2020-09-21 13:09:30 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:09:33 --> Config Class Initialized
INFO - 2020-09-21 13:09:33 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:09:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:09:33 --> Utf8 Class Initialized
INFO - 2020-09-21 13:09:33 --> URI Class Initialized
DEBUG - 2020-09-21 13:09:33 --> No URI present. Default controller set.
INFO - 2020-09-21 13:09:33 --> Router Class Initialized
INFO - 2020-09-21 13:09:33 --> Output Class Initialized
INFO - 2020-09-21 13:09:33 --> Security Class Initialized
DEBUG - 2020-09-21 13:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:09:33 --> Input Class Initialized
INFO - 2020-09-21 13:09:33 --> Language Class Initialized
INFO - 2020-09-21 13:09:33 --> Language Class Initialized
INFO - 2020-09-21 13:09:33 --> Config Class Initialized
INFO - 2020-09-21 13:09:33 --> Loader Class Initialized
INFO - 2020-09-21 13:09:33 --> Helper loaded: url_helper
INFO - 2020-09-21 13:09:33 --> Helper loaded: form_helper
INFO - 2020-09-21 13:09:33 --> Helper loaded: file_helper
INFO - 2020-09-21 13:09:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:09:33 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:09:33 --> Upload Class Initialized
INFO - 2020-09-21 13:09:33 --> Controller Class Initialized
DEBUG - 2020-09-21 13:09:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 13:09:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 13:09:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 13:09:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 13:09:33 --> Final output sent to browser
DEBUG - 2020-09-21 13:09:33 --> Total execution time: 0.0410
INFO - 2020-09-21 13:12:31 --> Config Class Initialized
INFO - 2020-09-21 13:12:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:12:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:12:31 --> Utf8 Class Initialized
INFO - 2020-09-21 13:12:31 --> URI Class Initialized
INFO - 2020-09-21 13:12:31 --> Router Class Initialized
INFO - 2020-09-21 13:12:31 --> Output Class Initialized
INFO - 2020-09-21 13:12:31 --> Security Class Initialized
DEBUG - 2020-09-21 13:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:12:31 --> Input Class Initialized
INFO - 2020-09-21 13:12:31 --> Language Class Initialized
INFO - 2020-09-21 13:12:31 --> Language Class Initialized
INFO - 2020-09-21 13:12:31 --> Config Class Initialized
INFO - 2020-09-21 13:12:31 --> Loader Class Initialized
INFO - 2020-09-21 13:12:31 --> Helper loaded: url_helper
INFO - 2020-09-21 13:12:31 --> Helper loaded: form_helper
INFO - 2020-09-21 13:12:31 --> Helper loaded: file_helper
INFO - 2020-09-21 13:12:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:12:31 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:12:31 --> Upload Class Initialized
INFO - 2020-09-21 13:12:31 --> Controller Class Initialized
ERROR - 2020-09-21 13:12:31 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:12:32 --> Config Class Initialized
INFO - 2020-09-21 13:12:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:12:32 --> Utf8 Class Initialized
INFO - 2020-09-21 13:12:32 --> URI Class Initialized
INFO - 2020-09-21 13:12:32 --> Router Class Initialized
INFO - 2020-09-21 13:12:32 --> Output Class Initialized
INFO - 2020-09-21 13:12:32 --> Security Class Initialized
DEBUG - 2020-09-21 13:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:12:32 --> Input Class Initialized
INFO - 2020-09-21 13:12:32 --> Language Class Initialized
INFO - 2020-09-21 13:12:32 --> Language Class Initialized
INFO - 2020-09-21 13:12:32 --> Config Class Initialized
INFO - 2020-09-21 13:12:32 --> Loader Class Initialized
INFO - 2020-09-21 13:12:32 --> Helper loaded: url_helper
INFO - 2020-09-21 13:12:32 --> Helper loaded: form_helper
INFO - 2020-09-21 13:12:32 --> Helper loaded: file_helper
INFO - 2020-09-21 13:12:32 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:12:32 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:12:32 --> Upload Class Initialized
INFO - 2020-09-21 13:12:32 --> Controller Class Initialized
ERROR - 2020-09-21 13:12:32 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:12:34 --> Config Class Initialized
INFO - 2020-09-21 13:12:34 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:12:34 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:12:34 --> Utf8 Class Initialized
INFO - 2020-09-21 13:12:34 --> URI Class Initialized
INFO - 2020-09-21 13:12:34 --> Router Class Initialized
INFO - 2020-09-21 13:12:34 --> Output Class Initialized
INFO - 2020-09-21 13:12:34 --> Security Class Initialized
DEBUG - 2020-09-21 13:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:12:34 --> Input Class Initialized
INFO - 2020-09-21 13:12:34 --> Language Class Initialized
INFO - 2020-09-21 13:12:34 --> Language Class Initialized
INFO - 2020-09-21 13:12:34 --> Config Class Initialized
INFO - 2020-09-21 13:12:34 --> Loader Class Initialized
INFO - 2020-09-21 13:12:34 --> Helper loaded: url_helper
INFO - 2020-09-21 13:12:34 --> Helper loaded: form_helper
INFO - 2020-09-21 13:12:34 --> Helper loaded: file_helper
INFO - 2020-09-21 13:12:34 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:12:34 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:12:34 --> Upload Class Initialized
INFO - 2020-09-21 13:12:34 --> Controller Class Initialized
ERROR - 2020-09-21 13:12:34 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:12:41 --> Config Class Initialized
INFO - 2020-09-21 13:12:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:12:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:12:41 --> Utf8 Class Initialized
INFO - 2020-09-21 13:12:41 --> URI Class Initialized
INFO - 2020-09-21 13:12:41 --> Router Class Initialized
INFO - 2020-09-21 13:12:41 --> Output Class Initialized
INFO - 2020-09-21 13:12:41 --> Security Class Initialized
DEBUG - 2020-09-21 13:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:12:41 --> Input Class Initialized
INFO - 2020-09-21 13:12:41 --> Language Class Initialized
INFO - 2020-09-21 13:12:41 --> Language Class Initialized
INFO - 2020-09-21 13:12:41 --> Config Class Initialized
INFO - 2020-09-21 13:12:41 --> Loader Class Initialized
INFO - 2020-09-21 13:12:41 --> Helper loaded: url_helper
INFO - 2020-09-21 13:12:41 --> Helper loaded: form_helper
INFO - 2020-09-21 13:12:41 --> Helper loaded: file_helper
INFO - 2020-09-21 13:12:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:12:41 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:12:41 --> Upload Class Initialized
INFO - 2020-09-21 13:12:41 --> Controller Class Initialized
ERROR - 2020-09-21 13:12:41 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:33:41 --> Config Class Initialized
INFO - 2020-09-21 13:33:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:33:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:33:41 --> Utf8 Class Initialized
INFO - 2020-09-21 13:33:41 --> URI Class Initialized
DEBUG - 2020-09-21 13:33:41 --> No URI present. Default controller set.
INFO - 2020-09-21 13:33:41 --> Router Class Initialized
INFO - 2020-09-21 13:33:41 --> Output Class Initialized
INFO - 2020-09-21 13:33:41 --> Security Class Initialized
DEBUG - 2020-09-21 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:33:41 --> Input Class Initialized
INFO - 2020-09-21 13:33:41 --> Language Class Initialized
INFO - 2020-09-21 13:33:41 --> Language Class Initialized
INFO - 2020-09-21 13:33:41 --> Config Class Initialized
INFO - 2020-09-21 13:33:41 --> Loader Class Initialized
INFO - 2020-09-21 13:33:41 --> Helper loaded: url_helper
INFO - 2020-09-21 13:33:41 --> Helper loaded: form_helper
INFO - 2020-09-21 13:33:41 --> Helper loaded: file_helper
INFO - 2020-09-21 13:33:41 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:33:41 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:33:41 --> Upload Class Initialized
INFO - 2020-09-21 13:33:41 --> Controller Class Initialized
DEBUG - 2020-09-21 13:33:41 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 13:33:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 13:33:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 13:33:41 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 13:33:41 --> Final output sent to browser
DEBUG - 2020-09-21 13:33:41 --> Total execution time: 0.0472
INFO - 2020-09-21 13:34:44 --> Config Class Initialized
INFO - 2020-09-21 13:34:44 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:34:44 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:34:44 --> Utf8 Class Initialized
INFO - 2020-09-21 13:34:44 --> URI Class Initialized
DEBUG - 2020-09-21 13:34:44 --> No URI present. Default controller set.
INFO - 2020-09-21 13:34:44 --> Router Class Initialized
INFO - 2020-09-21 13:34:44 --> Output Class Initialized
INFO - 2020-09-21 13:34:44 --> Security Class Initialized
DEBUG - 2020-09-21 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:34:44 --> Input Class Initialized
INFO - 2020-09-21 13:34:44 --> Language Class Initialized
INFO - 2020-09-21 13:34:44 --> Language Class Initialized
INFO - 2020-09-21 13:34:44 --> Config Class Initialized
INFO - 2020-09-21 13:34:44 --> Loader Class Initialized
INFO - 2020-09-21 13:34:44 --> Helper loaded: url_helper
INFO - 2020-09-21 13:34:44 --> Helper loaded: form_helper
INFO - 2020-09-21 13:34:44 --> Helper loaded: file_helper
INFO - 2020-09-21 13:34:44 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:34:44 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:34:44 --> Upload Class Initialized
INFO - 2020-09-21 13:34:44 --> Controller Class Initialized
DEBUG - 2020-09-21 13:34:44 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 13:34:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 13:34:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 13:34:44 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 13:34:44 --> Final output sent to browser
DEBUG - 2020-09-21 13:34:44 --> Total execution time: 0.0445
INFO - 2020-09-21 13:35:04 --> Config Class Initialized
INFO - 2020-09-21 13:35:04 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:35:04 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:35:04 --> Utf8 Class Initialized
INFO - 2020-09-21 13:35:04 --> URI Class Initialized
INFO - 2020-09-21 13:35:04 --> Router Class Initialized
INFO - 2020-09-21 13:35:04 --> Output Class Initialized
INFO - 2020-09-21 13:35:04 --> Security Class Initialized
DEBUG - 2020-09-21 13:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:35:04 --> Input Class Initialized
INFO - 2020-09-21 13:35:04 --> Language Class Initialized
INFO - 2020-09-21 13:35:04 --> Language Class Initialized
INFO - 2020-09-21 13:35:04 --> Config Class Initialized
INFO - 2020-09-21 13:35:04 --> Loader Class Initialized
INFO - 2020-09-21 13:35:04 --> Helper loaded: url_helper
INFO - 2020-09-21 13:35:04 --> Helper loaded: form_helper
INFO - 2020-09-21 13:35:04 --> Helper loaded: file_helper
INFO - 2020-09-21 13:35:04 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:35:04 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:35:04 --> Upload Class Initialized
INFO - 2020-09-21 13:35:04 --> Controller Class Initialized
ERROR - 2020-09-21 13:35:04 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:35:06 --> Config Class Initialized
INFO - 2020-09-21 13:35:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:35:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:35:06 --> Utf8 Class Initialized
INFO - 2020-09-21 13:35:06 --> URI Class Initialized
INFO - 2020-09-21 13:35:06 --> Router Class Initialized
INFO - 2020-09-21 13:35:06 --> Output Class Initialized
INFO - 2020-09-21 13:35:06 --> Security Class Initialized
DEBUG - 2020-09-21 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:35:06 --> Input Class Initialized
INFO - 2020-09-21 13:35:06 --> Language Class Initialized
INFO - 2020-09-21 13:35:06 --> Language Class Initialized
INFO - 2020-09-21 13:35:06 --> Config Class Initialized
INFO - 2020-09-21 13:35:06 --> Loader Class Initialized
INFO - 2020-09-21 13:35:06 --> Helper loaded: url_helper
INFO - 2020-09-21 13:35:06 --> Helper loaded: form_helper
INFO - 2020-09-21 13:35:06 --> Helper loaded: file_helper
INFO - 2020-09-21 13:35:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:35:06 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:35:06 --> Upload Class Initialized
INFO - 2020-09-21 13:35:06 --> Controller Class Initialized
ERROR - 2020-09-21 13:35:06 --> 404 Page Not Found: /index
INFO - 2020-09-21 13:35:07 --> Config Class Initialized
INFO - 2020-09-21 13:35:07 --> Hooks Class Initialized
DEBUG - 2020-09-21 13:35:07 --> UTF-8 Support Enabled
INFO - 2020-09-21 13:35:07 --> Utf8 Class Initialized
INFO - 2020-09-21 13:35:07 --> URI Class Initialized
INFO - 2020-09-21 13:35:07 --> Router Class Initialized
INFO - 2020-09-21 13:35:07 --> Output Class Initialized
INFO - 2020-09-21 13:35:07 --> Security Class Initialized
DEBUG - 2020-09-21 13:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 13:35:07 --> Input Class Initialized
INFO - 2020-09-21 13:35:07 --> Language Class Initialized
INFO - 2020-09-21 13:35:07 --> Language Class Initialized
INFO - 2020-09-21 13:35:07 --> Config Class Initialized
INFO - 2020-09-21 13:35:07 --> Loader Class Initialized
INFO - 2020-09-21 13:35:07 --> Helper loaded: url_helper
INFO - 2020-09-21 13:35:07 --> Helper loaded: form_helper
INFO - 2020-09-21 13:35:07 --> Helper loaded: file_helper
INFO - 2020-09-21 13:35:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 13:35:07 --> Database Driver Class Initialized
DEBUG - 2020-09-21 13:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 13:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 13:35:07 --> Upload Class Initialized
INFO - 2020-09-21 13:35:07 --> Controller Class Initialized
ERROR - 2020-09-21 13:35:07 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:00:45 --> Config Class Initialized
INFO - 2020-09-21 14:00:45 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:00:45 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:00:45 --> Utf8 Class Initialized
INFO - 2020-09-21 14:00:45 --> URI Class Initialized
DEBUG - 2020-09-21 14:00:45 --> No URI present. Default controller set.
INFO - 2020-09-21 14:00:45 --> Router Class Initialized
INFO - 2020-09-21 14:00:45 --> Output Class Initialized
INFO - 2020-09-21 14:00:45 --> Security Class Initialized
DEBUG - 2020-09-21 14:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:00:45 --> Input Class Initialized
INFO - 2020-09-21 14:00:45 --> Language Class Initialized
INFO - 2020-09-21 14:00:45 --> Language Class Initialized
INFO - 2020-09-21 14:00:45 --> Config Class Initialized
INFO - 2020-09-21 14:00:45 --> Loader Class Initialized
INFO - 2020-09-21 14:00:45 --> Helper loaded: url_helper
INFO - 2020-09-21 14:00:45 --> Helper loaded: form_helper
INFO - 2020-09-21 14:00:45 --> Helper loaded: file_helper
INFO - 2020-09-21 14:00:45 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:00:45 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:00:45 --> Upload Class Initialized
INFO - 2020-09-21 14:00:45 --> Controller Class Initialized
DEBUG - 2020-09-21 14:00:45 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:00:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:00:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:00:45 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:00:45 --> Final output sent to browser
DEBUG - 2020-09-21 14:00:45 --> Total execution time: 0.0428
INFO - 2020-09-21 14:05:07 --> Config Class Initialized
INFO - 2020-09-21 14:05:07 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:05:07 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:05:07 --> Utf8 Class Initialized
INFO - 2020-09-21 14:05:07 --> URI Class Initialized
INFO - 2020-09-21 14:05:07 --> Router Class Initialized
INFO - 2020-09-21 14:05:07 --> Output Class Initialized
INFO - 2020-09-21 14:05:07 --> Security Class Initialized
DEBUG - 2020-09-21 14:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:05:07 --> Input Class Initialized
INFO - 2020-09-21 14:05:07 --> Language Class Initialized
INFO - 2020-09-21 14:05:07 --> Language Class Initialized
INFO - 2020-09-21 14:05:07 --> Config Class Initialized
INFO - 2020-09-21 14:05:07 --> Loader Class Initialized
INFO - 2020-09-21 14:05:07 --> Helper loaded: url_helper
INFO - 2020-09-21 14:05:07 --> Helper loaded: form_helper
INFO - 2020-09-21 14:05:07 --> Helper loaded: file_helper
INFO - 2020-09-21 14:05:07 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:05:07 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:05:07 --> Upload Class Initialized
INFO - 2020-09-21 14:05:07 --> Controller Class Initialized
ERROR - 2020-09-21 14:05:07 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:05:11 --> Config Class Initialized
INFO - 2020-09-21 14:05:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:05:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:05:11 --> Utf8 Class Initialized
INFO - 2020-09-21 14:05:11 --> URI Class Initialized
INFO - 2020-09-21 14:05:11 --> Router Class Initialized
INFO - 2020-09-21 14:05:11 --> Output Class Initialized
INFO - 2020-09-21 14:05:11 --> Security Class Initialized
DEBUG - 2020-09-21 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:05:11 --> Input Class Initialized
INFO - 2020-09-21 14:05:11 --> Language Class Initialized
INFO - 2020-09-21 14:05:11 --> Language Class Initialized
INFO - 2020-09-21 14:05:11 --> Config Class Initialized
INFO - 2020-09-21 14:05:11 --> Loader Class Initialized
INFO - 2020-09-21 14:05:11 --> Helper loaded: url_helper
INFO - 2020-09-21 14:05:11 --> Helper loaded: form_helper
INFO - 2020-09-21 14:05:11 --> Helper loaded: file_helper
INFO - 2020-09-21 14:05:11 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:05:11 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:05:11 --> Upload Class Initialized
INFO - 2020-09-21 14:05:11 --> Controller Class Initialized
ERROR - 2020-09-21 14:05:11 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:05:28 --> Config Class Initialized
INFO - 2020-09-21 14:05:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:05:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:05:28 --> Utf8 Class Initialized
INFO - 2020-09-21 14:05:28 --> URI Class Initialized
INFO - 2020-09-21 14:05:28 --> Router Class Initialized
INFO - 2020-09-21 14:05:28 --> Output Class Initialized
INFO - 2020-09-21 14:05:28 --> Security Class Initialized
DEBUG - 2020-09-21 14:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:05:28 --> Input Class Initialized
INFO - 2020-09-21 14:05:28 --> Language Class Initialized
INFO - 2020-09-21 14:05:28 --> Language Class Initialized
INFO - 2020-09-21 14:05:28 --> Config Class Initialized
INFO - 2020-09-21 14:05:28 --> Loader Class Initialized
INFO - 2020-09-21 14:05:28 --> Helper loaded: url_helper
INFO - 2020-09-21 14:05:28 --> Helper loaded: form_helper
INFO - 2020-09-21 14:05:28 --> Helper loaded: file_helper
INFO - 2020-09-21 14:05:28 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:05:28 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:05:28 --> Upload Class Initialized
INFO - 2020-09-21 14:05:28 --> Controller Class Initialized
ERROR - 2020-09-21 14:05:28 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:21:25 --> Config Class Initialized
INFO - 2020-09-21 14:21:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:21:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:21:25 --> Utf8 Class Initialized
INFO - 2020-09-21 14:21:25 --> URI Class Initialized
DEBUG - 2020-09-21 14:21:25 --> No URI present. Default controller set.
INFO - 2020-09-21 14:21:25 --> Router Class Initialized
INFO - 2020-09-21 14:21:25 --> Output Class Initialized
INFO - 2020-09-21 14:21:25 --> Security Class Initialized
DEBUG - 2020-09-21 14:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:21:25 --> Input Class Initialized
INFO - 2020-09-21 14:21:25 --> Language Class Initialized
INFO - 2020-09-21 14:21:25 --> Language Class Initialized
INFO - 2020-09-21 14:21:25 --> Config Class Initialized
INFO - 2020-09-21 14:21:25 --> Loader Class Initialized
INFO - 2020-09-21 14:21:25 --> Helper loaded: url_helper
INFO - 2020-09-21 14:21:25 --> Helper loaded: form_helper
INFO - 2020-09-21 14:21:25 --> Helper loaded: file_helper
INFO - 2020-09-21 14:21:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:21:25 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:21:25 --> Upload Class Initialized
INFO - 2020-09-21 14:21:25 --> Controller Class Initialized
DEBUG - 2020-09-21 14:21:25 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:21:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:21:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:21:25 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:21:25 --> Final output sent to browser
DEBUG - 2020-09-21 14:21:25 --> Total execution time: 0.0619
INFO - 2020-09-21 14:21:26 --> Config Class Initialized
INFO - 2020-09-21 14:21:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:21:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:21:26 --> Utf8 Class Initialized
INFO - 2020-09-21 14:21:26 --> URI Class Initialized
INFO - 2020-09-21 14:21:26 --> Router Class Initialized
INFO - 2020-09-21 14:21:26 --> Output Class Initialized
INFO - 2020-09-21 14:21:26 --> Security Class Initialized
DEBUG - 2020-09-21 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:21:26 --> Input Class Initialized
INFO - 2020-09-21 14:21:26 --> Language Class Initialized
INFO - 2020-09-21 14:21:26 --> Language Class Initialized
INFO - 2020-09-21 14:21:26 --> Config Class Initialized
INFO - 2020-09-21 14:21:26 --> Loader Class Initialized
INFO - 2020-09-21 14:21:26 --> Helper loaded: url_helper
INFO - 2020-09-21 14:21:26 --> Helper loaded: form_helper
INFO - 2020-09-21 14:21:26 --> Helper loaded: file_helper
INFO - 2020-09-21 14:21:26 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:21:26 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:21:26 --> Upload Class Initialized
INFO - 2020-09-21 14:21:26 --> Controller Class Initialized
ERROR - 2020-09-21 14:21:26 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:21:51 --> Config Class Initialized
INFO - 2020-09-21 14:21:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:21:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:21:51 --> Utf8 Class Initialized
INFO - 2020-09-21 14:21:51 --> URI Class Initialized
DEBUG - 2020-09-21 14:21:51 --> No URI present. Default controller set.
INFO - 2020-09-21 14:21:51 --> Router Class Initialized
INFO - 2020-09-21 14:21:51 --> Output Class Initialized
INFO - 2020-09-21 14:21:51 --> Security Class Initialized
DEBUG - 2020-09-21 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:21:51 --> Input Class Initialized
INFO - 2020-09-21 14:21:51 --> Language Class Initialized
INFO - 2020-09-21 14:21:51 --> Language Class Initialized
INFO - 2020-09-21 14:21:51 --> Config Class Initialized
INFO - 2020-09-21 14:21:51 --> Loader Class Initialized
INFO - 2020-09-21 14:21:51 --> Helper loaded: url_helper
INFO - 2020-09-21 14:21:51 --> Helper loaded: form_helper
INFO - 2020-09-21 14:21:51 --> Helper loaded: file_helper
INFO - 2020-09-21 14:21:51 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:21:51 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:21:51 --> Upload Class Initialized
INFO - 2020-09-21 14:21:51 --> Controller Class Initialized
DEBUG - 2020-09-21 14:21:51 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:21:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:21:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:21:51 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:21:51 --> Final output sent to browser
DEBUG - 2020-09-21 14:21:51 --> Total execution time: 0.0429
INFO - 2020-09-21 14:24:01 --> Config Class Initialized
INFO - 2020-09-21 14:24:01 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:24:01 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:24:01 --> Utf8 Class Initialized
INFO - 2020-09-21 14:24:01 --> URI Class Initialized
DEBUG - 2020-09-21 14:24:01 --> No URI present. Default controller set.
INFO - 2020-09-21 14:24:01 --> Router Class Initialized
INFO - 2020-09-21 14:24:01 --> Output Class Initialized
INFO - 2020-09-21 14:24:01 --> Security Class Initialized
DEBUG - 2020-09-21 14:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:24:01 --> Input Class Initialized
INFO - 2020-09-21 14:24:01 --> Language Class Initialized
INFO - 2020-09-21 14:24:01 --> Language Class Initialized
INFO - 2020-09-21 14:24:01 --> Config Class Initialized
INFO - 2020-09-21 14:24:01 --> Loader Class Initialized
INFO - 2020-09-21 14:24:01 --> Helper loaded: url_helper
INFO - 2020-09-21 14:24:01 --> Helper loaded: form_helper
INFO - 2020-09-21 14:24:01 --> Helper loaded: file_helper
INFO - 2020-09-21 14:24:01 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:24:01 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:24:01 --> Upload Class Initialized
INFO - 2020-09-21 14:24:01 --> Controller Class Initialized
DEBUG - 2020-09-21 14:24:01 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:24:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:24:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:24:01 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:24:01 --> Final output sent to browser
DEBUG - 2020-09-21 14:24:01 --> Total execution time: 0.0937
INFO - 2020-09-21 14:24:03 --> Config Class Initialized
INFO - 2020-09-21 14:24:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:24:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:24:03 --> Utf8 Class Initialized
INFO - 2020-09-21 14:24:03 --> URI Class Initialized
INFO - 2020-09-21 14:24:03 --> Router Class Initialized
INFO - 2020-09-21 14:24:03 --> Output Class Initialized
INFO - 2020-09-21 14:24:03 --> Security Class Initialized
DEBUG - 2020-09-21 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:24:03 --> Input Class Initialized
INFO - 2020-09-21 14:24:03 --> Language Class Initialized
INFO - 2020-09-21 14:24:03 --> Language Class Initialized
INFO - 2020-09-21 14:24:03 --> Config Class Initialized
INFO - 2020-09-21 14:24:03 --> Loader Class Initialized
INFO - 2020-09-21 14:24:03 --> Helper loaded: url_helper
INFO - 2020-09-21 14:24:03 --> Helper loaded: form_helper
INFO - 2020-09-21 14:24:03 --> Helper loaded: file_helper
INFO - 2020-09-21 14:24:03 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:24:03 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:24:03 --> Upload Class Initialized
INFO - 2020-09-21 14:24:03 --> Controller Class Initialized
ERROR - 2020-09-21 14:24:03 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:27:57 --> Config Class Initialized
INFO - 2020-09-21 14:27:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:27:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:27:57 --> Utf8 Class Initialized
INFO - 2020-09-21 14:27:57 --> URI Class Initialized
DEBUG - 2020-09-21 14:27:57 --> No URI present. Default controller set.
INFO - 2020-09-21 14:27:57 --> Router Class Initialized
INFO - 2020-09-21 14:27:58 --> Output Class Initialized
INFO - 2020-09-21 14:27:58 --> Security Class Initialized
DEBUG - 2020-09-21 14:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:27:58 --> Input Class Initialized
INFO - 2020-09-21 14:27:58 --> Language Class Initialized
INFO - 2020-09-21 14:27:58 --> Language Class Initialized
INFO - 2020-09-21 14:27:58 --> Config Class Initialized
INFO - 2020-09-21 14:27:58 --> Loader Class Initialized
INFO - 2020-09-21 14:27:58 --> Helper loaded: url_helper
INFO - 2020-09-21 14:27:58 --> Helper loaded: form_helper
INFO - 2020-09-21 14:27:58 --> Helper loaded: file_helper
INFO - 2020-09-21 14:27:58 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:27:58 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:27:58 --> Upload Class Initialized
INFO - 2020-09-21 14:27:58 --> Controller Class Initialized
DEBUG - 2020-09-21 14:27:58 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:27:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:27:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:27:58 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:27:58 --> Final output sent to browser
DEBUG - 2020-09-21 14:27:58 --> Total execution time: 0.0486
INFO - 2020-09-21 14:28:00 --> Config Class Initialized
INFO - 2020-09-21 14:28:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:28:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:28:00 --> Utf8 Class Initialized
INFO - 2020-09-21 14:28:00 --> URI Class Initialized
DEBUG - 2020-09-21 14:28:00 --> No URI present. Default controller set.
INFO - 2020-09-21 14:28:00 --> Router Class Initialized
INFO - 2020-09-21 14:28:00 --> Output Class Initialized
INFO - 2020-09-21 14:28:00 --> Security Class Initialized
DEBUG - 2020-09-21 14:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:28:00 --> Input Class Initialized
INFO - 2020-09-21 14:28:00 --> Language Class Initialized
INFO - 2020-09-21 14:28:00 --> Language Class Initialized
INFO - 2020-09-21 14:28:00 --> Config Class Initialized
INFO - 2020-09-21 14:28:00 --> Loader Class Initialized
INFO - 2020-09-21 14:28:00 --> Helper loaded: url_helper
INFO - 2020-09-21 14:28:00 --> Helper loaded: form_helper
INFO - 2020-09-21 14:28:00 --> Helper loaded: file_helper
INFO - 2020-09-21 14:28:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:28:00 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:28:00 --> Upload Class Initialized
INFO - 2020-09-21 14:28:00 --> Controller Class Initialized
DEBUG - 2020-09-21 14:28:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:28:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:28:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:28:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:28:00 --> Final output sent to browser
DEBUG - 2020-09-21 14:28:00 --> Total execution time: 0.0453
INFO - 2020-09-21 14:28:09 --> Config Class Initialized
INFO - 2020-09-21 14:28:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:28:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:28:09 --> Utf8 Class Initialized
INFO - 2020-09-21 14:28:09 --> URI Class Initialized
INFO - 2020-09-21 14:28:09 --> Router Class Initialized
INFO - 2020-09-21 14:28:09 --> Output Class Initialized
INFO - 2020-09-21 14:28:09 --> Security Class Initialized
DEBUG - 2020-09-21 14:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:28:09 --> Input Class Initialized
INFO - 2020-09-21 14:28:09 --> Language Class Initialized
INFO - 2020-09-21 14:28:09 --> Language Class Initialized
INFO - 2020-09-21 14:28:09 --> Config Class Initialized
INFO - 2020-09-21 14:28:09 --> Loader Class Initialized
INFO - 2020-09-21 14:28:09 --> Helper loaded: url_helper
INFO - 2020-09-21 14:28:09 --> Helper loaded: form_helper
INFO - 2020-09-21 14:28:09 --> Helper loaded: file_helper
INFO - 2020-09-21 14:28:09 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:28:09 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:28:09 --> Upload Class Initialized
INFO - 2020-09-21 14:28:09 --> Controller Class Initialized
ERROR - 2020-09-21 14:28:09 --> 404 Page Not Found: /index
INFO - 2020-09-21 14:28:50 --> Config Class Initialized
INFO - 2020-09-21 14:28:50 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:28:50 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:28:50 --> Utf8 Class Initialized
INFO - 2020-09-21 14:28:50 --> URI Class Initialized
DEBUG - 2020-09-21 14:28:50 --> No URI present. Default controller set.
INFO - 2020-09-21 14:28:50 --> Router Class Initialized
INFO - 2020-09-21 14:28:50 --> Output Class Initialized
INFO - 2020-09-21 14:28:50 --> Security Class Initialized
DEBUG - 2020-09-21 14:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:28:50 --> Input Class Initialized
INFO - 2020-09-21 14:28:50 --> Language Class Initialized
INFO - 2020-09-21 14:28:50 --> Language Class Initialized
INFO - 2020-09-21 14:28:50 --> Config Class Initialized
INFO - 2020-09-21 14:28:50 --> Loader Class Initialized
INFO - 2020-09-21 14:28:50 --> Helper loaded: url_helper
INFO - 2020-09-21 14:28:50 --> Helper loaded: form_helper
INFO - 2020-09-21 14:28:50 --> Helper loaded: file_helper
INFO - 2020-09-21 14:28:50 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:28:50 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:28:50 --> Upload Class Initialized
INFO - 2020-09-21 14:28:50 --> Controller Class Initialized
DEBUG - 2020-09-21 14:28:50 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:28:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:28:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:28:50 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:28:50 --> Final output sent to browser
DEBUG - 2020-09-21 14:28:50 --> Total execution time: 0.0531
INFO - 2020-09-21 14:29:00 --> Config Class Initialized
INFO - 2020-09-21 14:29:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:29:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:29:00 --> Utf8 Class Initialized
INFO - 2020-09-21 14:29:00 --> URI Class Initialized
DEBUG - 2020-09-21 14:29:00 --> No URI present. Default controller set.
INFO - 2020-09-21 14:29:00 --> Router Class Initialized
INFO - 2020-09-21 14:29:00 --> Output Class Initialized
INFO - 2020-09-21 14:29:00 --> Security Class Initialized
DEBUG - 2020-09-21 14:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:29:00 --> Input Class Initialized
INFO - 2020-09-21 14:29:00 --> Language Class Initialized
INFO - 2020-09-21 14:29:00 --> Language Class Initialized
INFO - 2020-09-21 14:29:00 --> Config Class Initialized
INFO - 2020-09-21 14:29:00 --> Loader Class Initialized
INFO - 2020-09-21 14:29:00 --> Helper loaded: url_helper
INFO - 2020-09-21 14:29:00 --> Helper loaded: form_helper
INFO - 2020-09-21 14:29:00 --> Helper loaded: file_helper
INFO - 2020-09-21 14:29:00 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 14:29:00 --> Database Driver Class Initialized
DEBUG - 2020-09-21 14:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 14:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:29:00 --> Upload Class Initialized
INFO - 2020-09-21 14:29:00 --> Controller Class Initialized
DEBUG - 2020-09-21 14:29:00 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 14:29:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 14:29:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 14:29:00 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 14:29:00 --> Final output sent to browser
DEBUG - 2020-09-21 14:29:00 --> Total execution time: 0.0460
INFO - 2020-09-21 15:31:20 --> Config Class Initialized
INFO - 2020-09-21 15:31:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:31:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:31:20 --> Utf8 Class Initialized
INFO - 2020-09-21 15:31:20 --> URI Class Initialized
DEBUG - 2020-09-21 15:31:20 --> No URI present. Default controller set.
INFO - 2020-09-21 15:31:20 --> Router Class Initialized
INFO - 2020-09-21 15:31:20 --> Output Class Initialized
INFO - 2020-09-21 15:31:20 --> Security Class Initialized
DEBUG - 2020-09-21 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:31:20 --> Input Class Initialized
INFO - 2020-09-21 15:31:20 --> Language Class Initialized
INFO - 2020-09-21 15:31:20 --> Language Class Initialized
INFO - 2020-09-21 15:31:20 --> Config Class Initialized
INFO - 2020-09-21 15:31:20 --> Loader Class Initialized
INFO - 2020-09-21 15:31:20 --> Helper loaded: url_helper
INFO - 2020-09-21 15:31:20 --> Helper loaded: form_helper
INFO - 2020-09-21 15:31:20 --> Helper loaded: file_helper
INFO - 2020-09-21 15:31:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:31:20 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:31:20 --> Upload Class Initialized
INFO - 2020-09-21 15:31:20 --> Controller Class Initialized
DEBUG - 2020-09-21 15:31:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:31:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:31:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:31:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:31:20 --> Final output sent to browser
DEBUG - 2020-09-21 15:31:20 --> Total execution time: 0.0604
INFO - 2020-09-21 15:34:14 --> Config Class Initialized
INFO - 2020-09-21 15:34:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:34:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:34:14 --> Utf8 Class Initialized
INFO - 2020-09-21 15:34:14 --> URI Class Initialized
DEBUG - 2020-09-21 15:34:14 --> No URI present. Default controller set.
INFO - 2020-09-21 15:34:14 --> Router Class Initialized
INFO - 2020-09-21 15:34:14 --> Output Class Initialized
INFO - 2020-09-21 15:34:14 --> Security Class Initialized
DEBUG - 2020-09-21 15:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:34:14 --> Input Class Initialized
INFO - 2020-09-21 15:34:14 --> Language Class Initialized
INFO - 2020-09-21 15:34:14 --> Language Class Initialized
INFO - 2020-09-21 15:34:14 --> Config Class Initialized
INFO - 2020-09-21 15:34:14 --> Loader Class Initialized
INFO - 2020-09-21 15:34:14 --> Helper loaded: url_helper
INFO - 2020-09-21 15:34:14 --> Helper loaded: form_helper
INFO - 2020-09-21 15:34:14 --> Helper loaded: file_helper
INFO - 2020-09-21 15:34:14 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:34:14 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:34:14 --> Upload Class Initialized
INFO - 2020-09-21 15:34:14 --> Controller Class Initialized
DEBUG - 2020-09-21 15:34:14 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:34:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:34:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:34:14 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:34:14 --> Final output sent to browser
DEBUG - 2020-09-21 15:34:14 --> Total execution time: 0.0519
INFO - 2020-09-21 15:36:06 --> Config Class Initialized
INFO - 2020-09-21 15:36:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:36:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:36:06 --> Utf8 Class Initialized
INFO - 2020-09-21 15:36:06 --> URI Class Initialized
DEBUG - 2020-09-21 15:36:06 --> No URI present. Default controller set.
INFO - 2020-09-21 15:36:06 --> Router Class Initialized
INFO - 2020-09-21 15:36:06 --> Output Class Initialized
INFO - 2020-09-21 15:36:06 --> Security Class Initialized
DEBUG - 2020-09-21 15:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:36:06 --> Input Class Initialized
INFO - 2020-09-21 15:36:06 --> Language Class Initialized
INFO - 2020-09-21 15:36:06 --> Language Class Initialized
INFO - 2020-09-21 15:36:06 --> Config Class Initialized
INFO - 2020-09-21 15:36:06 --> Loader Class Initialized
INFO - 2020-09-21 15:36:06 --> Helper loaded: url_helper
INFO - 2020-09-21 15:36:06 --> Helper loaded: form_helper
INFO - 2020-09-21 15:36:06 --> Helper loaded: file_helper
INFO - 2020-09-21 15:36:06 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:36:06 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:36:06 --> Upload Class Initialized
INFO - 2020-09-21 15:36:06 --> Controller Class Initialized
DEBUG - 2020-09-21 15:36:06 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:36:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:36:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:36:06 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:36:06 --> Final output sent to browser
DEBUG - 2020-09-21 15:36:06 --> Total execution time: 0.0401
INFO - 2020-09-21 15:41:33 --> Config Class Initialized
INFO - 2020-09-21 15:41:33 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:41:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:41:33 --> Utf8 Class Initialized
INFO - 2020-09-21 15:41:33 --> URI Class Initialized
DEBUG - 2020-09-21 15:41:33 --> No URI present. Default controller set.
INFO - 2020-09-21 15:41:33 --> Router Class Initialized
INFO - 2020-09-21 15:41:33 --> Output Class Initialized
INFO - 2020-09-21 15:41:33 --> Security Class Initialized
DEBUG - 2020-09-21 15:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:41:33 --> Input Class Initialized
INFO - 2020-09-21 15:41:33 --> Language Class Initialized
INFO - 2020-09-21 15:41:33 --> Language Class Initialized
INFO - 2020-09-21 15:41:33 --> Config Class Initialized
INFO - 2020-09-21 15:41:33 --> Loader Class Initialized
INFO - 2020-09-21 15:41:33 --> Helper loaded: url_helper
INFO - 2020-09-21 15:41:33 --> Helper loaded: form_helper
INFO - 2020-09-21 15:41:33 --> Helper loaded: file_helper
INFO - 2020-09-21 15:41:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:41:33 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:41:33 --> Upload Class Initialized
INFO - 2020-09-21 15:41:33 --> Controller Class Initialized
DEBUG - 2020-09-21 15:41:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:41:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:41:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:41:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:41:33 --> Final output sent to browser
DEBUG - 2020-09-21 15:41:33 --> Total execution time: 0.0547
INFO - 2020-09-21 15:51:20 --> Config Class Initialized
INFO - 2020-09-21 15:51:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:51:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:51:20 --> Utf8 Class Initialized
INFO - 2020-09-21 15:51:20 --> URI Class Initialized
DEBUG - 2020-09-21 15:51:20 --> No URI present. Default controller set.
INFO - 2020-09-21 15:51:20 --> Router Class Initialized
INFO - 2020-09-21 15:51:20 --> Output Class Initialized
INFO - 2020-09-21 15:51:20 --> Security Class Initialized
DEBUG - 2020-09-21 15:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:51:20 --> Input Class Initialized
INFO - 2020-09-21 15:51:20 --> Language Class Initialized
INFO - 2020-09-21 15:51:20 --> Language Class Initialized
INFO - 2020-09-21 15:51:20 --> Config Class Initialized
INFO - 2020-09-21 15:51:20 --> Loader Class Initialized
INFO - 2020-09-21 15:51:20 --> Helper loaded: url_helper
INFO - 2020-09-21 15:51:20 --> Helper loaded: form_helper
INFO - 2020-09-21 15:51:20 --> Helper loaded: file_helper
INFO - 2020-09-21 15:51:20 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:51:20 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:51:20 --> Upload Class Initialized
INFO - 2020-09-21 15:51:20 --> Controller Class Initialized
DEBUG - 2020-09-21 15:51:20 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:51:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:51:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:51:20 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:51:20 --> Final output sent to browser
DEBUG - 2020-09-21 15:51:20 --> Total execution time: 0.0584
INFO - 2020-09-21 15:51:21 --> Config Class Initialized
INFO - 2020-09-21 15:51:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:51:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:51:21 --> Utf8 Class Initialized
INFO - 2020-09-21 15:51:21 --> URI Class Initialized
INFO - 2020-09-21 15:51:21 --> Router Class Initialized
INFO - 2020-09-21 15:51:21 --> Output Class Initialized
INFO - 2020-09-21 15:51:21 --> Security Class Initialized
DEBUG - 2020-09-21 15:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:51:21 --> Input Class Initialized
INFO - 2020-09-21 15:51:21 --> Language Class Initialized
INFO - 2020-09-21 15:51:21 --> Language Class Initialized
INFO - 2020-09-21 15:51:21 --> Config Class Initialized
INFO - 2020-09-21 15:51:21 --> Loader Class Initialized
INFO - 2020-09-21 15:51:21 --> Helper loaded: url_helper
INFO - 2020-09-21 15:51:21 --> Helper loaded: form_helper
INFO - 2020-09-21 15:51:21 --> Helper loaded: file_helper
INFO - 2020-09-21 15:51:21 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:51:21 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:51:21 --> Upload Class Initialized
INFO - 2020-09-21 15:51:21 --> Controller Class Initialized
ERROR - 2020-09-21 15:51:21 --> 404 Page Not Found: /index
INFO - 2020-09-21 15:51:23 --> Config Class Initialized
INFO - 2020-09-21 15:51:23 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:51:23 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:51:23 --> Utf8 Class Initialized
INFO - 2020-09-21 15:51:23 --> URI Class Initialized
DEBUG - 2020-09-21 15:51:23 --> No URI present. Default controller set.
INFO - 2020-09-21 15:51:23 --> Router Class Initialized
INFO - 2020-09-21 15:51:23 --> Output Class Initialized
INFO - 2020-09-21 15:51:23 --> Security Class Initialized
DEBUG - 2020-09-21 15:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:51:23 --> Input Class Initialized
INFO - 2020-09-21 15:51:23 --> Language Class Initialized
INFO - 2020-09-21 15:51:23 --> Language Class Initialized
INFO - 2020-09-21 15:51:23 --> Config Class Initialized
INFO - 2020-09-21 15:51:23 --> Loader Class Initialized
INFO - 2020-09-21 15:51:23 --> Helper loaded: url_helper
INFO - 2020-09-21 15:51:23 --> Helper loaded: form_helper
INFO - 2020-09-21 15:51:23 --> Helper loaded: file_helper
INFO - 2020-09-21 15:51:23 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:51:23 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:51:23 --> Upload Class Initialized
INFO - 2020-09-21 15:51:23 --> Controller Class Initialized
DEBUG - 2020-09-21 15:51:23 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:51:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:51:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:51:23 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:51:23 --> Final output sent to browser
DEBUG - 2020-09-21 15:51:23 --> Total execution time: 0.0604
INFO - 2020-09-21 15:51:29 --> Config Class Initialized
INFO - 2020-09-21 15:51:29 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:51:29 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:51:29 --> Utf8 Class Initialized
INFO - 2020-09-21 15:51:29 --> URI Class Initialized
INFO - 2020-09-21 15:51:29 --> Router Class Initialized
INFO - 2020-09-21 15:51:29 --> Output Class Initialized
INFO - 2020-09-21 15:51:29 --> Security Class Initialized
DEBUG - 2020-09-21 15:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:51:29 --> Input Class Initialized
INFO - 2020-09-21 15:51:29 --> Language Class Initialized
INFO - 2020-09-21 15:51:29 --> Language Class Initialized
INFO - 2020-09-21 15:51:29 --> Config Class Initialized
INFO - 2020-09-21 15:51:29 --> Loader Class Initialized
INFO - 2020-09-21 15:51:29 --> Helper loaded: url_helper
INFO - 2020-09-21 15:51:29 --> Helper loaded: form_helper
INFO - 2020-09-21 15:51:29 --> Helper loaded: file_helper
INFO - 2020-09-21 15:51:29 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:51:29 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:51:29 --> Upload Class Initialized
INFO - 2020-09-21 15:51:29 --> Controller Class Initialized
ERROR - 2020-09-21 15:51:29 --> 404 Page Not Found: /index
INFO - 2020-09-21 15:51:31 --> Config Class Initialized
INFO - 2020-09-21 15:51:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:51:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:51:31 --> Utf8 Class Initialized
INFO - 2020-09-21 15:51:31 --> URI Class Initialized
DEBUG - 2020-09-21 15:51:31 --> No URI present. Default controller set.
INFO - 2020-09-21 15:51:31 --> Router Class Initialized
INFO - 2020-09-21 15:51:31 --> Output Class Initialized
INFO - 2020-09-21 15:51:31 --> Security Class Initialized
DEBUG - 2020-09-21 15:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:51:31 --> Input Class Initialized
INFO - 2020-09-21 15:51:31 --> Language Class Initialized
INFO - 2020-09-21 15:51:31 --> Language Class Initialized
INFO - 2020-09-21 15:51:31 --> Config Class Initialized
INFO - 2020-09-21 15:51:31 --> Loader Class Initialized
INFO - 2020-09-21 15:51:31 --> Helper loaded: url_helper
INFO - 2020-09-21 15:51:31 --> Helper loaded: form_helper
INFO - 2020-09-21 15:51:31 --> Helper loaded: file_helper
INFO - 2020-09-21 15:51:31 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 15:51:31 --> Database Driver Class Initialized
DEBUG - 2020-09-21 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 15:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:51:31 --> Upload Class Initialized
INFO - 2020-09-21 15:51:31 --> Controller Class Initialized
DEBUG - 2020-09-21 15:51:31 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 15:51:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 15:51:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 15:51:31 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 15:51:31 --> Final output sent to browser
DEBUG - 2020-09-21 15:51:31 --> Total execution time: 0.0544
INFO - 2020-09-21 16:06:52 --> Config Class Initialized
INFO - 2020-09-21 16:06:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:06:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:06:52 --> Utf8 Class Initialized
INFO - 2020-09-21 16:06:52 --> URI Class Initialized
INFO - 2020-09-21 16:06:52 --> Router Class Initialized
INFO - 2020-09-21 16:06:52 --> Output Class Initialized
INFO - 2020-09-21 16:06:52 --> Security Class Initialized
DEBUG - 2020-09-21 16:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:06:52 --> Input Class Initialized
INFO - 2020-09-21 16:06:52 --> Language Class Initialized
INFO - 2020-09-21 16:06:52 --> Language Class Initialized
INFO - 2020-09-21 16:06:52 --> Config Class Initialized
INFO - 2020-09-21 16:06:52 --> Loader Class Initialized
INFO - 2020-09-21 16:06:52 --> Helper loaded: url_helper
INFO - 2020-09-21 16:06:52 --> Helper loaded: form_helper
INFO - 2020-09-21 16:06:52 --> Helper loaded: file_helper
INFO - 2020-09-21 16:06:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 16:06:52 --> Database Driver Class Initialized
DEBUG - 2020-09-21 16:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 16:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:06:52 --> Upload Class Initialized
INFO - 2020-09-21 16:06:52 --> Controller Class Initialized
ERROR - 2020-09-21 16:06:52 --> 404 Page Not Found: /index
INFO - 2020-09-21 16:11:25 --> Config Class Initialized
INFO - 2020-09-21 16:11:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:11:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:11:25 --> Utf8 Class Initialized
INFO - 2020-09-21 16:11:25 --> URI Class Initialized
DEBUG - 2020-09-21 16:11:25 --> No URI present. Default controller set.
INFO - 2020-09-21 16:11:25 --> Router Class Initialized
INFO - 2020-09-21 16:11:25 --> Output Class Initialized
INFO - 2020-09-21 16:11:25 --> Security Class Initialized
DEBUG - 2020-09-21 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:11:25 --> Input Class Initialized
INFO - 2020-09-21 16:11:25 --> Language Class Initialized
INFO - 2020-09-21 16:11:25 --> Language Class Initialized
INFO - 2020-09-21 16:11:25 --> Config Class Initialized
INFO - 2020-09-21 16:11:25 --> Loader Class Initialized
INFO - 2020-09-21 16:11:25 --> Helper loaded: url_helper
INFO - 2020-09-21 16:11:25 --> Helper loaded: form_helper
INFO - 2020-09-21 16:11:25 --> Helper loaded: file_helper
INFO - 2020-09-21 16:11:25 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 16:11:25 --> Database Driver Class Initialized
DEBUG - 2020-09-21 16:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:11:25 --> Upload Class Initialized
INFO - 2020-09-21 16:11:26 --> Controller Class Initialized
DEBUG - 2020-09-21 16:11:26 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 16:11:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 16:11:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 16:11:26 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 16:11:26 --> Final output sent to browser
DEBUG - 2020-09-21 16:11:26 --> Total execution time: 0.0507
INFO - 2020-09-21 16:15:56 --> Config Class Initialized
INFO - 2020-09-21 16:15:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:15:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:15:56 --> Utf8 Class Initialized
INFO - 2020-09-21 16:15:56 --> URI Class Initialized
INFO - 2020-09-21 16:15:56 --> Router Class Initialized
INFO - 2020-09-21 16:15:56 --> Output Class Initialized
INFO - 2020-09-21 16:15:56 --> Security Class Initialized
DEBUG - 2020-09-21 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:15:56 --> Input Class Initialized
INFO - 2020-09-21 16:15:56 --> Language Class Initialized
INFO - 2020-09-21 16:15:56 --> Language Class Initialized
INFO - 2020-09-21 16:15:56 --> Config Class Initialized
INFO - 2020-09-21 16:15:56 --> Loader Class Initialized
INFO - 2020-09-21 16:15:56 --> Helper loaded: url_helper
INFO - 2020-09-21 16:15:56 --> Helper loaded: form_helper
INFO - 2020-09-21 16:15:56 --> Helper loaded: file_helper
INFO - 2020-09-21 16:15:56 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 16:15:56 --> Database Driver Class Initialized
DEBUG - 2020-09-21 16:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:15:56 --> Upload Class Initialized
INFO - 2020-09-21 16:15:56 --> Controller Class Initialized
ERROR - 2020-09-21 16:15:56 --> 404 Page Not Found: /index
INFO - 2020-09-21 16:15:57 --> Config Class Initialized
INFO - 2020-09-21 16:15:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:15:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:15:57 --> Utf8 Class Initialized
INFO - 2020-09-21 16:15:57 --> URI Class Initialized
INFO - 2020-09-21 16:15:57 --> Router Class Initialized
INFO - 2020-09-21 16:15:57 --> Output Class Initialized
INFO - 2020-09-21 16:15:57 --> Security Class Initialized
DEBUG - 2020-09-21 16:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:15:57 --> Input Class Initialized
INFO - 2020-09-21 16:15:57 --> Language Class Initialized
INFO - 2020-09-21 16:15:57 --> Language Class Initialized
INFO - 2020-09-21 16:15:57 --> Config Class Initialized
INFO - 2020-09-21 16:15:57 --> Loader Class Initialized
INFO - 2020-09-21 16:15:57 --> Helper loaded: url_helper
INFO - 2020-09-21 16:15:57 --> Helper loaded: form_helper
INFO - 2020-09-21 16:15:57 --> Helper loaded: file_helper
INFO - 2020-09-21 16:15:57 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 16:15:57 --> Database Driver Class Initialized
DEBUG - 2020-09-21 16:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 16:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:15:57 --> Upload Class Initialized
INFO - 2020-09-21 16:15:57 --> Controller Class Initialized
ERROR - 2020-09-21 16:15:57 --> 404 Page Not Found: /index
INFO - 2020-09-21 17:17:33 --> Config Class Initialized
INFO - 2020-09-21 17:17:33 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:17:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:17:33 --> Utf8 Class Initialized
INFO - 2020-09-21 17:17:33 --> URI Class Initialized
DEBUG - 2020-09-21 17:17:33 --> No URI present. Default controller set.
INFO - 2020-09-21 17:17:33 --> Router Class Initialized
INFO - 2020-09-21 17:17:33 --> Output Class Initialized
INFO - 2020-09-21 17:17:33 --> Security Class Initialized
DEBUG - 2020-09-21 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:17:33 --> Input Class Initialized
INFO - 2020-09-21 17:17:33 --> Language Class Initialized
INFO - 2020-09-21 17:17:33 --> Language Class Initialized
INFO - 2020-09-21 17:17:33 --> Config Class Initialized
INFO - 2020-09-21 17:17:33 --> Loader Class Initialized
INFO - 2020-09-21 17:17:33 --> Helper loaded: url_helper
INFO - 2020-09-21 17:17:33 --> Helper loaded: form_helper
INFO - 2020-09-21 17:17:33 --> Helper loaded: file_helper
INFO - 2020-09-21 17:17:33 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 17:17:33 --> Database Driver Class Initialized
DEBUG - 2020-09-21 17:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:17:33 --> Upload Class Initialized
INFO - 2020-09-21 17:17:33 --> Controller Class Initialized
DEBUG - 2020-09-21 17:17:33 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 17:17:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 17:17:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 17:17:33 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 17:17:33 --> Final output sent to browser
DEBUG - 2020-09-21 17:17:33 --> Total execution time: 0.0642
INFO - 2020-09-21 17:17:52 --> Config Class Initialized
INFO - 2020-09-21 17:17:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:17:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:17:52 --> Utf8 Class Initialized
INFO - 2020-09-21 17:17:52 --> URI Class Initialized
DEBUG - 2020-09-21 17:17:52 --> No URI present. Default controller set.
INFO - 2020-09-21 17:17:52 --> Router Class Initialized
INFO - 2020-09-21 17:17:52 --> Output Class Initialized
INFO - 2020-09-21 17:17:52 --> Security Class Initialized
DEBUG - 2020-09-21 17:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:17:52 --> Input Class Initialized
INFO - 2020-09-21 17:17:52 --> Language Class Initialized
INFO - 2020-09-21 17:17:52 --> Language Class Initialized
INFO - 2020-09-21 17:17:52 --> Config Class Initialized
INFO - 2020-09-21 17:17:52 --> Loader Class Initialized
INFO - 2020-09-21 17:17:52 --> Helper loaded: url_helper
INFO - 2020-09-21 17:17:52 --> Helper loaded: form_helper
INFO - 2020-09-21 17:17:52 --> Helper loaded: file_helper
INFO - 2020-09-21 17:17:52 --> Helper loaded: myhelper_helper
INFO - 2020-09-21 17:17:52 --> Database Driver Class Initialized
DEBUG - 2020-09-21 17:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-21 17:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:17:52 --> Upload Class Initialized
INFO - 2020-09-21 17:17:52 --> Controller Class Initialized
DEBUG - 2020-09-21 17:17:52 --> Home MX_Controller Initialized
DEBUG - 2020-09-21 17:17:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/header.php
DEBUG - 2020-09-21 17:17:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/home.php
DEBUG - 2020-09-21 17:17:52 --> File loaded: /home/myfive11/public_html/application/modules/home/views/footer.php
INFO - 2020-09-21 17:17:52 --> Final output sent to browser
DEBUG - 2020-09-21 17:17:52 --> Total execution time: 0.0526
